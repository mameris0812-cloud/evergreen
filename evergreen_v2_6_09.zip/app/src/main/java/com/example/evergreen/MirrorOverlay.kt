package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.SystemClock
import android.util.LruCache
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.abs

/** 가운데 안내(이동 시간·배속 등)는 위쪽 바 아래 가운데에 — 한가운데에는 컨트롤 버튼이 있다 */
private const val OSD_GRAVITY = android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL

/**
 * 미러링(페이지 영상을 창 가득 보기) 위에 얹는 내장 플레이어 스타일 컨트롤.
 * 페이지의 영상에는 명령(재생/일시정지·이동·배속·화면 비율)만 보내고, 상태는 페이지가 알려 오는 값을 쓴다.
 *
 * - 위: 닫기 · 제목/사이트 · 화면 비율 · 작은 창(PiP) · 회전
 * - 아래: 재생/일시정지 · 10초 뒤로/앞으로 · 시간 · 진행 막대(끌어서 이동) · 배속
 * - 자막: 위쪽 CC 버튼 → 페이지 영상의 자막 트랙 / 페이지가 불러온 자막 파일을 골라 앱이 직접 그린다
 *   (한국어 번역 · 글자 크기 · 배경 · 위치는 내장 플레이어와 같은 설정)
 * - 제스처: 한 번 탭 = 컨트롤 보이기/숨기기, 두 번 탭 = ±10초(연달아 하면 누적), 길게 누르기 = 2배속,
 *   가로로 쓸기 = 시간 이동(손을 떼면 이동)
 */
class MirrorOverlay(ctx: Context) : FrameLayout(ctx) {

    /** 페이지 영상에 보내는 조작: toggle / seek(초) / skip(±초) / rate(배속) / fit(0 맞춤·1 채움·2 늘림) */
    var onCommand: (String, Double) -> Unit = { _, _ -> }
    var onClose: () -> Unit = {}
    var onPip: (() -> Unit)? = null
    var onRotate: () -> Unit = {}
    /** 화질 바꾸기: 페이지가 알려 준 화질 번호(유튜브는 hd720 같은 이름, 자동은 auto) */
    var onQuality: ((String) -> Unit)? = null

    /** 페이지가 따로 불러온 자막 파일 주소들 (페이지 <track> 과 겹치는 것은 이 안에서 걸러 낸다) */
    var fileSubProvider: () -> List<String> = { emptyList() }

    /** 자막 파일 내용을 받아 온다 (백그라운드 스레드에서 불린다) */
    var fileFetcher: (String) -> String? = { null }

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val accent = ctx.getColor(R.color.ev_accent)
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
    private val fitNames = arrayOf("화면에 맞추기", "화면 채우기", "화면에 늘리기")

    // ── 영상 상태: 페이지가 알려 준 값 + 방금 직접 조작한 동안의 예상값 ──
    private var pos = 0.0
    private var dur = -1.0
    private var playing = false
    private var rate = 1f
    private var at = 0L
    private var ovPos = 0.0
    private var ovAt = 0L
    private var ovUntil = 0L
    private var ovPlay = false
    private var ovPlayUntil = 0L
    private var fitIdx = 0
    private var scrubPos = -1.0

    private fun curPlaying(): Boolean =
        if (SystemClock.uptimeMillis() < ovPlayUntil) ovPlay else playing

    private fun curPos(): Double {
        val now = SystemClock.uptimeMillis()
        val v = when {
            now < ovUntil -> ovPos + (if (curPlaying()) (now - ovAt) / 1000.0 * rate else 0.0)
            playing -> pos + (now - at) / 1000.0 * rate
            else -> pos
        }
        return if (dur > 0) v.coerceIn(0.0, dur) else v.coerceAtLeast(0.0)
    }

    private fun fmt(sec: Double): String {
        val s = sec.toLong().coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, ss)
        else String.format(java.util.Locale.US, "%d:%02d", m, ss)
    }

    // ── 화면 ──
    private val controls = FrameLayout(ctx)
    private val titleView = TextView(ctx)
    private val hostView = TextView(ctx)
    private val playBtn = ImageButton(ctx)
    private val timeText = TextView(ctx)
    private val speedChip = TextView(ctx)
    private val seek = MirrorSeekBar(ctx, accent)
    private val osd = TextView(ctx)
    private val pipBtn = iconBtn(R.drawable.ic_pip, "작은 창으로 보기", 6, "pip") { onPip?.invoke() }
    /** 재생/일시정지 버튼 아이콘 (재생 ↔ 일시정지로 모양이 변한다) */
    private var playIcon: MorphIconDrawable? = null
    /** 내장 플레이어 아래 줄의 CC 칩과 같은 모양 */
    private val ccChip = TextView(ctx).apply {
        text = "CC"
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        minWidth = dp(40)
        setPadding(dp(8), 0, dp(8), 0)
        setBackgroundResource(R.drawable.ev_chip_bg)
        contentDescription = "자막"
        setOnClickListener { openSubPanel(); scheduleHide() }
        Motion.barButton(this, "chip")
    }
    /** 위쪽 바의 '자막 번역' 칩 (내장 플레이어와 같다): 자막을 켜 둔 동안만 보이고, 누를 때마다 번역 끔 → 자막 번역 → 번역+원문 */
    private val subChip = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        minWidth = dp(64)
        setPadding(dp(12), 0, dp(12), 0)
        contentDescription = "자막 번역"
        visibility = View.GONE
        setOnClickListener { cycleSubTranslate(); scheduleHide() }
        Motion.barButton(this, "chip")
    }
    private class QOpt(val id: String, val name: String)
    private var qOpts: List<QOpt> = emptyList()
    private var qSel = ""
    private var lastIconPlaying: Boolean? = null
    private var controlsOn = false

    // ── 자막 ──
    private val prefs = Prefs(ctx)
    private class PageTrack(val idx: Int, val label: String, val lang: String, val url: String)
    private class SubOpt(val label: String, val pageIdx: Int, val url: String?, val lang: String = "")

    private var pageTracks: List<PageTrack> = emptyList()
    private var fileSubUrls: List<String> = emptyList()
    private var subSel: SubOpt? = null
    private var fileCues: List<SubtitleFile.Cue>? = null
    private val fileCueCache = HashMap<String, List<SubtitleFile.Cue>>()
    private val fileExec = Executors.newSingleThreadExecutor()
    private val subExec = Executors.newSingleThreadExecutor()
    private val subTranslator = FreeTranslator()
    private val subCache = LruCache<String, String>(600)
    private val subPending = HashSet<String>()
    private var lastSubErrAt = 0L
    private var subHinted = false
    private var reportN = 0
    private var curRaw = ""
    private var lastRawCue = "\u0000"
    private var curOrig = ""
    private var subKey = ""
    private var subSourceKo = false
    private var subPanel: FrameLayout? = null
    private var released = false
    private val subMain = TextView(ctx)
    private val subOrig = TextView(ctx)
    private val subOverlay = LinearLayout(ctx)
    private val subSizeNames = listOf("작게", "보통", "크게", "아주 크게")
    private val subSizeScale = floatArrayOf(0.8f, 1f, 1.3f, 1.7f)
    private val subBgNames = listOf("기본", "없음", "반투명", "검정")
    private val subPosNames = listOf("낮게", "보통", "높게")

    /** kind: 내장 플레이어·메인 브라우저 바 버튼과 같은 눌림 + 아이콘 모양 변화 (Motion.barButton) */
    private fun iconBtn(res: Int, desc: String, padDp: Int, kind: String, onClick: () -> Unit) = ImageButton(context).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE)
        scaleType = ImageView.ScaleType.FIT_CENTER
        background = null
        contentDescription = desc
        setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
        setOnClickListener { onClick(); scheduleHide() }
        Motion.barButton(this, kind)
    }

    /** 10초 이동 버튼: 화살표와 숫자 10 이 한 그림 (눌리면 화살표만 가는 방향으로 쏜다) */
    private fun skipBtn(res: Int, desc: String, kind: String, onClick: () -> Unit): View =
        iconBtn(res, desc, 10, kind, onClick)

    private val tapFx = DoubleTapFx(ctx)

    init {
        isClickable = true
        isFocusable = false

        // 컨트롤이 보이는 동안 영상을 살짝 어둡게 (한가운데 버튼이 밝은 영상 위에서도 보이게)
        controls.addView(View(ctx).apply { setBackgroundColor(0x33000000) },
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        // 위·아래 어두운 막
        controls.addView(View(ctx).apply { setBackgroundResource(R.drawable.ev_scrim_top) },
            LayoutParams(LayoutParams.MATCH_PARENT, dp(96), Gravity.TOP))
        controls.addView(View(ctx).apply { setBackgroundResource(R.drawable.ev_scrim_bottom) },
            LayoutParams(LayoutParams.MATCH_PARENT, dp(150), Gravity.BOTTOM))

        // 위쪽 바
        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        top.addView(iconBtn(R.drawable.ic_back, "닫기", 6, "back") { onClose() }, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titleCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        titleView.apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setShadowLayer(dp(2).toFloat(), 0f, 0f, 0x99000000.toInt())
        }
        hostView.apply {
            setTextColor(0xB3FFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setShadowLayer(dp(2).toFloat(), 0f, 0f, 0x99000000.toInt())
        }
        titleCol.addView(titleView)
        titleCol.addView(hostView)
        top.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
        top.addView(subChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)))
        top.addView(pipBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        top.addView(iconBtn(R.drawable.ic_rotate, "화면 회전", 6, "rotate") { onRotate() }, LinearLayout.LayoutParams(dp(46), dp(46)))
        controls.addView(top, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // 아래쪽: 진행 막대 + 한 줄
        val bottom = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(12), dp(10))
        }
        seek.onScrub = { phase, f -> onScrub(phase, f) }
        // 진행 막대는 한 줄을 통째로 쓰고, 시간은 맨 아래 줄 왼쪽에 둔다
        val seekRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        seekRow.addView(seek, LinearLayout.LayoutParams(0, dp(40), 1f))
        bottom.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // 화면 한가운데: 이전 · 10초 뒤로 · 재생/일시정지 · 10초 앞으로 · 다음 — 좌우 대칭
        val transport = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        playBtn.apply {
            setBackgroundResource(R.drawable.ev_ctrl_play_bg)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            contentDescription = "재생"
            setImageResource(R.drawable.ic_play)
            setOnClickListener { toggle() }
            // 탭해도 따로 튀지 않고, 재생 상태(refresh)에 따라 삼각형 ↔ 두 막대로 모양이 변한다
            playIcon = Motion.barButton(this, "player", playOnTap = false)
        }
        transport.addView(iconBtn(R.drawable.ic_skip_prev, "이전 영상", 10, "skip") { onCommand("prev", 0.0); showOsd("이전 영상") }, LinearLayout.LayoutParams(dp(44), dp(44)))
        transport.addView(skipBtn(R.drawable.ic_rewind_10, "10초 뒤로", "skipback") { skip(-10.0) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        transport.addView(playBtn, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginStart = dp(10); marginEnd = dp(10) })
        transport.addView(skipBtn(R.drawable.ic_forward_10, "10초 앞으로", "skipfwd") { skip(10.0) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        transport.addView(iconBtn(R.drawable.ic_skip_next, "다음 영상", 10, "skip") { onCommand("next", 0.0); showOsd("다음 영상") }, LinearLayout.LayoutParams(dp(44), dp(44)))
        controls.addView(transport, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // 맨 아래 줄: 시간(왼쪽) … 배속 / CC / 설정(오른쪽)
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        timeText.apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = false
            fontFeatureSettings = "tnum"
            setShadowLayer(dp(2).toFloat(), 0f, 0f, 0xAA000000.toInt())
        }
        row.addView(timeText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(4) })
        row.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        speedChip.apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(40)
            setPadding(dp(8), 0, dp(8), 0)
            contentDescription = "재생 속도"
            setOnClickListener { cycleSpeed(); scheduleHide() }
            Motion.barButton(this, "chip")
        }
        row.addView(speedChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)))
        row.addView(ccChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)).apply { marginStart = dp(4) })
        // 톱니: 화질 · 자막 · 재생 속도 · 화면 비율 (내장 플레이어의 설정과 같은 구성)
        row.addView(iconBtn(R.drawable.ic_settings, "설정", 8, "settings") { openSubPanel("settings") }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bottom.addView(row)
        controls.addView(bottom, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        // 더블탭 효과는 컨트롤 아래에 깐다 (그리기만 하고 터치는 통과)
        addView(tapFx, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(controls, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        buildSubOverlay()

        // 가운데 표시창 (이동 시간·배속 등)
        osd.apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xCC000000.toInt())
                setStroke(dp(1), 0x1FFFFFFF)
            }
            visibility = View.GONE
        }
        addView(osd, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, OSD_GRAVITY).apply { topMargin = dp(72) })

        updateSpeedChip()
        refresh()
    }

    // ───────────────────────── 바깥에서 부르는 것 ─────────────────────────

    /** 작은 창(PiP)을 지원하지 않는 기기에서는 버튼을 감춘다 */
    fun setPipAvailable(on: Boolean) {
        pipBtn.visibility = if (on) View.VISIBLE else View.GONE
    }

    fun setTitle(title: String, host: String) {
        titleView.text = title.ifBlank { host.ifBlank { "동영상" } }
        hostView.text = if (title.isNotBlank()) host else ""
        hostView.visibility = if (title.isNotBlank() && host.isNotBlank()) View.VISIBLE else View.GONE
    }

    /** 페이지가 알려 온 재생 상태 (약 0.5초마다 + 재생·정지·이동 때) */
    fun report(position: Double, duration: Double, isPlaying: Boolean, speed: Double) {
        val was = playing
        pos = position
        dur = duration
        playing = isPlaying
        rate = speed.toFloat().coerceIn(0.1f, 8f)
        at = SystemClock.uptimeMillis()
        updateSpeedChip()
        refresh()
        if ((reportN++ and 3) == 0) refreshFileSubs()
        if (controlsOn) startTick()
        if (was != isPlaying) {
            if (!isPlaying && !controlsOn) setControls(true) else scheduleHide()
        }
    }

    /** 처음 나타날 때 컨트롤을 보여 준다 */
    fun start() {
        setControls(true)
    }

    // ───────────────────────── 조작 ─────────────────────────

    private fun toggle() {
        val now = SystemClock.uptimeMillis()
        val p = curPos()
        ovPlay = !curPlaying()
        ovPlayUntil = now + 700
        ovPos = p
        ovAt = now
        ovUntil = now + 700
        onCommand("toggle", 0.0)
        refresh()
        startTick()
        scheduleHide()
    }

    private fun skip(delta: Double) {
        val now = SystemClock.uptimeMillis()
        var t = curPos() + delta
        if (dur > 0) t = t.coerceIn(0.0, dur) else t = t.coerceAtLeast(0.0)
        ovPos = t
        ovAt = now
        ovUntil = now + 900
        onCommand("skip", delta)
        refresh()
        startTick()
    }

    private fun seekTo(sec: Double) {
        val now = SystemClock.uptimeMillis()
        val t = if (dur > 0) sec.coerceIn(0.0, dur) else sec.coerceAtLeast(0.0)
        ovPos = t
        ovAt = now
        ovUntil = now + 900
        onCommand("seek", t)
        refresh()
        startTick()
    }

    private fun setRate(r: Float) {
        // 배속이 바뀌기 전까지의 위치를 기준점으로 잡아 둔다
        pos = curPos()
        at = SystemClock.uptimeMillis()
        rate = r
        onCommand("rate", r.toDouble())
        updateSpeedChip()
    }

    private fun speedLabel(v: Float) = if (v % 1f == 0f) "${v.toInt()}x" else "${v}x"

    private fun cycleSpeed() {
        val i = speeds.indexOfFirst { abs(it - rate) < 0.01f }
        val next = if (i < 0) 1f else speeds[(i + 1) % speeds.size]
        setRate(next)
        showOsd("${speedLabel(next)} 배속")
    }

    private fun updateSpeedChip() {
        speedChip.text = speedLabel(rate)
        // 1배속이 아니면 포인트 색으로
        val bg = if (abs(rate - 1f) < 0.01f) 0x29FFFFFF else accent
        speedChip.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(bg)
        }
    }

    private fun cycleFit() {
        fitIdx = (fitIdx + 1) % fitNames.size
        onCommand("fit", fitIdx.toDouble())
        showOsd(fitNames[fitIdx])
    }

    /** 진행 막대를 끄는 동안: 이동할 시간 표시, 손을 떼면 이동 */
    private fun onScrub(phase: Int, f: Float) {
        if (dur <= 0) return
        when (phase) {
            0, 1 -> {
                scrubPos = f * dur
                val diff = (scrubPos - curPos()).toLong()
                showOsd("${fmt(scrubPos)} / ${fmt(dur)}\n${if (diff >= 0) "+" else ""}${diff}초", 1500)
                removeCallbacks(hideRun)
                refresh()
            }
            2 -> {
                val t = scrubPos
                scrubPos = -1.0
                if (t >= 0) seekTo(t)
                removeCallbacks(hideOsdRun)
                postDelayed(hideOsdRun, 350)
                scheduleHide()
            }
            else -> {
                scrubPos = -1.0
                scheduleHide()
            }
        }
    }

    // ───────────────────────── 컨트롤 보이기/숨기기 · 갱신 ─────────────────────────

    private val hideRun = Runnable { if (!seek.scrubbing && subPanel == null) setControls(false) }

    private fun scheduleHide() {
        removeCallbacks(hideRun)
        if (controlsOn && curPlaying() && !seek.scrubbing) postDelayed(hideRun, 3000L)
    }

    private fun setControls(on: Boolean) {
        controlsOn = on
        liftSub()
        controls.animate().cancel()
        if (on) {
            if (controls.visibility != View.VISIBLE) {
                controls.alpha = 0f
                controls.visibility = View.VISIBLE
            }
            controls.animate().alpha(1f).setDuration(180).setInterpolator(DecelerateInterpolator(1.5f)).start()
            refresh()
            startTick()
            scheduleHide()
        } else {
            removeCallbacks(hideRun)
            controls.animate().alpha(0f).setDuration(160)
                .withEndAction { if (!controlsOn) controls.visibility = View.GONE }.start()
        }
    }

    private var ticking = false
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            val keep = isAttachedToWindow && controls.visibility == View.VISIBLE &&
                (curPlaying() || SystemClock.uptimeMillis() < ovUntil)
            if (keep) postOnAnimation(this) else ticking = false
        }
    }

    private fun startTick() {
        if (ticking || !isAttachedToWindow) return
        ticking = true
        postOnAnimation(tick)
    }

    private fun refresh() {
        val known = dur > 0
        val p = if (scrubPos >= 0) scrubPos else curPos()
        if (!seek.scrubbing && seekTarget < 0) seek.fraction = if (known) (p / dur).toFloat() else 0f
        seek.enabledSeek = known
        timeText.text = if (known) "${fmt(p)} / ${fmt(dur)}" else fmt(p)
        val pl = curPlaying()
        if (lastIconPlaying != pl) {
            lastIconPlaying = pl
            val icon = playIcon
            if (icon != null) icon.settle(if (pl) 1f else 0f, isShown && Motion.enabled(context))
            else playBtn.setImageResource(if (pl) R.drawable.ic_pause else R.drawable.ic_play)
            playBtn.contentDescription = if (pl) "일시정지" else "재생"
        }
    }

    // ───────────────────────── 가운데 표시창 ─────────────────────────

    private val hideOsdRun = Runnable { fadeOutOsd() }

    private fun showOsd(text: String, hideAfterMs: Long = 700, gravity: Int = OSD_GRAVITY) {
        (osd.layoutParams as LayoutParams).let { lp ->
            if (lp.gravity != gravity) {
                lp.gravity = gravity
                // 가운데에는 컨트롤 버튼이 있으므로 기본 안내는 위쪽 바 바로 아래에 띄운다
                lp.topMargin = if ((gravity and Gravity.VERTICAL_GRAVITY_MASK) == Gravity.TOP) dp(72) else 0
                lp.marginStart = if ((gravity and Gravity.START) == Gravity.START) dp(56) else 0
                lp.marginEnd = if ((gravity and Gravity.END) == Gravity.END) dp(56) else 0
                osd.layoutParams = lp
            }
        }
        osd.text = text
        removeCallbacks(hideOsdRun)
        if (osd.visibility != View.VISIBLE || osd.alpha < 1f) {
            osd.animate().cancel()
            if (osd.visibility != View.VISIBLE) {
                osd.alpha = 0f
                osd.scaleX = 0.9f
                osd.scaleY = 0.9f
            }
            osd.visibility = View.VISIBLE
            osd.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        postDelayed(hideOsdRun, hideAfterMs)
    }

    private fun fadeOutOsd() {
        osd.animate().cancel()
        osd.animate().alpha(0f).scaleX(0.95f).scaleY(0.95f).setDuration(160)
            .withEndAction { if (osd.alpha <= 0.01f) osd.visibility = View.GONE }.start()
    }

    // ───────────────────────── 자막 ─────────────────────────

    private fun buildSubOverlay() {
        subMain.apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(dp(3).toFloat(), 0f, 0f, Color.BLACK)
        }
        subOrig.apply {
            setTextColor(0xCCFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            setShadowLayer(dp(3).toFloat(), 0f, 0f, Color.BLACK)
            visibility = View.GONE
        }
        subOverlay.apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(0x99000000.toInt())
            }
            visibility = View.GONE
            addView(subMain)
            addView(subOrig)
        }
        // 터치는 그대로 아래 영상(제스처)으로 통과한다
        addView(
            subOverlay,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                marginStart = dp(32)
                marginEnd = dp(32)
            }
        )
        applySubStyle()
    }

    /** 컨트롤(진행 막대)이 보이면 자막이 가리지 않게 위로 올린다 */
    private fun liftSub() {
        subOverlay.animate().cancel()
        subOverlay.animate().translationY(if (controlsOn) -dp(92).toFloat() else 0f).setDuration(180).start()
    }

    /** 내장 플레이어와 같은 자막 모양 설정 (크기 · 배경 · 위치) */
    private fun applySubStyle() {
        val scale = subSizeScale[prefs.subSize.coerceIn(0, 3)]
        val bg = prefs.subBg.coerceIn(0, 3)
        val pos = prefs.subPos.coerceIn(0, 2)
        subMain.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f * scale)
        subOrig.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f * scale)
        (subOverlay.background as? GradientDrawable)?.setColor(
            when (bg) { 1 -> Color.TRANSPARENT; 3 -> Color.BLACK; else -> 0x99000000.toInt() }
        )
        (subOverlay.layoutParams as? LayoutParams)?.let { lp ->
            lp.bottomMargin = dp(intArrayOf(12, 28, 84)[pos])
            subOverlay.layoutParams = lp
        }
    }

    /** 페이지 플레이어가 알려 온 화질 목록 (JSON: {k, sel, l:[{id, n}]}). 빈 글이면 화질 칩을 숨긴다 */
    fun setQualities(json: String) {
        if (released) return
        val list = ArrayList<QOpt>()
        var sel = ""
        try {
            if (json.isNotBlank()) {
                val o = JSONObject(json)
                sel = o.optString("sel")
                val a = o.getJSONArray("l")
                for (k in 0 until a.length()) {
                    val q = a.getJSONObject(k)
                    list.add(QOpt(q.optString("id"), q.optString("n")))
                }
            }
        } catch (_: Exception) {
            list.clear()
        }
        qOpts = list
        qSel = sel
        // 설정·화질 창이 열려 있는 채로 목록이 바뀌면 새 목록으로 다시 그린다
        if (subPanel != null && subCard != null) {
            if (subPage == "quality" && list.size < 2) renderSubPage("settings", animate = false)
            else if (subPage == "quality" || subPage == "settings") renderSubPage(subPage, animate = false)
        }
    }

    /** 페이지가 알려 온 자막 트랙 목록 (JSON: [{i, l, g, u}]) */
    fun setPageTracks(json: String) {
        if (released) return
        val list = ArrayList<PageTrack>()
        try {
            val a = JSONArray(json)
            for (k in 0 until a.length()) {
                val o = a.getJSONObject(k)
                list.add(PageTrack(o.optInt("i", -1), o.optString("l"), o.optString("g"), o.optString("u")))
            }
        } catch (_: Exception) {
        }
        pageTracks = list.filter { it.idx >= 0 }
        // 고른 페이지 트랙이 사라졌으면 끈다
        subSel?.let { sel ->
            if (sel.url == null && pageTracks.none { it.idx == sel.pageIdx }) selectSub(null, quiet = true)
        }
        refreshFileSubs()
        hintIfAvailable()
    }

    /** 페이지 트랙으로 고른 자막의 지금 글 (바뀔 때마다 온다) */
    fun onPageCue(text: String) {
        val sel = subSel ?: return
        if (sel.url != null) return
        showCue(text)
    }

    /** 페이지가 따로 불러온 자막 파일 중 <track> 과 겹치지 않는 것만 모은다 */
    private fun refreshFileSubs() {
        if (released) return
        val known = pageTracks.map { it.url }.filter { it.isNotEmpty() }.toHashSet()
        val urls = try { fileSubProvider() } catch (_: Exception) { emptyList() }
        val list = urls.filter { it !in known }.distinct().take(8)
        if (list != fileSubUrls) {
            fileSubUrls = list
            hintIfAvailable()
        }
    }

    private fun hintIfAvailable() {
        if (subHinted || subSel != null) return
        if (pageTracks.isEmpty() && fileSubUrls.isEmpty()) return
        subHinted = true
        showOsd("자막이 있어요 · CC 버튼으로 켤 수 있어요", 2200)
    }

    private fun subOptions(): List<SubOpt> {
        val out = ArrayList<SubOpt>()
        pageTracks.forEachIndexed { n, t ->
            val name = t.label.ifBlank { t.lang.uppercase() }.ifBlank { "자막 ${n + 1}" }
            out.add(SubOpt(name, t.idx, null, t.lang))
        }
        fileSubUrls.forEachIndexed { n, u ->
            val file = Uri.decode(u.substringBefore('#').substringBefore('?').substringAfterLast('/'))
                .ifBlank { "자막 파일 ${n + 1}" }
            out.add(SubOpt(file, -1, u))
        }
        return out
    }

    private fun isSel(o: SubOpt): Boolean {
        val sel = subSel ?: return false
        return if (o.url != null) sel.url == o.url else sel.url == null && sel.pageIdx == o.pageIdx
    }

    /** 자막 고르기 (null = 끔). 페이지 트랙이면 페이지에 알려 글을 받고, 자막 파일이면 받아 와서 영상 위치에 맞춰 그린다 */
    private fun selectSub(o: SubOpt?, quiet: Boolean = false) {
        subSel = o
        updateSubChip()
        fileCues = null
        removeCallbacks(subTick)
        subSourceKo = o != null && o.url == null && o.lang.lowercase().startsWith("ko")
        // 페이지 쪽: 고른 트랙만 켜고 나머지는 끈다 (파일 자막이거나 끄면 모두 끈다)
        onCommand("sub", if (o != null && o.url == null) o.pageIdx.toDouble() else -1.0)
        curRaw = ""
        lastRawCue = "\u0000"
        showCue("")
        if (o == null) {
            if (!quiet) showOsd("자막을 껐어요", 900)
            return
        }
        if (o.url == null) {
            if (!quiet) showOsd("자막: ${o.label}", 1200)
            return
        }
        loadFileSub(o)
    }

    private fun loadFileSub(o: SubOpt) {
        val url = o.url ?: return
        val cached = fileCueCache[url]
        if (cached != null) {
            fileCues = cached
            showOsd("자막: ${o.label}", 1200)
            startSubTick()
            return
        }
        if (released) return
        showOsd("자막을 불러오는 중…", 20_000)
        fileExec.execute {
            val txt = try { fileFetcher(url) } catch (_: Exception) { null }
            val cues = if (txt != null) {
                try { SubtitleFile.parse(txt) } catch (_: Exception) { emptyList() }
            } else emptyList()
            post {
                if (released) return@post
                if (cues.isEmpty()) {
                    if (subSel === o) selectSub(null, quiet = true)
                    showOsd("자막을 불러오지 못했어요", 1800)
                    return@post
                }
                fileCueCache[url] = cues
                if (subSel === o) {
                    fileCues = cues
                    showOsd("자막: ${o.label}", 1200)
                    startSubTick()
                }
            }
        }
    }

    /** 자막 파일은 영상 위치에 맞춰 0.15초마다 지금 글을 찾아 그린다 (컨트롤이 숨어 있어도 돈다) */
    private val subTick = object : Runnable {
        override fun run() {
            val cues = fileCues
            if (cues == null || subSel?.url == null || released || !isAttachedToWindow) return
            showCue(SubtitleFile.textAt(cues, curPos()))
            postDelayed(this, 150)
        }
    }

    private fun startSubTick() {
        removeCallbacks(subTick)
        post(subTick)
    }

    /** 지금 글을 화면에 올린다: 번역을 켰고 한국어가 아니면 번역해서(오기 전엔 원문을 흐리게) 보여 준다 */
    private fun showCue(raw: String) {
        curRaw = raw
        if (raw == lastRawCue) return
        lastRawCue = raw
        val orig = raw.replace(Regex("<[^>]+>"), "").trim()
        if (orig.isEmpty()) {
            subKey = ""
            curOrig = ""
            subOverlay.visibility = View.GONE
            return
        }
        curOrig = orig
        val norm = orig.replace(Regex("\\s*\\n\\s*"), " ").trim()
        if (prefs.subTranslateMode == 0 || subSourceKo || FreeTranslator.isKoreanOrEmpty(norm)) {
            subKey = ""
            renderSub(null)
            return
        }
        subKey = norm
        val cached = subCache.get(norm)
        renderSub(cached)
        if (cached == null) requestTranslation(norm)
    }

    private fun renderSub(translated: String?) {
        subOverlay.visibility = View.VISIBLE
        if (subKey.isEmpty()) {
            subMain.alpha = 1f
            subMain.text = curOrig
            subOrig.visibility = View.GONE
            return
        }
        if (translated != null) {
            subMain.alpha = 1f
            subMain.text = translated
            if (prefs.subTranslateMode == 2) {
                subOrig.text = curOrig
                subOrig.visibility = View.VISIBLE
            } else {
                subOrig.visibility = View.GONE
            }
        } else {
            subMain.alpha = 0.65f
            subMain.text = curOrig
            subOrig.visibility = View.GONE
        }
    }

    private fun subChipLabel() = when (prefs.subTranslateMode) {
        1 -> "자막 번역"
        2 -> "번역+원문"
        else -> "번역 끔"
    }

    private fun updateSubChip() {
        subChip.text = subChipLabel()
        subChip.visibility = if (subSel != null) View.VISIBLE else View.GONE
    }

    /** 위쪽 칩을 누를 때마다: 번역 끔 → 자막 번역(한국어로) → 번역+원문 (내장 플레이어와 같다) */
    private fun cycleSubTranslate() {
        prefs.subTranslateMode = (prefs.subTranslateMode + 1) % 3
        updateSubChip()
        refreshCue()
        val msg = when (prefs.subTranslateMode) {
            1 -> "자막을 한국어로 번역해요"
            2 -> "한국어 번역 + 원문을 함께 보여요"
            else -> "자막 번역을 껐어요"
        }
        showOsd(if (prefs.subTranslateMode != 0 && subSourceKo) "한국어 자막이라 번역하지 않아요" else msg, 1500)
    }

    private fun refreshCue() {
        updateSubChip()
        val r = curRaw
        lastRawCue = "\u0000"
        showCue(r)
    }

    private fun requestTranslation(key: String) {
        if (released || !subPending.add(key)) return
        subExec.execute {
            val (res, err) = subTranslator.translate(listOf(key))
            post {
                subPending.remove(key)
                if (released) return@post
                val tr = res?.firstOrNull()
                if (tr != null) {
                    subCache.put(key, tr)
                    if (key == subKey && prefs.subTranslateMode != 0) renderSub(tr)
                } else if (err != null) {
                    // 같은 오류 안내가 계속 뜨지 않게 15초에 한 번만
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastSubErrAt > 15_000L) {
                        lastSubErrAt = now
                        showOsd("자막 번역 실패 · $err", 2500)
                    }
                }
            }
        }
    }

    // ── 자막 설정창 (내장 플레이어의 설정창과 같은 모양: 오른쪽 아래 카드 · 페이지 이동 · 묶음 행) ──

    private val ROW = "ev_row"
    private val ROW_ON = "ev_row_on"
    private var subCard: LinearLayout? = null
    private var subDir = 1
    private val gray = 0xFF9AA0A6.toInt()

    /** 열려 있으면 닫고 true (뒤로 가기에서 먼저 부른다). [msg] 가 있으면 닫히며 안내를 띄운다 */
    fun closeSubPanel(msg: String? = null): Boolean {
        val p = subPanel ?: return false
        val card = subCard
        subPanel = null
        subCard = null
        p.animate().cancel()
        p.animate().alpha(0f).setDuration(130).start()
        if (card != null) {
            // 열릴 때의 반대로: 오른쪽 아래로 작아지며 사라진다
            card.animate().cancel()
            card.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).translationY(dp(10).toFloat()).translationX(0f)
                .setDuration(130).setInterpolator(android.view.animation.AccelerateInterpolator())
                .withEndAction { removeView(p) }.start()
        } else {
            removeView(p)
        }
        if (msg != null) showOsd(msg, 1600)
        scheduleHide()
        return true
    }

    /** 지금 열려 있는 창의 쪽 (settings · quality · speed · fit · subs …) */
    private var subPage = "subs"

    /** 설정(톱니)에서 들어온 쪽이면 머리글에 뒤로 가기가 생긴다 */
    private var subFromSettings = false

    private fun openSubPanel(kind: String = "subs") {
        if (subPanel != null) return
        subFromSettings = kind == "settings"
        refreshFileSubs()
        removeCallbacks(hideRun)
        val host = FrameLayout(context).apply {
            setBackgroundColor(0x59000000)
            isClickable = true
            setOnClickListener { closeSubPanel() }
        }
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat(); setColor(0xF2121212.toInt()); setStroke(dp(1), 0x26FFFFFF)
            }
            isClickable = true // 카드 안을 눌러도 닫히지 않게
        }
        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            addView(card)
        }
        val dm = resources.displayMetrics
        host.addView(scroll, LayoutParams(minOf(dp(340), dm.widthPixels - dp(24)), LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            marginEnd = dp(12)
            bottomMargin = dp(64)
            topMargin = dp(16)
        })
        host.alpha = 0f
        addView(host, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        subPanel = host
        subCard = card
        subDir = 1
        renderSubPage(kind, animate = false)
        // 오른쪽 아래(CC 버튼 쪽)에서 살짝 커지며 나타난다
        host.animate().alpha(1f).setDuration(160).start()
        card.alpha = 0f; card.scaleX = 0.94f; card.scaleY = 0.94f; card.translationX = 0f; card.translationY = dp(14).toFloat()
        card.post {
            card.pivotX = card.width.toFloat(); card.pivotY = card.height.toFloat()
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(260)
                .setInterpolator(android.view.animation.OvershootInterpolator(0.9f)).start()
        }
    }

    private fun subStyleSummary() = "${subSizeNames[prefs.subSize.coerceIn(0, 3)]} · ${subBgNames[prefs.subBg.coerceIn(0, 3)]}"

    private fun setSubKind(m: Int) {
        if (m == 0) {
            selectSub(null, quiet = true)
            renderSubPage("subs")
            return
        }
        val opts = subOptions()
        if (opts.isEmpty()) {
            closeSubPanel("이 영상엔 들어 있는 자막이 없어요")
            return
        }
        selectSub(opts.first(), quiet = true)
        renderSubPage("subs")
    }

    private fun subShow(animate: Boolean, build: LinearLayout.() -> Unit) {
        val card = subCard ?: return
        card.removeAllViews()
        card.build()
        groupSubRows(card)
        val dir = subDir
        subDir = 1
        if (!animate) return
        // 앞으로 가면 오른쪽에서, 뒤로 가면 왼쪽에서 살짝 밀려 들어온다
        card.animate().cancel()
        card.alpha = 0f
        card.translationX = dp(18).toFloat() * dir
        card.animate().alpha(1f).translationX(0f).setDuration(190)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    private fun renderSubPage(kind: String, animate: Boolean = true): Unit = subShow(animate) {
        subPage = kind
        val back: () -> Unit = { subDir = -1; renderSubPage("subs") }
        val toSettings: (() -> Unit)? = if (subFromSettings) ({ subDir = -1; renderSubPage("settings") }) else null
        when (kind) {
            "subs" -> {
                addView(subHeader("자막", toSettings, root = toSettings == null))
                val opts = subOptions()
                val on = if (subSel != null) 1 else 0
                addView(subChoices("자막 종류", listOf("끔", "영상 자막"), on) { m -> setSubKind(m) })
                addView(TextView(context).apply {
                    text = when {
                        on == 1 -> "영상에 들어 있는 자막을 보여 줘요 · 정확하고 바로 나와요"
                        opts.isEmpty() -> "이 영상엔 들어 있는 자막이 없어요 · 페이지가 자막을 따로 불러오면 여기에 나타나요"
                        else -> "자막을 보지 않아요 · 영상 자막을 골라 보세요"
                    }
                    setTextColor(gray)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    setPadding(dp(18), dp(8), dp(18), dp(4))
                })
                if (on == 1) {
                    addView(subHeader("영상 자막", null))
                    addView(subRow("자막 선택", subSel?.label, false, true) { renderSubPage("subtrack") })
                    addView(subChoices("자막 번역", listOf("안 함", "한국어로", "번역+원문"), prefs.subTranslateMode.coerceIn(0, 2)) { m ->
                        prefs.subTranslateMode = m
                        refreshCue()
                    })
                    addView(subHeader("모양", null))
                    addView(subRow("자막 모양", subStyleSummary(), false, true) { renderSubPage("substyle") })
                }
            }
            "subtrack" -> {
                addView(subHeader("영상 자막", back))
                addView(subRow("끔", null, subSel == null, false) {
                    selectSub(null, quiet = true)
                    closeSubPanel("자막을 껐어요")
                })
                for (o in subOptions()) {
                    addView(subRow(o.label, null, isSel(o), false) {
                        selectSub(o, quiet = true)
                        closeSubPanel("자막: ${o.label}")
                    })
                }
            }
            "settings" -> {
                addView(subHeader("설정", null, root = true))
                if (qOpts.size >= 2) {
                    addView(subRow("화질", qOpts.firstOrNull { it.id == qSel }?.name, false, true) { renderSubPage("quality") })
                }
                addView(subRow("자막", subSel?.label ?: "끔", false, true) { renderSubPage("subs") })
                addView(subRow("재생 속도", speedLabel(rate), false, true) { renderSubPage("speed") })
                addView(subRow("화면 비율", fitNames[fitIdx], false, true) { renderSubPage("fit") })
            }
            "quality" -> {
                addView(subHeader("화질", toSettings, root = toSettings == null))
                for (o in qOpts) {
                    addView(subRow(o.name, null, o.id == qSel, false) {
                        onQuality?.invoke(o.id)
                        closeSubPanel("화질: ${o.name}")
                    })
                }
            }
            "speed" -> {
                addView(subHeader("재생 속도", toSettings, root = toSettings == null))
                for (sp in speeds) {
                    addView(subRow(if (sp == 1f) "보통 (1x)" else speedLabel(sp), null, abs(sp - rate) < 0.01f, false) {
                        setRate(sp)
                        closeSubPanel("${speedLabel(sp)} 배속")
                    })
                }
            }
            "fit" -> {
                addView(subHeader("화면 비율", toSettings, root = toSettings == null))
                for (i in fitNames.indices) {
                    addView(subRow(fitNames[i], null, i == fitIdx, false) {
                        fitIdx = i
                        onCommand("fit", i.toDouble())
                        closeSubPanel(fitNames[i])
                    })
                }
            }
            "substyle" -> {
                addView(subHeader("자막 모양", back))
                addView(subChoices("글자 크기", subSizeNames, prefs.subSize.coerceIn(0, 3)) { prefs.subSize = it; applySubStyle() })
                addView(subChoices("배경", subBgNames, prefs.subBg.coerceIn(0, 3)) { prefs.subBg = it; applySubStyle() })
                addView(subChoices("위치", subPosNames, prefs.subPos.coerceIn(0, 2)) { prefs.subPos = it; applySubStyle() })
                addView(TextView(context).apply {
                    text = "영상 자막 · 번역 자막에 모두 적용돼요"
                    setTextColor(gray)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    setPadding(dp(18), dp(10), dp(18), dp(4))
                })
            }
        }
    }

    private fun subRow(label: String, value: String?, checked: Boolean, chevron: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(14), 0)
            minimumHeight = dp(52)
            isClickable = true
            tag = if (checked) ROW_ON else ROW // 배경(묶음 모양)은 subShow 가 위치를 보고 입힌다
            setOnClickListener { onClick() }
        }
        row.addView(TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            if (checked) typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (value != null) row.addView(TextView(context).apply {
            text = value
            setTextColor(gray)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            maxWidth = dp(150)
        })
        if (chevron) row.addView(TextView(context).apply {
            text = "›"
            setTextColor(gray)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setPadding(dp(8), 0, 0, 0)
        })
        if (checked) row.addView(ImageView(context).apply {
            setImageResource(R.drawable.ic_check_bold)
            setColorFilter(0xFF6BE3A0.toInt())
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(8) })
        return row
    }

    private fun isSubRow(v: View) = v.tag == ROW || v.tag == ROW_ON

    /** 이어진 항목들을 한 덩어리(둥근 카드)로 묶어 보이게: 첫·끝 항목만 바깥쪽 모서리를 둥글게, 사이는 얇은 틈 */
    private fun groupSubRows(card: LinearLayout) {
        val n = card.childCount
        var i = 0
        while (i < n) {
            if (!isSubRow(card.getChildAt(i))) { i++; continue }
            var j = i
            while (j + 1 < n && isSubRow(card.getChildAt(j + 1))) j++
            for (k in i..j) {
                val row = card.getChildAt(k)
                val top = if (k == i) dp(16).toFloat() else 0f
                val bottom = if (k == j) dp(16).toFloat() else 0f
                val radii = floatArrayOf(top, top, top, top, bottom, bottom, bottom, bottom)
                val on = row.tag == ROW_ON
                row.background = android.graphics.drawable.StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply {
                        cornerRadii = radii; setColor(0x33FFFFFF)
                    })
                    addState(intArrayOf(), GradientDrawable().apply {
                        cornerRadii = radii
                        setColor(if (on) (accent and 0x00FFFFFF) or 0x33000000 else 0x14FFFFFF)
                    })
                }
                (row.layoutParams as? LinearLayout.LayoutParams)?.let { lp ->
                    lp.topMargin = if (k == i) 0 else dp(1)
                    row.layoutParams = lp
                }
            }
            i = j + 1
        }
    }

    private fun subHeader(title: String, onBack: (() -> Unit)?, root: Boolean = false): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            when {
                root -> { setPadding(dp(16), dp(8), dp(8), dp(8)); minimumHeight = dp(48) }
                onBack != null -> { setPadding(dp(4), dp(4), dp(14), dp(8)); minimumHeight = dp(48) }
                else -> { setPadding(dp(18), dp(14), dp(14), dp(6)); minimumHeight = dp(32) } // 작은 구역 제목
            }
        }
        if (onBack != null) row.addView(TextView(context).apply {
            text = "‹"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x1AFFFFFF) }
            setOnClickListener { onBack() }
        }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) })
        row.addView(TextView(context).apply {
            text = title
            if (root || onBack != null) {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (root) 19f else 17f)
            } else {
                setTextColor(gray)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            }
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (root) row.addView(TextView(context).apply {
            text = "✕"
            setTextColor(0xFFE8EAED.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x1AFFFFFF) }
            setOnClickListener { closeSubPanel() }
        }, LinearLayout.LayoutParams(dp(32), dp(32)))
        return row
    }

    /** 제목 + 알약 선택지 한 줄. 눌러도 화면을 다시 그리지 않고 그 자리에서 바뀐다 */
    private fun subChoices(title: String, names: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0x14FFFFFF) }
        }
        box.addView(TextView(context).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
        })
        val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val pills = ArrayList<TextView>()
        fun paint(sel: Int) {
            pills.forEachIndexed { i, t ->
                t.background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setColor(if (i == sel) accent else 0x1FFFFFFF)
                }
                t.typeface = if (i == sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
        }
        names.forEachIndexed { i, n ->
            val t = TextView(context).apply {
                text = n
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                gravity = Gravity.CENTER
                maxLines = 1
                setOnClickListener { paint(i); onPick(i) }
            }
            pills.add(t)
            line.addView(t, LinearLayout.LayoutParams(0, dp(36), 1f).apply { if (i > 0) marginStart = dp(6) })
        }
        paint(selected)
        box.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        box.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        return box
    }

    /** 아래로 밀어 나가기를 쓰면 안 되는 때: 자막 패널이 열려 있거나 진행 막대를 끄는 중 */
    fun swipeBlocked() = subPanel != null || seek.scrubbing

    /** 컨트롤이 떠 있을 때 진행 막대 위(사방 12dp 더)에서 시작한 터치인지 — [host] 의 좌표 (x, y) */
    fun touchOnSeek(host: FullscreenSwipeLayout, x: Float, y: Float): Boolean =
        controlsOn && host.hits(seek, x, y, dp(12).toFloat())

    /** 미러링을 끝낼 때: 번역·받아 오기 작업을 멈추고 창을 정리한다 */
    fun release() {
        released = true
        removeCallbacks(subTick)
        subTranslator.cancel()
        subExec.shutdownNow()
        fileExec.shutdownNow()
        subPanel?.let { removeView(it) }
        subPanel = null
    }

    // ───────────────────────── 제스처 (내장 플레이어와 같은 방식) ─────────────────────────

    private var scrollMode = 0 // 0 미정, 1 세로(무시), 2 가로(시간 이동)
    private var seekStart = 0.0
    private var seekTarget = -1.0
    private var longPressing = false
    private var prevRate = 1f
    private var tapAcc = 0
    private var tapDir = 0
    private var lastTapAt = 0L

    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean {
            scrollMode = 0
            seekStart = curPos()
            seekTarget = -1.0
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            setControls(!controlsOn)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val w = width.coerceAtLeast(1)
            // 화면을 3등분: 왼쪽 = 10초 뒤로, 가운데 = 재생/일시정지, 오른쪽 = 10초 앞으로
            if (e.x > w * 0.35f && e.x < w * 0.65f) {
                tapDir = 0
                tapAcc = 0
                val willPlay = !curPlaying()
                toggle()
                // 재생/일시정지 버튼이 있는 컨트롤이 떠 있을 땐 가운데 효과를 안 띄운다
                if (!controlsOn) tapFx.center(willPlay)
                return true
            }
            val left = e.x < w / 2f
            val dir = if (left) -1 else 1
            val now = SystemClock.uptimeMillis()
            tapAcc = if (dir == tapDir && now - lastTapAt < 900) tapAcc + 10 else 10
            tapDir = dir
            lastTapAt = now
            skip(dir * 10.0)
            tapFx.skip(left, tapAcc, e.x, e.y)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (!curPlaying()) return
            longPressing = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            prevRate = rate
            setRate(2f)
            showOsd("››  2배속", 100_000)
        }
        // 가로로 쓸어서 시간 이동하는 제스처는 없앴다 (v2.5.75). 시간 이동은 진행 막대·10초 버튼·더블탭으로
    })

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        detector.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            if (longPressing) {
                longPressing = false
                setRate(prevRate)
                removeCallbacks(hideOsdRun)
                fadeOutOsd()
            }
            if (ev.actionMasked == MotionEvent.ACTION_UP && seekTarget >= 0) {
                seekTo(seekTarget)
                removeCallbacks(hideOsdRun)
                postDelayed(hideOsdRun, 500)
            }
            seekTarget = -1.0
            scrubPos = -1.0
        }
        return true
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(hideRun)
        removeCallbacks(hideOsdRun)
        removeCallbacks(tick)
        removeCallbacks(subTick)
        ticking = false
        controls.animate().cancel()
        osd.animate().cancel()
    }
}

/** 진행 막대: 가는 막대 + 손잡이, 끌면 손잡이가 커진다 */
private class MirrorSeekBar(ctx: Context, private val accent: Int) : View(ctx) {
    var fraction = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var enabledSeek = true
    var scrubbing = false
        private set

    /** phase: 0 시작 · 1 이동 · 2 손 뗌 · 3 취소 */
    var onScrub: (Int, Float) -> Unit = { _, _ -> }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val padX = 14f * d
    // 끌 때 막대가 굵어지고 손잡이가 톡 커지는 움직임 (눌렀다 놓을 때 부드럽게)
    private val press = PressAnim { invalidate() }

    override fun onDetachedFromWindow() {
        press.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val left = padX
        val right = width - padX
        val cy = height / 2f
        val h = (4f + 2.5f * press.tc) * d
        paint.color = 0x40FFFFFF
        rect.set(left, cy - h / 2f, right, cy + h / 2f)
        c.drawRoundRect(rect, h / 2f, h / 2f, paint)
        val x = left + (right - left) * fraction
        paint.color = accent
        rect.set(left, cy - h / 2f, x, cy + h / 2f)
        c.drawRoundRect(rect, h / 2f, h / 2f, paint)
        if (enabledSeek) {
            val rad = (7f + 6f * press.t) * d
            c.drawCircle(x, cy, rad.coerceAtLeast(1f), paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!enabledSeek) return false
        val w = (width - 2 * padX).coerceAtLeast(1f)
        val f = ((e.x - padX) / w).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                scrubbing = true
                press.to(true)
                fraction = f
                onScrub(0, f)
            }
            MotionEvent.ACTION_MOVE -> if (scrubbing) {
                fraction = f
                onScrub(1, f)
            }
            MotionEvent.ACTION_UP -> if (scrubbing) {
                scrubbing = false
                press.to(false)
                fraction = f
                onScrub(2, f)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> if (scrubbing) {
                scrubbing = false
                press.to(false)
                onScrub(3, f)
                invalidate()
            }
        }
        return true
    }
}
