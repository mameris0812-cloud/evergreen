# 웹페이지 스크립트가 호출하는 @JavascriptInterface 메서드는 이름이 바뀌면 안 된다
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface,Signature,*Annotation*

# 매니페스트에 등록된 컴포넌트
-keep class com.example.evergreen.MainActivity { *; }
-keep class com.example.evergreen.MediaService { *; }
-keep class com.example.evergreen.DownloadService { *; }
-keep class com.example.evergreen.DownloadsActivity { *; }
-keep class com.example.evergreen.HistoryActivity { *; }
-keep class com.example.evergreen.PlayerActivity { *; }

# 레이아웃 XML 에서 쓰는 커스텀 뷰
-keep class com.example.evergreen.PullRefreshLayout { *; }
