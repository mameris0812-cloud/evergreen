package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * AI 가 답을 준비하는 동안 보여 주는 점 세 개.
 * 점이 차례로 위로 튀어 오르며 커지고 진해지는 물결 애니메이션이다.
 * 시스템의 "애니메이션 끄기" 설정이면 움직이지 않고 점만 보여 준다.
 */
class TypingDotsView(context: Context, dotColor: Int) : View(context) {
    private val d = resources.displayMetrics.density
    private val radius = 3.5f * d
    private val gap = 6f * d
    private val lift = 5f * d
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = dotColor }
    private var t = 0f
    private val animate = Motion.enabled(context)

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1100
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedFraction
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animate) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (radius * 2 * 3 + gap * 2).toInt() + 2
        val h = (radius * 2 + lift).toInt() + 2
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val cy = height - radius - 1f
        val startX = (width - (radius * 2 * 3 + gap * 2)) / 2f + radius
        for (i in 0 until 3) {
            // 점마다 0.15 만큼 늦게 출발해서 왼쪽부터 차례로 튄다
            val phase = ((t - i * 0.15f) % 1f + 1f) % 1f
            val wave = if (animate && phase < 0.45f) sin(phase / 0.45f * PI).toFloat() else 0f
            paint.alpha = (90 + 165 * wave).toInt()
            val r = radius * (1f + 0.18f * wave)
            canvas.drawCircle(startX + i * (radius * 2 + gap), cy - lift * wave, r, paint)
        }
    }
}
