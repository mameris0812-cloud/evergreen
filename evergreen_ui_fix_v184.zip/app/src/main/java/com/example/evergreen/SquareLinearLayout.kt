package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.widget.LinearLayout

/** 가로 길이에 맞춰 세로 길이를 똑같이 만드는 LinearLayout (정사각형 카드용). */
class SquareLinearLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = MeasureSpec.getSize(widthMeasureSpec)
        super.onMeasure(
            widthMeasureSpec,
            MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY)
        )
    }
}
