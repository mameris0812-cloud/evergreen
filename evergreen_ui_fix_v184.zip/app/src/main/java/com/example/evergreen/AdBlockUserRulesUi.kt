package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.color.MaterialColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 설정 > 직접 선택한 광고 관리.
 * '광고 직접 선택' 으로 고른 광고를 사이트별로 보여 주고, 하나씩 또는 한꺼번에 지울 수 있다.
 */
object AdBlockUserRulesUi {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /**
     * @param onChanged 규칙을 지우고 목록을 닫을 때 한 번 (페이지를 새로 불러와야 광고가 되살아난다)
     * @param changed 이 화면을 열기 전에 이미 지운 것이 있는지 (지울 때마다 다시 여는 화면이라서)
     */
    fun show(ctx: Context, blocker: AdBlocker, changed: Boolean = false, onChanged: () -> Unit): Dialog {
        val rules = blocker.userRules()
        val onSurface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val date = SimpleDateFormat("yyyy.MM.dd", Locale.getDefault())
        var handled = false

        return Popup.panel(
            ctx,
            title = "직접 선택한 광고",
            subtitle = if (rules.isEmpty()) "아직 없어요" else "${rules.size}개 · 눌러서 지우면 다음 로드부터 다시 보여요",
            headerIcon = R.drawable.ic_shield,
            widthDp = 380,
            secondaryLabel = if (rules.isEmpty()) null else "모두 지우기",
            onSecondary = { d ->
                Popup.confirm(
                    ctx, "직접 선택한 광고를 모두 지울까요?",
                    "${rules.size}개의 차단이 사라지고 해당 광고가 다시 보입니다. 기본 광고 차단 목록은 그대로예요.",
                    "모두 지우기", danger = true
                ) {
                    blocker.clearUserRules()
                    handled = true
                    d.dismiss()
                    onChanged()
                }
            }
        ) { list, dialog ->
            if (changed) dialog.setOnDismissListener { if (!handled) onChanged() }
            if (rules.isEmpty()) {
                list.addView(TextView(ctx).apply {
                    text = "광고 차단 설정의 '광고 직접 선택'을 눌러 페이지에서 차단할 광고를 골라 보세요."
                    textSize = 13f
                    setTextColor(onVar)
                    setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12))
                })
                return@panel
            }
            rules.groupBy { it.host }.toSortedMap().forEach { (host, group) ->
                list.addView(TextView(ctx).apply {
                    text = host
                    textSize = 12f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(primary)
                    setPadding(dp(ctx, 12), dp(ctx, 14), dp(ctx, 12), dp(ctx, 4))
                })
                group.sortedByDescending { it.time }.forEach { r ->
                    list.addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 4), dp(ctx, 6))
                        addView(LinearLayout(ctx).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            addView(TextView(ctx).apply {
                                text = r.label.ifEmpty { "선택한 광고" }
                                textSize = 14f
                                setTextColor(onSurface)
                                maxLines = 1
                                ellipsize = android.text.TextUtils.TruncateAt.END
                            })
                            addView(TextView(ctx).apply {
                                text = r.selector + if (r.time > 0) "  ·  ${date.format(Date(r.time))}" else ""
                                textSize = 11f
                                setTextColor(onVar)
                                maxLines = 2
                                ellipsize = android.text.TextUtils.TruncateAt.END
                            })
                        })
                        addView(ImageView(ctx).apply {
                            setImageResource(R.drawable.ic_delete)
                            imageTintList = android.content.res.ColorStateList.valueOf(onVar)
                            val pad = dp(ctx, 10)
                            setPadding(pad, pad, pad, pad)
                            contentDescription = "삭제"
                            setOnClickListener {
                                blocker.removeUserRule(r)
                                handled = true
                                dialog.dismiss()
                                // 남은 규칙으로 목록을 다시 연다 (다 지웠으면 바로 새로 불러온다)
                                if (blocker.userRuleCount > 0) show(ctx, blocker, true, onChanged) else onChanged()
                            }
                            layoutParams = LinearLayout.LayoutParams(dp(ctx, 44), dp(ctx, 44))
                        })
                    })
                }
            }
        }
    }
}
