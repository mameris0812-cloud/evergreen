package com.example.evergreen

/** 탭 그룹: 이름 / 색상 / 접힘 상태를 가진다. 탭은 BrowserTab.groupId 로 그룹에 속한다. */
class TabGroup(
    val id: Int,
    var name: String,
    var color: Int,
    var collapsed: Boolean = false
) {
    companion object {
        /** 그룹 색상 팔레트 */
        val COLORS = intArrayOf(
            0xFF2FA35B.toInt(), // 초록
            0xFFD93025.toInt(), // 빨강
            0xFFF29900.toInt(), // 주황
            0xFF3978E8.toInt(), // 파랑
            0xFF12B5CB.toInt(), // 청록
            0xFF9334E6.toInt(), // 보라
            0xFFE52592.toInt(), // 분홍
            0xFF5F6368.toInt()  // 회색
        )
    }
}
