package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Bundle
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 화면 확대/축소 팝업용 게이지바.
 * 채워진 막대와 빈 막대를 틈을 두고 나누고, 가운데에 세로 손잡이를 둔다. 눈금(step) 단위로 딱딱 맞춰진다.
 * 기본값 위치에는 작은 점을 찍어 둔다.
 */
class ZoomGauge @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var min = 50
    var max = 500
    var step = 10
    var defaultValue = 100
    var activeColor = 0xFF2E9E5B.toInt()
        set(v) { field = v; invalidate() }
    var inactiveColor = 0xFFDDE0E8.toInt()
        set(v) { field = v; invalidate() }
    var dotOnActiveColor = 0xFFFFFFFF.toInt()
        set(v) { field = v; invalidate() }

    /** 사용자가 움직여서 값이 바뀔 때만 불린다 */
    var onValueChange: ((Int) -> Unit)? = null

    var value = 100
        set(v) {
            val nv = snap(v.toFloat())
            if (nv == field) return
            field = nv
            invalidate()
        }

    private val d = resources.displayMetrics.density
    private val barH = 20 * d
    private val gap = 6 * d
    private val thumbW = 7 * d
    private val thumbH = 40 * d
    private val outerR = 10 * d
    private val innerR = 3 * d
    private val dotR = 2.5f * d

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private var press = 0f
    private var pressAnim: ValueAnimator? = null

    private fun snap(raw: Float): Int {
        val s = Math.round((raw - min) / step.toFloat()) * step + min
        return s.coerceIn(min, max)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize(suggestedMinimumWidth, widthMeasureSpec),
            resolveSize((48 * d).toInt(), heightMeasureSpec)
        )
    }

    private fun roundRect(l: Float, t: Float, r: Float, b: Float, radii: FloatArray) {
        rect.set(l, t, r, b)
        path.reset()
        path.addRoundRect(rect, radii, Path.Direction.CW)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cy = height / 2f
        val usable = w - thumbW
        val p = (value - min) / (max - min).toFloat()
        val left = usable * p

        // 채워진 막대
        val activeEnd = left - gap
        if (activeEnd > 0f) {
            paint.color = activeColor
            roundRect(0f, cy - barH / 2, activeEnd, cy + barH / 2,
                floatArrayOf(outerR, outerR, innerR, innerR, innerR, innerR, outerR, outerR))
            canvas.drawPath(path, paint)
        }
        // 빈 막대
        val inactiveStart = left + thumbW + gap
        if (inactiveStart < w) {
            paint.color = inactiveColor
            roundRect(inactiveStart, cy - barH / 2, w, cy + barH / 2,
                floatArrayOf(innerR, innerR, outerR, outerR, outerR, outerR, innerR, innerR))
            canvas.drawPath(path, paint)
        }
        // 기본값 점 (손잡이가 가까이 있으면 숨긴다)
        if (Math.abs(value - defaultValue) > step) {
            val dx = usable * ((defaultValue - min) / (max - min).toFloat()) + thumbW / 2
            paint.color = if (value > defaultValue) dotOnActiveColor else activeColor
            canvas.drawCircle(dx, cy, dotR, paint)
        }
        // 손잡이: 누르는 동안 살짝 가늘어진다
        val tw = thumbW - 2 * d * press
        val tl = left + (thumbW - tw) / 2
        paint.color = activeColor
        rect.set(tl, cy - thumbH / 2, tl + tw, cy + thumbH / 2)
        canvas.drawRoundRect(rect, tw / 2, tw / 2, paint)
    }

    private fun animatePress(to: Float) {
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(press, to).apply {
            duration = 120
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun updateFromX(x: Float) {
        val usable = (width - thumbW).coerceAtLeast(1f)
        val p = ((x - thumbW / 2) / usable).coerceIn(0f, 1f)
        change(snap(min + p * (max - min)))
    }

    private fun change(nv: Int) {
        val c = nv.coerceIn(min, max)
        if (c == value) return
        value = c
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onValueChange?.invoke(c)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                animatePress(1f)
                updateFromX(e.x)
            }
            MotionEvent.ACTION_MOVE -> updateFromX(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animatePress(0f)
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    @Suppress("DEPRECATION")
    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        info.className = "android.widget.SeekBar"
        info.rangeInfo = AccessibilityNodeInfo.RangeInfo.obtain(
            AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_INT, min.toFloat(), max.toFloat(), value.toFloat()
        )
        if (android.os.Build.VERSION.SDK_INT >= 30) info.stateDescription = "${value}%"
        info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD)
        info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD)
    }

    override fun performAccessibilityAction(action: Int, arguments: Bundle?): Boolean {
        when (action) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD -> { change(value + step); return true }
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD -> { change(value - step); return true }
        }
        return super.performAccessibilityAction(action, arguments)
    }

    override fun onDetachedFromWindow() {
        pressAnim?.cancel()
        super.onDetachedFromWindow()
    }
}
