package com.example.evergreen

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Bundle
import java.lang.ref.WeakReference

/** 지금 화면에 떠 있는 evergreen 창을 기억해 둔다. 서비스에서 끝난 일을 앱 자체 알림으로 알릴 때 쓴다. */
object AppForeground {
    private val resumed = ArrayList<WeakReference<Activity>>()

    @Synchronized
    fun add(a: Activity) {
        resumed.removeAll { it.get() == null || it.get() === a }
        resumed.add(WeakReference(a))
    }

    @Synchronized
    fun remove(a: Activity) {
        resumed.removeAll { it.get() == null || it.get() === a }
    }

    /** 알림을 띄울 창. 입력 초점이 있는 창을 먼저, 없으면 가장 나중에 켜진 창. 작은 화면(PiP)이나 닫히는 창은 뺀다. */
    @Synchronized
    fun current(): Activity? {
        val list = resumed.mapNotNull { it.get() }.filter { a ->
            !a.isFinishing && !a.isDestroyed &&
                !(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && a.isInPictureInPictureMode)
        }
        return list.lastOrNull { it.hasWindowFocus() } ?: list.lastOrNull()
    }
}

class EvergreenApp : Application() {
    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                AppForeground.add(activity)
            }

            override fun onActivityPaused(activity: Activity) = AppForeground.remove(activity)
            override fun onActivityDestroyed(activity: Activity) = AppForeground.remove(activity)
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
        })
    }
}
