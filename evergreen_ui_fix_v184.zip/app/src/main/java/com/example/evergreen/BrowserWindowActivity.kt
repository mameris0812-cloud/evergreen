package com.example.evergreen

/**
 * 앱을 여러 창으로 띄우기 위한 추가 창. 화면·동작은 MainActivity 와 같고,
 * documentLaunchMode="always" 로 열 때마다 별개 창(최근 앱 항목)이 생긴다.
 * 탭 저장·복원은 첫 번째 창만 한다.
 */
class BrowserWindowActivity : MainActivity()
