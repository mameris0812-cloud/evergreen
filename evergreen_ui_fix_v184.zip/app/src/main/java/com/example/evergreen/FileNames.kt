package com.example.evergreen

import android.webkit.MimeTypeMap
import android.webkit.URLUtil

/**
 * 다운로드 파일 이름 / MIME 정하기.
 *
 * URLUtil.guessFileName 은 서버가 종류를 알 수 없는 "application/octet-stream" 으로 보내면
 * 주소나 헤더에 적힌 올바른 확장자(.apk, .zip …)를 버리고 ".bin" 으로 바꿔 버린다.
 * 그래서 '그냥 바이너리'라는 뜻의 일반적인 MIME 은 없는 것으로 보고 이름을 정한다.
 */
object FileNames {

    private val GENERIC = setOf(
        "application/octet-stream", "binary/octet-stream", "application/x-binary",
        "application/force-download", "application/x-force-download",
        "application/download", "application/x-download", "application/unknown"
    )

    fun isGeneric(mime: String?): Boolean =
        mime.isNullOrBlank() || mime.substringBefore(';').trim().lowercase() in GENERIC

    fun guess(url: String?, contentDisposition: String?, mime: String?): String =
        URLUtil.guessFileName(url, contentDisposition, if (isGeneric(mime)) null else mime)

    /** 서버가 준 MIME 이 일반적이면, 파일 이름의 확장자로 알맞은 MIME 을 찾는다 (예: .apk → android 패키지) */
    fun mimeFor(fileName: String, mime: String?): String? {
        if (!isGeneric(mime)) return mime
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: mime
    }
}
