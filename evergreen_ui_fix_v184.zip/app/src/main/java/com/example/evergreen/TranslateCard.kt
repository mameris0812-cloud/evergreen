package com.example.evergreen

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.google.android.material.color.MaterialColors
import com.google.android.material.progressindicator.LinearProgressIndicator

/**
 * 페이지 번역 진행 카드.
 * 화면 아래에 떠올라서 지구본이 돌며 "번역 중 · 12/40" 과 진행 막대를 보여 주고,
 * 끝나면 체크 표시가 통통 튀며 "원문 보기" 버튼으로 바뀐 뒤 스스로 내려간다.
 */
class TranslateCard(
    private val activity: AppCompatActivity,
    private val isEnabled: () -> Boolean = { true }
) {
    private val ui = Handler(Looper.getMainLooper())
    private val d = activity.resources.displayMetrics.density

    private var card: LinearLayout? = null
    private var iconBox: FrameLayout? = null
    private var icon: ImageView? = null
    private var title: TextView? = null
    private var sub: TextView? = null
    private var action: TextView? = null
    private var bar: LinearProgressIndicator? = null
    private var spin: ObjectAnimator? = null
    private var dismissRunnable: Runnable? = null
    private var onAction: (() -> Unit)? = null
    private var shownTotal = 0
    private var running = false          // 번역이 진행 중인 동안 true
    private var hiddenByUser = false     // 이번 번역에서 카드를 숨겼다 (번역은 계속된다)

    private fun dp(n: Int) = (n * d).toInt()
    private fun color(attr: Int, fallback: Int) = MaterialColors.getColor(activity, attr, fallback)

    private val onSurface get() = color(com.google.android.material.R.attr.colorOnSurface, Color.BLACK)
    private val onSurfaceVar get() = color(com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)
    private val primary get() = color(com.google.android.material.R.attr.colorPrimary, Color.GREEN)
    private val primaryContainer get() = color(com.google.android.material.R.attr.colorPrimaryContainer, Color.LTGRAY)
    private val surface get() = color(com.google.android.material.R.attr.colorSurface, Color.WHITE)
    private val outline get() = color(com.google.android.material.R.attr.colorOutlineVariant, Color.LTGRAY)

    val isShowing get() = card?.parent != null

    /** 번역을 시작할 때: 글자를 찾는 동안은 막대가 흐르는 모양. */
    fun showSearching(onCancel: () -> Unit) {
        running = true
        hiddenByUser = !isEnabled()
        if (hiddenByUser) return
        build()
        cancelDismiss()
        setSpinning(true)
        icon?.setImageResource(R.drawable.ic_globe)
        icon?.imageTintList = android.content.res.ColorStateList.valueOf(primary)
        title?.text = "번역 준비 중"
        sub?.text = "페이지의 글자를 찾는 중…"
        bar?.apply {
            animate().cancel()
            visibility = View.VISIBLE
            alpha = 1f
            isIndeterminate = true
        }
        setAction("취소") { onCancel() }
        attachWithAnimation()
    }

    /** 진행 상황. done/total 은 묶음 수. */
    fun progress(done: Int, total: Int) {
        if (!isShowing || total <= 0) return
        val pct = (done * 100 / total).coerceIn(0, 100)
        title?.text = "한국어로 번역 중"
        sub?.text = "$pct% · $done/$total"
        bar?.let { b ->
            if (b.isIndeterminate) {
                b.isIndeterminate = false
                b.max = 100
            }
            b.setProgressCompat(pct, true)
        }
        shownTotal = total
    }

    /**
     * 끝났을 때. ok = 성공(체크 표시), 아니면 안내/오류.
     * actionLabel 이 있으면 오른쪽 버튼(원문 보기 등)을 보여 주고, 그동안은 더 오래 머문다.
     */
    fun finish(
        titleText: String,
        subText: String? = null,
        ok: Boolean,
        actionLabel: String? = null,
        onActionClick: (() -> Unit)? = null,
        withBar: Boolean = true
    ) {
        val suppress = hiddenByUser || !isEnabled()
        hiddenByUser = false
        running = false
        if (suppress) {
            // 카드를 숨겼거나 꺼 둔 경우: 카드 대신 짧은 안내만 보여 준다
            dismiss()
            AppToast.show(activity, titleText + (if (subText.isNullOrBlank()) "" else " · $subText"))
            return
        }
        build()
        cancelDismiss()
        setSpinning(false)
        if (!isShowing) attachWithAnimation()
        val ic = icon
        ic?.rotationY = 0f
        if (ok) {
            ic?.setImageResource(R.drawable.ic_check)
            ic?.imageTintList = android.content.res.ColorStateList.valueOf(primary)
            Motion.pop(iconBox ?: ic ?: return, 0.4f)
        } else {
            ic?.setImageResource(R.drawable.ic_globe)
            ic?.imageTintList = android.content.res.ColorStateList.valueOf(onSurfaceVar)
        }
        title?.text = titleText
        sub?.apply {
            if (subText.isNullOrBlank()) visibility = View.GONE else {
                visibility = View.VISIBLE
                text = subText
            }
        }
        bar?.let { b ->
            if (!withBar) {
                b.animate().cancel()
                b.visibility = View.GONE
            } else if (ok) {
                if (b.isIndeterminate) { b.isIndeterminate = false; b.max = 100 }
                b.setProgressCompat(100, true)
                b.animate().alpha(0f).setStartDelay(450).setDuration(250)
                    .withEndAction { b.visibility = View.GONE }.start()
            } else {
                b.animate().cancel()
                b.visibility = View.GONE
            }
        }
        if (actionLabel != null && onActionClick != null) {
            setAction(actionLabel) { onActionClick() }
        } else {
            action?.visibility = View.GONE
            onAction = null
        }
        val stay = if (actionLabel != null) 6000L else 3200L
        val r = Runnable { dismiss() }
        dismissRunnable = r
        ui.postDelayed(r, stay)
    }

    /** 사용자가 카드를 숨긴다 (버튼·밀어서). 번역 중이면 번역은 그대로 이어진다. */
    fun hideByUser() {
        if (running) {
            hiddenByUser = true
            AppToast.show(activity, "카드를 숨겼어요 · 번역은 계속돼요")
        }
        dismiss()
    }

    fun dismiss() {
        cancelDismiss()
        setSpinning(false)
        val c = card ?: return
        if (c.parent == null) return
        val remove = {
            (c.parent as? ViewGroup)?.removeView(c)
            c.alpha = 1f
            c.translationY = 0f
            c.translationX = 0f
        }
        if (!Motion.enabled(activity)) {
            remove()
            return
        }
        Motion.cancel(c)
        c.animate().alpha(0f).translationY(c.translationY + dp(24).toFloat()).scaleX(0.96f).scaleY(0.96f)
            .setDuration(180).withEndAction {
                remove()
                c.scaleX = 1f
                c.scaleY = 1f
            }.start()
    }

    // ───────────────────────── 내부 ─────────────────────────

    private fun cancelDismiss() {
        dismissRunnable?.let { ui.removeCallbacks(it) }
        dismissRunnable = null
        card?.animate()?.cancel()
    }

    private fun setAction(label: String, click: () -> Unit) {
        onAction = click
        action?.apply {
            text = label
            visibility = View.VISIBLE
        }
    }

    private fun setSpinning(on: Boolean) {
        val ic = icon ?: return
        if (on) {
            if (spin?.isRunning == true || !Motion.enabled(activity)) return
            ic.cameraDistance = 9000f * d
            spin = ObjectAnimator.ofFloat(ic, View.ROTATION_Y, 0f, 360f).apply {
                duration = 1700
                interpolator = LinearInterpolator()
                repeatCount = ValueAnimator.INFINITE
                start()
            }
        } else {
            spin?.cancel()
            spin = null
            ic.rotationY = 0f
        }
    }

    private fun attachWithAnimation() {
        val c = card ?: return
        if (c.parent != null) return
        val host = activity.findViewById<FrameLayout>(android.R.id.content) ?: return
        val tablet = activity.resources.configuration.screenWidthDp >= 600
        val lp = FrameLayout.LayoutParams(
            if (tablet) dp(420) else ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            // 폰은 하단 내비게이션 바(58dp) 위로 띄운다
            bottomMargin = dp(if (tablet) 28 else 74)
            if (!tablet) {
                leftMargin = dp(14)
                rightMargin = dp(14)
            }
        }
        c.alpha = 1f
        c.translationY = 0f
        c.scaleX = 1f
        c.scaleY = 1f
        host.addView(c, lp)
        c.translationZ = dp(12).toFloat()
        if (Motion.enabled(activity)) {
            c.alpha = 0f
            c.translationY = dp(44).toFloat()
            c.scaleX = 0.92f
            c.scaleY = 0.92f
            Motion.spring(c, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            Motion.spring(c, DynamicAnimation.TRANSLATION_Y, 0f, 260f, 0.68f)
            Motion.spring(c, DynamicAnimation.SCALE_X, 1f, 300f, 0.6f)
            Motion.spring(c, DynamicAnimation.SCALE_Y, 1f, 300f, 0.6f)
        }
    }

    private fun build() {
        if (card != null) return
        val bg = GradientDrawable().apply {
            setColor(surface)
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), outline)
        }
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(14), dp(12), dp(10), dp(12))
            isClickable = true // 카드 뒤 페이지로 터치가 새지 않게
        }

        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val box = FrameLayout(activity).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(primaryContainer)
            }
        }
        val img = ImageView(activity).apply {
            setImageResource(R.drawable.ic_globe)
            imageTintList = android.content.res.ColorStateList.valueOf(primary)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        box.addView(img, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        row.addView(box, LinearLayout.LayoutParams(dp(40), dp(40)))

        val texts = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
        }
        val t = TextView(activity).apply {
            setTextColor(onSurface)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val s = TextView(activity).apply {
            setTextColor(onSurfaceVar)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        texts.addView(t)
        texts.addView(s)
        row.addView(
            texts,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(12)
                marginEnd = dp(6)
            }
        )

        val hide = android.widget.ImageButton(activity).apply {
            setImageResource(R.drawable.ic_expand_more)
            imageTintList = android.content.res.ColorStateList.valueOf(onSurfaceVar)
            contentDescription = "카드 숨기기"
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(6), dp(6), dp(6), dp(6))
            val ta = TypedValue()
            if (activity.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ta, true)) {
                setBackgroundResource(ta.resourceId)
            } else {
                background = null
            }
            setOnClickListener { hideByUser() }
        }
        val act = TextView(activity).apply {
            setTextColor(primary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            val ta = TypedValue()
            if (activity.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ta, true)) {
                setBackgroundResource(ta.resourceId)
            }
            isClickable = true
            setOnClickListener { onAction?.invoke() }
            visibility = View.GONE
        }
        row.addView(act)
        row.addView(hide, LinearLayout.LayoutParams(dp(36), dp(36)))
        root.addView(row)

        // 카드를 아래나 옆으로 밀면 숨긴다. 놓았을 때 충분히 밀렸으면 숨기고, 아니면 제자리로 돌아온다.
        var downX = 0f
        var downY = 0f
        var dragging = false
        val slop = android.view.ViewConfiguration.get(activity).scaledTouchSlop
        root.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; dragging = false
                    Motion.cancel(v)
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (Math.abs(dx) > slop || dy > slop)) dragging = true
                    if (dragging) {
                        v.translationX = dx
                        v.translationY = if (dy > 0) dy else dy / 4f   // 위로는 살짝만
                        v.alpha = (1f - Math.max(Math.abs(dx) / dp(260), dy / dp(160))).coerceIn(0.25f, 1f)
                    }
                    true
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    val dx = v.translationX
                    val dy = v.translationY
                    if (dragging && (Math.abs(dx) > dp(90) || dy > dp(56))) {
                        hideByUser()
                    } else {
                        Motion.spring(v, DynamicAnimation.TRANSLATION_X, 0f, 400f, 0.7f)
                        Motion.spring(v, DynamicAnimation.TRANSLATION_Y, 0f, 400f, 0.7f)
                        Motion.spring(v, DynamicAnimation.ALPHA, 1f, 400f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                    }
                    true
                }
                else -> true
            }
        }

        val pb = LinearProgressIndicator(activity).apply {
            trackThickness = dp(4)
            trackCornerRadius = dp(2)
            setIndicatorColor(primary)
            trackColor = primaryContainer
            isIndeterminate = true
        }
        root.addView(
            pb,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
                marginEnd = dp(4)
            }
        )

        card = root
        iconBox = box
        icon = img
        title = t
        sub = s
        action = act
        bar = pb
    }
}
