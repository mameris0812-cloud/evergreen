package com.example.evergreen

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.autofill.AutofillValue
import android.widget.AutoCompleteTextView
import androidx.annotation.RequiresApi

/**
 * 주소창. 비밀번호 관리자·자동완성 서비스가 로그인 정보를 여기에 넣지 못하게 막는다.
 * (자동완성 프레임워크는 importantForAutofill=no 와 함께, 값 채우기 요청 자체도 무시한다)
 */
class UrlEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.autoCompleteTextViewStyle
) : AutoCompleteTextView(context, attrs, defStyleAttr) {

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun autofill(value: AutofillValue?) { /* 무시 */ }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun getAutofillType(): Int = AUTOFILL_TYPE_NONE

    @RequiresApi(Build.VERSION_CODES.O)
    override fun getAutofillValue(): AutofillValue? = null
}
