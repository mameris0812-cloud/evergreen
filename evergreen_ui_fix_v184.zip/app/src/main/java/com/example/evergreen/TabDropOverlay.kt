package com.example.evergreen

import android.content.Context
import android.view.View

/**
 * 탭을 시스템 드래그로 끌고 있는 동안 창 위에 얹는 투명한 막.
 * 그리지는 않고, 놓을 곳을 받아 주는(드래그 이벤트 수신) 역할만 한다.
 */
class TabDropOverlay(context: Context) : View(context) {
    companion object {
        const val ZONE_NONE = 0
        const val ZONE_POPUP = 1
    }

    fun setZone(@Suppress("UNUSED_PARAMETER") z: Int) {}
}
