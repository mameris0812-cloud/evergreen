package com.example.evergreen

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** 검색어 자동완성. 네트워크 작업이므로 백그라운드 스레드에서 호출. */
object Suggest {
    fun fetch(query: String): List<String> {
        val endpoint = "https://suggestqueries.google.com/complete/search?client=firefox&q=" +
            URLEncoder.encode(query, "UTF-8")
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 2500
            conn.readTimeout = 2500
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
            val arr = JSONArray(text).getJSONArray(1)
            return (0 until arr.length()).map { arr.getString(it) }
        } finally {
            conn.disconnect()
        }
    }
}
