package com.example.evergreen

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** 서비스 → 앱(액티비티) 연결: 알림의 '정지' 버튼이 눌리면 재생 중인 미디어를 멈춘다. */
object MediaBridge {
    @Volatile var onStop: (() -> Unit)? = null

    /** 내장 플레이어가 백그라운드에서 재생 중일 때 알림의 '정지' 로 멈추기 위한 연결 */
    @Volatile var playerStop: (() -> Unit)? = null
}

/**
 * 백그라운드 오디오용 포그라운드 서비스.
 * 영상/소리가 재생되는 동안만 떠 있으면서 앱이 화면 밖으로 나가거나 화면이 꺼져도 시스템이 앱을 멈추지 못하게 한다.
 */
class MediaService : Service() {

    companion object {
        // 채널의 중요도는 만든 뒤에 바꿀 수 없어서, 소리·팝업 없는 최소 중요도 채널을 새 이름으로 만든다
        private const val CH = "media_playback_quiet"
        private const val OLD_CH = "media_playback"
        private const val ID = 4201
        private const val ACTION_STOP = "com.example.evergreen.MEDIA_STOP"

        fun start(ctx: Context, title: String, sub: String) {
            try {
                ContextCompat.startForegroundService(
                    ctx,
                    Intent(ctx, MediaService::class.java).putExtra("title", title).putExtra("sub", sub)
                )
            } catch (e: Exception) {
                // 백그라운드에서 시작이 막힌 경우 등: 무시
            }
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, MediaService::class.java)) } catch (e: Exception) {}
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.deleteNotificationChannel(OLD_CH)
            nm.createNotificationChannel(
                NotificationChannel(CH, "미디어 재생 (백그라운드 유지)", NotificationManager.IMPORTANCE_MIN).apply {
                    setShowBadge(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_SECRET
                    setSound(null, null)
                    enableVibration(false)
                    enableLights(false)
                }
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            MediaBridge.onStop?.invoke()
            MediaBridge.playerStop?.invoke()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val title = intent?.getStringExtra("title").orEmpty().ifBlank { "재생 중" }
        val sub = intent?.getStringExtra("sub").orEmpty()

        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, MediaService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_play)
            .setContentTitle(title)
            .setContentText(sub)
            .setContentIntent(open)
            .addAction(0, "정지", stop)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setShowWhen(false)
            .build()
        ServiceCompat.startForeground(this, ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        return START_NOT_STICKY
    }
}
