package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.webkit.WebView
import androidx.core.graphics.ColorUtils
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * WebView 위에 겹쳐지는 우측 드래그 스크롤바.
 *
 * - 밝은 회색의 얇은 알약 모양 핸들
 * - 스크롤할 때만 부드럽게 나타나고, 멈추면 잠시 뒤 서서히 사라짐
 * - 핸들을 잡으면 굵어지고 뒤에 은은한 레일이 나타남
 * - 핸들 근처만 터치를 가로채서, 오른쪽 가장자리의 링크/버튼은 그대로 눌림
 */
class WebPageScrollBar(context: Context) : View(context) {
    private var target: WebView? = null
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val thumbRect = RectF()
    private val railRect = RectF()

    private var dragging = false
    private var dragOffset = 0f
    private var lastMaxScroll = 0
    private var lastScrollY = 0

    /** 0 = 완전히 숨김, 1 = 완전히 보임 */
    private var shown = 0f
    /** 0 = 평소, 1 = 잡고 드래그 중 */
    private var active = 0f
    private var shownAnim: ValueAnimator? = null
    private var activeAnim: ValueAnimator? = null
    private val hideRunnable = Runnable { if (!dragging) animateShown(0f, HIDE_MS) }

    private val density = resources.displayMetrics.density
    private fun dp(value: Float) = value * density

    init {
        isClickable = true
        isFocusable = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        contentDescription = "웹페이지 스크롤바"
        refresh()
    }

    fun bind(webView: WebView?) {
        target = webView
        dragging = false
        lastScrollY = webView?.scrollY ?: 0
        removeCallbacks(hideRunnable)
        shownAnim?.cancel()
        activeAnim?.cancel()
        shown = 0f
        active = 0f
        refresh()
        postInvalidateOnAnimation()
    }

    /** Call after scroll, page load, or a WebView size change. */
    fun refresh() {
        val web = target
        val maxScroll = web?.let { max(0, (it.contentHeight * it.scale).roundToInt() - it.height) } ?: 0
        lastMaxScroll = maxScroll
        val shouldShow = web != null && web.height > 0 && maxScroll > dp(2f).roundToInt()
        val newVisibility = if (shouldShow) VISIBLE else GONE
        if (visibility != newVisibility) visibility = newVisibility
        if (shouldShow) {
            val y = web!!.scrollY
            // 실제로 스크롤 위치가 바뀐 경우에만 나타나게 한다 (레이아웃 갱신만으로는 깜빡이지 않음)
            if (y != lastScrollY) {
                lastScrollY = y
                reveal()
            }
            invalidate()
        }
    }

    // ───────────────────────── 애니메이션 ─────────────────────────

    private fun reveal() {
        removeCallbacks(hideRunnable)
        if (shown < 1f) animateShown(1f, SHOW_MS)
        if (!dragging) postDelayed(hideRunnable, HIDE_DELAY_MS)
    }

    private fun animateShown(to: Float, duration: Long) {
        shownAnim?.cancel()
        if (shown == to) return
        shownAnim = ValueAnimator.ofFloat(shown, to).apply {
            this.duration = duration
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun animateActive(to: Float) {
        activeAnim?.cancel()
        if (active == to) return
        activeAnim = ValueAnimator.ofFloat(active, to).apply {
            duration = ACTIVE_MS
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener {
                active = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(hideRunnable)
        shownAnim?.cancel()
        activeAnim?.cancel()
    }

    // ───────────────────────── 계산 ─────────────────────────

    private fun metrics(): Triple<Float, Float, Float> {
        val inset = dp(10f)
        val trackTop = inset
        val trackHeight = max(0f, height - inset * 2f)
        val web = target
        val contentHeight = web?.let { (it.contentHeight * it.scale).toFloat() } ?: 0f
        val viewportHeight = web?.height?.toFloat() ?: 0f
        val ratio = if (contentHeight > 0f) (viewportHeight / contentHeight).coerceIn(0f, 1f) else 1f
        val minThumb = minOf(dp(44f), trackHeight)
        val thumbHeight = (trackHeight * ratio).coerceIn(minThumb, trackHeight)
        return Triple(trackTop, trackHeight, thumbHeight)
    }

    private fun thumbTop(trackTop: Float, trackHeight: Float, thumbHeight: Float): Float {
        val web = target ?: return trackTop
        val travel = max(0f, trackHeight - thumbHeight)
        val maxScroll = max(1, lastMaxScroll)
        val fraction = (web.scrollY.toFloat() / maxScroll).coerceIn(0f, 1f)
        return trackTop + travel * fraction
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        refresh()
    }

    // ───────────────────────── 그리기 ─────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (target == null || shown <= 0.01f) return
        val (top, trackHeight, thumbHeight) = metrics()
        if (trackHeight <= 0f || lastMaxScroll <= 0) return

        val maxW = dp(THUMB_ACTIVE_DP)
        val thumbW = dp(THUMB_IDLE_DP) + (maxW - dp(THUMB_IDLE_DP)) * active
        val right = width - dp(4f)
        val left = right - thumbW

        // 드래그 중에만 나타나는 은은한 레일
        if (active > 0.01f) {
            railPaint.color = ColorUtils.setAlphaComponent(
                RAIL_COLOR, (RAIL_ALPHA * active * shown).roundToInt()
            )
            railRect.set(right - maxW, top, right, top + trackHeight)
            canvas.drawRoundRect(railRect, maxW / 2f, maxW / 2f, railPaint)
        }

        // 밝은 회색 핸들 (드래그하면 살짝 진해짐)
        val color = ColorUtils.blendARGB(THUMB_COLOR, THUMB_COLOR_ACTIVE, active)
        val alpha = (255f * (0.88f + 0.12f * active) * shown).roundToInt()
        thumbPaint.color = ColorUtils.setAlphaComponent(color, alpha)

        val y = thumbTop(top, trackHeight, thumbHeight)
        thumbRect.set(left, y, right, y + thumbHeight)
        canvas.drawRoundRect(thumbRect, thumbW / 2f, thumbW / 2f, thumbPaint)

        // 흰 배경 페이지에서도 보이도록 아주 옅은 테두리
        outlinePaint.strokeWidth = dp(0.6f)
        outlinePaint.color = ColorUtils.setAlphaComponent(0xFF000000.toInt(), (34f * shown).roundToInt())
        val half = outlinePaint.strokeWidth / 2f
        canvas.drawRoundRect(
            thumbRect.left + half, thumbRect.top + half, thumbRect.right - half, thumbRect.bottom - half,
            thumbW / 2f, thumbW / 2f, outlinePaint
        )
    }

    // ───────────────────────── 터치 ─────────────────────────

    override fun onTouchEvent(event: MotionEvent): Boolean {
        target ?: return false
        if (lastMaxScroll <= 0) return false
        val (top, trackHeight, thumbHeight) = metrics()
        if (trackHeight <= 0f) return false
        val currentTop = thumbTop(top, trackHeight, thumbHeight)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // 핸들 근처가 아니면 터치를 WebView 로 넘긴다 (오른쪽 가장자리 링크가 눌리도록)
                val slop = dp(14f)
                if (event.y < currentTop - slop || event.y > currentTop + thumbHeight + slop) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                removeCallbacks(hideRunnable)
                animateShown(1f, SHOW_MS)
                animateActive(1f)
                dragOffset = event.y - currentTop
                moveTo(event.y, top, trackHeight, thumbHeight)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                moveTo(event.y, top, trackHeight, thumbHeight)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) return false
                moveTo(event.y, top, trackHeight, thumbHeight)
                endDrag()
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) endDrag()
                return true
            }
        }
        return true
    }

    private fun endDrag() {
        dragging = false
        parent?.requestDisallowInterceptTouchEvent(false)
        animateActive(0f)
        removeCallbacks(hideRunnable)
        postDelayed(hideRunnable, HIDE_DELAY_MS)
        invalidate()
    }

    private fun moveTo(y: Float, trackTop: Float, trackHeight: Float, thumbHeight: Float) {
        val web = target ?: return
        val travel = max(1f, trackHeight - thumbHeight)
        val thumbTop = (y - dragOffset).coerceIn(trackTop, trackTop + travel)
        val fraction = ((thumbTop - trackTop) / travel).coerceIn(0f, 1f)
        val maxScroll = max(0, (web.contentHeight * web.scale).roundToInt() - web.height)
        lastMaxScroll = maxScroll
        web.scrollTo(web.scrollX, (fraction * maxScroll).roundToInt())
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private companion object {
        const val THUMB_IDLE_DP = 4f
        const val THUMB_ACTIVE_DP = 8f
        const val SHOW_MS = 140L
        const val HIDE_MS = 380L
        const val ACTIVE_MS = 160L
        const val HIDE_DELAY_MS = 1000L
        const val THUMB_COLOR = 0xFFC9CDD2.toInt()        // 밝은 회색
        const val THUMB_COLOR_ACTIVE = 0xFFB4B9BF.toInt() // 드래그 시 살짝 진한 회색
        const val RAIL_COLOR = 0xFFBFC3C8.toInt()
        const val RAIL_ALPHA = 70
    }
}
