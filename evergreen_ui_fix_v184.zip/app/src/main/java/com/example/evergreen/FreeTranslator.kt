package com.example.evergreen

import android.util.LruCache
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * API 키 없이 쓰는 번역 (Google 번역의 공개 웹 주소를 사용한다).
 * - 여러 문장을 한 번에 보내고, 응답 모양이 예상과 다르면 문장 하나씩 다시 보낸다.
 * - 한 번 번역한 글은 앱을 쓰는 동안 기억해서 같은 글을 다시 보내지 않는다.
 * - 반드시 백그라운드 스레드에서 부른다. 스레드마다 인스턴스를 따로 쓰면 [cancel] 로 개별 중단할 수 있다.
 */
class FreeTranslator {
    @Volatile
    private var conn: HttpURLConnection? = null

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
        try {
            conn?.disconnect()
        } catch (e: Exception) {
            // 이미 끝난 연결
        }
    }

    private class HttpError(val code: Int) : IOException("HTTP $code")

    /** 결과 글은 [texts] 와 같은 순서·같은 개수. 실패하면 (null, 오류 메시지). */
    fun translate(texts: List<String>, target: String = "ko"): Pair<List<String>?, String?> {
        cancelled = false
        if (texts.isEmpty()) return Pair(emptyList(), null)
        val out = arrayOfNulls<String>(texts.size)
        val todo = ArrayList<Int>()
        for (i in texts.indices) {
            val hit = cache.get(target + "\u0000" + texts[i])
            if (hit != null) out[i] = hit else todo.add(i)
        }
        try {
            var p = 0
            while (p < todo.size) {
                if (cancelled) return Pair(null, null)
                // 한 번에 너무 크지 않게 (약 4천 자 / 30문장)
                val chunk = ArrayList<Int>()
                var chars = 0
                while (p < todo.size && chunk.size < 30) {
                    val len = texts[todo[p]].length
                    if (chunk.isNotEmpty() && chars + len > 4000) break
                    chunk.add(todo[p])
                    chars += len
                    p++
                }
                val part = translateChunk(chunk.map { texts[it] }, target)
                if (cancelled) return Pair(null, null)
                for (k in chunk.indices) {
                    val tr = part[k]
                    out[chunk[k]] = tr
                    cache.put(target + "\u0000" + texts[chunk[k]], tr)
                }
            }
        } catch (e: HttpError) {
            if (cancelled) return Pair(null, null)
            return Pair(
                null,
                if (e.code == 429 || e.code == 403) "번역 서버가 잠시 요청을 막았어요. 잠시 뒤에 다시 시도해 주세요"
                else "번역 서버 오류 (${e.code})"
            )
        } catch (e: IOException) {
            if (cancelled) return Pair(null, null)
            return Pair(null, "번역 서버에 연결하지 못했어요. 인터넷 연결을 확인해 주세요")
        } catch (e: Exception) {
            if (cancelled) return Pair(null, null)
            return Pair(null, "번역 결과를 읽지 못했어요")
        }
        return Pair(out.map { it ?: "" }, null)
    }

    /** 한 묶음 번역. 묶음 응답을 못 읽으면 문장 하나씩 보낸다. */
    private fun translateChunk(chunk: List<String>, target: String): List<String> {
        val multi = try {
            val body = StringBuilder()
            for (t in chunk) body.append("q=").append(URLEncoder.encode(t, "UTF-8")).append('&')
            val raw = post(
                "https://translate.googleapis.com/translate_a/t?client=gtx&sl=auto&tl=$target&dt=t&ie=UTF-8&oe=UTF-8&format=text",
                body.toString()
            )
            parseMulti(raw, chunk.size)
        } catch (e: HttpError) {
            throw e
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            null
        }
        if (multi != null) {
            // 빈 결과는 원문 그대로 둔다
            return multi.mapIndexed { i, s -> if (s.isBlank()) chunk[i] else s }
        }
        return chunk.map { t ->
            if (cancelled) throw IOException("cancelled")
            val raw = post(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$target&dt=t&ie=UTF-8&oe=UTF-8",
                "q=" + URLEncoder.encode(t, "UTF-8")
            )
            parseSingle(raw).ifBlank { t }
        }
    }

    private fun post(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            c.setRequestProperty("User-Agent", UA)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code != 200) throw HttpError(code)
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            try {
                c.disconnect()
            } catch (e: Exception) {
                // 무시
            }
        }
    }

    /** 묶음 응답: ["번역", ...] 또는 [["번역","en"], ...]. 개수가 안 맞으면 null. */
    private fun parseMulti(raw: String, n: Int): List<String>? {
        val arr = JSONArray(raw)
        fun item(o: Any?): String? = when (o) {
            is String -> o
            is JSONArray -> if (o.length() > 0 && !o.isNull(0)) o.optString(0) else null
            else -> null
        }
        if (n == 1) return item(arr.opt(0))?.let { listOf(it) }
        if (arr.length() != n) return null
        val res = ArrayList<String>(n)
        for (i in 0 until n) res.add(item(arr.opt(i)) ?: return null)
        return res
    }

    /** 단일 응답: [[["번역","원문",...], ...], ...] — 조각을 이어 붙인다. */
    private fun parseSingle(raw: String): String {
        val segs = JSONArray(raw).getJSONArray(0)
        val sb = StringBuilder()
        for (k in 0 until segs.length()) {
            val seg = segs.optJSONArray(k) ?: continue
            if (!seg.isNull(0)) sb.append(seg.optString(0))
        }
        return sb.toString()
    }

    companion object {
        private const val UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

        private val cache = LruCache<String, String>(4000)

        /** 글이 이미 한국어(한글 비율이 높음)이거나 번역할 글자가 없으면 true */
        fun isKoreanOrEmpty(s: String): Boolean {
            var letters = 0
            var hangul = 0
            for (ch in s) {
                if (ch in '\uAC00'..'\uD7A3' || ch in '\u3131'..'\u318E') {
                    hangul++
                    letters++
                } else if (Character.isLetter(ch)) {
                    letters++
                }
            }
            return letters == 0 || hangul.toFloat() / letters > 0.4f
        }
    }
}
