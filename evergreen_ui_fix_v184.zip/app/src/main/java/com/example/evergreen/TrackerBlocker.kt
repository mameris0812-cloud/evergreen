package com.example.evergreen

import java.util.concurrent.atomic.AtomicInteger

/**
 * 트래커 차단기 (엄격 모드).
 * - 웹사이트 동작에 필요한 도메인(로그인·결제·캡차 등)은 허용 목록으로 항상 통과
 * - 그 외 알려진 트래킹 도메인으로 가는 "서드파티 하위 요청"은 모두 차단
 * - 페이지와 같은 사이트(퍼스트파티) 요청은 건드리지 않음
 */
class TrackerBlocker {

    val blockedCount = AtomicInteger(0)

    private val verdicts = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    fun shouldBlock(requestHost: String?, pageHost: String?): Boolean {
        if (requestHost.isNullOrEmpty()) return false
        // 요청마다 목록을 뒤지지 않도록 (요청 호스트, 페이지 호스트) 조합별 결과를 기억한다
        val key = if (pageHost == null) requestHost else "$requestHost|$pageHost"
        verdicts[key]?.let { return it }
        val req = requestHost.lowercase()
        val r = when {
            pageHost != null && registrable(req) == registrable(pageHost.lowercase()) -> false
            matches(req, ESSENTIAL) -> false
            else -> matches(req, TRACKERS)
        }
        if (verdicts.size > 6000) verdicts.clear()
        verdicts[key] = r
        return r
    }

    private fun matches(host: String, set: Set<String>): Boolean {
        var h = host
        while (true) {
            if (set.contains(h)) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
            if (!h.contains('.')) return false
        }
    }

    /** 대략적인 사이트 단위(eTLD+1). co.kr 같은 2단계 TLD만 따로 처리한다. */
    private fun registrable(host: String): String {
        val parts = host.split('.')
        if (parts.size <= 2) return host
        val last2 = parts.takeLast(2).joinToString(".")
        return if (last2 in SECOND_LEVEL) parts.takeLast(3).joinToString(".") else last2
    }

    companion object {
        private val SECOND_LEVEL = setOf(
            "co.kr", "or.kr", "go.kr", "ne.kr", "ac.kr", "co.uk", "org.uk", "co.jp", "com.au", "com.cn", "com.br",
            "com.tw", "org.tw", "com.hk", "com.sg", "com.my", "com.ph", "com.vn", "co.id", "co.th", "co.in",
            "co.nz", "co.za", "com.tr", "com.mx", "com.ar", "com.ua"
        )

        /** 사이트가 정상 동작하는 데 필요한 도메인: 캡차, 로그인(SSO), 결제 */
        val ESSENTIAL: Set<String> = setOf(
            "recaptcha.net", "hcaptcha.com", "challenges.cloudflare.com", "gstatic.com",
            "accounts.google.com", "appleid.apple.com", "login.microsoftonline.com",
            "kauth.kakao.com", "nid.naver.com", "stripe.com", "js.stripe.com", "paypal.com",
            "tosspayments.com", "iamport.kr"
        )

        val TRACKERS: Set<String> = setOf(
            // 분석·태그 관리
            "googletagmanager.com", "googletagservices.com", "google-analytics.com", "analytics.google.com",
            "stats.g.doubleclick.net", "segment.io", "segment.com", "mixpanel.com", "amplitude.com",
            "heap.io", "heapanalytics.com", "fullstory.com", "hotjar.com", "hotjar.io", "mouseflow.com",
            "crazyegg.com", "luckyorange.com", "clarity.ms", "newrelic.com", "nr-data.net",
            "chartbeat.com", "chartbeat.net", "parsely.com", "comscore.com", "scorecardresearch.com",
            "quantserve.com", "quantcount.com", "omtrdc.net", "demdex.net", "everesttech.net",
            "adobedtm.com", "tiqcdn.com", "branch.io", "appsflyer.com", "adjust.com", "kochava.com",
            // 소셜 픽셀
            "connect.facebook.net", "pixel.facebook.com", "analytics.twitter.com", "ads-twitter.com",
            "analytics.tiktok.com", "ads.linkedin.com", "px.ads.linkedin.com", "snap.licdn.com",
            "sc-static.net", "tr.snapchat.com", "ct.pinterest.com", "bat.bing.com",
            // 데이터 브로커·리타게팅
            "bluekai.com", "krxd.net", "exelator.com", "agkn.com", "rlcdn.com", "liveramp.com",
            "tapad.com", "eyeota.net", "lotame.com", "crwdcntrl.net", "mathtag.com", "turn.com",
            "adsymptotic.com", "bounceexchange.com", "outbrain.com", "taboola.com", "criteo.com",
            "criteo.net", "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
            "adnxs.com", "doubleclick.net", "adsrvr.org", "id5-sync.com", "idsync.rlcdn.com",
            // 국내
            "wcs.naver.com", "wcs.naver.net", "analytics.kakao.com", "t1.daumcdn.net", "dable.io",
            "ads.kakao.com", "ad.daum.net", "acecounter.com", "wisetracker.co.kr"
        )
    }
}
