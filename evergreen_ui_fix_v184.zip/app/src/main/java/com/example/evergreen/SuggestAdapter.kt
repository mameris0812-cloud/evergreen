package com.example.evergreen

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView

/**
 * 주소창 아래 목록 어댑터. 입력한 글자로 걸러내지 않고, 받은 목록을 그대로 보여 준다.
 * - 추천 모드: 아이콘(검색 / 주소) + 글자
 * - 최근 검색 모드: 맨 위에 "최근 검색 · 전체 삭제" 줄, 각 줄 오른쪽에 지우기 버튼
 */
class SuggestAdapter(context: Context, private val data: List<String>) : BaseAdapter(), Filterable {

    var recentMode = false
    var onRemove: ((String) -> Unit)? = null
    var onClearAll: (() -> Unit)? = null

    /** 목록이 팝업 창에 붙어 보이게 되면 불린다 (팝업 뒤 블러를 거는 데 쓴다) */
    var onShown: ((View) -> Unit)? = null

    private val inflater = LayoutInflater.from(context)

    private fun hasHeader() = recentMode && data.isNotEmpty()
    private fun offset() = if (hasHeader()) 1 else 0

    /** 눌린 자리의 글자 (제목 줄이면 null) */
    fun itemAt(position: Int): String? = data.getOrNull(position - offset())

    override fun getCount() = data.size + offset()
    override fun getItem(position: Int): String? = itemAt(position)
    override fun getItemId(position: Int) = position.toLong()
    override fun getViewTypeCount() = 2
    override fun getItemViewType(position: Int) = if (hasHeader() && position == 0) 0 else 1
    override fun areAllItemsEnabled() = false
    override fun isEnabled(position: Int) = !(hasHeader() && position == 0)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        if (position == 0) parent.post { if (parent.isAttachedToWindow) onShown?.invoke(parent) }
        if (getItemViewType(position) == 0) {
            val v = convertView ?: inflater.inflate(R.layout.item_suggest_header, parent, false)
            v.findViewById<View>(R.id.sgClearAll).setOnClickListener { onClearAll?.invoke() }
            return v
        }
        val v = convertView ?: inflater.inflate(R.layout.item_suggest, parent, false)
        val text = itemAt(position).orEmpty()
        v.findViewById<TextView>(R.id.sgText).text = text
        v.findViewById<ImageView>(R.id.sgIcon).setImageResource(
            when {
                recentMode -> R.drawable.ic_history
                text.startsWith("http://") || text.startsWith("https://") -> R.drawable.ic_globe
                else -> R.drawable.ic_search
            }
        )
        v.findViewById<ImageButton>(R.id.sgRemove).apply {
            visibility = if (recentMode) View.VISIBLE else View.GONE
            setOnClickListener { onRemove?.invoke(text) }
        }
        return v
    }

    private val noFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults =
            FilterResults().also {
                it.values = data
                it.count = data.size
            }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            if (data.isNotEmpty()) notifyDataSetChanged() else notifyDataSetInvalidated()
        }
    }

    override fun getFilter(): Filter = noFilter
}
