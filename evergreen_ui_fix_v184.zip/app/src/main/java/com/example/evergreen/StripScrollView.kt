package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.widget.HorizontalScrollView

/**
 * 상단 탭 줄용 스크롤 뷰.
 * 가장자리 페이드는 "오른쪽(+ 버튼 앞)"에만 보여 준다. 왼쪽은 화면 끝에서 탭이 그냥 잘리게 두는 게 자연스럽다.
 */
class StripScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.horizontalScrollViewStyle
) : HorizontalScrollView(context, attrs, defStyleAttr) {

    override fun getLeftFadingEdgeStrength(): Float = 0f
}
