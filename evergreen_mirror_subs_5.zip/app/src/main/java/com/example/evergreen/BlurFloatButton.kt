package com.example.evergreen

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 상/하단바 숨기기를 켰을 때 뜨는 작은 '더보기' 버튼.
 * Android 12(API 31) 이상에서는 버튼 뒤의 웹 페이지를 실시간으로 흐리게 비춰 주는 유리 모양이 된다.
 * 그 아래 버전에서는 원래의 불투명 배경(bg_float_menu) 그대로다.
 *
 * 버튼 자리의 [source] 화면(앱 화면)을 RenderNode 에 다시 그리고 블러 효과를 걸어서, 버튼 모양(동그라미)으로 잘라 먼저 그린다.
 * 위치·크기·투명도 애니메이션은 뷰 자체의 변형을 그대로 따르므로 따로 맞출 게 없다.
 */
class BlurFloatButton @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null, defStyle: Int = androidx.appcompat.R.attr.imageButtonStyle
) : AppCompatImageButton(ctx, attrs, defStyle) {

    /** 뒤에 비춰 줄 화면 (버튼과 같은 부모 안에서 버튼보다 먼저 그려지는 형제 뷰) */
    var source: View? = null
        set(v) { field = v; invalidate() }

    private val blurOn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    private var node: Any? = null
    private val clip = Path()
    private var pending = false
    private val pre = ViewTreeObserver.OnPreDrawListener {
        // 화면이 바뀌는 프레임마다 한 번만 다시 그린다 (우리가 요청한 프레임에서는 또 요청하지 않아 무한 반복을 막는다)
        if (pending) pending = false
        else if (source != null && isShown && alpha > 0.01f) { pending = true; invalidate() }
        true
    }

    init {
        if (blurOn) {
            // 뒤가 비치도록 반투명 유리 배경
            val fill = ColorUtils.setAlphaComponent(
                MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurfaceContainerHighest), 0x8C
            )
            val edge = ColorUtils.setAlphaComponent(
                MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutlineVariant), 0xA0
            )
            val shape = GradientDrawable().apply {
                this.shape = GradientDrawable.OVAL
                setColor(fill)
                setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), edge)
            }
            val ripple = MaterialColors.getColor(this, android.R.attr.colorControlHighlight, 0x22000000)
            background = RippleDrawable(ColorStateList.valueOf(ripple), shape, null)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (blurOn) viewTreeObserver.addOnPreDrawListener(pre)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (blurOn && viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(pre)
    }

    // 배경(반투명 유리)보다 먼저 흐린 뒤 화면을 그려야 하므로 onDraw 가 아니라 draw 에서 한다
    override fun draw(canvas: Canvas) {
        if (blurOn && source != null && width > 0 && height > 0 && canvas.isHardwareAccelerated) {
            try { drawBackdrop(canvas) } catch (e: Throwable) { /* 못 그리면 유리 배경만 */ }
        }
        super.draw(canvas)
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.S)
    private fun drawBackdrop(canvas: Canvas) {
        val src = source ?: return
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()           // 가장자리가 납작하게 번지지 않게 버튼보다 넓게 그린 뒤 자른다
        val w = width + pad * 2
        val h = height + pad * 2
        val rn = (node as? RenderNode) ?: RenderNode("floatMenuBlur").also {
            val r = 14f * d
            it.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
            node = it
        }
        rn.setPosition(0, 0, w, h)
        val rc = rn.beginRecording(w, h)
        try {
            rc.translate((pad - (left - src.left)).toFloat(), (pad - (top - src.top)).toFloat())
            src.draw(rc)
        } finally {
            rn.endRecording()
        }
        clip.reset()
        clip.addOval(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        canvas.translate(-pad.toFloat(), -pad.toFloat())
        canvas.drawRenderNode(rn)
        canvas.restore()
    }
}
