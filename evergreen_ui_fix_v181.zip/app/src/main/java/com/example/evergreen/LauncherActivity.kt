package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 런처 아이콘(작업 표시줄·앱 목록·엣지 패널 포함)의 진입점. 보이지 않고 바로 닫힌다.
 *
 * 이미 떠 있는 에버그린을 앞으로 가져오기만 하면 삼성 One UI 가 "evergreen은(는) 이미 실행 중입니다."
 * 토스트로 막아 버린다. 그래서 '지금 화면에 보이는 창이 있는데 아이콘을 또 눌렀다'면
 * 창 모드(분할·자유 창)인지 전체 화면인지와 상관없이 새 창을 하나 더 띄운다.
 *
 * - 앱이 화면에 안 보이는 상태(홈 화면에서 눌렀을 때 등)면 예전처럼 떠 있는 앱을 앞으로 가져오거나 새로 시작한다.
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val running = MainActivity.runningWindows().filter { !it.isFinishing && !it.isDestroyed }

        // 새 창은 '창 모드(분할·팝업)로 시작된 경우'나 시스템이 새 작업으로 열라고 한 경우에만 연다.
        // 작업 표시줄·런처 아이콘을 그냥 누른 것(전체 화면 진입)이면 떠 있는 창을 앞으로만 가져오고 새 창은 만들지 않는다.
        val wantNewWindow = isInMultiWindowMode ||
            (intent.flags and Intent.FLAG_ACTIVITY_MULTIPLE_TASK) != 0

        var handled = false
        if (running.isNotEmpty()) {
            if (wantNewWindow) {
                val base = running.firstOrNull { it.visibleNow }
                    ?: running.firstOrNull { it.isInMultiWindowMode }
                    ?: running.first()
                handled = try {
                    base.openNewWindow()
                    true
                } catch (e: Throwable) {
                    false
                }
            }
            if (!handled) {
                handled = try {
                    val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
                    am.appTasks.firstOrNull {
                        it.taskInfo.baseIntent?.component?.className != LauncherActivity::class.java.name
                    }?.also { it.moveToFront() } != null
                } catch (e: Throwable) {
                    false
                }
            }
        }
        if (!handled && running.isEmpty()) {
            // 떠 있는 창이 없으면 '여러 창 가능한' 문서형 작업(BrowserWindowActivity)으로 첫 창을 연다.
            startActivity(
                Intent(this, BrowserWindowActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
            )
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
