package com.example.evergreen

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * AI 이미지 만들기 (Gemini 이미지 모델).
 * 설명 글(과, 있으면 바탕이 될 사진)을 보내면 그림을 만들어 돌려준다.
 * - 한도(429)나 키 거부가 나면 다른 키로, 모델이 없으면(404) 다음 모델로 바꿔 다시 보낸다.
 * - 반드시 백그라운드 스레드에서 부른다. [cancel] 은 어느 스레드에서든 불러도 된다.
 */
class AiImageGen {
    class Result(val images: List<PageImage>, val text: String, val error: String?, val cancelled: Boolean = false, val model: String = "")

    companion object {
        /** 위에서부터 차례로 써 본다. 지금은 Lite 하나만 쓴다 */
        val MODELS = listOf(
            "gemini-3.1-flash-lite-image"   // Nano Banana 2 Lite (1K 전용, 가장 빠름) — 유료 모델로 넘어가지 않도록 이것만 쓴다
        )

        /** 바탕 사진으로 보낼 수 있는 최대 장수 */
        const val MAX_REFS = 4

        /** 만든 그림을 갤러리(사진 > Evergreen)에 저장한다. 저장한 이름을 돌려주고, 못 하면 null */
        fun saveToGallery(ctx: Context, img: PageImage): String? {
            return try {
                val bytes = Base64.decode(img.base64, Base64.DEFAULT)
                val ext = when {
                    img.mime.contains("jpeg") || img.mime.contains("jpg") -> "jpg"
                    img.mime.contains("webp") -> "webp"
                    else -> "png"
                }
                val name = "evergreen_ai_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + "." + ext
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, img.mime)
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Evergreen")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return null
                    cv.clear()
                    cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                    ctx.contentResolver.update(uri, cv, null, null)
                } else {
                    // 안드로이드 9 이하: 권한 없이 쓸 수 있는 앱 전용 사진 폴더에 저장한다
                    val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Evergreen").apply { mkdirs() }
                    File(dir, name).writeBytes(bytes)
                }
                name
            } catch (e: Exception) {
                null
            }
        }
    }

    @Volatile
    private var conn: HttpURLConnection? = null

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
        try {
            conn?.disconnect()
        } catch (e: Exception) {
            // 이미 끝난 연결
        }
    }

    /** [refs] 는 바탕이 될 사진(고쳐 그리기·참고용). 사진이 아닌 것은 걸러서 쓴다 */
    fun generate(startKey: String, prompt: String, refs: List<PageImage>): Result {
        cancelled = false
        val photos = refs.filter { it.mime.startsWith("image/") }.take(MAX_REFS)
        var key = startKey
        val triedKeys = mutableSetOf<String>()
        var lastError = "이미지를 만들지 못했어요"
        for (model in MODELS) {
            triedKeys.clear()
            var busy = 0
            while (true) {
                if (cancelled) return Result(emptyList(), "", null, cancelled = true)
                GeminiKeyPool.used(key)
                val r = request(key, model, prompt, photos)
                if (cancelled) return Result(emptyList(), "", null, cancelled = true)
                if (r.error == null) return Result(r.images, r.text, null, model = model)
                lastError = r.error
                val code = r.code
                // 한도가 찼거나 키가 거부됐다: 다른 키로 같은 모델에 다시
                val quota = code == 429 && GeminiKeyPool.isQuota(r.body)
                if (quota || code == 401 || code == 403) {
                    val bad = !quota
                    GeminiKeyPool.onLimit(key, model, r.body, bad)
                    triedKeys.add(key)
                    val alt = GeminiKeyPool.alternative(triedKeys, model)
                    if (alt != null) {
                        GeminiKeyPool.notifySwitch(key, alt, bad)
                        key = alt
                        continue
                    }
                    break   // 이 모델은 어느 키로도 안 된다 → 다음 모델
                }
                // 서버가 붐빈다: 잠깐 뒤 같은 모델로 한 번 더
                if ((code in 500..599 || code == 429) && busy < 1) {
                    busy++
                    try {
                        Thread.sleep(1500)
                    } catch (e: InterruptedException) {
                        return Result(emptyList(), "", null, cancelled = true)
                    }
                    continue
                }
                // 안전 정책으로 막힌 건 다른 모델도 같으니 여기서 멈춘다
                if (r.blocked) return Result(emptyList(), "", r.error, model = model)
                break   // 모델이 없거나(404) 그림을 못 만든다(400) → 다음 모델
            }
        }
        return Result(emptyList(), "", lastError)
    }

    private class Raw(
        val images: List<PageImage>,
        val text: String,
        val error: String?,
        val code: Int = 0,
        val body: String = "",
        val blocked: Boolean = false
    )

    private fun request(apiKey: String, model: String, prompt: String, photos: List<PageImage>): Raw {
        var c: HttpURLConnection? = null
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            c = url.openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 180000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)

            val parts = JSONArray()
            for (p in photos) {
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", p.mime).put("data", p.base64)))
            }
            parts.put(JSONObject().put("text", prompt))
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = try {
                    c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                } ?: ""
                return Raw(emptyList(), "", describeError(code, err), code, err)
            }
            val raw = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val o = JSONObject(raw)
            val blockReason = o.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            if (blockReason.isNotEmpty()) {
                return Raw(emptyList(), "", "요청이 안전 정책에 의해 차단되었어요 ($blockReason).\n설명을 바꿔서 다시 시도해 보세요", 200, raw, blocked = true)
            }
            val cand = o.optJSONArray("candidates")?.optJSONObject(0)
            val finish = cand?.optString("finishReason").orEmpty()
            val ps = cand?.optJSONObject("content")?.optJSONArray("parts")
            val images = ArrayList<PageImage>()
            val text = StringBuilder()
            if (ps != null) {
                for (i in 0 until ps.length()) {
                    val p = ps.optJSONObject(i) ?: continue
                    val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    if (inl != null) {
                        val data = inl.optString("data")
                        if (data.isNotEmpty()) {
                            val mime = inl.optString("mimeType").ifEmpty { inl.optString("mime_type") }.ifEmpty { "image/png" }
                            images.add(PageImage(mime, data, "[AI가 만든 그림]"))
                        }
                        continue
                    }
                    if (p.optBoolean("thought", false)) continue
                    val t = p.optString("text", "")
                    if (t.isNotBlank()) text.append(t.trim()).append('\n')
                }
            }
            if (images.isEmpty()) {
                val safety = finish == "IMAGE_SAFETY" || finish == "PROHIBITED_CONTENT" || finish == "SAFETY" || finish == "IMAGE_PROHIBITED_CONTENT"
                val why = text.toString().trim()
                val msg = when {
                    safety -> "안전 정책 때문에 이 그림은 만들 수 없어요 ($finish).\n설명을 바꿔서 다시 시도해 보세요"
                    why.isNotEmpty() -> why
                    finish.isNotEmpty() && finish != "STOP" -> "그림을 만들지 못했어요 ($finish)"
                    else -> "그림을 만들지 못했어요. 설명을 조금 더 구체적으로 적어 보세요"
                }
                // 400 으로 올려 두면 다른 모델로 다시 시도해 본다 (안전 정책이면 멈춘다)
                return Raw(emptyList(), "", msg, 400, raw, blocked = safety)
            }
            return Raw(images, text.toString().trim(), null)
        } catch (e: Exception) {
            return if (cancelled) Raw(emptyList(), "", "중지했어요", -1)
            else Raw(emptyList(), "", "네트워크 오류로 이미지를 만들지 못했어요. 연결을 확인하고 다시 시도해 주세요", 599, e.message ?: "")
        } catch (e: OutOfMemoryError) {
            return Raw(emptyList(), "", "그림이 너무 커서 처리하지 못했어요", -2)
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
                // 무시
            }
        }
    }

    private fun describeError(code: Int, body: String?): String {
        val msg = try {
            JSONObject(body ?: "").optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        val head = when (code) {
            400 -> "이 모델로는 그림을 만들 수 없거나 요청이 올바르지 않아요"
            401, 403 -> "API 키가 거부되었어요. 키와 사용 권한을 확인해 주세요 (이미지 모델은 결제가 연결된 키에서만 될 수 있어요)"
            404 -> "이미지 모델을 찾을 수 없어요"
            429 -> if (GeminiKeyPool.isQuota(body)) "이미지 만들기 한도를 넘었어요. 잠시 후 다시 시도해 주세요 (무료 키는 이미지 한도가 없을 수 있어요)"
            else "Gemini 서버가 지금 붐벼요. 잠시 후 다시 시도해 주세요"
            in 500..599 -> "Gemini 서버에 문제가 있어요. 잠시 후 다시 시도해 주세요"
            else -> "오류가 났어요 ($code)"
        }
        return if (msg.isNullOrBlank() || !msg.any { it in '가'..'힣' }) head else "$head\n$msg"
    }
}
