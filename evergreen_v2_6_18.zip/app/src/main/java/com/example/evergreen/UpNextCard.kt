package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * 영상이 끝났을 때 뜨는 '다음 영상' 카드 (유튜브의 끝 화면처럼).
 * - 첫 번째 영상은 큰 카드(썸네일·제목·채널·길이)로, 나머지는 아래 가로 줄로 보여 준다.
 * - 자동 재생이 켜져 있으면 큰 카드 위에 카운트다운 고리가 돌고, 끝나면 페이지가 알아서 다음 영상으로 넘어간다 (취소 가능).
 * - 항목이 없는 사이트에서는 '다시 보기' / '다음 영상' 버튼만 보여 준다.
 */
class UpNextCard(ctx: Context) : FrameLayout(ctx) {

    class Item(val title: String, val author: String, val duration: String, val thumb: String)

    var onReplay: () -> Unit = {}
    var onNext: () -> Unit = {}
    var onPick: (Int) -> Unit = {}
    var onCancelAuto: () -> Unit = {}

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val accent = ctx.getColor(R.color.ev_accent)
    private val ui = Handler(Looper.getMainLooper())

    private val content = LinearLayout(ctx)
    private val header = TextView(ctx)
    private val ring = CountdownRing(ctx, accent)
    private val primaryRow = LinearLayout(ctx)
    private val btnRow = LinearLayout(ctx)
    private val moreRow = LinearLayout(ctx)
    private val moreScroll = HorizontalScrollView(ctx)

    private var autoEndAt = 0L
    private var autoTotalMs = 0L
    private var autoCancelled = false
    private var sig = ""

    companion object {
        private val exec = Executors.newFixedThreadPool(3)
        private val cache = object : android.util.LruCache<String, Bitmap>(24) {}
    }

    init {
        visibility = View.GONE
        isClickable = true // 뒤쪽 영상으로 탭이 새지 않게 막는다
        setBackgroundColor(0xE6000000.toInt())

        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_HORIZONTAL
        content.setPadding(dp(16), dp(56), dp(16), dp(16))

        header.apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            text = "다음 영상"
        }
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        primaryRow.orientation = LinearLayout.HORIZONTAL
        primaryRow.gravity = Gravity.CENTER_VERTICAL
        content.addView(primaryRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.gravity = Gravity.CENTER
        content.addView(btnRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        moreRow.orientation = LinearLayout.HORIZONTAL
        moreScroll.isHorizontalScrollBarEnabled = false
        moreScroll.addView(moreRow)
        content.addView(moreScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })

        addView(content, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
    }

    private fun chip(label: String, primary: Boolean, onClick: () -> Unit) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(18), 0, dp(18), 0)
        background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            if (primary) setColor(accent) else { setColor(0x1FFFFFFF); setStroke(dp(1), 0x33FFFFFF) }
        }
        setOnClickListener { onClick() }
        Motion.barButton(this, "chip")
    }

    private fun thumbView(url: String, w: Int, h: Int): ImageView {
        val iv = ImageView(context)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xFF2A2A2A.toInt()) }
        iv.clipToOutline = true
        iv.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat()) }
        }
        if (url.isNotBlank()) {
            val c = cache.get(url)
            if (c != null) iv.setImageBitmap(c) else {
                exec.execute {
                    val bmp = try {
                        PlayerHttp.client.newCall(okhttp3.Request.Builder().url(url).build()).execute().use { r ->
                            val b = r.body
                            if (!r.isSuccessful || b == null) null else {
                                val bytes = b.bytes()
                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            }
                        }
                    } catch (e: Throwable) { null }
                    if (bmp != null) {
                        cache.put(url, bmp)
                        ui.post { iv.setImageBitmap(bmp) }
                    }
                }
            }
        }
        return iv
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean, lines: Int) = TextView(context).apply {
        this.text = text
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        maxLines = lines
        ellipsize = TextUtils.TruncateAt.END
    }

    /**
     * 카드를 채운다. items 가 비면 버튼만 보인다.
     * autoSec > 0 이면 첫 항목에 카운트다운을 붙인다 (페이지의 자동 재생 대기 시간과 맞춘다).
     */
    fun show(items: List<Item>, autoSec: Int, hasNext: Boolean) {
        val s = items.joinToString("|") { it.title + it.thumb } + "#" + autoSec + hasNext
        if (visibility == View.VISIBLE && s == sig) return
        val keepAuto = visibility == View.VISIBLE && autoCancelled
        sig = s
        autoCancelled = keepAuto
        ui.removeCallbacks(tickRun)
        primaryRow.removeAllViews()
        btnRow.removeAllViews()
        moreRow.removeAllViews()

        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val first = items.firstOrNull()
        if (first != null) {
            header.text = if (autoSec > 0 && !autoCancelled) "다음 영상 자동 재생" else "다음 영상"
            val w = dp(if (land) 220 else 150)
            val h = w * 9 / 16
            val frame = FrameLayout(context)
            frame.addView(thumbView(first.thumb, w, h), LayoutParams(w, h))
            if (first.duration.isNotBlank()) {
                frame.addView(label(first.duration, 11f, Color.WHITE, true, 1).apply {
                    setPadding(dp(5), dp(1), dp(5), dp(1))
                    background = GradientDrawable().apply { cornerRadius = dp(4).toFloat(); setColor(0xCC000000.toInt()) }
                }, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(6), dp(6)) })
            }
            if (autoSec > 0 && !autoCancelled) {
                frame.addView(ring, LayoutParams(dp(44), dp(44), Gravity.CENTER))
                ring.visibility = View.VISIBLE
            } else ring.visibility = View.GONE
            frame.setOnClickListener { onPick(0) }
            primaryRow.addView(frame, LinearLayout.LayoutParams(w, h))
            val info = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(first.title, 15f, Color.WHITE, true, 3))
            if (first.author.isNotBlank()) info.addView(label(first.author, 12f, 0xB3FFFFFF.toInt(), false, 1), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
            primaryRow.addView(info, LinearLayout.LayoutParams(dp(if (land) 260 else 170), ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(12) })
        } else {
            header.text = "재생이 끝났어요"
            ring.visibility = View.GONE
        }

        btnRow.addView(chip("↺  다시 보기", false) { cancelTimer(); onReplay() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        if (autoSec > 0 && !autoCancelled && first != null) {
            btnRow.addView(chip("취소", false) { autoCancelled = true; cancelTimer(); ring.visibility = View.GONE; header.text = "다음 영상"; onCancelAuto() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginStart = dp(8) })
        }
        if (hasNext || first != null) {
            btnRow.addView(chip("다음 영상 ▶", true) { cancelTimer(); if (first != null) onPick(0) else onNext() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginStart = dp(8) })
        }

        if (items.size > 1) {
            moreScroll.visibility = View.VISIBLE
            val cw = dp(if (land) 150 else 120)
            for (i in 1 until minOf(items.size, 8)) {
                val it = items[i]
                val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
                col.addView(thumbView(it.thumb, cw, cw * 9 / 16), LinearLayout.LayoutParams(cw, cw * 9 / 16))
                col.addView(label(it.title, 11f, Color.WHITE, false, 2), LinearLayout.LayoutParams(cw, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
                col.setOnClickListener { cancelTimer(); onPick(i) }
                moreRow.addView(col, LinearLayout.LayoutParams(cw, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(10) })
            }
        } else moreScroll.visibility = View.GONE

        if (visibility != View.VISIBLE) {
            alpha = 0f
            visibility = View.VISIBLE
            animate().alpha(1f).setDuration(220).start()
        }
        if (first != null && autoSec > 0 && !autoCancelled) {
            autoTotalMs = autoSec * 1000L
            if (autoEndAt == 0L) autoEndAt = SystemClock.uptimeMillis() + autoTotalMs
            ui.post(tickRun)
        }
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (visibility != View.VISIBLE || autoEndAt == 0L) return
            val left = autoEndAt - SystemClock.uptimeMillis()
            ring.fraction = if (autoTotalMs > 0) (left.toFloat() / autoTotalMs).coerceIn(0f, 1f) else 0f
            if (left > 0) ui.postDelayed(this, 50)
        }
    }

    private fun cancelTimer() {
        ui.removeCallbacks(tickRun)
    }

    fun hideCard() {
        cancelTimer()
        autoEndAt = 0L
        autoCancelled = false
        sig = ""
        if (visibility == View.VISIBLE) {
            animate().cancel()
            visibility = View.GONE
        }
    }

    fun isShowing() = visibility == View.VISIBLE

    override fun onDetachedFromWindow() {
        cancelTimer()
        super.onDetachedFromWindow()
    }

    /** 남은 시간을 보여 주는 고리 */
    private class CountdownRing(ctx: Context, private val color: Int) : View(ctx) {
        var fraction = 1f
            set(v) { field = v; invalidate() }
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = 0x99000000.toInt() }
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; this.color = 0x55FFFFFF; strokeWidth = 3f * resources.displayMetrics.density }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; this.color = color; strokeWidth = 3f * resources.displayMetrics.density; strokeCap = Paint.Cap.ROUND }
        private val tri = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = Color.WHITE }
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val p = arc.strokeWidth
            c.drawCircle(w / 2, h / 2, w / 2, bg)
            val r = RectF(p, p, w - p, h - p)
            c.drawOval(r, track)
            c.drawArc(r, -90f, 360f * fraction, false, arc)
            val path = android.graphics.Path()
            path.moveTo(w * 0.42f, h * 0.34f); path.lineTo(w * 0.42f, h * 0.66f); path.lineTo(w * 0.68f, h * 0.5f); path.close()
            c.drawPath(path, tri)
        }
    }
}
