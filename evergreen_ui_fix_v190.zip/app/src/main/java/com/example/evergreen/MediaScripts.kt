package com.example.evergreen

/** 페이지 안에서 돌아가는 스크립트 모음 (재생 상태 알림 / 일시정지 / PiP 용 화면 꾸미기) */
object MediaScripts {

    /**
     * 모든 프레임에서 문서 시작 시점에 실행된다.
     * - 영상/소리 재생 상태가 바뀌면 EvMedia.state() 로 앱에 알린다.
     * - 백그라운드 재생이 켜져 있으면 페이지가 "숨겨짐"을 감지해 스스로 멈추지 못하게 가시성 API 를 가린다.
     * - postMessage({__ev:'pause'}) 를 받으면 (iframe 포함) 재생 중인 미디어를 멈춘다.
     * - 탭 음소거: EvMedia.muted() 가 true 인 동안 모든 video/audio 와 WebAudio 출력을 끈다.
     *   postMessage({__ev:'mute'}) 를 받으면 (iframe 포함) 상태를 다시 읽어 적용한다.
     */
    const val INJECT = """
(function(){
 if(window.__evMedia) return; window.__evMedia=1;
 var fid=Math.random().toString(36).slice(2);
 function bg(){try{return EvMedia.bg()}catch(e){return false}}
 try{
  var dh=Object.getOwnPropertyDescriptor(Document.prototype,'hidden');
  var dv=Object.getOwnPropertyDescriptor(Document.prototype,'visibilityState');
  Object.defineProperty(document,'hidden',{configurable:true,get:function(){return bg()?false:dh.get.call(document)}});
  Object.defineProperty(document,'visibilityState',{configurable:true,get:function(){return bg()?'visible':dv.get.call(document)}});
  var stop=function(e){if(bg())e.stopImmediatePropagation()};
  window.addEventListener('visibilitychange',stop,true);
  document.addEventListener('visibilitychange',stop,true);
 }catch(e){}

 /* ── 탭 음소거: 이 탭이 음소거면 video/audio 를 muted 로, WebAudio 는 게인 0 으로 만든다 ── */
 var muteOn=false,gains=[];
 function mu(){try{return !!EvMedia.muted()}catch(e){return false}}
 function applyMute(){
  var m=document.querySelectorAll('video,audio');
  for(var i=0;i<m.length;i++){var x=m[i];
   try{
    if(muteOn){ if(!x.__evM){x.__evM=1;x.__evWas=x.muted} if(!x.muted)x.muted=true }
    else if(x.__evM){x.__evM=0;x.muted=!!x.__evWas}
   }catch(e){}
  }
  for(var g=0;g<gains.length;g++){try{gains[g].gain.value=muteOn?0:1}catch(e){}}
 }
 function syncMute(){var n=mu(); if(n!==muteOn){muteOn=n} applyMute()}
 try{
  var AN=window.AudioNode&&AudioNode.prototype,oc=AN&&AN.connect,od=AN&&AN.disconnect;
  if(oc){
   AN.connect=function(d){
    var a=arguments;
    if(window.AudioDestinationNode&&d instanceof AudioDestinationNode){
     var c=this.context;
     if(!c.__evG){var gn=c.createGain();oc.call(gn,c.destination);gn.gain.value=muteOn?0:1;c.__evG=gn;gains.push(gn)}
     a=[].slice.call(arguments);a[0]=c.__evG;
     oc.apply(this,a);return d;
    }
    return oc.apply(this,a);
   };
   AN.disconnect=function(d){
    var a=arguments;
    if(window.AudioDestinationNode&&d instanceof AudioDestinationNode&&d.context.__evG){
     a=[].slice.call(arguments);a[0]=d.context.__evG;
    }
    return od.apply(this,a);
   };
  }
 }catch(e){}
 muteOn=mu();
 ['play','playing','loadeddata','volumechange'].forEach(function(n){
  document.addEventListener(n,function(){if(muteOn)applyMute()},true);
 });
 setInterval(function(){if(muteOn)applyMute()},1200);
 var last='';
 function chk(){
  var m=document.querySelectorAll('video,audio'),p=false,v=false,w=0,h=0;
  for(var i=0;i<m.length;i++){var x=m[i];
   if(!x.paused&&!x.ended&&x.readyState>2){p=true;
    if(x.tagName=='VIDEO'&&x.videoWidth>0&&!v){v=true;w=x.videoWidth;h=x.videoHeight}}}
  var k=p+','+v+','+w+','+h;
  if(k===last)return; last=k;
  try{EvMedia.state(fid,p,v,w,h)}catch(e){}
 }
 ['play','playing','pause','ended','emptied','loadeddata'].forEach(function(n){
  document.addEventListener(n,function(){setTimeout(chk,60)},true);
 });
 setInterval(function(){if(document.querySelector('video,audio'))chk()},2500);
 /* ── 메뉴의 미디어 플레이어용: 진행 상황 보고 / 조작 명령 받기 ── */
 var act=null;
 function pick(){
  var m=document.querySelectorAll('video,audio');
  for(var i=0;i<m.length;i++){var x=m[i]; if(!x.paused&&!x.ended&&x.readyState>2)return x}
  return (act&&document.contains(act))?act:null;
 }
 function prog(){
  var x=pick(); if(!x)return;
  var d=x.duration;
  try{EvMedia.progress(fid,x.currentTime||0,(isFinite(d)&&d>0)?d:-1,!x.paused&&!x.ended)}catch(e){}
 }
 ['play','playing'].forEach(function(n){
  document.addEventListener(n,function(e){
   var t=e.target; if(t&&(t.tagName=='VIDEO'||t.tagName=='AUDIO')){act=t;setTimeout(prog,60)}
  },true);
 });
 ['pause','ended','seeked'].forEach(function(n){
  document.addEventListener(n,function(){setTimeout(prog,60)},true);
 });
 setInterval(function(){var x=pick(); if(x&&!x.paused&&!x.ended)prog()},1000);
 window.addEventListener('pagehide',function(){last='';try{EvMedia.state(fid,false,false,0,0);EvMedia.gone(fid)}catch(e){}});
 window.addEventListener('message',function(e){
  var d=e.data; if(!d)return;
  if(d.__ev==='cmd'){
   if(d.f===fid){
    var x=pick();
    if(x){
     try{
      if(d.a==='toggle'){ if(x.paused||x.ended){var pr=x.play(); if(pr&&pr.catch)pr.catch(function(){})} else x.pause() }
      else if(d.a==='seek'){ x.currentTime=Math.max(0,d.v) }
      else if(d.a==='skip'){ x.currentTime=Math.max(0,(x.currentTime||0)+d.v) }
     }catch(err){}
     setTimeout(prog,120);
    }
   }
   var f3=document.querySelectorAll('iframe');
   for(var q=0;q<f3.length;q++){try{f3[q].contentWindow.postMessage(d,'*')}catch(x2){}}
   return;
  }
  if(d.__ev==='mute'){
   syncMute();
   var f2=document.querySelectorAll('iframe');
   for(var k=0;k<f2.length;k++){try{f2[k].contentWindow.postMessage(d,'*')}catch(x){}}
   return;
  }
  if(d.__ev!=='pause')return;
  var m=document.querySelectorAll('video,audio');
  for(var i=0;i<m.length;i++){try{m[i].pause()}catch(x){}}
  var f=document.querySelectorAll('iframe');
  for(var j=0;j<f.length;j++){try{f[j].contentWindow.postMessage(d,'*')}catch(x){}}
 },false);
})();
"""

    /**
     * 내장 플레이어로 넘길 영상 주소를 찾는다 (blob/data 는 제외). 재생 중인 것이 앞에 온다.
     * video/audio/source 태그뿐 아니라 같은 출처 iframe 안, data-src 같은 지연 로딩 속성, og:video 메타,
     * JSON-LD(contentUrl), embed/object, 영상 파일로 연결된 링크, 그리고 페이지가 실제로 불러온 요청 기록(performance)까지 훑는다.
     */
    const val FIND_MEDIA = """
(function(){
 var out=[],seen={},subs=[],sseen={};
 var SRE=/\.(vtt|srt|ass|ssa|ttml|dfxp)(\?|#|$)/i;
 var RE=/\.(m3u8|mpd|mp4|webm|m4v|mov|mkv|avi|flv|3gp|ogv|wmv|mpe?g)(\?|#|$)|\.m3u8|\.mpd|\.ism\/manifest/i;
 function add(u,t,p){
  if(!u||typeof u!=='string'||u.indexOf('blob:')==0||u.indexOf('data:')==0) return;
  try{u=new URL(u,location.href).href}catch(e){return}
  if(seen[u]) return; seen[u]=1; out.push({u:u,t:t||0,p:!!p});
 }
 var docs=[document];
 try{
  var fr=document.querySelectorAll('iframe');
  for(var f=0;f<fr.length;f++){try{var d=fr[f].contentDocument; if(d&&d.documentElement) docs.push(d)}catch(e){}}
 }catch(e){}
 docs.forEach(function(doc){
  var base=doc.location&&doc.location.href||location.href;
  function addd(u,t,p){ if(!u||typeof u!=='string') return; try{u=new URL(u,base).href}catch(e){return} add(u,t,p) }
  var ms=doc.querySelectorAll('video,audio');
  for(var i=0;i<ms.length;i++){
   var m=ms[i],p=!m.paused&&!m.ended;
   addd(m.currentSrc,m.currentTime,p); addd(m.getAttribute('src'),m.currentTime,p);
   ['data-src','data-url','data-video','data-hls','data-mp4','data-stream'].forEach(function(a){addd(m.getAttribute(a),m.currentTime,p)});
   var ss=m.querySelectorAll('source');
   for(var j=0;j<ss.length;j++){addd(ss[j].src,m.currentTime,p); addd(ss[j].getAttribute('data-src'),m.currentTime,p)}
  }
  var tk=doc.querySelectorAll('video track[src],audio track[src]');
  for(var z=0;z<tk.length&&subs.length<8;z++){
   var tt=tk[z],kd=(tt.kind||'subtitles').toLowerCase();
   if(kd!=='subtitles'&&kd!=='captions')continue;
   try{var su=new URL(tt.getAttribute('src'),base).href;
    if(!sseen[su]&&/^https?:/i.test(su)){sseen[su]=1;subs.push({u:su,l:tt.label||'',g:tt.srclang||''})}}catch(e){}
  }
  var ds=doc.querySelectorAll('source[src],source[data-src],embed[src],object[data]');
  for(var k=0;k<ds.length;k++){var x=ds[k],v=x.getAttribute('src')||x.getAttribute('data-src')||x.getAttribute('data'); if(v&&RE.test(v)) addd(v,0,false)}
  var mt=doc.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
  for(var q=0;q<mt.length;q++){var c=mt[q].getAttribute('content'); if(c&&RE.test(c)) addd(c,0,false)}
  var ld=doc.querySelectorAll('script[type="application/ld+json"]');
  for(var l=0;l<ld.length;l++){
   try{
    (function walk(o){
     if(!o||typeof o!=='object') return;
     if(Array.isArray(o)){o.forEach(walk);return}
     if(typeof o.contentUrl==='string') addd(o.contentUrl,0,false);
     for(var key in o) if(typeof o[key]==='object') walk(o[key]);
    })(JSON.parse(ld[l].textContent));
   }catch(e){}
  }
  var as=doc.querySelectorAll('a[href]');
  for(var n=0;n<as.length&&n<400;n++){var h=as[n].getAttribute('href'); if(h&&RE.test(h)) addd(h,0,false)}
  try{
   var es=(doc.defaultView||window).performance.getEntriesByType('resource');
   for(var r=0;r<es.length;r++){
    if(RE.test(es[r].name)) add(es[r].name,0,false);
    else if(SRE.test(es[r].name)&&subs.length<8&&!sseen[es[r].name]&&/^https?:/i.test(es[r].name)){sseen[es[r].name]=1;subs.push({u:es[r].name,l:'',g:''})}
   }
  }catch(e){}
 });
 out.sort(function(a,b){return (b.p?1:0)-(a.p?1:0)});
 return JSON.stringify({title:document.title,items:out,subs:subs});
})();
"""

    const val PAUSE_ALL = "window.postMessage({__ev:'pause'},'*');"

    /** 탭의 음소거 상태가 바뀌었음을 모든 프레임에 알린다 (각 프레임이 EvMedia.muted() 를 다시 읽는다) */
    const val MUTE_SYNC = "window.postMessage({__ev:'mute'},'*');"

    /** 작은 창(PiP)에서 재생 중인 동영상만 화면 가득 보이게 한다. */
    const val PIP_ON = """
(function(){
 var vs=[].slice.call(document.querySelectorAll('video'));
 if(!vs.length) return '';
 var v=null;
 for(var i=0;i<vs.length;i++){if(!vs[i].paused&&!vs[i].ended){v=vs[i];break}}
 if(!v){vs.sort(function(a,b){return b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight});v=vs[0]}
 var st=document.getElementById('__ev_pip_style');
 if(!st){st=document.createElement('style');st.id='__ev_pip_style';document.documentElement.appendChild(st)}
 st.textContent='html,body{overflow:hidden!important;background:#000!important}'
  +'body *{visibility:hidden!important}'
  +'video.__ev_pip{visibility:visible!important;position:fixed!important;top:0!important;left:0!important;'
  +'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;'
  +'z-index:2147483647!important;background:#000!important;object-fit:contain!important;transform:none!important}';
 v.classList.add('__ev_pip');
 return 'ok';
})();
"""

    const val PIP_OFF = """
(function(){
 var st=document.getElementById('__ev_pip_style'); if(st) st.remove();
 var m=document.querySelectorAll('video.__ev_pip');
 for(var i=0;i<m.length;i++) m[i].classList.remove('__ev_pip');
})();
"""

    /**
     * 당겨서 새로고침 오작동 방지용. 모든 프레임에서 문서 시작 시점에 실행된다.
     * 페이지 안의 '안쪽 스크롤 영역'(채팅/피드 등 body 가 아닌 요소가 스크롤되는 사이트)은
     * WebView 의 scrollY 가 늘 0 이라서 앱이 맨 위로 착각한다. 그래서 손가락이 닿은 자리의 조상 중
     * 이미 스크롤된(scrollTop>0) 요소가 있거나, 터치 중 안쪽 요소가 스크롤되거나,
     * 페이지가 touchmove 를 직접 처리(preventDefault)하면 EvMedia.pullInner(true) 로 알린다.
     */
    const val PULL_GUARD = """
(function(){
 if(window.__evPull) return; window.__evPull=1;
 var touching=false, sent=false;
 function send(v){ if(sent===v) return; sent=v; try{EvMedia.pullInner(v)}catch(e){} }
 function scrolledAncestor(t){
  try{
   var e=t;
   while(e){
    if(e.nodeType===1 && e.scrollTop>0){
     var o=getComputedStyle(e).overflowY;
     if(o==='auto'||o==='scroll'||o==='overlay'||e===document.scrollingElement||e===document.body||e===document.documentElement) return true;
    }
    e=e.parentNode||e.host||null;
   }
  }catch(x){}
  return false;
 }
 window.addEventListener('touchstart',function(e){
  touching=true; sent=null;
  var t=(e.composedPath&&e.composedPath()[0])||e.target;
  send(scrolledAncestor(t));
 },{capture:true,passive:true});
 function end(){touching=false}
 window.addEventListener('touchend',end,{capture:true,passive:true});
 window.addEventListener('touchcancel',end,{capture:true,passive:true});
 window.addEventListener('scroll',function(e){
  if(!touching) return;
  var t=e.target;
  if(t && t!==document && t.scrollTop>0) send(true);
 },true);
 window.addEventListener('touchmove',function(e){
  if(touching && e.defaultPrevented) send(true);
 },{passive:true});
})();
"""
}
