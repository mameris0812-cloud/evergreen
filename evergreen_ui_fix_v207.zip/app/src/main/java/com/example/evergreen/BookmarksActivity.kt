package com.example.evergreen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * 북마크 목록.
 * - 위쪽 칩으로 폴더를 만들고(＋ 폴더), 칩을 길게 누르면 이름 변경 / 삭제
 * - 북마크를 누르면 현재 탭에서 열기, ⋮ 메뉴(또는 길게 누르기)로 새 탭 열기 / 수정 / 폴더로 이동 / 삭제
 * - 고른 주소는 결과(EXTRA_URL)로 MainActivity 에 돌려준다.
 */
class BookmarksActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var chipRow: LinearLayout
    private val adapter = RowAdapter()
    private lateinit var select: ListSelect<Long>

    private val shown = ArrayList<Bookmark>()
    private var folderNames: Map<Long, String> = emptyMap()
    private var selected = ListUi.ALL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        ListUi.fitSystemBars(this)
        ListUi.applyTabletPopup(this)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "북마크"
        findViewById<View>(R.id.btnListBack).setOnClickListener { finish() }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        chipRow = findViewById(R.id.chipRow)
        listView.adapter = adapter
        select = ListSelect(
            this, listView, findViewById(R.id.btnListAction),
            visibleKeys = { shown.map { it.id } },
            onChanged = { adapter.notifyDataSetChanged() },
            onDelete = { ids -> confirmDeleteMany(ids) }
        )

        refreshView()
    }

    private fun confirmDeleteMany(ids: Set<Long>) {
        val n = ids.size
        Popup.confirm(this, "북마크 ${n}개 삭제", "선택한 북마크 ${n}개를 삭제할까요?", "삭제", danger = true) {
            prefs.removeBookmarks(ids)
            select.finishDelete()
            refreshView()
            ListUi.toast(this, "${n}개를 삭제했습니다")
        }
    }

    private fun refreshView() {
        val all = prefs.bookmarks()
        val folders = prefs.folders(Prefs.KIND_BM)
        folderNames = folders.associate { it.id to it.name }
        if (selected != ListUi.ALL && folders.none { it.id == selected }) selected = ListUi.ALL

        val entries = ArrayList<ListUi.ChipEntry>()
        entries.add(ListUi.ChipEntry(ListUi.ALL, "전체 (${all.size})"))
        folders.forEach { f ->
            entries.add(ListUi.ChipEntry(f.id, "${f.name} (${all.count { it.folderId == f.id }})"))
        }
        ListUi.renderChips(
            chipRow, entries, selected,
            onSelect = {
                selected = it
                select.exit()
                refreshView()
            },
            onLongPress = { id ->
                folders.firstOrNull { it.id == id }?.let { f ->
                    ListUi.showFolderMenu(this, prefs, Prefs.KIND_BM, f) { refreshView() }
                }
            },
            onAdd = {
                ListUi.createFolder(this, prefs, Prefs.KIND_BM) {
                    selected = it.id
                    refreshView()
                }
            }
        )

        shown.clear()
        shown.addAll(if (selected == ListUi.ALL) all else all.filter { it.folderId == selected })
        select.retain()
        adapter.notifyDataSetChanged()

        if (shown.isEmpty()) {
            emptyView.text =
                if (selected == ListUi.ALL) "북마크가 없습니다\n웹페이지에서 메뉴 → '북마크에 추가' 를 눌러 보세요"
                else "이 폴더는 비어 있습니다\n북마크의 ⋮ 메뉴 → '폴더로 이동' 으로 옮겨 보세요"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = shown[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)
            val b = shown[position]

            select.bindRow(v, b.id, R.drawable.ic_bookmark)
            v.findViewById<ProgressBar>(R.id.rowProgress).visibility = View.GONE
            v.findViewById<TextView>(R.id.rowTitle).text = ListUi.displayTitle(b.title, b.url)
            val folder = folderNames[b.folderId]
            v.findViewById<TextView>(R.id.rowSub).text =
                if (folder != null && selected == ListUi.ALL) "${b.url} · $folder" else b.url

            v.setOnClickListener { if (select.active) select.toggle(b.id) else openUrl(b.url, newTab = false) }
            v.setOnLongClickListener {
                if (select.active) select.toggle(b.id) else select.enter(b.id)
                true
            }
            v.findViewById<ImageButton>(R.id.rowMore).setOnClickListener { showMenu(b) }
            return v
        }
    }

    private fun openUrl(url: String, newTab: Boolean) {
        setResult(
            RESULT_OK,
            Intent().putExtra(EXTRA_URL, url).putExtra(EXTRA_NEW_TAB, newTab)
        )
        finish()
    }

    private fun showMenu(b: Bookmark) {
        Popup.menu(
            this,
            title = ListUi.displayTitle(b.title, b.url),
            subtitle = b.url,
            headerIcon = R.drawable.ic_bookmark,
            items = listOf(
                Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { openUrl(b.url, newTab = true) },
                Popup.Item(R.drawable.ic_edit, "수정") {
                    ListUi.showBookmarkEditor(this, prefs, b, b.url, b.title) { msg ->
                        ListUi.toast(this, msg)
                        refreshView()
                    }
                },
                Popup.Item(R.drawable.ic_folder, "폴더로 이동") {
                    ListUi.pickFolder(this, prefs, Prefs.KIND_BM, b.folderId) { folderId ->
                        prefs.moveBookmark(b.id, folderId)
                        refreshView()
                        val name = prefs.folders(Prefs.KIND_BM).firstOrNull { it.id == folderId }?.name
                        ListUi.toast(this, if (name == null) "폴더에서 뺐습니다" else "'$name' 폴더로 옮겼습니다")
                    }
                },
                Popup.Item(R.drawable.ic_copy, "주소 복사") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("url", b.url))
                    ListUi.toast(this, "복사했습니다")
                },
                Popup.Item(R.drawable.ic_delete, "삭제", danger = true) {
                    Popup.confirm(
                        this, "북마크를 삭제할까요?",
                        "'${ListUi.displayTitle(b.title, b.url)}'", "삭제", danger = true
                    ) {
                        prefs.removeBookmark(b.id)
                        refreshView()
                    }
                }
            )
        )
    }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_NEW_TAB = "newTab"
    }
}
