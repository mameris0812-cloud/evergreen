package com.example.evergreen

import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import com.google.android.material.color.MaterialColors

/**
 * 북마크 · 방문 기록 · 다운로드 목록이 함께 쓰는 '여러 개 선택해서 한 번에 지우기'.
 * - 제목줄의 '선택' 또는 항목을 길게 누르면 선택 모드. 항목을 누르면 체크가 켜지고 꺼진다.
 * - 선택 모드에서는 목록 아래에 [취소 · n개 선택 · 전체 선택 · 삭제] 막대가 떠오른다.
 * - 뒤로 가기는 먼저 선택 모드부터 끈다.
 * 선택은 항목의 키(북마크 id / 주소 / 다운로드 키)로 기억한다.
 */
class ListSelect<K : Any>(
    private val act: AppCompatActivity,
    private val listView: ListView,
    private val headerAction: TextView,
    /** 지금 화면에 보이는 항목의 키 (전체 선택 · 사라진 항목 정리용) */
    private val visibleKeys: () -> List<K>,
    /** 선택 상태가 바뀌어 목록을 다시 그려야 할 때 */
    private val onChanged: () -> Unit,
    /** 삭제 막대의 '삭제' 를 눌렀을 때 (선택된 키들) */
    private val onDelete: (Set<K>) -> Unit
) {
    private val keys = LinkedHashSet<K>()
    var active = false
        private set

    private val bar: LinearLayout
    private val countText: TextView
    private val allText: TextView
    private val delText: TextView
    private val basePadBottom = listView.paddingBottom
    private val d = act.resources.displayMetrics.density

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { exit() }
    }

    private fun color(attr: Int) = MaterialColors.getColor(listView, attr, 0)

    init {
        act.onBackPressedDispatcher.addCallback(act, backCb)

        headerAction.text = "선택"
        headerAction.visibility = View.VISIBLE
        headerAction.setOnClickListener { if (active) exit() else enter() }

        val host = listView.parent as FrameLayout
        bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = 24 * d
                setColor(color(com.google.android.material.R.attr.colorSurfaceContainerHighest))
            }
            elevation = 6 * d
            setPadding((6 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            visibility = View.GONE
            // 막대 뒤로 목록이 비치거나 눌리지 않게
            isClickable = true
        }
        val close = ImageButton(act).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = android.content.res.ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnSurface))
            background = androidx.appcompat.content.res.AppCompatResources.getDrawable(
                act, selectableBorderless()
            )
            contentDescription = "선택 취소"
            setOnClickListener { exit() }
        }
        bar.addView(close, LinearLayout.LayoutParams((44 * d).toInt(), (44 * d).toInt()))
        countText = TextView(act).apply {
            setTextColor(color(com.google.android.material.R.attr.colorOnSurface))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
        }
        bar.addView(countText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = (4 * d).toInt()
        })
        allText = pill("전체 선택", false).also {
            it.setOnClickListener { toggleAll() }
        }
        bar.addView(allText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (40 * d).toInt()).apply {
            marginEnd = (8 * d).toInt()
        })
        delText = pill("삭제", true).also {
            it.setOnClickListener { if (keys.isNotEmpty()) onDelete(LinkedHashSet(keys)) }
        }
        bar.addView(delText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (40 * d).toInt()))

        host.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM
                val m = (12 * d).toInt()
                setMargins(m, 0, m, m)
            }
        )
    }

    private fun selectableBorderless(): Int {
        val tv = android.util.TypedValue()
        act.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        return tv.resourceId
    }

    private fun pill(text: String, danger: Boolean): TextView = TextView(act).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 14f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding((16 * d).toInt(), 0, (16 * d).toInt(), 0)
        isClickable = true
        isFocusable = true
        applyPill(this, danger, true)
    }

    private fun applyPill(v: TextView, danger: Boolean, enabled: Boolean) {
        val bg = GradientDrawable().apply { cornerRadius = 20 * d }
        if (danger) {
            bg.setColor(ContextCompat.getColor(act, R.color.ev_danger))
            v.setTextColor(ContextCompat.getColor(act, R.color.ev_on_danger))
        } else {
            bg.setColor(color(com.google.android.material.R.attr.colorSurfaceContainerHigh))
            v.setTextColor(color(com.google.android.material.R.attr.colorPrimary))
        }
        v.background = bg
        v.alpha = if (enabled) 1f else 0.4f
    }

    fun isSelected(key: K) = key in keys

    fun enter(first: K? = null) {
        if (!active) {
            active = true
            backCb.isEnabled = true
            headerAction.text = "완료"
            bar.visibility = View.VISIBLE
            if (Motion.enabled(act)) {
                bar.alpha = 0f
                bar.translationY = 40 * d
                Motion.spring(bar, DynamicAnimation.ALPHA, 1f, 400f, 1f)
                Motion.spring(bar, DynamicAnimation.TRANSLATION_Y, 0f, 380f, 0.72f)
            } else {
                bar.alpha = 1f; bar.translationY = 0f
            }
            // 막대에 마지막 항목이 가리지 않게 목록 아래에 여백
            listView.setPadding(listView.paddingLeft, listView.paddingTop, listView.paddingRight, basePadBottom + (76 * d).toInt())
        }
        if (first != null) keys.add(first)
        update()
        onChanged()
    }

    fun exit() {
        if (!active) return
        active = false
        backCb.isEnabled = false
        keys.clear()
        headerAction.text = "선택"
        listView.setPadding(listView.paddingLeft, listView.paddingTop, listView.paddingRight, basePadBottom)
        if (Motion.enabled(act)) {
            bar.animate().cancel()
            bar.animate().alpha(0f).translationY(30 * d).setDuration(140)
                .withEndAction { if (!active) bar.visibility = View.GONE }.start()
        } else {
            bar.visibility = View.GONE
        }
        onChanged()
    }

    fun toggle(key: K) {
        if (!keys.remove(key)) keys.add(key)
        update()
        onChanged()
    }

    private fun toggleAll() {
        val all = visibleKeys()
        if (keys.containsAll(all) && all.isNotEmpty()) keys.removeAll(all.toSet()) else keys.addAll(all)
        update()
        onChanged()
    }

    /** 목록이 다시 그려질 때: 사라진 항목을 선택에서 뺀다 */
    fun retain() {
        if (!active) return
        keys.retainAll(visibleKeys().toSet())
        update()
    }

    private fun update() {
        val all = visibleKeys()
        countText.text = if (keys.isEmpty()) "항목을 선택하세요" else "${keys.size}개 선택됨"
        allText.text = if (all.isNotEmpty() && keys.containsAll(all)) "선택 해제" else "전체 선택"
        applyPill(delText, true, keys.isNotEmpty())
        delText.text = if (keys.isEmpty()) "삭제" else "삭제 (${keys.size})"
    }

    /** 삭제를 마쳤을 때 */
    fun finishDelete() {
        keys.clear()
        exit()
    }

    /**
     * 행 모양을 선택 상태에 맞게 바꾼다 (재활용되는 행이라 항상 두 경우 모두 설정).
     * 선택 모드: 아이콘 자리가 체크 칸이 되고, 선택된 행은 은은하게 칠해지며, ⋮ 는 숨긴다.
     */
    fun bindRow(row: View, key: K, normalIcon: Int, selectable: Boolean = true) {
        val icon = row.findViewById<ImageView>(R.id.rowIcon)
        val more = row.findViewById<View>(R.id.rowMore)
        if (!active || !selectable) {
            row.setBackgroundColor(0)
            icon.setImageResource(normalIcon)
            icon.setBackgroundResource(R.drawable.bg_row_icon)
            icon.imageTintList = android.content.res.ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnPrimaryContainer))
            more.visibility = View.VISIBLE
            row.alpha = if (active && !selectable) 0.45f else 1f
            return
        }
        row.alpha = 1f
        more.visibility = View.INVISIBLE
        val on = key in keys
        row.setBackgroundColor(if (on) color(com.google.android.material.R.attr.colorPrimaryContainer) and 0x00FFFFFF or 0x66000000 else 0)
        if (on) {
            icon.setImageResource(R.drawable.ic_check)
            icon.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color(com.google.android.material.R.attr.colorPrimary))
            }
            icon.imageTintList = android.content.res.ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnPrimary))
        } else {
            icon.setImageResource(normalIcon)
            icon.setBackgroundResource(R.drawable.bg_row_icon)
            icon.imageTintList = android.content.res.ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnPrimaryContainer))
        }
    }
}
