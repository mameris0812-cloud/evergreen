package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.SpringAnimation
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * AI 가 지금 무슨 생각을 하고 있는지(사고 과정의 종류).
 * 종류마다 입력 중 애니메이션의 모양·움직임·색이 달라지고, 바뀔 때는 모양이 이어서 변한다.
 */
enum class ThinkKind(val label: String) {
    /** 일반 생각: 점 세 개가 물결처럼 */
    THINK("생각하는 중…"),

    /** 페이지 읽기: 글줄이 위에서 아래로 차례로 읽힌다 */
    READ("페이지 읽는 중…"),

    /** 사진 보기: 세 점이 렌즈 조리개처럼 모였다 퍼진다 */
    LOOK("사진 살펴보는 중…"),

    /** 웹 검색: 꼬리가 달린 점이 원을 그리며 훑는다 */
    SEARCH("웹에서 찾는 중…"),

    /** 분석·비교·계산: 막대가 오르내린다 */
    ANALYZE("따져 보는 중…"),

    /** 답 정리·초안: 글머리 점에서 줄이 차례로 뻗어 나가 목록이 만들어진다 */
    WRITE("답 정리하는 중…"),

    /** 아이디어 떠올리기: 가운데 불씨 둘레로 빛살이 돌며 차례로 켜진다 */
    IDEA("아이디어 떠올리는 중…"),

    /** 순서·계획 짜기: 계단 막대를 불빛이 차례로 오른다 */
    PLAN("순서 짜는 중…"),

    /** 점검·확인: 동그라미 속 ✓ 가 톡 커지며 잔물결이 퍼진다 */
    CHECK("꼼꼼히 확인하는 중…"),

    /** 코드 짜기: >_ 프롬프트의 커서가 깜빡인다 */
    CODE("코드 짜는 중…"),

    /** 번역·옮기기: 두 점이 앞뒤로 엇갈리며 자리를 맞바꾼다 (잔상 없음) */
    TRANSLATE("옮겨 적는 중…"),

    /** AI 로 만들기(확장 프로그램 · 웹사이트 · 기능 · 테마): 벽돌 네 장이 2×2 로 쌓이고(아래 줄 → 윗줄), 닿을 때 출렁이며, 다 쌓이면 빛이 훑고 가운데로 작아져 사라진 뒤 다시 쌓인다 */
    BUILD("만드는 중…");

    companion object {
        private val headingRe = Regex("\\*\\*([^*\\n]{2,90})\\*\\*")

        /** 모델이 제목을 안 줘도 시간이 지나면 저절로 이어서 바뀔 수 있는 (실제로 읽거나 검색하는 게 아닌) 종류 */
        val DRIFTING = setOf(THINK, IDEA, PLAN, ANALYZE, CHECK, WRITE, CODE, TRANSLATE)

        /**
         * 「AI로 만들기」 요청인가: 「확장 프로그램 만들어줘: …」 「웹사이트 만들어줘」 「새로운 기능 만들어줘」 「내 테마 만들어줘」 처럼
         * 만들 것(확장 · 웹사이트 · 기능 · 테마)과 만들라는 말이 함께 있을 때. 이때는 입력 중 모양이 처음부터 끝까지 「만드는 중」 이다.
         */
        fun isMakeRequest(q: String): Boolean {
            val t = q.lowercase()
            val verb = listOf("만들어", "만들기", "만들래", "만들고", "제작", "create", "build", "make").any { t.contains(it) }
            if (!verb) return false
            return listOf("확장", "웹사이트", "웹 사이트", "홈페이지", "사이트", "기능", "테마", "extension", "website", "theme", "feature").any { t.contains(it) }
        }

        /** 만들기 · 고치기 도구인가 (실행 중인 진행 카드에 「만드는 중」 모양을 붙이는 데 쓴다) */
        fun isBuildTool(name: String): Boolean = name in BUILD_TOOLS

        private val BUILD_TOOLS = setOf(
            "create_extension", "create_website", "create_feature", "customize_theme",
            "edit_extension", "edit_website", "edit_feature"
        )

        /**
         * 질문에서 짐작한 주제 (없으면 null). 중간 단계의 모양을 고르는 데 쓴다:
         * 코드 질문이면 「코드 짜는 중」, 번역이면 「옮겨 적는 중」, 비교·계산이면 「따져 보는 중」.
         */
        fun topicOf(q: String): ThinkKind? {
            val t = q.lowercase()
            fun has(vararg ks: String) = ks.any { t.contains(it) }
            return when {
                isMakeRequest(q) -> BUILD
                has("번역", "translate", "영어로", "한국어로", "일본어로", "중국어로", "해석") -> TRANSLATE
                has("코드", "함수", "버그", "에러", "오류", "코딩", "스크립트", "정규식", "kotlin", "python", "javascript", "css", "html", "sql", "compile") -> CODE
                has("계산", "비교", "차이", "장단점", " vs ", "분석", "얼마", "몇 ") -> ANALYZE
                else -> null
            }
        }

        /**
         * 같은 모양이 한참 이어질 때 다음에 보여 줄 모양. 생각 → 아이디어 → 순서 → (주제) → 확인 → 정리 로
         * 실제 일의 흐름처럼 이어지고, 정리까지 가도 계속 걸리면 주제 단계로 돌아가 다시 돈다.
         */
        fun nextDrift(cur: ThinkKind, topic: ThinkKind?): ThinkKind {
            val mid = topic ?: ANALYZE
            return when (cur) {
                THINK -> IDEA
                IDEA -> PLAN
                PLAN -> mid
                ANALYZE, CODE, TRANSLATE -> CHECK
                CHECK -> WRITE
                WRITE -> mid
                else -> THINK
            }
        }

        /**
         * 모델이 보내 준 생각 요약에서 지금 하고 있는 일을 읽어 낸다.
         * 요약은 「**제목**」으로 시작하는 토막이 이어지므로, 가장 마지막 제목의 낱말로 고른다.
         * 제목이 아직 없으면 null (지금 모양을 그대로 둔다).
         */
        fun classify(thought: String): ThinkKind? {
            val h = headingRe.findAll(thought).lastOrNull()?.groupValues?.get(1)?.lowercase() ?: return null
            fun has(vararg ks: String) = ks.any { h.contains(it) }
            return when {
                has("translat", "번역", "옮겨") -> TRANSLATE
                has("code", "coding", "debug", "implement", "function", "program", "script", "코드", "디버", "구현", "함수", "프로그램") -> CODE
                has("search", "look up", "looking up", "browsing", "fact-check", "fact check", "검색", "찾아", "찾는", "찾기", "조회", "알아보") -> SEARCH
                has("draft", "writ", "compos", "formulat", "structur", "outline", "organiz", "organis", "finaliz", "polish", "refin", "summar", "작성", "정리", "구성", "초안", "다듬", "요약") -> WRITE
                has("image", "photo", "picture", "visual", "screenshot", "사진", "이미지", "그림", "스크린샷") -> LOOK
                has("read", "page", "document", "article", "읽", "페이지", "본문", "문서") -> READ
                has("verif", "check", "confirm", "review", "double", "validat", "확인", "검증", "점검", "검토") -> CHECK
                has("analy", "compar", "evaluat", "calculat", "weigh", "assess", "reason", "분석", "비교", "계산", "따져", "평가") -> ANALYZE
                has("idea", "brainstorm", "consider", "imagin", "explor", "아이디어", "떠올", "생각해 볼", "탐색") -> IDEA
                has("plan", "strateg", "approach", "step", "sequence", "계획", "순서", "단계", "접근", "방법") -> PLAN
                else -> THINK
            }
        }
    }
}

/**
 * AI 가 답을 준비하는 동안 보여 주는 작은 움직임 (예전 점 세 개를 대신한다).
 *
 * 세 개의 둥근 막대가 [ThinkKind] 마다 다른 모양으로 움직인다:
 * 점(생각) · 가로줄(읽기) · 조리개(사진) · 꼬리 달린 궤도(검색) · 막대(분석) · 차례로 써지는 목록(정리) ·
 * 빛살이 도는 ✦ (아이디어) · 불빛이 오르는 계단 막대(순서) · 잔물결이 퍼지는 동그라미 속 ✓ (확인) · 깜빡이는 >_ (코드) · 앞뒤로 엇갈리는 두 점(번역).
 * 새 다섯 종류는 모두 처음과 끝이 이어진 고리라 반복되는 이음매가 보이지 않는다.
 * 종류가 바뀌면 지금 모양에서 새 모양으로 스프링을 타고 이어서 변하고, 색도 함께 흐른다.
 * 움직임은 멈추지 않고 계속 돌기 때문에 바뀌는 순간에도 끊기지 않는다.
 * 시스템의 "애니메이션 끄기" 설정이면 움직이지 않고 모양만 보여 준다.
 */
class ThinkingGlyphView(
    context: Context,
    kind: ThinkKind = ThinkKind.THINK,
    scale: Float = 1f
) : View(context) {

    private val d = resources.displayMetrics.density * scale
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val animate = Motion.enabled(context)

    /** 흐른 시간(초). 모든 종류의 움직임이 이 시계 하나를 쓴다 */
    private var ts = 0f

    var kind: ThinkKind = kind
        private set
    private var from: ThinkKind = kind
    private var morph = 1f
    private var morphAnim: SpringAnimation? = null

    /** 지금 모양 / 이전 모양이 시작된 시계 값. 새 모양은 자기 박자의 처음(쉬는 자세)부터 시작해서 어색하게 중간에서 끼어들지 않는다 */
    private var kindOrigin = 0f
    private var fromOrigin = 0f

    private class S {
        var x = 0f
        var y = 0f
        var w = 0f
        var h = 0f
        var a = 1f
        /** 기울기(도). 0 이면 가로 막대 */
        var r = 0f
        /** 짝색으로 물드는 정도(0~1). 빛이 지나는 조각만 색이 살짝 달라진다 */
        var c = 0f
    }

    private val now = Array(N) { S() }
    private val old = Array(N) { S() }

    private val clock = ValueAnimator.ofFloat(0f, 3600f).apply {
        duration = 3_600_000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            ts = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        contentDescription = kind.label
    }

    /** [k] 모양으로 바꾼다. 이미 그 모양이면 아무것도 하지 않는다 */
    fun setKind(k: ThinkKind, withMorph: Boolean = true) {
        if (k == kind) return
        morphAnim?.cancel()
        from = kind
        fromOrigin = kindOrigin
        kind = k
        kindOrigin = ts
        contentDescription = k.label
        if (!animate || !withMorph || !isAttachedToWindow) {
            morph = 1f
            invalidate()
            return
        }
        morph = 0f
        morphAnim = Motion.springValue(
            0f, 1f, stiffness = 130f, damping = 0.92f,
            onUpdate = {
                morph = it
                invalidate()
            },
            onEnd = {
                morph = 1f
                invalidate()
            }
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animate) clock.start()
    }

    /** 보이지 않는 동안(접힌 카드 등)에는 시계를 세워 배터리를 아낀다 */
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (!animate || !isAttachedToWindow) return
        if (isShown) {
            if (!clock.isStarted) clock.start()
        } else {
            clock.cancel()
        }
    }

    override fun onDetachedFromWindow() {
        clock.cancel()
        morphAnim?.cancel()
        morph = 1f
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize((W * d).toInt() + 2, widthMeasureSpec),
            resolveSize((H * d).toInt() + 2, heightMeasureSpec)
        )
    }

    // ───────── 종류별 모양 (dp 단위, 가운데가 0,0) ─────────

    private fun smooth(x: Float): Float {
        val c = x.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    /** 0→1→0 으로 부드럽게 한 번 솟았다 가라앉는 값 ([phase] 가 1 늘 때마다 한 바퀴) */
    private fun pulse(phase: Float): Float {
        val p = phase - floor(phase)
        return 0.5f - 0.5f * cos(p * 2f * PI.toFloat())
    }

    /** [t] 초가 흐를 때 [period] 초마다 0→1 로 한 바퀴 도는 값 */
    private fun cyc(t: Float, period: Float): Float {
        val x = t / period
        return x - floor(x)
    }

    /** 길이 [period] 인 고리 위에서 [a] 와 [b] 사이의 부호 있는 거리 (-period/2 ≤ 값 < period/2) */
    private fun wrapDelta(a: Float, b: Float, period: Float = 1f): Float {
        val d = a - b
        return d - period * floor(d / period + 0.5f)
    }

    /** 빛이 [d] 만큼 떨어졌을 때의 밝기. 폭 [w] 안에서 부드럽게 0→1 (d 는 거리라 0 이상) */
    private fun glow(d: Float, w: Float): Float = smooth(1f - abs(d) / w)

    /** 종류마다 한 박자(움직임이 한 바퀴 도는 시간, 초) */
    private fun periodOf(k: ThinkKind): Float = when (k) {
        ThinkKind.THINK -> 0.95f
        ThinkKind.READ -> 1.5f
        ThinkKind.LOOK -> 3.2f
        ThinkKind.SEARCH -> 1.15f
        ThinkKind.ANALYZE -> 0.85f
        ThinkKind.WRITE -> 2.4f
        ThinkKind.IDEA -> 2.4f
        ThinkKind.PLAN -> 2.1f
        ThinkKind.CHECK -> 1.9f
        ThinkKind.CODE -> 1.3f
        ThinkKind.TRANSLATE -> 2.0f
        ThinkKind.BUILD -> 3.4f
    }

    /** 지금 모양의 한 박자가 끝나기까지 남은 시간(ms). 모양을 바꿀 때 박자의 끝에 맞추면 움직임이 끊기지 않고 이어진다 */
    fun msToCycleEnd(): Long {
        if (!animate || !isShown) return 0L
        val p = periodOf(kind)
        val x = (ts - kindOrigin) / p
        return ((1f - (x - floor(x))) * p * 1000f).toLong()
    }

    /** 종류마다 쓰는 조각 수 (나머지 조각은 보이지 않는다) */
    private fun countOf(k: ThinkKind): Int = when (k) {
        ThinkKind.IDEA -> 5
        ThinkKind.WRITE -> 6
        ThinkKind.CHECK -> 4
        ThinkKind.BUILD -> 4
        else -> 3
    }

    /**
     * (x0,y0)→(x1,y1) 선분 중 [pa]~[pb] 구간(0~1)만 굵기 [th] 의 기울어진 막대로 [o] 에 담는다.
     * 구간의 끝이 움직이면 선이 그어지고 지워지는 모양이 된다.
     */
    private fun seg2(o: S, x0: Float, y0: Float, x1: Float, y1: Float, pa: Float, pb: Float, th: Float, a: Float) {
        val dx = x1 - x0
        val dy = y1 - y0
        val mid = (pa + pb) / 2f
        o.x = x0 + dx * mid
        o.y = y0 + dy * mid
        // 둥근 끝이 선분의 두 끝점에 정확히 오도록 굵기만큼 늘려서, 꺾이는 곳(✓ · >)에서 두 선이 틈 없이 이어진다
        o.w = if (pb - pa > 0.0001f) sqrt(dx * dx + dy * dy) * (pb - pa) + th else 0.01f
        o.h = th
        o.r = atan2(dy, dx) * 180f / PI.toFloat()
        o.a = a
    }

    private fun shape(k: ThinkKind, i: Int, t: Float, o: S) {
        val tau = 2f * PI.toFloat()
        o.x = 0f
        o.y = 0f
        o.w = 0f
        o.h = 0f
        o.a = 0f
        o.r = 0f
        o.c = 0f
        if (i >= countOf(k)) return
        when (k) {
            ThinkKind.THINK -> {
                // 점이 왼쪽부터 차례로 떠올랐다 가라앉는다
                val wave = smooth(pulse(t / 0.95f - i * 0.15f))
                val dia = 6.4f * (0.88f + 0.30f * wave)
                o.x = (i - 1) * 9.6f
                o.y = 3f - 6f * wave
                o.w = dia
                o.h = dia
                o.a = 0.47f + 0.53f * wave
            }
            ThinkKind.READ -> {
                // 글줄 세 개가 위에서 아래로 차례로 밝아지며 읽힌다
                val full = when (i) { 0 -> 17f; 1 -> 12.5f; else -> 15f }
                val sweep = smooth(pulse(t / 1.5f - i * 0.2f))
                val w = full * (0.78f + 0.22f * sweep)
                o.x = -9f + w / 2f
                o.y = (i - 1) * 6.6f
                o.w = w
                o.h = 3.4f
                o.a = 0.35f + 0.65f * sweep
            }
            ThinkKind.LOOK -> {
                // 세 점이 렌즈 조리개처럼 천천히 돌며 모였다 퍼진다
                val ang = tau * (t / 3.2f) + i * tau / 3f
                val rad = 6f + 2.4f * sin(tau * t / 1.7f)
                o.x = rad * cos(ang)
                o.y = rad * sin(ang)
                o.w = 5.6f
                o.h = 5.6f
                o.a = 0.95f
            }
            ThinkKind.SEARCH -> {
                // 꼬리가 달린 점이 원을 그리며 훑고 지나간다
                val theta = tau * (t / 1.15f) - i * 0.62f
                val dia = 6.4f * (1f - 0.2f * i)
                o.x = 6.6f * cos(theta)
                o.y = 6.6f * sin(theta)
                o.w = dia
                o.h = dia
                o.a = 1f - 0.3f * i
            }
            ThinkKind.ANALYZE -> {
                // 막대 세 개가 서로 엇갈려 오르내린다
                val s = 0.5f + 0.5f * sin(tau * t / 0.85f + i * 2.1f)
                o.x = (i - 1) * 8.2f
                o.y = 0f
                o.w = 4.2f
                o.h = 6f + 11f * smooth(s)
                o.a = 0.6f + 0.4f * s
            }
            ThinkKind.WRITE -> {
                // 글머리 점 세 개로 이루어진 목록. 점에서 줄이 위에서부터 차례로 쭉 뻗어 나가 목록이 완성되고,
                // 잠시 머문 뒤 줄이 다시 위에서부터 차례로 점 속으로 접혀 들어간다 (쉬는 자세 = 점 세 개라 처음과 끝이 이어진다)
                val u = cyc(t, 2.4f)
                val j = i % 3
                val grow = smooth((u - 0.06f - j * 0.16f) / 0.26f)
                val fold = smooth((u - 0.78f - j * 0.06f) / 0.16f)
                val e = grow * (1f - fold)
                if (i < 3) {
                    val full = floatArrayOf(17f, 11f, 14f)[j]
                    val w = full * e
                    o.x = -7f + w / 2f
                    o.y = (j - 1) * 6.6f
                    o.w = w
                    o.h = 3.4f
                    o.a = 0.4f + 0.6f * e
                    o.c = e
                } else {
                    o.x = -10.5f
                    o.y = (j - 1) * 6.6f
                    o.w = 3.6f
                    o.h = 3.6f
                    o.a = 0.55f + 0.45f * e
                    o.c = e
                }
            }
            ThinkKind.IDEA -> {
                // ✦ 반짝임: 가운데 불씨가 숨 쉬고, 둘레의 빛살 네 개에 불빛이 시계 방향으로 계속 돌며 차례로 켜진다.
                // 켜진 빛살은 바깥으로 길게 뻗고 굵어졌다 가라앉는다 (처음과 끝이 없는 고리라 끊기는 순간이 없다)
                val u = cyc(t, 2.4f)
                if (i == 0) {
                    val b = pulse(t / 1.2f)
                    val dia = 4.8f + 2.4f * smooth(b)
                    o.w = dia
                    o.h = dia
                    o.a = 0.72f + 0.28f * b
                    o.c = b
                } else {
                    val k = i - 1
                    val l = glow(wrapDelta(u, k / 4f), 0.42f)
                    val ang = (-45f + 90f * k) * PI.toFloat() / 180f
                    val r0 = 4.6f + 1.2f * l
                    val r1 = 7.6f + 3.0f * l
                    seg2(o, r0 * cos(ang), r0 * sin(ang), r1 * cos(ang), r1 * sin(ang), 0f, 1f, 2.2f + 1.0f * l, 0.26f + 0.74f * l)
                    o.c = l
                }
            }
            ThinkKind.PLAN -> {
                // ▂▄▆ 계단 막대 세 개. 불빛이 낮은 계단에서 높은 계단으로 차례로 오르고, 맨 위를 지나면 맨 아래에서 이어진다
                val l = glow(wrapDelta(cyc(t, 2.1f) * 3f, i + 0.5f, 3f), 1.1f)
                val h = floatArrayOf(7f, 11.5f, 16f)[i] + 1.6f * l
                o.x = (i - 1) * 8.4f
                o.y = 8f - h / 2f
                o.w = 5f
                o.h = h
                o.a = 0.3f + 0.7f * l
                o.c = l
            }
            ThinkKind.CHECK -> {
                // 동그라미 안의 ✓. 1.9초마다 ✓ 가 톡 커지고 동그라미 테두리에서 잔물결이 한 번 퍼진다
                val u = cyc(t, 1.9f)
                val pop = glow(wrapDelta(u, 0f), 0.25f)
                val sc = 1f + 0.12f * pop
                when (i) {
                    0 -> {
                        o.w = 19f
                        o.h = 19f
                        o.a = 0.12f + 0.06f * pop
                    }
                    1 -> {
                        val dia = 15f + 7f * u
                        o.w = dia
                        o.h = dia
                        o.a = 0.3f * (1f - u) * smooth(u * 8f)
                    }
                    2 -> {
                        seg2(o, -4.2f * sc, 0.5f * sc, -1.4f * sc, 3.4f * sc, 0f, 1f, 2.8f, 1f)
                        o.c = pop
                    }
                    else -> {
                        seg2(o, -1.4f * sc, 3.4f * sc, 4.6f * sc, -3.2f * sc, 0f, 1f, 2.8f, 1f)
                        o.c = pop
                    }
                }
            }
            ThinkKind.CODE -> {
                // >_ 프롬프트. > 가 앞으로 살짝 나아갔다 돌아오고, 밑줄 커서가 부드럽게 깜빡인다
                val b = smooth(pulse(t / 1.3f))
                val nudge = 1.3f * b
                when (i) {
                    0 -> {
                        seg2(o, -10f + nudge, -5.2f, -4.4f + nudge, 0f, 0f, 1f, 2.8f, 0.6f + 0.4f * b)
                        o.c = b
                    }
                    1 -> {
                        seg2(o, -4.4f + nudge, 0f, -10f + nudge, 5.2f, 0f, 1f, 2.8f, 0.6f + 0.4f * b)
                        o.c = b
                    }
                    else -> {
                        o.x = 6f
                        o.y = 4.4f
                        o.w = 8f
                        o.h = 2.6f
                        o.a = 0.25f + 0.75f * smooth(pulse(t / 1.3f + 0.5f))
                        o.c = 1f
                    }
                }
            }
            ThinkKind.TRANSLATE -> {
                // 두 점이 타원 궤도를 돌며 서로 자리를 맞바꾼다. 앞으로 온 점은 크고 선명하게, 뒤로 간 점은 작고 흐리게 보여
                // 입체로 엇갈리는 느낌을 주고, 두 점 사이를 잇는 가는 다리가 같이 돈다 (꼬리·잔상 없음)
                val ang = tau * cyc(t, 2.0f)
                fun front(a: Float) = 0.5f + 0.5f * sin(a)
                val px = 8.4f * cos(ang)
                val py = 4.2f * sin(ang)
                when (i) {
                    0 -> {
                        seg2(o, px, py, -px, -py, 0.1f, 0.9f, 1.5f, 0.2f + 0.2f * pulse(t))
                        o.c = 0.5f
                    }
                    else -> {
                        val sg = if (i == 1) 1f else -1f
                        val fr = if (i == 1) front(ang) else 1f - front(ang)
                        val dia = 4.6f + 2.2f * fr
                        o.x = sg * px
                        o.y = sg * py
                        o.w = dia
                        o.h = dia
                        o.a = 0.5f + 0.5f * fr
                        o.c = if (i == 1) 0f else 1f
                    }
                }
            }
            ThinkKind.BUILD -> {
                // 벽돌 네 장이 2×2 로 쌓인다: 아래 줄(왼쪽 → 오른쪽)이 먼저 놓이고, 그 위에 윗줄(왼쪽 → 오른쪽)이 얹힌다.
                // 위에서 중력으로 떨어져(점점 빨라짐) 닿는 순간 납작해졌다가 감쇠하며 출렁이고 번쩍한다.
                // 다 쌓이면 빛이 놓인 순서대로 훑고, 네 장이 가운데로 모이며 작아져 사라진 뒤 다음 덩어리가 이어서 쌓인다.
                val u = cyc(t, 3.4f)
                val s0 = 0.04f + i * 0.15f
                val g = ((u - s0) / 0.17f).coerceIn(0f, 1f)
                val since = u - s0 - 0.17f
                val sq = if (since >= 0f) exp(-since * 22f) * cos(since * 45f) else 0f
                val sk = smooth((u - 0.86f) / 0.14f)
                val keep = 1f - sk
                val bw = 9f * (1f + 0.1f * sq)
                val bh = 5.4f * (1f - 0.3f * sq)
                val rest = if (i < 2) 3.4f else -3.4f
                val flash = if (since in 0f..0.1f) 1f - smooth(since / 0.1f) else 0f
                val sp = (u - 0.66f) / 0.2f * 4f - 0.5f
                val sw = if (u in 0.66f..0.86f) glow(abs(sp - i), 1.0f) else 0f
                // 사라질 때는 가운데(0,0)를 향해 위치와 크기가 함께 줄어든다
                o.x = (if (i % 2 == 0) -5.2f else 5.2f) * keep
                // 아랫면은 그대로 두고 눌린 만큼 가운데가 내려간다
                o.y = (rest + (5.4f - bh) / 2f - 15f * (1f - g * g)) * (if (sk > 0f) keep else 1f)
                o.w = bw * keep
                o.h = bh * keep
                o.a = smooth(g * 3f) * (1f - sk * sk) * (0.65f + 0.35f * max(flash, sw))
                o.c = max(flash, sw)
            }
        }
    }

    /** 조각마다 따로 물드는 짝색 (빛이 지나는 조각이 살짝 다른 색으로 빛난다) */
    private fun companionOf(k: ThinkKind): Int = when (k) {
        ThinkKind.IDEA -> AiGradient.at(0.58f)
        ThinkKind.PLAN -> AiGradient.at(0.78f)
        ThinkKind.CHECK -> AiGradient.at(0.22f)
        ThinkKind.CODE -> AiGradient.at(0.6f)
        ThinkKind.WRITE -> AiGradient.at(0.55f)
        ThinkKind.TRANSLATE -> AiGradient.at(0.9f)
        ThinkKind.BUILD -> AiGradient.at(0.85f)
        else -> colorOf(k)
    }

    private fun pieceColor(k: ThinkKind, tint: Float): Int =
        if (tint <= 0.001f) colorOf(k) else ColorUtils.blendARGB(colorOf(k), companionOf(k), tint.coerceIn(0f, 1f))

    private fun colorOf(k: ThinkKind): Int {
        val st = AiGradient.STOPS
        return when (k) {
            ThinkKind.THINK -> st[0]
            ThinkKind.READ -> st[1]
            ThinkKind.SEARCH -> st[2]
            ThinkKind.ANALYZE -> st[3]
            ThinkKind.LOOK -> AiGradient.at(0.78f)
            ThinkKind.WRITE -> AiGradient.at(0.2f)
            ThinkKind.IDEA -> AiGradient.at(0.9f)
            ThinkKind.PLAN -> AiGradient.at(0.4f)
            ThinkKind.CHECK -> AiGradient.at(0.62f)
            ThinkKind.CODE -> AiGradient.at(0.08f)
            ThinkKind.TRANSLATE -> AiGradient.at(0.5f)
            ThinkKind.BUILD -> AiGradient.at(0.28f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        // 움직이지 않는 설정이면 시간을 0 에 세워 두고 모양만 그린다. 모양마다 자기 시작 시각부터 박자를 센다
        val t = if (animate) ts - kindOrigin else 0f
        val tf = if (animate) ts - fromOrigin else 0f
        val m = morph
        val morphing = m < 1f
        val nNew = countOf(kind)
        val nOld = countOf(from)
        for (i in 0 until N) {
            val b = now[i]
            shape(kind, i, t, b)
            var x = b.x
            var y = b.y
            var w = b.w
            var h = b.h
            var a = b.a
            var rot = b.r
            var col = pieceColor(kind, b.c)
            if (morphing) {
                // 이전 모양도 계속 움직이게 두고 둘 사이를 스프링으로 오간다.
                // 한쪽 모양에서 안 쓰는 조각은 가운데로 몰리지 않고 제자리에서 작아지며 옅어지고(사라질 때) 커지며 짙어진다(나타날 때).
                // 조각마다 시작을 조금씩 어긋나게(0.04 씩) 해서 한꺼번에 뒤섞이지 않고 물결처럼 이어진다
                val o = old[i]
                shape(from, i, tf, o)
                if (i >= nOld) {
                    o.x = b.x; o.y = b.y; o.w = b.w * 0.3f; o.h = b.h * 0.3f; o.a = 0f; o.r = b.r; o.c = b.c
                }
                if (i >= nNew) {
                    b.x = o.x; b.y = o.y; b.w = o.w * 0.3f; b.h = o.h * 0.3f; b.a = 0f; b.r = o.r; b.c = o.c
                }
                val dl = i * 0.04f
                val mi = ((m - dl) / (1f - dl)).coerceAtLeast(0f)
                val mc = mi.coerceIn(0f, 1f)
                x = o.x + (b.x - o.x) * mi
                y = o.y + (b.y - o.y) * mi
                w = o.w + (b.w - o.w) * mi
                h = o.h + (b.h - o.h) * mi
                a = o.a + (b.a - o.a) * mc
                // 기울기는 가까운 쪽으로 돌아간다 (170° → -170° 일 때 한 바퀴 도는 일이 없게)
                var dr = b.r - o.r
                dr -= 360f * floor(dr / 360f + 0.5f)
                rot = o.r + dr * mi
                col = ColorUtils.blendARGB(pieceColor(from, o.c), pieceColor(kind, b.c), mc)
            }
            w = max(0f, w) * d
            h = max(0f, h) * d
            if (w < 0.5f || h < 0.5f) continue
            paint.color = col
            paint.alpha = (a.coerceIn(0f, 1f) * 255f).toInt()
            rect.set(cx + x * d - w / 2f, cy + y * d - h / 2f, cx + x * d + w / 2f, cy + y * d + h / 2f)
            // 만들기 모양은 둥근 네모(타일), 나머지는 알약·동그라미
            val r = min(w, h) * (if (kind == ThinkKind.BUILD) 0.3f else 0.5f)
            if (rot != 0f) {
                canvas.save()
                canvas.rotate(rot, cx + x * d, cy + y * d)
                canvas.drawRoundRect(rect, r, r, paint)
                canvas.restore()
            } else {
                canvas.drawRoundRect(rect, r, r, paint)
            }
        }
    }

    private companion object {
        const val W = 30f
        const val H = 22f
        /** 한 모양을 이루는 조각의 최대 수 */
        const val N = 6
    }
}

/** 글자를 바꿀 때 위로 살짝 떠오르며 옅어졌다가 새 글자가 아래에서 올라온다 */
object ThinkText {
    /**
     * [tv] 의 글을 [text] 로 바꾼다. [widthAnim] 이면 글 너비가 달라지는 만큼 칸이 부드럽게 늘고 줄어든다
     * (너비가 정해져 있지 않은 말풍선 안의 글에 쓴다).
     */
    fun swap(tv: TextView, text: String, widthAnim: Boolean = false) {
        if (tv.text.toString() == text) return
        if (!Motion.enabled(tv.context) || !tv.isAttachedToWindow || tv.width <= 0) {
            tv.animate().cancel()
            tv.text = text
            tv.alpha = 1f
            tv.translationY = 0f
            return
        }
        val d = tv.resources.displayMetrics.density
        val fromW = tv.width
        val toW = (tv.paint.measureText(text) + tv.paddingLeft + tv.paddingRight).toInt() + 1
        tv.animate().cancel()
        tv.animate().alpha(0f).translationY(-3f * d).setDuration(110).withEndAction {
            tv.text = text
            tv.translationY = 4f * d
            tv.animate().alpha(1f).translationY(0f).setDuration(190).start()
        }.start()
        if (widthAnim && fromW != toW) {
            val lp = tv.layoutParams
            ValueAnimator.ofInt(fromW, toW).apply {
                duration = 240
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener {
                    lp.width = it.animatedValue as Int
                    tv.layoutParams = lp
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        lp.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                        tv.layoutParams = lp
                    }
                })
                start()
            }
        }
    }
}
