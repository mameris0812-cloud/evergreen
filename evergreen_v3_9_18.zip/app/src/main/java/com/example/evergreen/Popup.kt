package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.annotation.DrawableRes

/**
 * 앱 전체가 함께 쓰는 팝업 (가운데에 뜨는 둥근 카드).
 * - menu(): 머리말 + 아이콘 달린 항목 목록
 * - confirm(): 제목 + 설명 + 취소/확인 버튼
 * 등장은 통통 튀는 확대, 항목은 위에서부터 차례로 떠오른다.
 */
object Popup {
    private val open = ArrayList<java.lang.ref.WeakReference<PopupWindow>>()

    /** 시스템 뒤로가기(제스처 포함)로 닫을 수 있게 떠 있는 팝업을 기억해 둔다 */
    fun track(p: PopupWindow) {
        open.removeAll { it.get() == null || it.get() === p }
        open.add(java.lang.ref.WeakReference(p))
    }

    private val openDialogs = ArrayList<java.lang.ref.WeakReference<Dialog>>()

    /** 폰/태블릿 모드가 바뀔 때 한꺼번에 닫으려고 떠 있는 카드 팝업(Dialog)도 기억해 둔다 */
    fun trackDialog(d: Dialog) {
        openDialogs.removeAll { it.get() == null || it.get() === d }
        openDialogs.add(java.lang.ref.WeakReference(d))
    }

    private val dialogWidthDp = java.util.WeakHashMap<Dialog, Int>()

    /**
     * 카드 팝업의 폭을 지금 앱 창 크기에 다시 맞춘다.
     * 분할 화면으로 들어가거나 창 크기가 바뀌면, 팝업이 만들어질 때 잰 옛 창 폭이 그대로 남아 어긋나 보이다가
     * 건드려야 다시 그려졌다. 창 크기가 바뀐 뒤(레이아웃이 끝난 뒤)와 팝업이 뜬 직후에 불러 맞춘다.
     */
    fun relayout(d: Dialog) {
        if (!d.isShowing || d is MorphDialog) return
        val wDp = dialogWidthDp[d] ?: return
        val w = d.window ?: return
        val maxW = minOf(dp(d.context, wDp), (viewport(d.context).first * 0.92f).toInt())
        if (maxW <= 0) return
        val lp = w.attributes
        if (lp.width != maxW) w.setLayout(maxW, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.decorView.requestLayout()
    }

    /** 떠 있는 카드 팝업 전부를 새 창 크기에 맞춘다 (창 크기가 바뀔 때 호출) */
    fun relayoutAll() {
        openDialogs.toList().forEach { r -> r.get()?.let { runCatching { relayout(it) } } }
    }

    /**
     * 떠 있는 팝업·카드 팝업을 모두 닫는다. 폰↔태블릿 화면이 바뀌면 옛 모드로 만든 창이 그대로 남아
     * 어색해지므로, 모드가 바뀔 때 닫아서 새 모드에서 다시 열게 한다. 하나라도 닫았으면 true.
     */
    fun dismissAll(): Boolean {
        var any = false
        open.toList().forEach { r ->
            val p = r.get()
            if (p != null && p.isShowing) { runCatching { p.dismiss(); any = true } }
        }
        open.clear()
        openDialogs.toList().forEach { r ->
            val d = r.get()
            if (d != null && d.isShowing) { runCatching { d.dismiss(); any = true } }
        }
        openDialogs.clear()
        return any
    }

    /**
     * 가장 나중에 뜬 팝업이 떠 있으면 닫고 true. 없으면 false.
     * 팝업 창은 포커스를 가져가도 제스처 뒤로가기는 팝업이 아니라 액티비티로 와서, 그대로 두면 웹페이지가 뒤로 가 버린다.
     */
    fun dismissTop(): Boolean {
        open.removeAll { val p = it.get(); p == null || !p.isShowing }
        val p = open.lastOrNull()?.get() ?: return false
        open.removeAt(open.size - 1)
        return try { p.dismiss(); true } catch (e: Exception) { false }
    }


    // ── 태블릿: 메뉴는 누른 버튼 바로 아래에 붙어서 뜬다 ──
    // 창에 닿은 마지막 손가락 자리의 클릭 가능한 뷰를 기억해 두었다가, 메뉴를 띄울 때 그 뷰를 기준으로 삼는다.
    // 기억해 둔 뷰가 없거나 너무 크면(웹페이지 등) 예전처럼 가운데에 띄운다.
    private var tapRef: java.lang.ref.WeakReference<View>? = null
    private var tapAt = 0L

    /** 창의 터치를 지켜보는 껍데기. 동작은 원래 콜백에 그대로 맡긴다 */
    class TapTracker(private val base: android.view.Window.Callback, private val window: android.view.Window) :
        android.view.Window.Callback by base {
        override fun dispatchTouchEvent(event: android.view.MotionEvent): Boolean {
            if (event.actionMasked == android.view.MotionEvent.ACTION_DOWN) {
                runCatching { noteTap(window.decorView, event.rawX.toInt(), event.rawY.toInt()) }
            }
            return base.dispatchTouchEvent(event)
        }

        companion object {
            fun install(activity: android.app.Activity) {
                val w = activity.window ?: return
                val cur = w.callback ?: return
                if (cur is TapTracker) return
                w.callback = TapTracker(cur, w)
            }
        }
    }

    private fun noteTap(root: View, x: Int, y: Int) {
        tapRef = clickableAt(root, x, y)?.let { java.lang.ref.WeakReference(it) }
        tapAt = android.os.SystemClock.uptimeMillis()
    }

    private fun clickableAt(v: View, x: Int, y: Int): View? {
        if (v.visibility != View.VISIBLE) return null
        val l = IntArray(2)
        v.getLocationOnScreen(l)
        if (x < l[0] || x > l[0] + v.width || y < l[1] || y > l[1] + v.height) return null
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) clickableAt(v.getChildAt(i), x, y)?.let { return it }
        }
        return if (v.isClickable) v else null
    }

    private fun isTablet(ctx: Context) = ctx.resources.configuration.screenWidthDp >= 600

    private fun activityOf(ctx: Context): android.app.Activity? {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) return c
            c = c.baseContext
        }
        return null
    }

    /** 이 창에서 방금(8초 안에) 눌린 버튼. 적당한 크기의 버튼·줄일 때만 돌려준다 */
    private fun recentAnchor(ctx: Context): View? {
        val a = tapRef?.get() ?: return null
        if (android.os.SystemClock.uptimeMillis() - tapAt > 8000) return null
        val act = activityOf(ctx) ?: return null
        if (!a.isAttachedToWindow || !a.isShown || a.rootView !== act.window?.decorView) return null
        val root = a.rootView
        if (a.height > root.height / 4 || a.width > root.width * 9 / 10) return null
        return a
    }

    /**
     * 손가락을 떼지 않고 끌어 온 채로 항목을 고를 수 있게 하는 손잡이 ([menu] 의 handle 로 넘긴다).
     * 팝업은 별도의 창이라 끄는 중인 터치는 받지 못하므로, 끌고 있는 쪽이 화면 좌표(rawX/rawY)로 이 손잡이에 물어본다.
     * 손가락 밑의 항목은 살짝 물든 채 눌린 모양이 되고, 손가락을 떼면 끌던 쪽이 [indexAt] 으로 어느 항목인지 알아내 실행한다.
     */
    class DragHandle {
        internal val rows = ArrayList<View>()
        internal var card: View? = null
        private var lit = -1

        private fun screenRect(v: View, out: android.graphics.Rect) {
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            out.set(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
        }

        /** 화면 좌표 (x, y) 밑에 있는 항목 번호 (없으면 -1) */
        fun indexAt(x: Float, y: Float): Int {
            val r = android.graphics.Rect()
            rows.forEachIndexed { i, v ->
                if (!v.isShown) return@forEachIndexed
                screenRect(v, r)
                if (r.contains(x.toInt(), y.toInt())) return i
            }
            return -1
        }

        /** 팝업 카드가 차지한 자리 (화면 좌표). 아직 안 보이면 null */
        fun cardBounds(): android.graphics.Rect? {
            val c = card?.takeIf { it.isShown } ?: return null
            return android.graphics.Rect().also { screenRect(c, it) }
        }

        /** [i] 번 항목만 손가락이 올라간 모양으로 (-1 이면 모두 해제). 바뀌었으면 true */
        fun highlight(i: Int): Boolean {
            if (i == lit) return false
            rows.getOrNull(lit)?.let { off(it) }
            rows.getOrNull(i)?.let { on(it) }
            lit = i
            return true
        }

        private fun on(v: View) {
            val ctx = v.context
            val c = ThemeColors.get(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF2E7D32.toInt())
            v.foreground = GradientDrawable().apply {
                setColor((c and 0x00FFFFFF) or 0x26000000)
                cornerRadius = 16f * ctx.resources.displayMetrics.density
            }
            v.isPressed = true
            v.animate().scaleX(1.025f).scaleY(1.025f).setDuration(110).start()
        }

        private fun off(v: View) {
            v.foreground = null
            v.isPressed = false
            v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
        }
    }

    class Item(
        @DrawableRes val icon: Int,
        val label: String,
        val sub: String? = null,
        val danger: Boolean = false,
        /** 아이콘 대신 이 색의 동그라미를 보여준다 (탭 그룹 색 등) */
        val dotColor: Int? = null,
        val checked: Boolean = false,
        /** 설명(sub)을 한 줄로 줄여 보여준다 (주소처럼 긴 글자용) */
        val compactSub: Boolean = false,
        /** 아이콘에 회색 틴트를 입히지 않고 원래 색 그대로 보여준다 (나뭇잎 아이콘 등) */
        val keepIconColor: Boolean = false,
        /** 이 주소 사이트의 아이콘(파비콘)을 아이콘 자리에 보여준다. 아직 없거나 못 구하면 원래 아이콘을 그대로 둔다 */
        val iconUrl: String? = null,
        val action: () -> Unit
    )

    /**
     * AlertDialog 의 카드를 창 폭(테마의 고정 폭, 창이 더 좁으면 창 폭)에 꽉 차게 한다.
     * 기본 틀은 내용 폭만큼만 잡혀서, 분할 화면처럼 창 크기가 달라지면 내용이 카드 한쪽에 쏠려 보였다.
     * 폭을 픽셀로 정하지 않으므로 창 크기가 바뀌어도 어긋나지 않는다. show() 뒤에 부른다.
     */
    fun fillWidth(dialog: androidx.appcompat.app.AlertDialog) {
        val panel = dialog.findViewById<View>(androidx.appcompat.R.id.parentPanel) ?: return
        val lp = panel.layoutParams ?: return
        if (lp.width != ViewGroup.LayoutParams.MATCH_PARENT) {
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            panel.layoutParams = lp
        }
    }

    /** 위험(삭제 등) 색: 밝은/어두운 테마에 맞춰 resources 에서 가져온다 */
    private fun danger(ctx: Context) = androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_danger)

    /**
     * 대화상자 안의 글자 입력칸을 앱 공통 모양(연한 면 + 둥근 모서리)으로 만든다.
     * 기본 밑줄 입력칸 대신 쓰며, 포커스를 받으면 테두리가 강조색으로 바뀐다.
     */
    fun styleInput(et: android.widget.EditText) {
        val ctx = et.context
        val fill = ThemeColors.get(
            ctx, com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFFF0F2F5.toInt()
        )
        val accent = ThemeColors.get(
            ctx, androidx.appcompat.R.attr.colorPrimary, 0xFF1E8E3E.toInt()
        )
        fun shape(stroke: Int) = GradientDrawable().apply {
            cornerRadius = dp(ctx, 14).toFloat()
            setColor(fill)
            setStroke(if (stroke == 0) 0 else dp(ctx, 2), stroke)
        }
        et.background = android.graphics.drawable.StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(accent))
            addState(intArrayOf(), shape(0))
        }
        et.setPadding(dp(ctx, 16), dp(ctx, 13), dp(ctx, 16), dp(ctx, 13))
        et.textSize = 15f
    }


    /** 버튼 아래에 붙어 뜨는 카드 팝업의 공통 규격 (모서리 · 그림자) */
    const val ANCHORED_RADIUS_DP = 16
    const val ANCHORED_ELEVATION_DP = 10

    /**
     * 붙어 뜨는 팝업(PopupWindow)의 둥근 카드 배경을 만든다.
     * [content] 는 같은 모양으로 잘리고, 블러가 켜져 있으면 뒤가 비치는 반투명 색이 된다.
     */
    fun anchoredBackground(ctx: Context, content: View, radiusDp: Int = ANCHORED_RADIUS_DP, glass: Boolean = Blur.supported(ctx)): GradientDrawable {
        val radius = dp(ctx, radiusDp).toFloat()
        content.clipToOutline = true
        content.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, v.width, v.height, radius)
            }
        }
        return GradientDrawable().apply {
            cornerRadius = radius
            setColor(Blur.surface(ctx, com.google.android.material.R.attr.colorSurfaceContainer, glass))
        }
    }

    /** 등장 시작 상태: 누른 버튼 가운데 아래에서 펼쳐질 준비. 팝업을 띄우기 전에 부른다. */
    fun prepareAnchoredEnter(content: View, pivotXPx: Float, widthPx: Int) {
        if (!Motion.enabled(content.context)) return
        content.pivotX = pivotXPx.coerceIn(0f, widthPx.toFloat())
        content.pivotY = 0f
        content.alpha = 0f
        content.scaleX = 0.92f
        content.scaleY = 0.86f
    }

    /** 등장 재생: 부드럽게 안착하는 스프링 + (목록이 있으면) 항목이 살짝 내려오며 차례로 나타난다. 팝업을 띄운 뒤에 부른다. */
    fun playAnchoredEnter(content: View, list: ViewGroup? = null) {
        val ctx = content.context
        if (!Motion.enabled(ctx)) return
        Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 480f, 1f)
        Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 420f, 1f)
        Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 800f, 1f)
        if (list == null) return
        for (i in 0 until list.childCount) {
            val row = list.getChildAt(i)
            row.alpha = 0f
            row.translationY = -dp(ctx, 4).toFloat()
            row.animate()
                .alpha(1f).translationY(0f)
                .setStartDelay(minOf(40L + i * 16L, 220L))
                .setDuration(180)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f))
                .start()
        }
    }

    /** 꾹 눌러 뜨는 메뉴(링크·이미지)의 가로 폭 */
    private const val POINT_WIDTH_DP = 264

    /**
     * 꾹 눌러 뜨는 메뉴 전용 창.
     * 카드 배경·그림자는 content 의 부모(창 배경 뷰)가 그리므로, 내용만 움직이면 카드 틀이 먼저 통째로 보이고
     * 그 안에서 내용만 커졌다. 그래서 부모까지 한 덩어리로 움직이고, 닫을 때도 같은 점으로 접히며 사라진다.
     */
    private class PointPopupWindow(content: View, w: Int, h: Int) : PopupWindow(content, w, h, true) {
        var pivotX = 0f
        var pivotY = 0f
        private var closing = false

        fun target(): View {
            val c = contentView
            val p = c.parent as? View
            return if (p != null && p !== c.rootView) p else c
        }

        private fun finish() = super.dismiss()

        override fun dismiss() {
            val c = contentView
            if (closing) return
            if (!isShowing || c == null || !Motion.enabled(c.context)) {
                finish()
                return
            }
            closing = true
            val t = target()
            Motion.cancel(t)
            t.animate().cancel()
            t.pivotX = pivotX
            t.pivotY = pivotY
            t.animate()
                .alpha(0f).scaleX(0.9f).scaleY(0.84f)
                .setDuration(120)
                .setInterpolator(android.view.animation.AccelerateInterpolator(1.3f))
                .withEndAction { finish() }
                .start()
            // 화면이 먼저 사라지는 등 애니메이션이 끝나지 못해도 창이 남지 않게
            t.postDelayed({ if (isShowing) finish() }, 260)
        }
    }

    /**
     * 꾹 누르기 메뉴 등장: 손가락 자리에서 가로가 먼저 퍼지고 세로가 뒤따라 펼쳐진다.
     * 창 크기가 정해져 있어 커지다 넘치면 잘리므로 튕김은 거의 없이 부드럽게 안착시킨다.
     * 항목은 손가락에서 멀어지는 방향으로 살짝 떠오르며 차례로 나타난다.
     */
    private fun playPointEnter(pw: PointPopupWindow, list: ViewGroup, above: Boolean) {
        val ctx = list.context
        if (!Motion.enabled(ctx)) return
        val t = pw.target()
        Motion.cancel(t)
        t.pivotX = pw.pivotX
        t.pivotY = pw.pivotY
        t.alpha = 0f
        t.scaleX = 0.82f
        t.scaleY = 0.7f
        Motion.spring(t, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 640f, 0.9f)
        Motion.spring(t, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 540f, 0.9f)
        Motion.spring(t, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 1000f, 1f)
        val shift = dp(ctx, 8).toFloat() * (if (above) 1f else -1f)
        for (i in 0 until list.childCount) {
            val row = list.getChildAt(i)
            row.animate().cancel()
            row.alpha = 0f
            row.translationY = shift
            row.animate()
                .alpha(1f).translationY(0f)
                .setStartDelay(minOf(50L + i * 24L, 230L))
                .setDuration(220)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.8f))
                .start()
        }
    }

    /** 버튼 아래에 붙는 메뉴(탭 메뉴·기록 등)의 기본 가로 폭. 예전에는 380dp 였다 */
    private const val ANCHORED_WIDTH_DP = 296

    /** 항목이 두세 개뿐인 아주 작은 메뉴(탭 화면 더보기 등)의 가로 폭 */
    private const val COMPACT_WIDTH_DP = 244

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /**
     * 팝업이 기준으로 삼을 "보이는 창"의 크기. 분할 화면·작은 창에서는 기기 화면 전체가 아니라
     * 앱 창 크기를 써야 팝업이 창 밖으로 나가거나 어긋나지 않는다. 알 수 없으면 화면 크기.
     */
    private fun viewport(ctx: Context): Pair<Int, Int> {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) {
                val root = c.window?.decorView
                if (root != null && root.width > 0 && root.height > 0) return root.width to root.height
                break
            }
            c = c.baseContext
        }
        val dm = ctx.resources.displayMetrics
        return dm.widthPixels to dm.heightPixels
    }


    /** XML 의 ?attr 색(제목·본문 글자, 아이콘 칸 등)에도 테마 색을 입힌다. 뜰 때(안의 줄이 다 채워진 뒤) 한 번 입힌다 */
    private fun skinOnAttach(v: View) {
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(view: View) { ThemeColors.skin(view) }
            override fun onViewDetachedFromWindow(view: View) {}
        })
    }

    private fun create(
        ctx: Context,
        title: String,
        subtitle: String?,
        headerIcon: Int?,
        headerColor: Int?,
        widthDp: Int = 340,
        preview: Boolean = false,
        origin: View? = null,
        /** true 면 메뉴창처럼 회색(colorSurfaceContainer) 바탕 — 안의 카드는 흰색(colorSurface)으로 얹는다 */
        gray: Boolean = false,
        /** true 면 태블릿에서만 펼쳐지는 팝업이 화면 가운데가 아니라 origin(눌린 줄) 곁에 뜬다 (폰은 가운데) */
        nearOrigin: Boolean = false
    ): Pair<Dialog, View> {
        // origin 이 있으면 그 카드가 그대로 펼쳐져 팝업이 되는 '모핑' 팝업 (애니메이션을 끈 기기에서는 일반 팝업)
        val morph = origin != null && !preview && Motion.enabled(ctx) &&
            origin.isAttachedToWindow && origin.width > 0 && origin.height > 0
        val dialog: Dialog = if (morph && origin != null) MorphDialog(ctx, origin, nearOrigin = nearOrigin && isTablet(ctx)) else Dialog(ctx, R.style.Evergreen_Popup)
        trackDialog(dialog)
        dialogWidthDp[dialog] = widthDp
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null).also { skinOnAttach(it) }
        val bgAttr = if (gray) com.google.android.material.R.attr.colorSurfaceContainer else com.google.android.material.R.attr.colorSurface
        if (gray) view.background = GradientDrawable().apply {
            setColor(ThemeColors.get(ctx, bgAttr, 0xFFF7F8FA.toInt()))
            cornerRadius = dp(ctx, 26).toFloat()
        }

        BetaBadge.set(view.findViewById<TextView>(R.id.popupTitle), title)
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        val icon = view.findViewById<ImageView>(R.id.popupIcon)
        if (headerColor != null) {
            icon.setImageDrawable(null)
            icon.setPadding(0, 0, 0, 0)
            icon.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(headerColor)
            }
            icon.visibility = View.VISIBLE
        } else if (headerIcon != null) {
            icon.setImageResource(headerIcon)
            icon.visibility = View.VISIBLE
        }

        val maxW = minOf(dp(ctx, widthDp), (viewport(ctx).first * 0.92f).toInt())
        if (dialog is MorphDialog) dialog.setCard(view, maxW) else dialog.setContentView(view)
        // 팝업이 뜨면 화면 읽기가 제목을 먼저 읽어 준다
        androidx.core.view.ViewCompat.setAccessibilityPaneTitle(view, title)
        dialog.setCanceledOnTouchOutside(true)
        if (dialog !is MorphDialog) {
            dialog.window?.apply {
                setLayout(maxW, ViewGroup.LayoutParams.WRAP_CONTENT)
                setGravity(Gravity.CENTER)
            }
        }
        // 뒤 페이지를 흐리게 + 카드를 반투명 유리처럼 (Android 12+ 에서 지원될 때만)
        var glassed = false
        if (preview) {
            // 뒤 페이지가 실시간으로 바뀌는 걸 봐야 하는 팝업(확대/축소 등): 흐림 없이 살짝만 어둡게
            dialog.window?.setDimAmount(0.15f)
        } else if (dialog is MorphDialog && !Blur.supported(ctx)) {
            // 모핑 팝업: 시스템 창 블러를 못 쓰는 기기는 흐림 없이 어둡게만 (어둡기는 펼쳐지는 만큼 서서히 진해진다)
        } else if (Blur.behind(dialog.window, ctx)) {
            view.background = Blur.glass(ctx, bgAttr, dp(ctx, 26).toFloat())
            glassed = true
        }
        if (dialog is MorphDialog) dialog.arm(glassed)
        else dialog.window?.decorView?.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            // 분할 화면에서는 팝업이 뜰 때 앱 창 크기가 아직 옛 값일 수 있다 → 뜬 직후 한 번, 한 프레임 뒤 한 번 다시 맞춘다
            override fun onViewAttachedToWindow(v: View) {
                v.post { relayout(dialog) }
                v.postDelayed({ relayout(dialog) }, 120)
            }
            override fun onViewDetachedFromWindow(v: View) { v.removeOnAttachStateChangeListener(this) }
        })
        return dialog to view
    }

    fun menu(
        ctx: Context,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        headerColor: Int? = null,
        items: List<Item>,
        /** 주면 이 버튼(줄)이 그대로 펼쳐져 팝업이 되고, 닫을 때 다시 그 자리로 접힌다 (MorphDialog) */
        origin: View? = null,
        /** true 면 펼쳐지는 팝업이 가운데가 아니라 origin(눌린 줄) 곁에 뜬다 */
        nearOrigin: Boolean = false,
        /** 주면 손가락을 떼지 않고 끌어 온 채로 항목을 고를 수 있다 (origin 이 있는 팝업에서만 채워진다) */
        handle: DragHandle? = null
    ): Dialog? {
        // 태블릿에서는 누른 버튼 바로 아래에 붙어서 뜬다 (버튼이 펼쳐지는 팝업이면 그쪽이 우선)
        if (origin == null && isTablet(ctx)) {
            recentAnchor(ctx)?.let { a ->
                menuAnchored(ctx, a, title, subtitle, headerIcon, headerColor, items)
                return null
            }
        }
        val (dialog, view) = create(ctx, title, subtitle, headerIcon, headerColor, origin = origin, nearOrigin = nearOrigin)
        val list = view.findViewById<LinearLayout>(R.id.popupList)

        handle?.card = view
        fillRows(ctx, list, items, { dialog.dismiss() }, handle?.rows)
        capListHeight(ctx, view, list, 340)

        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        // 펼쳐지는 팝업(MorphDialog)은 항목이 떠오르는 움직임까지 스스로 하므로 따로 겹쳐 주지 않는다
        if (dialog !is MorphDialog) Motion.stagger(list, 70, 30, 260)
        return dialog
    }


    /** 내용이 화면보다 길면 스크롤 영역 높이를 제한해서 아래 버튼이 밀려나지 않게 한다 (가로 화면은 더 낮게) */
    private fun capListHeight(ctx: Context, view: View, list: LinearLayout, widthDp: Int) {
        val (vw, vh) = viewport(ctx)
        val landscape = vw > vh
        val cap = (vh * (if (landscape) 0.5f else 0.6f)).toInt()
        val widthPx = minOf(dp(ctx, widthDp), (vw * 0.92f).toInt()) - dp(ctx, 16)
        list.measure(
            View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        if (list.measuredHeight > cap) {
            val scroll = view.findViewById<View>(R.id.popupScroll)
            scroll.layoutParams = scroll.layoutParams.apply { height = cap }
        }
    }

    /** 항목 줄들을 목록에 채운다. 항목을 누르면 먼저 onPick(팝업 닫기)을 부르고 그 동작을 실행한다. */
    private fun fillRows(ctx: Context, list: LinearLayout, items: List<Item>, onPick: () -> Unit, rowsOut: MutableList<View>? = null) {
        val inflater = LayoutInflater.from(ctx)
        items.forEach { it0 ->
            val row = inflater.inflate(R.layout.popup_item, list, false)
            val icon = row.findViewById<ImageView>(R.id.itemIcon)
            val label = row.findViewById<TextView>(R.id.itemTitle)
            if (it0.dotColor != null) {
                icon.imageTintList = null
                icon.setImageDrawable(GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(it0.dotColor)
                    setSize(dp(ctx, 16), dp(ctx, 16))
                })
            } else {
                icon.setImageResource(it0.icon)
                if (it0.keepIconColor) icon.imageTintList = null
                if (it0.iconUrl != null) Favicons.apply(icon, it0.iconUrl)
            }
            label.text = it0.label
            if (it0.danger) {
                icon.imageTintList = android.content.res.ColorStateList.valueOf(danger(ctx))
                label.setTextColor(danger(ctx))
            }
            if (it0.sub != null) {
                row.findViewById<TextView>(R.id.itemSub).apply {
                    text = it0.sub
                    visibility = View.VISIBLE
                    if (it0.compactSub) {
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    }
                }
            }
            if (it0.checked) {
                row.findViewById<View>(R.id.itemCheck).visibility = View.VISIBLE
                // 화면 읽기(TalkBack)에서 "✓" 대신 "선택됨"으로 읽히게
                androidx.core.view.ViewCompat.setStateDescription(row, "선택됨")
                row.findViewById<View>(R.id.itemCheck).importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            row.setOnClickListener {
                onPick()
                it0.action()
            }
            list.addView(row)
            rowsOut?.add(row)
        }
    }

    /**
     * 태블릿용: 누른 버튼 바로 아래에 붙어서 뜨는 목록 팝업 (뒤로/앞으로 기록 등).
     * 버튼의 왼쪽 끝에 맞추되 화면 밖으로는 나가지 않고, 남는 높이보다 길면 스크롤된다.
     */
    fun menuAnchored(
        ctx: Context,
        anchor: View,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        headerColor: Int? = null,
        items: List<Item>,
        /** 주면 버튼 아래가 아니라 이 점(창 안 좌표) 바로 아래에 뜬다. 아래 공간이 모자라면 점 위에 뜬다 */
        pointX: Int? = null,
        pointY: Int? = null,
        /** true 면 폭을 좁게 하고 버튼의 오른쪽 끝에 맞춰, 버튼 가운데에서 카드째 펼쳐지고 접힌다 (탭 화면 더보기 등) */
        compact: Boolean = false,
        /** false 면 팝업 뒤를 흐리지 않고 카드를 불투명하게 칠한다 (웹페이지 위에 뜨는 메뉴: 뒤 블러가 웹페이지를 깜빡이게 해서) */
        blurBehind: Boolean = true
    ): PopupWindow {
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null).also { skinOnAttach(it) }
        BetaBadge.set(view.findViewById<TextView>(R.id.popupTitle), title)
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        if (headerColor != null) {
            view.findViewById<ImageView>(R.id.popupIcon).apply {
                setImageDrawable(null)
                setPadding(0, 0, 0, 0)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(headerColor)
                }
                visibility = View.VISIBLE
            }
        } else if (headerIcon != null) {
            view.findViewById<ImageView>(R.id.popupIcon).apply {
                setImageResource(headerIcon)
                visibility = View.VISIBLE
            }
        }
        val list = view.findViewById<LinearLayout>(R.id.popupList)

        val dm = ctx.resources.displayMetrics
        // 창 안 좌표와 창 크기로 계산 (프리폼·팝업 창에서 화면 좌표와 섞이면 위치가 어긋난다)
        val winW = anchor.rootView.width.takeIf { it > 0 } ?: dm.widthPixels
        val winH = anchor.rootView.height.takeIf { it > 0 } ?: dm.heightPixels
        val pt = pointX != null && pointY != null
        // 웹페이지를 꾹 눌러 뜨는 메뉴(pt)는 가로를 좁게, 버튼 아래 붙는 목록은 기존 폭
        val width = minOf(dp(ctx, if (pt) POINT_WIDTH_DP else if (compact) COMPACT_WIDTH_DP else ANCHORED_WIDTH_DP), winW - dp(ctx, 16))
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val gap = dp(ctx, 14) // 손가락이 가리지 않게 누른 곳에서 살짝 띄운다
        val below = if (pt) pointY!! + gap else loc[1] + anchor.height
        val maxH = (winH - below - dp(ctx, 12)).coerceAtLeast(if (pt) dp(ctx, 120) else dp(ctx, 240))

        var pw: PopupWindow? = null
        fillRows(ctx, list, items, { pw?.dismiss() })

        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        var height = minOf(view.measuredHeight, maxH)
        var above = false
        if (pt && winH - below - dp(ctx, 12) < minOf(view.measuredHeight, dp(ctx, 240))) {
            // 누른 곳 아래가 너무 좁으면 위로 띄운다
            above = true
            height = minOf(view.measuredHeight, (pointY!! - gap - dp(ctx, 12)).coerceAtLeast(dp(ctx, 120)))
        }

        // 둥근 카드 모양은 팝업 창 배경이 맡는다 (그림자도 이 모양을 따라간다)
        view.background = null
        val bg = anchoredBackground(ctx, view, glass = blurBehind && Blur.supported(ctx))
        // 꾹 누르기 메뉴는 누른 손가락 자리를 기준으로 열리고 닫히는 전용 창을 쓴다 (창 기본 애니메이션은 끔)
        val popup = PointPopupWindow(view, width, height)
        popup.apply {
            setBackgroundDrawable(bg)
            isOutsideTouchable = true
            elevation = dp(ctx, 10).toFloat()
            animationStyle = 0
        }
        pw = popup
        track(popup)

        // 버튼이 화면 오른쪽 절반에 있으면 버튼 오른쪽 끝에 맞춰서 팝업이 버튼 아래에 자연스럽게 걸리게 한다
        val rightHalf = loc[0] + anchor.width / 2 > winW / 2
        val leftWanted = if (pt) pointX!! - width / 2 else if (rightHalf) loc[0] + anchor.width - width else loc[0]
        val wantLeft = leftWanted.coerceIn(dp(ctx, 8), (winW - width - dp(ctx, 8)).coerceAtLeast(dp(ctx, 8)))
        if (pt) {
            val topY = if (above) pointY!! - gap - height else below
            popup.showAsDropDown(anchor, wantLeft - loc[0], topY - (loc[1] + anchor.height))
        } else {
            popup.showAsDropDown(anchor, wantLeft - loc[0], dp(ctx, 4))
        }
        if (blurBehind) Blur.behindPopup(popup, ctx)
        if (pt) {
            // 손가락이 닿은 점에서 펼쳐진다 (아래가 좁아 위로 뜨면 아래쪽 모서리 기준)
            popup.pivotX = (pointX!! - wantLeft).toFloat().coerceIn(0f, width.toFloat())
            popup.pivotY = if (above) height.toFloat() else 0f
            playPointEnter(popup, list, above)
        } else {
            // 링크 길게 누르기 메뉴와 같은 움직임: 누른 버튼 가운데 아래에서 카드째 펼쳐지고, 닫을 때도 같은 점으로 접힌다
            popup.pivotX = (loc[0] + anchor.width / 2f - wantLeft).coerceIn(0f, width.toFloat())
            popup.pivotY = 0f
            playPointEnter(popup, list, false)
        }
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        return popup
    }

    /** 태블릿이고 [anchor] 버튼이 지금 화면에 보이면 true — 이때는 [panelAnchored] 로 버튼 아래에 붙여 띄울 수 있다 */
    fun canAnchor(ctx: Context, anchor: View?): Boolean =
        anchor != null && isTablet(ctx) && anchor.isAttachedToWindow && anchor.isShown && anchor.width > 0 && anchor.height > 0

    /**
     * [panel] 과 같은 내용(머리말 + 직접 만든 목록 + 아래 버튼)을, 태블릿에서 누른 버튼 바로 아래에 붙여 띄운다.
     * 회색 바탕에 흰 카드를 얹는 메뉴창 색 그대로이고, 남는 높이보다 길면 목록만 스크롤된다.
     * [build] 는 목록을 채우고, 닫는 함수와 "닫힐 때 부를 함수 등록" 함수를 받는다.
     */
    fun panelAnchored(
        ctx: Context,
        anchor: View,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        widthDp: Int = 360,
        secondaryLabel: String? = null,
        onSecondary: ((close: () -> Unit) -> Unit)? = null,
        closeLabel: String = "닫기",
        /** 오른쪽(진한) 버튼을 눌렀을 때 동작. 없으면 그냥 닫는다. 닫는 일은 직접 해야 한다 */
        onClose: ((close: () -> Unit) -> Unit)? = null,
        build: (list: LinearLayout, close: () -> Unit, onDismiss: (() -> Unit) -> Unit) -> Unit
    ): PopupWindow {
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null).also { skinOnAttach(it) }
        BetaBadge.set(view.findViewById<TextView>(R.id.popupTitle), title)
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        if (headerIcon != null) {
            view.findViewById<ImageView>(R.id.popupIcon).apply {
                setImageResource(headerIcon)
                visibility = View.VISIBLE
            }
        }
        val list = view.findViewById<LinearLayout>(R.id.popupList)

        val dm = ctx.resources.displayMetrics
        val winW = anchor.rootView.width.takeIf { it > 0 } ?: dm.widthPixels
        val winH = anchor.rootView.height.takeIf { it > 0 } ?: dm.heightPixels
        val width = minOf(dp(ctx, widthDp), winW - dp(ctx, 16))
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val below = loc[1] + anchor.height
        val maxH = (winH - below - dp(ctx, 12)).coerceAtLeast(dp(ctx, 240))

        var pw: PopupWindow? = null
        var dismissCb: (() -> Unit)? = null
        build(list, { pw?.dismiss() }, { cb -> dismissCb = cb })

        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).apply {
            if (secondaryLabel == null) {
                visibility = View.GONE
                (view.findViewById<View>(R.id.popupOk).layoutParams as LinearLayout.LayoutParams).marginStart = 0
            } else {
                text = secondaryLabel
                setOnClickListener { onSecondary?.invoke { pw?.dismiss() } }
            }
        }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = closeLabel
            setOnClickListener {
                if (onClose != null) onClose.invoke { pw?.dismiss() } else pw?.dismiss()
            }
        }
        ThemeColors.paintPopupFooter(view)

        fun measureAll() = view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        measureAll()
        // 남는 높이보다 길면 목록만 스크롤되게 — 위 머리말과 아래 버튼은 그대로 보인다
        if (view.measuredHeight > maxH) {
            val scroll = view.findViewById<View>(R.id.popupScroll)
            val over = view.measuredHeight - maxH
            scroll.layoutParams = scroll.layoutParams.apply { height = (scroll.measuredHeight - over).coerceAtLeast(dp(ctx, 120)) }
            measureAll()
        }
        val height = minOf(view.measuredHeight, maxH)

        view.background = null
        val bg = anchoredBackground(ctx, view)
        val popup = PointPopupWindow(view, width, height)
        popup.apply {
            setBackgroundDrawable(bg)
            isOutsideTouchable = true
            elevation = dp(ctx, 10).toFloat()
            animationStyle = 0
            setOnDismissListener { dismissCb?.invoke() }
        }
        pw = popup
        track(popup)

        val rightHalf = loc[0] + anchor.width / 2 > winW / 2
        val leftWanted = if (rightHalf) loc[0] + anchor.width - width else loc[0]
        val wantLeft = leftWanted.coerceIn(dp(ctx, 8), (winW - width - dp(ctx, 8)).coerceAtLeast(dp(ctx, 8)))
        popup.showAsDropDown(anchor, wantLeft - loc[0], dp(ctx, 4))
        Blur.behindPopup(popup, ctx)
        popup.pivotX = (loc[0] + anchor.width / 2f - wantLeft).coerceIn(0f, width.toFloat())
        popup.pivotY = 0f
        playPointEnter(popup, list, false)
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        return popup
    }

    /**
     * 목록 대신 직접 만든 내용을 담는 팝업 (현황 화면 등).
     * 내용이 길면 화면의 60% 높이까지만 보이고 그 안에서 스크롤된다.
     * @param secondaryLabel 왼쪽 버튼 글자 (없으면 버튼을 숨김)
     */
    fun panel(
        ctx: Context,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        widthDp: Int = 360,
        secondaryLabel: String? = null,
        onSecondary: ((Dialog) -> Unit)? = null,
        closeLabel: String = "닫기",
        /** 오른쪽(진한) 버튼을 눌렀을 때 동작. 없으면 그냥 닫는다. 닫는 일은 직접 해야 한다 */
        onClose: ((Dialog) -> Unit)? = null,
        /** 뒤 페이지를 흐리지 않고 그대로 보여 준다 (실시간 미리보기가 있는 팝업용) */
        preview: Boolean = false,
        /** 이 카드가 그대로 펼쳐져 팝업이 되고, 닫을 때 다시 그 자리로 접힌다 (예: 새 탭 화면 위젯) */
        origin: View? = null,
        /** 메뉴창처럼 회색 바탕 (안의 카드는 흰색으로) */
        grayBackground: Boolean = false,
        build: (list: LinearLayout, dialog: Dialog) -> Unit
    ): Dialog {
        val (dialog, view) = create(ctx, title, subtitle, headerIcon, null, widthDp, preview, origin, grayBackground)
        val list = view.findViewById<LinearLayout>(R.id.popupList)
        build(list, dialog)

        capListHeight(ctx, view, list, widthDp)

        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).apply {
            if (secondaryLabel == null) {
                visibility = View.GONE
                // 취소 버튼이 없으면 확인 버튼이 꽉 차므로 사이 간격도 없앤다
                (view.findViewById<View>(R.id.popupOk).layoutParams as LinearLayout.LayoutParams).marginStart = 0
            } else {
                text = secondaryLabel
                setOnClickListener { onSecondary?.invoke(dialog) }
            }
        }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = closeLabel
            setOnClickListener { if (onClose != null) onClose(dialog) else dialog.dismiss() }
        }
        ThemeColors.paintPopupFooter(view)
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        return dialog
    }

    /** 닫힘 애니메이션 없이 바로 닫는다 (같은 팝업을 곧바로 다시 띄울 때) */
    fun dismissNow(d: Dialog) {
        if (d is MorphDialog) d.dismissNow() else d.dismiss()
    }

    fun confirm(
        ctx: Context,
        title: String,
        message: String,
        positive: String = "확인",
        danger: Boolean = false,
        onOk: () -> Unit
    ): Dialog {
        val (dialog, view) = create(ctx, title, null, null, null)
        view.findViewById<TextView>(R.id.popupMessage).apply {
            text = message
            visibility = View.VISIBLE
        }
        view.findViewById<View>(R.id.popupScroll).visibility = View.GONE
        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).setOnClickListener { dialog.dismiss() }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = positive
            // 위험한 동작(삭제 등)은 빨간 채움 버튼으로 눈에 띄게
            if (danger) {
                backgroundTintList = android.content.res.ColorStateList.valueOf(danger(ctx))
                setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_on_danger))
            }
            setOnClickListener {
                dialog.dismiss()
                onOk()
            }
        }
        dialog.show()
        return dialog
    }

    /**
     * 페이지가 "나가면 변경사항이 사라질 수 있어요"(beforeunload)라고 물을 때 뜨는 확인 팝업.
     * 웹뷰 기본 창("탐색 확인") 대신 앱 공통 카드 팝업으로 보여 준다.
     * 안전한 선택인 '머무르기'를 오른쪽 진한 버튼으로, '나가기'를 왼쪽 연한 빨간 글자 버튼으로 둔다.
     * 뒤로가기 · 바깥 터치는 '머무르기'로 처리한다. [onDecide] 는 한 번만 불린다 (true = 나가기).
     */
    fun leavePage(ctx: Context, host: String?, onDecide: (leave: Boolean) -> Unit): Dialog {
        val (dialog, view) = create(
            ctx, "이 페이지를 나갈까요?", host?.takeIf { it.isNotBlank() }, R.drawable.ic_warning, null
        )
        view.findViewById<TextView>(R.id.popupMessage).apply {
            text = "저장하지 않은 변경사항은 사라질 수 있어요."
            visibility = View.VISIBLE
        }
        view.findViewById<View>(R.id.popupScroll).visibility = View.GONE
        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        var decided = false
        fun decide(leave: Boolean) {
            if (decided) return
            decided = true
            onDecide(leave)
        }
        view.findViewById<Button>(R.id.popupCancel).apply {
            text = "나가기"
            setTextColor(danger(ctx))
            setOnClickListener { decide(true); dialog.dismiss() }
        }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = "머무르기"
            setOnClickListener { decide(false); dialog.dismiss() }
        }
        dialog.setOnDismissListener { decide(false) }
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        return dialog
    }
}
