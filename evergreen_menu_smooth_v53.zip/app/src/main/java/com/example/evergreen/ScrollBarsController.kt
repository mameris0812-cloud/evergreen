package com.example.evergreen

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 페이지를 스크롤하면 상단 바(탭 줄 · 주소창)와 하단 바가 손가락을 따라 사라지고 나타나는 동작.
 *
 * 핵심은 두 가지를 완전히 나누는 것이다.
 *
 *  1) 크기(레이아웃)는 '미리, 한 번만' 바꾼다.
 *     이 동작을 쓸 수 있는 페이지에서는 웹 영역을 처음부터 화면 전체 높이로 키워 둔다
 *     (바가 보일 때 바 뒤로 가려지는 아래쪽 여백만큼 화면 밖으로 길어진다).
 *     스크롤하는 동안에는 웹 영역의 크기가 절대 바뀌지 않으므로, WebView 가 늘어난 부분을 못 그려서
 *     하단에 흰 줄이 보이는 일도, 크기가 바뀌며 페이지가 흔들리는 일도 없다.
 *
 *  2) 움직임은 translationY 로만 한다.
 *     진행도 f (0 = 모두 보임, 1 = 모두 숨김) 에 맞춰
 *       상단 바 · 진행 막대 · 웹 영역은 위로 T × f, 하단 바는 아래로 H × f 만큼 옮긴다.
 *     translation 은 곧바로 적용되므로 WebView 가 손가락 좌표를 정확히 보정할 수 있어 떨림이 없다.
 *     (레이아웃 여백을 매 프레임 바꾸면 다음 프레임에야 반영되어 좌표가 어긋나 페이지가 부들거린다.)
 *
 * 손가락이 움직이는 동안(PullRefreshLayout 의 중첩 스크롤)에는 바가 움직임을 먼저 쓰고 남는 만큼만 페이지가 스크롤된다.
 * 손가락을 떼면 움직이던 방향으로 끝까지 숨기거나 보여 준다.
 *
 * 크기를 키워 두는 시점: sync() — 이 동작을 쓸 수 있는 상태가 되면 키우고, 못 쓰게 되면(홈 화면, 주소 입력, 찾기 …)
 * 바를 먼저 되돌린 뒤에 줄인다.
 */
class ScrollBarsController(
    /** 위에서부터 차례로 늘어선 상단 바들 (보이지 않는 것은 건너뛴다) */
    private val topBars: () -> List<View>,
    /** 하단 바 (태블릿처럼 없으면 null 이나 보이지 않는 상태) */
    private val bottomBar: () -> View?,
    /** 상단 바와 함께 움직이는 것들 (로딩 막대 등) */
    private val followers: () -> List<View>,
    /** 웹 영역(WebView 를 담은 칸). 세로 LinearLayout 안에서 weight 로 남는 자리를 차지한다 */
    private val webFrame: () -> View?,
    /** 지금 이 동작을 써도 되는 상황인지 (설정, 홈 화면, 주소 입력 중, 찾기 중 …) */
    private val allowed: () -> Boolean,
    private val animationsOn: () -> Boolean,
    /** 화면 맨 위의 상태표시줄 자리 높이 (루트 위 여백). 바가 숨을 때 이 자리도 함께 올려 페이지가 맨 위까지 차지하게 한다 */
    private val statusInset: () -> Int = { 0 },
    /** 바가 모두 숨었을 때 true, 조금이라도 돌아오면 false: 이때 시스템 상태표시줄을 숨기고 보인다 */
    private val onFullyHidden: (Boolean) -> Unit = {},
    /** 화면 맨 아래의 내비게이션 바(제스처 막대) 자리 높이. 하단 바가 숨으면 웹 영역이 이 자리까지 채워 흰 줄이 보이지 않게 한다 */
    private val bottomInset: () -> Int = { 0 }
) {
    private var fullyHidden = false

    /** 0 = 모두 보임, 1 = 모두 숨김 */
    var fraction = 0f
        private set

    private var lastDir = 0
    private var anim: ValueAnimator? = null
    private var touching = false

    /** 웹 영역이 화면 전체 높이로 키워져 있는지 */
    private var grown = false
    private var grownAt = 0L
    private var layoutListener: View.OnLayoutChangeListener? = null
    private var listenedFrame: View? = null

    private fun visibleTops(): List<View> = topBars().filter { it.visibility == View.VISIBLE }

    /** 웹 영역이 화면 맨 위(상태표시줄 자리 포함)에서 얼마나 내려와 있는가 = 위로 올려야 하는 거리 */
    private fun topTravel(): Int {
        val frame = webFrame() ?: return 0
        val first = visibleTops().firstOrNull() ?: return 0
        return max(0, frame.top - first.top) + max(0, statusInset())
    }

    private fun bottomHeight(): Int {
        val b = bottomBar() ?: return 0
        return if (b.visibility == View.VISIBLE) b.height else 0
    }

    /** 웹 영역 아래쪽 여백: 키워 둔 동안은 -(올라가는 거리 + 하단 바 높이) 로 두어 화면 전체 높이가 되게 한다 */
    private fun syncGrownMargin() {
        val frame = webFrame() ?: return
        val lp = frame.layoutParams as? LinearLayout.LayoutParams ?: return
        // 하단 바가 있을 때만 내비게이션 바 자리까지 키운다 (바가 없으면 원래 여백 그대로)
        val navExtra = if (bottomHeight() > 0) max(0, bottomInset()) else 0
        val want = if (grown) -(topTravel() + bottomHeight() + navExtra) else 0
        if (lp.bottomMargin != want) {
            lp.bottomMargin = want
            frame.layoutParams = lp
        }
    }

    /** 진행도를 화면에 반영한다 (translation 만 쓴다) */
    fun apply(f: Float) {
        fraction = f.coerceIn(0f, 1f)
        val up = -topTravel() * fraction
        for (v in topBars()) v.translationY = up
        for (v in followers()) v.translationY = up
        webFrame()?.translationY = up
        bottomBar()?.translationY = bottomHeight() * fraction
        val hidden = fraction >= 1f
        if (hidden != fullyHidden) {
            fullyHidden = hidden
            onFullyHidden(hidden)
        }
    }

    /**
     * 지금 상태에 맞게 웹 영역 크기를 정한다. 상태가 바뀔 때마다 부르면 된다 (여러 번 불러도 안전).
     * 쓸 수 있으면 미리 키워 두고, 못 쓰게 되면 바를 되돌린 뒤 줄인다.
     */
    fun sync() {
        watchFrame()
        if (allowed()) {
            if (!grown) {
                grown = true
                grownAt = android.os.SystemClock.uptimeMillis()
                syncGrownMargin()
                apply(fraction)
            }
        } else if (grown) {
            if (fraction > 0f && !touching) animateTo(0f) else if (fraction <= 0f && !touching) shrink()
        }
    }

    /** 바 높이가 바뀌면(탭 줄이 나타나는 등) 웹 영역 여백도 따라 맞춘다 */
    private fun watchFrame() {
        val frame = webFrame() ?: return
        if (listenedFrame === frame) return
        listenedFrame?.let { old -> layoutListener?.let { old.removeOnLayoutChangeListener(it) } }
        val l = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (grown) {
                syncGrownMargin()
                apply(fraction)
            }
        }
        layoutListener = l
        listenedFrame = frame
        frame.addOnLayoutChangeListener(l)
    }

    private fun shrink() {
        if (!grown) return
        grown = false
        syncGrownMargin()
        apply(fraction)
    }

    /** 레이아웃이 바뀐 뒤 지금 진행도로 다시 맞춘다 */
    fun reapply() {
        if (grown) syncGrownMargin()
        apply(fraction)
    }

    /** 애니메이션 없이 곧바로 모두 보이게 되돌린다 (탭 전환 · 설정 변경 · 화면 구성 변경) */
    fun reset() {
        anim?.cancel()
        anim = null
        lastDir = 0
        grown = false
        syncGrownMargin()
        apply(0f)
    }

    private fun animateTo(target: Float) {
        anim?.cancel()
        if (!animationsOn()) {
            apply(target)
            afterSettled()
            return
        }
        if (fraction == target) {
            afterSettled()
            return
        }
        anim = ValueAnimator.ofFloat(fraction, target).apply {
            duration = (260f * abs(target - fraction)).toLong().coerceAtLeast(140L)
            interpolator = DecelerateInterpolator(1.5f)
            addUpdateListener { apply(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) { if (!cancelled) afterSettled() }
            })
            start()
        }
    }

    /** 바가 멈춘 뒤: 이 동작을 더 쓸 수 없는 상태이고 바가 모두 돌아왔다면 웹 영역을 줄인다 */
    private fun afterSettled() {
        if (fraction <= 0f && !touching && !allowed()) shrink()
    }

    /** 바를 다시 보여 준다 (페이지 이동 · 주소창 선택 · 맨 위 도달 · 찾기 열기 등) */
    fun show(animate: Boolean = true) {
        if (fraction == 0f && anim?.isRunning != true) {
            afterSettled()
            return
        }
        if (animate) animateTo(0f) else {
            anim?.cancel()
            anim = null
            apply(0f)
            afterSettled()
        }
    }

    /** 손가락이 닿았다 */
    fun onTouchStart() {
        anim?.cancel()
        anim = null
        lastDir = 0
        touching = true
    }

    /**
     * 손가락이 dy 만큼 움직였다 (dy > 0 : 내용을 아래로 보는 방향).
     * 바가 쓴 만큼을 돌려주며, 그 부분은 페이지가 스크롤하지 않는다.
     */
    fun onPreScroll(dy: Int): Int {
        if (dy == 0 || !grown || !allowed()) return 0
        // 막 키운 직후에는 WebView 가 새 크기로 그릴 시간을 잠깐 준다
        if (android.os.SystemClock.uptimeMillis() - grownAt < 250L) return 0
        lastDir = if (dy > 0) 1 else -1
        val travel = max(1, topTravel()).toFloat()
        return if (dy > 0) {
            val room = ((1f - fraction) * travel).roundToInt()
            val use = min(dy, room)
            if (use <= 0) return 0
            apply(fraction + use / travel)
            use
        } else {
            val room = (fraction * travel).roundToInt()
            val use = max(dy, -room)
            if (use >= 0) return 0
            apply(fraction + use / travel)
            use
        }
    }

    /** 손가락을 뗐다: 움직이던 방향으로 마저 숨기거나 보여 준다 */
    fun onTouchEnd() {
        touching = false
        if (fraction <= 0f) {
            afterSettled()
            return
        }
        if (fraction >= 1f) return
        animateTo(
            when {
                lastDir > 0 -> 1f
                lastDir < 0 -> 0f
                else -> if (fraction >= 0.5f) 1f else 0f
            }
        )
    }
}
