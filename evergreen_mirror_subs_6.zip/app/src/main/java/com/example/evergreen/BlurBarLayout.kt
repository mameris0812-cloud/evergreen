package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import android.widget.LinearLayout

/**
 * 상단바(탭 줄 · 주소창)와 하단 내비게이션 바용 유리 배경.
 * Android 12(API 31) 이상에서, 바와 맞닿은 웹 페이지 가장자리(위쪽 바는 페이지 맨 위, 아래쪽 바는 페이지 맨 아래)를
 * 흐리게 만들어 바 뒤에 깔고, 바 배경은 반투명으로 만든다. 그 아래 버전에서는 원래 배경 그대로다.
 * 바는 페이지 위에 겹치지 않고 따로 놓여 있으므로(레이아웃은 그대로) 페이지의 맨 위/아래가 바에 가려지지 않는다.
 * 페이지가 스크롤되거나 바뀌면 같이 갱신된다.
 */
class BlurBarLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : LinearLayout(ctx, attrs) {

    /** 흐리게 비출 화면 (웹 페이지가 붙는 영역) */
    var source: View? = null
        set(v) { field = v; invalidate() }

    /** true 면 아래쪽 바 (페이지 맨 아래를 비춘다), false 면 위쪽 바 (페이지 맨 위를 비춘다) */
    var bottomEdge = false

    private val blurOn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    private var node: Any? = null
    private var pending = false
    private var tinted = false
    private val pre = ViewTreeObserver.OnPreDrawListener {
        // 화면이 바뀌는 프레임마다 한 번만 다시 그린다 (우리가 요청한 프레임에서는 또 요청하지 않아 무한 반복을 막는다)
        if (pending) pending = false
        else if (source != null && isShown) { pending = true; invalidate() }
        true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (blurOn) viewTreeObserver.addOnPreDrawListener(pre)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (blurOn && viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(pre)
    }

    override fun draw(canvas: Canvas) {
        if (blurOn && source != null && width > 0 && height > 0 && canvas.isHardwareAccelerated) {
            try {
                if (!tinted) {
                    // 뒤의 흐린 화면이 비치도록 바 배경을 반투명으로 (한 번만)
                    background?.mutate()?.alpha = 0xC4
                    tinted = true
                }
                drawBackdrop(canvas)
            } catch (e: Throwable) { /* 못 그리면 원래 배경 */ }
        }
        super.draw(canvas)
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.S)
    private fun drawBackdrop(canvas: Canvas) {
        val src = source ?: return
        if (src.width <= 0 || src.height <= 0) return
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()
        val w = width + pad * 2
        val h = height + pad * 2
        val rn = (node as? RenderNode) ?: RenderNode("barBlur").also {
            val r = 18f * d
            it.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
            node = it
        }
        rn.setPosition(0, 0, w, h)
        val rc = rn.beginRecording(w, h)
        try {
            // 위쪽 바: 페이지 맨 위가 바 자리에 오도록 / 아래쪽 바: 페이지 맨 아래가 바 자리에 오도록
            val dy = if (bottomEdge) -(src.height - height).toFloat() else 0f
            rc.translate(pad.toFloat(), pad + dy)
            src.draw(rc)
        } finally {
            rn.endRecording()
        }
        canvas.save()
        canvas.clipRect(0, 0, width, height)
        canvas.translate(-pad.toFloat(), -pad.toFloat())
        canvas.drawRenderNode(rn)
        canvas.restore()
    }
}
