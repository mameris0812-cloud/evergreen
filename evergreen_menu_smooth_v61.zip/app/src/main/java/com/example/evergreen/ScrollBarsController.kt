package com.example.evergreen

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.graphics.Rect
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 페이지를 스크롤하면 상단 바(탭 줄 · 주소창)와 하단 바가 손가락을 따라 사라지고 나타나는 동작.
 *
 * 핵심은 두 가지를 완전히 나누는 것이다.
 *
 *  1) 크기(레이아웃)는 '미리, 한 번만' 바꾼다.
 *     이 동작을 쓸 수 있는 페이지에서는 웹 영역을 처음부터 화면 전체 높이로 키워 둔다
 *     (바가 보일 때 바 뒤로 가려지는 아래쪽 여백만큼 화면 밖으로 길어진다).
 *     스크롤하는 동안에는 웹 영역의 크기가 절대 바뀌지 않으므로, WebView 가 늘어난 부분을 못 그려서
 *     하단에 흰 줄이 보이는 일도, 크기가 바뀌며 페이지가 흔들리는 일도 없다.
 *
 *  2) 움직임은 translationY 로만 한다.
 *     진행도 f (0 = 모두 보임, 1 = 모두 숨김) 에 맞춰
 *       상단 바 · 진행 막대 · 웹 영역은 위로 T × f, 하단 바는 아래로 H × f 만큼 옮긴다.
 *     translation 은 곧바로 적용되므로 WebView 가 손가락 좌표를 정확히 보정할 수 있어 떨림이 없다.
 *     (레이아웃 여백을 매 프레임 바꾸면 다음 프레임에야 반영되어 좌표가 어긋나 페이지가 부들거린다.)
 *
 * 손가락이 움직이는 동안(PullRefreshLayout 의 중첩 스크롤)에는 바가 움직임을 먼저 쓰고 남는 만큼만 페이지가 스크롤된다.
 * 손가락을 떼면 움직이던 방향으로 끝까지 숨기거나 보여 준다.
 *
 * 크기를 키워 두는 시점: sync() — 이 동작을 쓸 수 있는 상태가 되면 키우고, 못 쓰게 되면(홈 화면, 주소 입력, 찾기 …)
 * 바를 먼저 되돌린 뒤에 줄인다.
 */
class ScrollBarsController(
    /** 위에서부터 차례로 늘어선 상단 바들 (보이지 않는 것은 건너뛴다) */
    private val topBars: () -> List<View>,
    /** 하단 바 (태블릿처럼 없으면 null 이나 보이지 않는 상태) */
    private val bottomBar: () -> View?,
    /** 상단 바와 함께 움직이는 것들 (로딩 막대 등) */
    private val followers: () -> List<View>,
    /** 웹 영역(WebView 를 담은 칸). 세로 LinearLayout 안에서 weight 로 남는 자리를 차지한다 */
    private val webFrame: () -> View?,
    /** 지금 이 동작을 써도 되는 상황인지 (설정, 홈 화면, 주소 입력 중, 찾기 중 …) */
    private val allowed: () -> Boolean,
    private val animationsOn: () -> Boolean,
    /** 화면 맨 위의 상태표시줄 자리 높이 (루트 위 여백). 바가 숨을 때 이 자리도 함께 올려 페이지가 맨 위까지 차지하게 한다 */
    private val statusInset: () -> Int = { 0 },
    /** 바가 숨기 시작하면 true, 완전히 돌아오면 false: 이때 시스템 상태표시줄을 숨기고 보인다 */
    private val onFullyHidden: (Boolean) -> Unit = {},
    /** 화면 맨 아래의 내비게이션 바(제스처 막대) 자리 높이. 하단 바가 숨으면 웹 영역이 이 자리까지 채워 흰 줄이 보이지 않게 한다 */
    private val bottomInset: () -> Int = { 0 }
) {
    private var fullyHidden = false
    private var lastFraction = 0f

    /** 0 = 모두 보임, 1 = 모두 숨김 */
    var fraction = 0f
        private set

    private var lastDir = 0
    private var oppositeAcc = 0
    private var anim: ValueAnimator? = null
    private var touching = false

    /** 웹 영역이 화면 전체 높이로 키워져 있는지 */
    private var grown = false
    private var grownAt = 0L
    private var layoutListener: View.OnLayoutChangeListener? = null
    private var listenedFrame: View? = null
    private var listenedParent: View? = null

    private fun visibleTops(): List<View> = topBars().filter { it.visibility == View.VISIBLE }

    /** 웹 영역이 화면 맨 위(상태표시줄 자리 포함)에서 얼마나 내려와 있는가 = 위로 올려야 하는 거리 */
    private fun topTravel(): Int {
        val frame = webFrame() ?: return 0
        val first = visibleTops().firstOrNull() ?: return 0
        return max(0, frame.top - first.top) + max(0, statusInset())
    }

    private fun bottomHeight(): Int {
        val b = bottomBar() ?: return 0
        return if (b.visibility == View.VISIBLE) b.height else 0
    }

    /**
     * 웹 영역 크기를 정한다. 키워 둔 동안은 높이를 '남는 자리 + 올라가는 거리 + 하단 바 + 내비게이션 바' 로 직접 지정하고
     * 같은 만큼 아래쪽 여백을 음수로 둔다 (그래야 하단 바는 제자리에 남는다).
     * weight 로 남는 자리를 받게 두면 LinearLayout 이 weight 칸의 음수 여백을 계산에서 빼 버려서
     * 칸이 커지지 않고 하단 바만 위로 밀려 올라간다.
     */
    private fun syncGrownMargin() {
        val frame = webFrame() ?: return
        val lp = frame.layoutParams as? LinearLayout.LayoutParams ?: return
        val parent = frame.parent as? View
        var weight = 1f
        var height = 0
        var margin = 0
        if (grown && parent != null && parent.height > 0) {
            val bar = bottomHeight()
            // 하단 바가 있을 때만 내비게이션 바 자리까지 키운다
            val nav = if (bar > 0) max(0, bottomInset()) else 0
            val extra = topTravel() + bar + nav
            val natural = max(0, parent.height - frame.top - bar)
            weight = 0f
            height = natural + extra
            margin = -extra
        }
        if (lp.weight != weight || lp.height != height || lp.bottomMargin != margin) {
            lp.weight = weight
            lp.height = height
            lp.bottomMargin = margin
            frame.layoutParams = lp
        }
    }

    /**
     * 키워 둔 웹 영역은 하단 바 아래 내비게이션 바 자리까지 내려가 있으므로, 바가 보이는 동안(f=0)에는 그 자리를 잘라 내고
     * 바가 숨는 만큼 잘라 낸 부분을 열어 준다. 그러면 흰 줄이 갑자기 사라지지 않고 페이지가 부드럽게 채워진다.
     */
    private fun updateClip() {
        val frame = webFrame() ?: return
        val parent = frame.parent as? View
        if (!grown || parent == null || parent.height <= 0 || frame.width <= 0) {
            if (frame.clipBounds != null) frame.clipBounds = null
            return
        }
        val bar = bottomHeight()
        val nav = if (bar > 0) max(0, bottomInset()) else 0
        val natural = max(0, parent.height - frame.top - bar)
        // 내비게이션 바 자리는 하단 바가 내려가는 속도에 맞춰(바 높이만큼 내려가는 동안) 부드럽게 열어 준다.
        // 바가 이미 그 자리를 지나갔는데 흰 줄만 늦게 사라지는 일이 없도록, 전체 진행도가 아니라 바 이동량 기준이다.
        val t = if (nav > 0) min(1f, fraction * bar / nav) else 1f
        val navOpen = nav * (t * t * (3f - 2f * t))
        val bottom = natural + bar + (topTravel() * fraction + navOpen).roundToInt()
        val cur = frame.clipBounds
        if (cur == null || cur.bottom != bottom || cur.right != frame.width) {
            frame.clipBounds = Rect(0, 0, frame.width, bottom)
        }
    }

    /** 진행도를 화면에 반영한다 (translation 만 쓴다) */
    fun apply(f: Float) {
        fraction = f.coerceIn(0f, 1f)
        val up = -topTravel() * fraction
        for (v in topBars()) v.translationY = up
        for (v in followers()) v.translationY = up
        webFrame()?.translationY = up
        bottomBar()?.translationY = bottomHeight() * fraction
        // 스크롤로 숨기기 시작하면(2% 이상) 상태표시줄도 같이 숨기고, 바가 완전히 돌아오면 보인다 (실수 오차로 1f 에 못 닿는 경우 방지)
        updateClip()
        // 숨길 때는 2% 만 움직여도 상태표시줄을 숨기고, 바가 내려오기 시작하면(85% 아래) 바로 다시 보여 준다.
        // 바가 다 내려온 뒤에야 시계 줄이 툭 나타나지 않고 바와 함께 내려오게 하려는 것이다.
        val delta = fraction - lastFraction
        val movingUp = delta > 0.002f
        val movingDown = delta < -0.002f
        if (movingUp || movingDown) lastFraction = fraction
        val hidden = when {
            fraction <= 0.005f -> false
            movingUp -> if (fraction > 0.02f) true else fullyHidden
            movingDown -> if (fraction < 0.85f) false else fullyHidden
            else -> fullyHidden
        }
        if (hidden != fullyHidden) {
            fullyHidden = hidden
            onFullyHidden(hidden)
        }
    }

    /**
     * 지금 상태에 맞게 웹 영역 크기를 정한다. 상태가 바뀔 때마다 부르면 된다 (여러 번 불러도 안전).
     * 쓸 수 있으면 미리 키워 두고, 못 쓰게 되면 바를 되돌린 뒤 줄인다.
     */
    fun sync() {
        watchFrame()
        if (allowed()) {
            if (!grown) {
                grown = true
                grownAt = android.os.SystemClock.uptimeMillis()
                syncGrownMargin()
                apply(fraction)
            }
        } else if (grown) {
            if (fraction > 0f && !touching) animateTo(0f) else if (fraction <= 0f && !touching) shrink()
        }
    }

    /** 바 높이가 바뀌면(탭 줄이 나타나는 등) 웹 영역 여백도 따라 맞춘다 */
    private fun watchFrame() {
        val frame = webFrame() ?: return
        if (listenedFrame === frame) return
        layoutListener?.let { old ->
            listenedFrame?.removeOnLayoutChangeListener(old)
            listenedParent?.removeOnLayoutChangeListener(old)
        }
        val l = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (grown) {
                syncGrownMargin()
                apply(fraction)
            }
        }
        layoutListener = l
        listenedFrame = frame
        frame.addOnLayoutChangeListener(l)
        // 키보드 · 회전 등으로 부모 크기가 바뀔 때도 다시 맞춘다
        (frame.parent as? View)?.let { it.addOnLayoutChangeListener(l); listenedParent = it }
    }

    private fun shrink() {
        if (!grown) return
        grown = false
        syncGrownMargin()
        apply(fraction)
    }

    /** 레이아웃이 바뀐 뒤 지금 진행도로 다시 맞춘다 */
    fun reapply() {
        if (grown) syncGrownMargin()
        apply(fraction)
    }

    /** 애니메이션 없이 곧바로 모두 보이게 되돌린다 (탭 전환 · 설정 변경 · 화면 구성 변경) */
    fun reset() {
        anim?.cancel()
        anim = null
        lastDir = 0
        grown = false
        syncGrownMargin()
        apply(0f)
    }

    private fun animateTo(target: Float) {
        anim?.cancel()
        if (!animationsOn()) {
            apply(target)
            afterSettled()
            return
        }
        if (fraction == target) {
            afterSettled()
            return
        }
        anim = ValueAnimator.ofFloat(fraction, target).apply {
            if (target <= 0f) {
                // 다시 내려올 때: 더 천천히, 시작은 빠르고 끝은 길게 잦아드는 곡선 (툭 떨어지는 느낌을 없앤다)
                duration = (460f * abs(target - fraction)).toLong().coerceAtLeast(300L)
                interpolator = PathInterpolator(0.22f, 0.0f, 0.0f, 1.0f)
            } else {
                duration = (260f * abs(target - fraction)).toLong().coerceAtLeast(140L)
                interpolator = DecelerateInterpolator(1.5f)
            }
            addUpdateListener { apply(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) { if (!cancelled) afterSettled() }
            })
            start()
        }
    }

    /** 바가 멈춘 뒤: 이 동작을 더 쓸 수 없는 상태이고 바가 모두 돌아왔다면 웹 영역을 줄인다 */
    private fun afterSettled() {
        if (fraction <= 0f && !touching && !allowed()) shrink()
    }

    /** 바를 다시 보여 준다 (페이지 이동 · 주소창 선택 · 맨 위 도달 · 찾기 열기 등) */
    fun show(animate: Boolean = true) {
        if (fraction == 0f && anim?.isRunning != true) {
            afterSettled()
            return
        }
        if (animate) animateTo(0f) else {
            anim?.cancel()
            anim = null
            apply(0f)
            afterSettled()
        }
    }

    /** 손가락이 닿았다 */
    fun onTouchStart() {
        anim?.cancel()
        anim = null
        lastDir = 0
        oppositeAcc = 0
        touching = true
    }

    /**
     * 손가락이 dy 만큼 움직였다 (dy > 0 : 내용을 아래로 보는 방향).
     * 바가 쓴 만큼을 돌려주며, 그 부분은 페이지가 스크롤하지 않는다.
     */
    fun onPreScroll(dy: Int): Int {
        if (dy == 0 || !grown || !allowed()) return 0
        // 막 키운 직후에는 WebView 가 새 크기로 그릴 시간을 잠깐 준다
        if (android.os.SystemClock.uptimeMillis() - grownAt < 250L) return 0
        // 방향은 '반대로 충분히 움직였을 때'만 바꾼다. 손가락을 뗄 때 생기는 1~3px 역방향 떨림 때문에
        // 살짝 숨기다 놓았는데 바가 도로 내려오는 일을 막는다.
        val dir = if (dy > 0) 1 else -1
        if (lastDir == 0 || dir == lastDir) {
            lastDir = dir
            oppositeAcc = 0
        } else {
            oppositeAcc += abs(dy)
            if (oppositeAcc >= DIR_FLIP_PX) {
                lastDir = dir
                oppositeAcc = 0
            }
        }
        val travel = max(1, topTravel()).toFloat()
        return if (dy > 0) {
            val room = ((1f - fraction) * travel).roundToInt()
            val use = min(dy, room)
            if (use <= 0) return 0
            apply(fraction + use / travel)
            use
        } else {
            val room = (fraction * travel).roundToInt()
            val use = max(dy, -room)
            if (use >= 0) return 0
            apply(fraction + use / travel)
            use
        }
    }

    /** 손가락을 뗐다: 움직이던 방향으로 마저 숨기거나 보여 준다 */
    fun onTouchEnd() {
        touching = false
        if (fraction <= 0f) {
            afterSettled()
            return
        }
        if (fraction >= 1f) return
        animateTo(
            when {
                lastDir > 0 -> 1f
                lastDir < 0 -> 0f
                else -> if (fraction >= 0.5f) 1f else 0f
            }
        )
    }

    private companion object {
        /** 이만큼(px) 이상 반대로 움직여야 숨김/보임 방향이 바뀐다 */
        const val DIR_FLIP_PX = 24
    }
}
