# evergreen v2.2

WebView 기반의 안드로이드 브라우저 앱입니다.

## 작업 규칙

### 업데이트 로그 (`Changelog.kt`) 작성 규칙
업데이트 로그는 **일반 사용자가 읽는 글**입니다. 개발자용 내용은 넣지 않고, 사용자가 체감하는 굵직한 변화만 적습니다.

- **넣는 것**: 새로 생긴 기능, 눈에 띄게 달라진 동작·화면, 사용자가 겪던 문제를 고친 것
- **빼는 것**: 빌드 오류 수정 · 클래스/함수/파일 이름 · 내부 원인 설명 · 수치 튜닝(스프링 강성·ms·dp 등) · 리팩터링 · 권한/설정 파일 변경 · 롤백 같은 개발 과정 이야기
- **쓰는 법**: 항목은 한두 문장, 쉬운 말로 "무엇이 어떻게 달라졌는지"만 적습니다. 사용자에게 보이는 변화가 없으면 항목을 만들지 않습니다.
- 정리된 규칙 외 상세한 기술 내용은 이 README 에 남깁니다.
- 이 규칙을 만들거나 고치는 것처럼 앱 기능과 무관한 작업은 **버전을 올리지 않고, 업데이트 로그에도 넣지 않습니다.**

## 기능

**홈 화면 검색 위젯 추가 (v3.8.91)**
- `SearchWidgetProvider`(AppWidgetProvider) + `res/xml/search_widget_info.xml` + `res/layout/widget_search.xml`. 4×2 칸 기본, 가로·세로 크기 조절 가능(`minResizeHeight` 56dp). 위젯 이름은 `widget_label`(evergreen 검색).
- 위쪽 알약 검색창 → `WEB_SEARCH`, 아래 버튼 셋 → `NEW_TAB` · `NEW_INCOGNITO` · `BOOKMARKS`. 런처 바로가기(shortcuts.xml)와 같은 액션이라 `MainActivity.handleAppShortcut` 을 그대로 탐(콜드 스타트는 `onCreate`, 실행 중이면 `onNewIntent` → `handleIncomingIntent`). 위젯 쪽은 `setClassName` + `FLAG_ACTIVITY_NEW_TASK`, `PendingIntent` 는 `FLAG_IMMUTABLE`, 버튼마다 requestCode 가 다름(1~4).
- 위젯은 `?attr` 를 못 쓰므로 `widget_bg`/`widget_search_bg`/`widget_btn_bg` 는 `@color/ev_*` 만 사용 → `values-night` 로 다크 모드 자동 대응. 아이콘은 `android:tint`.
- 높이가 90dp 미만으로 줄면 `onAppWidgetOptionsChanged` 에서 버튼 줄(`widget_actions`)을 숨기고 검색창만 남김. `updatePeriodMillis=0`(내용이 변하지 않음).
- 미리보기: 안드로이드 12+ 는 `previewLayout`, 그 미만은 `widget_preview` 정적 그림. 아직 실기기 확인 전.

**상/하단바 AI 버튼 애니메이션 새로 만듦: 피어남 (v3.8.90)**
- 이전 안(큰 별이 오므라들었다 부풀며 작은 별·작은 반짝임 둘이 뜸, 3.8.88 로 내려보내지 않고 폐기)을 버리고 `MorphIconDrawable` 의 `ai` 를 다시 설계. v3.8.89 에 있던 바깥으로 퍼지는 파동은 요청으로 뺌.
- 누르는 동안(`holdLevel` 0.5): 별이 12% 작아지며 둥글게 오므라듦(`buildBigStar(m)`: 별 ↔ 같은 네 꼭짓점의 타원, 곡선 조절점을 `m` 으로 섞음, `m` > 1 이면 꼭지가 더 뾰족).
- 떼면(`play`): `swap`(0→1, `AI_MS`=900ms 시계)이 흐름을 정함 — 0~0.16초 씨앗(크기 0.3, 타원)으로 모임(세제곱 가속), 이후 감쇠 진동 `x = 1 − e^-6.5τ·cos 10τ` 으로 크기(0.3→1)와 모양(`m`)이 같이 피어나며 최대 13% 넘침, 속이 최대 18% 로 채워졌다 빔(glow), 작은 별은 0.14~0.7초에 `sin(π·u^0.55)` 로 톡 튀어 올랐다 천천히 돌아옴(최대 55%).
- 피어나는 중에 또 누르면 모양은 건드리지 않고(`press` 가드) 떼면 처음부터 다시. 돌거나 기울지 않는 규칙은 그대로. 작은 반짝임 둘과 파동은 없음.

**AI 어시스턴트 버튼: 열려 있으면 닫기 (v3.8.87)**
- `AssistantUi.show` 의 토글 조건을 `splitPanel != null` → `isOpen()`(분할 패널·팝업·시트) 으로 넓힘. 팝업은 바깥 터치가 AI 버튼까지 전달돼서 `show()` 가 `closeChat(false)` 후 다시 열기만 했음. `anchor != null && prefill 없음` 일 때만 닫으므로 「AI에게 물어보기」·모드 전환 재열기(`closeNow()` 뒤라 `isOpen()` 거짓)는 그대로. 닫는 중(`closingPopup`)에 또 눌러도 `closeChat` 이 그대로 둬서 다시 열리지 않음.

**자동 스크롤 웹툰 끝 멈춤 추가 거리 32dp → 310dp (v3.8.86)**
- v3.8.84 의 `END_EXTRA_DP` 를 310 으로. 실기기 화면(네이버 웹툰, 태블릿)에서 기존 멈춤 자리(마지막 컷 크레딧이 보이는 자리)와 원하는 자리(별점·좋아요 칸이 위로 올라온 자리)의 차이가 화면 453px ≈ 310dp(탭 줄 44dp = 64px 로 환산, 밀도 ≈ 1.45)였음. 끝 확인 시점부터 이만큼 더 내려간 뒤 멈춤.

**팝업 창에서 메뉴 「새 창」 설명의 '분할' 글씨 제거 (v3.8.85)**
- 메뉴의 `newWindowRow` 부제를 `isFloatingWindow()` 이면 "전체 · 팝업 중에 골라 한 개 더 띄웁니다", 아니면 기존 "전체 · 분할 · 팝업 …" 으로 표시 (선택 팝업의 분할 항목은 v3.8.83 에서 이미 뺌).

**자동 스크롤 웹툰 끝 멈춤: 조금 더 아래에서 멈춤 (v3.8.84)**
- 끝 감지(`probeWebtoonEnd`)가 두 번 연속 끝으로 읽히면 바로 `pauseAtEnd` 하던 것을, `endExtraPx = dp(END_EXTRA_DP=32)` 만큼 더 내려간 뒤 `finishWebtoonEnd()` 로 멈추게 변경. `onFrame` 에서 실제로 스크롤된 거리만큼 `endExtraPx` 를 깎고, 더 못 내려가면(페이지 끝) 남은 거리를 기다리지 않고 바로 멈춤. 위로 `END_REARM_PX` 이상 올라가거나 사용자가 일시정지/이어가기·새 페이지 이동 시 대기 중인 거리는 0 으로 초기화.
**팝업 창에서는 새 창 선택에 분할 항목을 뺌 (v3.8.83)**
- v3.8.82(팝업 창을 저장 후 전체 화면으로 다시 열고 옆에 새 창을 붙이는 `splitFromFloatingWindow`)는 창을 다시 여는 방식이라 영상·입력이 끊겨 제거. 떠 있는 창(`isFloatingWindow()`: 멀티윈도우 + `floatingWindowBounds() != null`)에서는 `LAUNCH_ADJACENT` 가 무시돼 분할이 안 되므로 `chooseNewWindowMode` 가 「분할 화면」 항목을 목록에서 뺌(전체 화면·팝업 창만). 실기기 확인 전
**분할 화면에서도 새 창 전체 화면·팝업이 고른 방식으로 열림 (v3.8.81)**
- 창이 분할(멀티윈도우)일 때 `startActivity` 로 `ADJACENT` 없이 열면 시스템이 새 작업을 출발 작업과 같은 분할 칸에 넣어서, `windowingMode`(전체 1·자유 창 5) 요청이 무시되고 분할로 열렸음. `openNewWindow` 에서 `mode` 가 `WIN_FULL`·`WIN_POPUP` 이고 `isInMultiWindowMode` 이면 `applicationContext.startActivity(NEW_TASK 추가)` 로 열어 출발 작업을 없앰(분할 칸 상속 방지). 예외가 나면 예전처럼 `startActivity`. 기기가 자유 창을 지원하지 않으면 팝업은 여전히 전체로 열릴 수 있음. 실기기 확인 전
**탭 화면 「＋ 새 창」 팝업: 바깥을 눌러 닫을 때 새 칩으로 접힘 (v3.8.80)**
- v3.8.78(고른 뒤 접힘이 끝나야 새 창을 여는 방식)은 되돌림. 진짜 원인은 `refreshWindowStrip()` 이 `box.removeAllViews()` 로 칩을 전부 다시 만들어, 팝업이 떠 있는 동안 눌렀던 「＋ 새 창」 칩(`origin`)이 화면에서 떨어져 나가는 것. 그러면 `MorphDialog.locateOrigin()` 이 접혀 들어갈 자리를 못 찾아 '제자리에서 90%로 줄며 사라지는' 대체 동작으로 빠졌음.
- `MorphDialog.origin` 을 `var` 로 바꾸고 `rebindOrigin(newOrigin)` 추가(옛 칩 복원 → 새 칩을 이어받아 INVISIBLE). `MainActivity.newWindowDialog` 로 떠 있는 팝업을 기억해 두고, `refreshWindowStrip()` 이 새 「＋ 새 창」 칩을 만든 직후 호출. 닫히는 중(`closing`)이면 건드리지 않음. 실기기 확인 전. (v3.8.79 는 `origin` 을 `var` 로 바꾼 뒤 `snapshotOrigin()` 의 스마트 캐스트 컴파일 오류로 빌드 실패 → 지역 변수 `o` 로 한 번만 읽도록 고쳐 v3.8.80)
**새 창 선택 팝업 줄 곁 배치는 태블릿(screenWidthDp ≥ 600)에서만 (v3.8.77)**
- v3.8.76 의 `nearOrigin` 을 `Popup.create` 에서 `nearOrigin && isTablet(ctx)` 로 제한. 폰은 v3.8.75 처럼 줄에서 출발해 가운데로 펼쳐짐. 실기기 확인 전
**새 창 선택 팝업이 누른 줄 곁에 뜸 (v3.8.76)**
- v3.8.75 의 모핑 팝업이 줄에서 출발해 화면 '가운데'로 펼쳐지던 것을, 누른 줄 곁에서 끝나게 변경. `MorphDialog(nearOrigin = true)`: 카드를 `TOP|START` + 마진으로 놓고, 첫 레이아웃 뒤 `placeNearOrigin()` 이 줄의 가로 가운데 · 줄 윗변부터 아래로 자리를 잡음(아래가 모자라면 줄 아랫변에 맞춰 위로, 시스템바 안쪽 12dp 여백으로 clamp). `Popup.menu/create` 에 `nearOrigin` 추가, `chooseNewWindowMode` 만 true. 새 탭 개인정보 카드 팝업은 그대로 가운데. 실기기 확인 전
**새 창 선택: 누른 줄이 팝업으로 변형 (v3.8.75)**
- v3.8.74 의 `menuAnchored`(점에서 펼쳐짐)를 `Popup.menu(origin = 눌린 줄)` → `MorphDialog`(컨테이너 트랜스폼: 크기·위치·모서리·색이 한 스프링으로 변하고 닫을 때 그 줄로 접힘)로 교체. `Popup.menu` 에 `origin` 매개변수 추가(주면 태블릿 앵커 팝업·`Motion.stagger` 는 건너뜀). 애니메이션을 끄거나 줄을 못 쓰면 가운데 팝업. 실기기 확인 전
**새 창 선택이 누른 자리에서 펼쳐지는 팝업 (v3.8.74)**
- v3.8.73 의 가운데 대화상자를 `Popup.menuAnchored`(누른 점에서 카드째 펼쳐지고 접히는 기존 팝업)로 교체. 메뉴의 「새 창」 줄은 메뉴를 닫지 않고 그 줄 자리에서 팝업을 띄우고, 고르면 메뉴를 닫은 뒤 새 창을 연다. 아래 공간이 모자라면 위로 뜬다. 창 목록의 「＋ 새 창」도 같은 방식. 앵커를 못 쓰면 `Popup.menu`(가운데 팝업). 아이콘 `ic_window_full`, `ic_window_split` 추가, 팝업은 `ic_pip`. 실기기 확인 전
**새 창 열기 방식 선택: 전체 · 분할 · 팝업 (v3.8.73)**
- 메뉴 > 새 창(과 창 목록의 「＋ 새 창」)을 누르면 `chooseNewWindowMode()` 대화상자. 전체 = `WIN_FULL`(ADJACENT 없이, 전체 화면 모드 요청), 분할 = 기존 기본(ADJACENT), 팝업 = `WIN_POPUP`(화면 중앙 자유 창). 시스템이 모드 요청을 무시하면 평소처럼 열림. 실기기 확인 전
**창 최대 5개, 넘으면 가장 먼저 연 창 자동 정리 (v3.8.72)**
- `MainActivity.MAX_WINDOWS = 5`. 새 창이 만들어질 때(`onCreate`) 떠 있는 창이 5개를 넘으면 `openSeq`(연 순서)가 가장 작은 창을 `finishAndRemoveTask()` 로 닫고 안내 토스트를 띄움. 닫힌 창의 탭은 기존 창 닫기와 같이 보존. 대표(primary) 창이 정리 대상이면 새 창이 대표를 이어받음. `openSeq` 는 `onSaveInstanceState` 로 보존. 실기기 확인 전
**작업 표시줄 새 창: 크롬과 같은 진입점 구조 (v3.8.71)**
- 크롬 158 APK 매니페스트 분석: 런처 진입점이 중계 창이 아니라 `activity-alias`(`Main`) 로 실제 화면(`ChromeTabbedActivity`)을 바로 가리키고, 그 화면은 `launchMode=singleTask` + 메타데이터 `android.activity.launch_mode=singleInstancePerTask`, 멀티 인스턴스 속성은 별칭·화면 양쪽에 있음.
- 같은 구조로 변경: `LauncherActivity` 중계 창 삭제, 같은 이름의 `activity-alias` 가 `MainActivity` 를 바로 가리킴(이미 고정한 아이콘 호환). `MainActivity` 는 singleTask + singleInstancePerTask 메타데이터. 바로가기(shortcuts) 메타데이터는 별칭으로 이동. 실기기 확인 전
**작업 표시줄 새 창: 놓은 쪽에 새 창 (v3.8.70)**
- 영상 확인: 작업 표시줄에서 아이콘을 오른쪽에 놓으면 시스템이 떠 있던 작업을 오른쪽으로 옮기고 새 창은 반대쪽(왼쪽)에 열렸음. `LauncherActivity` 가 기존 작업 위에 만들어지는(`isTaskRoot` false) 경우, 새 창을 `LAUNCH_ADJACENT` 없이 같은 자리에 별개 작업으로 띄우고, 떠 있던 창은 `NEW_TASK|LAUNCH_ADJACENT` 로 반대쪽에 붙여 앞으로 가져옴. 실기기 확인 전
**작업 표시줄 새 창: 중계 창이 직접 새 창을 띄움 (v3.8.68, 버전만 3.8.69 로 올림)**
- 문서(Android 15 멀티 인스턴스)상 시스템 UI 는 런처 MAIN 인텐트를 NEW_TASK/MULTIPLE_TASK/LAUNCH_ADJACENT 로 새 작업에 요청하는 방식. v3.8.67 은 떠 있는 창(`host.openNewWindow()`)을 거쳐 새 창을 열어, 시스템이 방금 만든 작업 대신 기존 창이 움직이는 것처럼 보일 수 있었음. 이제 `LauncherActivity` 가 `MainActivity.openWindowFromLauncher(this)` 로 자기 컨텍스트에서 `BrowserWindowActivity` 를 NEW_DOCUMENT|MULTIPLE_TASK|LAUNCH_ADJACENT 로 직접 띄움 (실패 시 기존 방식으로 대체). 실기기 확인 전
**작업 표시줄 새 창: 플래그 없이도 새 창 (v3.8.67)**
- v3.8.66 에서 "이미 실행 중" 메시지는 사라졌지만 새 창 대신 기존 창이 움직임. 삼성 작업 표시줄이 MULTIPLE_TASK/LAUNCH_ADJACENT 플래그 없이 런처를 실행해 `LauncherActivity` 가 `MainActivity` 를 같은 작업에 열었기 때문. 이제 중계 창이 만들어졌을 때 떠 있는 창이 있으면(평범한 아이콘 탭은 시스템이 중계 창 없이 기존 작업을 앞으로 가져옴) 플래그와 무관하게 `openWindowFromLauncher()` 로 새 창을 띄움. 실기기 확인 전

**런처 중계 창 `LauncherActivity` (v3.8.66)**
- 크롬·삼성 인터넷은 되는데 에버그린만 작업 표시줄에서 끌어다 놓을 때 "이미 실행 중입니다" 가 떠서, 런처 진입점(MAIN/LAUNCHER)을 실제 화면 `MainActivity` 에서 화면 없는 중계 창 `LauncherActivity` 로 옮김. 중계 창은 `onCreate` 에서 바로 끝남: 새 창 요청(MULTIPLE_TASK/LAUNCH_ADJACENT)이고 떠 있는 창이 있으면 `MainActivity.openWindowFromLauncher()` 로 새 창을 옆에 띄우고, 아니면 `MainActivity` 를 연다. 이미 떠 있을 때 아이콘 탭은 시스템이 기존 작업을 앞으로 가져옴. 바로가기·공유·링크 열기는 그대로 `MainActivity`. 실기기 확인 전

**작업 표시줄 끌어다 놓기 "이미 실행 중입니다" 재시도 (v3.8.65)**
- 시스템(삼성)이 앱에 닿기 전에 막는 메시지라 앱 코드로는 못 고침. 매니페스트만 보강: MainActivity 에 `launchMode="standard"` 명시, 삼성 멀티 인스턴스 메타데이터 키 변형(`com.samsung.android.multiwindow.multi_instance`, `...multiwindow.multiinstance.enable`)과 `android.allow_multiple_resumed_activities` 추가. 실기기(One UI 8 / Android 16) 확인 전

**꾹 누르기 메뉴 동안 자동 스크롤 멈춤 (v3.8.64)**
- `AutoScroller.holdForMenu(hold)` + `menuHold` 플래그. `showLinkMenu` 가 메뉴를 띄울 때 true, 메뉴 `setOnDismissListener` 에서 false. 메뉴가 떠 있는 동안은 손을 뗀 뒤에도 `onFrame` 이 스크롤·웹툰 끝 감지를 건너뛰고, 닫히면 `RESUME_DELAY_MS` 뒤 이어서 흐름. 자동 스크롤이 안 돌 땐 무시. 빌드 전

**웹툰 끝 서서히 정지 (v3.8.63)**
- 조작 막대(`pill`) 없이 웹툰 끝 감지 시 `endFadeStart` 로 `END_FADE_MS`(900ms) 동안 속도를 (1-t)² 로 줄인 뒤 `stop(null)`. 정지 토스트 제거(웹툰 끝·페이지 끝 정지 모두; "자동 스크롤할 수 없어요"는 유지). 화면을 만지면 감속 취소. 빌드 전

**조작 막대 꺼짐 시 웹툰 끝 정지 (v3.8.62)**
- 동작은 v3.8.60 부터 이미 그랬음(`probeWebtoonEnd`: `pill` 없으면 `stop`). 설정 토글 설명만 조작 막대 꺼짐일 때 "일시정지 대신 정지"로 보이게 수정.

**웹툰 끝 일시정지 옵션 (v3.8.61)**
- `Prefs.autoScrollPauseAtWebtoonEnd`(기본 true) + 설정 > 자동 스크롤 「웹툰 끝에서 일시정지」 토글. 꺼지면 `AutoScroller.onFrame` 이 `probeWebtoonEnd` 를 돌리지 않아 웹툰 끝 감지·일시정지를 건너뜀. 페이지 맨 끝(스크롤 더 못 내려감)에서의 일시정지/정지는 그대로. 빌드·실기기 확인 전

**웹툰 끝 자동 멈춤이 안 되던 문제 (v3.8.60)**
- `END_PROBE_JS`: (1) 아직 안 불러온 지연 로딩 그림이 페이지 어디에든 있으면 9999 를 돌려 끝으로 못 보던 것 → 본문 끝 `b` 에서 400px 이내(+화면 중간보다 아래)의 미로딩 그림만 센다(`P` 배열). 댓글·추천 썸네일이 data-src/lazy 면 영원히 안 멈추던 원인. (2) 컷 폭 기준 `W*0.6` → `TW=min(W*0.6, 480)`: PC 모드(창 폭이 큰 페이지)에서 컷이 60% 미만이라 웹툰으로 안 보던 것 보정.
- `AutoScroller.onFrame`: 끝 감지를 조작 막대(`pill`) 유무와 상관없이 돌리고, 막대가 없으면 일시정지 대신 `stop`. 노드로 JS 문법만 확인, 실기기 확인 전
**AI 버튼이 계속 분할로 열리던 문제 (v3.8.59)**
- 원인: 분할 패널을 끌어 떼면(`lift`) `split=false` 로 바뀌는데, 놓을 때 터치가 CANCEL 로 끊기면 `splitDragListener` 가 `zone = side` 로 `dockSplit` 을 호출해 `split=true` 로 되돌렸음 → 다음 AI 버튼이 `showSplit`. CANCEL 은 이제 `undockToPopup`. 또 `snapZone` 이 지난 끌기 값으로 남아 그냥 눌렀다 떼도 붙을 수 있어 `lift`·팝업 끌기 DOWN 에서 0 으로 초기화. 실기기 확인 전
**「AI에게 물어보기」 바로 전송 (v3.8.58)**
- `AssistantUi.show(..., autoSend: Boolean = false)` 추가. `autoSend` 이고 `prefill` 이 있으면 창을 연 뒤 `ui.post { send(prefill) }`. 사진 첨부는 `send` 안의 `attachLoading` 대기 로직으로 다 받은 뒤 전송됨. Gemini 키가 없으면 `send` 가 설정 안내를 띄우고 질문은 입력창에 남음. 꾹 누르기 메뉴(링크·이미지)와 글자 선택 팝업 두 호출부(`MainActivity`)에서 `autoSend = true`. 빌드·실기기 확인 전

**글자 선택 메뉴 '웹 검색' (v3.8.57)**
- `NestedWebView.onWebSearch` + `AskAiCallback` 에 `WEB_SEARCH_ID` 항목 추가(「AI에게 물어보기」 옆). 누르면 선택한 글을 JS 로 읽어 `MainActivity` 가 `prefs.currentEngine().url(query)` 를 새 탭(`createTab`, 현재 탭이 시크릿이면 시크릿 유지)으로 연다. 300자까지. 실기기 확인 전

**웹툰 끝 감지 보강 (v3.8.56)**
- `END_PROBE_JS` 재작성: 폭 60%↑·높이 40px↑ 의 img/canvas(없으면 배경그림 요소 최대 1500개)를 세로 간격 250px 이내로 묶어 가장 큰 덩어리(3장↑ 또는 화면 3배↑)의 아래 끝을 본문 끝으로 봄. 높이 200px 미만 얇은 컷·긴 그림 1장·배경그림 뷰어도 감지. 아래에 아직 안 불러온 그림이 있으면 9999 를 돌려 끝으로 보지 않음. 끝이 -300~900px 이내면 확인 주기를 200ms 로 줄여 지나침을 줄임(`endNextMs`).
- `AutoScroller.onPageNavigate`: 일시정지 중 새 페이지로 넘어가면 `stop` 대신 끝 상태만 초기화하고 막대 유지(`MainActivity.onPageStarted`). 흐르는 중이면 전처럼 stop. 실기기 확인 전

**웹툰 끝 감지 후 일시정지 (v3.8.55)**
- `AutoScroller.probeWebtoonEnd`: 0.4초마다 `END_PROBE_JS` 로 폭 60%↑·높이 200px↑ 큰 그림이 3장 이상인 페이지(웹툰 뷰어)의 '마지막 컷 아래 끝 − 화면 아래 끝'(CSS px)을 읽어, 12px 이내가 두 번 연속이면 `pauseAtEnd`. 한 번 멈춘 뒤엔 300px 넘게 멀어질 때까지 재감지 안 함(`endHandled`). 기존 페이지 끝(`END_HOLD_MS`) 일시정지는 보조로 유지. 조작 막대(`pill`)가 있을 때만 동작. 지연 로딩·광고 배너 오감지는 실사이트 확인 필요
**자동 스크롤 끝에서 일시정지 (v3.8.54)**
- `AutoScroller.onFrame`: 더 못 내려가는 상태가 `END_HOLD_MS` 지속되면, 한 번이라도 움직였고 조작 막대(`pill`)가 있을 때는 `stop()` 대신 `userPaused = true` + `refreshPauseButton` 으로 일시정지(▶ 표시). 막대가 없으면(설정에서 끔) 이전처럼 `stop()`. 이어가기는 기존 `togglePause()` 그대로. 실기기 확인 전
**악성 사이트 경고 알림을 '보안'으로 이동 (v3.8.53)**
- 설정 > 알림에서 `악성 사이트 경고 알림`(`toggleMalwareWarning`) 행을 '백그라운드' 앞 `sub("보안")` 끝으로 옮김. 동작 변경 없음, 검색 그룹 목록만 갱신. 실기기 확인 전
**알림 설정 '보안' 항목 (v3.8.52)**
- 설정 > 알림에 `sub("보안")` 신설: `notifyAutoDlBlocked`(자동 다운로드 차단 토스트, `setDownloadListener`), `notifyBackBlocked`(뒤로가기 자동 이동 차단 토스트), 기존 `notifyRedirectBlocked`(이동 차단 안내)를 '앱 안 안내'에서 이 항목으로 옮김. 기본 켜짐. 꺼도 차단 자체와 보안 현황 집계(`SecurityStats`)는 그대로고 안내만 숨김. 설정 검색 키워드·그룹 목록 갱신.
**AI 답변 알림 설정 즉시 반영 (v3.8.51)**
- `AiKeepAliveService`: 알림 채널(`CH`/`CH_HIDDEN`)을 서비스 시작 때 한 번만 골라서, 답을 받는 도중 토글을 바꿔도 다음 질문부터 적용되던 것을 `running` 플래그 + `refresh()` 로 토글 즉시 `onStartCommand` 를 다시 불러 알림을 다시 올림(꺼져 있으면 아무 것도 안 함, 웨이크락은 중복 획득 안 함). 실기기 확인 전
**알림 설정이 안 먹던 문제 수정 (v3.8.50)**
- `DownloadService`: 서비스 유지용 알림이 `notifyDownloadProgress` 와 상관없이 `CH_SERVICE`(MIN)로 항상 보이던 것을, 진행 알림을 끄면 `CH_SERVICE_HIDDEN`(IMPORTANCE_NONE)으로 보냄. 받는 도중 설정이 바뀌면 `notifyProgress` 가 `svcHidden` 과 비교해 서비스 알림을 다시 올림.
- `DownloadNotifier.postSystemDone`: `notifyDownloadDone` 이 꺼져 있으면 그냥 return 해서 ongoing 진행 알림(같은 id)이 영원히 남던 것을 `cancel(id)` 후 return.
- 시스템 `DownloadManager` 대체 다운로드: 알림 가시성을 설정에 맞춤(진행+완료=NOTIFY_COMPLETED, 진행만=VISIBLE, 완료만=NOTIFY_ONLY_COMPLETION, 둘 다 꺼짐=HIDDEN). HIDDEN 때문에 `DOWNLOAD_WITHOUT_NOTIFICATION` 권한 추가.
- `requestNotificationPermission`: 이미 한 번 물어서 거절됐거나 시스템 설정에서 앱 알림이 꺼져 있으면(`areNotificationsEnabled()==false`) 세션당 한 번 '설정' 버튼이 달린 안내를 띄워 `ACTION_APP_NOTIFICATION_SETTINGS` 로 보냄. 실기기 확인 전
**탭 화면 카드 폭 맞춤 (v3.8.49)**
- 3.8.48 의 고정 폭(176dp)은 남는 폭이 오른쪽에 빈 자리로 남아 폐기. 열 수를 `round((화면폭dp-24)/188)`(최소 2, 상한 없음)로 정하고 카드는 예전처럼 가중치로 폭을 나눠 가짐 → 빈 자리 없이 채우면서 카드 폭은 목표(약 176dp)의 ±(0.5/열 수) 안에 머묾(8열이면 ±6%).

**"+N" 알약 크기 고정 (v3.8.47)**
그룹/숨긴 탭 카드 그림(400×320 비트맵)이 FIT_CENTER 로 카드 크기에 따라 같이 커져 알약도 커지던 것을, `bindPreview` 가 레이아웃 후 표시 배율을 재서 알약 높이를 24dp 로 맞춰 다시 그리게 함 (글자 0.625배, 폭 최소 1.35배).

**"+N" 알약 크기 줄임 (v3.8.46)**
글자 44→30px, 알약 높이 72→48px, 최소 폭 96→64px.

**탭 화면 그룹 카드 "+N" 표시 개선 (v3.8.45)**
네 번째 칸의 까만 막과 큰 글씨를 없애고, 실제 탭 그림 위에 밝은 반투명 막 + 둥근 "+N" 알약을 올림 (숨긴 탭 카드도 동일, 흐림 처리 뒤에 그려 글자는 또렷함).

**새 탭 '개인정보' 제목 숨기기 (v3.8.44)**
- `layout_home.xml`: `homeWidgetHeader`(텍스트 '개인정보')에 `visibility="gone"`. 코드(`styleHomeTexts`·`alignWidgetToTiles`·테마 색 적용)가 이 뷰를 찾아 색·패딩을 만지므로 삭제하지 않고 숨김만 함(findViewById null 방지). 제목이 빠진 자리에 맞춰 `homeAdCard` 윗 여백 12dp→32dp (즐겨찾기 줄과 카드 사이가 붙지 않게).

**광고 차단 아이콘 작대기: 살짝 줄이고 두껍게 (v3.8.43)**
- `ic_shield_person`: 작대기 반폭 0.62→0.85, 상자와의 틈 반폭 1.32→1.55(보이는 틈 0.7 은 그대로), 작대기 끝은 중심에서 축마다 ±9.6→±8.8(상자 밖으로 삐져나온 길이 약 3→2). 상자·글자는 v3.8.42 와 같음.

**광고 차단 아이콘: 상자 줄이고 작대기 늘리기 (v3.8.42)**
- `ic_shield_person`: v3.8.41 의 `<group>` 0.85배 축소를 없애고 24×24 좌표에서 직접 다시 계산. 상자 (3.5,5.25)-(20.5,18.75) 반지름 2.2, 글자 배율 1.2(전엔 1.5×0.85), 작대기 반폭 0.62·틈 반폭 1.32(보이는 굵기는 v3.8.41 과 같음), 작대기 끝은 중심에서 축마다 ±9.6(전엔 약 ±8) → 상자 밖으로 약 3 더 삐져나옴. 36dp ImageView·tint 규칙은 그대로.

**광고 차단 아이콘 크기 줄이기 (v3.8.41)**
- `ic_shield_person`: 그림 전체를 `<group>` 으로 감싸 중심(12,12) 기준 0.85배로 축소. layout 의 36dp ImageView 와 `applyHomeGlassToWidgets` tint 규칙은 그대로라 레이아웃·카드 높이 변화 없음. 보안 카드 아이콘(방패 폭 16)과 크기를 맞추는 정도(상자 폭 21 → 약 17.9).

**광고 차단 아이콘을 AD 상자 + 대각선 작대기로 (v3.8.40)**
- `ic_shield_person`: 'AD' 글자가 evenOdd 로 뚫린 큰 둥근 상자(1.5,3.5)-(22.5,20.5) 가운데로 좌상→우하(x=y) 대각선 작대기(반폭 0.72, 둥근 끝)를 긋고, 작대기 양옆 반폭 1.55 를 상자에서 비워 띠 모양 틈을 둠. 틈은 vector `clip-path` 대신 꼭짓점을 직접 잘라 계산(반평면 클리핑)해서 가장자리가 계단지지 않음 → 두 반쪽 path(evenOdd) + 작대기 path(nonZero) 로 구성. 글자는 v3.8.39 의 A·D 윤곽을 1.5배 키워 상자 중앙에 둠. v3.8.39 의 '금지 표시 고리' 방식 대체.

**광고 차단 아이콘 다시 만들기 (v3.8.39)**
- `ic_shield_person`: 'AD' 글자가 evenOdd 로 뚫린 광고 배너(1.5,2.5)-(19,14.5) + 오른쪽 아래 금지 표시(중심 18,18 · 바깥 5.5 · 안쪽 3.7 고리 + 대각선 띠). 배너 오른쪽 아래는 금지 표시 둘레 1.2 간격으로 둥글게 파서(반지름 6.7 호) 겹치지 않음 → v3.8.38 의 '글자를 대각선으로 가르는' 방식(글자가 작고 읽기 어려웠음)을 대체. 배너·금지 표시는 별도 `<path>`(배너 evenOdd, 금지 표시 nonZero). 실기기 확인 전

**(바뀜) 광고 차단 아이콘 / 보안 아이콘 원복 (v3.8.38)**
- `ic_shield_person`(광고 카드): 'AD' 광고 금지 표시. 고리(바깥 CW · 안쪽 CCW) + 대각선(좌상→우하) 띠 + 글자 A(왼쪽 아래 반쪽)·D(오른쪽 위 반쪽)를 대각선이 가르도록 배치. 겹치는 도형이 합쳐지게 nonZero 로 채움(구멍은 반대 방향). 글자가 대각선과 겹치면 뭉개져서 반쪽씩 나눠 둠.
- `ic_shield_check_filled`(보안 카드): v3.8.35 의 체크 방패(evenOdd)로 원복. 실기기 확인 전

**(바뀜) 새 탭 개인정보 카드 아이콘을 광고·보안 내용에 맞게 (v3.8.37)** (v3.8.36 의 방패 두 톤 + 44dp 받침 디자인은 되돌림: 레이아웃·`applyHomeGlassToWidgets` 는 v3.8.35 와 동일)
- `ic_shield_person`(광고 차단 카드): 'AD' 글자가 evenOdd 로 뚫린 둥근 광고 배너. `ic_shield_check_filled`(보안 현황 카드): 자물쇠(몸통·걸쇠)가 뚫린 방패. 파일 이름은 그대로(레이아웃 참조 유지), 단색 면 + tint 방식도 그대로.
- 카드 첫 자식은 36dp ImageView 여야 함(`applyHomeGlassToWidgets` 가 tint). 실기기 확인 전

**(되돌림) 새 탭 개인정보 카드 아이콘 방패 두 톤 + 받침 (v3.8.36)**
- 아이콘 모양을 내용(광고·보안)과 상관없이 방패로 꾸미는 쪽이어서 v3.8.37 에서 되돌림.

**탭 화면 아래 버튼 그림자·테두리 (v3.8.35)**
- `applyAppChromeColors`: `btnNewIncognito`/`btnNewTab` 에 `stateListAnimator=null` + `elevation=5dp`(Material 버튼 기본 눌림 elevation 제거, 그림자 고정). `btnNewIncognito` 는 `strokeWidth=1dp` · `strokeColor=primary α0x59`(선택 막대 `applySelectBarColors` 와 동일). `switcherBottom` 에 `clipChildren=false`/`clipToPadding=false` 로 그림자가 잘리지 않게 함. 실기기 확인 전

**그룹 밖으로 끌어낼 때 순서 바꾸기와 같은 동작 (v3.8.34)**
- `updateOutPreview`/`resetOutPreview`: `leaving` 중 손가락(카드 중심)이 그룹에 속하지 않은 탭 카드 위에 있으면 그 카드부터 뒤 카드들이 한 칸씩 비켜 줌(맨 뒤 카드는 같은 줄 오른쪽 / 다음 줄 왼쪽의 추정 칸). 놓으면 그 카드 바로 앞(`tabs.indexOf`)에 삽입, 어느 카드 위도 아니면 v3.8.33 의 `dropIndexAt`(가장 가까운 칸 앞/뒤). 그룹 안으로 돌아오거나 다른 그룹·창 칩 위·취소면 카드들을 제자리로. 실기기 확인 전

**그룹에서 끌어낸 탭을 놓은 자리에 두기 (v3.8.33)**
- `endSwitcherDrag` 의 `leaving` 분기: 예전엔 그 그룹 바로 뒤(`indexOfLast{groupId}+1`)에 고정. 이제 `SwitcherDrag.dropX/dropY`(카드 중심, `updateSwitcherDrag` 가 갱신)로 `dropIndexAt` 가 가장 가까운 칸(그룹에 속하지 않은 탭 카드 / 그룹 상자·접힌 카드)을 찾아 앞(위·왼쪽)이면 첫 탭 자리, 뒤면 마지막 탭 뒤에 삽입. 칸이 없으면 예전 위치로. 탭 줄(상단) 드래그는 건드리지 않음. 실기기 확인 전

**숨긴 탭 카드 제스처 (v3.8.32)**
- 펼친 숨긴 탭 카드에 `bindDragGesture` 적용(일반 탭 카드와 동일): 옆으로 밀기 → `closeHiddenTab`, 꾹 눌렀다 끌지 않고 떼기 → `showTabMenu(hidden=true)`. 순서 바꾸기 끌기는 없음(`onStart` 는 true 만 반환, `onMove` 비움). 이 호출이 `setOnLongClickListener`·터치 리스너를 설정하므로 같은 카드의 `Motion.pressable` 호출은 제거. 실기기 확인 전

**숨긴 탭 메뉴에서 탭 닫기 제거 (v3.8.31)**
- v3.8.30 의 `showTabMenu(hidden=true)` 에서 「탭 닫기」 항목 삭제(일반 탭 메뉴에도 없음). 닫기는 카드 X(`closeHiddenTab`). 실기기 확인 전

**숨긴 탭 꾹 누르기 메뉴 (v3.8.30)**
- `showTabMenu(tab, anchor, hidden=true)`: 일반 탭 메뉴 재사용. 숨긴 탭은 `tabs` 밖이라 「탭 숨기기」·창 이동·그룹 항목은 빼고(그룹 이동은 `tabs` 에 다시 넣어 버림) 음소거·북마크 + 「숨김 해제」「탭 닫기」만. v3.8.29 의 임시 2항목 메뉴를 대체. 실기기 확인 전

**숨긴 탭 삭제 (v3.8.29)**
- 탭 화면에서 펼친 숨긴 탭 카드: X(`tabClose`)를 「숨김 해제」→「탭 닫기」로 바꿈(`closeHiddenTab`: hiddenTabs 에서 제거 · 웹뷰 destroy · saveTabs). 숨김 해제는 카드 탭(해제하고 열기) 또는 꾹 누르기 메뉴([숨김 해제 / 탭 닫기]).
- 숨긴 탭이 「최근 닫은 탭」(`rememberClosed`)에 남아 되돌리기로 노출되지 않게 기억하지 않음 → 되돌리기 없음. 실기기 확인 전

**새 탭 버튼 줄 플로팅 (v3.8.28)**
- `layout_tab_switcher.xml`: `switcherBottom`(시크릿 탭/새 탭)도 `tabScroll` 과 같은 `FrameLayout` 안 `bottom` 으로 옮겨 목록 위에 겹침(`switcherBottomHost` 삭제). `tabScroll` 아래 패딩을 항상 88dp 로(평소·선택 모드 공통)하고 v3.8.26 의 `swapBottom` 패딩 코드는 제거. 버튼 모양·여백·교대 애니메이션은 그대로. 실기기 확인 전

**웹페이지 꾹 누르기 메뉴 깜빡임 수정 (v3.8.27)**
- 원인 추정: `Popup.menuAnchored` 가 `Blur.behindPopup` 으로 창 뒤 블러(FLAG_BLUR_BEHIND / 대체 BackdropView·RenderEffect)를 거는데, 뒤가 WebView 라 깜빡임(태블릿은 이미 같은 이유로 블러 제외 — `Blur.tablet` 주석). 재현·실기기 확인 전.
- 수정: `menuAnchored(blurBehind=false)` 추가 → 블러를 걸지 않고 카드 바탕은 불투명(`anchoredBackground(glass=false)`). `showLinkMenu` 의 꾹 누르기 메뉴만 `blurBehind=false`. 다른 메뉴·팝업은 그대로.

**선택 막대 플로팅 (v3.8.26)** (v3.8.25 의 알약·그림자 디자인 변경은 되돌림: 막대 디자인은 v3.8.24 와 동일)
- `layout_tab_switcher.xml`: `tabScroll` 과 `selectBar` 를 `FrameLayout`(weight 1)로 묶고 `selectBar` 를 `bottom|center_horizontal` 로 목록 위에 겹침(이전: 아래 자리 `switcherBottomHost` 안). 아래 자리에는 [시크릿 탭/새 탭] 버튼만 남음.
- `swapBottom`: 선택 모드 동안 `tabScroll` 아래 패딩 88dp(평소 8dp) → 마지막 카드도 막대 위로 스크롤 가능. 실기기 확인 전

**탭 화면 전환 중 스크롤 시 카드 위치 어긋남 수정 (v3.8.24)**
- 원인: `openTabSwitcher` 가 morph 도착 사각형(`rectInRoot(thumb)`)을 시작 시점에 한 번만 계산해, 전환 중 `tabScroll` 이 움직이면 도착점과 실제 카드 위치가 달라짐(끝에서 카드가 튀는 듯 보임).
- 수정 1: `runMorph` 에 `toLive` 인자 추가 → 매 프레임 `rectInRoot(thumb)` 로 도착 사각형을 다시 구해 따라감(열 때만 사용).
- 수정 2: `dispatchTouchEvent` 에서 `switcherBusy` 중 `tabScroll` 영역에서 시작한 터치는 끝(UP/CANCEL)까지 삼킴(열고 닫는 전환 모두). 실기기 확인 전

**하단 내비게이션 바 투명 처리 롤백 (v3.8.23)**
- v3.2.71 의 `makeNavBarTransparent()`(navigationBarColor 투명 · `isNavigationBarContrastEnforced=false` · navigationBarDividerColor 투명)와 호출 2곳(`installCaptionIntegration`, `enableCaptionEdgeToEdge`)을 삭제하고, `values`·`values-night` `themes.xml` 의 `navigationBarColor`/`navigationBarDividerColor`/`enforceNavigationBarContrast` 항목도 삭제(Material3 기본값으로 복귀). 실기기 확인 전
- 인셋 처리(`setDecorFitsSystemWindows(false)` 등)는 건드리지 않음.

**선택 막대 테두리 (v3.8.22)**
- `applySelectBarColors`: 막대 바탕에 `setStroke(1dp, colorPrimary α0x59)` 추가(테마 색을 따라감). 실기기 확인 전

**로딩 안 된 탭 전환: 잎사귀 빼기 (v3.8.21)**
- v3.8.20 은 카드(잎사귀 포함)를 `drawToBitmap` 으로 찍어 펼쳐서 잎사귀가 커졌음. 이제 `colorSurface` 로 칠한 8×8 단색 비트맵을 morph 이미지로 사용(잎사귀 없음). 끝에서 `hideMorph(fade=true)` 는 그대로. 실기기 확인 전

**로딩 안 된 탭 열 때 전환 애니메이션 (v3.8.20)**
- 원인: `closeTabSwitcher` 의 morph 조건에 `tab.thumb != null` 이 있어, 미리보기 사진이 없는 탭(지연 복원된 탭, 카드엔 잎사귀 자리표시)은 morph 를 건너뛰고 기본 폴백(브라우저 0.95배 + alpha)으로 바로 넘어감.
- 수정: `thumb` 이 없으면 카드의 `tabThumb`(자리표시)을 `drawToBitmap` 으로 찍어 morph 이미지로 쓰고, 끝날 때 `hideMorph(fade = true)` 로 진짜 화면 위에서 서서히 걷음(자리표시는 실제 화면과 달라 겹쳐 보이지 않음). 사진이 있는 탭은 기존 그대로. 실기기 확인 전

**선택 막대 디자인을 앱 컨셉에 맞춤 (v3.8.19)**
- 문제: 떠 있는 상자(elevation 6dp + 테두리 + 모서리 22dp, 바탕 `colorSurfaceContainerHighest`) · 아이콘 20dp · 글자 11sp 라서 같은 자리의 「새 탭/시크릿 탭」 버튼 줄(톤 면 · 14dp · 가장자리 여백 18dp)과 모양이 달랐고, 테마 색도 따르지 않았음.
- `layout_tab_switcher.xml` `selectBar`: 여백 14→18dp(버튼 줄과 같은 폭), elevation 제거, minHeight 56dp, 항목 아이콘 `@dimen/ev_icon`(24dp)·글자 12sp·위아래 padding 8dp, 항목 배경은 새 `bg_select_item`(10dp 둥근 리플).
- `applySelectBarColors()`(`setupSelectBar`·`applyAppChromeColors` 에서 호출): 막대 바탕 = `colorSecondaryContainer`(모서리 14dp, 테두리 없음), 아이콘·글자 = `colorOnSecondaryContainer`, 닫기만 `ev_danger`(Popup 의 danger 항목과 같음). 실기기 확인 전

**「이동」 아이콘 화살표 키움 (v3.8.18)**
- `ic_window_move`: 창 윤곽을 x3~14 로 줄이고 화살표를 별도 path(선 2.2, 샤프트 8.5→21, 머리 16.5~21 × 8~17)로 키움. v3.8.17 은 20dp 에서 화살표가 작고 가늘어 잘 안 보였음. 실기기 확인 전

**선택 막대 「이동」 아이콘 교체 (v3.8.17)**
- 새 `ic_window_move`(창 윤곽 + 오른쪽으로 나가는 화살표, 24dp·선 1.8)로 `ic_folder_move` 를 대체. `layout_tab_switcher.xml` 의 `selectMove` 와 `moveSelectedTabs` 팝업 `headerIcon` 두 곳에 적용, 옛 `ic_folder_move.xml` 삭제(「그룹」 `ic_folder_plus` 와 둘 다 폴더 모양이라 헷갈렸음). 실기기 확인 전

**탭 화면 「새 탭」 애니메이션 수정 (v3.8.16)**
- 원인: 탭 화면(switcherOpen)에서 새 탭을 만들면 `selectTab`/`updateUi` 가 등장 애니메이션(`playNewTabEnter`)을 건너뛰고 `homeContent` 순차 등장(stagger)만 탭 화면 뒤에서 먼저 재생됨 → 이어서 `closeTabSwitcher()` 는 새 탭 카드·썸네일이 없어 기본 폴백(브라우저 전체 0.95배 + alpha 0→1)을 탐.
- `openNewTabFromSwitcher`: 탭 화면의 「새 탭」·「시크릿 탭」·그룹 메뉴 「이 그룹에 새 탭」이 사용. `newTabFromSwitcher` 플래그로 `updateUi` 의 stagger 를 미루고 `closeTabSwitcher(newTabEnter = true)` 호출.
- `closeTabSwitcher(newTabEnter)`: morph 끔, 상·하단 막대는 그대로 두고 새 화면(홈 또는 웹뷰)에 `playNewTabEnter` + 홈 stagger(60ms 지연), 탭 화면은 stiffness 650 으로 걷음. 실기기 확인 전

**펼친 그룹 상자 끌기 개선 (v3.8.15)**
- `updateSwitcherGroupDrag`: 상자(isBox) 드래그는 translationX=0(세로만), 자리 판정점을 가운데 대신 손가락 위치로(큰 상자는 가운데 기준이면 한참 끌어야 비켜 줬음). 카드 드래그는 v3.8.10 그대로. 실기기 확인 전

**접힌 그룹 속 탭의 탭 화면 전환 애니메이션 (v3.8.14)**
- `switcherCardFor(tab)`: `switcherRows[tab]` 이 없으면(접힌 그룹) `switcherGroupCells[group.id]` 카드를 돌려줌. `openTabSwitcher`/`closeTabSwitcher` 의 morph 대상·시작 카드에 사용(전엔 카드가 null 이라 페이드만 됐음). 실기기 확인 전

**선택 막대 축소 (v3.8.13)**
- 아이콘 26→20dp, 글자 12.5→11sp, 위아래 padding 10→6dp, 아이콘-글자 간격 6→3dp, 모서리 32→22dp, 태블릿 폭 520→400dp. 실기기 확인 전

**접힌 그룹 카드 끌기 = 탭 카드와 동일 (v3.8.12)**
- `SwGroupDrag.winChip/winTarget`: 접힌 그룹 카드(!isBox)가 창 칩 위로 가면 0.62배·alpha 0.85·칩 강조(탭 끌기와 같음), 놓으면 소속 탭을 모두 `moveTabToWindow` 로 옮기고 칩으로 빨려 들어감. 「새 창」 칩(target=null)은 그룹엔 무시(탭마다 새 창이 열리는 걸 막음). 칩 위에서는 순서를 원래대로 돌려 둠. 실기기 확인 전

**그룹 끌기 앞쪽 이동 버그 · 밖으로 끌 때 안 보임 (v3.8.11)**
- v3.8.10 의 `updateSwitcherGroupDrag` 에서 카드끼리 past=true 로 두어 뒤로(앞쪽으로) 가는 이동(ok=!past)이 막히던 것: 카드끼리는 방향 상관없이 ok. 
- `syncLeaveGhost`: 그룹 안 탭이 자기 상자 밖으로 나가면(leaving) 카드 비트맵을 `tabSwitcher.overlay` 에 띄우고 진짜 카드는 alpha 0 (상자·줄에 가려지거나 잘리는 걸 피함). 끝/칩 위/뷰 사라짐 때 정리. 원인은 코드만으로 확정 못 함 — 실기기 확인 필요

**탭 화면: 그룹 탭 밖으로 빼기 · 그룹 끌기 타이밍 (v3.8.10)**
- `SwitcherDrag.ownBox/leaving`: 그룹 안 탭의 가운데가 자기 상자 밖(다른 상자·창 칩 위가 아닐 때)이면 leaving(카드 alpha 0.8, 햅틱). 놓으면 `groupId=0` 으로 빼서 그 그룹 마지막 탭 바로 뒤에 둔다. 접힌 그룹은 탭이 안 보여 해당 없음.
- `updateSwitcherGroupDrag`: 판정점을 손가락→끄는 덩어리 가운데로, 카드끼리는 중심 넘기 조건 없이 바로 자리 바꿈(상자가 끼면 기존 조건 유지). 실기기 확인 전

**탭 줄 그룹 끌 때 불투명 (v3.8.9)**
- `startStripGroupDrag` 에서 그룹 소속 탭 칩의 `bg.alpha=255`(개별 탭 끌기와 동일), 끝/취소 때 `applyChipSelection` 으로 복원. 실기기 확인 전

**탭 그룹 카드 미리보기 양옆 여백 (v3.8.8)**
- 접힌 그룹 카드 `tabThumb` scaleType CENTER_CROP→FIT_CENTER (숨긴 탭 카드와 동일, v3.8.7). 실기기 확인 전

**숨긴 탭 카드 미리보기 양옆 여백 (v3.8.7)**
- 숨긴 탭 카드 `tabThumb` 의 scaleType 을 CENTER_CROP→FIT_CENTER 로(400×320 비트맵이 넓은 카드에서 좌우가 잘리던 것). 실기기 확인 전

**숨긴 탭 카드 가운데 자물쇠 축소 (v3.8.6)**
- `hiddenPreviewBitmap`(400×320 비트맵) 가운데 배지 원 반지름 62→42(20 줄임), 아이콘 68→46px. 오른쪽 위 작은 자물쇠는 그대로. 실기기 확인 전

**태블릿 선택 막대 폭 제한 (v3.8.3)**
- `selectBar` 폭을 `@dimen/select_bar_width` 로(기본 -1px=match_parent, `values-sw600dp` 에서 520dp) + `layout_gravity=center_horizontal`. 실기기 확인 전

**선택 막대 「잠금」→「숨기기」 (v3.8.2)**
- `selectHide` 의 글자를 숨기기, 아이콘을 `ic_visibility_off` 로 변경(동작은 그대로 `hideSelectedTabs`). 실기기 확인 전

**선택 막대 개편: 이동·그룹·잠금·공유·닫기 (v3.8.1)**
- `selectBar` 를 아이콘(위)+글자(아래) 5칸 균등 막대로 교체(`selectMove/Group/Hide/Share/Delete`, id 는 기존 이름 재사용). 전체 선택은 제목줄 `btnSelectAll`(선택 모드에서만 보임, 문구는 전체 선택/선택 해제). 새 아이콘 `ic_folder_move`·`ic_folder_plus`·`ic_tab_close`. 잠금=`hideSelectedTabs`, 그룹=`groupSelectedTabs`, 닫기=`confirmCloseSelected`(기존 확인창), 이동=`moveSelectedTabs`(다른 창이 하나면 바로, 여럿이면 `Popup.menu` 로 선택, 없으면 토스트. 새 창으로 여러 탭 보내기는 없음), 공유=`shareSelectedTabs`(주소 있는 탭만, 제목+주소 줄바꿈 연결). 고른 게 없으면 alpha 0.38 + 반응 없음. 예전 삭제 알약·전체 선택 체크 코드는 제거(`delPill*`, `selAllCheck` 필드는 남아 있으나 안 씀). 실기기 확인 전

**선택 모드: 숨김·그룹 (v3.8.0)**
- 선택 막대(`selectBar`)에 `selectHide`(눈 꺼짐)·`selectGroup`(폴더) 아이콘 버튼 추가(고른 게 없으면 alpha 0.38 + 눌러도 반응 없음). `hideSelectedTabs`: 시크릿 제외, 현재 탭은 마지막에, `hideTab(quiet=true)` 로 토스트·다시 그리기 없이 숨기고 마지막에 한 번만 갱신. `groupSelectedTabs`: `Popup.menu`(새 그룹 → `showGroupEditor`, 기존 그룹 추가, 그룹에서 빼기)로 고른 뒤 `moveToGroup`. 둘 다 끝나면 선택 모드를 끔. 폭이 아주 좁은 폰(<~330dp)에서는 막대가 빡빡할 수 있음. 실기기 확인 전

**숨긴 탭 블러를 칸마다 따로 (v3.7.99)**
- `groupPreviewBitmap(blurEach=true)`: 2×2 칸을 각각 별도 비트맵에 그려 칸마다 4×3 → 16×12 → 원래 크기로 뭉갠 뒤 합침(이전엔 합친 그림 전체를 6×5 로 줄여 네 탭 색이 섞였음). `hiddenPreviewBitmap` 은 이것을 쓰고 자물쇠 배지만 올림. 칸 안 흐림 정도는 이전보다 약간 약해 보일 수 있음(칸이 작아서 같은 비율로 줄이면 오히려 더 뭉개짐). 실기기 확인 전

**탭 화면 그룹 끌기: 실시간 자리 비킴 (v3.7.98)**
- v3.7.97 의 '놓을 대상 강조 + 놓을 때 이동' 을 탭 카드 끌기와 같은 방식으로 교체. `SwGroupDrag` 가 덩어리(`SwUnit`: 탭 카드/접힌 그룹 카드/펼친 상자) 순서 `order` 를 들고, 손가락이 다른 덩어리 위로 가서 앞으로는 중심을 넘으면·뒤로는 중심 앞이면 `order` 에서 위치를 옮기고 `previewSwitcherGroupOrder` 로 나머지를 새 자리로 미끄러뜨림(되돌아가며 깜빡이지 않게 중심 기준 비대칭). 카드(정사각)·상자(가로 전체) 크기가 달라 `simulateSwitcher` 가 cols 열 격자를 흉내 내 자리를 계산하고, 처음 순서로 계산한 자리와의 차이만 translation 으로 씀. 숨긴 탭 카드/상자는 맨 끝에 고정으로 끼워 계산. 놓으면 `tabs` 를 `order` 대로 다시 채우고 `refreshSwitcher(false)`. 실기기 확인 전(자리 계산이 실제 레이아웃과 어긋나는지 확인 필요)

**탭 화면 그룹 끌어서 순서 바꾸기 (v3.7.97)**
- 접힌 그룹 카드(`addGroupCell`)·펼친 그룹 줄(`addGroupHeader`, 숨긴 탭 제외·선택 모드 제외)에 `bindDragGesture` 연결 → `startSwitcherGroupDrag`. 끄는 뷰는 접힌 카드면 그 카드, 펼쳤으면 상자(`switcherBoxes`) 전체. 놓을 수 있는 대상은 `tabUnits` 의 다른 덩어리(탭 카드/그룹 카드/상자)이고 손가락이 올라간 덩어리가 1.04배로 강조됨. 놓으면 `moveGroupUnitNextTo`(대상이 원래 앞이면 앞, 뒤면 뒤)로 `tabs` 순서를 바꾸고 `refreshSwitcher(false)`. 덩어리 크기가 달라 다른 카드들이 미리 비켜 주지는 않음(놓은 뒤 기존 glide 로 이동). 자동 스크롤은 `swAutoScroll` 공유. 끌지 않고 떼면 접힌 카드만 그룹 메뉴. 실기기 확인 전

**그룹 알약 끌어서 순서 바꾸기 (v3.7.96)**
- 상단 탭 줄의 그룹 알약(`bindStripPill`)에 `bindDragGesture` 연결(길게 누름 → `startStripGroupDrag`). 알약 + 펼쳐진 그룹 탭들(`groupStripViews`)이 같이 `translationX` 로 손가락을 따라가고, 이웃 덩어리(`tabUnits` 기준 탭 하나/그룹)의 가운데를 넘으면 `reorderGroupUnit` + `swapStripGroupDrag` 로 데이터·뷰 순서를 바꿈(이웃은 미끄러지듯 이동). 가장자리 자동 스크롤은 기존 `stripAutoScroll` 공유. 끌지 않고 떼면 기존처럼 `showGroupMenu`. 새 창으로 끌어내기는 그룹에는 없음. 접힌 그룹도 알약만 같은 방식으로 이동. 실기기 확인 전

**숨긴 탭이 그룹처럼 펼쳐짐 (v3.7.95)**
- 숨긴 탭 카드를 누르면 `openHiddenTabs`(생체인식) 뒤 `toggleSwitcherGroup(hiddenGroup, true)` 로 그룹과 같은 펼침 애니메이션. `hiddenGroup`(id=`HIDDEN_GID`=-1)은 `TabGroup` 을 흉내 낸 가짜 그룹이라 `groups` 에 안 들어감. 상자는 `switcherBoxes` 가 아니라 `switcherHiddenBox` 에 둠(탭을 끌어다 넣는 대상에 안 끼게). 펼침 상태 `hiddenOpen` 은 저장 안 하고 탭 화면을 열고 닫을 때·`onStop` 에서 false(다시 잠김)
- 펼친 상자: 헤더(「숨긴 탭」·개수·메뉴: 「모두 숨김 해제」「다시 잠그기」) + 숨긴 탭 카드(`switcherRows` 에 등록해서 열 때 미리보기가 펼쳐지는 전환이 됨). 카드 누름 → `unhideTab` + `closeTabSwitcher(tab)`, X 자리(눈 꺼짐 모양)는 숨김만 해제. 끌기·밀어서 닫기는 없음. 선택 모드에서는 숨긴 탭 카드·상자 모두 안 보임. 실기기 확인 전

**숨긴 탭 카드 블러 강화 (v3.7.93)**
- `hiddenPreviewBitmap` 의 뭉개기를 16×13 → 64×52 에서 6×5 → 24×20 으로 더 줄여 모양이 남지 않게 함(구형 기기에서도 같은 가짜 블러). 실기기 확인 전

**숨겨도 미리보기 유지 (v3.7.92)**
- `hideTab` 이 더 이상 `tab.thumb` 를 지우지 않음. 현재 탭을 숨길 때는 웹뷰를 떼기 전에 `captureContent()` 로 지금 모습을 `thumb` 에 남김(탭 화면이 열려 있으면 이미 찍혀 있음). 그래서 숨긴 탭 카드(`hiddenPreviewBitmap`)의 흐린 모자이크에 실제 페이지가 비침. `thumb` 는 메모리에만 있어서 앱을 다시 켜면 사라지고 그땐 아이콘 색 덩어리만 흐리게 보임. 숨긴 탭은 탭 목록에 없어 미리보기가 따로 노출되는 곳은 없음. 실기기 확인 전

**숨긴 탭 카드: 블러 + 자물쇠 (v3.7.91)**
- 숨긴 탭 카드의 미리보기 자리를 `hiddenPreviewBitmap` 으로 그림: `groupPreviewBitmap`(숨긴 탭 아이콘 2×2 모자이크)을 16×13 → 64×52 → 원래 크기로 줄였다 키워 뭉갠(구형 기기에서도 되는 가짜 블러) 뒤, 가운데에 `colorSurface` 원 배지 + `ic_lock` 을 얹음. 숨길 때 `thumb` 를 지우므로 실제 페이지 모습이 아니라 아이콘 색 덩어리만 흐리게 보임(내용 노출 없음). 실기기 확인 전

**숨긴 탭을 그룹 카드처럼 맨 끝 한 칸으로 (v3.7.90)**
- `refreshSwitcher` 맨 끝의 전체 폭 잠금 줄을 없애고, `hiddenTabs` 가 있으면(선택 모드 제외) `item_tab` 을 재사용한 격자 카드 한 칸(`addCell`)을 마지막 탭/그룹 카드 뒤에 놓음: 제목 「숨긴 탭 · N」, 점선 테두리, 미리보기 자리와 X 자리에 자물쇠. 누르면 기존처럼 `openHiddenTabs`(생체인식 → 숨긴 탭 메뉴). 끌어서 순서 바꾸기·밀어서 닫기 대상 아님. 실기기 확인 전

**탭 화면: 그룹 펼침·접힘 애니메이션 (v3.7.89)**
- 그룹 카드/그룹 줄/그룹 메뉴의 펼치기·접기가 모두 `toggleSwitcherGroup(g, expand)` 하나로 모임(모션이 꺼져 있으면 예전처럼 바로 `refreshSwitcher`). 목록은 그대로 다시 그린 뒤, `OnPreDrawListener` 에서 막 레이아웃된 뷰에 애니메이션을 입힘
- 펼침: 접힌 카드 모양의 둥근 구멍(`ViewOutlineProvider` + `clipToOutline`)이 그룹 상자 전체로 자라고(`springValue`), 멤버 카드는 그룹 카드 중심에서 0.72배·투명으로 출발해 차례로(최대 192ms) 제자리로 스프링(`settleHome`), 헤더는 살짝 늦게 위에서 내려옴. 사라지는 그룹 카드는 `drawToBitmap` 스냅샷을 오버레이로 잠깐 얹어 크로스페이드(`GroupFxDrawable`). 일반 `Motion.enter` 는 이 그룹 멤버에게는 건너뜀(`refreshSwitcher(skipEnterGroup)`)
- 접힘: 접기 직전 상자(그림 대신 같은 색의 둥근 사각형)·헤더·멤버 카드를 스냅샷으로 떠 두고, 목록을 다시 그린 뒤 스냅샷들이 새 그룹 카드 자리로 모이며(상자는 줄고 카드는 0.8배로 작아지며 사라짐) 새 그룹 카드가 늦게 떠오름. 아래 카드는 기존 `glideFrom` 으로 같이 올라감
- 애니메이션 중에는 `groupToggling` 으로 다른 탭 조작을 막고, 끝나면(또는 1.3초 안전 타이머) 오버레이·윤곽을 원래대로 되돌림. 실기기·컴파일 확인 전 (이 환경엔 Kotlin 빌드 도구가 없음)
**탭 화면: 그룹을 카드 한 칸으로 (v3.7.88)**
- `TabGroup.swExpanded`(기본 false, 저장 안 함) 추가 — 탭바의 접힘(`collapsed`)과 따로 둠. `refreshSwitcher` 가 `swExpanded` 가 false 인 그룹을 `addGroupCell` 로 탭 카드와 같은 격자 한 칸에 그림(`item_tab` 재사용: 그룹 색 테두리, 안에 든 탭 미리보기 2×2 `groupPreviewBitmap`, 5개 이상이면 네 번째 칸 「+N」, 현재 탭이 든 그룹은 테두리 3dp). 누르면 `swExpanded = true`, 길게 누르면 그룹 메뉴(탭 화면에선 「펼치기/한 칸으로 접기」가 `swExpanded` 를 바꿈)
- 펼친 그룹은 예전 그룹 상자(헤더 + 탭 카드) 그대로이고, 헤더를 누르면 접힘 애니메이션 후 다시 한 칸. 헤더의 접힘 미리보기·화살표 회전은 제거(펼친 상태만 있음). 선택 모드에서는 그룹이 항상 펼쳐져 탭을 하나씩 고를 수 있음
- 한계: 접힌 그룹 카드는 끌어서 순서 바꾸기·밀어서 닫기·탭을 끌어다 넣기가 안 됨(펼친 뒤에 가능). 실기기 확인 전

**탭 숨기기 (v3.7.87)**
- 탭 메뉴(탭바·탭 화면에서 길게 누름)의 「탭 숨기기」 → `hideTab`: `tabs` 에서 빼서 `hiddenTabs` 에 보관(웹뷰는 그대로, 그룹은 해제, 재생 중 미디어는 멈춤, 미리보기 `thumb` 지움). 그래서 탭바·탭 화면·탭 개수·탭 넘기기·닫을 때 다음 탭 고르기에 자연히 안 잡힘. 시크릿 탭은 숨길 수 없음(시크릿 프로필 정리 로직과 충돌). 기기에 생체인식·화면 잠금이 없으면 숨기지 않음(영영 못 여는 일 방지)
- 탭 화면 맨 끝에 「숨긴 탭 N개」 잠금 줄(선택 모드에선 안 보임) → `openHiddenTabs` → `TabLock.authenticate`(androidx.biometric 1.1.0, `BIOMETRIC_WEAK | DEVICE_CREDENTIAL`: 지문·얼굴, 없으면 PIN·패턴) 성공 시 `showHiddenTabsMenu` 에서 탭을 고르면 `unhideTab`(목록 맨 뒤로) 후 열림, 「모두 숨김 해제」도 있음
- 저장: `saveTabs` 가 `tabs + hiddenTabs` 를 함께 저장하고 각 항목에 `hidden` 표시, `restoreTabs` 가 `hidden` 항목을 `hiddenTabs` 로 옮김(보이는 탭이 없으면 새 탭 생성, 현재 탭이 숨김이면 첫 보이는 탭). 숨긴 탭도 복원 때 웹뷰를 미루고(lazy) 만든다
- 한계: 숨긴 탭이 있다는 사실(잠금 줄)은 탭 화면에서 보임. 탭 단위 잠금이지 앱 잠금은 아님. 실기기 확인 전

**탭 닫기(X) 색이 제목 색을 따름 (v3.7.86)**
- `applyChipSelection` 이 제목 색(`stripFgUnsel`↔`stripFgSel` 를 선택 비율로 섞은 값)을 계산해 `stripClose` 의 `imageTintList` 에도 같이 적용. `styleStripChip` 의 고정 틴트(`stripFgUnsel`만)는 제거. 실기기 확인 전

**시스템 미디어 플레이어 로딩 표시 (v3.7.85)**
- 페이지 미디어 스크립트(`MediaScripts` 의 `prog`)가 `readyState<3 && (!paused || seeking)` 일 때를 로딩으로 보고 바뀔 때만 `EvMedia.loading(fid, ld)` 로 알림(`waiting`·`stalled`·`seeking`·`canplay` 이벤트에도 `prog` 호출). 앱은 `MediaProg.buffering` 에 담아 `MediaService.start(buffering=)` 로 넘기고, `showControls` 가 `PlaybackState.STATE_BUFFERING` 으로 세션을 갱신 → Android 13+ 미디어 패널이 재생/일시정지 버튼 자리에 로딩 고리를 그림
- 로딩 중엔 재생 위치가 안 흘러서 `updateMediaSession` 의 위치 어긋남(drift) 검사에서 예상 위치를 앞당기지 않음(`pushBuffering`). Android 12 이하 알림 버튼에는 로딩 표시가 없음. 실기기 확인 전

**탭 아이콘이 이전 사이트 걸로 바뀌던 것 (v3.7.84)**
- 원인: 새 페이지로 넘어가는 동안 웹뷰가 이동 전 페이지의 아이콘을 `onPageStarted` 의 `favicon` 인자나 뒤늦은 `onReceivedIcon` 으로 넘겨, 탭 아이콘이 잠깐 이전 사이트 것이 되고(저장 아이콘 파일도 새 주소로 잘못 저장될 수 있음) 
- 수정: `BrowserTab.iconHost`(현재 `favicon` 이 속한 호스트) 추가. `onPageStarted` 는 같은 사이트일 때만 넘어온 아이콘을 쓰고 아니면 저장 아이콘/새로 받기, `onReceivedIcon` 은 `view.url` 호스트가 이동 중인 호스트(`curHost`)와 다르면 아이콘 반영·저장을 모두 건너뜀, 비동기 `Favicons.fetch` 결과도 호스트가 같을 때만 반영. 실기기 확인 전

**미디어 패널 버튼 5개 (v3.7.83)**
- Android 13+ 의 시스템 미디어 패널(삼성 One UI 등)은 알림의 `addAction` 이 아니라 세션의 `PlaybackState` 로 버튼을 그림: 이전·재생/일시정지·다음 3칸만 기본이고 `ACTION_FAST_FORWARD/REWIND` 같은 표준 동작엔 칸이 없음 → `MediaService.showControls` 에서 `PlaybackState.CustomAction` 두 개(`CA_REW` 10초 뒤로 `ic_rewind_10`, `CA_FF` 10초 앞으로 `ic_forward_10`)를 추가, `MediaSession.Callback.onCustomAction` 에서 `skip ∓SKIP_MS` 처리
- 칸 배치: 첫 커스텀 = 왼쪽 끝, 두 번째 = 오른쪽 끝, 가운데 이전·재생·다음 → ⏪ ⏮ ⏯ ⏭ ⏩. (Android 12 이하는 알림 버튼 5개가 그대로 쓰임.) 기기·제조사 UI 에 따라 칸 배치가 다를 수 있음. 실기기 확인 전

**「번역 해제」 아이콘 (v3.7.82)**
- `res/drawable/ic_globe_off.xml` 신설(`ic_globe` 에 빗금 한 줄, 24dp 격자·선 1.8·tint). `showLinkMenu` 의 「번역 해제」 항목이 `ic_close` 대신 사용

**이미지 번역: 영어 남음 줄이기 + 「번역 해제」 (v3.7.81)**
- 영어가 남던 원인: ① 키 없는 번역이 `sl=auto` 라 짧은 이름 줄(「Written by Huma Raza」)의 언어를 잘못 감지(→ 「Race Power」) ② Google 이 이름·브랜드를 그대로 두고 원문을 괄호로 덧붙임(「…(Arbhylle Artiaga)의 그림」) ③ `IMG_SYSTEM` 이 이름·브랜드를 한글로 쓰라고 하지 않음
- 수정: `ImageOcr.Result.lang`(latin/ja/zh-CN)으로 `FreeTranslator.translate(…, source)` 의 `sl` 을 지정(라틴은 페이지 lang 이 비었거나 en·ko·ja·zh 일 때만 `en`, 그 외 auto. 번역 캐시 키에 source 포함). `tidyImgText` 가 한글이 있는 번역에서 영문 2글자 이상 괄호(`(Race Power)`)를 지움. `IMG_SYSTEM` 에 「이름·브랜드·영어 단어는 한글 음차, 알파벳·괄호 병기 금지, TV·OK·CD 같은 약어만 유지, 로고 조각·잡음은 그대로 반환」 추가
- 한계: 키 없는 Google 번역은 브랜드·이름을 영어로 두는 일이 남음(Gemini 번역을 켜면 음차). 영어 안의 단어도 Google 이 그대로 둘 수 있음
- 제목+로고가 한 상자로 합쳐지던 것: 열린 바탕 덩어리를 줄로 나누는 조건(`splitLines`)을 단색 여백뿐 아니라 줄 높이 1.6배 이상 차이·줄 사이가 줄 높이 1.2배보다 큰 경우까지 넓힘(가로쓰기만, 세로쓰기는 한 문장으로 봄)
- 꾹 누른 메뉴(`showLinkMenu`): 이미지에 덮개가 이미 있으면(`PageTranslator.isImageTranslated` — 같은 주소 `img.__evHas`) 「이미지 번역」 대신 「번역 해제」(`untranslateImage` → 페이지 `__evImgClearOne`, 그 이미지 덮개만 걷음). 메뉴는 페이지에 한 번 물어본 뒤 뜸(수 ms). 실기기 확인 전

**이미지 번역: v3.7.79 검토 보완 (v3.7.80)**
- 열린 바탕 판별(`bubbleRect` 의 창 가장자리 두 변 이상 닿음)을 실제 만화(「In My Next Life」)로 확인: 말풍선 4개는 윤곽선 안(넓힘), 머리말 제목·크레딧·자막은 열린 바탕(안 넓힘)으로 갈림
- 줄 나누기는 열린 바탕 **이면서 단색(`flatRatio` 0.6 이상)** 일 때만. 그림 위에 쓴 여러 줄 글은 예전처럼 한 문장으로 합쳐 번역(줄마다 번역하면 문장이 끊겨 어색)
- `separate` 의 글자 범위(`cores`)에서 가장자리 여유(3px)를 뺌 — 여유까지 넣으면 줄 간격이 촘촘한 줄끼리 글자 범위가 겹쳐 갈라 내지 못하고 건너뜀. 실기기 확인 전

**이미지 번역: 말풍선이 아닌 글은 줄 모양 지키기 (v3.7.79)**
- 증상(영어 만화 「In My Next Life」): 머리말의 제목·로고·크레딧(흰 여백 위 글)이 한 덩어리로 합쳐져 큰 상자 하나에 한 문장으로 번역됨 → 줄 위치·글자 크기 같은 원래 형식이 사라짐. 원인: 흰 여백은 `bubbleRect` 채우기가 끝없이 번져 넓힌 범위끼리 30% 이상 겹쳐 `mergeBubbles` 가 합쳤고, v3.7.78 의 「간격 6px 이하」 합치기도 크레딧 줄을 붙임
- 수정: ① `bubbleRect` 가 `Bub(rect, open)` 을 돌려줌 — 채운 바탕이 탐색 창 가장자리 두 변 이상에 닿으면 윤곽선으로 막힌 말풍선이 아니라 열린 바탕(`open`)으로 보고 넓히지 않음(원래 글자 범위만) ② 열린 바탕의 여러 줄 덩어리는 줄마다(`Raw.lines`) 따로 번역 상자를 만듦 ③ 합치기는 글자 범위끼리 10% 넘게 겹칠 때와 윤곽선 안 말풍선(넓힌 범위 30% 겹침)만 — v3.7.78 의 간격 6px 규칙은 뺌
- 한계: 윤곽선이 끊어진 말풍선·윤곽선 없는 단색 상자도 열린 바탕으로 봐 글자 범위만 덮음(원문 조각이 남을 수 있음). 열린 바탕의 여러 줄 문단은 줄마다 번역돼 문장이 어색할 수 있음. 실기기 확인 전

**이미지 번역: 한 말풍선 안 조각 합치기 (v3.7.78)**
- 증상: 한 말풍선 안에서 「ー..」·「0」 같은 작은 조각이 따로 읽혀 각자 번역 상자가 되어 번역 글자끼리 겹침 (덮개를 못 넓힌 경우 `mergeBubbles` 의 30% 겹침 기준이 안 걸림)
- 수정: `mergeBubbles` 합치기 조건에 ① 읽은 글자 범위(`kept` rect)끼리 조금이라도 겹침 ② 간격 6px 이하이고 바탕색 차이 합 60 이하 를 추가(`rectGap`·`colorClose`). v3.7.77 `separate` 는 서로 다른 말풍선 덮개용으로 그대로 둠. 실기기 확인 전

**이미지 번역: 덮개끼리 겹침 풀기 (v3.7.77)**
- 증상: 이웃한 말풍선의 번역 상자가 서로 겹쳐 글이 가려짐 (말풍선 덮개를 넓히는 `bubbleRect`·세로쓰기 가로 넓히기·가장자리 여유 때문에, 넓힌 범위가 30% 미만 겹치는 말풍선은 `mergeBubbles` 에서 합쳐지지 않고 따로 남아 겹침)
- 수정: `ImageOcr.separate` — 모든 덩어리를 원본 좌표로 만든 뒤, 겹치는 쌍마다 겹침이 작은 축(좌우/위아래)으로 맞닿는 가장자리를 겹침 가운데에서 서로 잘라 냄(사이 1샘플 간격). 실제로 읽은 글자 범위(`Grp.core` + 가장자리 3px)는 안쪽으로 자르지 않아 원문은 계속 덮임. 글자 범위끼리 두 축 모두 갈라 낼 수 없는 쌍은 그대로 둠. 최대 3번 반복(3개 이상 연쇄 겹침 대비)
- 번역문 글자 크기는 잘린 상자에 맞춰 `fit` 이 다시 맞춤. 실기기 확인 전

**이미지 꾹 눌러 「이미지 번역」 (v3.7.76)**
- 이미지(또는 사진 링크)를 꾹 누르면 나오는 메뉴(`showLinkMenu`)의 「새 탭에서 이미지 열기」 아래에 「이미지 번역」 추가 → `PageTranslator.translateImage(url)`
- 흐름: 번역 표식(`window.__evId`)을 새로 만들고 `IMG_COLLECT_JS` 로 페이지 이미지를 모은 뒤, 눌러 둔 주소(`#` 뒤 제외)와 같은 것 하나를 골라 기존 `runImages` 로 처리(글자 읽기 → 번역 → 덮기). 본문 글은 번역하지 않고, 「이미지 속 글자도 번역」 설정이 꺼져 있어도 동작. 끝나면 「원문 보기」 로 되돌릴 수 있음(페이지 번역과 같은 되돌리기)
- 번역 중에 다시 누르면 멈춤. 이미 번역한 이미지(`__evHas`)·화면에 없는 이미지·작은 이미지(120x60 미만)는 「이미지를 찾지 못했어요」. 빌드·실기기 확인 전

**이미지 번역 정확도: 읽는 순서 + 만화용 지시문 (v3.7.75)**
- `PageTranslator.readingOrder`: 글자 덩어리를 줄(띠, 높이 중앙값 기준)별로 위→아래, 한 줄 안에서는 세로쓰기가 많으면 오른쪽→왼쪽·아니면 왼쪽→오른쪽으로 정렬해 번역 묶음에 넣음(`i` 번호는 그대로라 결과 짝짓기는 같음)
- `IMG_SYSTEM`: 이미지용 번역 지시문 — 연속 대사의 말투·이름 일관성, OCR 오인식(ー→1/l/|, 한자·작은 가나) 문맥으로 바로잡기, 말풍선에 들어갈 짧은 말, 효과음은 한글 의성어. 이미지 번역만 씀(웹 글 번역은 `TRANSLATE_SYSTEM` 그대로)
- Gemini 번역일 때 효과가 큼. 키 없는 번역(`FreeTranslator`)은 덩어리별 번역이라 순서·지시문 영향이 거의 없음. 실기기 확인 전

**이미지 번역: 일본어 대사 누락 완화 (v3.7.74)**
- `rawBlocks` 에서 가나가 2글자 이상 읽힌 덩어리는 확신도 기준을 낮춤(덩어리 0.4→0.25, 줄 0.25→0.12). 그 외(가나 없는 한자·라틴)는 그대로라 그림 속 무늬를 글자로 읽는 오탐은 늘리지 않음
- 대상: 「いや」「え—…やだよ めんどくさい」 처럼 세로쓰기·색 말풍선에서 확신이 낮게 나와 버려지던 대사(원인 추정, 실기기 확인 전). 「撫子」 같은 이름·한자 오인식은 그대로

**이미지 번역: 장음 기호(ー)를 1로 읽던 것 수정 (v3.7.73)**
- 원본(만화)에서 확인: 「勿体ねー」 의 ー 를 인식기가 `1` 로 읽어 번역이 「물론 1」 처럼 됨 (세로쓰기에서는 선 하나라 `1`·`l`·`I`·`|` 로 읽힘)
- 수정: `ImageOcr.fixLongMark` — 히라가나·가타카나 바로 뒤에 붙은 `1 l I | ｜ 丨` 중 뒤에 숫자가 이어지지 않는 것을 ー 로 되돌림. 줄마다 `rawBlocks` 에서 적용(번역 전). 가나 뒤가 아닌 숫자(「第1話」 등)는 건드리지 않음
- 아직 못 고침: 「え—…やだよ めんどくさい」·「いや」 가 번역 안 되고 남는 것, 「撫子」 같은 이름·한자 오인식(원인 확정 전, 실기기 확인 전)

**이미지 번역 어색함 손질 (v3.7.72)**
- 스크린샷(만화 말풍선: 파랑·분홍 말풍선, 세로쓰기 일본어)에서 본 문제: ① 긴 한글 번역문이 세로로 한 글자씩 세워져 어색함 ② 그림 위 글자용 흐림 상자가 투명(0.4)해 원문 일본어가 비쳐 번역 안 된 것처럼 보임 ③ 일부 말풍선 글자는 번역 안 되고 남음 ④ 세로쓰기를 잘못 읽어 엉뚱한 번역('무코가 오지 않니? 메이크업', '물론 1', '뭐')
- 수정: `fit()` 에서 세로 쓰기는 번역문이 공백 뺀 6글자 이하일 때만 고름(그 외는 가로로 줄바꿈). 흐림 상자 배경 알파 0.4→0.78, 블러 7→9px
- 아직 안 고침(원인 추정만): ③ 은 `rawBlocks` 의 확신도 거르기(MIN_CONF 0.4/LINE_MIN_CONF 0.25)나 번역문이 원문과 같을 때 건너뛰는 처리(`processImage`) 때문일 수 있음, ④ 는 일본어 인식기가 세로쓰기·색 말풍선을 잘못 읽은 것으로 보임 — 같은 이미지로 확인이 필요함

**폰↔태블릿·분할 화면에서 페이지가 확대돼 보이던 것 수정 (v3.7.71)**
- 증상: 폰 화면에서 태블릿 UI 로 바뀌거나(창을 넓힘·접이식 펼침) 분할 화면·AI 분할로 웹 영역 폭이 바뀌면 웹페이지가 확대돼 보임
- 추정 원인(실기기 확인 전): 웹뷰가 페이지 배율(화면에 맞춤 배율)을 옛 폭 기준으로 들고 있음. 기존 `REFIT_VIEWPORT_JS` 는 viewport 메타가 있는 모바일 페이지만 다시 맞추고, 사이트 모드가 바뀌어 다시 불러온 페이지는 이전 배율을 물려받을 수 있음
- 수정: `refitPageScale` — `WebView.setInitialScale(1)` 후 곧바로 `setInitialScale(0)` 으로 처음 배율을 한 번 재설정해 현재 폭·뷰포트 기준으로 다시 계산하게 함. 호출 시점: ① `webRelayout`(창 크기 변경 160ms 뒤, 뷰포트 JS 다시 쓴 다음) ② AI 분할 등으로 웹 영역 폭이 멈춘 뒤 420ms(`areaRefit`) ③ 폰↔태블릿으로 사이트 모드가 바뀌어 다시 불러온 페이지의 `onPageFinished`(80ms·600ms 두 번) ④ 안 보이는 동안 폭이 바뀐 탭을 선택할 때(`BrowserTab.refitPending`). PiP·전체화면 영상 중에는 안 함
- 핀치로 확대해 둔 상태는 폭이 바뀌면 화면에 맞춤으로 되돌아감

**이미지 속 글자 번역 (v3.7.60)**
- 설정 > 브라우저 > 번역 > 「이미지 속 글자 번역」(또는 번역 설정 창의 같은 이름 체크박스). 기본은 꺼짐. 켜면 「페이지 번역」·「항상 번역」·AI 어시스턴트의 번역 칩이 본문 글 번역이 끝난 뒤 이어서 이미지도 번역함
- 흐름: 페이지 JS(`PageTranslator.IMG_COLLECT_JS`)가 `document.images` 중 보이고 120x60 이상인 것을 화면에 보이는 순서로 최대 40장 골라 줌(lazy 로딩 `data-src` 계열 포함, svg·blob 주소 제외) → 앱이 웹뷰와 같은 UA·쿠키·Referer 로 내려받고(`AssistantImages.fetchBytes`) → `ImageOcr` 가 기기 안(ML Kit, 모델 포함)에서 글자를 읽고 → 기존 번역 경로(Google 번역 / Gemini, `translateBatch`)로 번역 → 페이지의 `__evImgApply` 가 이미지 위에 번역문 상자를 얹음
- 인식 언어: 영문 · 일본어 · 중국어(한글은 이미 한국어라 건너뜀). 페이지 `lang` 으로 시도 순서를 정하고, 라틴 → 일본어 → 중국어 순으로 결과가 맞는지 보며 고름. 가나가 없고 한자만 있으면 중국어로도 읽어 더 많이 읽은 쪽을 씀
- 세로로 긴 이미지(웹툰)는 2200px 높이 조각(2000px 간격)으로 나눠 읽고, 조각 경계에 걸린 글은 중심이 속한 조각에서만 씀. 가로는 2000px 이하로 줄여 읽음
- 덮는 방식: 글자 덩어리 둘레 색(가장 많은 색)을 배경으로, 밝기에 따라 검정/흰 글자를 씀. 상자 안에 들어가도록 글자 크기를 맞추고, 스크롤·크기 변화·레이아웃 이동을 따라감(문서 맨 끝 `#__ev_img_root` 층, 포인터 이벤트 없음). 세로쓰기처럼 좁고 긴 글은 번역문이 들어가게 가로로 조금 넓힘
- **이미지 효과 (v3.7.70)**: 번역 중 효과(v3.7.61~69 의 스캔 띠·무지개 테두리·별 등)는 모두 없앰 — `__evImgBusy` 는 호출만 받고 아무것도 그리지 않음. 남긴 것은 번역이 끝나 번역문을 덮을 때(`__evImgApply`)의 등장 효과뿐: 번역 상자가 흐림(blur 8px)·확대(1.06)에서 또렷하게(0.48초, 상자마다 70ms 간격) 나타남. 글자를 못 읽은 이미지는 아무 변화 없음. 「원문 보기」는 `__evRestore` + `__evImgClear`
- **말풍선 덮기 (v3.7.67)**: 글자 덩어리마다 둘레 바탕색(`sampleBg`)에서 색이 이어진 곳을 퍼 올려(채우기, 색 차이 합 60 이하, 창은 글자 범위 +0.8배+24px·최대 200px) 말풍선 안쪽 사각형까지 넓힘 → 글자로 못 읽은 작은 글자·말끝·후리가나도 같은 색 상자로 덮임. 넓힌 범위가 겹치는(30% 이상) 덩어리는 한 말풍선으로 보고 읽는 순서(세로쓰기는 오른쪽 줄부터, 가로쓰기는 위 줄부터)대로 이어 한 문장으로 번역. 넓힌 상자는 윤곽선에 닿지 않게 2px 안쪽으로 줄이고 글자 범위는 항상 포함, 넓힌 상자에는 가장자리 여유(3px)와 세로쓰기 가로 넓히기를 적용하지 않음. 번역문 글자 크기는 원래 글자 크기(`fs`)의 1.5배를 넘지 않게 함. 글자 인식 확신 기준은 덩어리 0.4·줄 0.25 로 낮춰 흘림체 말풍선 글자도 잡음
- **그림 위 글자는 블러 (v3.7.68)**: 글자 덩어리 바로 바깥 둘레(3·6px) 중 바탕색과 비슷한 곳(색 차이 합 48 이하)이 60% 미만이고 말풍선 확장도 거의 없으면(넓힌 넓이가 글자 넓이의 1.5배 미만) 그림 위 글자로 봄(`Block.blur`, JSON `bl`). 이때는 바탕색 상자 대신 상자에 `backdrop-filter: blur(7px)` + 바탕색 40% 막을 깔아 원문을 뭉개고, 번역문에는 바탕색 후광(text-shadow)을 줌. 말풍선·단색 바탕은 기존처럼 같은 색 상자로 덮음
- **세로쓰기 (v3.7.69)**: 읽는 순서는 이미 세로쓰기(오른쪽 줄부터)를 따름. 번역문 글자는 기본 가로쓰기이고, 상자가 세로로 길고 좁을 때(높이 > 너비 1.5배) 가로 크기와 세로쓰기(`writing-mode: vertical-rl`, `text-orientation: upright`) 크기를 모두 맞춰 보고 세로쓰기가 15% 넘게 더 크면 세로쓰기로 씀(`fit`). 말풍선으로 넓어진 상자는 대개 가로쓰기가 이김
- 「원문 보기」는 본문 글과 이미지 덮개를 함께 되돌림(`__evRestore` + `__evImgClear`)
- 한계: CSS 배경 이미지·canvas·blob 주소 이미지는 못 읽음. 말풍선이 아닌 그림 위 글자는 배경색이 어색할 수 있음. 이미지가 많으면 시간이 걸림(한 번에 40장까지, 번역 서버가 막으면 멈춤). 글자 인식 모델(영·일·중)이 들어가 APK 가 수 MB 커짐
- 의존성: `com.google.mlkit:text-recognition(-japanese/-chinese):16.0.1`, `play-services-tasks:18.2.0`

**탭 / 빠른 검색**
- 멀티 탭 (하단 숫자 버튼 → 탭 목록, 탭 닫기, 새 탭)
- 새 탭을 열면 주소창이 바로 활성화됨
- **탭 그룹**: 탭 목록에서 탭의 ⋮ 버튼(또는 길게 누르기) → 새 그룹에 추가 / 다른 그룹으로 이동 / 그룹에서 제거
  - 그룹 헤더를 누르면 접기/펼치기, ⋮ → 이름·색상 변경, 그룹 해제, 그룹의 탭 모두 닫기, 그룹에 새 탭 추가
  - 링크·팝업으로 연 탭은 연 탭 옆에 같은 그룹으로 열림
  - 메뉴 → "현재 탭을 새 그룹으로" 로 한 번에 그룹 만들기
  - 탭이 모두 사라진 그룹은 자동 삭제
- 검색어 자동완성 (방문 기록 + Google 추천어)
- 단축어: `g 검색어`(Google) `n`(네이버) `d`(DuckDuckGo) `b`(Bing) `yt`(YouTube) `w`(위키백과) `map`(지도)
- 검색 엔진 선택 (메뉴 → 검색 엔진)

**태블릿 UI** (화면 최소 폭 600dp 이상, 분할 화면·접이식 펼침에도 자동 전환)
- 상단 가로 탭 스트립: 파비콘·제목·닫기 버튼, 선택한 탭 강조, 그룹 색 밑줄 + 그룹 이름 칩(눌러서 접기/펼치기, 길게 눌러 메뉴)
- 툴바에 뒤로·앞으로·새로고침·홈 + 주소창 + 메뉴 (하단 바는 숨김)
- 키보드 단축키: Ctrl+T 새 탭 / Ctrl+W 탭 닫기 / Ctrl+L 주소창 / Ctrl+R·F5 새로고침 / Ctrl+Tab(+Shift) 탭 전환 / Ctrl+1~9 탭 선택 / Alt+←→ 뒤로·앞으로
- 앱을 켤 때 1번 창이 비어 있고 다른 창에 탭이 남아 있으면, 탭이 있는 창이 먼저 열림
- 이미 켜져 있을 때 시스템 작업 표시줄에서 에버그린 아이콘을 끌어다 화면 옆에 놓으면 새 창이 옆에 열림 (멀티태스킹). 앱의 launchMode 를 standard 로 두어 시스템이 "이미 실행 중입니다" 로 막지 않게 함
- 메뉴 → "데스크톱 사이트" 로 탭별 데스크톱 모드 전환
- 뒤로가기: 페이지 기록이 있으면 페이지 뒤로 → 없으면 (링크로 연 탭은) 연 탭으로 돌아가며 닫힘 → 마지막 탭이면 앱 종료

**광고 차단**
- 광고/트래커 도메인 차단 (내장 목록 + 메뉴에서 목록 업데이트)
- 화면에 남는 광고 영역 숨김(CSS)
- 주소 경로 규칙(`||example.com/ads/` 형태)으로도 차단, 차단 목록은 여러 개를 동시에 내려받아 업데이트
- 설정 > 광고 차단 현황: 이 페이지·오늘·전체 차단 건수, **최근 7일 막대그래프(날짜별 차단 건수, 오늘 강조)**, 종류별 건수, 많이 막은 사이트, 차단 목록 상태
  - 그래프는 보안 현황과 같은 7일 기록(광고·팝업 차단)을 쓰며 「통계 초기화」로 함께 지워짐
- 새 탭 화면 「개인정보」 위젯: 광고 차단 카드 아래에 **보안 현황 카드**(보호 수준 · 오늘 차단 수). 누르면 카드가 펼쳐져 보안 현황 창이 됨
- 사용자 동작 없이 열리는 팝업 / 외부 앱·스토어 자동 이동 차단
- 한계: YouTube 등 영상 서비스가 광고를 자기 도메인에서 직접 내려주는 경우는 막을 수 없음

**영상 재생**
- 하드웨어 가속, 자동재생 허용, 전체화면 재생(화면 켜짐 유지)
- 전체화면 재생 중 홈으로 나가면 PiP(작은 창)로 계속 재생
- 재생 속도 조절 0.5x ~ 3x (메뉴 → 재생 속도)
- **내장 플레이어로 열 수 있는 영상 확대 (v2.4.19)**: 페이지 안의 video 태그뿐 아니라 shadow DOM 안 영상, 여러 겹 iframe,
  `data-*` 설정(video.js 등)·인라인 스크립트(JW Player 등)에 적힌 영상 주소, 미리 불러오기 링크, `<video>` 가 불러온 확장자 없는 주소,
  fetch/XHR 응답 종류(Content-Type)가 m3u8/mpd 인 주소, `?format=m3u8` 같은 쿼리, f4v·m2ts·ogm·asf 등 더 많은 확장자를 후보에 올림.
  후보는 탭마다 60개까지 기억하고 최근 것이 먼저, 한 번에 25개까지 보여 줌
- **영상 아래 버튼 (v2.4.20)**: 웹페이지에서 크게 보이는 영상 바로 아래 오른쪽에 「내장 플레이어로 열기」「PiP로 보기」 버튼이 뜸 (아래에 자리가 없으면 영상 안쪽 위 오른쪽). 나타나고 사라질 때 부드러운 애니메이션, 스크롤 중에도 끊김 없이 따라다님(문서 좌표 + transform). 영상이 전체화면이거나 PiP 중이면 숨김
- **유튜브 내장 플레이어 (v2.4.21)**: 유튜브 영상 페이지(m.youtube.com / youtu.be / shorts / 다른 사이트에 임베드된 유튜브)에서도 「내장 플레이어로 열기」가 됨. 페이지 영상은 blob 이라 주소를 못 쓰므로, 영상 번호만 뽑아 유튜브 앱용 내부 API(안드로이드 VR → iOS 순)로 재생 주소를 직접 받음. 최대 1080p DASH(화질 선택 가능) → HLS → 일반 mp4(360p) 순으로 시도하고, 라이브는 HLS. 로그인이 필요한 영상(나이 제한·비공개·멤버십)과 유튜브가 봇 확인을 요구하는 경우는 안 열릴 수 있음. 유튜브 영상은 저장 불가. 유튜브가 내부 API 를 바꾸면 `YouTube.kt` 의 clientVersion/UA 를 올려야 함
- **미러링 화면 컨트롤 (내장 플레이어 스타일)**: 내장 플레이어가 못 여는 영상을 「화면 그대로 보기」로 창 가득 볼 때, 영상 위에 앱 컨트롤을 얹음 (페이지의 기본 조작은 끔)
  - 위: 닫기 · 제목/사이트 · 화면 비율(맞추기/채우기/늘리기) · 작은 창(PiP) · 회전
  - 아래: 재생/일시정지 · 10초 뒤로/앞으로 · 시간 · 진행 막대(끌면 이동 시간 표시) · 배속(눌러서 순환, 메뉴의 재생 속도와 같은 값)
  - 제스처: 한 번 탭 = 컨트롤 보이기/숨기기, 두 번 탭 = ±10초(연달아 하면 누적), 길게 누르기 = 2배속, 가로로 쓸기 = 시간 이동
  - 한계: 화질·음성 선택, 자막 번역, 실시간 자막, 영상 저장은 파일 주소를 알 수 없는 영상이라 옮기지 못함
- **PiP 작은 창의 재생/일시정지 버튼**: 웹 영상 PiP·내장 플레이어 PiP 모두 시스템이 그려 주는 재생/일시정지 버튼이 뜸
- 메뉴의 미디어 플레이어는 곡·영상이 바뀌면 제목·아티스트(페이지가 알려 주는 정보)와 길이를 바로 갱신함
- 유튜브는 영상을 틀 때마다 자막이 저절로 켜지지 않게 새 영상 시작 직후 한 번만 꺼 줌 (그 뒤에 직접 켜는 자막은 그대로 유지)
- 메뉴 맨 위 미디어 플레이어는 여러 창을 쓸 때 다른 창에서 재생 중인 미디어도 함께 보여 주고, 재생/일시정지·이동·넘기기를 그대로 조작할 수 있음 (제목 부분을 누르면 그 창으로 이동)

**다운로드**
- **빠른 다운로드** (Android 10+, 직접 연결일 때): 서버가 구간 요청을 지원하면 파일을 조각내 최대 8개 연결로 동시에 받음
  - 끊기면 받은 곳부터 이어받기, 서버가 동시 연결을 거부하면 연결 수를 줄여 계속, 끝까지 실패하면 시스템 다운로더로 자동 전환
  - 진행률·속도 알림과 취소 버튼 (Android 13+ 는 알림 권한 필요), 앱을 나가도 계속 받음
  - Android 9 이하는 기존 시스템 다운로더 사용
- 다운로드 중에는 화면 아래에 **진행 카드**(파일명·퍼센트·속도·진행 막대·취소)가 뜨고, 누르면 다운로드 목록이 열림 (빠른 다운로드 한정)
- 파일 다운로드, 이미지 길게 눌러 저장, 링크 길게 눌러 새 탭/복사
- 메뉴 → "페이지의 영상 파일 찾기": 내장 플레이어가 영상을 찾는 방식 그대로 페이지의 영상을 찾아 저장 (v2.4.19 확대)
  - 일반 파일(mp4·webm·mkv·flv·f4v·m2ts 등), 주소에 확장자가 없는 영상, 다른 도메인 iframe 안에서 재생된 영상
  - **HLS(m3u8) 스트리밍** (Android 10+): 조각을 여러 개 동시에 받아 이어 붙이고, 가능하면 mp4 로 다시 묶어 저장 (재인코딩 없음)
    - 마스터 목록이면 가장 화질 좋은 것을 고름, 영상·소리가 따로 있어도 하나로 묶음, AES-128 암호화 조각은 키를 받아 풀어서 저장
    - 코덱이 mp4 에 맞지 않으면 이어 붙인 원본(.ts)을 그대로 저장, 아직 방송 중인 목록은 지금까지 올라온 조각까지 저장
  - 페이지가 만들어 둔 blob 파일(URL.createObjectURL)
- 내장 플레이어의 저장 버튼도 같은 방식: 직접 파일은 재생에 쓴 쿠키·Referer 로 받고, HLS 는 영상 제목을 파일 이름으로 저장
- 지원하지 않는 것: DRM 보호 영상(SAMPLE-AES, Widevine 등), mpd(DASH)·ism 스트리밍, MediaSource 로만 만들어지는 blob 영상
  (저작권·서비스 약관을 지켜서 사용하세요)

**다운로드 목록 (앱 안)**
- 메뉴 → "다운로드 목록" (다운로드 알림을 눌러도 열림): 받은 파일을 최근 순으로 표시, 누르면 열기
- 받는 중인 파일은 맨 위에 진행률·속도와 함께 표시, ⋮ → 다운로드 취소
- 파일 ⋮ (또는 길게 누르기) → 열기 / 공유 / 폴더로 이동 / 삭제
- **폴더**: 위쪽 칩의 "＋ 폴더"로 폴더를 만들고 파일을 옮겨 정리. 폴더 칩을 길게 누르면 이름 변경 / 삭제
  (폴더는 앱 안에서만 쓰는 분류이며 실제 파일 위치는 그대로입니다. 폴더를 지워도 파일은 남습니다)
- Android 10+ 는 이 앱이 받은 파일이, Android 9 이하는 시스템 다운로더로 받은 파일이 표시됩니다

**북마크**
- 메뉴 → "북마크에 추가" (Ctrl+D): 이름·주소·폴더를 정해 저장. 이미 북마크한 페이지는 "북마크 수정"(삭제 가능)
- 메뉴 → "북마크": 목록에서 누르면 현재 탭에서 열기, ⋮ → 새 탭에서 열기 / 수정 / 폴더로 이동 / 주소 복사 / 삭제
- **북마크 폴더**: 칩의 "＋ 폴더"로 만들고, 길게 눌러 이름 변경 / 삭제 (폴더를 지워도 북마크는 남음)
- 주소창 자동완성에 북마크가 먼저 나타남

**크롬 확장 프로그램 (v2.7.1 · 백그라운드 v2.7.2 · 팝업/바 버튼 v2.7.3 · 지원 범위 확대 v2.8.0 · 큰 확장 설치 v2.8.1 · 리다이렉트 규칙 v2.8.2 · webRequest · 헤더 고치기 · 우클릭 메뉴 v2.8.3 · 글자 선택 메뉴 · onAuthRequired v2.8.4 · 팝업 개선 v2.8.5 · 목록 화면 v2.8.6)**
- 설정 > 확장 프로그램 > ＋ 추가: **크롬 웹스토어에서 추가**(웹스토어 주소 또는 영문 32자 ID 를 넣으면 구글 업데이트 서버에서 .crx 를 받아 설치) 또는 .zip · .crx 파일에서 추가
- 웹스토어 확장 프로그램 상세 페이지(chromewebstore.google.com/detail/… · chrome.google.com/webstore/detail/…)를 열면 '설치' 알림이 뜸 (시크릿 탭 제외, `offerStoreInstall`)
- 웹스토어의 「Chrome에 추가」 버튼은 안드로이드 웹뷰에서 동작하지 않아서, 위 방식으로 대신함
- **백그라운드 (v2.7.2)**: `ExtensionManager.syncBackground` 가 background(service worker · scripts)를 눈에 안 보이는 웹뷰의 일반 페이지(`https://ext.evergreen.invalid/<id>/__evx_bg.html`)로 돌림 (service worker 는 `type=module` 도 지원, `importScripts` 는 동기 XHR 로 흉내)
- **팝업 · 바 버튼 (v2.7.3)**: `ExtensionPopup` 이 action 팝업을 앱 안 카드(`ExtensionManager.newPopupView` 웹뷰, 폭 360dp · 내용 높이에 맞춰 자동 조절)로 띄움. 상/하단바 편집에 `extensions` 버튼(`TopBarConfig`)이 추가돼 바에서 `ExtensionsUi` 를 바로 열 수 있음
  - 메시지: 콘텐츠 스크립트·팝업 → 백그라운드 `runtime.sendMessage`(콜백/Promise, `return true` 비동기 응답), 백그라운드 → 보고 있는 탭 `tabs.sendMessage`, `tabs.query/get/create`, `chrome.alarms`, `onInstalled/onStartup`
  - 백그라운드의 `fetch` 는 manifest 의 host 권한에 맞는 http(s) 주소만 앱(HttpURLConnection)이 대신 요청해 CORS 없이 돌려줌 (최대 15MB, Referer·Origin 은 안 보내고 쿠키는 `credentials: 'include'` 일 때만 보냄). XMLHttpRequest 는 대신해 주지 않음
  - **지원 범위 확대 (v2.8.0)**:
    - 포트: `runtime.connect` / `onConnect`(콘텐츠 스크립트 · 팝업 ↔ 백그라운드), `tabs.connect`(백그라운드 → 보고 있는 탭). 열기 · 메시지 · 닫기를 `__evxPort` 봉투 메시지로 주고받음 (`ext_shim.js` 의 `mkPort` / `handlePort`)
    - `storage.onChanged` 를 창 사이에 공유: 쓰는 쪽이 `Bridge.sbcast` 로 알리면 백그라운드 · 팝업 · 이 확장이 적용된 탭이 받음. 영역별 `storage.local.onChanged` 등도 지원
    - 탭에 스크립트 넣기: `scripting.executeScript`(func + args · files) · `insertCSS` · `removeCSS`, `tabs.executeScript` · `insertCSS` · `removeCSS` · `update` · `reload` · `goBack` · `goForward` (보고 있는 탭만, host 권한 또는 `activeTab` 필요)
    - 요청 차단: `declarativeNetRequest` 의 `block` · `allow` · `allowAllRequests` 규칙을 정적(`rule_resources`) · 동적(`updateDynamicRules`, 파일에 저장) · 세션(`updateSessionRules`, 메모리) 모두 적용. 조건은 `urlFilter`(`||` · `|` · `*` · `^`) · `regexFilter` · `resourceTypes` · `domainType` · initiator/request 도메인. 우선순위가 높은 규칙이 이기고 같으면 허용이 이김. `MainActivity.shouldInterceptRequest` 에서 `ExtensionManager.dnrBlocks` 로 검사 (요청 종류는 확장자 · Accept 로 추정). `updateEnabledRulesets` · `getEnabledRulesets` 도 지원
    - `chrome.cookies`(get · getAll · set · remove, host 권한 필요, 앱의 CookieManager 사용 — 이름·값만 알 수 있고 HttpOnly·만료는 알 수 없음), `chrome.windows` 기본 동작
    - 백그라운드 `fetch` 는 `credentials: 'include'` 일 때 쿠키를 붙이고 `Set-Cookie` 를 저장. 백그라운드의 `runtime.sendMessage` 는 열린 팝업 · 옵션 페이지로 전달
    - 같은 페이지의 콘텐츠 스크립트 묶음들이 `runtime.onMessage` · `onConnect` · `storage.onChanged` 리스너를 함께 씀. `include_globs` · `exclude_globs` 지원
    - 보안: 메시지 · 답장 · 저장소 알림은 이 확장의 콘텐츠 스크립트가 적용되는 주소의 페이지나 확장 자신의 페이지에만 보냄 (`ExtensionManager.canReach`)
  - **큰 확장 설치 (v2.8.1)**: 파일 160MB · 압축 해제 1GB 까지 설치 가능, 카드의 백그라운드 제한 안내 문구 제거
  - **리다이렉트 규칙 (v2.8.2)**: `declarativeNetRequest` 의 `redirect`(url · extensionPath · regexSubstitution · transform) · `upgradeScheme` 적용 (`ExtensionManager.dnrRedirect`, 하위 리소스는 `dnrRedirectResponse` 가 대신 받아 돌려줌, 최상위 문서는 `loadUrl`). 우선순위는 허용 > 차단 > 리다이렉트
  - **webRequest · 헤더 고치기 · 우클릭 메뉴 (v2.8.3)** (`ExtensionManager.netIntercept` · `contextMenuEntries`):
    - 백그라운드가 `webRequest.onXxx.addListener` 로 등록하면(`Bridge.wrreg`) 앱이 요청마다 백그라운드 웹뷰의 `__evxWr` 를 불러 줌. 막는(blocking) 리스너는 `Bridge.wrres` 로 결과를 돌려주고, 요청 스레드가 최대 1.5초 기다림 (늦으면 그 확장 프로그램은 20초 동안 건너뜀)
    - 요청·응답 헤더를 보거나 고쳐야 하면(헤더 리스너, `modifyHeaders` 규칙) 앱이 HttpURLConnection 으로 대신 받아 돌려줌 (GET 만, 쿠키는 CookieManager 로 주고받음, 최상위 문서의 3xx 는 loadUrl 로 이동)
    - `contextMenus`: 항목은 파일(`cm_items.json`)에 저장돼 앱을 다시 켜도 남고, 링크 · 이미지 길게 누르기 메뉴에 `page` · `link` · `image` · `all` 컨텍스트 항목이 나타남. 누르면 `onClicked`
  - **v2.8.4**: `selection` 컨텍스트 항목을 글자 선택 팝업(`NestedWebView.extSelectionTitles`)에 끼워 넣음, `onAuthRequired`(`ExtensionManager.netAuth`, `onReceivedHttpAuthRequest` 에서 먼저 물어봄)
  - **v2.8.5 팝업**: 높이 측정을 개선(줄어들 수 있음)하고 폭이 넓은 팝업은 카드를 넓힘, `window.close()` → `Bridge.popclose` 로 팝업 닫기, 팝업 · 옵션 페이지의 `fetch` 는 `Bridge.pfetch` 로 앱이 대신 받음(host 권한 필요), 키보드 `ADJUST_RESIZE`
  - **v2.8.6 목록 화면**(`ExtensionsUi`): 켜짐/꺼짐 구역 나누기, 기능 꼬리표, 삭제는 아이콘 버튼
  - 안 되는 것: POST 요청 본문 보기 · 본문/헤더 고치기(웹뷰가 본문을 안 줌), 팝업 창(「팝업 열기」로 새 탭에서 열림). 시크릿 탭에서는 확장을 쓰지 않음. 여러 창을 쓰면 창마다 백그라운드가 따로 돎

**보안**
- 뒤로가기 리다이렉트 차단: 뒤로가기 직후 페이지가 스스로 다른 곳으로 보내면 막고, 그런 페이지는 건너뛰어 그 앞 페이지로 돌아감
- 기기 백업에 북마크·방문 기록이 들어가지 않음 (allowBackup 끔), 다른 앱은 앱 전용 저장소를 읽을 수 없음
- Google Safe Browsing(위험 사이트 경고) 사용, WebView 파일 접근 차단, 사용자 동작 없는 팝업·외부 앱 이동 차단
- 빠른 다운로드는 https → http 로 넘어가는 리다이렉트와 http/https 가 아닌 주소를 따라가지 않음

**앱 아이콘**: 연두색 배경 + 작게 줄인 나뭇잎 (Android 8+ 적응형 아이콘, 테마 아이콘 지원 / 7.x 는 PNG)

**속도**
- 광고 숨김 스크립트를 페이지당 1번만 실행, 방문 기록 저장을 백그라운드로 이동
- 광고 차단 목록 주 1회 자동 업데이트
- v2.4.18 속도 개선
  - **릴리스 APK**(`evergreen-release-apk`)를 같이 만듭니다: R8 최적화로 디버그 APK 보다 시작·동작이 빠릅니다 (같은 키로 서명, 그대로 덮어써서 설치)
  - 터치할 때마다 DOM 전체를 훑던 광고 막 검사를 가볍게 바꿈 (큰 페이지에서 터치당 약 6.5ms → 0.3ms)
  - 방문 기록·북마크·즐겨찾기·최근 검색어 JSON 을 매번 다시 읽지 않고 기억해 둠 (자동완성이 메인 스레드에서 도는 비용 감소), 방문 기록 저장은 한 번만 읽고 씀
  - 광고 목록 읽기를 자동완성 스레드와 분리하고 낮은 우선순위로, 파일을 줄 단위로 읽고 써서 메모리 사용·GC 감소
  - 자동완성은 이미 낡은 글자의 네트워크 요청을 건너뜀, 스크롤 이벤트당 스크롤바 중복 갱신 제거, WebView 를 앱 시작 때 미리 불러오기


## APK 만드는 법 (GitHub Actions)

1. GitHub에서 새 저장소를 만들고 이 폴더의 내용을 전부 push 합니다.
   ```bash
   git init
   git add .
   git commit -m "init"
   git branch -M main
   git remote add origin https://github.com/<아이디>/<저장소>.git
   git push -u origin main
   ```
2. 저장소의 **Actions** 탭에서 `Build APK` 워크플로가 자동 실행됩니다.
   (수동 실행: Actions → Build APK → Run workflow)
3. 빌드가 끝나면 실행 결과 페이지 아래쪽 **Artifacts**에서
   `evergreen-debug-apk`를 내려받아 압축을 풀면 `app-debug.apk`가 나옵니다.
4. 폰으로 옮겨서 설치합니다. ("출처를 알 수 없는 앱 설치" 허용 필요)
   - 앱은 `app/evergreen.keystore` 고정 키로 서명되므로, 이후 버전은 **지우지 않고 그대로 덮어써서** 업데이트됩니다.
     (키 서명을 바꾼 첫 한 번만 기존 앱을 지우고 설치해야 합니다. `versionCode` 는 올리기만 해야 합니다.)
   - 이 키스토어 파일을 바꾸거나 지우면 다시 "패키지 충돌"이 납니다.

## 설정 바꾸기

- 광고 차단 도메인: `AdBlocker.kt`의 `BUILTIN`
- 단축어/검색엔진: `Prefs.kt`의 `SearchEngines`
- 앱 이름: `res/values/strings.xml`의 `app_name`
- 패키지명: `app/build.gradle.kts`의 `applicationId`와 `namespace`

## 애니메이션
- 스프링(물리 기반) 애니메이션 사용 (`Motion.kt`, androidx.dynamicanimation): 버튼 눌림, 탭 전환, 탭 카드 등장·닫기·재배치, 메뉴 시트 항목, 홈 화면 요소
- 시스템 설정에서 애니메이션을 끄면 자동으로 꺼짐
- **상/하단바 버튼 애니메이션 (v2.4.43~50)**: 메인 브라우저 바의 버튼 동작(누르면 쏙 들어가고, 탭하면 아이콘 모양이 변했다 돌아옴)을 내장 플레이어·미러링 화면·탭 화면에도 같게 적용
  - 플레이어 위쪽 바: 뒤로(화살촉이 쏨) · 작은 창(안쪽 창이 커짐) · 회전(폰이 기울었다 돌아옴), 아래 줄: 10초 뒤로/앞으로(원형 화살표가 해당 방향으로 한 바퀴) · 설정(톱니 회전) · 배속/CC/자막 칩(눌림)
  - 재생/일시정지 버튼은 탭할 때 따로 튀지 않고 재생 상태에 따라 삼각형 ↔ 두 막대로 모양이 변함. 예전에는 눌림 스프링과 상태 변경 때의 크기 애니메이션이 같은 scale 을 두고 부딪쳐 버튼이 떨렸고, media3 가 상태마다 아이콘을 갈아 끼워 모양이 풀렸음 (`LockableImageButton` 이 media3 의 아이콘 교체를 막음)
  - v2.4.44: 10초 버튼의 원형 화살표 중심이 격자 (12, 13) 이라 회전 축을 맞추고(링이 흔들리던 문제), 가운데 "10" 도 같은 중심에 오게 1.75dp 내림
  - v2.4.45: **탭 버튼** — 누르는 동안 앞 카드가 왼쪽 아래로 움츠리고, 떼면 뒤 카드가 오른쪽 위로 튀어 올랐다 출렁이며 제자리 (뒤 카드는 앞 카드에 가려지는 부분을 잘라 내 겹쳐 보이지 않음). 숫자를 아이콘(`MorphIconDrawable`)이 직접 그려 카드와 같이 움직이고, 탭 개수가 바뀌면 숫자가 위/아래로 굴러 바뀌며(늘면 위로, 줄면 아래로) 카드가 한 번 출렁임. 예전에는 숫자가 카드와 따로 놀고 개수가 바뀔 때 버튼 전체가 커졌다 작아졌음
  - v2.4.45: **플레이어 버튼**(내장 플레이어로 재생) — 재생/일시정지 모양으로 갈라졌다 돌아오던 효과(열기 버튼에는 어울리지 않음)를 새 동작(`openplayer`)으로 교체: 누르는 동안 삼각형이 뒤로 물러나고, 떼면 오른쪽으로 날아가며 사라지고 새 삼각형이 왼쪽에서 들어와 살짝 넘어갔다 자리를 잡음. 플레이어 화면 안의 재생/일시정지 버튼(`player`)은 그대로
  - v2.4.46: 빌드 오류 수정 — 탭 버튼 숫자 연결에서 TextView 형변환이 빠졌던 것(`MorphIcon.kt`), `Motion.flyAway` 가 `onEnd` 를 속도 자리에 넘기던 것(`Motion.kt`)
  - v2.4.47: 10초 뒤로/앞으로 버튼 — 한 방향으로 한 바퀴만 돎 (되감기 = 반시계, 빨리감기 = 시계). 예전에는 돌다가 도로 풀리며 반대로 돌아오는 것처럼 보였음. 도는 중에 또 누르면 한 바퀴 더 이어서 돎
  - v2.4.50: AI 어시스턴트 버튼 — 반짝이는 동작. 큰 별이 제자리에서 오므라들고(기울지도 돌지도 않음), 작은 별이 커졌다 작아지고, 작은 반짝임 두 개(오른쪽 아래·왼쪽 위)가 차례로 떴다 사라짐
  - v2.4.51~52: 방문 기록 버튼 — 누르는 동안 시계 바늘이 반시계 방향으로 살짝 감기고, 떼면 분침이 **시계 방향**으로 한 바퀴 돌며(흐릿한 꼬리가 뒤따라 돎) 살짝 넘었다가 자리를 잡음. 시침은 1/12 만큼만 갔다가 제자리. 예전에는 바늘이 돌다가 도로 풀리며 반대로 돌아오는 것처럼 보였음(v2.4.51 은 반시계로 돌았고 v2.4.52 에서 시계 방향으로 바꿈). 도는 중에 또 누르면 한 바퀴 더 이어서 돎
  - v2.4.55~56: **플레이어 버튼**(내장 플레이어로 열기) 새로 만듦 — 누르면 삼각형이 작아지고, 떼면 앞으로 튀어 오르며 삼각형이 세로 조각 세 개로 갈라져 **그대로 이퀄라이저 막대로 변함**(왼쪽부터 차례로 벌어지고, 막대가 출렁이다 오른쪽부터 차례로 다시 합쳐져 삼각형이 됨, 1.2초). v2.4.55 는 삼각형이 사라지고 막대가 따로 나타나는 방식이었음. 예전의 날아가고 들어오는 동작(v2.4.45~53)·윤곽 퍼짐(v2.4.54)은 없앰
  - 탭 화면: 위쪽 뒤로·더보기는 모양 변화, 선택·시크릿 탭·새 탭·전체 선택은 눌림(넓은 버튼은 4%만 줄어듦)
- **탭 화면(전체 화면)**: 탭 버튼을 누르면 현재 페이지가 탭 카드의 미리보기 크기로 줄어들며 탭 화면이 나타나고, 카드를 누르면 그 카드가 펼쳐져 페이지가 됨 (뒤로가기·닫기도 동일). 탭 카드에는 페이지 미리보기가 표시됨
- 방문 기록의 날짜 펼침·접힘 (`HistoryActivity.morph`): 날짜 줄을 누르면 그 날의 기록이 날짜 줄 밑에서 위에서부터 차례로 펼쳐져 나오고, 아래 날짜 줄들은 순간이동하지 않고 밀려 내려감. 접을 때는 기록이 날짜 줄 쪽으로 말려 올라가며 사라진 뒤 아래 줄이 올라와 빈자리를 메움. 펼친 기록이 화면 아래로 넘치면 날짜 줄이 가려지지 않는 선까지 스르르 스크롤. 모션 끔 설정이면 애니메이션 없이 바로 바뀜
- 북마크·방문 기록·다운로드 목록의 선택 삭제: 선택 모드에서 제목줄이 "n개 선택됨"으로 바뀌고 오른쪽 버튼은 '취소', 아래 막대는 [전체 선택 / 삭제 (n)]. 북마크·방문 기록은 묻지 않고 바로 지우며 알림의 '실행 취소'로 되돌리고, 다운로드는 파일이 지워지므로 용량 합계를 보여 주는 확인을 유지
- 탭 화면의 탭 일괄 닫기: 제목줄 '선택' → 카드를 눌러 체크(그룹 줄을 누르면 그 그룹의 탭이 모두 선택·해제, 접혀 있어도 됨) → 아래 막대의 [전체 선택 / 삭제 (n)]. 선택 모드에서는 제목줄이 "n개 선택됨"으로 바뀌고 '선택'은 '취소', '모두 닫기'는 숨겨지며, 밀어서 닫기·길게 눌러 순서 바꾸기는 꺼짐. 아래 막대는 [시크릿 탭 / 새 탭] 줄과 같은 자리에서 교대로 나타나(목록 높이 변화 없음), 고른 탭이 없으면 '삭제'는 회색으로 비활성, 개수가 바뀌면 알약이 톡 튐. 뒤로 가기(화살표 포함)는 선택 모드부터 끔. 탭은 닫으면 되살릴 수 없어 "탭 n개를 닫을까요?" 확인을 한 번 거치고, 전부 고르면 '모두 닫기'처럼 빈 새 탭 하나만 남음. 지금 보던 탭은 맨 마지막에 닫아 이어서 볼 탭이 이미 닫힌 탭으로 뽑히지 않게 함
- **AI 어시스턴트 사진 읽기 (v2.4.92)**: 어시스턴트가 페이지 안의 사진도 보고 답함. 지금 화면에 보이는 사진부터 최대 6장을 골라(아이콘 크기 이하는 제외) 웹뷰와 같은 쿠키·Referer 로 내려받아 긴 변 1280px JPEG 로 줄여 Gemini 에 이미지로 보냄. 웹툰처럼 세로로 아주 긴 사진은 화면에 보이는 부분만 잘라 보내고, `blob:`·`data:` 사진도 처리(`AssistantImages.kt`). 채팅 창에 「✓ 사진도 읽어요」 알약(끄면 글만 보냄, 페이지 참고가 꺼져 있으면 함께 꺼짐)과 「사진 설명」 칩 추가. 사진은 이번 질문에만 붙이고(이전 질문마다 다시 보내지 않음), 사진을 못 받았으면 AI 가 못 봤다고 말하게 함. 설정 안내문에 사진도 Google 서버로 전송된다고 표시
- **빌드 진행 창에 경과 시간 표시 (v2.4.93)**: 「빌드 중」 창에 빌드가 시작된 뒤 지난 시간(`경과 시간 2:05`)이 1초마다 올라감. GitHub 의 `run_started_at` 을 기준으로 하고 시간 표시는 요청 없이 앱 안에서만 갱신(요청 한도에 영향 없음). 빌드가 끝나면 취소·실패 알림에 걸린 시간도 함께 표시 (`BuildStatus.kt`)
- **빌드 진행 알림 (v2.4.94)**: 「빌드 중」 창을 띄우면 `BuildWatchService`(포그라운드 서비스)가 함께 시작돼 앱이 화면 밖에 있어도 알림에 진행률과 경과 시간(시스템 스톱워치)을 보여 줌. 15초마다 GitHub 를 확인(같은 ETag 캐시를 써서 304 는 한도에 안 들어감)하고, 빌드가 끝나면 「빌드 완료/실패/취소 + 걸린 시간」 알림으로 바뀌고 서비스는 내려감. 진행 창이 끝을 직접 처리하면 서비스와 완료 알림을 함께 치움. 알림의 「그만 보기」로 중지, 40분 뒤 자동 종료
- **AI 어시스턴트 새 디자인 (v2.4.95)**: Gemini 같은 파랑 → 보라 → 분홍 그라데이션(`AiGradient.kt`). 창 위쪽에 오로라 빛이 번져 천천히 떠다니고(답을 만드는 동안 더 환해짐), 제목 글자·로고·보낸 말풍선·보내기 버튼·빈 화면 로고·점 세 개·질문 칩에 그라데이션을 입힘. 입력창은 글을 쓰거나 답을 받는 동안 그라데이션 테두리가 켜져 흐름. 위쪽 칩 줄을 없애고 **입력창 바로 위에 뜨는 「바로 물어보기」 카드**로 옮김(칩 + 페이지·사진 참고 알약): 열릴 때 입력창 쪽에서 통통 튀며 떠오르고 칩이 물결처럼 이어서 나타나며, 화살표로 접고 펼 수 있고 키보드가 올라오면 저절로 접혔다가 내려가면 펴짐(`CollapseLayout`, 스프링). 애니메이션은 모두 스프링 기반으로 다듬음: 보내기↔중지 버튼이 돌며 전환, 칩 흐려짐·'맨 아래로' 버튼이 부드럽게 나타나고 사라짐, 점 세 개의 튀는 곡선을 부드럽게. 시스템의 「애니메이션 끄기」를 따름
- **AI 어시스턴트: 대표색 그라데이션 + 설정 알약 위치 (v2.4.96)**: 그라데이션이 앱 대표색(초록, `colorPrimary`)에서 시작해 청록 → 파랑 → 보라로 이어지도록 바꿈(`AiGradient.setBase`: 대표색의 색상을 돌려 나머지 색을 만들고, 보낸 말풍선은 흰 글자가 읽히게 더 짙게). 오로라 빛·제목·로고·보내기 버튼·입력창 테두리·칩 색이 모두 이 흐름을 따름. 「현재 페이지를 참고해요 / 사진도 읽어요」는 질문 칩이 아니라 보내는 내용 설정이라 「바로 물어보기」 카드 밖, 카드와 입력창 사이로 되돌림(카드가 접혀도 늘 보임)
- **AI 어시스턴트: 보내기 화살표 + 그라데이션 순하게 (v2.4.97)**: 보내기 버튼 아이콘을 종이비행기에서 위쪽 화살표(`ic_arrow_up`)로. 그라데이션을 덜 진하게: 두 번째 색부터는 채도를 낮추고 밝게, 오로라 빛·입력창 테두리(가늘게, 최대 67%)·카드 테두리·칩 틴트의 투명도를 낮추고, 보낸 말풍선은 대표색 → 파랑이 옅게 비치는 틴트에 원래 글자색으로
- **AI 어시스턴트 애니메이션 자연스럽고 유기적으로 (v2.4.98)**: ① 태블릿 팝업이 열리고 닫힐 때 틀(배경·그림자)이 먼저 통째로 보이고 그 안에서 내용만 커지던 어색함을 고쳐, 틀과 내용이 한 덩어리로 AI 버튼 자리에서 펼쳐지고 같은 점으로 접히며 사라짐(`popupFrame`). ② 말풍선은 보낸 말은 오른쪽 아래, 받은 말은 왼쪽 아래 모서리에서 자라며 떠오름(`Motion.bubbleIn`, 크기가 정해진 뒤 모서리를 기준점으로, 튕김은 약하게). ③ 점 세 개 말풍선이 답 말풍선으로 바로 자라나 점이 글로 바뀌는 느낌. ④ 글이 쏟아지는 동안·새 말풍선이 생길 때 맨 아래로 뚝 떨어지지 않고 감속하며 부드럽게 따라가고, 손가락으로 만지면 바로 멈춤(`glideToEnd`). ⑤ 복사·다시 생성 버튼이 살며시 떠오름. ⑥ 창을 끌어 옮길 때 들어 올림/내려놓음을 스프링으로(끊겨도 이어짐), 열릴 때 카드·칩의 튕김을 줄임. 시스템의 「애니메이션 끄기」를 따름
- **AI 어시스턴트 빈 화면 동그라미 수정 (v2.4.99)**: 빈 화면 로고 동그라미가 커질 때 가장자리가 잘리던 것을 고침 — 동그라미를 여백(16dp)이 있는 틀 안에 넣고 부모들의 `clipChildren`/`clipToPadding` 을 꺼서 어디에서도 잘리지 않게 함. 움직임도 새로 바꿈: 하나의 시계(4.2초)로 동그라미가 사인 곡선으로 숨 쉬듯 커졌다 작아지고(±4.5%), 반짝이 아이콘이 아주 살짝 기울며, 뒤에서 은은한 빛이 한 번 숨 쉴 때마다 퍼져 나가며 사라짐. 예전의 일정한 왕복 확대(8%)는 제거
- **AI 어시스턴트 빈 화면 동그라미 그라데이션 교체 (v2.4.100)**: 일직선으로 흐르던 띠 그라데이션(청록·파랑·초록이 세로 줄처럼 갈라져 보임)을 구슬(`OrbDrawable`)로 교체 — 색 덩어리 세 개가 서로 다른 속도·방향으로 구슬 안을 돌며 부드럽게 섞이고, 위 왼쪽 하이라이트와 아래 가장자리 그늘로 입체감을 줌(9초 주기). 뒤에서 퍼지는 빛도 같은 구슬
- **AI 어시스턴트 빈 화면 동그라미: 파동 효과 제거 (v2.4.101)**: 뒤에서 퍼지던 빛(파동)을 없앰. 구슬 안의 색 섞임과 은은한 숨 쉬기(±4.5%)만 남음
- **AI 입력창 높이를 보내기 버튼에 맞춤 (v2.4.102)**: 한 줄일 때 입력창이 보내기 버튼(46dp)보다 낮아 어긋나던 것을 고침 — 입력창 최소 높이를 46dp 로 하고 모서리 둥글기를 23dp(완전한 알약)로 맞춤. 여러 줄이 되면 입력창만 위로 늘어나고 버튼은 아래에 남음
- **AI 설정을 모델 버튼 아래 팝업으로 (v2.4.103)**: AI 창 위쪽의 모델 버튼(칩)을 누르면 화면 가운데 대화상자 대신 버튼 바로 아래에 붙는 카드 팝업으로 뜸(API 키·모델·저장/취소/키 삭제). 버튼 아래에서 틀과 내용이 함께 펼쳐지고, 아래 공간이 모자라면 가운데 내용만 스크롤됨. 버튼이 안 보일 때는 예전 대화상자로 열림
- **꾹 누르기 메뉴에 「AI에게 물어보기」 (v2.4.104)**: 웹페이지의 링크·이미지를 꾹 눌러 뜨는 메뉴 맨 아래에 「AI에게 물어보기」 추가. 누르면 AI 창이 열리면서 입력창에 질문(링크: 「이 링크가 어떤 내용인지 설명해 주세요: 주소」 / 이미지: 「이 페이지의 이 이미지가 무엇인지 설명해 주세요: 주소」)이 미리 채워져, 고쳐서 보낼 수 있음. AI 는 링크를 직접 열어 보지 못하고 주소와 현재 페이지 내용만 참고함
- **글자 선택 팝업에 「AI에게 물어보기」 (v2.4.105)**: 웹페이지에서 글자를 선택하면 뜨는 시스템(네이티브) 팝업(복사·전체 선택 등)에 「AI에게 물어보기」 추가 (`NestedWebView.startActionMode` 을 감싸 항목을 끼워 넣음). 누르면 선택한 글을 읽은 뒤 팝업을 닫고, AI 창이 열리면서 입력창에 「이 내용을 설명해 주세요: > 선택한 글(최대 2000자)」 가 미리 채워짐. 보내기 전에 고칠 수 있음. 기기에 따라 항목이 「⋮」 더보기 안에 들어갈 수 있음
- **보낸 사진을 내 메시지에 표시 (v2.4.106)**: 질문과 함께 페이지 사진을 AI 에게 보냈다면(설정의 「사진도 읽어요」), 내가 보낸 말풍선 바로 위에 그 사진이 작은 썸네일(76dp, 둥근 모서리, 오른쪽 정렬)로 뜸. 최대 4장, 더 있으면 마지막 칸에 「+N」. 사진이 준비되는 대로 말풍선과 같이 떠오르고, 다시 생성하면 새로 바뀌고, AI 창을 닫았다 다시 열어도 대화 기록에서 같이 복원됨. 이전 질문의 사진은 AI 에게 다시 보내지 않음(기존과 같음)
- **키보드를 열 때 AI 창이 부드럽게 움직임 (v2.4.107)**: AI 창을 켜 둔 채 입력창을 눌러 키보드가 올라오면, 태블릿 팝업이 시스템에 의해 툭 밀려 올라가고 높이가 한 번에 줄던 것을 고쳐서, 키보드 위로 위치·높이가 부드럽게 미끄러져 맞춰짐(끌어서 옮기거나 크기를 조절하는 중에는 손가락을 바로 따라감). 폰 바텀시트도 키보드가 올라오는 만큼 조금씩 따라 올라가고, 100dp 를 넘을 때 한 번에 튀지 않음
- **AI 창 분할 보기 (v2.4.109)**: 태블릿에서 떠 있는 AI 창의 머리글(위쪽 막대)을 잡고 화면 왼쪽 또는 오른쪽 가장자리로 끌어가면 붙을 자리가 반투명하게 미리 보이고(창은 반투명해짐), 거기서 놓으면 창이 있던 자리에서 옆 패널로 커지며 붙는 분할 보기가 됨. 웹 영역은 패널 너비만큼 좁아져 페이지와 AI 를 나란히 볼 수 있고, 패널의 움직임과 웹 영역이 좁아지는 것이 한 진행도로 함께 움직임(닫을 때도 같음). 반대로 패널 머리글을 끌어 가장자리에서 떼면 패널이 손가락을 따라오는 떠 있는 창이 되고, 가운데에 놓으면 그 자리에 떠 있는 창으로, 반대쪽 가장자리에 놓으면 그쪽으로 옮겨 붙음. 페이지 쪽 가장자리를 끌어 너비 조절(320dp ~ 화면의 60%, 기억함). 고른 모드·쪽은 기억되어 다음에도 그렇게 열림. 분할 보기가 열려 있을 때 AI 버튼을 다시 누르면 패널이 닫힘. 폰(바텀시트)에는 해당 없음
- **대화 지우기 재확인 (v2.4.110)**: AI 창 머리글의 휴지통 버튼을 누르면 바로 지우지 않고 「지금까지 나눈 메시지 N개를 모두 지울까요?」 확인 창이 먼저 뜸. 「지우기」를 눌러야 지워지고, 「취소」면 그대로 남음. 지울 대화가 없으면 확인 없이 「지울 대화가 없어요」 안내만 나옴
- **내장 플레이어로 열 때 영상이 확대되며 열림 (v2.4.111)**: 영상 아래 「내장 플레이어로 열기」(또는 메뉴·위쪽 바의 내장 플레이어)를 누르면 플레이어가 아래에서 뜨는 대신, 웹페이지 속 영상이 있던 그 자리에서 화면 가득(영상 비율 그대로) 커지면서 열림. 영상 자리를 PixelCopy 로 복사해 브라우저 창 위에 얹고(`PlayerZoom`), 모서리가 각지며 커지는 동안 뒤 페이지는 어두워짐. 거의 다 커지면 플레이어 창이 짧은 페이드로 겹치고, 플레이어는 같은 정지 그림을 덮어 두었다가 영상 첫 화면이 그려지면 서서히 걷어 내 끊김 없이 이어짐. iframe 안 영상도 위 프레임에 위치를 올려 보내 iframe 자리를 더해 계산. 영상 위치를 모르거나(전체화면 등) 시스템 애니메이션이 꺼져 있으면 예전 열기 방식 그대로
- **영상 확대 전환을 더 자연스럽게 (v2.4.112)**: ① 고정 시간 곡선 대신 앱의 다른 움직임과 같은 스프링(`Motion.springValue`)으로 확대 — 빠르게 붙었다가 부드럽게 자리를 잡고, 도중에 끊기거나 겹쳐도 속도가 이어짐. ② 확대하는 동안 뒤 페이지가 살짝 물러나며(0.94배) 어두워져 깊이감이 생김(어둡기도 확대 진행에 맞춰 부드럽게). ③ 확대가 시작되는 순간 페이지 영상을 멈춰, 플레이어가 뜰 때 소리가 겹치던 것을 없앰. ④ 영상 자리 복사 대기 50ms → 30ms 로 줄여 누른 뒤 반응이 빨라짐. ⑤ 플레이어 창은 확대가 80% 진행했을 때 열어 끝나자마자 이어짐
- **확대 전환에서 두 영상이 겹쳐 비치던 것 수정 (v2.4.113)**: 확대 도중 플레이어 창이 140ms 페이드로 겹치면서 움직이는 영상과 페이드되는 영상이 동시에 비쳐 어색하던 것을 고침. 이제 플레이어 창은 확대가 92% 진행했을 때(남은 움직임이 거의 없을 때) 페이드 없이 바로 뜨고, 같은 그림이 같은 자리에 놓여 끊김 없이 이어짐. 스프링 감쇠를 0.95 로 올려 끝에서 넘치지 않게 했고, 정지 그림이 걷히는 시간도 240ms → 160ms 로 줄임
- **확대 전환: 스프링 복원 + 뒤 배경 축소 제거 (v2.4.114)**: ① 스프링을 다시 살려(강성 240 · 감쇠 0.72) 살짝 넘쳤다가 돌아오며 자리를 잡는 맛을 되찾음. ② 확대하는 동안 뒤 페이지를 작게 만들던 효과를 없애고 크기는 그대로 두고 어둡게만 가림. ③ 스프링이 넘쳐도 창이 바뀔 때 튀지 않게, 플레이어 창이 뜬 뒤에도 같은 스프링 값(`PlayerZoom` 이 한곳에서 계산)으로 덮개 그림이 같은 움직임을 이어서 그림 — 두 창이 같은 식으로 그리므로 영상이 겹쳐 비치지도, 어긋나지도 않음. 뒤가 완전히 가려지는 시점(진행 80%)에 플레이어 창을 페이드 없이 열고, 움직임이 끝난 뒤 정지 그림을 걷음. 화면이 돌아가면 덮개를 바로 최종 배치로
- **빌드 오류 수정 (v2.4.115)**: 모드 전환 때 AI 어시스턴트를 닫는 `AssistantUi.closeNow()` 가 없어 릴리스 빌드가 `Unresolved reference: closeNow` 로 실패하던 것을 고침. 애니메이션 없이 바로 닫는 함수를 추가함
- **알림 설정 추가 (v2.4.116)**: 설정에 「알림」 묶음을 새로 만듦. ① 다운로드 진행 알림 ② 다운로드 완료 알림(앱이 백그라운드일 때의 시스템 알림) ③ 빌드 결과 알림을 각각 켜고 끌 수 있고(기본 켜짐, 꺼도 앱 안 진행 카드·안내는 그대로), ④ 「시스템 알림 설정」 줄이 휴대폰의 이 앱 알림 설정 화면(소리·팝업·채널)을 열며 알림이 막혀 있으면 그 상태를 보여 줌. 설정 검색에서도 찾을 수 있음
- **알림 켜기/끄기를 더 다양하게 (v2.4.117)**: 설정의 알림을 세 묶음으로 나눠 켜고 끌 수 있게 함(기본은 모두 켜짐). ① 다운로드 알림: 진행 · 완료(시스템) · 완료 안내(앱 안) · 실패 ② 앱 안 안내: 탭 닫기 되돌리기 · 삭제 실행 취소 · 이동 차단 안내 ③ 백그라운드 알림: 빌드 진행 · 빌드 결과 · AI 답변 받는 중 · 미디어 컨트롤 · 악성 사이트 경고 · 시스템 알림 설정 바로가기. 진행·AI 알림은 서비스가 알림 객체를 꼭 가져야 해서, 끄면 알림창에 안 보이는 '알림 끔' 채널로 보냄
- **빌드 진행을 Now Bar에도 표시 (v2.4.118)**: 안드로이드 16(삼성 One UI 8)의 Live Updates 를 써서 빌드 진행 알림을 Now Bar·상태표시줄 칩에 올려 달라고 요청함(칩에는 진행 % 가 짧게 보임). 설정 「빌드 진행을 Now Bar에도 표시」로 끄고 켤 수 있음(기본 켜짐, 「빌드 진행 알림」이 꺼져 있으면 같이 안 뜸). 매니페스트에 `POST_PROMOTED_NOTIFICATIONS` 권한을 추가함. 빌드 설정(compileSdk 35 · AGP 8.5.2)을 건드리지 않으려고 안드로이드 16 전용 클래스 대신 알림 extras 로 요청하며, 지원하지 않는 기기에서는 무시되고 일반 알림으로만 뜸. 기기에 따라 개발자 옵션의 '모든 앱에 라이브 알림'을 켜야 보일 수 있음
- **버전 2.5.00**: 기능 변경 없이 버전만 2.4.132 → 2.5.00 으로 올림
- **v2.4.130 롤백 (v2.4.132)**: 보내기 ↔ 중지(X) 전환을 아이콘 모양 변형(`SendStopIcon`)으로 바꿨던 것을 되돌려, 예전처럼 버튼이 돌며 아이콘이 바뀜(v2.4.131의 구슬 그라데이션은 그대로)
- **AI 보내기 버튼 그라데이션 모양·애니메이션 개선 (v2.4.131)**: ① 모양: 비스듬한 띠가 평평하게 흐르던 동그라미 대신, 입체감 있는 구슬(OrbDrawable — 색 덩어리가 구슬 안에서 섞이고 위쪽 하이라이트·아래쪽 그늘)로 바꿈. ② 애니메이션: 답을 받는 동안 2.2초 주기로 띠가 빠르게 훑고 지나가 번쩍이던 것을, 구슬이 약 0.3초에 걸쳐 천천히 빨라지며 돌고 끝나면 천천히 느려져 멈추도록 함(켜고 끌 때 속도가 갑자기 바뀌지 않음). 시작 때 위치가 튀지 않고 이어서 돎
- **분할 미리보기 영역에만 블러 (v2.4.129)**: AI 창을 가장자리로 끌 때 뜨는 분할 미리보기 안에, 붙을 자리 뒤의 웹 화면을 흐리게 깔아 줌(그 자리만, 상·하단 바·나머지 화면은 그대로). 웹뷰를 다시 그리지 않고 그 영역만 작게 한 번 찍어 와서 깜빡이지 않음. 설정에서 블러 효과를 끄면 예전처럼 색·테두리만 보임
- **AI 창을 가장자리로 끌 때 뜨는 분할 미리보기가 상·하단 바를 덮던 것 수정 (v2.4.128)**: 미리보기 틀이 화면 전체 높이로 그려져 상·하단 바까지 덮었음 → 실제 분할 패널처럼 바 사이의 웹 영역 옆에만 그려짐
- **AI 어시스턴트: 사진도 읽어요가 켜져 있어도 내 말풍선에 사진 안 보이게 (v2.4.127)**: 페이지 사진을 함께 보내도 내가 보낸 메시지 아래에 사진 미리보기가 붙지 않음. 사진은 그대로 AI 에게 전달됨
- **미러링(창 가득 보기)도 영상이 커지며 열리도록 (v2.4.126)**: 미러링은 페이지의 영상을 그대로 창 가득 키워 보여 주는데, 전에는 한 번에 확 바뀌었음. 이제 영상이 원래 있던 자리에서 창 가득으로 스프링처럼 커짐(실제 영상이 커지므로 정지 그림 없음, 모서리는 커질수록 각지게). 켜질 때만 동작하고 애니메이션을 끄면 예전처럼 바로 바뀜. 영상이 iframe 안에 있거나 화면 밖이면 전환 없이 바로 열림
- **내장 플레이어 열기: 그림이 아니라 실제 영상이 커지도록 (v2.4.125)**: 전에는 영상 자리를 캡처한 정지 그림만 커지다가, 자리를 잡은 뒤에야 실제 영상으로 바뀌었음. 이제 첫 화면이 그려졌을 때 확대가 아직 움직이는 중이면, 정지 그림은 제자리에서 서서히 걷히고 그 아래의 **실제 영상(재생 화면)이 같은 스프링 움직임을 이어받아 계속 커짐**(영상 비율 그대로 처음 칸 안에서 시작해 플레이어의 영상 자리로). 커지는 동안은 컨트롤을 숨기고 자리를 잡으면 보여 줌. 화면 방향이 바뀌거나 화면에 맞추기가 아니면 예전 방식으로 동작
- **내장 플레이어 열기: 확대 뒤 멈춤·크기 튐 개선 (v2.4.124)**: ① 플레이어 창을 확대가 80% 진행된 뒤에야 열어서, 확대가 끝난 뒤 창이 뜰 때까지 카드가 가만히 서 있었음 → 확대가 30% 진행되어 뒤가 가려지면 바로 열도록 앞당김(창이 뜨는 시간이 확대 움직임과 겹침). ② 확대하던 그림은 페이지의 영상 칸(제목·좋아요 줄까지 찍힘, 영상과 다른 비율)이고 플레이어는 영상 원래 비율로 보여 줘서, 그림을 걷을 때 폭과 그림이 한 번에 튀었음 → 걷는 동안 그림도 플레이어의 실제 영상 자리·크기로 함께 맞춰 감
- **내장 플레이어 열기 애니메이션에서 AI 창이 밝게 남던 문제 (v2.4.123)**: 페이지 영상이 커지며 내장 플레이어가 열릴 때, 확대 오버레이는 앱 창 안에 깔려서 별도 창인 AI 팝업을 덮지 못했음. 그래서 화면은 어두워지는데 AI 창만 밝게 떠 있다가 플레이어가 뜨는 순간 갑자기 사라졌음. 이제 확대가 시작되면 AI 창도 함께 서서히 사라지고, 플레이어에서 돌아오면(또는 5초 안에 플레이어가 안 열리면) 원래대로 돌아옴
- **AI 대화 지우기 확인 창이 삭제 버튼 아래에 (v2.4.122)**: AI 어시스턴트 머리글의 휴지통 버튼을 누르면 화면 가운데 대화상자가 뜨던 것을, 버튼 바로 아래에 붙는 카드 팝업으로 바꿈(AI 설정 팝업과 같은 모양, 버튼 오른쪽 끝에 맞추고 화면 밖으로는 안 나감). 버튼이 보이지 않는 경우에만 예전 대화상자를 씀
- **AI 분할 패널과 팝업이 같이 뜨지 않게 (v2.4.121)**: 분할 보기 패널과 떠 있는 팝업이 동시에 화면에 남을 수 있었음. 이제 분할 패널·팝업·시트 중 하나를 열 때마다 남아 있는 다른 AI 창을 먼저 모두 치워서 항상 하나만 보임
- **AI 분할 보기에 창 상단 멀티태스킹 바 표시 (v2.4.120)**: AI 어시스턴트를 옆 패널(분할 보기)로 붙이면 떠 있는 창 맨 위에 있던 작은 끌기 막대가 사라져 있었음. 이제 분할 보기 패널 맨 위에도 막대가 보이고, 머리글뿐 아니라 이 막대를 잡고 끌어도 패널을 떼어 낼 수 있음
- **AI 분할 보기가 상·하단 바를 침범하지 않게 (v2.4.119)**: AI 어시스턴트를 옆 패널(분할 보기)로 붙이면 패널이 화면 높이 전체를 차지해 탭 줄·주소창 옆까지 올라오고, 바들도 같이 좁아졌음. 이제 상단 바와 하단 바는 폭이 그대로이고, 패널은 두 바 사이의 웹 영역 옆에만 붙고 웹 영역만 좁아짐. 찾기 줄이 열리는 등 웹 영역의 위·아래 끝이 바뀌면 패널도 따라감. 분할 보기 중에는 스크롤로 상·하단 바가 숨지 않으며(패널과 어긋나지 않게), 닫으면 다시 숨음. 패널을 끌어 떼어 떠 있는 창으로 만들 때는 예전처럼 창 전체 범위에서 움직임
- **설정의 알림을 「알림」 하나로 (v2.5.01)**: 설정에 따로 있던 「다운로드 알림」·「앱 안 안내」·「백그라운드 알림」 세 묶음을 「알림」 한 묶음으로 합침(벨 아이콘 `ic_bell`). 안에서 소제목 「다운로드」·「앱 안 안내」·「백그라운드」로 나뉘고, 항목·동작·설정 검색은 그대로
- **분할 미리보기 블러를 실시간으로, 위치도 정확하게 (v2.5.02)**: AI 창을 가장자리로 끌 때 뜨는 분할 미리보기의 블러가 한 번 찍은 정지 그림이라 페이지가 바뀌어도 안 따라가고, 미리보기 여백(6dp) 때문에 그림이 어긋나 있었음(분할 패널을 끌 때는 끌고 있는 패널까지 찍혀 번져 보임). 이제 `Blur.liveBackdrop` 이 웹 영역(바 사이 칸)만 매 프레임 미리보기 자리에 다시 그려 흐림(스크롤·영상이 바뀌면 같이 바뀜). 위치는 화면 좌표로 맞춰 여백이 있어도 1:1 이고, 상·하단 바·끌고 있는 창·미리보기 자신은 흐린 그림에 섞이지 않음. 미리보기는 크기 애니메이션 없이 서서히 나타남. 설정에서 블러를 끄면 색·테두리만 보임
- **영상 아래 「내장 플레이어로 열기」·「PiP로 보기」가 첫 탭에 눌리게 (v2.5.03)**: 여러 번 눌러야 열리던 것을 고침. 버튼 누름을 `click` 에만 맡기지 않고 직접 감지함 — 손가락이 버튼 위(여유 5px)에 닿았다가 거의 안 움직이고 떨어지면 그 버튼을 누른 것으로 보고 바로 실행하며, 이 터치는 페이지에 전달하지 않음(페이지가 터치를 가로채거나 `preventDefault` 해서 click 이 사라지던 경우, 누르는 순간 페이지 컨트롤이 바뀌며 버튼이 밀리던 경우 대비). 누르는 동안엔 버튼 위치·표시를 고정해 움직이거나 숨지 않고, 누른 순간의 영상을 그대로 사용. 마우스·키보드용 `click` 은 중복 실행 없이 그대로 둠
- **업데이트 받기 서버 오류 대응 (v2.5.26)**: 릴리스 APK 를 받을 때 공개 주소로 먼저 받고, 실패(예: 비공개 저장소 404)하면 저장된 GitHub 토큰으로 API 자산 주소(`assets[].url`)로 다시 받음. 오류 문구에 원인 안내(404·403·5xx) 추가
- **AI 어시스턴트 로딩 애니메이션 개선 (v2.5.30)**: 답을 기다리는 점 세 개가 멈춤 없이 이어지는 물결로 떠올랐다 가라앉도록 변경 (빛 번짐·색 변화 없음, 점 색은 앱 대표색으로 통일, 속도 빠르게)
- **사진 칩 아래 글에 글머리표 (v2.5.31)**: AI 답변의 목록 항목에서 사진 칩은 글머리표 없이 두고, 칩 아래 설명 글 맨 앞에 글머리표(•)를 붙임
- **태블릿 어시스턴트 창 위쪽 모서리 정리 (v2.5.34)**: 태블릿 UI에서만 대화 영역 패널의 테두리선·잘라내기를 없애 모서리에 검은 선이 비치지 않게 하고, 머리글 아래 선을 없애고 패널 위 여백과 첫 말풍선 안쪽 여백을 늘림 (폰은 그대로)
- **태블릿 어시스턴트 창 크기 조절 손잡이 모양 제거 (v2.5.36)**: 팝업 아래 왼쪽·오른쪽 모서리의 크기 조절 표시(대각선 줄)는 보이지 않게 하고, 모서리를 끌어서 크기를 바꾸는 기능은 그대로 유지
- **어시스턴트 로고 색 흐름 끊김 수정 (v2.5.37)**: 답을 만드는 동안 창 왼쪽 위 로고에 흐르는 색이 한 바퀴 돌 때마다 툭 튀던 문제를, 거울 반복의 한 주기에 맞춰 이어지게 고침 (흐르는 속도는 그대로)
- **꾹 누르기 메뉴에 「자동 스크롤」 + 설정 (v2.5.38)**: 웹페이지의 링크·이미지를 꾹 눌러 뜨는 메뉴에 「자동 스크롤」(흐르는 중에는 「자동 스크롤 멈추기」) 추가. 지금 보는 페이지가 설정한 속도로 저절로 내려가며, 화면 아래에 느리게(−)/빠르게(+)/정지 막대가 뜸. 설정 > 자동 스크롤에서 속도(1~20단계, 1단계 = 초당 25dp, 기본 6), 화면을 만졌을 때(만지는 동안만 멈췄다가 이어서 / 완전히 멈춤), 조작 막대 표시를 바꿀 수 있음. 다른 탭·탭 화면·전체화면·새 페이지로 이동·앱 나가기에서는 저절로 멈추고, 페이지 끝에 닿은 채 1.5초가 지나도 멈춤
- **사진을 꾹 눌러 AI에게 물어보면 사진을 첨부 (v2.5.39)**: 링크 없이 이미지만 꾹 눌러 「AI에게 물어보기」를 고르면 주소 대신 그 사진을 내려받아 AI 창 입력창 위에 알약(눌러서 빼기)으로 붙이고, 질문을 보내면 내 말풍선 위에 사진이 보임(대화를 다시 열어도 유지, 다시 생성해도 같은 사진). 이때는 페이지의 다른 사진 대신 고른 사진만 보냄. 사진을 보낸 질문에서 내 말풍선 위 사진이 안 뜨던 것도 함께 고침
- **폰 AI 창 머리글 아래 얇은 선 제거 (v2.5.39)**: 폰 바텀시트에서 머리글과 둥근 대화 패널 사이에 가로선이 남아 모서리 위로 틈이 보이던 것을 없애고, 패널 위 여백과 첫 말풍선 안쪽 여백을 태블릿과 같게 맞춤
- **AI 사진 칩: 대표 사진은 한 줄, 문장 속 참조는 글 사이 (v2.5.39)**: 문단·항목 맨 앞의 [[사진N]] 은 칩이 한 줄을 차지하고 설명은 아래 줄(칩이 여러 개면 한 줄에 나란히), 문장 중간·끝의 [[사진N]] 은 줄을 바꾸지 않고 글 사이에 놓임. AI 안내문도 이 두 쓰임을 나눠 알려 줌
- **클릭 가로채기 차단이 안 먹히던 것 수정 (v2.5.40)**: 「재생」「다운로드」처럼 생긴 버튼을 눌렀는데 엉뚱한 사이트로 보내거나 새 창을 여는 것을 놓치던 원인 세 가지를 고침. ① 눌린 것이 링크이기만 하면 무조건 통과시키던 것을, 링크가 가리키는 사이트와 가는 곳이 다르면(주소가 `#`·`javascript:` 인 버튼 포함) 가로채기로 보도록 바꿈. 눌린 곳과 그 링크 주소는 페이지 스크립트(캡처 단계, 가짜 클릭 무시)가 터치 순간부터 앱에 알려 줘서 웹뷰의 늦고 부정확한 판정에 기대지 않음 ② 손을 떼기 전(touchstart·mousedown)에 바로 이동시키는 경우는 누른 시각이 아직 없어 놓치던 것을, 손이 닿는 순간부터 누르는 중으로 봄 ③ 버튼이 `window.open` 으로 연 새 창은 첫 이동이 이동 검사를 거치지 않는 경우가 있어, 새 창의 첫 요청도 한 번 더 검사해 막고 창을 닫음. 서버 리다이렉트 예외는 「방금 통과시킨 이동에 곧바로 이어지는 것」만 인정(스크립트가 location 을 바꾸는 이동은 리다이렉트 표시가 붙어도 검사). 공유 버튼(share/sharer/intent)은 정상 이동으로 통과. 막은 뒤 알림의 「이동」을 누르면 그 사이트는 이번 실행 동안 허용
- **클릭 가로채기 차단 보강 (v3.7.28)**: ① 눌린 곳을 알리는 `HIJACK_TAP_JS` 의 리스너를 `document` 가 아니라 `window` 캡처 단계에 달아, 페이지가 window 캡처 처리기에서 `stopPropagation` 으로 막아도 눌린 곳 보고가 빠지지 않게 함 ② `market://` · 플레이 스토어를 가리키는 `intent://` 는 `http(s)` 와 달리 이동 검사를 거치지 않고 제스처만 있으면 열리던 것을, 링크(http · market · intent 주소)가 아닌 곳을 누른 직후(2.5초)에는 막도록 함(`isHijackedStoreOpen`). 결제 앱 등 다른 외부 앱 연결은 건드리지 않으며, 누른 곳을 스크립트가 알려 준 경우에만 판단. 막으면 알림의 「열기」 로 열 수 있음
- **클릭 가로채기 차단 구멍 막기 (v3.7.29)**: ① 사용자가 한 번도 안 만진 스크립트 팝업이 같은 사이트 주소를 한 번 거친 뒤 광고로 넘어가면, 팝업 자기 탭에는 누른 기록이 없어 통과하던 것을 연 탭에서 누른 곳(링크가 아닌 곳, 5초 안)으로 판단해 막고 그 팝업 탭을 닫음 (`isUntouchedPopup`, 링크를 눌러 연 팝업은 단축 주소가 흔해서 링크 주소와 비교하지 않음) ② 링크가 아닌 곳을 누른 직후 통과한 이동은 `lastHopAt` 을 갱신하지 않아, 같은 사이트 → 광고 서버 리다이렉트가 '이어지는 리다이렉트' 예외로 통과하던 것을 막음(`nonLinkTapRecent`), 리다이렉트 검사 시간은 4초로 늘림 ③ `siteKey` 가 github.io · pages.dev · blogspot.com · tistory.com 같은 공유 호스팅을 통째로 한 사이트로 보던 것을, 서브도메인 하나가 한 사이트가 되게 함(`SHARED_HOST_SUFFIXES`) ④ 로그인·결제 예외(`looksLikeSignInOrPay`)가 주소 글자 일부만 닮아도(`pay` · `sso` · `share` 등) 통과하던 것을 주소의 칸·길 단위로만 보게 좁힘. 눌린 곳 판정은 `tapInfo` 로 한곳에 모음
- **직접 고른 광고가 앱 재시작 후 돌아오던 문제 (v3.7.30)**: 직접 고른 광고 규칙(`adblock_user_rules.json`)을 `load()` 맨 끝에서 읽었는데, `load()` 는 큰 차단 목록을 읽느라 백그라운드에서 수 초 걸려서 그동안 처음 열린 페이지(복원된 탭)가 `aduser` · `adcss` 를 부를 때 규칙이 비어 있었음. `AdBlocker` 생성 때(`init`) 바로 읽도록 옮기고 `load()` 안의 다시 읽기는 뺌(방금 추가한 규칙을 옛 파일로 덮어쓸 수 있음). 저장은 임시 파일에 쓴 뒤 바꿔 끼움
- **광고 직접 선택: 값이 매번 바뀌는 광고 대응 (v3.7.31)**: `PICKER_JS` 의 선택자 만들기를 보강. ① `looksRandom` 으로 해시·뒤섞은 글자 같은 이름(`xK9fQ`, `Header_box__3xK9a`, 문자·숫자가 번갈아 나오는 긴 이름)은 클래스·아이디 선택자에 쓰지 않음 ② `data-ad-slot` 같은 광고 서비스 속성은 값이 아니라 속성 이름으로 고름 ③ 다른 사이트(등록 도메인이 다름)에서 온 iframe/embed/object 는 `src*="광고서버"` 로 고르고, 앱에는 경로 없는 origin 을 넘겨 `AdBlocker.shouldBlock` 이 그 origin 의 요청을 모두 막음(`originOf`). 같은 사이트가 직접 내려주는 이미지·영상은 예전처럼 전체 주소(경로까지)로 막음. 이미 저장된 규칙은 그대로라서 다시 고르면 새 방식이 적용됨
- **현황 창 열고 닫을 때 카드 블러 깜빡임 (v3.7.42)**: `MorphDialog` 가 닫기 끝에서 창의 면·유리(`surface.hide()`)를 지우는 것과 카드(`restoreOrigin()`, 다른 창)를 되살리는 것을 같은 프레임에 했는데, 두 창은 같은 프레임에 합성된다는 보장이 없어 한 프레임 동안 블러 없는 배경이 비쳤음. 유리 카드(`glassOrigin`)일 때는 `holdGlassOnly()` 로 글자·면·테두리만 지우고 유리는 남긴 채 카드를 되살리고, 두 프레임 뒤에 유리를 지운다(유리는 불투명한 흐린 그림이라 겹쳐도 같은 모양, 단색 카드는 겹치면 진해져서 예전 방식 유지). 열 때도 같은 이유로 카드 숨김을 두 프레임 늦춘다
- **태블릿 메뉴 ↔ 목록 팝업 전환 (v3.7.41)**: 메뉴 카드와 목록 팝업 카드는 같은 자리·같은 크기인데, 메뉴는 축소+페이드로 닫히고 목록은 처음부터 불투명하게 떠서 카드가 깜빡이고 뒤 화면이 비쳤음(영상 프레임 분석). ① 메뉴→목록: `dismissMenu(toList=true)` 는 메뉴를 바로 닫지 않고 `ListUi.pendingMenuDismiss` 에 맡겨, 목록 팝업의 첫 화면이 그려진 두 프레임 뒤에 애니메이션 없이(`animationStyle=0`) 걷어낸다(700ms 안전 타이머). ② 목록→메뉴: 닫는 모션을 축소+페이드(`menu_pop_out`)에서 제자리 페이드(`list_fade_out`, 창·액티비티 둘 다)로 바꿔 메뉴 카드 위에서 내용만 교차한다. ③ `bindMediaCard(view, instant)` 로 즉시 모드(`menuEnterInstant`)에서는 카드 등장·버튼 팝을 건너뜀(카드 칸이 비었다가 튀어나오던 문제).
- **새 탭 카드 블러 어긋남 + 새 탭 → 웹페이지 전환 (v3.7.39)**: ① `ThemeGlassDrawable` 이 화면 1/10 크기(한 칸≈10px)의 흐린 그림에서 잘라 올 자리를 `toInt()` 로 칸 단위에 맞춰 그려서, 카드가 몇 px 움직이거나 크기가 바뀌면 블러가 한 칸(≈10px)씩 툭 튀고 늘어나는 비율도 어긋났음. 이제 흐린 그림 전체를 `BitmapShader`(CLAMP) + 로컬 행렬(루트 크기 대비 실수 배율, 이동량은 실수 좌표)로 그려 자리·비율이 정확함. 그릴 때마다 새 셰이더를 만든다(기록된 그리기 목록과 공유 금지). `paintAt`(MorphDialog 가 카드를 팝업으로 펼칠 때)도 같은 방식. ② `crossfadeHomeToPage` 가 `withEndAction` 을 썼는데 취소되면 끝 동작이 안 불려 `homeFading` 이 true 로 남아 이후 전환이 계속 건너뛰어질 수 있었음 → `AnimatorListenerAdapter` 로 end·cancel 모두 처리. 연출도 키워서 페이지가 아래 28dp·0.96배에서 떠올라 제자리로 오고(스프링), 홈은 불투명한 채 1.05배까지 커짐(460ms)
- **웹페이지 → 새 탭 전환 보강 (v3.7.38)**: v3.7.37 은 새 탭 버튼 경로(`selectTab`)에만 적용됐고, 고스트(떠나는 화면 사진)가 알파로 사라지는 동시에 새 탭도 알파 0→1 이라 중간에 둘 다 반투명해 뒤 바탕이 비쳤음(3.7.36 과 같은 문제). 고스트를 **홈 바로 아래**(`area.indexOfChild(homeView)`)에 깔고 알파는 그대로 둔 채 크기 0.95·위로 14dp 만 물러나게 해, 새 탭이 위에서 떠오르며 덮는 크로스디졸브로 바꿈. 홈 알파가 0.985 이상이면(또는 1초 뒤) 제거. 또 같은 탭에서 페이지 → 홈(뒤로가기·홈 버튼·마지막 탭 닫기)도 `updateUi` 에서 웹뷰를 숨기기 전에 `capturePixels()` 로 찍어 같은 효과를 냄(`inSelectTab` 으로 탭 선택 중엔 건너뜀). 캡처는 PixelCopy 성공 때만 사용(실패 시 빈 화면이 깔리지 않게 효과 생략)
- **웹페이지 → 새 탭 전환 애니메이션 추가 (v3.7.37)**: `selectTab` 이 이전 탭의 웹뷰를 바로 떼어 내서 새 탭 홈만 아래에서 떠오르고 떠나는 페이지는 뚝 사라졌음. 새 탭(홈)으로 넘어가는 경우(`newTabAnimFor===tab`, 탭 화면 닫힘, 이전 탭이 홈 아님)에만 떼기 전에 `captureContent(pixels=true)` 로 화면을 찍어 `playLeavingGhost` 가 웹 영역 맨 위에 ImageView 로 겹치고, 알파 1→0 · 크기 1→0.94 · 위로 20dp 스프링으로 내보냄(끝나거나 900ms 뒤, 또는 다른 탭 선택 시 `removeLeavingGhost` 로 제거). 찍은 이미지는 탭 화면 미리보기(thumb)로도 재사용
- **새 탭 → 웹페이지 전환이 허옇게 뜨던 것 수정 (v3.7.36)**: `crossfadeHomeToPage` 가 홈(알파 1→0, 220ms 감속)과 페이지(알파 0→1, 스프링)를 동시에 반투명으로 겹쳐서, 중간(약 0.1초)에 홈 약 15%·페이지 약 50% 라 덮이지 않은 약 40% 로 뒤 바탕(흰색)이 비쳤음. 홈 알파는 1 로 두고(확대 1.025 만 유지) 페이지만 위에서 떠오르게(스프링 420) 해 두 장이 서로 녹아 섞이는 크로스디졸브로 바꿈. 끝나면 홈을 숨김(300ms)
- **목록 창이 뜰 때 뒤 상단바·탭바 색이 바뀌던 것 수정 (v3.7.35)**: 테마에 `frame_inactive` 가 있으면 메인 창이 포커스를 잃고 250ms 뒤 `focusFrameTask` 가 탭바·상태표시줄 밴드를 비활성 색으로 바꿈. 북마크·방문 기록·다운로드 창이 포커스를 가져가는 것도 비활성으로 취급해서, 팝업이 뜬 뒤 0.25초 만에 뒤 상단바 색이 튀고 닫으면 다시 튀었음(영상에서 상태표시줄 자리 색이 팝업 시작 약 0.3초 뒤·닫힘 직후 한 프레임에 바뀜). `MainActivity.ownListOpen`(`listIntent` 에서 true, `onResume` 에서 false)이 켜져 있으면 비활성으로 보지 않음
- **태블릿 메뉴 ↔ 목록 팝업(북마크·방문 기록·다운로드) 전환 다듬기 (v3.7.34)**: 화면 녹화를 프레임 단위로 보면 ① 메뉴→목록: 메뉴 팝업이 사라지는 120ms 동안 새 목록 창이 알파 0 에서 올라와 반투명 두 장이 겹쳐 뒤가 비쳤음 ② 목록→메뉴: 닫히는 목록 창 뒤로 새 메뉴 면만 먼저 비어 회색 면으로 보였음(메뉴 내용은 알파 0 에서 시작) ③ 창 테마의 어두움(dim)이 한 프레임에 켜지고 꺼졌음. 수정: ① `ListUi.buildTabletPopup` — 메뉴에서 온 팝업(`fromMenu`)은 면을 알파 1·배율 1 로 시작하고 항목만 떠오름 ② `MainActivity.menuEnterInstant` — 목록에서 돌아와 `showMenu` 를 다시 부를 때 `prepareAnchoredEnter`/`playAnchoredEnter` 를 건너뜀 ③ `ListUi.fadeTabletDim` — 시작 때 dim 0 에서 220ms 로 올리고, 끝날 때(`onActivityPaused` + `isFinishing`)는 120ms 로 내림
- **테마 새 탭 카드 색이 반투명이면 블러 적용 (v3.7.33)**: `homeGlassFor` 가 테마의 `ntpSection` 색이 있으면 단색 `GradientDrawable` 만 돌려줘서, 반투명 색이면 바로가기 버튼·카드가 뒤 배경이 선명하게 비치기만 했음. 이제 색의 알파가 255 미만이고 흐린 배경 그림(`homeGlassBmp`)이 있으면 `ThemeGlassDrawable(tint = ntpSection, 테두리 없음)` 으로 그려 그 색 아래 배경이 흐리게 보임. 불투명 색이면 예전처럼 단색
- **카드 팝업이 열리고 닫힐 때 흰 창이 튀던 것 수정 (v3.7.32)**: `MorphDialog` 의 면 출발 색이 늘 불투명한 `colorSurface` 라서, 반투명 새 탭 카드가 열리면 한 프레임 만에 흰 창으로 바뀌고 닫을 때는 흰 창이 반투명 카드로 툭 바뀌었음(화면 녹화를 프레임 단위로 확인). ① `readOriginLook()` 이 카드 배경을 작은 그림(12x4)에 그려 면 색(투명도 포함)과 테두리 유무를 읽어 시작 색·시작 테두리 짙기(`startStrokeAlpha`)로 씀. 테마 색 카드(`ntpSection`·하늘색)는 테두리가 없어 테두리가 갑자기 생기지 않음. 유리 카드(`ThemeGlassDrawable`)는 유리가 그려지므로 면이 투명에서 시작 ② 닫기가 끝나 카드가 돌아오는 순간 `MorphSurface.hide()` 로 면·그림을 같은 때 지워, 반투명 카드 위에 면이 한 프레임 겹쳐 진해 보이던 것을 없앰
- **자동 스크롤 조작 막대 개선 (v2.5.41)**: ① 막대 배경을 「상/하단바 다시 보이기」 버튼과 같은 유리(블러) 모양으로 바꿈: 블러가 켜져 있고 안드로이드 12 이상이면 막대 바로 뒤의 웹 페이지 색이 흐리게 비치고(스크롤을 따라 실시간으로 바뀜), 아니면 예전처럼 반투명 면. 새 `BlurPillLayout` 이 `GlassBackdrop` 을 알약 모양으로 잘라 씀 ② 막대를 아래로 끌어 내리거나(또는 왼쪽 ⌄ 버튼) 누르면 막대가 화면 아래로 내려가 숨고 작은 ⌃ 탭만 남음. 탭을 누르거나 위로 끌면 다시 올라옴. 숨겨도 자동 스크롤은 계속 흐르고, 새로 시작하면 막대는 다시 보임 ③ 막대 위에서 시작한 세로 끌기는 버튼이 아니라 막대가 받음(버튼을 그냥 누르는 것은 그대로)
- **자동 스크롤 조작 막대: 숨기면 아무것도 안 남게, 제스처만으로 (v2.5.42)**: ⌄ 숨기기 버튼과 숨긴 뒤 남던 ⌃ 탭을 없앰. 막대(위쪽 가는 손잡이 포함, 버튼 위에서 시작해도 됨)를 아래로 끌어 내리면 완전히 사라지고, 다시 보려면 웹 화면 아래 가운데(시스템 제스처 영역 바로 위)에서 위로 쓸어 올림(이때는 자동 스크롤이 멈추지 않고 만지는 동안만 쉼). 처음 숨길 때 한 번만 이 방법을 알려 줌. 막대 모양도 다듬음: 위에 끌 수 있다는 표시인 손잡이, 속도는 작은 「속도」 이름 아래 큰 숫자, 속도를 바꿀 때 짧은 진동, 가장 느림/빠름에서는 −/+ 가 흐려짐
- **자동 스크롤 조작 막대 다듬기: 블러 제거 · 닫기/일시정지 (v2.5.43)**: ① 막대의 블러(유리) 배경을 없애고 불투명한 알약 모양으로 바꿈(`BlurPillLayout` 삭제 → 블러 없는 `DragPillLayout`). 가는 테두리선으로 웹 페이지와 구분 ② 왼쪽에 X 버튼(자동 스크롤을 끝내고 막대 닫기), 오른쪽 ▮▮ 버튼은 막대를 연 채로 일시정지 ↔ ▶ 이어가기(일시정지 중에는 화면을 만져도 아무 일 없고 직접 스크롤해서 볼 수 있음) ③ 속도 숫자 아래에 1~20단계 막대, 숫자가 바뀔 때 통통 튀고 −/+ 는 꾹 누르면 계속 바뀜(끝 단계에서 자동으로 멈춤) ④ −/+/닫기/일시정지 버튼은 동그란 물결과 눌림 반응, 일시정지 버튼은 강조 바탕 ⑤ 막대가 나타날 때·끌어 내릴 때(점점 옅어짐)·놓았을 때 스프링 움직임으로 부드럽게
- **자동 스크롤 일시정지 버튼 애니메이션 (v2.5.44)**: ▮▮ ↔ ▶ 가 아이콘 교체 대신 모양이 이어서 변함(두 막대가 각각 삼각형의 왼쪽·오른쪽 조각으로). 스프링으로 살짝 튕기며 기울었다 돌아오고, 버튼도 한 번 출렁임
- **자동 스크롤 막대: 「속도」 글자와 숫자 아래 막대 제거 (v2.5.45)**: 속도 칸에는 숫자만 남김(글자 크기 20). 위 v2.5.43 ③ 의 단계 막대는 없어짐
- **자동 스크롤 막대 숨기기/다시 보기 제스처가 멀티윈도우에서 안 먹히던 것 수정 (v2.5.46)**: 터치 위치(`rawX/rawY`, 화면 좌표)와 웹 화면·막대 영역(창 안 좌표)을 비교해서, 분할 화면·팝업 창처럼 창이 화면 (0,0) 이 아닐 때 어긋나던 것을 영역을 화면 좌표로 바꿔 맞춤. 다시 보기 쓸어올리기 자리도 넓힘(가로 ±110dp, 창 아래 120dp~6dp)하고 인식 기준을 살짝 완화(위로 40dp, 세로 우세 1.2배)
- **일시정지 버튼 모핑을 더 자연스럽게 (v2.5.47)**: 변하는 동안 기울어지던 것을 없애고, 거의 튕기지 않는 부드러운 스프링(강성 420·감쇠 0.82)으로 ▮▮ ↔ ▶ 가 이어서 변함. 버튼 전체 출렁임도 약하게
- **꾹 누르기 메뉴의 자동 스크롤 아이콘 변경 (v2.5.48)**: 「자동 스크롤」은 아래로 이어 흐르는 겹쳐진 쐐기 두 개(새 `ic_auto_scroll`), 「자동 스크롤 멈추기」는 조작 막대의 끝내기 버튼과 같은 X(`ic_close`)
- **자동 스크롤 막대의 X 버튼 다시 만들기 (v2.5.49)**: 맨 왼쪽 X 를 옅은 회색 동그라미 바탕(34dp)에 작은 X 로 바꿔 −/+ 와 구분되고 눈에 덜 띄게 함
- **꾹 누르기 메뉴 「자동 스크롤 멈추기」 아이콘 변경 (v2.5.50)**: 일반 X 대신 원 안의 작은 X(새 `ic_stop_circle`)로 바꿔 조작 막대의 동그란 X 버튼과 모양을 맞춤
- **자동 스크롤 막대 X 버튼 원 크기를 일시정지 버튼과 맞춤 (v2.5.51)**: X 버튼 바탕 동그라미를 34dp → 40dp 로 키워 일시정지 버튼과 같은 크기로(X 모양 크기 16dp 는 그대로)
- **자동 스크롤 설정을 「브라우저」 안으로 이동 (v2.5.52)**: 설정 첫 화면의 별도 「자동 스크롤」 카테고리를 없애고, 속도 · 화면을 만졌을 때 · 조작 막대 세 항목을 「브라우저」 카테고리의 새 소제목 「자동 스크롤」(번역 아래)로 옮김. 설정 값(`auto_scroll_*`)과 동작은 그대로
- **자동 스크롤 최대 속도 30단계로 확대 (v2.5.53)**: 속도 범위를 1~20단계 → 1~30단계로 늘림(1단계당 25dp/초 그대로라 최대 500 → 750dp/초). 기존에 저장된 1~20단계 값과 기본값(6단계)은 그대로
- **GitHub 올리기 「Update is not a fast forward」 수정 (v2.5.54)**: 확인 창을 띄울 때 읽어 둔 저장소 끝(head)을 「올리기」 때 그대로 부모로 써서, 그 사이 빌드 봇 등이 커밋하면 GitHub 가 거부하던 것을 고침. 이제 올리는 순간 최신 head 를 다시 읽어 그 위에 쌓고, 또 거부되면 처음부터 다시 쌓음(최대 3번)
- **자동 스크롤 막대 X 버튼 바탕 원을 더 밝게 (v2.5.55)**: 바탕 동그라미 투명도를 밝은 테마 10%(0x1A) → 6%(0x0F)로 낮춰 더 옅게, 어두운 테마는 10% → 17%(0x2B)로 올려 더 밝게
- **자동 스크롤 막대 여백 6dp 로 통일 (v2.5.56)**: 좌우·아래 여백, 손잡이(맨 위 작대기) 위 여백, 손잡이와 버튼 사이, 버튼 사이(X·−·숫자·+·일시정지) 간격을 모두 `GAP`=6dp 한 값으로 맞춤(전에는 10/6/6/2/4/0/0/8 제각각). 막대 크기 약 232×58dp → 236×62dp
- **자동 스크롤 막대 여백을 v2.5.55 로 되돌림 (v2.5.57)**: v2.5.56 의 6dp 통일을 취소하고 여백·간격을 이전 값(좌우 10 · 아래 6 · 손잡이 위 6 · 손잡이 아래 2 · X 뒤 4 · +/− 사이 0 · 일시정지 앞 8)으로 복원
- **탭 화면 창 전환이 멀티윈도우 상태를 이어받게 (v2.5.58)**: 지금 창이 분할 화면·떠 있는 창이었는데 탭 화면의 창 목록에서 다른 창을 고르면, 선택한 창을 앞으로 가져오며 분할이 깨지고 전체 화면으로 뜨던 것을 고침. 이제 지금 창이 멀티윈도우일 때는 선택한 창의 탭을 저장하고 그 창을 닫은 뒤, 지금 창이 있던 자리(분할 칸, 떠 있는 창이면 위치·크기까지)에 같은 창 번호로 다시 열고 지금 창을 닫음(`switchToWindow` · `openInPlaceOfThisWindow`). 닫힌 창을 누를 때도 같은 방식. 예외로 예전처럼 앞으로 가져오는 경우: 선택한 창에 시크릿 탭이 있을 때(저장되지 않아 사라지므로) · 선택한 창이 이미 옆 칸에 보이고 있을 때 · PiP
- **미러링·내장 플레이어 전환 애니메이션 제거 (v2.5.59)**: 미러링을 켤 때 페이지 영상이 원래 자리에서 창 가득 커지던 움직임(`MIRROR_ON_OWN_ANIM`)을 없애고 바로 창 가득 보여 줌. 내장 플레이어가 열리고 닫힐 때의 떠오르기·사라지기 전환(`player_in` / `player_out`)도 없애 바로 뜨고 바로 닫힘(`overridePendingTransition(0, 0)`). 시스템 애니메이션 설정과 무관하게 항상 적용
- **오류 화면 주소가 data:text/html... 로 뜨던 것 수정 (v2.5.60)**: 연결할 수 없어요 같은 오류 화면은 웹 기록에 실패한 주소로 남지만, 저장했다 되살린 탭·다른 창으로 옮긴 탭에서는 기록 항목이 `data:text/html;charset=utf-8;base64,` 로 바뀌어 주소창에 알 수 없는 글자가 뜨고 원래 주소는 보이지 않았음. 이제 주소창·보안 아이콘·북마크·공유 등은 오류 화면일 때 실패한 원래 주소(`errorUrl`)를 쓰고(`pageUrlOf`), `data:` 주소는 주소창에 보이지 않게 함. 되살린 탭이 오류 화면이면 빈 화면 대신 원래 주소를 다시 불러오고, 뒤로 가기는 남은 빈 오류 항목을 건너뜀
- **연결 실패 화면에 「다음 번호」 버튼 (v2.5.61)**: 오류 화면(연결할 수 없어요·404 등)의 「이전으로 · 다시 시도」 아래에 「다음 번호 (N)」 버튼을 추가. 누르면 실패한 주소의 마지막 번호를 1 늘린 주소를 바로 엶(`nextNumberUrl` · `errNext`). 경로의 마지막 번호를 먼저 보고 없으면 쿼리(`?page=3`)의 번호를 씀. 도메인·파일 확장자(`.mp4`)·`%XX` 인코딩 안의 숫자는 제외하고, `009 → 010` 처럼 앞의 0 자릿수를 지킴. 주소에 올릴 번호가 없으면 버튼은 숨김
- **「다음 번호」: 도메인 이름의 번호를 먼저 올림 (v2.5.62)**: `blacktoon145.com` → `blacktoon146.com` 처럼 도메인 이름 칸(.com 앞, `co.kr` 은 한 칸 더 앞)의 번호를 먼저 올리고 버튼에는 새 도메인을 표시(`다음 번호 (blacktoon146.com)`). 도메인에 번호가 없으면 v2.5.61 처럼 경로 → 쿼리의 번호를 올림. 서브도메인(`s3.`)·IP 주소의 숫자는 제외
- **미러링을 끄면 사이트의 영상이 사라지던 것 수정 (v2.5.63)**: 미러링 종료 때 영상의 인라인 `left·top·width·height·border-radius·transition` 을 통째로 지워서, 영상의 크기·자리를 인라인 스타일로 잡는 사이트(유튜브 등)에서 영상이 사라져 보였음(`mirrorIntroClear`). 이제 미러링이 처음 건드리기 전의 값을 저장해 두었다가 그대로 되돌림. 또 끌 때 페이지에 `resize` 를 알리고, 내장 플레이어에서 돌아올 때처럼 영상을 두 번 다시 그리게 함(`repaintPageVideos`)
- **영상 아래 「내장 플레이어로 열기」·「PiP로 보기」 버튼 글자 선택 막기 (v2.5.64)**: 두 버튼(과 그 바깥 상자)에 `user-select:none`·`-webkit-touch-callout:none` 을 주고, `selectstart`·`contextmenu`·`dragstart` 를 막아 길게 눌러도 글자가 선택되거나 선택 메뉴가 뜨지 않음
- **영상 아래 「PiP로 보기」 버튼에 아이콘 추가 (v2.5.65)**: 「▶ 내장 플레이어로 열기」처럼 「PiP로 보기」 앞에도 아이콘을 붙임. 앱 안 `ic_pip` 과 같은 모양(바깥 화면 + 오른쪽 아래 작은 창)을 SVG 요소로 그려 글자색(`currentColor`)을 따름. 유튜브처럼 Trusted Types 로 `innerHTML` 이 막힌 사이트에서도 보이도록 `createElementNS` 로 만듦
- **「PiP로 보기」 버튼 글자 높이 맞춤 (v2.5.66)**: 아이콘 때문에 줄 높이가 늘어 글자가 「내장 플레이어로 열기」보다 아래로 처지던 것을, 버튼을 `inline-flex` + `align-items:center` 로 바꿔 두 버튼 글자 높이를 맞춤
- **영상 아래 버튼을 누르면 중앙으로 줄어들게 (v2.5.67)**: 누르는 모양(`scale(.93)`)이 나타날 때 쓰던 `transform-origin:100% 100%`(오른쪽 아래 모서리)를 그대로 따라 모서리 쪽으로 쪼그라들던 것을, 나타난 뒤에는 `50% 50%`(중앙)로 바꿔 제자리에서 줄었다 돌아오게 함. 나타나는 동안 원점이 튀지 않도록 `transform-origin` 도 같이 전환(`.32s`), 두 번째 버튼의 전환 지연도 4개 값으로 맞춤
- **PiP 에서 전체 창으로 돌아오면 상태표시줄 자리가 하얘지던 것 수정 (v2.5.68)**: 전체화면 영상·미러링 중 PiP 에 다녀오면 창 크기 변경 알림으로 `updateStatusBarColor()` 가 불려 상태표시줄 자리를 평소 앱 면 색(흰색)으로 칠했음. 전체화면 영상·미러링 중에는 검정(`videoFull`)으로 두고, `onPictureInPictureModeChanged` 에서 뒤 배경을 다시 검정으로 칠하고 시스템 바를 다시 숨김
- **「PiP로 보기」로 갔다 돌아오면 상태표시줄 자리가 하얘지던 것 수정 (v2.5.69)**: 일반 페이지에서 PiP 로 갔다 전체 창으로 돌아올 때 시스템이 상태표시줄 인셋을 다시 알려 주지 않으면 위 여백이 PiP 때 값(0)으로 남아 흰 주소창이 상태표시줄 자리까지 올라왔음. `onPictureInPictureModeChanged(false)` 에서 바로·150ms·500ms 뒤 세 번 `requestApplyInsets` + 상태표시줄 숨김·색 다시 적용(`resync`)
- **PiP 에서는 AI 어시스턴트 창을 숨김 (v2.5.70)**: 작은 창(PiP)이 되면 열려 있던 AI 어시스턴트 창(시트·태블릿 팝업·분할 패널)을 닫아 두고(`aiReopenAfterPip`), 전체 창으로 돌아오면 다시 엶. PiP 로 창 크기가 바뀌며 폰↔태블릿 모드 전환 처리(`closeWindowsForModeChange`)가 AI 창을 다시 열던 것도 PiP 중에는 열지 않고 돌아올 때로 미룸
- **미러링 컨트롤에 「화질」 선택 추가 (v2.5.71)**: 미러링(페이지 영상을 창 가득 보기) 아래 줄의 배속 칩 옆에, 페이지 플레이어가 화질 목록을 알려 주면 현재 화질 칩(`자동`·`720p` 등)이 나타나고 누르면 화질 창이 열려 고를 수 있음. 유튜브(`#movie_player.setPlaybackQualityRange`, 자동 = `tiny~highres`)와 JW Player(`setCurrentQuality`)를 지원하고, 바꾼 화질이 바로 적용되게 유튜브는 지금 위치로 한 번 다시 찾아 감. 목록은 JS 가 `EvMedia.mquals` 로 알려 주고(`mqRep`), 고른 화질은 `mcmd` `q` 로 보냄(`MediaScripts.mirrorQuality`). 화질 목록을 알 수 없는 사이트에서는 칩이 나타나지 않음
- **미러링 컨트롤을 내장 플레이어와 같은 구성으로 + 유튜브 자막·번역 (v2.5.72)**: ① 위쪽 바는 `닫기 · 제목 · 자막 번역 칩 · 작은 창 · 회전`(화면 비율 버튼은 설정으로 이동), 아래 줄은 `재생 · ±10초 · 시간 · 배속 · CC · 톱니`. 자막을 켜 두면 위쪽에 「자막 번역」 칩이 나타나 누를 때마다 번역 끔 → 자막 번역 → 번역+원문(`cycleSubTranslate`). 톱니는 내장 플레이어 설정처럼 `화질 · 자막 · 재생 속도 · 화면 비율` 창을 열고(`settings`/`quality`/`speed`/`fit` 쪽), 앞서 따로 두었던 화질 칩은 이 안으로 옮김. ② 유튜브는 자막이 영상의 `textTracks` 가 아니라 플레이어 안에 있어 미러링에서 자막·번역이 안 됐음: 플레이어(`getOption('captions','tracklist')`)에서 자막 목록을 받아 번호 1000~ 로 CC 목록에 넣고, 고르면 `setOption('captions','track')` 으로 켜서 `.ytp-caption-segment` 글을 읽어 앱에 보냄(`ytCue`). 자동 생성 자막은 한 단어씩 늘어나므로 260ms 멈춘 뒤 보내 번역이 한 줄에 한 번만 되게 함. 번역·모양은 기존 앱 자막과 같음. 실시간(소리 인식) 자막은 미러링에 넣지 않음
- **미러링 화질 목록 표시 + 화면 비율 렉 수정 (v2.5.73)**: ① 화질은 유튜브·JW Player 만 목록이 떠서 그 밖의 사이트에서는 설정에 '화질' 줄이 아예 안 보였음 → 페이지에 걸린 hls.js·shaka·dash.js·video.js(VHS)·Plyr 플레이어를 찾아(`mqFind`/`mqDuck`, 영상 요소·윗대 요소·전역 객체를 훑음, 못 찾으면 2초에 한 번만 다시 찾음) 화질 목록을 앱에 알리고 고른 화질로 바꿈(`mqListX`/`mqSetX`, 자동 포함). 영상 파일 하나(mp4 등)처럼 화질 목록 자체가 없는 영상은 여전히 화질 줄이 안 보임. ② 화면 비율을 바꿀 때마다 스타일 시트(`__ev_pip_style`) 전체를 다시 써서 문서 전체 스타일이 다시 계산돼 렉이 걸렸음 → 비율은 영상에만 인라인 `object-fit` 으로 걸고(`mfitApply`, 끌 때 원래 값 복구), 스타일 시트는 내용이 같으면 다시 쓰지 않음(PiP·회전 뒤 `nudgeMirrorLayout` 도 가벼워짐)
- **이전/다음 영상 버튼 (v2.5.74)**: 내장 플레이어와 미러링 컨트롤 아래 줄에 `⏮ 이전 영상` · `⏭ 다음 영상` 버튼 추가. ① 내장 플레이어: 플레이어는 영상 주소 하나만 재생하므로, 누르면 원래 페이지에서 '이전·다음 영상' 버튼(유튜브식 `.ytp-next-button`, `aria-label`/`title` 이 Next·다음 인 것 등)을 대신 눌러(`MediaScripts.pageSkip`) 새로 잡힌 영상 주소(누르기 전에 없던 것)를 최대 8초 찾고, 찾으면 열려 있는 플레이어를 그 영상으로 바꿈(`MainActivity.playerSkip` → `PlayerActivity.switchTo/loadOther`). 이전 버튼은 3초 넘게 봤으면 처음부터. 페이지에 버튼이 없으면 '버튼을 찾지 못했어요' 알림. 세로처럼 폭이 430dp 보다 좁으면 10초 버튼을 숨겨 아래 줄이 넘치지 않게 함(더블탭 10초 이동은 그대로). ② 미러링: 같은 버튼이 페이지 버튼을 누르고(`mSkipDo`), 없으면 이전은 처음부터·다음은 끝으로 보내 사이트가 다음 영상을 잇게 함. 영상이 든 iframe 안에 버튼이 없으면 바깥 페이지에서도 찾음(`mskipUp`). 아래 줄이 좁아지지 않게 재생 시간은 진행 막대 오른쪽 끝으로 옮김
- **가로로 밀어서 재생 위치 바꾸기 제거 (v2.5.75)**: 내장 플레이어와 미러링 화면에서 좌우로 쓸어 시간 이동하던 제스처(`onScroll`)를 없앰. 시간 이동은 진행 막대·10초 버튼·더블탭으로만 함. 더블탭 10초·길게 눌러 2배속·탭으로 컨트롤 보이기/숨기기는 그대로
- **더블탭 가운데 = 재생/일시정지 + 더블탭 애니메이션 개선 (v2.5.76)**: 내장 플레이어·미러링 화면을 3등분해 왼쪽 더블탭 = 10초 뒤로, 가운데 = 재생/일시정지, 오른쪽 = 10초 앞으로(`onDoubleTap`). 효과는 새 `DoubleTapFx` 뷰가 그림(터치는 통과): 좌우는 그 쪽 화면이 곡선 모양으로 밝아지고 탭한 자리에서 물결이 번지며 화살표 세 개가 차례로 밝아지고 누적 초(10→20→30초)가 톡 튐, 가운데는 검은 동그라미 안의 재생/일시정지 아이콘이 커졌다 사라짐. 예전의 글자 표시(‹‹ 10초)는 없앰
- **빌드 오류 대비 정리 (v2.5.77)**: GitHub 빌드가 `:app:compileReleaseKotlin` 의 Internal compiler error 로 실패. 가장 의심되는 코드(이전/다음 영상 찾기 `playerSkip` 안의 람다 속 재귀 지역 함수 + 바뀌는 지역 변수 캡처)를 일반 멤버 함수(`playerSkipPoll`)로 풀어 컴파일러가 다루기 쉽게 함. 원인이 이것이 아니면 로그 앞쪽의 `File being compiled` 줄로 파일을 확인해야 함
- **빌드 오류 원인 확정·수정 (v2.5.78)**: 로그의 `File being compiled: MediaScripts.kt` / `UTF8 string too large` — `MediaScripts.INJECT` 문자열 상수가 약 66KB 라 JVM 상수 한계(UTF-8 65535바이트)를 넘어 컴파일러가 죽었음(v2.5.77 의 `playerSkip` 정리는 원인이 아니었음). `INJECT` 를 4조각(`INJECT_1`~`INJECT_4`, 각 약 16KB)으로 나누고 `val INJECT = INJECT_1 + … ` 로 런타임에 이어 붙임(const 로 두면 상수 접기로 다시 합쳐져 넘침). 스크립트 내용은 그대로. **주의**: 한 `const val` 문자열은 UTF-8 로 65535바이트를 넘기면 안 됨
- **이전/다음 영상 버튼이 PiP 아이콘으로 보이던 문제 수정 (v2.5.79)**: 두 버튼의 눌림 효과 종류를 `"pip"` 로 줬는데, `Motion.barButton` → `MorphIconDrawable.install` 이 `"pip"` 종류에는 PiP 모양을 직접 그려 버튼 아이콘을 덮어써서 `ic_skip_prev/next` 가 가려졌음. 종류를 `"skip"` 으로 바꿈(`MorphIconDrawable.KINDS` 에 없는 종류라 아이콘은 XML 그대로, 눌림 크기 효과만 적용 — `Motion.barFx` 에 0.88 로 등록). 대상: `PlayerActivity`(ev_prev/ev_next), `MirrorOverlay`(이전/다음). **주의**: `barButton` 의 종류 이름은 모양 변하는 아이콘 이름이기도 하니, 다른 아이콘 버튼에 `pip`·`rotate` 같은 이름을 빌려 쓰지 말 것
- **다음 영상을 누르면 유튜브 광고 건너뛰기 (v2.5.80)**: 미러링(유튜브는 내장 플레이어 대신 미러링)의 「다음 영상」을 눌렀을 때 ① 광고 중(`.ad-showing` 등)이면 영상 이동 대신 광고부터 건너뜀 — '건너뛰기' 버튼이 보이면 누르고, 건너뛸 수 없는 광고는 광고 영상을 끝으로 보냄(`MediaScripts.mAdSkip`). ② 광고가 아니면 평소처럼 다음 영상으로 가고, 그 직후 새 영상 앞에 붙는 광고도 약 8초 동안 0.3초마다 살펴 건너뜀(`mAdWatch`). 설정의 '광고 자동 건너뛰기'와 상관없이 버튼을 눌렀을 때는 항상 동작. 유튜브 주소(youtube.com / youtube-nocookie.com)에서만 동작
- **페이지가 다시 불러와져도 보던 영상 위치로 이어보기 (v2.5.81)**: PiP 로 오래 보다 돌아오면 시스템이 웹뷰 렌더러·앱을 종료해 페이지가 새로 로드되고 본 위치가 사라지던 문제. 재생 보고(`EvMedia.progress`)마다 영상 위치를 탭에 적어 두고(`noteResume`: 60초 이상 영상, 10초~끝 10초 전 구간만), ① 렌더러 종료 복구(`recoverRenderer`) ② 앱이 종료됐다 탭이 복원될 때(`saveTabs` 의 `rp`/`ru`) 같은 페이지(유튜브는 `v=` 값 비교)가 다시 로드를 마치면 영상이 준비되는 대로 그 위치로 한 번 옮김(`resumeJs`: 광고 중이면 기다리고, 이미 5초 넘게 재생됐으면 건드리지 않음, 최대 45초). 시크릿 탭은 제외. 최상위 문서의 video 만 대상(iframe 안 플레이어는 못 이어감)
- **유튜브 광고 자동 건너뛰기가 안 되던 문제 수정 (v2.5.82)**: 미러링·PiP 는 영상 말고 모든 요소를 `visibility:hidden` 으로 가리는데, 건너뛰기 버튼이 '보이는지' 를 `visibility` 로 검사해서 숨겨진 것으로 판단하고 한 번도 누르지 않았음. 이제 크기(>0)와 `display` 로만 판단. 또 유튜브가 `click()` 하나로는 눌림으로 안 치는 때가 있어 pointerdown·mousedown·pointerup·mouseup·click 을 순서대로 보냄(`tap`). '다음 영상' 의 광고 건너뛰기(`mAdSkip`)도 같은 검사를 고침. **주의**: 미러링·PiP 중인 페이지에서 요소가 '보이는지' 를 `visibility` 로 판단하지 말 것
- **미러링 제목이 영상이 바뀌어도 고정되던 문제 수정 (v2.5.83)**: 미러링 위쪽 제목은 `addMirrorOverlay` 에서 시작할 때 한 번만 정해져서, 유튜브처럼 같은 페이지 안에서 다음 영상으로 넘어가도 처음 제목이 남았음. 이제 `mirrorTitleFor`(페이지가 알려 준 지금 영상 제목(mediaSession) → 탭 제목 순)로 정하고, 탭 제목이 바뀔 때(`onReceivedTitle`)와 영상 제목 보고(`EvMedia.meta`)가 올 때마다 `refreshMirrorTitle` 로 다시 반영
- **AI 창을 팝업 모드로 바꿨는데 AI 버튼을 다시 누르면 분할로 열리던 문제 보완 (v2.5.84)**: 분할 패널의 머리글을 끌어 떼어 내면 패널이 떠 있는 창 모양으로 바뀌지만, '팝업 모드' 설정(`ai_popup_size` 의 `split`)은 손가락을 뗄 때(`undockToPopup`)에야 false 로 바뀌었음. 그 전에 터치가 끊기거나 앱이 전환되면 설정이 true 로 남아 다음에 AI 버튼을 누르면 분할로 열렸음. 이제 떼어 내는 순간(`lift`)에 바로 false 로 저장하고, 가장자리에 놓으면 `dockSplit` 이 다시 true 로 바꿈. **원인을 한 가지로 확정하지 못함** — 그래도 같은 증상이면 어떤 순서로 눌렀는지(떼어 낸 뒤 놓은 위치, 버튼을 누른 때) 확인할 것
- **PiP 작은 창에 「백그라운드로 재생」 헤드셋 버튼 추가 (v2.5.85)**: 웹 영상 PiP(`MainActivity.pipParams`)와 내장 플레이어 PiP(`PlayerActivity.pipParams`) 의 시스템 버튼에 헤드셋 아이콘(`ic_pip_headset`)을 넣음. 누르면 작은 창을 닫고(`moveTaskToBack`) 소리만 계속 재생하며, 멈춰 있던 영상이면 이어서 재생함. 설정의 「백그라운드 재생」 이 꺼져 있어도 이번에는 재생하도록 임시 값(`bgForced` / `bgRequested`)을 써서 설정 자체는 바꾸지 않고, 앱 화면으로 돌아오면 해제됨. 웹 PiP 는 작은 창에 둘 수 있는 버튼 수(`maxNumPictureInPictureActions`)가 4개 미만인 기기에서는 「이전 영상」 을 빼고 「재생 · 다음 · 헤드셋」 으로 보여 줌
- **PiP·백그라운드에서 「다음 영상」 으로 넘어간 뒤 앱을 다시 켜면 재생 시간이 사라지고 새로고침되던 문제 수정 (v2.5.86)**: 탭 상태(`saveTabs`: 주소·앞뒤 기록·이어보기 위치)는 앱을 나갈 때 한 번만 저장돼서, 그 뒤 PiP·알림에서 다음 영상으로 주소가 바뀌고 시스템이 앱을 종료하면 옛 주소·옛 위치로 복원됐음. 이제 앱이 안 보이거나 PiP 인 동안 재생 보고(`EvMedia.progress`)가 올 때 주소가 바뀌었거나 10초가 지났으면 저장함(`saveTabsWhileAway`). **원인을 앱 종료(프로세스 종료)로 추정한 수정** — 종료 없이도 새로고침된다면 그때 상황(어디서 눌렀는지, 사이트)을 알려 줄 것
- **이어보기 한계 풀기 (v2.5.87)**: v2.5.86 의 한계였던 ① 60초 미만 영상은 기록 안 함 ② 처음 10초·끝 10초는 기록 안 함 ③ 위치가 최대 10초 전으로 돌아감 을 모두 완화. 이제 10초 이상 유한 길이 영상이면 3초~끝 5초 전 구간을 기록하고(`noteResume`, 라이브는 제외), 앱이 안 보이거나 PiP 인 동안은 재생 위치만 작은 설정 파일(`evergreen_resume`, `saveResumeLight`)에 2초마다 적음. 주소가 바뀔 때는 기존처럼 탭 전체를 저장하고(`saveTabsWhileAway`, 같은 주소면 30초 간격), 앱 복원 때 탭 번호표(`sid`)로 가벼운 저장분이 더 최근이면 그 값을 씀. 이어가는 조건도 완화(`resumeJs`: 영상 길이 > 위치+2초, 이미 위치 근처까지 재생됐으면 건드리지 않음). iframe 안 플레이어는 여전히 못 이어감
- **PiP 헤드셋(백그라운드로 재생) 버튼을 누르면 영상이 처음부터 재생되던 문제 보완 (v2.5.88)**: **원인을 코드만으로 확정하지 못해** 증상을 막는 보호를 넣음. 버튼을 누르는 순간의 재생 위치를 적어 두고(웹 PiP: `bgGuardPos`, 내장 플레이어: `guardPosition`), 그 뒤 20초(웹)/약 8초(내장) 안에 위치가 3초 넘게 뒤로 튀면 누른 위치로 되돌림. 내장 플레이어는 버튼을 누르는 즉시 `savePosition()` 도 해서 창이 다시 만들어져도 그 위치에서 이어짐. 같은 증상이면 웹 PiP 인지 내장 플레이어 PiP 인지, 어떤 사이트인지 확인할 것
- **유튜브에서 PiP 헤드셋 버튼 후 처음부터 재생되는 경우 보완 (v2.5.89)**: 영상 사이트는 유튜브(미러링/웹 PiP 경로)로 확인됨. v2.5.88 의 위치 되돌리기(`bgGuard*`)에 더해, 버튼을 누른 뒤 20초 동안은 페이지가 새로 로드돼도 누른 위치로 이어가도록 이어보기(`resumeApply`)를 켜 둠. **원인은 아직 확정 못 함** — 같은 증상이면 누른 직후 화면(앱이 열리는지/소리만 처음부터 나는지)과 영상이 처음부터 시작되는 시점을 알려 줄 것
- **웹 PiP 버튼 4개 모두 넣기 (v2.5.90)**: v2.5.85 는 버튼 수 한도(`maxNumPictureInPictureActions`)가 4 미만이면 「이전 영상」 을 뺐음. 이제 한도와 상관없이 「이전 · 재생 · 다음 · 헤드셋」 4개를 항상 넘김. 시스템이 그릴 수 있는 개수보다 많으면 시스템이 **뒤쪽(헤드셋)부터** 자르므로, 3개만 보이는 기기에서는 헤드셋이 안 보일 수 있음 (앱에서 풀 수 없는 OS 한도)
- **「이전 영상」 이 현재 영상을 처음으로 돌리던 문제 수정 (v2.5.91)**: 유튜브 단일 영상처럼 페이지에 재생 목록 「이전」 버튼이 없으면 예전에는 항상 현재 영상 `currentTime=0` 이었음. 이제 재생 목록 「이전」 버튼이 있으면 시간과 상관없이 그걸 누르고, 없으면 `EvMedia.prevPage()` 로 웹 기록에서 바로 앞 페이지가 다른 영상 페이지(/watch, /shorts/, v= 등)일 때 그곳으로 돌아감(`MediaJs.prevPage`). 갈 곳이 없을 때만 현재 영상을 처음부터 재생. 앞 페이지가 영상이 아니면(검색 결과 등) 돌아가지 않음
- **유튜브에서 미디어 플레이어 제목이 옛 영상 제목으로 남던 문제 수정 (v2.5.92)**: 시스템 미디어 패널·메뉴 플레이어·미러링 제목은 페이지가 `navigator.mediaSession` 에 넣어 준 제목을 그대로 썼는데, 유튜브는 다음 영상으로 넘어가거나 앱이 화면 밖에 있는 동안 이 값이 늦게 갱신돼 화면의 영상은 "정치 대상"인데 패널에는 이전 영상 제목이 남았음. 이제 유튜브에서는 플레이어가 지금 틀고 있는 영상 정보(`getVideoData()` 의 제목·채널·video_id, `MediaScripts.ytNow`)를 `meta()` 에서 먼저 확인해, mediaSession 제목과 다르면 플레이어 값으로 바꿔 보고함. 아티스트는 채널 이름, 그림은 그 영상의 썸네일(`i.ytimg.com/vi/<id>/hqdefault.jpg`)로 함께 바뀌어 옛 영상 그림이 남지 않음. 광고 재생 중(`.ad-showing`)에는 광고 정보라서 건드리지 않음. 유튜브가 아닌 사이트는 기존 그대로
- **PiP·백그라운드 재생 뒤 앱을 다시 열면 페이지가 새로 불러와지던 문제 보완 (v2.5.93)**: **원인을 코드만으로 확정하지 못해** 가능성이 큰 두 갈래를 막음. ① 웹뷰 렌더러 우선순위: 기본값(`setRendererPriorityPolicy(IMPORTANT, waivedWhenNotVisible=true)`)은 화면에 안 보이면 낮은 우선순위라, PiP·백그라운드 재생으로 가려진 동안 메모리가 모자라면 렌더러가 먼저 종료되고 앱을 열 때 `recoverRenderer` 가 페이지를 다시 불러왔음. 이제 소리가 나는 탭이 있고 백그라운드 재생이 켜져 있거나 PiP 중이면 안 보여도 중요한 렌더러로 취급(`applyRendererPriority`, 새 웹뷰·미디어 상태 변경·PiP 전환 때 적용). ② 창 재생성: `configChanges` 에 없던 `keyboard|navigation|touchscreen|colorMode|uiMode` 가 바뀌면(키보드 커버·마우스 연결, 화면 색 모드 변경 등) 시스템이 창을 다시 만들어 탭이 복원·재로딩됐음. 메인·추가 창은 이 값들을 직접 받게 하고(`uiMode` 는 다크 모드가 실제로 바뀔 때만 `recreate()`, `onConfigurationChanged`), 내장 플레이어는 `uiMode` 를 뺀 나머지를 추가. 같은 증상이 남으면 다시 연 직후 「메모리가 부족해 페이지가 종료되어 다시 불러옵니다」 안내가 떴는지(렌더러 종료) 아니면 안내 없이 앱이 처음부터 시작됐는지(앱 프로세스 종료)를 알려 줄 것
- **PiP 에서 전체화면 버튼을 누르면 페이지가 새로 불러와지던 문제 수정 (v2.5.94)**: 넓은 화면에서는 데스크톱 사이트, 폰 화면에서는 모바일 사이트로 자동 전환하는데(`syncSiteModeWithLayout`), PiP 에서 전체 창으로 돌아오는 순간 시스템이 'PiP 아님' 을 먼저 알리고 창 폭은 아직 PiP 때의 작은 값으로 읽히는 때가 있어 '폰 화면' 으로 판단 → 사이트가 모바일로 바뀌며 페이지를 다시 불러오고, 폭이 제대로 오면 다시 데스크톱으로 바뀌며 또 불러왔음(앱을 다시 연 직후 "안내 없이 새로고침" 증상과 일치). 이제 PiP 중이거나 방금 나온 뒤 1.5초 동안(`pipSettling`)은 이 자동 전환을 하지 않고, 창 크기가 자리 잡은 뒤(1.7초) 실제 폭으로 한 번만 다시 판단함(`siteModeSettle`, 폭이 그대로면 아무것도 바뀌지 않음). 진짜로 화면 모양이 바뀐 경우(폰↔태블릿)는 그 뒤에 그대로 전환됨. 앞서 v2.5.93 에서 넣은 렌더러 우선순위·`configChanges` 보완은 그대로 둠(원인이 이것이 아니었더라도 해롭지 않은 안전장치). 코드로 확정한 것이 아니라 증상(안내 없이 새로고침, PiP 전체화면 버튼)에서 좁힌 원인이므로, 같은 증상이 남으면 알려 줄 것
- **모바일↔데스크톱 사이트를 바꿔도 보던 영상 위치에서 이어 재생 (v2.5.95)**: 사이트 모드를 바꾸면(상단바 버튼 `toggleDesktopSite`, 창 크기에 따른 자동 전환 `syncSiteModeWithLayout`) 페이지를 다시 불러오는데, 영상 위치를 이어 주는 이어보기(`resumeApply`)는 렌더러 종료·앱 복원 때만 켜져서 처음부터 다시 재생됐음. 이제 다시 불러오기 직전에 재생 보고(`mediaProg`)에서 지금 위치를 적어 두고(`carryPlaybackPosition`: 길이 10초 이상, 3초~끝 5초 전 구간, 재생 중이면 마지막 보고 뒤 흐른 시간을 더함) 새 페이지에서 영상이 준비되면 그 위치로 옮김(`resumeJs`). 유튜브는 모바일(m.)↔데스크톱(www.)으로 넘어가면 주소 앞머리가 달라 같은 영상으로 못 알아보던 것도 `m.`·`www.` 를 무시하고 비교하도록 보완(`resumeHost`). 일시정지해 둔 영상이라도 다시 불러오면 사이트가 자동 재생하는 동작은 그대로
- **「모바일/데스크톱 자동 전환」 설정 추가 (v2.5.96)**: 설정 > 브라우저 > 일반에 켜고 끄는 스위치(`Prefs.autoSiteMode`, 기본 켜짐)를 추가. 켜져 있으면 지금까지처럼 창이 넓으면 데스크톱 사이트, 좁으면 모바일 사이트로 자동 전환(바뀔 때 페이지를 다시 불러오고 보던 영상 위치는 이어 감). 끄면 창 크기·분할 화면·PiP 로 폭이 바뀌어도 사이트 모드를 건드리지 않고 직접 고른 모드를 유지하며, 상단바/메뉴의 데스크톱 버튼으로만 바꿈(`syncSiteModeWithLayout` 맨 앞에서 확인). 다시 켜면 지금 창 크기에 맞춰 바로 판단함. 폰↔태블릿 **화면 구성(바·탭 줄 배치)** 전환은 이 설정과 상관없이 그대로 창 크기를 따름. 설정 검색에도 등록(pc·데스크탑·분할 화면 등으로 찾아짐)
- **분할·팝업 창에서 미러링 영상이 창 가득 안 차던 것 수정 (v2.5.97)**: 미러링은 페이지 영상을 `100vw`×`100vh`(레이아웃 뷰포트)로 키우는데, 분할 화면·팝업 창으로 창 크기가 바뀌면 페이지 배율이 새 창에 다시 맞춰지지 않아 이 크기가 실제로 보이는 영역의 약 80% 만 되어, 영상이 왼쪽 위에 작게 붙고 오른쪽·아래가 비었음(창 크기가 바뀌는 것을 미러링은 PiP 진입·복귀 때만 알아챘음). ① 영상 칸을 `max(100vw, 보이는 영역 CSS px)`(`--ev_mw`/`--ev_mh`, `mSizeOn`/`mSizeSync`)로 잡고, `resize`·`visualViewport.resize` 때마다 다시 잼. ② 창 크기가 바뀔 때(`onConfigurationChanged`·`onMultiWindowModeChanged`·웹 영역 가로/세로 크기 변화) 미러링 중이면 크기가 멎은 뒤(0.3초) `nudgeMirrorLayout` 이 앱이 잰 보이는 영역(웹뷰 px ÷ 페이지 배율)을 페이지에 알려(`MediaScripts.mirrorResize`) 영상을 다시 창 가득 맞춤(0.4초 뒤 한 번 더). 미러링을 끄면 이 값들은 지움. 내장 플레이어(`PlayerActivity`)는 해당 없음
- **탭 화면 전환 애니메이션의 미리보기에서 사진이 찌그러지고 배치가 달라지던 것 수정 (v2.5.98)**: 탭 버튼을 눌러 페이지가 탭 카드로 줄어드는 그림을 웹뷰를 소프트웨어 캔버스에 0.6배로 다시 그려(`View.draw`) 만들었는데, 이 방식은 웹뷰가 실제 화면과 다르게(사진이 눌리고 배치가 조금 다르게) 그려질 수 있었음. 이제 탭 화면을 열 때는 화면에 이미 그려진 픽셀을 PixelCopy 로 그대로 복사해 와서(`capturePixels`, 보통 수십 ms 기다림, RGB_565 로 줄여 보관) 그 그림으로 줄어듦·카드 미리보기를 만듦. 탭 화면을 닫을 때(카드 → 페이지)는 탭 화면이 위에 떠 있어 다시 복사할 수 없으므로, 열 때 찍어 둔 그림이 지금 페이지 영역과 같은 비율이면 그 그림을 그대로 쓰고 비율이 달라졌을 때만 예전처럼 다시 그림. 시크릿 탭(FLAG_SECURE)·복사 실패 때는 예전 방식으로 대신함. 탭을 바꿀 때 남기는 미리보기(`selectTab`)는 메뉴·팝업의 흐림 효과가 같이 찍힐 수 있어 그대로 둠
- **내장 플레이어 재생/일시정지 버튼 애니메이션을 자연스럽게 (v2.5.99)**: 내장 플레이어(`PlayerActivity`)와 미러 오버레이(`MirrorOverlay`)의 버튼은 재생 삼각형 ↔ 일시정지 막대로 모양이 바뀔 때 스프링(감쇠 0.62)을 써서 목표를 넘나들며 출렁였고, 막대가 늘어났다 줄어드는 식으로 모양이 일그러져 보였음. 이제 `MorphIconDrawable.settle` 이 `player` 종류에는 스프링 대신 `SmoothClock` + `PathInterpolator(0.4, 0, 0.2, 1)` 곡선으로 300ms 동안 넘치지 않고 매끄럽게 변하고, 변하는 중간에는 최대 6% 작아졌다 돌아와 숨 쉬듯 이어짐(도중에 상태가 또 바뀌면 지금 모양에서 남은 거리만큼만 시간을 써서 되돌아감). 메뉴창의 미디어 플레이어(`MainActivity` 의 `setPlayIcon`)는 이미지를 통째로 바꾼 뒤 버튼을 비틀어 튕기던 방식이어서 어색했는데, 같은 `player` 모양 변하는 아이콘으로 바꿔 세 플레이어가 똑같이 움직임. 모션 끄기 설정이면 바로 바뀜. PiP 작은 창의 버튼은 시스템이 그려서 그대로 둠
- **내장 플레이어·미러링 플레이어 컨트롤 버튼 배치 정리 (v2.5.100)**: 예전에는 재생 · 이전 · 10초 뒤로 · 10초 앞으로 · 다음 순서로 왼쪽에 몰려 있어 이전/다음이 10초 버튼 양옆으로 갈라져 보였고, 세로 화면(폭 430dp 미만)에서는 10초 버튼을 아예 숨겼음. 이제 아래 컨트롤을 세 줄로 나눠 1줄: 이전 · 10초 뒤로 · 재생/일시정지(가장 크게, 가운데) · 10초 앞으로 · 다음을 가운데 정렬로 좌우 대칭 배치, 2줄: 진행 막대, 3줄: 시간(왼쪽) … 배속 · CC · 설정(오른쪽). 줄이 나뉘어 좁은 화면에서도 넘치지 않으므로 10초 버튼 숨김 코드를 없앰. 위·아래 어두운 막은 늘어난 높이에 맞춰 200dp 로 키움(`ev_player_controls.xml`, `MirrorOverlay`). 메뉴창 미디어 플레이어는 이미 이전 · 10초 · 재생 · 10초 · 다음이 같은 간격으로 대칭이라 그대로 둠
- **플레이어 재생·이전·다음·10초 버튼을 화면 한가운데로 (v2.5.101)**: v2.5.100 에서 아래 한 줄로 모아 둔 이전 · 10초 뒤로 · 재생/일시정지 · 10초 앞으로 · 다음 버튼을 영상 한가운데로 옮김(`ev_player_controls.xml`, `MirrorOverlay`). 아래에는 진행 막대 + 시간 · 배속 · CC · 설정 두 줄만 남아 아래 어두운 막을 150dp 로 줄임. 밝은 영상 위에서도 가운데 버튼이 보이게 컨트롤이 떠 있는 동안 영상을 살짝(20%) 어둡게 함(`ev_dim`). 가운데에 버튼이 생겨서 이동 시간·배속·이어서 재생 같은 가운데 안내(OSD)는 위쪽 바 바로 아래 가운데로 옮김
- **10초 이동 버튼을 숫자가 들어간 화살표 모양으로 (v2.5.102)**: 내장 플레이어 · 미러링 플레이어 · 메뉴창 미디어 플레이어의 10초 뒤로/앞으로 버튼을 Tabler 의 `rewind-backward-10` / `rewind-forward-10` 모양(꺾이는 화살표 + 숫자 10, 선 2)으로 바꿈(`ic_rewind_10`, `ic_forward_10`). 숫자가 그림 안에 들어가서 따로 얹던 "10" 글자(`TextView`·`IconNumberView`)는 없앰. 버튼을 누르면 숫자는 그대로 있고 화살표만 가는 방향(되감기 = 왼쪽, 빨리감기 = 오른쪽)으로 쏘았다가 돌아옴(`MorphIconDrawable` 의 `skipback`/`skipfwd`). 이전·다음 버튼 아이콘도 같은 크기(24dp)로 맞춤
- **자막 번역 속도 높이기 (v2.6.00)**: 예전에는 자막 줄이 화면에 뜬 뒤에야 한 줄씩 번역을 요청해서, 번역이 올 때까지 원문이 흐리게 보였음. 이제 영상에 딸려 온 자막 파일(VTT/SRT/ASS/TTML)을 재생 시작 때 통째로 받아서 지금 위치부터 30줄씩 미리 번역해 둠(`PlayerActivity.startSubPrefetch`, 별도 스레드·별도 `FreeTranslator`, 줄 사이 0.12초 간격, 번역 서버가 막으면 멈추고 줄 단위 번역으로 이어감). 번역 기억(`subCache`)은 600 → 4000 줄. `FreeTranslator.post` 는 성공한 연결을 끊지 않아 다음 요청이 같은 연결을 재사용. 영상 안에 들어 있는 자막(파일이 따로 없는 경우)은 미리 받을 수 없어 예전처럼 뜨는 순간 번역
- **컨트롤이 떠 있으면 가운데 더블탭 효과 숨기기 (v2.6.01)**: 내장 플레이어(`PlayerActivity`)와 미러링 플레이어(`MirrorOverlay`)에서 재생/일시정지 버튼이 있는 컨트롤이 보이는 동안 화면 가운데를 더블탭하면, 재생·일시정지는 그대로 되지만 가운데 동그라미 효과(`DoubleTapFx.center`)는 띄우지 않음. 컨트롤이 숨어 있을 때만 효과가 뜸. 좌우 더블탭(10초 이동) 효과는 그대로
- **재생바를 끌 때 막대·손잡이 애니메이션을 부드럽게 (v2.6.02~v2.6.03)**: 새 파일 `SmoothSeek.kt`. 끌기 시작하면 막대가 굵어지고(4→7dp) 손잡이가 톡 커지고(7→13dp, 살짝 넘쳤다 돌아옴), 놓으면 부드럽게 원래대로 돌아옴(`PressAnim`: 누를 때 `OvershootInterpolator`, 뗄 때 `DecelerateInterpolator`). ① 내장 플레이어: `DefaultTimeBar` 대신 직접 만든 `SmoothTimeBar`(미디어 컨트롤의 `TimeBar` 구현, `ev_player_controls.xml` 의 `exo_progress`)를 씀 — 처음 누른 자리로 손잡이가 순간이동하지 않고 0.14초 동안 미끄러져 가고, 손을 떼면 놓은 자리에 머물러 예전 위치로 튕기지 않음 ② 미러링 플레이어: `MirrorSeekBar` 의 굵기·크기 변화가 즉시 바뀌던 것을 같은 애니메이션으로 ③ 메뉴창 미디어 카드: `SmoothSeekTrack`(막대 6→9dp) · `SmoothSeekThumb`(손잡이 14→22dp)를 `mediaSeek` 에 코드로 끼움(손잡이 자리 크기는 14dp 그대로라 누를 때 높이가 출렁이지 않음)
- **재생바 손잡이 둘레의 은은한 빛 없앰 (v2.6.03)**: v2.6.02 에서 끌 때 손잡이 둘레에 퍼지던 옅은 빛(halo)을 내장 플레이어(`SmoothTimeBar`)와 미러링 플레이어(`MirrorSeekBar`)에서 뺌. 막대 굵기·손잡이 크기 애니메이션은 그대로
- **메뉴창 미디어 카드의 이전·10초 뒤로·10초 앞으로·다음 버튼 뒤 동그라미 없앰 (v2.6.04)**: `dialog_menu.xml` 의 `mediaPrev` · `mediaBack` · `mediaFwd` · `mediaNext` 에서 `bg_share_btn` 배경을 뺌. 아이콘만 보이고, 누를 때 살짝 줄어드는 눌림 효과(`Motion.pressable`)는 그대로. 재생/일시정지 버튼의 동그라미는 그대로
- **내장 플레이어·미러링 화면도 가운데를 아래로 밀어 나가기 (v2.6.05)**: 전체화면 영상에 있던 「아래로 밀어 나가기」(`FullscreenSwipeLayout`)를 내장 플레이어(`PlayerActivity`)와 미러링 화면(`MirrorOverlay`)에도 씀. 화면 가운데에서 아래로 밀면 화면이 손가락을 따라 내려오며 작아지고, 충분히(화면 높이의 22%) 또는 빠르게 밀고 놓으면 닫힘(내장 플레이어는 `finish()`, 미러링은 `stopMirror()`), 모자라면 탄성 있게 제자리로 돌아옴. 같은 설정(`swipeDownExit`)으로 한꺼번에 켜고 끔. 진행 막대를 끄는 터치와 겹치지 않게 `FullscreenSwipeLayout.startFilter` 를 새로 넣어 컨트롤이 떠 있을 때 막대 위에서 시작한 터치는 뺌. PiP 중 · 확대 전환 중 · 미러링 자막 패널이 열려 있을 때는 꺼짐
- **미러링에서 아래로 밀어 나갈 때 영상도 같이 내려감 (v2.6.06)**: 미러링은 영상이 컨트롤 UI(`MirrorOverlay`) 뒤쪽 웹뷰 안에 있어서, 예전엔 밀면 컨트롤 UI 만 내려가고 영상은 제자리에 남았음. `FullscreenSwipeLayout` 에 `companions` 를 새로 넣어 미러링에서는 웹뷰 영역(`webContainer` 의 부모)도 컨트롤과 같은 위치·크기·투명도로 움직이게 함(끌기 · 나가기 · 되돌아가기 모두). 미러링을 닫을 때 `removeMirrorOverlay()` 가 `resetTransform()` 으로 웹뷰 영역 변형을 원래대로 돌려 놓음
- **미러링 밀어 내리기: 드러나는 바탕을 검정으로 (v2.6.07)**: v2.6.06 에서 웹뷰 영역이 작아지며 내려가면, 그 뒤의 앱 루트 뷰 배경(`colorSurface`, 밝은 테마에서는 흰색)이 드러나 번쩍였음. `addMirrorOverlay()` 가 미러링 동안만 루트 뷰 배경을 검정으로 바꾸고 `removeMirrorOverlay()` 가 원래 배경으로 되돌림
- **내장 플레이어: 일시정지 중에도 PiP (v2.6.08)**: `PlayerActivity.pipParams()` 의 자동 진입(`setAutoEnterEnabled`, Android 12+)과 `onUserLeaveHint()` (Android 11 이하)가 재생 중일 때만 켜져 있어서, 멈춘 영상은 홈으로 나가도 작은 창이 되지 않았음. 이제 플레이어가 준비돼 있고 닫히는 중이 아니면 멈춰 있어도 들어감. `onStart()` 에서도 `updatePipParams()` 를 불러 멈춘 채 열어도 자동 진입이 켜지게 함
- **미러링: 일시정지 중에도 PiP 버튼 (v2.6.09)**: 미러링 화면의 PiP 버튼(`startPipFromMenu`)은 `pipWanted()` 가 참일 때만 들어가는데, 영상을 멈추면 재생 정보(`mediaFrames`)가 비워져서 거짓이 되어 「재생 중인 동영상이 없어요」 가 떴음. 미러링 중(`mirrorActive`)에는 항상 참으로 둠. (홈으로 나갈 때 자동 진입은 `autoPipWanted()` 가 이미 `mirrorActive` 로 처리하고 있었음)
- **PiP 로 들어간 창이 사라지는 문제 진단 기록 (v2.6.10)**: 새 파일 `PipDiag.kt`. `enterPip()` 로 PiP 를 시작하면 창 종류·작업 번호·미러링 여부·멀티윈도우 여부를 적고, 이어서 `onPictureInPictureModeChanged` · `onPause` · `onStop` · `finish()` / `finishAndRemoveTask()` (부른 곳의 호출 스택 포함) · `onDestroy` 를 기록함. 창이 PiP 도중 파괴됐다면 다음에 앱 화면이 보일 때 「PiP 진단 기록」 창을 한 번 띄워 복사할 수 있게 함. 원인을 찾으면 이 기록 기능은 걷어 낼 것
- **모든 내장 플레이어에 영상 로딩 표시 (v2.6.11)**: 새 파일 `VideoLoadingView.kt` — 재생 버튼을 감싸며 도는 고리(길이가 늘었다 줄었다 하는 호, 앱 강조색). 250ms 안에 끝나는 짧은 끊김에는 나타나지 않고, 터치는 통과함. ① 내장 플레이어(`PlayerActivity`): media3 기본 버퍼링 표시(재생 중일 때만 나왔음)를 끄고 `syncLoading()` 이 처음 불러오는 중(IDLE, 오류 없음)·버퍼링(BUFFERING)·멈춘 채 이동하는 중에도 고리를 켬. 오류 상자가 뜨거나 오류가 나면 끔. ② 미러링(`MirrorOverlay`): 페이지 스크립트(`mrep`)가 `!ended && readyState<3 && (!paused || seeking)` 일 때 `EvMedia.mload()` 로 알려 오면 고리를 켬(바뀔 때만 보냄). `waiting`·`stalled`·`seeking`·`canplay`·`emptied` 이벤트를 더 들어 빨리 반응함
- **영상 로딩 고리 등장·퇴장을 더 자연스럽게 (v2.6.12)**: `VideoLoadingView` — 나타날 때 0.82배 크기·투명에서 시작해 320ms 동안 감속하며 커지고 떠오름(호는 가장 짧은 길이에서 시작해 늘어남), 사라질 때 240ms 동안 가속하며 0.92배로 작아지며 흐려짐. 사라지던 중 다시 로딩이 시작되면 끊김 없이 다시 또렷해짐
- **영상 로딩 고리 회전 애니메이션을 더 자연스럽게 (v2.6.13)**: `VideoLoadingView` — 예전 계산은 한 바퀴가 끝나고 다시 시작할 때 호 길이가 230°→40°로 튀었음. 이제 머리·꼬리가 각자 감속 곡선(`PathInterpolator(0.4,0,0.2,1)`)으로 움직이는 머티리얼식 방식(주기 1333ms, 호가 24°~약 200°로 늘고 줄며 매 주기 290°씩 앞으로 나아감, 고리 전체는 1600ms에 한 바퀴)으로 바꾸고, 시간은 애니메이터 값 대신 흘러간 시간으로 직접 계산해 경계에서 끊기지 않게 함
- **메뉴 미디어 카드: 일시정지 버튼과 10초 이동 버튼 사이 여백 확대 (v2.6.14)**: `dialog_menu.xml` — `mediaPlay` 의 좌우 margin 을 4dp → 16dp 로 늘려 일시정지·10초 뒤로/앞으로 버튼이 덜 붙어 보이게 함
- **유튜브 광고 차단을 광고 차단에서 분리해 별도 설정으로 (v2.6.16)**: 설정 「광고 차단」 묶음에 「유튜브 광고 차단」 토글(`Prefs.ytAdBlock`, 기본 켜짐) 추가. 유튜브 전용 처리(광고 칸 숨김 CSS · 광고 재생 중 16배속·음소거로 끝까지 넘기기 · 오버레이 닫기 클릭)를 `AdBlocker.COSMETIC_START_JS` 에서 `AdBlocker.YT_AD_START_JS` 로 옮겨, 일반 「광고 차단」 켜짐/꺼짐과 무관하게 이 토글만으로 동작하고, 바꾸면 페이지를 새로 불러오지 않아도 0.5초 안에 반영됨. 「유튜브 광고 건너뛰기 자동 클릭」·「다음 영상」 때의 광고 건너뛰기는 그대로
- **영상이 끝나면 '다음 영상' 카드 (v2.6.18)**: 새 `UpNextCard` — 유튜브 미러링에서 영상이 끝나면(`MediaScripts.mNextScan`이 끝 화면 `.ytp-videowall-still`·자동 재생 카드 `.ytp-autonav-endscreen-upnext-*`를 읽어 `EvMedia.mnext`로 전달) 큰 카드(썸네일·제목·채널·길이·자동 재생 카운트다운)와 추천 영상 가로 줄, '다시 보기'·'취소'·'다음 영상' 버튼을 띄움. 항목을 못 읽는 사이트와 일반 내장 플레이어(`PlayerActivity`)는 '다시 보기'·'다음 영상' 버튼만
- **'다음 영상' 카드 디자인 개선 (v2.6.19)**: 첫 영상 썸네일을 흐리게 깐 배경, 둥근 큰 카드(썸네일·제목·채널·길이) + 자동 재생 남은 초 알약("5초 후 자동 재생")·카운트다운 고리, '이어서 볼 영상' 목록(세로 화면은 가로 줄, 가로 화면은 왼쪽 큰 카드 + 오른쪽 세로 목록), 카드·줄 눌림 효과와 순서대로 떠오르는 등장 효과, 회전·분할 화면 때 다시 배치. 고리가 이미 붙어 있다는 오류(두 번째 표시 때)도 막음
- **'다음 영상' 카드 태블릿 화면 개선 (v2.6.20)**: 짧은 변이 600dp 이상이면 글자·카드·버튼을 1.3배, 840dp 이상이면 1.5배로 키움. 세로 화면은 카드 폭 확대, 가로 화면은 큰 카드 + 오른쪽 '이어서 볼 영상'을 두 줄(격자)로 배치
- **유튜브 광고 차단을 켜면 미러링(내장 플레이어)이 로딩만 돌던 문제 보완 (v2.6.21)**: ① 광고를 끝으로 넘기면 광고 영상이 `ended` 가 되는데 이때 '다음 영상' 카드가 떠서 본 영상을 가렸음 → 유튜브 광고 중(`ad-showing`)에는 끝 화면 목록을 보내지 않음(`MediaScripts.ytAdOn`). ② 유튜브가 광고→본 영상으로 넘어가며 `<video>` 를 새로 만들면 표시한 영상(`__ev_pip`)이 사라져 화면이 까맣고 로딩 고리만 남던 것 → 새 영상에 미러링을 다시 붙이고, 못 찾으면 로딩 고리를 걷음(`mrep`). ③ 광고 넘기기(`YT_AD_START_JS`)의 16배속이 본 영상에 남으면 되돌림. **원인은 코드만으로 확정 못 함** — 같은 증상이면 그때 화면(까만지/광고/카드)과 광고 구간에서만 그런지 알려 줄 것
- **유튜브 '사이트 방문' 끝 카드 광고가 안 넘어가던 문제 수정 (v2.6.22)**: 광고 영상이 끝난 뒤 '사이트 방문'·'건너뛰기' 끝 카드만 남는 광고는 영상 길이가 있어서 `YT_AD_START_JS` 가 건너뛰기 버튼을 누르지 않고 끝으로 넘기기만 반복했음. 이제 건너뛰기 버튼이 보이면 광고 상태와 상관없이 누르고(`skipBtn`: 알려진 클래스 + 광고 영역 안 '건너뛰기/Skip' 글자 버튼, 크기·display 로만 판단), 포인터·마우스 이벤트를 차례로 보냄(`tap`). 이미 끝난 영상은 다시 끝으로 보내지 않음
- **유튜브 광고 차단: 영상 없는 광고도 숨김 (v2.6.17)**: `YT_AD_START_JS` — 숨기는 목록을 모바일(`ytm-`·`ad-slot-renderer`)·데스크톱(`ytd-`) 피드 광고 카드, 스폰서·배너·브랜드 영상, 광고 슬롯을 품은 피드 항목(`:has()`), 플레이어 위 이미지/글자/유료 광고 오버레이까지 넓힘. 광고 중인데 영상 길이가 없는 경우(이미지 광고)에는 건너뛰기 버튼을 눌러 봄
- **사진 팝업: 확대 제거 + 사라짐 애니메이션 (v2.5.25)**: 팝업의 사진을 눌러도 전체 화면으로 확대되지 않고 닫히기만 함. 닫힐 때(바깥 터치·뒤로가기·사진 터치) 칩 쪽으로 살짝 작아지며 흐려지는 애니메이션(150ms) 추가
- **사진 칩 항목은 글머리표 제거 (v2.5.24)**: 사진 칩이 붙은 목록 항목은 「•」 없이 칩부터 시작하고 들여쓰기도 맞춤
- **사진 칩 아래 줄에 설명 글 (v2.5.23)**: 사진 칩 뒤에 이어지는 설명 글을 같은 줄이 아니라 칩 아래 줄에서 시작하도록 줄바꿈(목록 안에서는 들여쓰기 유지)
- **AI 사진 바로가기 칩 자연스럽게 (v2.5.22)**: 칩이 글보다 커서 첫 줄이 들뜨고 줄 간격이 벌어지던 것을, 칩을 작게(높이 20dp·썸네일 16dp·글자 11) 하고 글줄 높이를 건드리지 않은 채 글자 가운데 높이에 맞춰 그리도록 수정(`CenteredImageSpan`)
- **AI 사진 바로가기: 버튼 아래 팝업으로 표시 (v2.5.21)**: 「사진 N」 칩을 누르면 전체 화면 대신 그 칩 바로 아래(공간이 모자라면 위)에 사진이 작은 팝업으로 뜸. 사진을 누르면 전체 화면 보기, 바깥을 누르거나 뒤로 가면 닫힘(`showPhotoPopup`)
- **AI 사진 바로가기 UI 개선 (v2.5.20)**: 「🖼 사진 N」 글자 링크 대신, 둥근 사진 썸네일 + 「사진 N」이 들어간 알약 모양 칩(강조색 테두리)으로 표시. 누르면 그 사진을 크게 보여 줌(`photoChipDrawable`)
- **AI 사진 바로가기를 설명하는 글마다 배치 (v2.5.19)**: AI 가 사진을 설명할 때 사진마다 설명 글 맨 앞에 [[사진N]] 표시를 달게 하고, 앱이 그 자리를 「🖼 사진 N」 바로가기로 바꿔 누르면 그 사진을 크게 보여 줌(`ReplyBubble.images`, `photoMarkRe`). 답변 아래의 「사진 보기」 버튼은 AI 가 표시를 달지 않았을 때만 대신 나타남. 답변 복사 시에는 「사진 N」 글자로 바뀜
- **빌드 알림이 Now Bar에 안 뜨던 것 수정 (v2.5.18)**: v2.5.13에서 넣은 colorized(바탕 채움)가 Live Updates 승격 조건(colorized 금지)에 걸려 Now Bar에 올라가지 못했음 → colorized 해제, 강조색(`ev_accent`)만 지정하고 카테고리를 진행(progress)으로 지정
- **새 탭 화면에서 AI 「바로 물어보기」 칩 비활성 (v2.5.17)**: 현재 탭이 새 탭(홈) 화면이면 칩(이 페이지 요약·핵심 3줄·선택한 글 설명·사진 설명)을 흐리게 하고 눌러도 동작 대신 안내 토스트만 표시. 탭 전환·홈↔페이지 전환 때 바로 갱신(`refreshChips`)
- **AI 보내기 버튼 애니메이션 중 잘림 수정 (v2.5.16)**: 보내기 버튼이 눌림·튕김으로 커질 때 입력줄과 패널 안쪽 여백(clipToPadding)에 잘리던 것을 해제
- **AI 어시스턴트 칩 버튼 애니메이션 중 잘림 수정 (v2.5.15)**: 칩 줄(가로 스크롤)이 떠오르는·눌림 튕김 동작의 위아래를 잘라내던 것을, 위아래 여유 칸(8dp, 바깥 여백으로 상쇄)과 clipToPadding/clipChildren 해제로 해결
- **AI 분할 열고 닫을 때 웹 영역이 느리게 변하던 것 개선 (v2.5.14)**: 열림·닫힘 애니메이션 동안 웹 영역 너비를 매 프레임 바꾸던 것(웹뷰가 매번 다시 배치돼 버벅임)을, 시작할 때 한 번에 최종 너비로 바꾸고 패널만 미끄러지게 변경. 애니메이션도 약간 짧게(열기 220/260ms, 닫기 200ms). 패널 너비를 끌어 조절할 때는 기존처럼 실시간
- **Now Bar 배경색 (v2.5.13)**: 빌드 진행을 Now Bar·상태표시줄 칩에 올릴 때 알림 색을 앱 초록(`ev_accent`)으로 칠하고 colorized 로 바탕을 채움
- **AI 분할: 웹 영역 너비를 실시간 반영 + 모바일↔데스크톱 자동 전환 (v2.5.12)**: AI 분할 패널의 너비를 끄는 동안 웹 영역 너비가 바뀔 때마다(약 0.07초 간격) 페이지 뷰포트(데스크톱 사이트 폭·페이지 확대 기준)를 새 폭에 맞춰 다시 배치(`onWebAreaResized`, `webAreaWidthDp`). 분할로 웹 영역이 600dp 미만이 되면 모바일 사이트로, 560dp 이상이 되면 데스크톱 사이트로 자동 전환(0.3초 뒤 확정, 경계에서 깜빡이지 않게 히스테리시스). 분할을 닫으면 창 너비 기준으로 복귀. 직접 누른 모바일/데스크톱 버튼은 다음 전환 전까지 우선
- **AI 「응답이 없어요」 화면 개선 (v2.5.11)**: 빈 답일 때 회색 글자 대신 붉은 오류 말풍선(「AI가 답을 주지 않았어요」)으로 안내하고, 질문을 입력창에 되돌림. 오류·빈 답 말풍선에 「↻ 다시 시도」 버튼 추가(실패한 질문·오류를 치우고 같은 질문을 다시 보냄)
- **「설명한 사진 보기」 버튼 문구 변경 (v2.5.10)**: 「사진 보기」로 바꿈
- **AI 사진 설명: 말풍선 위 사진 제거 (v2.5.09)**: 내 말풍선 위에 사진을 띄우지 않음. 사진은 답변 아래 「사진 보기」 버튼으로만 크게 볼 수 있음
- **AI 사진 설명: 사진 크게 보기 바로가기 (v2.5.08)**: 내 말풍선 위 사진을 누르면 전체 화면으로 보여 줌(여러 장이면 누를 때마다 다음 사진). 사진을 보낸 질문의 답변 아래에도 「설명한 사진 보기」 버튼이 생김
- **AI 어시스턴트가 사진을 설명할 때 그 사진을 보여 줌 (v2.5.07)**: 질문과 함께 AI 에게 보낸 사진을 내 말풍선 위에 보여 줌(한 장이면 크게, 여러 장이면 작게 최대 4장 + 나머지는 +N). 대화를 다시 열어도 유지됨
- **AI 어시스턴트 「핵심 3줄」 아이콘 변경 (v2.5.06)**: 체크 표시 대신 세 줄 목록 아이콘(`ic_lines3`)으로 바꿈
- **탭 화면 창 전환 시 분할 대신 교체 (v2.5.05)**: 탭 화면의 창 목록에서 다른 창(열린 창·닫힌 창)을 누르면 옆에 붙여 분할로 열지 않고, 선택한 창을 연 뒤 지금 창은 닫음(탭은 남아 창 목록에서 다시 열 수 있음). 「＋ 새 창」은 기존처럼 옆에 붙여 열림
- **내장 플레이어 확대 전환 제거 + 닫은 뒤 페이지 영상 다시 그리기 (v2.5.04)**: ① 영상 아래 「내장 플레이어로 열기」(·메뉴·위쪽 바의 내장 플레이어)를 누르면 페이지 영상이 커지며 열리던 전환(`PlayerZoom`)을 쓰지 않고 바로 플레이어를 엶(영상 자리 알림·버튼 숨김·AI 창 사라짐도 함께 없어짐). ② 플레이어를 닫고 돌아오면 웹페이지의 영상이 비어 보이던 것을 고침 — 돌아온 직후와 0.6초 뒤 두 번, 페이지(iframe 포함)의 영상마다 합성 층을 새로 만들고 멈춘 영상은 같은 자리를 다시 찾아 장면을 다시 그리게 함(`MediaScripts.REPAINT`). 미러링의 확대는 그대로
- **확장 프로그램 로그인 (v3.5.7)**: `chrome.identity.launchWebAuthFlow` / `getAuthToken` 지원. 전체 화면 웹뷰 로그인 창(`ExtensionManager.showAuthFlow`)을 띄우고(UA 에서 `; wv` 제거), 주소가 `https://<확장 id>.chromiumapp.org/…` 에 닿으면 그 주소를 확장에 돌려줌. `getAuthToken` 은 manifest `oauth2.client_id`·`scopes` 로 구글 implicit 흐름(`response_type=token`)을 같은 창으로 돌려 토큰을 받음(메모리 캐시). 크롬 앱용 클라이언트는 리디렉션 `https://<id>.chromiumapp.org/` 를 허용하므로 스토어에서 받은 확장(같은 id)이면 동작. 팝업·사이드 패널·백그라운드 웹뷰는 서드파티 쿠키 허용(v3.5.6). 한계: Firebase `signInWithPopup` 처럼 `window.open` + postMessage 로 하는 로그인은 아직 미지원
