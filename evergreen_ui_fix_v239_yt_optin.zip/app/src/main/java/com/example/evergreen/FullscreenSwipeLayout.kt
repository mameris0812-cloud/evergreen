package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * 동영상 전체화면 컨테이너: 화면 가운데에서 아래로 밀면 영상이 손가락을 따라 내려오며 작아지고,
 * 충분히 밀고 놓으면 전체화면을 빠져나간다. 모자라게 밀고 놓으면 탄성 있게 제자리로 돌아간다.
 *
 * 오작동을 줄이려고 아래 조건을 모두 만족할 때만 끼어든다 (그 전에는 페이지가 터치를 그대로 받는다):
 * - 손가락 하나, 시작 위치가 화면 가운데 영역 (위·아래 컨트롤 막대, 왼쪽·오른쪽 밝기/볼륨 구역, 시스템 제스처 가장자리 제외)
 * - 처음부터 분명하게 아래쪽으로 움직임 (가로로 먼저 움직이거나 위로 움직이면 이번 터치는 포기 → 탐색 막대 끌기 등과 겹치지 않음)
 * - 놓을 때 충분히 내려왔거나 빠르게 휙 내렸을 때만 나감. 끌고 있는 도중 다시 위로 올리면 취소됨
 */
class FullscreenSwipeLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    /** 지금 이 제스처를 쓸 수 있는지 (설정이 켜져 있고 전체화면 중일 때) */
    var enabledProvider: () -> Boolean = { false }

    /** 놓았을 때 나가기로 결정되고 나가는 애니메이션이 끝난 뒤 불린다 */
    var onDismiss: () -> Unit = {}

    private val density = resources.displayMetrics.density
    private val slop = maxOf(ViewConfiguration.get(ctx).scaledTouchSlop * 2f, 20f * density)
    private val flingV = 1000f * density
    private val minFlingDist = 48f * density

    private var eligible = false
    private var dragging = false
    private var animating = false
    private var downX = 0f
    private var downY = 0f
    private var armed = false          // 지금 놓으면 나가는 거리에 도달했는지 (햅틱 1회용)
    private var vt: VelocityTracker? = null

    private fun content(): View? = if (childCount > 0) getChildAt(childCount - 1) else null

    /** 영상 위치·크기·투명도를 원래대로 돌린다 (영상 뷰는 다음 전체화면에서 다시 쓰일 수 있다) */
    fun resetTransform() {
        animating = false          // 먼저 내려야 cancel() 이 끝 동작(onDismiss)을 다시 부르지 않는다
        content()?.let {
            it.animate().cancel()
            it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f; it.alpha = 1f
        }
        dragging = false
        eligible = false
        armed = false
        recycle()
    }

    private fun recycle() { vt?.recycle(); vt = null }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (animating) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = false; armed = false
                val w = width.toFloat(); val h = height.toFloat()
                eligible = enabledProvider() && content() != null &&
                    ev.x in (w * 0.25f)..(w * 0.75f) && ev.y in (h * 0.12f)..(h * 0.75f)
                downX = ev.x; downY = ev.y
                recycle()
                if (eligible) { vt = VelocityTracker.obtain(); vt?.addMovement(ev) }
            }
            MotionEvent.ACTION_POINTER_DOWN -> eligible = false          // 두 손가락(확대 등)이면 포기
            MotionEvent.ACTION_MOVE -> {
                if (!eligible) return false
                vt?.addMovement(ev)
                val dx = ev.x - downX; val dy = ev.y - downY
                if (dy < -slop * 0.5f || (abs(dx) > slop && abs(dx) > dy)) { eligible = false; return false }
                if (dy > slop && dy > abs(dx) * 2f) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { eligible = false; recycle() }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (animating) return true
        if (!dragging) {
            // 아래에서 아무도 DOWN 을 받지 않았다면 이후 움직임을 받으려고 여기서 받는다
            return ev.actionMasked == MotionEvent.ACTION_DOWN && enabledProvider()
        }
        vt?.addMovement(ev)
        val v = content() ?: return true
        val h = height.toFloat().coerceAtLeast(1f)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val dy = (ev.y - downY - slop).coerceAtLeast(0f)       // 끼어든 순간부터 따라가서 툭 튀지 않게
                val p = (dy / (h * 0.45f)).coerceIn(0f, 1f)
                v.translationY = dy * 0.85f
                val s = 1f - 0.12f * p
                v.scaleX = s; v.scaleY = s
                v.alpha = 1f - 0.45f * p
                val ready = dy > h * 0.22f
                if (ready != armed) {
                    armed = ready
                    // 놓으면 나가는 거리에 닿거나, 다시 돌아가면 살짝 진동
                    performHapticFeedback(
                        if (ready) {
                            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.KEYBOARD_TAP
                        } else HapticFeedbackConstants.CLOCK_TICK
                    )
                }
            }
            MotionEvent.ACTION_UP -> {
                vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                val dy = (ev.y - downY - slop).coerceAtLeast(0f)
                dragging = false; eligible = false; recycle()
                if (dy > h * 0.22f || (vy > flingV && dy > minFlingDist)) dismiss(v, h) else springBack(v)
            }
            MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> {
                dragging = false; eligible = false; recycle()
                springBack(v)
            }
        }
        return true
    }

    private fun dismiss(v: View, h: Float) {
        animating = true
        v.animate().cancel()
        v.animate()
            .translationY(h * 0.55f).scaleX(0.82f).scaleY(0.82f).alpha(0f)
            .setDuration(190).setInterpolator(AccelerateInterpolator(1.4f))
            .withEndAction {
                if (!animating) return@withEndAction      // 그 사이 다른 경로(뒤로 가기 등)로 이미 닫힌 경우
                animating = false
                onDismiss()
            }
            .start()
    }

    private fun springBack(v: View) {
        armed = false
        v.animate().cancel()
        v.animate()
            .translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(260).setInterpolator(OvershootInterpolator(1.1f))
            .start()
    }
}
