package com.example.evergreen

import android.app.Activity
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.MaterialColors

/**
 * 웹 페이지를 저절로 아래로 스크롤해 주는 기능 (웹툰·긴 글을 손 안 대고 볼 때).
 *
 * - 화면 프레임(Choreographer)마다 지난 시간만큼 계산한 거리를 WebView 에 스크롤한다. 속도는 설정의 「자동 스크롤 속도」.
 * - 화면 아래에 작은 조작 막대(느리게 / 빠르게 / 정지)를 띄운다 (설정에서 끌 수 있음).
 * - 웹 화면을 손가락으로 만지면 설정에 따라 '만지는 동안 잠깐 멈춤' 또는 '완전히 멈춤'.
 * - 다른 탭·탭 화면·전체화면·새 페이지 이동·앱 나가기에서는 저절로 멈춘다.
 * - 페이지 끝에 닿은 채로 잠깐(이미지가 더 불러와질 시간) 지나면 멈춘다.
 */
class AutoScroller(
    private val act: Activity,
    private val prefs: Prefs,
    /** 이 WebView 에서 자동 스크롤을 계속해도 되는 상황인지 (현재 탭인지, 탭 화면·전체화면이 아닌지) */
    private val allowed: (WebView) -> Boolean,
    /** 창 아래에서 띄울 높이(px). 아래 막대가 보이면 그 위, 없으면 0 */
    private val liftProvider: () -> Int,
    private val notify: (String) -> Unit
) {
    companion object {
        const val MIN_LEVEL = 1
        const val MAX_LEVEL = 20
        const val DEFAULT_LEVEL = 6

        /** 단계 → 초당 dp. 1단계 = 25dp/초 (아주 천천히), 20단계 = 500dp/초 */
        fun dpPerSecond(level: Int): Float = 25f * level.coerceIn(MIN_LEVEL, MAX_LEVEL)

        /** 손가락을 떼고 이만큼(ms) 지나서 다시 흐른다 (뗀 뒤 이어지는 관성 스크롤이 가라앉을 시간) */
        private const val RESUME_DELAY_MS = 500L

        /** 끝에 닿은 채 이만큼(ms) 지나면 멈춘다 */
        private const val END_HOLD_MS = 1500L

        private const val PILL_TAG = "evergreen_auto_scroll_pill"
    }

    private val density = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private var target: WebView? = null
    private var running = false
    private var touching = false
    private var resumeAt = 0L
    private var lastNanos = 0L
    private var carry = 0f
    private var endSince = 0L
    private var everMoved = false
    private var frames = 0

    private var pill: View? = null
    private var levelText: TextView? = null

    val isRunning: Boolean get() = running

    fun isRunningOn(wv: WebView?): Boolean = running && wv != null && wv === target

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) = onFrame(frameTimeNanos)
    }

    fun start(wv: WebView) {
        if (running && target === wv) return
        stop(null)
        target = wv
        running = true
        touching = false
        resumeAt = 0L
        lastNanos = 0L
        carry = 0f
        endSince = 0L
        everMoved = false
        frames = 0
        if (prefs.autoScrollControls) showPill()
        notify("자동 스크롤을 시작했어요")
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    /** 설정에서 조작 막대를 켜거나 껐을 때: 흐르는 중이면 막대만 바로 보이거나 치운다 (스크롤은 그대로) */
    fun applyControlsSetting() {
        if (!running) return
        if (prefs.autoScrollControls) { if (pill == null) showPill() } else removePill()
    }

    /** 멈춘다. [message] 가 있으면 안내를 띄운다 */
    fun stop(message: String?) {
        val was = running
        running = false
        target = null
        touching = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        removePill()
        if (was && message != null) notify(message)
    }

    private fun onFrame(nanos: Long) {
        val wv = target
        if (!running || wv == null) return
        if (act.isFinishing || act.isDestroyed || !wv.isAttachedToWindow || !allowed(wv)) {
            stop(null)
            return
        }
        val dt = if (lastNanos == 0L) 0f else ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNanos = nanos

        val now = SystemClock.uptimeMillis()
        if (!touching && now >= resumeAt) {
            carry += dpPerSecond(prefs.autoScrollSpeed) * density * dt
            val dy = carry.toInt()
            if (dy > 0) {
                carry -= dy
                val before = wv.scrollY
                wv.scrollBy(0, dy)
                if (wv.scrollY != before) {
                    everMoved = true
                    endSince = 0L
                } else {
                    // 더 못 내려간다: 이미지가 더 불러와질 수 있으니 잠깐 기다려 본다
                    if (endSince == 0L) endSince = now
                    else if (now - endSince >= END_HOLD_MS) {
                        stop(if (everMoved) "페이지 끝에 닿아 자동 스크롤을 멈췄어요" else "이 페이지는 자동으로 스크롤할 수 없어요")
                        return
                    }
                }
            }
        }
        // 아래 막대가 나타나고 사라지는 만큼 조작 막대 높이를 맞춘다
        if (++frames % 15 == 0) placePill()
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    /** 액티비티의 dispatchTouchEvent 에서 모든 터치를 넘겨 받는다 (조작 막대 위의 터치는 건드리지 않는다) */
    fun onTouch(ev: MotionEvent) {
        if (!running) return
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (hitPill(ev) || !hitWeb(ev)) return
                if (prefs.autoScrollTouch == 1) stop("자동 스크롤을 멈췄어요") else touching = true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (touching) {
                    touching = false
                    resumeAt = SystemClock.uptimeMillis() + RESUME_DELAY_MS
                    lastNanos = 0L
                    carry = 0f
                }
            }
        }
    }

    private fun hitPill(ev: MotionEvent): Boolean {
        val p = pill ?: return false
        val r = Rect()
        if (!p.getGlobalVisibleRect(r)) return false
        return r.contains(ev.rawX.toInt(), ev.rawY.toInt())
    }

    private fun hitWeb(ev: MotionEvent): Boolean {
        val w = target ?: return false
        val r = Rect()
        if (!w.getGlobalVisibleRect(r)) return false
        return r.contains(ev.rawX.toInt(), ev.rawY.toInt())
    }

    // ───────────────────────── 조작 막대 ─────────────────────────

    private fun root(): ViewGroup? = act.window?.decorView as? ViewGroup

    private fun showPill() {
        val root = root() ?: return
        removePill()
        val fg = MaterialColors.getColor(root, com.google.android.material.R.attr.colorOnSurface, 0xFF202020.toInt())
        val surface = MaterialColors.getColor(root, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFFEEEEEE.toInt())
        val outline = MaterialColors.getColor(root, com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt())
        val accent = MaterialColors.getColor(root, com.google.android.material.R.attr.colorPrimary, 0xFF2E9E5B.toInt())

        fun glyph(label: String, desc: String, onClick: () -> Unit) = TextView(act).apply {
            text = label
            textSize = 22f
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(fg)
            contentDescription = desc
            isClickable = true
            isFocusable = true
            val ripple = android.util.TypedValue()
            act.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ripple, true)
            if (ripple.resourceId != 0) setBackgroundResource(ripple.resourceId)
            setOnClickListener { onClick() }
        }

        val slower = glyph("−", "느리게") { changeLevel(-1) }
        val faster = glyph("+", "빠르게") { changeLevel(+1) }
        val lv = TextView(act).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(accent)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            minWidth = dp(54)
        }
        levelText = lv
        val stopBtn = ImageView(act).apply {
            setImageResource(R.drawable.ic_pause)
            setColorFilter(fg)
            contentDescription = "자동 스크롤 멈추기"
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(9), dp(9), dp(9), dp(9))
            isClickable = true
            isFocusable = true
            val ripple = android.util.TypedValue()
            act.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ripple, true)
            if (ripple.resourceId != 0) setBackgroundResource(ripple.resourceId)
            setOnClickListener { stop("자동 스크롤을 멈췄어요") }
        }
        val divider = View(act).apply { setBackgroundColor(ColorUtils.setAlphaComponent(outline, 0xB0)) }

        val bar = LinearLayout(act).apply {
            tag = PILL_TAG
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(ColorUtils.setAlphaComponent(surface, 0xF2))
                setStroke(dp(1), ColorUtils.setAlphaComponent(outline, 0x99))
            }
            addView(slower, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)))
            addView(faster, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(divider, LinearLayout.LayoutParams(dp(1), dp(22)).apply { marginStart = dp(4); marginEnd = dp(4) })
            addView(stopBtn, LinearLayout.LayoutParams(dp(40), dp(40)))
            // 앱 알림(토스트·진행 카드)보다는 아래, 일반 화면보다는 위
            AppToast.raiseToTop(this, dp(AppToast.CARD_Z_DP - 20))
        }
        pill = bar
        refreshLevelText()
        root.addView(bar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ))
        placePill()
        bar.bringToFront()
        if (Motion.enabled(act)) {
            bar.alpha = 0f
            bar.translationY = dp(12).toFloat()
            bar.animate().alpha(1f).translationY(0f).setDuration(180).start()
        }
    }

    private fun placePill() {
        val p = pill ?: return
        val root = root() ?: return
        val lp = p.layoutParams as? FrameLayout.LayoutParams ?: return
        val bottomInset = ViewCompat.getRootWindowInsets(root)
            ?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val lift = liftProvider()
        val m = (if (lift > 0) lift + dp(8) else bottomInset + dp(24))
        if (lp.bottomMargin != m) {
            lp.bottomMargin = m
            p.layoutParams = lp
        }
    }

    private fun removePill() {
        val p = pill ?: return
        pill = null
        levelText = null
        p.animate().cancel()
        (p.parent as? ViewGroup)?.removeView(p)
    }

    private fun changeLevel(delta: Int) {
        val next = (prefs.autoScrollSpeed + delta).coerceIn(MIN_LEVEL, MAX_LEVEL)
        if (next == prefs.autoScrollSpeed) return
        prefs.autoScrollSpeed = next
        refreshLevelText()
    }

    private fun refreshLevelText() {
        levelText?.text = "속도 ${prefs.autoScrollSpeed}"
    }
}
