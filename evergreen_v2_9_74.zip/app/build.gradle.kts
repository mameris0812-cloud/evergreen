plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.evergreen"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.evergreen"
        minSdk = 24
        targetSdk = 35
        // 날짜 기반(yyMMddHH): 항상 이전 빌드보다 커야 덮어쓰기가 되고, 낮추면 "패키지가 잘못되어" 로 설치가 막힌다
        versionCode = 26131122
        versionName = "2.9.74"

        // 앱 안 업데이트가 확인할 GitHub 저장소 ("소유자/이름"). -PupdateRepo=... 로 바꿀 수 있다.
        // 워크플로가 안 넘겨 주면 아래 기본 저장소를 쓴다
        val updateRepo = (project.findProperty("updateRepo") as String?)?.takeIf { it.isNotBlank() } ?: "mameris0812-cloud/evergreen"
        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")
    }

    // 매번 같은 키로 서명해서, 지우고 다시 깔지 않고 덮어써서 업데이트할 수 있게 한다.
    // (GitHub Actions 는 실행할 때마다 새 임시 키를 만들어서 "패키지 충돌"이 났었다)
    signingConfigs {
        create("fixed") {
            storeFile = file("evergreen.keystore")
            storePassword = "evergreen123"
            keyAlias = "evergreen"
            keyPassword = "evergreen123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            signingConfig = signingConfigs.getByName("fixed")
            // R8 로 코드·리소스를 줄이고 최적화해 설치 크기와 시작 속도를 개선한다
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    // 릴리스 빌드에서 린트 검사로 빌드가 멈추지 않게 한다 (APK 만드는 데 필요한 검사가 아님)
    lint {
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    implementation("androidx.media3:media3-exoplayer-smoothstreaming:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.3.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
