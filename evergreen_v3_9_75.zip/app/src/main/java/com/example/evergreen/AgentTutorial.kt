package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.graphics.ColorUtils

/**
 * 'AI 에이전트 사용법' 튜토리얼.
 *
 * 화면의 버튼을 짚어 주는 [Tutorial] 의 스포트라이트와 달리, AI 창은 따로 뜨는 창이라 그 위를 짚을 수 없다.
 * 그래서 다섯 쪽짜리 안내 카드로 보여 준다: 쪽마다 실제 AI 창의 진행 카드 · 확인 카드 · 계획 · 되돌리기 모양을
 * 그림(뷰로 그린 모형)으로 보여 주고, 두 번째 쪽의 예시 말은 눌러 보면 AI 창이 그 말을 채운 채 열린다.
 *
 * 열 때: 설정 > 둘러보기 다시 보기 > 'AI 에이전트 사용법', AI 설정의 'AI 에이전트 사용법 ›',
 * 업데이트 뒤 '새 기능을 둘러볼까요?' 의 'AI 에이전트 배우기'.
 */
object AgentTutorial {

    /** 쪽마다 쓰는 색. 테마가 켜져 있으면 테마 색을 따른다 */
    private class Pal(ctx: Context) {
        val surface: Int = ThemeColors.get(ctx, com.google.android.material.R.attr.colorSurface, Color.WHITE) or 0xFF000000.toInt()
        val fg: Int = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF202124.toInt())
        val dim: Int = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF73777F.toInt())
        val primary: Int = ThemeColors.get(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF2FA35B.toInt())
        val onPrimary: Int = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnPrimary, Color.WHITE)
        val edge: Int = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt())
        val bad: Int = 0xFFD93025.toInt()

        /** 그림을 담는 판: 바탕에 주색을 아주 옅게 얹은 색 */
        val panel: Int = ColorUtils.compositeColors(ColorUtils.setAlphaComponent(primary, 0x14), surface)

        /** 판 안의 카드: 바탕색 그대로 + 얇은 테두리 */
        val card: Int = surface
    }

    private class Page(
        val title: String,
        val body: String,
        /** 그림. onPick 은 예시 말을 눌렀을 때(두 번째 쪽) 부른다 */
        val art: (Context, Pal, (String) -> Unit) -> View
    )

    private val EXAMPLES = listOf(
        "열려 있는 탭 알려 줘",
        "다크 모드 켜 줘",
        "이 페이지 북마크에 추가해 줘",
        "오늘 서울 날씨 검색해서 알려 줘"
    )

    private val PAGES: List<Page> = listOf(
        Page(
            "AI가 앱을 직접 움직여요",
            "대화만 하던 AI가 이제 탭을 보고, 설정을 바꾸고, 웹을 검색해요. 말로 시키면 하나씩 실행하고, 결과를 보면서 이어서 처리해요."
        ) { c, p, _ -> artIntro(c, p) },
        Page(
            "이렇게 말해 보세요",
            "탭 · 설정 · 북마크 · 검색처럼 앱 기능이 필요한 말이면 에이전트가 일해요. 인사나 잡담은 평소처럼 대화로만 답해요. 아래 말을 눌러 보세요."
        ) { c, p, pick -> artExamples(c, p, pick) },
        Page(
            "바꾸기 전에 먼저 물어봐요",
            "앱을 바꾸는 일은 실행 전에 확인 카드로 허락을 받아요. 한 번 허락하면 그 요청이 끝날 때까지는 다시 묻지 않고, 파일 다운로드는 그때마다 물어요. 시크릿 탭은 기본으로 보지 않아요."
        ) { c, p, _ -> artConfirm(c, p) },
        Page(
            "알아서 해 줘 · 자율 모드",
            "「알아서」「끝까지」「스스로」「목표」 같은 말로 맡기면 AI가 계획을 세워 보여 줘요. 허락하면 실행하고, 결과가 맞는지 확인하는 것까지 이어가요. 막히면 선택지로 물어봐요."
        ) { c, p, _ -> artPlan(c, p) },
        Page(
            "마음에 안 들면 되돌리기",
            "일이 끝난 뒤(중지했을 때도) 「되돌리기」를 누르면 열었던 탭 닫기, 닫은 탭 다시 열기, 바꾼 설정 원래대로, 추가한 북마크 지우기를 해 줘요. 다운로드·새로고침은 되돌릴 수 없어요. AI 설정의 「에이전트 실행 기록」에서 AI가 한 일을 볼 수 있어요."
        ) { c, p, _ -> artUndo(c, p) }
    )

    /**
     * 튜토리얼을 연다.
     * [openAi] 는 '해 보기' 로 AI 창을 열 때 부른다. 인자는 입력창에 미리 채울 말(없으면 null).
     */
    fun show(act: Activity, openAi: (String?) -> Unit) {
        if (act.isFinishing || act.isDestroyed) return
        val p = Pal(act)
        fun dp(v: Int): Int = (v * act.resources.displayMetrics.density).toInt()

        var index = 0
        var dialog: AlertDialog? = null

        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(10))
        }

        // 머리글: 이름 + n / 5
        val stepText = TextView(act).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(p.dim)
        }
        val header = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(act).apply {
                text = "AI 에이전트 사용법"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(p.primary)
                typeface = Typeface.DEFAULT_BOLD
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(stepText)
        }
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(14) })

        // 쪽이 바뀌어도 높이가 들쭉날쭉하지 않게 가장 큰 쪽에 맞춰 둔다
        val host = FrameLayout(act).apply { minimumHeight = dp(330) }
        root.addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // 점 표시
        val dots = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        root.addView(dots, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6); bottomMargin = dp(8) })

        // 아래 단추: 이전 · 다음(마지막 쪽은 'AI 열어 보기')
        val prevBtn = pill(act, p, "이전", filled = false) { }
        val nextBtn = pill(act, p, "다음", filled = true) { }
        val nav = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(prevBtn)
            addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
            addView(nextBtn)
        }
        root.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun buildPage(i: Int): View {
            val page = PAGES[i]
            val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            val art = page.art(act, p) { text ->
                dialog?.dismiss()
                openAi(text)
            }
            col.addView(art, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(18) })
            col.addView(TextView(act).apply {
                text = page.title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                setTextColor(p.fg)
                typeface = Typeface.DEFAULT_BOLD
            })
            col.addView(TextView(act).apply {
                text = page.body
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(p.dim)
                setLineSpacing(0f, 1.25f)
                setPadding(0, dp(8), 0, dp(4))
            })
            // 그림 속 줄이 차례로 나타나게
            if (art is ViewGroup) {
                for (k in 0 until art.childCount) {
                    val v = art.getChildAt(k)
                    v.alpha = 0f
                    v.translationY = dp(8).toFloat()
                    v.animate().alpha(1f).translationY(0f).setDuration(220).setStartDelay(120L + 80L * k).start()
                }
            }
            return col
        }

        fun refreshChrome() {
            stepText.text = "${index + 1} / ${PAGES.size}"
            prevBtn.visibility = if (index == 0) View.INVISIBLE else View.VISIBLE
            nextBtn.text = if (index == PAGES.size - 1) "AI 열어 보기" else "다음"
            dots.removeAllViews()
            for (k in PAGES.indices) {
                val on = k == index
                dots.addView(View(act).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(4).toFloat()
                        setColor(if (on) p.primary else ColorUtils.setAlphaComponent(p.dim, 0x55))
                    }
                }, LinearLayout.LayoutParams(if (on) dp(16) else dp(6), dp(6)).apply {
                    marginStart = dp(3); marginEnd = dp(3)
                })
            }
        }

        fun go(to: Int) {
            if (to < 0 || to >= PAGES.size || to == index) return
            val forward = to > index
            val old = host.getChildAt(0)
            index = to
            refreshChrome()
            val fresh = buildPage(to)
            val shift = dp(28).toFloat() * (if (forward) 1 else -1)
            host.addView(fresh, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            fresh.alpha = 0f
            fresh.translationX = shift
            fresh.animate().alpha(1f).translationX(0f).setDuration(220).start()
            old?.animate()?.alpha(0f)?.translationX(-shift)?.setDuration(160)?.withEndAction { host.removeView(old) }?.start()
        }

        prevBtn.setOnClickListener { go(index - 1) }
        nextBtn.setOnClickListener {
            if (index == PAGES.size - 1) {
                dialog?.dismiss()
                openAi(null)
            } else go(index + 1)
        }

        host.addView(buildPage(0), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        refreshChrome()

        val d = ThemedDialogBuilder(act)
            .setView(root)
            .setNegativeButton("닫기", null)
            .create()
        dialog = d
        d.show()
    }

    // ───────────────────────── 그림 (뷰로 그린 모형) ─────────────────────────

    private fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    /** 그림을 담는 둥근 판. 자식이 곧 '줄'이라서 쪽이 열릴 때 하나씩 나타난다 */
    private fun panel(c: Context, p: Pal): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14))
        background = GradientDrawable().apply { setColor(p.panel); cornerRadius = dp(c, 20).toFloat() }
    }

    /** 판 안의 카드(테두리 있는 둥근 상자) */
    private fun card(c: Context, p: Pal): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        background = GradientDrawable().apply {
            setColor(p.card); cornerRadius = dp(c, 16).toFloat(); setStroke(dp(c, 1), p.edge)
        }
    }

    private fun text(c: Context, s: String, color: Int, sp: Float, bold: Boolean = false): TextView = TextView(c).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    /** 내가 보낸 말풍선 (오른쪽) */
    private fun userBubble(c: Context, p: Pal, s: String): View = LinearLayout(c).apply {
        gravity = Gravity.END
        addView(TextView(c).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(p.onPrimary)
            setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9))
            background = GradientDrawable().apply { setColor(p.primary); cornerRadius = dp(c, 18).toFloat() }
        })
    }

    /** 진행 카드 한 줄: 표시 + 글 */
    private fun stepRow(c: Context, mark: String, markColor: Int, s: String, color: Int, bold: Boolean = false): View = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(c, 3), 0, dp(c, 3))
        addView(text(c, mark, markColor, 14f, true), LinearLayout.LayoutParams(dp(c, 22), ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(text(c, s, color, 13f, bold))
    }

    /**
     * 세로 간격. 높이를 레이아웃 속성으로 못 박는다: 글자 없는 View 는 WRAP_CONTENT 면 남은 높이를 전부 차지해서
     * (minimumHeight 는 무시된다) 그림 아래 제목·설명·단추가 화면 밖으로 밀려났다.
     */
    private fun gap(c: Context, h: Int): View = View(c).apply {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, h))
    }

    private fun artIntro(c: Context, p: Pal): View = panel(c, p).apply {
        addView(userBubble(c, p, "열려 있는 탭 정리해 줘"))
        addView(gap(c, 10))
        addView(card(c, p).apply {
            addView(text(c, "작업 중…", p.dim, 12f))
            addView(gap(c, 4))
            addView(stepRow(c, "✓", p.primary, "열린 탭 목록 보기", p.fg))
            addView(stepRow(c, "✓", p.primary, "같은 주소 탭 2개 닫기", p.fg))
            addView(stepRow(c, "●", p.dim, "결과 확인하는 중", p.dim))
        })
    }

    private fun artExamples(c: Context, p: Pal, pick: (String) -> Unit): View = panel(c, p).apply {
        for ((i, e) in EXAMPLES.withIndex()) {
            addView(TextView(c).apply {
                text = "「$e」"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(p.fg)
                setPadding(dp(c, 14), dp(c, 11), dp(c, 14), dp(c, 11))
                background = GradientDrawable().apply {
                    setColor(p.card); cornerRadius = dp(c, 16).toFloat(); setStroke(dp(c, 1), p.edge)
                }
                isClickable = true
                setOnClickListener { pick(e) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) topMargin = dp(c, 8)
            })
        }
    }

    private fun artConfirm(c: Context, p: Pal): View = panel(c, p).apply {
        addView(card(c, p).apply {
            addView(text(c, "AI가 앱을 조작하려고 해요", p.primary, 12f, true))
            addView(gap(c, 6))
            addView(text(c, "다크 모드 켜기", p.fg, 15f))
            addView(gap(c, 12))
            addView(LinearLayout(c).apply {
                gravity = Gravity.END
                addView(pill(c, p, "거절", filled = false) { })
                addView(pill(c, p, "허락", filled = true) { }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(c, 8) })
            })
        })
        addView(gap(c, 10))
        addView(card(c, p).apply {
            addView(text(c, "⚠ 이 작업을 해도 될까요?", p.bad, 12f, true))
            addView(gap(c, 6))
            addView(text(c, "파일 내려받기 · 항상 물어요", p.fg, 15f))
        })
    }

    private fun artPlan(c: Context, p: Pal): View = panel(c, p).apply {
        addView(userBubble(c, p, "탭 알아서 정리해 줘"))
        addView(gap(c, 10))
        addView(card(c, p).apply {
            addView(text(c, "계획", p.dim, 12f))
            addView(gap(c, 4))
            addView(stepRow(c, "✓", p.primary, "1. 열린 탭 확인", p.fg))
            addView(stepRow(c, "✓", p.primary, "2. 같은 주소 탭 닫기", p.fg))
            addView(stepRow(c, "○", p.dim, "3. 남은 탭 확인", p.dim))
        })
        addView(gap(c, 10))
        addView(card(c, p).apply {
            addView(text(c, "AI가 물어봐요", p.primary, 12f, true))
            addView(gap(c, 4))
            addView(text(c, "읽던 탭은 남겨 둘까요?", p.fg, 14f))
        })
    }

    private fun artUndo(c: Context, p: Pal): View = panel(c, p).apply {
        addView(card(c, p).apply {
            addView(stepRow(c, "✓", p.primary, "같은 주소 탭 2개 닫기", p.fg))
            addView(stepRow(c, "✓", p.primary, "다크 모드 켜기", p.fg))
            addView(stepRow(c, "✓", p.primary, "북마크에 추가", p.fg))
            addView(gap(c, 8))
            addView(text(c, "↶ 한 일 되돌리기 (3)", p.primary, 14f, true))
        })
        addView(gap(c, 10))
        addView(card(c, p).apply {
            addView(text(c, "↶ 3건 되돌렸어요", p.dim, 13f))
        })
    }

    /** 알약 단추. 채운 것(주색)과 글자만 있는 것 */
    private fun pill(c: Context, p: Pal, label: String, filled: Boolean, onClick: () -> Unit): TextView = TextView(c).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        gravity = Gravity.CENTER
        setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8))
        minHeight = dp(c, 36)
        if (filled) {
            setTextColor(p.onPrimary)
            background = GradientDrawable().apply { setColor(p.primary); cornerRadius = dp(c, 18).toFloat() }
        } else {
            setTextColor(p.dim)
        }
        isClickable = true
        setOnClickListener { onClick() }
    }
}
