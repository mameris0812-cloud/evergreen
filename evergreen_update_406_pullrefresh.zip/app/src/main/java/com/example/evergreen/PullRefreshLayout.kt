package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.core.graphics.PathParser
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 아래로 당겨 새로고침.
 * - 페이지(자식 WebView)가 손가락을 따라 고무줄처럼 내려오고, 그 빈자리에 나뭇잎(앱 아이콘의 잎)이 나타난다.
 * - 당기는 동안 나뭇잎이 비스듬히 누웠다가 일어서고, 아래에서부터 초록색으로 차오른다. 다 차면(기준선) 햅틱과 함께 톡 튄다.
 * - 놓으면 스프링으로 자리를 잡고, 나뭇잎이 세로축을 따라 팽그르르 돈다.
 * - 로딩이 끝나면 앞면으로 멈추며 작은 잎들이 흩날린 뒤 부드럽게 올라간다.
 */
class PullRefreshLayout @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    /** 자식(웹페이지)이 위로 더 스크롤될 수 있으면 true → 당기기 비활성 */
    var canChildScrollUp: () -> Boolean = { false }
    var onRefresh: (() -> Unit)? = null

    /** true 이면 이번 제스처로는 당겨서 새로고침을 하지 않는다 (예: 핀치로 확대된 상태) */
    var isPullBlocked: () -> Boolean = { false }

    /** 페이지 안쪽 요소가 이미 스크롤되어 있거나 스크롤 중이면 true (JS 가 알려 준다). 손가락이 닿을 때마다 false 로 초기화 */
    @Volatile var innerScrolled = false

    /** 자식(NestedWebView)의 세로 스크롤을 먼저 받아 쓰는 쪽. dy 를 받아 실제로 쓴 양을 돌려준다. */
    var onNestedStart: (() -> Unit)? = null
    var onNestedPreScrollDy: ((Int) -> Int)? = null
    var onNestedStop: (() -> Unit)? = null

    var isRefreshing = false
        private set

    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val maxPull = 200f * d
    private val trigger = 96f * d
    private val hold = 56f * d
    /** 나뭇잎 높이 (그림 좌표로는 584) */
    private val leafH = 32f * d

    private var offset = 0f
    private var armed = false
    private var dragging = false
    private var pointerId = -1
    /** 손가락을 대는 순간 페이지가 이미 맨 위였는지. 아니면 이번 터치로는 새로고침하지 않는다 (맨 위로 올라가려고 끌어내린 동작과 구분) */
    private var downAtTop = false
    /** 이번 제스처(DOWN~UP) 중 손가락이 둘 이상이었던 적이 있는지. 한 번이라도 있었으면 UP/CANCEL 까지 새로고침 불가 */
    private var sawMultiTouch = false
    /** 마지막으로 멀티터치가 끝난 시각. 핀치 직후 곧바로 이어지는 끌어내림은 무시한다 */
    private var multiTouchEndedAt = 0L
    private val pinchCooldownMs = 450L
    /** 새로고침으로 인정하려면 처음 방향이 거의 수직이어야 하고, 이만큼은 연속으로 내려와야 한다 */
    private val minStartDy get() = slop * 2f
    private var downX = 0f
    private var downY = 0f
    private var startY = 0f
    private var refreshStartedAt = 0L

    private var spinT = 0f            // 도는 동안 0~1 (1.2초에 한 바퀴)
    private var spinner: ValueAnimator? = null
    private var spring: SpringAnimation? = null

    /** 완료 연출 0→1: 나뭇잎이 앞면으로 멈추고 작은 잎이 흩날린다. finishing 은 연출이 시작된 뒤 완전히 닫힐 때까지 true */
    private var done = 0f
    private var finishing = false
    /** 기준선을 넘거나 완료되는 순간 표시기가 톡 튀는 정도 0→1 (1 이면 끝난 상태) */
    private var pop = 1f
    private var doneAnim: ValueAnimator? = null
    /** 완료 연출 동안 잎이 멈추지 않고 앞면이 될 때까지 마저 도는 각도: 시작 각도, 더 돌 각도, 연출 길이 */
    private var finishAng0 = 0f
    private var finishRemain = 0f
    private var finishMs = 300L
    private val popRunnable = Runnable { if (finishing) playPop() }
    private var popAnim: ValueAnimator? = null
    private val closeRunnable = Runnable {
        if (!finishing) return@Runnable
        isRefreshing = false
        animateTo(0f, 260f, 0.92f)
    }

    private val gapPaint = Paint().apply { color = ContextCompat.getColor(ctx, R.color.ev_bg) }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22000000 }
    private val accent = ContextCompat.getColor(ctx, R.color.ev_accent)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    // 나뭇잎: 앱 아이콘의 잎 모양 (그림 좌표 기준, 가로 387~902 · 세로 337~921, 중심 640,629)
    private val leafPath = PathParser.createPathFromPathData("M888,337C898,405 902,470 889,545C876,620 858,665 838,690C815,730 790,765 750,795C700,835 630,840 570,850C510,860 465,885 435,921C436,880 452,835 480,775C540,650 650,570 772,510C640,540 480,600 432,793C395,745 385,700 387,660C390,560 460,480 560,435C660,390 790,395 888,337Z") ?: Path()
    private val leafPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        shader = LinearGradient(
            860f, 337f, 430f, 921f,
            intArrayOf(Color.parseColor("#7DF695"), Color.parseColor("#34D37F"), Color.parseColor("#09975D"), Color.parseColor("#06B56A")),
            floatArrayOf(0f, 0.32f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
    }
    /** 아직 차오르지 않은 부분의 옅은 바탕 */
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = accent }
    /** 흩날리는 작은 잎 */
    private val bitA = PathParser.createPathFromPathData("M0 0C-1-7 4-12 11-12C11-5 6 1 0 0Z") ?: Path()
    private val bitB = PathParser.createPathFromPathData("M0 0C-1-6 3-10 9-10C9-4 5 1 0 0Z") ?: Path()
    private val burstAngles = floatArrayOf(-35f, 35f, 145f, 215f, 270f)

    private val offsetProp = object : FloatPropertyCompat<PullRefreshLayout>("pullOffset") {
        override fun getValue(o: PullRefreshLayout) = o.offset
        override fun setValue(o: PullRefreshLayout, v: Float) = o.applyOffset(v)
    }

    init {
        setWillNotDraw(false)
    }

    // ───────────────────────── 상태 ─────────────────────────

    /** 새로고침이 끝났을 때 부르면 표시기가 너무 빨리 사라지지 않게 잠깐 두었다가 올라간다. */
    fun endRefresh() {
        if (!isRefreshing || finishing) return
        val wait = 550L - (System.currentTimeMillis() - refreshStartedAt)
        if (wait > 0) { postDelayed({ endRefresh() }, wait); return }
        // 앞면으로 멈추고 작은 잎이 흩날리는 동안 잠깐 보여 준 뒤 올라간다
        finishing = true
        // 도는 잎을 갑자기 세우지 않고, 지금 각도에서 앞면이 될 때까지 감속하며 마저 돈다 (뒷면이었으면 그만큼 더 돈다)
        spinner?.cancel()
        spinner = null
        val remainFrac = if (spinT < 0.02f) 0f else 1f - spinT
        finishAng0 = 2f * PI.toFloat() * spinT
        finishRemain = 2f * PI.toFloat() * remainFrac
        finishMs = (300L + 280L * remainFrac).toLong()
        doneAnim?.cancel()
        doneAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = finishMs
            interpolator = LinearInterpolator()
            addUpdateListener { done = it.animatedValue as Float; invalidate() }
            start()
        }
        // 앞면으로 내려앉는 순간에 톡 튀고, 그 직후 작은 잎이 흩날린다
        postDelayed(popRunnable, (finishMs * 0.55f).toLong())
        postDelayed(closeRunnable, maxOf(240L, finishMs - 40L))
    }

    /** 탭을 바꾸는 등 즉시 원래 상태로 되돌릴 때 */
    fun reset() {
        spring?.cancel()
        popAnim?.cancel()
        pop = 1f
        stopSpinner()
        isRefreshing = false
        dragging = false
        armed = false
        applyOffset(0f)
    }

    // ───────────────────────── 중첩 스크롤 (메뉴바 숨김용) ─────────────────────────

    override fun onStartNestedScroll(child: View, target: View, nestedScrollAxes: Int): Boolean {
        val accept = onNestedPreScrollDy != null && (nestedScrollAxes and View.SCROLL_AXIS_VERTICAL) != 0
        if (accept) onNestedStart?.invoke()
        return accept
    }

    override fun onNestedPreScroll(target: View, dx: Int, dy: Int, consumed: IntArray) {
        consumed[1] = onNestedPreScrollDy?.invoke(dy) ?: 0
    }

    override fun onStopNestedScroll(child: View) {
        super.onStopNestedScroll(child)
        onNestedStop?.invoke()
    }

    override fun onViewRemoved(child: View) {
        super.onViewRemoved(child)
        child.translationY = 0f
    }

    override fun onViewAdded(child: View) {
        super.onViewAdded(child)
        child.translationY = offset
    }

    override fun onDetachedFromWindow() {
        spring?.cancel()
        popAnim?.cancel()
        stopSpinner()
        super.onDetachedFromWindow()
    }

    // ───────────────────────── 터치 ─────────────────────────

    /** 진행 중이던 끌어내림을 즉시 취소하고 원위치로 되돌린다 (새로고침은 하지 않는다) */
    private fun cancelPull() {
        if (dragging || offset > 0f) {
            dragging = false
            armed = false
            if (!isRefreshing) animateTo(0f, 300f, 0.9f)
        }
        dragging = false
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerId = ev.getPointerId(0)
                downX = ev.x
                downY = ev.y
                dragging = false
                sawMultiTouch = false
                innerScrolled = false
                downAtTop = !canChildScrollUp() && !isPullBlocked() &&
                    System.currentTimeMillis() - multiTouchEndedAt > pinchCooldownMs
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // 두 번째 손가락: 핀치 줌 등. 이번 제스처는 끝날 때까지 새로고침으로 쓰지 않는다.
                sawMultiTouch = true
                downAtTop = false
                if (dragging) cancelPull()
                return false
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // 손가락 하나가 떨어져도 남은 손가락의 좌표 기준은 이미 낡았으므로 이번 제스처는 계속 무효
                sawMultiTouch = true
                downAtTop = false
                multiTouchEndedAt = System.currentTimeMillis()
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                val i = ev.findPointerIndex(pointerId)
                if (i < 0 || !isEnabled || isRefreshing) return false
                // 손가락이 둘 이상이거나, 이번 제스처에서 한 번이라도 둘 이상이었으면 새로고침 끌어내리기가 아니다
                if (ev.pointerCount > 1 || sawMultiTouch) {
                    sawMultiTouch = true
                    downAtTop = false
                    if (dragging) cancelPull()
                    return false
                }
                // 맨 위가 아닌 상태에서 시작한 끌어내리기는 '위로 스크롤'이다: 도중에 맨 위에 닿아도 새로고침으로 바꾸지 않는다.
                // 새로고침은 맨 위에 멈춘 페이지를 새로 당겨야만 된다.
                if (!downAtTop) return false
                // 페이지 안쪽 스크롤 영역을 만지고 있다면 페이지 스크롤이다 (WebView scrollY 는 0 이라도)
                if (innerScrolled) {
                    downAtTop = false
                    if (dragging) cancelPull()
                    return false
                }
                // 도중에 확대되었으면(핀치 직후 등) 취소
                if (isPullBlocked()) {
                    downAtTop = false
                    if (dragging) cancelPull()
                    return false
                }
                val x = ev.getX(i)
                val y = ev.getY(i)
                if (canChildScrollUp()) {
                    // 아직 맨 위가 아니면 기준점을 계속 갱신 (맨 위에 닿은 순간부터 거리를 잰다)
                    downX = x
                    downY = y
                    return false
                }
                val dy = y - downY
                val dx = abs(x - downX)
                // 페이지의 판정(안쪽 스크롤 여부)이 도착할 시간을 준 뒤에만 시작한다
                val held = ev.eventTime - ev.downTime
                if (!dragging && held >= 70L && dy > minStartDy && dy > dx * 2f) {
                    dragging = true
                    startY = downY + minStartDy
                    spring?.cancel()
                    clearFinish()   // 체크가 보이는 채로 올라가던 중이면 다시 당기는 모양으로
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (sawMultiTouch) multiTouchEndedAt = System.currentTimeMillis()
                sawMultiTouch = false
                dragging = false
                pointerId = -1
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!dragging) return false
        // 끌어내리는 도중 두 번째 손가락이 닿거나 떨어지면 새로고침 취소
        if (ev.actionMasked == MotionEvent.ACTION_POINTER_DOWN ||
            ev.actionMasked == MotionEvent.ACTION_POINTER_UP || ev.pointerCount > 1) {
            sawMultiTouch = true
            cancelPull()
            return true
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val i = ev.findPointerIndex(pointerId)
                if (i < 0) { cancelPull(); return true }
                val raw = max(0f, ev.getY(i) - startY)
                applyOffset(rubber(raw))
                if (!armed && offset >= trigger) {
                    armed = true
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    playPop()
                } else if (armed && offset < trigger - 8f * d) {
                    armed = false
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                pointerId = -1
                val fire = ev.actionMasked == MotionEvent.ACTION_UP && offset >= trigger &&
                    !sawMultiTouch && !isPullBlocked() && !innerScrolled
                if (sawMultiTouch) multiTouchEndedAt = System.currentTimeMillis()
                sawMultiTouch = false
                armed = false
                if (fire) {
                    isRefreshing = true
                    refreshStartedAt = System.currentTimeMillis()
                    startSpinner()
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    animateTo(hold, 380f, 0.75f)
                    onRefresh?.invoke()
                } else {
                    animateTo(0f, 300f, 0.9f)
                }
            }
        }
        return true
    }

    // ───────────────────────── 애니메이션 ─────────────────────────

    /** 당긴 거리 → 화면에서 내려오는 거리 (멀어질수록 저항이 커지는 고무줄) */
    private fun rubber(raw: Float): Float = maxPull * (1f - exp(-raw / (maxPull * 1.1f)))

    private fun applyOffset(v: Float) {
        offset = v
        for (i in 0 until childCount) getChildAt(i).translationY = v
        invalidate()
    }

    private fun animateTo(target: Float, stiffness: Float, damping: Float) {
        spring?.cancel()
        if (abs(offset - target) < 0.5f) {
            applyOffset(target)
            if (target == 0f && !isRefreshing) stopSpinner()
            return
        }
        spring = SpringAnimation(this, offsetProp).apply {
            setSpring(
                SpringForce(target)
                    .setStiffness(stiffness)
                    .setDampingRatio(damping)
            )
            setMinimumVisibleChange(0.5f)
            addEndListener { _, canceled, _, _ ->
                if (!canceled && target == 0f) {
                    applyOffset(0f)
                    if (!isRefreshing) stopSpinner()
                }
            }
            start()
        }
    }

    private fun startSpinner() {
        spinner?.cancel()
        // 1.2초에 한 바퀴 돌고, 한 바퀴 동안 두 번 떠올랐다 내려온다
        spinner = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { spinT = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopSpinner() {
        spinner?.cancel()
        spinner = null
        spinT = 0f
        clearFinish()
    }

    /** 완료 연출을 지우고 당기는 모양으로 되돌린다 */
    private fun clearFinish() {
        removeCallbacks(closeRunnable)
        removeCallbacks(popRunnable)
        doneAnim?.cancel()
        finishing = false
        done = 0f
    }

    /** 표시기가 톡 튀었다 돌아오는 효과 */
    private fun playPop() {
        popAnim?.cancel()
        popAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 340
            addUpdateListener { pop = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    // ───────────────────────── 그리기 ─────────────────────────

    private fun easeOut(x: Float): Float { val k = 1f - x; return 1f - k * k * k }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (offset <= 0.5f) return

        // 페이지가 내려오면서 생긴 빈자리
        canvas.drawRect(0f, 0f, width.toFloat(), offset, gapPaint)

        // 표시기: 빈자리 한가운데, 내려온 만큼 커지면서 나타난다
        val appear = (offset / hold).coerceIn(0f, 1f)
        val eased = appear * appear * (3f - 2f * appear)
        if (eased <= 0.01f) return
        val cx = width / 2f
        val cy = offset / 2f
        val progress = (offset / trigger).coerceIn(0f, 1f)
        val spinning = isRefreshing || finishing
        val tau = 2f * PI.toFloat()

        // 당기는 동안엔 당긴 만큼 서고 차오르고, 놓은 뒤엔 다 자란 모양
        val grow = if (spinning) 1f else easeOut(progress)
        val fillFrac = if (spinning) 1f else progress
        // 완료 중엔 도는 각도가 앞면(한 바퀴의 끝)에 닿을 때까지 감속한다: 앞면에서는 flip=1, 떠오름·기울기=0 이라 저절로 가지런히 멈춘다
        val ang = if (finishing) finishAng0 + finishRemain * easeOut(done) else tau * spinT
        val flipRaw = if (spinning) cos(ang) else 1f
        // 옆면이 되어도 완전히 사라지지는 않게 얇은 선만큼은 남긴다
        val flip = if (flipRaw >= 0f) max(flipRaw, 0.07f) else min(flipRaw, -0.07f)
        val bob = if (spinning) 0.5f - 0.5f * cos(2f * ang) else 0f   // 떠올랐다 내려옴
        val tilt = if (spinning) 7f * sin(ang) else -40f * (1f - grow)   // 당길 땐 누웠다가 일어선다
        val bump = 1f + 0.15f * sin(PI.toFloat() * pop) * (1f - 0.35f * pop)           // 톡 튀는 효과

        val sc = leafH / 584f * (0.6f + 0.4f * eased) * (0.55f + 0.45f * grow) * bump

        // 바닥 그림자 (잎이 뜨면 작고 옅어지고, 옆면일 때 좁아진다)
        shadowPaint.alpha = (46 * eased * (1f - 0.3f * bob)).toInt()
        val sw = 9f * d * (0.45f + 0.55f * abs(flip)) * (1f - 0.15f * bob) * (0.6f + 0.4f * eased)
        val sy = cy + leafH * 0.5f + 4f * d
        canvas.drawOval(cx - sw, sy - 2.2f * d, cx + sw, sy + 2.2f * d, shadowPaint)

        canvas.save()
        canvas.translate(cx, cy - 2f * d * bob)
        canvas.rotate(tilt)
        canvas.scale(sc * flip, sc)
        canvas.translate(-640f, -629f)

        trackPaint.alpha = (60 * eased).toInt()
        canvas.drawPath(leafPath, trackPaint)
        if (fillFrac > 0.01f) {
            // 아래에서 위로 차오른다
            canvas.save()
            canvas.clipRect(300f, 921f - 584f * fillFrac, 1000f, 930f)
            leafPaint.alpha = (255 * eased).toInt()
            canvas.drawPath(leafPath, leafPaint)
            canvas.restore()
        }
        canvas.restore()

        // 완료: 작은 잎들이 둘레로 흩날린다
        val sp = ((done - 0.4f) / 0.6f).coerceIn(0f, 1f)
        if (finishing && sp > 0f) {
            val a = sin(PI.toFloat() * sp)
            val dist = (14f + 18f * easeOut(sp)) * d
            fill.color = accent; fill.alpha = (255 * a * eased).toInt()
            for (i in burstAngles.indices) {
                val rad = Math.toRadians(burstAngles[i].toDouble())
                canvas.save()
                canvas.translate(cx + dist * cos(rad).toFloat(), cy + dist * sin(rad).toFloat())
                canvas.rotate(burstAngles[i] + 90f + 140f * sp * (if (i % 2 == 0) 1f else -1f))
                val z = 0.8f * d * (0.5f + 0.5f * a)
                canvas.scale(z, z)
                canvas.drawPath(if (i % 2 == 0) bitA else bitB, fill)
                canvas.restore()
            }
        }
    }
}
