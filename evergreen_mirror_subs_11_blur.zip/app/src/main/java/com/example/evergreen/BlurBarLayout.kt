package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import android.widget.LinearLayout

/**
 * 상단바(탭 줄 · 주소창)와 하단 내비게이션 바용 유리 배경.
 * Android 12(API 31) 이상에서, 바와 맞닿은 웹 페이지 가장자리(위쪽 바는 페이지 맨 위, 아래쪽 바는 페이지 맨 아래)를
 * 흐리게 바 뒤에 깔고 바 배경은 반투명으로 만든다. 그 아래 버전에서는 원래 배경 그대로다.
 * 바는 페이지 위에 겹치지 않고 따로 놓여 있으므로(레이아웃은 그대로) 페이지의 맨 위/아래가 바에 가려지지 않는다.
 * 웹뷰를 직접 다시 그리지 않고 화면에 그려진 픽셀을 복사해 쓴다 (GlassBackdrop 참고).
 */
class BlurBarLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : LinearLayout(ctx, attrs) {

    /** 맞닿은 웹 페이지 영역 */
    var source: View? = null
        set(v) { field = v; invalidate() }

    /** true 면 아래쪽 바 (페이지 맨 아래를 비춘다), false 면 위쪽 바 (페이지 맨 위를 비춘다) */
    var bottomEdge = false

    private val blurOn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    private var glass: Any? = null
    private var tinted = false
    private val a = IntArray(2)
    private val b = IntArray(2)
    private val pre = ViewTreeObserver.OnPreDrawListener {
        if (source != null) (glass as? GlassBackdrop)?.refresh()
        true
    }

    private fun region(): Rect? {
        val src = source ?: return null
        if (src.width <= 0 || src.height < height || height <= 0) return null
        getLocationInWindow(a)
        src.getLocationInWindow(b)
        val top = if (bottomEdge) b[1] + src.height - height else b[1]
        // 바가 스크롤로 움직이는 중이어도 페이지 쪽 위치 기준으로 가져온다
        return Rect(a[0], top, a[0] + width, top + height)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (blurOn) {
            if (glass == null) glass = GlassBackdrop(this) { region() }
            viewTreeObserver.addOnPreDrawListener(pre)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (blurOn) {
            if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(pre)
            (glass as? GlassBackdrop)?.release()
        }
    }

    override fun draw(canvas: Canvas) {
        val g = glass as? GlassBackdrop
        if (blurOn && g != null && source != null && width > 0 && height > 0) {
            try {
                if (!tinted) {
                    // 뒤의 흐린 그림이 비치도록 바 배경을 반투명으로 (한 번만)
                    background?.mutate()?.alpha = 0xC4
                    tinted = true
                }
                g.draw(canvas, width, height)
            } catch (e: Throwable) { /* 못 그리면 원래 배경 */ }
        }
        super.draw(canvas)
    }
}
