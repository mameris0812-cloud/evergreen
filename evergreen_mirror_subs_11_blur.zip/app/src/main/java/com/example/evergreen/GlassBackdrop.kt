package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.PixelCopy
import android.view.View
import androidx.annotation.RequiresApi

/**
 * 유리(블러) 배경 공통 도우미 (Android 12 이상에서만 쓴다).
 *
 * 웹 페이지(WebView)를 우리가 직접 한 번 더 그리면 같은 프레임에 두 번 그려져 화면이 깜빡이므로,
 * 화면에 이미 그려진 픽셀을 PixelCopy 로 작게(1/8) 복사해 와서 그 그림을 흐리게 깐다.
 * 복사는 약 80ms 에 한 번 이하로만 하고, 그림이 실제로 바뀐 경우에만 다시 그린다 (바뀌지 않으면 멈춘다).
 *
 * [rectProvider]: 복사할 곳(창 좌표). 이 뷰 자신이 겹치지 않는 곳이어야 한다 (자기 자신이 찍히면 번져 보인다).
 */
@RequiresApi(Build.VERSION_CODES.S)
internal class GlassBackdrop(private val view: View, private val rectProvider: () -> Rect?) {

    private val handler = Handler(Looper.getMainLooper())
    private var front: Bitmap? = null
    private var back: Bitmap? = null
    private var busy = false
    private var lastAt = 0L
    private var lastSig = 0L
    private var retryQueued = false
    private var node: RenderNode? = null
    private val retry = Runnable { retryQueued = false; refresh() }

    private fun activity(c: Context): Activity? {
        var x: Context? = c
        while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }
        return null
    }

    /** 화면이 그려지기 직전에 부른다. 필요하면 복사를 요청한다 */
    fun refresh() {
        if (busy || !view.isShown || view.width <= 0) return
        val now = SystemClock.uptimeMillis()
        if (now - lastAt < 80) {
            if (!retryQueued) { retryQueued = true; handler.postDelayed(retry, 90) }
            return
        }
        val win = activity(view.context)?.window ?: return
        val r = rectProvider() ?: return
        val dm = view.resources.displayMetrics
        val bounds = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        if (r.isEmpty || !bounds.contains(r)) return
        val bw = (r.width() / 8).coerceIn(8, 400)
        val bh = (r.height() / 8).coerceIn(4, 400)
        var dst = back
        if (dst == null || dst.width != bw || dst.height != bh) {
            dst = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            back = dst
        }
        busy = true
        lastAt = now
        try {
            PixelCopy.request(win, r, dst, { result ->
                busy = false
                if (result == PixelCopy.SUCCESS) {
                    // 몇 군데 픽셀만 보고 그림이 바뀌었는지 확인한다
                    var sig = 17L
                    for (iy in 0 until 4) for (ix in 0 until 8) {
                        sig = sig * 31 + dst.getPixel((ix * (dst.width - 1)) / 7, (iy * (dst.height - 1)) / 3)
                    }
                    val t = front; front = dst; back = t
                    if (sig != lastSig) { lastSig = sig; view.invalidate() }
                }
            }, handler)
        } catch (e: Throwable) {
            busy = false
        }
    }

    /** 뷰의 (0,0)~(w,h) 자리에 흐린 그림을 그린다. 뒤 배경보다 먼저 불러야 한다 */
    fun draw(canvas: Canvas, w: Int, h: Int) {
        val bmp = front ?: return
        if (!canvas.isHardwareAccelerated) return
        val d = view.resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val rn = node ?: RenderNode("glassBlur").also {
            val r = 10f * d
            it.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
            node = it
        }
        rn.setPosition(0, 0, w + pad * 2, h + pad * 2)
        val rc = rn.beginRecording(w + pad * 2, h + pad * 2)
        try {
            rc.drawBitmap(bmp, null, RectF(0f, 0f, (w + pad * 2).toFloat(), (h + pad * 2).toFloat()), null)
        } finally {
            rn.endRecording()
        }
        canvas.save()
        canvas.clipRect(0, 0, w, h)
        canvas.translate(-pad.toFloat(), -pad.toFloat())
        canvas.drawRenderNode(rn)
        canvas.restore()
    }

    fun release() {
        handler.removeCallbacks(retry)
        retryQueued = false
    }
}
