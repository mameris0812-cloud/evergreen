package com.example.evergreen

import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

/**
 * 내장 플레이어용 유튜브 재생 주소 받기.
 *
 * 유튜브 웹페이지의 영상은 blob 주소라 그대로는 쓸 수 없다. 그래서 영상 번호(ID)만 뽑아서,
 * 유튜브 앱(안드로이드 VR / iOS)이 쓰는 내부 API(youtubei /player)로 직접 재생 주소를 받는다.
 * 이 두 클라이언트는 서명 암호화(signatureCipher)가 없는 주소를 준다.
 *
 * 받아 온 주소는 아래 순서로 시도한다 (앞의 것이 안 되면 플레이어가 다음 것으로 넘어간다):
 *   1) DASH  — 영상·소리가 따로 있는 고화질(최대 1080p) 스트림을 이 앱이 직접 mpd 로 엮은 것. 화질 선택도 된다.
 *   2) HLS   — 유튜브가 주는 m3u8 (라이브는 이것만)
 *   3) 일반 mp4 — 영상+소리가 합쳐진 낮은 화질(보통 360p). 마지막 수단
 *
 * 유튜브는 이 API 를 수시로 바꾼다(특히 PO 토큰 요구). 아래 상수(clientVersion 등)가 낡아서 막히면
 * clients() 의 값을 새 버전으로 올리면 된다.
 */
object YouTube {
    const val UA_VR = "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    const val UA_IOS = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"

    const val HLS = 0
    const val DASH = 1
    const val PROGRESSIVE = 2

    /** value: HLS 면 m3u8 주소, DASH 면 mpd 문서(XML 글자), PROGRESSIVE 면 mp4 주소. ua: 이 주소를 받을 때 보내야 하는 User-Agent */
    class Stream(val kind: Int, val value: String, val ua: String)

    class Info(
        val title: String,
        val live: Boolean,
        val streams: List<Stream>,
        /** 이 주소를 준 클라이언트 번호. 모두 실패하면 다음 번호부터 다시 받아 볼 수 있다 */
        val clientIdx: Int,
        val hasMoreClients: Boolean
    )

    class Fail(message: String) : Exception(message)

    private const val MAX_HEIGHT = 1080

    private class Client(val id: Int, val version: String, val ua: String, val context: JSONObject)

    private fun clients(): List<Client> = listOf(
        Client(
            28, "1.65.10", UA_VR,
            JSONObject()
                .put("clientName", "ANDROID_VR").put("clientVersion", "1.65.10")
                .put("deviceMake", "Oculus").put("deviceModel", "Quest 3")
                .put("osName", "Android").put("osVersion", "12L").put("androidSdkVersion", 32)
                .put("hl", "en").put("gl", "US").put("utcOffsetMinutes", 0).put("userAgent", UA_VR)
        ),
        Client(
            5, "20.10.4", UA_IOS,
            JSONObject()
                .put("clientName", "IOS").put("clientVersion", "20.10.4")
                .put("deviceMake", "Apple").put("deviceModel", "iPhone16,2")
                .put("osName", "iPhone").put("osVersion", "18.3.2.22D82")
                .put("hl", "en").put("gl", "US").put("utcOffsetMinutes", 0).put("userAgent", UA_IOS)
        )
    )

    // ───────────────────────── 주소에서 영상 번호 뽑기 ─────────────────────────

    private val ID_RE = Regex("^[A-Za-z0-9_-]{11}$")

    /** 유튜브 영상 주소(watch / youtu.be / shorts / embed / live)면 영상 번호, 아니면 null */
    fun videoIdOf(url: String?): String? {
        if (url.isNullOrBlank()) return null
        val u = try { Uri.parse(url) } catch (e: Exception) { return null }
        val scheme = u.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return null
        val host = (u.host ?: return null).lowercase()
            .removePrefix("www.").removePrefix("m.").removePrefix("music.")
        val segs = u.pathSegments
        val id: String? = when (host) {
            "youtu.be" -> segs.firstOrNull()
            "youtube.com", "youtube-nocookie.com" -> when (segs.firstOrNull()) {
                "watch" -> u.getQueryParameter("v")
                "shorts", "embed", "live", "v" -> segs.getOrNull(1)
                else -> null
            }
            else -> null
        }
        // /embed/videoseries 는 재생목록 임베드라 영상 번호가 아니다
        return id?.takeIf { ID_RE.matches(it) && it != "videoseries" }
    }

    // ───────────────────────── 재생 주소 받기 ─────────────────────────

    /**
     * 백그라운드 스레드에서 부를 것. fromClient 는 앞 클라이언트가 막혔을 때 다음 것부터 다시 받을 때 쓴다.
     * 실패하면 사용자에게 보여 줄 수 있는 한국어 이유를 담은 [Fail] 을 던진다.
     */
    fun resolve(id: String, fromClient: Int = 0): Info {
        val list = clients()
        var lastReason = "재생 주소를 받지 못했어요"
        var i = fromClient
        while (i < list.size) {
            val c = list[i]
            try {
                val root = fetchPlayer(c, id)
                val ps = root.optJSONObject("playabilityStatus")
                val status = ps?.optString("status").orEmpty()
                val sd = root.optJSONObject("streamingData")
                if (status == "OK" && sd != null) {
                    val details = root.optJSONObject("videoDetails")
                    val live = details?.optBoolean("isLive", false) == true
                    val streams = buildStreams(sd, details, live, c.ua)
                    if (streams.isNotEmpty()) {
                        return Info(details?.optString("title").orEmpty(), live, streams, i, i + 1 < list.size)
                    }
                    lastReason = "재생할 수 있는 형식이 없어요"
                } else {
                    lastReason = reasonOf(status, ps)
                }
            } catch (e: Fail) {
                lastReason = e.message ?: lastReason
            } catch (e: IOException) {
                // 인터넷이 안 되는 것이면 다른 클라이언트로 또 시도해 봐야 소용없다
                throw Fail("인터넷에 연결하지 못했어요")
            } catch (e: Exception) {
                lastReason = "유튜브 응답을 읽지 못했어요"
            }
            i++
        }
        throw Fail(lastReason)
    }

    private fun reasonOf(status: String, ps: JSONObject?): String {
        val r = ps?.optString("reason").orEmpty()
        return when (status) {
            "LOGIN_REQUIRED" ->
                "로그인이 필요한 영상이에요 (나이 제한·비공개·멤버십이거나, 유튜브가 봇 확인을 요구해요)" +
                    if (r.isNotBlank()) "\n$r" else ""
            "UNPLAYABLE" -> r.ifBlank { "재생할 수 없는 영상이에요" }
            "ERROR" -> r.ifBlank { "영상을 찾을 수 없어요" }
            "LIVE_STREAM_OFFLINE" -> r.ifBlank { "라이브가 끝났거나 아직 시작 전이에요" }
            else -> r.ifBlank { "재생할 수 없는 영상이에요 ($status)" }
        }
    }

    private fun fetchPlayer(c: Client, id: String): JSONObject {
        val body = JSONObject()
            .put("context", JSONObject().put("client", c.context))
            .put("videoId", id)
            .put("contentCheckOk", true)
            .put("racyCheckOk", true)
        val req = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
            .header("User-Agent", c.ua)
            .header("X-YouTube-Client-Name", c.id.toString())
            .header("X-YouTube-Client-Version", c.version)
            .header("Accept-Language", "en-US,en;q=0.9")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return PlayerHttp.client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Fail("유튜브가 요청을 거절했어요 (HTTP ${resp.code})")
            val text = resp.body?.string().orEmpty()
            if (text.isBlank()) throw Fail("유튜브가 빈 응답을 줬어요")
            JSONObject(text)
        }
    }

    // ───────────────────────── 형식 고르기 ─────────────────────────

    private fun buildStreams(sd: JSONObject, details: JSONObject?, live: Boolean, ua: String): List<Stream> {
        val out = ArrayList<Stream>()
        val hls = sd.optString("hlsManifestUrl")
        if (live) {
            if (hls.isNotBlank()) out.add(Stream(HLS, hls, ua))
            return out
        }
        buildDash(sd.optJSONArray("adaptiveFormats"), details)?.let { out.add(Stream(DASH, it, ua)) }
        if (hls.isNotBlank()) out.add(Stream(HLS, hls, ua))
        bestMuxed(sd.optJSONArray("formats"))?.let { out.add(Stream(PROGRESSIVE, it, ua)) }
        return out
    }

    /** 영상+소리가 합쳐진 형식 중 가장 큰 것 (보통 itag 18, 360p) */
    private fun bestMuxed(arr: JSONArray?): String? {
        if (arr == null) return null
        var best: String? = null
        var bestH = -1
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val url = o.optString("url")
            if (url.isBlank()) continue // signatureCipher 만 있는 것은 쓸 수 없다
            if (!o.optString("mimeType").startsWith("video/")) continue
            val h = o.optInt("height")
            if (h > bestH) { bestH = h; best = url }
        }
        return best
    }

    private class Fmt(val o: JSONObject) {
        val url: String = o.optString("url")
        val mime: String = o.optString("mimeType")
        val type: String = mime.substringBefore(';').trim()
        val codecs: String = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.get(1).orEmpty()
        val itag: Int = o.optInt("itag")
        val bitrate: Long = o.optLong("bitrate")
        val height: Int = o.optInt("height")
        val width: Int = o.optInt("width")
        val fps: Int = o.optInt("fps")
        val initR: String? = range(o.optJSONObject("initRange"))
        val indexR: String? = range(o.optJSONObject("indexRange"))

        private fun range(r: JSONObject?): String? {
            if (r == null) return null
            val s = r.optString("start")
            val e = r.optString("end")
            return if (s.isNotBlank() && e.isNotBlank()) "$s-$e" else null
        }

        /** 0 = H.264, 1 = VP9, 2 = AV1, -1 = 그 밖 */
        fun family(): Int = when {
            codecs.startsWith("avc1") -> 0
            codecs.startsWith("vp09") || codecs.startsWith("vp9") -> 1
            codecs.startsWith("av01") -> 2
            else -> -1
        }

        fun isHdr(): Boolean {
            if (codecs.startsWith("vp09.02") || codecs.startsWith("vp09.03")) return true // 10비트
            val prim = o.optJSONObject("colorInfo")?.optString("primaries").orEmpty()
            return prim.contains("2020")
        }
    }

    /**
     * 영상 전용 + 소리 전용 형식들로 DASH 목록(mpd)을 직접 만든다.
     * 한 가지 코덱(H.264 우선)의 1080p 이하 화질들을 모두 넣어서, 플레이어가 속도에 맞춰 화질을 바꾸고 사용자도 고를 수 있게 한다.
     */
    private fun buildDash(arr: JSONArray?, details: JSONObject?): String? {
        if (arr == null) return null
        val vids = ArrayList<Fmt>()
        val auds = ArrayList<Fmt>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val f = Fmt(o)
            if (f.url.isBlank() || f.initR == null || f.indexR == null) continue
            if (o.optBoolean("isDrc", false)) continue
            when {
                f.type.startsWith("video/") -> if (!f.isHdr()) vids.add(f)
                f.type.startsWith("audio/") -> {
                    // 더빙 등 여러 음성이 있으면 기본(원본) 음성만
                    val at = o.optJSONObject("audioTrack")
                    if (at != null && !at.optBoolean("audioIsDefault", true)) continue
                    auds.add(f)
                }
            }
        }

        // 코덱 고르기: 1080p 이하에서 가장 높은 화질을 내는 코덱 (같으면 H.264 > VP9 > AV1)
        var fam = -1
        var famH = -1
        for (c in 0..2) {
            val h = vids.filter { it.family() == c && it.height <= MAX_HEIGHT }.maxOfOrNull { it.height } ?: continue
            if (h > famH) { famH = h; fam = c }
        }
        if (fam < 0) return null
        val vsel = vids.filter { it.family() == fam && it.height in 144..MAX_HEIGHT }
            .sortedWith(compareBy({ it.height }, { it.fps }))
        if (vsel.isEmpty()) return null

        val wantAudio = if (fam == 1) "opus" else "mp4a"
        val asel = auds.filter { it.codecs.startsWith(wantAudio) }.maxByOrNull { it.bitrate }
            ?: auds.maxByOrNull { it.bitrate }
            ?: return null

        val durMs = vsel.first().o.optString("approxDurationMs").toLongOrNull()
            ?: ((details?.optString("lengthSeconds")?.toLongOrNull() ?: 0L) * 1000L)
        if (durMs <= 0L) return null

        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        sb.append("<MPD xmlns=\"urn:mpeg:dash:schema:mpd:2011\" profiles=\"urn:mpeg:dash:profile:full:2011\" ")
        sb.append("type=\"static\" minBufferTime=\"PT1.5S\" mediaPresentationDuration=\"PT")
        sb.append(String.format(Locale.US, "%.3f", durMs / 1000.0)).append("S\">")
        sb.append("<Period>")

        // 영상
        sb.append("<AdaptationSet mimeType=\"").append(xml(vsel.first().type))
            .append("\" subsegmentAlignment=\"true\" subsegmentStartsWithSAP=\"1\">")
        for (f in vsel) {
            sb.append("<Representation id=\"").append(f.itag)
                .append("\" codecs=\"").append(xml(f.codecs))
                .append("\" bandwidth=\"").append(f.bitrate)
                .append("\" width=\"").append(f.width)
                .append("\" height=\"").append(f.height)
            if (f.fps > 0) sb.append("\" frameRate=\"").append(f.fps)
            sb.append("\">")
            appendBase(sb, f)
            sb.append("</Representation>")
        }
        sb.append("</AdaptationSet>")

        // 소리
        sb.append("<AdaptationSet mimeType=\"").append(xml(asel.type)).append("\" subsegmentAlignment=\"true\">")
        sb.append("<Representation id=\"").append(asel.itag)
            .append("\" codecs=\"").append(xml(asel.codecs))
            .append("\" bandwidth=\"").append(asel.bitrate)
        val rate = asel.o.optString("audioSampleRate")
        if (rate.isNotBlank()) sb.append("\" audioSamplingRate=\"").append(xml(rate))
        sb.append("\">")
        val ch = asel.o.optInt("audioChannels", 2).coerceAtLeast(1)
        sb.append("<AudioChannelConfiguration schemeIdUri=\"urn:mpeg:dash:23003:3:audio_channel_configuration:2011\" value=\"")
            .append(ch).append("\"/>")
        appendBase(sb, asel)
        sb.append("</Representation></AdaptationSet>")

        sb.append("</Period></MPD>")
        return sb.toString()
    }

    private fun appendBase(sb: StringBuilder, f: Fmt) {
        sb.append("<BaseURL>").append(xml(f.url)).append("</BaseURL>")
        sb.append("<SegmentBase indexRange=\"").append(f.indexR).append("\">")
            .append("<Initialization range=\"").append(f.initR).append("\"/>")
            .append("</SegmentBase>")
    }

    private fun xml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
}
