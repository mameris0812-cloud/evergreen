package com.example.evergreen

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SearchEngine(
    val key: String,
    val name: String,
    val searchUrl: String,
    val homeUrl: String,
    /** 검색어 뒤에 붙는 주소 조각 (검색어 자리가 주소 중간에 있는 사용자 엔진용). 기본 엔진은 빈 글자 */
    val suffix: String = "",
    val custom: Boolean = false
) {
    /** 검색어를 넣은 완성 주소 */
    fun url(query: String): String = searchUrl + android.net.Uri.encode(query) + suffix
}

object SearchEngines {
    val all = listOf(
        SearchEngine("google", "Google", "https://www.google.com/search?q=", "https://www.google.com"),
        SearchEngine("naver", "네이버", "https://search.naver.com/search.naver?query=", "https://m.naver.com"),
        SearchEngine("ddg", "DuckDuckGo", "https://duckduckgo.com/?q=", "https://duckduckgo.com"),
        SearchEngine("bing", "Bing", "https://www.bing.com/search?q=", "https://www.bing.com")
    )

    fun byKey(key: String): SearchEngine = all.firstOrNull { it.key == key } ?: all[0]

    /** 빠른 검색 단축어: 주소창에 "yt 노래", "n 날씨" 처럼 입력 */
    val shortcuts: Map<String, String> = mapOf(
        "g" to "https://www.google.com/search?q=",
        "n" to "https://search.naver.com/search.naver?query=",
        "d" to "https://duckduckgo.com/?q=",
        "b" to "https://www.bing.com/search?q=",
        "yt" to "https://m.youtube.com/results?search_query=",
        "w" to "https://ko.wikipedia.org/w/index.php?search=",
        "map" to "https://www.google.com/maps/search/"
    )
}

/**
 * 저장된 JSON 글자를 파싱한 결과를 기억해 둔다.
 * SharedPreferences 는 값이 바뀌지 않는 동안 같은 String 객체를 돌려주므로, 객체가 그대로면(===) 다시 파싱하지 않는다.
 * 글자가 바뀌면 (다른 Prefs 인스턴스가 썼어도) 객체가 달라져서 자동으로 새로 파싱하므로 오래된 값이 남지 않는다.
 * 돌려주는 값은 읽기 전용으로만 쓴다 (모든 호출부가 filter/map/toMutableList 로 복사해서 쓴다).
 */
private class JsonMemo<T>(private val fallback: T, private val parse: (String) -> T) {
    private var raw: String? = null
    private var value: T = fallback

    @Synchronized
    fun get(current: String?): T {
        if (current == null) return fallback
        if (current === raw) return value
        val v = try { parse(current) } catch (e: Exception) { fallback }
        raw = current
        value = v
        return v
    }
}

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("browser", Context.MODE_PRIVATE)

    // 자동완성(글자를 칠 때마다 메인 스레드)·메뉴·페이지 로딩 완료 때마다 JSON 을 통째로 다시 읽던 것을 막는다
    private val historyMemo = JsonMemo<List<HistoryItem>>(emptyList()) { raw ->
        val arr = JSONArray(raw)
        val out = ArrayList<HistoryItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(HistoryItem(o.getString("u"), o.optString("t"), o.optLong("d", 0L)))
        }
        out
    }
    private val historyPairsMemo = JsonMemo<List<Pair<String, String>>>(emptyList()) { raw ->
        historyMemo.get(raw).map { it.url to it.title }
    }
    private val bookmarksMemo = JsonMemo<List<Bookmark>>(emptyList()) { raw ->
        val arr = JSONArray(raw)
        val out = ArrayList<Bookmark>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Bookmark(o.getLong("i"), o.getString("u"), o.optString("t"), o.optLong("f", 0L)))
        }
        out
    }
    private val shortcutsMemo = JsonMemo<List<HomeShortcut>>(DEFAULT_HOME_SHORTCUTS) { raw ->
        val arr = JSONArray(raw)
        val out = ArrayList<HomeShortcut>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(HomeShortcut(o.getString("n"), o.getString("u"), o.optString("g")))
        }
        out
    }
    private val recentMemo = JsonMemo<List<String>>(emptyList()) { raw ->
        val arr = JSONArray(raw)
        val out = ArrayList<String>(arr.length())
        for (i in 0 until arr.length()) out.add(arr.getString(i))
        out
    }
    private val folderMemos = HashMap<String, JsonMemo<List<Folder>>>()

    var adBlock: Boolean
        get() = sp.getBoolean("adblock", true)
        set(v) = sp.edit().putBoolean("adblock", v).apply()

    /** 앱을 껐다 켜도 탭이 남도록 저장해 두는 탭 목록(JSON) */
    var savedTabs: String?
        get() = sp.getString("saved_tabs", null)
        set(v) = sp.edit().putString("saved_tabs", v).apply()

    /** 창 번호별로 저장해 둔 탭 목록(JSON). 1번 창은 예전 저장 위치를 그대로 쓴다 */
    fun savedTabsFor(no: Int): String? = if (no == 1) savedTabs else sp.getString("saved_tabs_w$no", null)

    private fun numSet(key: String): Set<Int> =
        (sp.getString(key, null) ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()

    private fun putNumSet(key: String, set: Set<Int>) {
        sp.edit().putString(key, set.sorted().joinToString(",")).apply()
    }

    /** 탭을 저장하고 그 창을 "열려 있음"으로 표시한다 */
    fun setSavedTabsFor(no: Int, json: String) {
        if (no == 1) savedTabs = json else sp.edit().putString("saved_tabs_w$no", json).apply()
        putNumSet("saved_windows", numSet("saved_windows") + no)
        putNumSet("open_windows", numSet("open_windows") + no)
    }

    /** 창이 닫힘: 탭은 그대로 남기고 "열려 있음" 표시만 뗀다 (앱을 켤 때 자동으로 다시 열리지 않는다. 지금은 열림 표시와 상관없이 1번 창만 복원한다) */
    fun markWindowClosed(no: Int) = putNumSet("open_windows", numSet("open_windows") - no)

    /** 탭이 하나도 없어진 창의 저장분을 지운다 (1번 창은 기본 창이라 남겨 둔다) */
    fun clearSavedTabsFor(no: Int) {
        if (no == 1) return
        sp.edit().remove("saved_tabs_w$no").apply()
        putNumSet("saved_windows", numSet("saved_windows") - no)
        putNumSet("open_windows", numSet("open_windows") - no)
    }

    /** 탭이 저장돼 있는 창 번호들 */
    fun savedWindowNos(): Set<Int> = numSet("saved_windows")

    /** 앱이 꺼질 때 열려 있던 창 번호들 */
    fun openWindowNos(): Set<Int> = numSet("open_windows")

    /** 저장된 창의 (홈 화면이 아닌) 탭 개수 */
    fun savedTabCount(no: Int): Int = try {
        val arr = JSONObject(savedTabsFor(no) ?: "{}").optJSONArray("tabs")
        var n = 0
        if (arr != null) for (i in 0 until arr.length()) if (!arr.getJSONObject(i).optBoolean("home", false)) n++
        n
    } catch (e: Exception) { 0 }

    /** 창 이름 (창 번호별). 창을 닫거나 앱을 껐다 켜도 남는다 */
    fun windowName(no: Int): String? = try {
        JSONObject(sp.getString("window_names", null) ?: "{}").optString(no.toString()).takeIf { it.isNotBlank() }
    } catch (e: Exception) { null }

    /** 탭 화면의 창 칩 순서 (창 번호 순서대로). 끌어서 바꾼 순서를 모든 창이 같이 쓴다 */
    fun windowOrder(): List<Int> =
        (sp.getString("window_order", null) ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }

    fun setWindowOrder(order: List<Int>) {
        sp.edit().putString("window_order", order.joinToString(",")).apply()
    }

    fun setWindowName(no: Int, name: String?) {
        val o = try { JSONObject(sp.getString("window_names", null) ?: "{}") } catch (e: Exception) { JSONObject() }
        if (name.isNullOrBlank()) o.remove(no.toString()) else o.put(no.toString(), name)
        sp.edit().putString("window_names", o.toString()).apply()
    }

    /** 1. 트래커 차단(엄격): 사이트 동작에 필요한 것만 허용 */
    var strictTrackers: Boolean
        get() = sp.getBoolean("strict_trackers", false)
        set(v) = sp.edit().putBoolean("strict_trackers", v).apply()

    /** 2. 인증 과정 데이터로 추적하지 못하도록 캡차 건너뛰기(자동 인증) 우선 */
    var skipCaptchaTracking: Boolean
        get() = sp.getBoolean("skip_captcha_tracking", false)
        set(v) = sp.edit().putBoolean("skip_captcha_tracking", v).apply()

    /** 3. 악성 사이트 접속 시 알림 (Safe Browsing) */
    var malwareWarning: Boolean
        get() = sp.getBoolean("malware_warning", true)
        set(v) = sp.edit().putBoolean("malware_warning", v).apply()

    /** 4. 사용자 동작 없는 자동 다운로드 차단 */
    var blockAutoDownload: Boolean
        get() = sp.getBoolean("block_auto_download", true)
        set(v) = sp.edit().putBoolean("block_auto_download", v).apply()

    /** 뒤로가기 중 페이지가 스스로 다른 곳으로 보내는 자동 이동 차단 */
    var blockBackRedirect: Boolean
        get() = sp.getBoolean("block_back_redirect", true)
        set(v) = sp.edit().putBoolean("block_back_redirect", v).apply()

    /** http 주소도 먼저 https 로 연결 (HTTPS 우선) */
    var httpsFirst: Boolean
        get() = sp.getBoolean("https_first", true)
        set(v) = sp.edit().putBoolean("https_first", v).apply()

    /** 비밀번호 저장·자동완성 (기기의 자동완성 서비스 사용) */
    var autofill: Boolean
        get() = sp.getBoolean("autofill", true)
        set(v) = sp.edit().putBoolean("autofill", v).apply()

    /** 웹 페이지 다크 모드: 0 = 끔, 1 = 기기가 다크 모드일 때, 2 = 항상 */
    var webDarkMode: Int
        get() = sp.getInt("web_dark_mode", 1)
        set(v) = sp.edit().putInt("web_dark_mode", v).apply()

    /** 웹 페이지 확대/축소 (%, 50~500). 핀치 줌이 아니라 페이지 레이아웃 자체를 키우고 줄인다 */
    var pageZoom: Int
        get() = sp.getInt("page_zoom", 100).coerceIn(50, 500)
        set(v) = sp.edit().putInt("page_zoom", v.coerceIn(50, 500)).apply()

    /** 웹 페이지 글자 크기 (%) */
    var textZoom: Int
        get() = sp.getInt("text_zoom", 100)
        set(v) = sp.edit().putInt("text_zoom", v).apply()

    /** Gemini API 키 (기기 보안 저장소 키로 암호화해서 보관) */
    var geminiKey: String
        get() = sp.getString("gemini_key", null)?.let { KeyVault.decrypt(it) } ?: ""
        set(v) {
            if (v.isBlank()) sp.edit().remove("gemini_key").apply()
            else sp.edit().putString("gemini_key", KeyVault.encrypt(v.trim())).apply()
        }

    var geminiModel: String
        get() = GeminiModels.byId(sp.getString("gemini_model", "") ?: "").id
        set(v) = sp.edit().putString("gemini_model", v).apply()

    /** 페이지 번역에 Gemini 를 쓸지 (키가 있을 때만 의미 있음). 꺼져 있으면 키 없이 Google 번역을 쓴다. */
    var translateWithGemini: Boolean
        get() = sp.getBoolean("translate_gemini", false)
        set(v) = sp.edit().putBoolean("translate_gemini", v).apply()

    /** 페이지 번역 진행 카드를 보여 줄지. 꺼 두면 카드 없이 끝났을 때 짧은 안내만 뜬다. */
    var translateCard: Boolean
        get() = sp.getBoolean("translate_card", true)
        set(v) = sp.edit().putBoolean("translate_card", v).apply()

    /** 영상 자막 번역: 0 = 끔, 1 = 번역만, 2 = 번역 + 원문 */
    var subTranslateMode: Int
        get() = sp.getInt("sub_translate_mode", 0)
        set(v) = sp.edit().putInt("sub_translate_mode", v).apply()

    /** 실시간 자막 방식: 0 = Gemini(소리를 서버로 보냄), 1 = 기기 안에서 인식(오프라인) */
    var liveMode: Int
        get() = sp.getInt("live_mode", 0)
        set(v) = sp.edit().putInt("live_mode", v).apply()

    /** 기기 안 인식의 말하는 언어 (BCP-47) */
    var liveLang: String
        get() = sp.getString("live_lang", "en-US") ?: "en-US"
        set(v) = sp.edit().putString("live_lang", v).apply()

    /** 데스크톱 사이트 보기: 한 번 켜면 새 탭·앱 재시작 후에도 유지된다 */
    var desktopSite: Boolean
        get() = sp.getBoolean("desktop_site", false)
        set(v) = sp.edit().putBoolean("desktop_site", v).apply()

    /** 탭을 탭 줄 밖으로 끌어내 놓으면 새 창으로 여는 동작 (기본 켜짐) */
    var dragTabToWindow: Boolean
        get() = sp.getBoolean("drag_tab_to_window", true)
        set(v) = sp.edit().putBoolean("drag_tab_to_window", v).apply()

    /** 앱을 나가거나 화면을 꺼도 영상/소리를 계속 재생 */
    var backgroundAudio: Boolean
        get() = sp.getBoolean("background_audio", true)
        set(v) = sp.edit().putBoolean("background_audio", v).apply()

    /** 재생 중인 웹 미디어를 시스템 미디어 플레이어(알림창·잠금화면 미디어 컨트롤)에 보여 줄지 */
    var mediaControls: Boolean
        get() = sp.getBoolean("media_controls", true)
        set(v) = sp.edit().putBoolean("media_controls", v).apply()

    /** 영상 아래에 '내장 플레이어로 열기' / 'PiP로 보기' 버튼을 띄울지 (기본 켜짐) */
    var videoButtons: Boolean
        get() = sp.getBoolean("video_buttons", true)
        set(v) = sp.edit().putBoolean("video_buttons", v).apply()

    /** AI 에게 질문할 때 지금 보는 페이지 내용을 함께 보낼지 */
    var assistantUsePage: Boolean
        get() = sp.getBoolean("assistant_use_page", true)
        set(v) = sp.edit().putBoolean("assistant_use_page", v).apply()

    /** 태블릿 웹툰 보기 너비: 0 = 보통(720dp), 1 = 넓게(960dp), 2 = 화면 전체 */
    var engineKey: String
        get() = sp.getString("engine", "google") ?: "google"
        set(v) = sp.edit().putString("engine", v).apply()

    /** 직접 정한 홈 페이지 주소. 빈 글자면 기본(새 탭 화면) */
    var homepage: String
        get() = sp.getString("homepage", "") ?: ""
        set(v) = sp.edit().putString("homepage", v).apply()

    /** 새 탭을 열 때도 직접 정한 홈 페이지를 열지 (시크릿 탭은 제외) */
    var homepageOnNewTab: Boolean
        get() = sp.getBoolean("homepage_new_tab", false)
        set(v) = sp.edit().putBoolean("homepage_new_tab", v).apply()

    /** 사용자가 직접 추가한 검색엔진 */
    fun customEngines(): List<SearchEngine> {
        val raw = sp.getString("custom_engines", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                SearchEngine(o.getString("k"), o.getString("n"), o.getString("u"), o.getString("h"), o.optString("s"), true)
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveCustomEngines(list: List<SearchEngine>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("k", it.key).put("n", it.name).put("u", it.searchUrl).put("h", it.homeUrl).put("s", it.suffix))
        }
        sp.edit().putString("custom_engines", arr.toString()).apply()
    }

    fun addCustomEngine(e: SearchEngine) = saveCustomEngines(customEngines() + e)

    fun removeCustomEngine(key: String) {
        saveCustomEngines(customEngines().filter { it.key != key })
        if (engineKey == key) engineKey = "google"
    }

    /** 기본 + 사용자가 추가한 검색엔진 */
    fun allEngines(): List<SearchEngine> = SearchEngines.all + customEngines()

    /** 지금 선택된 검색엔진 (없어졌으면 Google) */
    fun currentEngine(): SearchEngine = allEngines().firstOrNull { it.key == engineKey } ?: SearchEngines.all[0]

    /** 광고 차단 목록을 마지막으로 자동 업데이트 시도한 시각 (ms) */
    var adblockLastTry: Long
        get() = sp.getLong("adblock_try", 0L)
        set(v) = sp.edit().putLong("adblock_try", v).apply()

    @Synchronized
    fun history(): List<Pair<String, String>> = historyPairsMemo.get(sp.getString("history", null))

    /**
     * 방문 기록을 맨 앞에 올린다. 페이지가 하나 끝날 때마다 불리므로 한 번만 읽고 한 번만 쓴다.
     * (SharedPreferences 는 쓸 때마다 파일 전체를 다시 쓰고, 앱이 멈출 때 그 쓰기가 끝나길 메인 스레드가 기다린다)
     */
    @Synchronized
    fun addHistory(url: String, title: String?) {
        val items = historyItems()
        val t = title ?: ""
        val now = System.currentTimeMillis()
        // 방금 같은 주소·제목으로 남겼다면(새로고침, 한 페이지의 중복 완료 신호) 다시 쓰지 않는다
        val head = items.firstOrNull()
        if (head != null && head.url == url && head.title == t && now - head.time in 0..HISTORY_REPEAT_MS) return
        val arr = JSONArray()
        arr.put(JSONObject().put("u", url).put("t", t).put("d", now))
        var n = 1
        for (e in items) {
            if (e.url == url) continue
            if (n >= HISTORY_MAX) break
            arr.put(JSONObject().put("u", e.url).put("t", e.title).put("d", e.time))
            n++
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    /** 방문 시각이 들어 있는 기록 목록 (최근 방문이 앞). 시각이 없던 옛 기록은 time = 0 */
    @Synchronized
    fun historyItems(): List<HistoryItem> = historyMemo.get(sp.getString("history", null))

    @Synchronized
    fun removeHistory(url: String) {
        val arr = JSONArray()
        historyItems().filter { it.url != url }.forEach {
            arr.put(JSONObject().put("u", it.url).put("t", it.title).put("d", it.time))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    /** 고른 주소들의 기록을 한 번에 지운다 */
    @Synchronized
    fun removeHistories(urls: Set<String>) {
        val arr = JSONArray()
        historyItems().filter { it.url !in urls }.forEach {
            arr.put(JSONObject().put("u", it.url).put("t", it.title).put("d", it.time))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    @Synchronized
    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    /** 지운 방문 기록을 되돌릴 때: 지우기 전에 저장해 둔 목록을 그대로 다시 쓴다 */
    @Synchronized
    fun setHistoryItems(items: List<HistoryItem>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("u", it.url).put("t", it.title).put("d", it.time)) }
        sp.edit().putString("history", arr.toString()).apply()
    }

    // ───────────────────────── 최근 검색어 (주소창에서 직접 검색한 글자) ─────────────────────────

    @Synchronized
    fun recentSearches(): List<String> = recentMemo.get(sp.getString("recent_searches", null))

    @Synchronized
    fun addRecentSearch(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val list = recentSearches().filter { !it.equals(q, ignoreCase = true) }.toMutableList()
        list.add(0, q)
        val arr = JSONArray()
        list.take(20).forEach { arr.put(it) }
        sp.edit().putString("recent_searches", arr.toString()).apply()
    }

    @Synchronized
    fun removeRecentSearch(query: String) {
        val arr = JSONArray()
        recentSearches().filter { it != query }.forEach { arr.put(it) }
        sp.edit().putString("recent_searches", arr.toString()).apply()
    }

    @Synchronized
    fun clearRecentSearches() {
        sp.edit().remove("recent_searches").apply()
    }

    // ───────────────────────── 폴더 (kind: KIND_BM = 북마크, KIND_DL = 다운로드) ─────────────────────────

    @Synchronized
    fun folders(kind: String): List<Folder> {
        val memo = folderMemos.getOrPut(kind) {
            JsonMemo<List<Folder>>(emptyList()) { raw ->
                val arr = JSONArray(raw)
                val out = ArrayList<Folder>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(Folder(o.getLong("i"), o.getString("n")))
                }
                out
            }
        }
        return memo.get(sp.getString("folders_$kind", null))
    }

    private fun saveFolders(kind: String, list: List<Folder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("i", it.id).put("n", it.name)) }
        sp.edit().putString("folders_$kind", arr.toString()).apply()
    }

    private fun newId(used: Collection<Long>): Long =
        maxOf(System.currentTimeMillis(), (used.maxOrNull() ?: 0L) + 1L)

    @Synchronized
    fun addFolder(kind: String, name: String): Folder {
        val list = folders(kind)
        val f = Folder(newId(list.map { it.id }), name)
        saveFolders(kind, list + f)
        return f
    }

    @Synchronized
    fun renameFolder(kind: String, id: Long, name: String) {
        saveFolders(kind, folders(kind).map { if (it.id == id) Folder(id, name) else it })
    }

    /** 폴더만 지운다. 안에 있던 북마크/다운로드 파일은 지워지지 않고 '폴더 없음' 상태가 된다. */
    @Synchronized
    fun removeFolder(kind: String, id: Long) {
        saveFolders(kind, folders(kind).filter { it.id != id })
        if (kind == KIND_BM) {
            saveBookmarks(bookmarks().map { if (it.folderId == id) it.copy(folderId = 0L) else it })
        } else {
            val map = downloadFolderMap().filterValues { it != id }
            saveDownloadFolderMap(map)
        }
    }

    // ───────────────────────── 북마크 ─────────────────────────

    /** 새 북마크를 만들 때 기본으로 선택할 폴더 (마지막으로 쓴 폴더) */
    var lastBookmarkFolder: Long
        get() = sp.getLong("bm_last_folder", 0L)
        set(v) = sp.edit().putLong("bm_last_folder", v).apply()

    /** 홈 화면 즐겨찾기 (사용자가 바꾸기 전에는 기본 4개) */
    @Synchronized
    fun homeShortcuts(): List<HomeShortcut> = shortcutsMemo.get(sp.getString("home_shortcuts", null))

    @Synchronized
    fun saveHomeShortcuts(list: List<HomeShortcut>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("n", it.name).put("u", it.url).put("g", it.glyph)) }
        sp.edit().putString("home_shortcuts", arr.toString()).apply()
    }

    fun resetHomeShortcuts() = sp.edit().remove("home_shortcuts").apply()

    /** 최근에 추가한 것이 앞에 온다. */
    @Synchronized
    fun bookmarks(): List<Bookmark> = bookmarksMemo.get(sp.getString("bookmarks", null))

    private fun saveBookmarks(list: List<Bookmark>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("i", it.id).put("u", it.url).put("t", it.title).put("f", it.folderId))
        }
        sp.edit().putString("bookmarks", arr.toString()).apply()
    }

    private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

    @Synchronized
    fun findBookmark(url: String): Bookmark? = bookmarks().firstOrNull { sameUrl(it.url, url) }

    /** id 가 같은 북마크가 있으면 고치고, 없으면 맨 앞에 추가한다. */
    @Synchronized
    fun saveBookmark(url: String, title: String, folderId: Long, existingId: Long? = null): Bookmark {
        val list = bookmarks()
        val id = existingId ?: newId(list.map { it.id })
        val b = Bookmark(id, url, title, folderId)
        // 같은 주소가 이미 다른 항목으로 있으면 하나로 합친다.
        val out = if (existingId != null && list.any { it.id == existingId }) {
            list.filter { it.id == id || !sameUrl(it.url, url) }.map { if (it.id == id) b else it }
        } else {
            listOf(b) + list.filter { !sameUrl(it.url, url) }
        }
        saveBookmarks(out)
        return b
    }

    @Synchronized
    fun moveBookmark(id: Long, folderId: Long) {
        saveBookmarks(bookmarks().map { if (it.id == id) it.copy(folderId = folderId) else it })
    }

    @Synchronized
    fun removeBookmark(id: Long) {
        saveBookmarks(bookmarks().filter { it.id != id })
    }

    /** 고른 북마크들을 한 번에 지운다 */
    @Synchronized
    fun removeBookmarks(ids: Set<Long>) {
        saveBookmarks(bookmarks().filter { it.id !in ids })
    }

    /** 지운 북마크를 되돌릴 때: 지우기 전에 저장해 둔 목록을 그대로 다시 쓴다 */
    @Synchronized
    fun restoreBookmarks(list: List<Bookmark>) {
        saveBookmarks(list)
    }

    // ───────────────────────── 다운로드 파일 → 폴더 ─────────────────────────

    /** 다운로드 항목 키("m:123" 등) → 폴더 id. 폴더가 없는 항목은 들어 있지 않다. */
    @Synchronized
    fun downloadFolderMap(): Map<String, Long> {
        val raw = sp.getString("dl_folder_map", null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            val m = HashMap<String, Long>()
            o.keys().forEach { k -> m[k] = o.getLong(k) }
            m
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun saveDownloadFolderMap(map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        sp.edit().putString("dl_folder_map", o.toString()).apply()
    }

    /** folderId 가 0 이면 폴더에서 뺀다. */
    /** 지운 파일들을 폴더 분류에서 한 번에 뺀다 */
    @Synchronized
    fun clearDownloadFolders(keys: Collection<String>) {
        val m = downloadFolderMap().toMutableMap()
        if (keys.any { m.remove(it) != null }) saveDownloadFolderMap(m)
    }

    @Synchronized
    fun setDownloadFolder(key: String, folderId: Long) {
        val m = downloadFolderMap().toMutableMap()
        if (folderId == 0L) m.remove(key) else m[key] = folderId
        saveDownloadFolderMap(m)
    }

    companion object {
        const val KIND_BM = "bm"
        const val KIND_DL = "dl"

        /** 남겨 두는 방문 기록 수 */
        private const val HISTORY_MAX = 300

        /** 같은 주소·제목이 이 시간 안에 또 끝나면 기록 파일을 다시 쓰지 않는다 */
        private const val HISTORY_REPEAT_MS = 60_000L
    }
}

/** 홈 화면의 즐겨찾기 타일. glyph 는 아이콘 자리에 보일 글자 (비우면 이름의 첫 글자). */
data class HomeShortcut(val name: String, val url: String, val glyph: String = "")

val DEFAULT_HOME_SHORTCUTS = listOf(
    HomeShortcut("Google", "https://www.google.com", "G"),
    HomeShortcut("네이버", "https://m.naver.com", "N"),
    HomeShortcut("YouTube", "https://m.youtube.com", "▶"),
    HomeShortcut("위키백과", "https://ko.wikipedia.org", "W")
)

data class HistoryItem(val url: String, val title: String, val time: Long)

data class Folder(val id: Long, val name: String)

data class Bookmark(val id: Long, val url: String, val title: String, val folderId: Long)
