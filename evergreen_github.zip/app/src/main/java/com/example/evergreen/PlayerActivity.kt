package com.example.evergreen

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * 앱 안에 들어 있는 동영상 플레이어.
 * - mp4/webm 같은 파일과 HLS(m3u8) / DASH(mpd) 스트리밍을 재생한다.
 * - 더블탭 ±10초(연속으로 하면 누적), 길게 누르면 2배속, 세로로 쓸어서 밝기(왼쪽) / 볼륨(오른쪽), 가로로 쓸어서 시간 이동
 * - 위쪽 바: 배속(눌러서 순환) / 화면 비율(맞추기·채우기·늘리기) / 화면 회전 / 작은 창(PiP)
 * - 화질·자막은 아래쪽 컨트롤의 설정(톱니)에서. 재생 오류가 나면 '다시 시도' 버튼이 뜬다
 */
@UnstableApi
class PlayerActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_URL = "url"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_REFERER = "referer"
        private const val EXTRA_UA = "ua"
        private const val EXTRA_COOKIE = "cookie"
        private const val EXTRA_POS = "pos"

        fun start(
            ctx: Context, url: String, title: String?, referer: String?,
            userAgent: String?, cookie: String?, positionMs: Long
        ) {
            ctx.startActivity(
                Intent(ctx, PlayerActivity::class.java)
                    .putExtra(EXTRA_URL, url)
                    .putExtra(EXTRA_TITLE, title)
                    .putExtra(EXTRA_REFERER, referer)
                    .putExtra(EXTRA_UA, userAgent)
                    .putExtra(EXTRA_COOKIE, cookie)
                    .putExtra(EXTRA_POS, positionMs)
            )
            // 부드럽게 떠오르며 열린다
            (ctx as? android.app.Activity)?.overridePendingTransition(R.anim.player_in, R.anim.player_hold)
        }
    }

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var osd: TextView
    private lateinit var errorBox: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var speedChip: TextView
    private lateinit var audio: AudioManager
    private lateinit var prefs: Prefs

    private var title = ""
    private var landscapeLocked = false
    private var videoRatio = Rational(16, 9)
    private var bgServiceOn = false
    private var longPressing = false
    private var prevSpeed = 1f

    // 연속 더블탭 누적 / 가로 쓸기 시간 이동
    private var tapAcc = 0
    private var tapDir = 0
    private var lastTapAt = 0L
    private var seekStart = 0L
    private var seekTarget = -1L

    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("화면에 맞추기", "화면 채우기 (확대)", "화면 늘리기")
    private var resizeIdx = 0

    // 세로 쓸기 제스처 상태
    private var scrollMode = 0 // 0 미정, 1 세로, 2 가로(무시)
    private var gestureBrightness = 0.5f
    private var gestureVolume = 0f

    private val hideOsd = Runnable { fadeOutOsd() }
    private var resumeKey = ""
    private var resumed = false

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.player_hold, R.anim.player_out)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // 가로 화면에서 노치 쪽까지 영상이 차도록 (버튼은 아래 인셋 처리로 노치를 피한다)
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        hideSystemBars()

        val url = intent.getStringExtra(EXTRA_URL)
        if (url.isNullOrBlank()) {
            finish()
            return
        }
        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val referer = intent.getStringExtra(EXTRA_REFERER)
        val ua = intent.getStringExtra(EXTRA_UA)
        val cookie = intent.getStringExtra(EXTRA_COOKIE)
        var startPos = intent.getLongExtra(EXTRA_POS, 0L)
        // 같은 영상을 다시 열면 지난번에 보던 곳부터 (주소의 ? 뒤는 매번 바뀌는 경우가 많아 뺀다)
        resumeKey = "p" + url.substringBefore('?').hashCode()
        if (startPos <= 0L) {
            val saved = getSharedPreferences("player_pos", Context.MODE_PRIVATE).getLong(resumeKey, 0L)
            if (saved > 5_000L) {
                startPos = saved
                resumed = true
            }
        }

        buildUi()

        // 영상 서버가 요구하는 Referer / UA / 쿠키를 그대로 보낸다
        val headers = HashMap<String, String>()
        if (!referer.isNullOrBlank()) headers["Referer"] = referer
        if (!cookie.isNullOrBlank()) headers["Cookie"] = cookie
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
        if (!ua.isNullOrBlank()) http.setUserAgent(ua)

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        playerView.player = player

        val path = url.substringBefore('?').lowercase()
        val item = MediaItem.Builder().setUri(url).apply {
            when {
                path.endsWith(".m3u8") -> setMimeType(MimeTypes.APPLICATION_M3U8)
                path.endsWith(".mpd") -> setMimeType(MimeTypes.APPLICATION_MPD)
            }
        }.build()
        player.setMediaItem(item)
        if (startPos > 0) player.seekTo(startPos)
        player.prepare()
        player.playWhenReady = true

        if (resumed) playerView.post { showOsd("이어서 재생  ${fmt(startPos)}", 1800) }

        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                if (size.width > 0 && size.height > 0) {
                    val r = size.width.toFloat() / size.height
                    videoRatio = when {
                        r > 2.39f -> Rational(239, 100)
                        r < 0.4184f -> Rational(100, 239)
                        else -> Rational(size.width, size.height)
                    }
                    // 가로 영상이면 처음 한 번 가로 화면으로
                    if (!landscapeLocked && size.width >= size.height) {
                        landscapeLocked = true
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                    updatePipParams()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePipParams()
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                updateSpeedChip(playbackParameters.speed)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY || state == Player.STATE_BUFFERING) errorBox.visibility = View.GONE
            }

            override fun onPlayerError(error: PlaybackException) {
                errorText.text = "재생할 수 없는 영상이에요\n(${error.errorCodeName})"
                errorBox.alpha = 0f
                errorBox.visibility = View.VISIBLE
                errorBox.animate().alpha(1f).setDuration(220).start()
                playerView.showController()
            }
        })
    }

    // ───────────────────────── 화면 구성 ─────────────────────────

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val accent = getColor(R.color.ev_accent)

        playerView = PlayerView(this).apply {
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            controllerShowTimeoutMs = 3000
            setShowSubtitleButton(true)
            setShowRewindButton(true)
            setShowFastForwardButton(true)
            setShowPreviousButton(false)
            setShowNextButton(false)
            keepScreenOn = true
        }
        root.addView(playerView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        // 컨트롤: 위·아래만 어두워지는 그라데이션(밝은 영상 위에서도 글자가 보이게), 진행 막대는 앱 포인트 색
        playerView.findViewById<View>(androidx.media3.ui.R.id.exo_controls_background)?.background =
            GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xB3000000.toInt(), 0x22000000, 0x22000000, 0xCC000000.toInt())
            )
        (playerView.findViewById<View>(androidx.media3.ui.R.id.exo_progress) as? DefaultTimeBar)?.apply {
            setPlayedColor(accent)
            setScrubberColor(accent)
            setBufferedColor(0x66FFFFFF)
            setUnplayedColor(0x33FFFFFF)
        }

        // 위쪽 바: 뒤로 / 제목·사이트 / 배속 / 화면 비율 / 회전 / PiP  (컨트롤이 보일 때만 보인다)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        fun circleBtn(res: Int, desc: String, onClick: () -> Unit) = ImageButton(this).apply {
            setImageResource(res)
            setColorFilter(Color.WHITE)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x40000000)
            }
            contentDescription = desc
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setOnClickListener { onClick() }
            Motion.pressable(this, 0.86f)
        }
        fun lp(w: Int, h: Int, start: Int = 8) =
            LinearLayout.LayoutParams(w, h).apply { marginStart = dp(start) }

        bar.addView(circleBtn(R.drawable.ic_back, "닫기") { finish() }, lp(dp(40), dp(40), 0))

        val host = runCatching { android.net.Uri.parse(intent.getStringExtra(EXTRA_URL)).host }
            .getOrNull().orEmpty().removePrefix("www.")
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        titleCol.addView(TextView(this).apply {
            text = title.ifBlank { host.ifBlank { "동영상" } }
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        if (title.isNotBlank() && host.isNotBlank()) {
            titleCol.addView(TextView(this).apply {
                text = host
                setTextColor(0xB3FFFFFF.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
        }
        bar.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })

        speedChip = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(52)
            setPadding(dp(12), 0, dp(12), 0)
            contentDescription = "재생 속도"
            setOnClickListener { cycleSpeed() }
            Motion.pressable(this, 0.92f)
        }
        updateSpeedChip(1f)
        bar.addView(speedChip, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)))
        bar.addView(circleBtn(R.drawable.ic_aspect, "화면 비율") { cycleResize() }, lp(dp(40), dp(40)))
        bar.addView(circleBtn(R.drawable.ic_rotate, "화면 회전") { toggleOrientation() }, lp(dp(40), dp(40)))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            bar.addView(circleBtn(R.drawable.ic_pip, "작은 창으로 보기") { enterPip() }, lp(dp(40), dp(40)))
        }
        topBar = bar
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            animateTopBar(v == View.VISIBLE)
        })
        // 노치(카메라 구멍)가 있는 쪽은 버튼이 가리지 않게 비워 둔다
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val c = insets.getInsets(WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.systemBars())
            topBar.setPadding(dp(10) + c.left, dp(10) + c.top, dp(10) + c.right, dp(10))
            insets
        }

        // 가운데 표시창 (밝기·볼륨·시간 이동 등)
        osd = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xCC000000.toInt())
            }
            visibility = View.GONE
        }
        root.addView(osd, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        // 재생 오류 화면: 안내 + 다시 시도
        errorText = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
        }
        val retry = Button(this).apply {
            text = "다시 시도"
            isAllCaps = false
            stateListAnimator = null
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(accent)
            }
            setPadding(dp(24), 0, dp(24), 0)
            setOnClickListener {
                errorBox.visibility = View.GONE
                player.prepare()
                player.playWhenReady = true
            }
        }
        errorBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(22), dp(28), dp(22))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xE6121212.toInt())
            }
            visibility = View.GONE
            addView(errorText)
            addView(retry, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { topMargin = dp(16) })
        }
        root.addView(errorBox, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        setContentView(root)
        setupGestures()
    }

    /** 위쪽 바가 위에서 살짝 내려오며 나타나고, 사라질 땐 위로 올라가며 흐려진다 */
    private fun animateTopBar(show: Boolean) {
        topBar.animate().cancel()
        if (show) {
            if (topBar.visibility != View.VISIBLE) {
                topBar.alpha = 0f
                topBar.translationY = -dp(12).toFloat()
                topBar.visibility = View.VISIBLE
            }
            topBar.animate().alpha(1f).translationY(0f).setDuration(200)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f)).start()
        } else {
            topBar.animate().alpha(0f).translationY(-dp(8).toFloat()).setDuration(180)
                .withEndAction { if (topBar.alpha <= 0.01f) topBar.visibility = View.GONE }.start()
        }
    }

    // ───────────────────────── 배속 / 화면 비율 ─────────────────────────

    private fun speedLabel(v: Float) = if (v % 1f == 0f) "${v.toInt()}x" else "${v}x"

    private fun updateSpeedChip(speed: Float) {
        speedChip.text = speedLabel(speed)
        // 1배속이 아니면 포인트 색으로 눈에 띄게
        val bg = if (abs(speed - 1f) < 0.01f) 0x40000000 else getColor(R.color.ev_accent)
        speedChip.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(bg)
        }
    }

    private fun cycleSpeed() {
        val cur = player.playbackParameters.speed
        val i = speeds.indexOfFirst { abs(it - cur) < 0.01f }
        val next = if (i < 0) 1f else speeds[(i + 1) % speeds.size]
        player.setPlaybackSpeed(next)
        showOsd("${speedLabel(next)} 배속")
    }

    private fun cycleResize() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        playerView.resizeMode = resizeModes[resizeIdx]
        showOsd(resizeNames[resizeIdx])
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(java.util.Locale.US, "%d:%02d", m, sec)
    }

    private fun setupGestures() {
        gestureBrightness = window.attributes.screenBrightness.takeIf { it >= 0f } ?: 0.5f
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scrollMode = 0
                seekStart = player.currentPosition
                seekTarget = -1L
                gestureVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController() else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val left = e.x < playerView.width / 2f
                val dir = if (left) -1 else 1
                // 같은 쪽을 연달아 두 번 탭하면 20초, 30초… 로 쌓여서 표시
                val now = SystemClock.uptimeMillis()
                tapAcc = if (dir == tapDir && now - lastTapAt < 900) tapAcc + 10 else 10
                tapDir = dir
                lastTapAt = now
                val target = (player.currentPosition + dir * 10_000L)
                    .coerceIn(0L, if (player.duration > 0) player.duration else Long.MAX_VALUE)
                player.seekTo(target)
                showOsd(
                    if (left) "⏪ ${tapAcc}초" else "${tapAcc}초 ⏩", 700,
                    if (left) Gravity.CENTER_VERTICAL or Gravity.START else Gravity.CENTER_VERTICAL or Gravity.END
                )
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!player.isPlaying) return
                longPressing = true
                playerView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                prevSpeed = player.playbackParameters.speed
                player.playbackParameters = PlaybackParameters(2f)
                showOsd("2배속", 100_000)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || longPressing) return false
                if (scrollMode == 0) {
                    scrollMode = if (abs(dy) > abs(dx)) 1 else 2
                }
                if (scrollMode == 2) {
                    // 가로로 쓸어서 시간 이동 (화면 폭 전체 = 최대 2분). 손을 떼면 그 위치로 이동
                    val dur = player.duration
                    if (dur <= 0 || !player.isCurrentMediaItemSeekable) return false
                    val total = e2.x - e1.x
                    val span = minOf(dur, 120_000L)
                    seekTarget = (seekStart + total / playerView.width.coerceAtLeast(1) * span).toLong().coerceIn(0L, dur)
                    val diff = (seekTarget - seekStart) / 1000
                    showOsd("${fmt(seekTarget)} / ${fmt(dur)}\n${if (diff >= 0) "+" else ""}${diff}초", 1500)
                    return true
                }
                if (scrollMode != 1) return false
                val h = playerView.height.toFloat().coerceAtLeast(1f)
                if (e1.x < playerView.width / 2f) {
                    gestureBrightness = (gestureBrightness + dy / h).coerceIn(0.02f, 1f)
                    window.attributes = window.attributes.apply { screenBrightness = gestureBrightness }
                    showOsd("☀  ${levelBar(gestureBrightness)}  ${(gestureBrightness * 100).roundToInt()}%")
                } else {
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    gestureVolume = (gestureVolume + dy / h * max * 1.2f).coerceIn(0f, max.toFloat())
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, gestureVolume.roundToInt(), 0)
                    showOsd("🔊  ${levelBar(gestureVolume / max)}  ${(gestureVolume / max * 100).roundToInt()}%")
                }
                return true
            }
        })
        playerView.setOnTouchListener { v, ev ->
            val handled = detector.onTouchEvent(ev)
            if ((ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL)) {
                if (longPressing) {
                    longPressing = false
                    player.playbackParameters = PlaybackParameters(prevSpeed)
                    ui.removeCallbacks(hideOsd)
                    fadeOutOsd()
                }
                if (ev.actionMasked == MotionEvent.ACTION_UP && seekTarget >= 0) {
                    player.seekTo(seekTarget)
                    ui.removeCallbacks(hideOsd)
                    ui.postDelayed(hideOsd, 500)
                }
                seekTarget = -1L
                if (ev.actionMasked == MotionEvent.ACTION_UP) v.performClick()
            }
            handled
        }
    }

    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    private fun showOsd(text: String, hideAfterMs: Long = 700, gravity: Int = Gravity.CENTER) {
        (osd.layoutParams as FrameLayout.LayoutParams).let { lp ->
            if (lp.gravity != gravity) {
                lp.gravity = gravity
                lp.marginStart = if ((gravity and Gravity.START) == Gravity.START) dp(56) else 0
                lp.marginEnd = if ((gravity and Gravity.END) == Gravity.END) dp(56) else 0
                osd.layoutParams = lp
            }
        }
        osd.text = text
        ui.removeCallbacks(hideOsd)
        if (osd.visibility != View.VISIBLE || osd.alpha < 1f) {
            // 톡 하고 커지며 나타난다
            osd.animate().cancel()
            if (osd.visibility != View.VISIBLE) {
                osd.alpha = 0f
                osd.scaleX = 0.9f
                osd.scaleY = 0.9f
            }
            osd.visibility = View.VISIBLE
            osd.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
        ui.postDelayed(hideOsd, hideAfterMs)
    }

    private fun fadeOutOsd() {
        osd.animate().cancel()
        osd.animate().alpha(0f).scaleX(0.95f).scaleY(0.95f).setDuration(160)
            .withEndAction { if (osd.alpha <= 0.01f) osd.visibility = View.GONE }.start()
    }

    private fun levelBar(f: Float): String {
        val n = (f.coerceIn(0f, 1f) * 10).roundToInt()
        return "█".repeat(n) + "░".repeat(10 - n)
    }

    private fun toggleOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        landscapeLocked = true
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    // ───────────────────────── PiP ─────────────────────────

    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val b = PictureInPictureParams.Builder().setAspectRatio(videoRatio)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) b.setAutoEnterEnabled(player.isPlaying)
            setPictureInPictureParams(b.build())
        } catch (e: Exception) {
            // 무시
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(videoRatio).build())
        } catch (e: Exception) {
            // 무시
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && ::player.isInitialized && player.isPlaying) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        playerView.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            osd.visibility = View.GONE
        } else if (!lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            // 작은 창의 X 로 닫은 경우
            player.pause()
            finish()
        }
    }

    // ───────────────────────── 수명 주기 ─────────────────────────

    override fun onStart() {
        super.onStart()
        if (bgServiceOn) {
            bgServiceOn = false
            MediaBridge.playerStop = null
            MediaService.stop(this)
        }
    }

    /** 보던 위치를 기억해 둔다 (끝부분이거나 라이브면 지운다) */
    private fun savePosition() {
        if (!::player.isInitialized || resumeKey.isEmpty()) return
        val dur = player.duration
        val pos = player.currentPosition
        val sp = getSharedPreferences("player_pos", Context.MODE_PRIVATE)
        val e = sp.edit()
        if (dur > 0 && pos > 5_000L && pos < dur - 10_000L) {
            if (sp.all.size > 200) e.clear()
            e.putLong(resumeKey, pos)
        } else {
            e.remove(resumeKey)
        }
        e.apply()
    }

    override fun onStop() {
        super.onStop()
        savePosition()
        if (!::player.isInitialized || isInPictureInPictureMode) return
        if (prefs.backgroundAudio && player.isPlaying && !isFinishing) {
            // 화면을 끄거나 앱을 나가도 소리는 계속 (알림의 '정지' 로 멈춤)
            bgServiceOn = true
            MediaBridge.playerStop = { ui.post { player.pause() } }
            MediaService.start(this, title.ifBlank { "재생 중" }, "내장 플레이어")
        } else {
            player.pause()
        }
    }

    override fun onDestroy() {
        savePosition()
        ui.removeCallbacks(hideOsd)
        if (bgServiceOn) {
            MediaBridge.playerStop = null
            MediaService.stop(this)
        }
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
