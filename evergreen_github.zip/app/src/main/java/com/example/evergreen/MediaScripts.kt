package com.example.evergreen

/** 페이지 안에서 돌아가는 스크립트 모음 (재생 상태 알림 / 일시정지 / PiP 용 화면 꾸미기) */
object MediaScripts {

    /**
     * 모든 프레임에서 문서 시작 시점에 실행된다.
     * - 영상/소리 재생 상태가 바뀌면 EvMedia.state() 로 앱에 알린다.
     * - 백그라운드 재생이 켜져 있으면 페이지가 "숨겨짐"을 감지해 스스로 멈추지 못하게 가시성 API 를 가린다.
     * - postMessage({__ev:'pause'}) 를 받으면 (iframe 포함) 재생 중인 미디어를 멈춘다.
     */
    const val INJECT = """
(function(){
 if(window.__evMedia) return; window.__evMedia=1;
 var fid=Math.random().toString(36).slice(2);
 function bg(){try{return EvMedia.bg()}catch(e){return false}}
 try{
  var dh=Object.getOwnPropertyDescriptor(Document.prototype,'hidden');
  var dv=Object.getOwnPropertyDescriptor(Document.prototype,'visibilityState');
  Object.defineProperty(document,'hidden',{configurable:true,get:function(){return bg()?false:dh.get.call(document)}});
  Object.defineProperty(document,'visibilityState',{configurable:true,get:function(){return bg()?'visible':dv.get.call(document)}});
  var stop=function(e){if(bg())e.stopImmediatePropagation()};
  window.addEventListener('visibilitychange',stop,true);
  document.addEventListener('visibilitychange',stop,true);
 }catch(e){}
 var last='';
 function chk(){
  var m=document.querySelectorAll('video,audio'),p=false,v=false,w=0,h=0;
  for(var i=0;i<m.length;i++){var x=m[i];
   if(!x.paused&&!x.ended&&x.readyState>2){p=true;
    if(x.tagName=='VIDEO'&&x.videoWidth>0&&!v){v=true;w=x.videoWidth;h=x.videoHeight}}}
  pv=p&&v; sched();
  var k=p+','+v+','+w+','+h;
  if(k===last)return; last=k;
  try{EvMedia.state(fid,p,v,w,h)}catch(e){}
 }
 /* ── 재생 중인 영상의 화면 위치를 앱에 알린다 (영상 아래에 '내장 플레이어' 버튼을 띄우기 위해) ──
    위치는 보이는 화면(visualViewport) 대비 비율로 보낸다. iframe 안의 영상은 부모 프레임이 오프셋을 더해 위로 전달한다. */
 var pv=false,lastR='',pend=false,kids={},lastK={},nk=0;
 function vp(){var q=window.visualViewport;return q?{w:q.width,h:q.height,x:q.offsetLeft,y:q.offsetTop}:{w:innerWidth,h:innerHeight,x:0,y:0}}
 function up(l,t,w,h,iw,ih,id){
  if(window===window.top){
   var q=vp(),a=q.w>0&&q.h>0&&w>0&&h>0;
   try{EvMedia.rect(id,a?(l-q.x)/q.w:0,a?(t-q.y)/q.h:0,a?w/q.w:0,a?h/q.h:0)}catch(e){}
  }else{
   try{window.parent.postMessage({__ev:'rect',id:id,l:l,t:t,w:w,h:h,iw:iw,ih:ih},'*')}catch(e){}
  }
 }
 function repSelf(){
  var best=null,ba=0,m=document.querySelectorAll('video');
  for(var i=0;i<m.length;i++){var x=m[i];
   if(x.paused||x.ended||x.readyState<=2||!(x.videoWidth>0))continue;
   var r=x.getBoundingClientRect(),ar=r.width*r.height;
   if(ar>ba){ba=ar;best=r}}
  var key=best?[best.left,best.top,best.width,best.height,innerWidth,innerHeight].map(Math.round).join():'';
  if(key===lastR)return; lastR=key;
  if(best)up(best.left,best.top,best.width,best.height,innerWidth,innerHeight,fid);
  else up(0,0,0,0,innerWidth,innerHeight,fid);
 }
 function fwd(id){
  var d=kids[id]; if(!d)return;
  var f=document.querySelectorAll('iframe'),ir=null;
  for(var j=0;j<f.length;j++){try{if(f[j].contentWindow===d.src){ir=f[j].getBoundingClientRect();break}}catch(x){}}
  var l=0,t=0,w=0,h=0;
  if(ir&&d.w>0&&d.iw>0&&d.ih>0){var sx=ir.width/d.iw,sy=ir.height/d.ih;l=ir.left+d.l*sx;t=ir.top+d.t*sy;w=d.w*sx;h=d.h*sy}
  var key=[l,t,w,h,innerWidth,innerHeight].map(Math.round).join();
  if(lastK[id]!==key){lastK[id]=key;up(l,t,w,h,innerWidth,innerHeight,id)}
  if(!(d.w>0)){delete kids[id];delete lastK[id];nk--}
 }
 function rep(){repSelf();for(var id in kids)fwd(id)}
 function sched(){if(pend)return;pend=true;requestAnimationFrame(function(){pend=false;rep()})}
 function act(){return pv||nk>0}
 window.addEventListener('scroll',function(){if(act())sched()},{capture:true,passive:true});
 window.addEventListener('resize',function(){if(act())sched()},true);
 setInterval(function(){if(act())sched()},1000);
 ['play','playing','pause','ended','emptied','loadeddata'].forEach(function(n){
  document.addEventListener(n,function(){setTimeout(chk,60)},true);
 });
 setInterval(function(){if(document.querySelector('video,audio'))chk()},2500);
 window.addEventListener('pagehide',function(){last='';lastR='';pv=false;try{EvMedia.state(fid,false,false,0,0)}catch(e){}up(0,0,0,0,innerWidth,innerHeight,fid)});
 window.addEventListener('message',function(e){
  var d=e.data; if(!d)return;
  if(d.__ev==='rect'){
   if(typeof d.id!=='string')return;
   if(!kids[d.id])nk++;
   kids[d.id]={src:e.source,l:+d.l||0,t:+d.t||0,w:+d.w||0,h:+d.h||0,iw:+d.iw||0,ih:+d.ih||0};
   fwd(d.id);
   return;
  }
  if(d.__ev!=='pause')return;
  var m=document.querySelectorAll('video,audio');
  for(var i=0;i<m.length;i++){try{m[i].pause()}catch(x){}}
  var f=document.querySelectorAll('iframe');
  for(var j=0;j<f.length;j++){try{f[j].contentWindow.postMessage(d,'*')}catch(x){}}
 },false);
})();
"""

    /** 내장 플레이어로 넘길 영상 주소를 찾는다 (blob/data 는 제외). 재생 중인 것이 앞에 온다. */
    const val FIND_MEDIA = """
(function(){
 var out=[],seen={};
 function add(u,t,p){
  if(!u||u.indexOf('blob:')==0||u.indexOf('data:')==0) return;
  try{u=new URL(u,location.href).href}catch(e){return}
  if(seen[u]) return; seen[u]=1; out.push({u:u,t:t||0,p:!!p});
 }
 var ms=document.querySelectorAll('video,audio');
 for(var i=0;i<ms.length;i++){
  var m=ms[i],p=!m.paused&&!m.ended;
  add(m.currentSrc,m.currentTime,p); add(m.getAttribute('src'),m.currentTime,p);
  var ss=m.querySelectorAll('source');
  for(var j=0;j<ss.length;j++) add(ss[j].src,m.currentTime,p);
 }
 out.sort(function(a,b){return (b.p?1:0)-(a.p?1:0)});
 return JSON.stringify({title:document.title,items:out});
})();
"""

    const val PAUSE_ALL = "window.postMessage({__ev:'pause'},'*');"

    /** 작은 창(PiP)에서 재생 중인 동영상만 화면 가득 보이게 한다. */
    const val PIP_ON = """
(function(){
 var vs=[].slice.call(document.querySelectorAll('video'));
 if(!vs.length) return '';
 var v=null;
 for(var i=0;i<vs.length;i++){if(!vs[i].paused&&!vs[i].ended){v=vs[i];break}}
 if(!v){vs.sort(function(a,b){return b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight});v=vs[0]}
 var st=document.getElementById('__ev_pip_style');
 if(!st){st=document.createElement('style');st.id='__ev_pip_style';document.documentElement.appendChild(st)}
 st.textContent='html,body{overflow:hidden!important;background:#000!important}'
  +'body *{visibility:hidden!important}'
  +'video.__ev_pip{visibility:visible!important;position:fixed!important;top:0!important;left:0!important;'
  +'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;'
  +'z-index:2147483647!important;background:#000!important;object-fit:contain!important;transform:none!important}';
 v.classList.add('__ev_pip');
 return 'ok';
})();
"""

    const val PIP_OFF = """
(function(){
 var st=document.getElementById('__ev_pip_style'); if(st) st.remove();
 var m=document.querySelectorAll('video.__ev_pip');
 for(var i=0;i<m.length;i++) m[i].classList.remove('__ev_pip');
})();
"""
}
