package com.example.evergreen

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import java.util.WeakHashMap

/**
 * 스프링(물리 기반) 애니메이션 모음.
 * 고정된 시간·곡선 대신 용수철 물리를 써서 속도가 이어지고, 끊기거나 중간에 바뀌어도 자연스럽게 이어진다.
 * 시스템의 "애니메이션 끄기" 설정을 따른다.
 */
object Motion {
    private val running = WeakHashMap<View, HashMap<DynamicAnimation.ViewProperty, SpringAnimation>>()

    fun enabled(ctx: Context): Boolean =
        Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f

    private fun dp(v: View, n: Float) = n * v.resources.displayMetrics.density

    private fun minChange(p: DynamicAnimation.ViewProperty): Float = when (p) {
        DynamicAnimation.ALPHA -> DynamicAnimation.MIN_VISIBLE_CHANGE_ALPHA
        DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y -> DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE
        DynamicAnimation.ROTATION -> DynamicAnimation.MIN_VISIBLE_CHANGE_ROTATION_DEGREES
        else -> DynamicAnimation.MIN_VISIBLE_CHANGE_PIXELS
    }

    /** 같은 뷰·같은 속성의 이전 스프링은 현재 값에서 멈추고, 새 스프링이 그 위치에서 이어서 움직인다. */
    fun spring(
        v: View,
        prop: DynamicAnimation.ViewProperty,
        target: Float,
        stiffness: Float = SpringForce.STIFFNESS_LOW,
        damping: Float = SpringForce.DAMPING_RATIO_LOW_BOUNCY,
        onEnd: (() -> Unit)? = null
    ): SpringAnimation {
        val map = running.getOrPut(v) { HashMap() }
        map[prop]?.cancel()
        val a = SpringAnimation(v, prop)
        a.setSpring(SpringForce(target).setStiffness(stiffness).setDampingRatio(damping))
        a.setMinimumVisibleChange(minChange(prop))
        a.addEndListener { _, canceled, _, _ ->
            if (map[prop] === a) map.remove(prop)
            if (!canceled) onEnd?.invoke()
        }
        map[prop] = a
        a.start()
        return a
    }

    fun cancel(v: View) {
        running.remove(v)?.values?.forEach { it.cancel() }
    }

    /** 아래에서 떠오르며 살짝 커지면서 나타난다. 여러 개면 delay 를 늘려 물결처럼 이어지게 한다. */
    fun enter(v: View, delayMs: Long = 0, rise: Float = 20f) {
        if (!enabled(v.context)) return
        cancel(v)
        v.alpha = 0f
        v.translationY = dp(v, rise)
        v.scaleX = 0.94f
        v.scaleY = 0.94f
        val start = Runnable {
            spring(v, DynamicAnimation.ALPHA, 1f, 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            spring(v, DynamicAnimation.TRANSLATION_Y, 0f, 220f, 0.72f)
            spring(v, DynamicAnimation.SCALE_X, 1f, 260f, 0.62f)
            spring(v, DynamicAnimation.SCALE_Y, 1f, 260f, 0.62f)
        }
        if (delayMs <= 0) v.post(start) else v.postDelayed(start, delayMs)
    }

    /** 자식 뷰들을 차례로 떠오르게 한다. */
    fun stagger(parent: ViewGroup, startDelay: Long = 0, step: Long = 38, maxDelay: Long = 320) {
        for (i in 0 until parent.childCount) {
            enter(parent.getChildAt(i), minOf(startDelay + i * step, maxDelay))
        }
    }

    /** 작게 시작해 통통 튀며 커진다 (숫자 배지 등). */
    fun pop(v: View, from: Float = 0.55f) {
        if (!enabled(v.context)) return
        v.scaleX = from
        v.scaleY = from
        spring(v, DynamicAnimation.SCALE_X, 1f, 420f, 0.42f)
        spring(v, DynamicAnimation.SCALE_Y, 1f, 420f, 0.42f)
    }

    /** 옆으로 살짝 기울어지며 날아가듯 사라진다. */
    fun flyAway(v: View, toRight: Boolean = true, onEnd: () -> Unit) {
        if (!enabled(v.context)) {
            onEnd()
            return
        }
        val dir = if (toRight) 1f else -1f
        spring(v, DynamicAnimation.ALPHA, 0f, 520f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.ROTATION, 5f * dir, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.SCALE_X, 0.88f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.SCALE_Y, 0.88f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.TRANSLATION_X, dir * dp(v, 140f), 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY, onEnd)
    }

    /**
     * 목록이 다시 그려질 때 남은 항목들이 예전 위치에서 새 위치로 미끄러지듯 이동하게 한다.
     * before: 다시 그리기 직전의 화면상 위치.
     */
    fun glideFrom(parent: View, items: Map<View, Pair<Int, Int>>) {
        if (!enabled(parent.context) || items.isEmpty()) return
        parent.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                parent.viewTreeObserver.removeOnPreDrawListener(this)
                val loc = IntArray(2)
                items.forEach { (view, old) ->
                    view.getLocationOnScreen(loc)
                    val dx = (old.first - loc[0]).toFloat()
                    val dy = (old.second - loc[1]).toFloat()
                    if (dx != 0f || dy != 0f) {
                        view.translationX = dx
                        view.translationY = dy
                        spring(view, DynamicAnimation.TRANSLATION_X, 0f, 380f, 0.78f)
                        spring(view, DynamicAnimation.TRANSLATION_Y, 0f, 380f, 0.78f)
                    }
                }
                return true
            }
        })
    }

    /** 누르면 쏙 들어갔다가, 떼면 탄성 있게 튀어 돌아온다. */
    @SuppressLint("ClickableViewAccessibility")
    fun pressable(v: View, pressedScale: Float = 0.9f) {
        v.setOnTouchListener { view, e ->
            if (enabled(view.context)) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        spring(view, DynamicAnimation.SCALE_X, pressedScale, 1100f, 0.9f)
                        spring(view, DynamicAnimation.SCALE_Y, pressedScale, 1100f, 0.9f)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        spring(view, DynamicAnimation.SCALE_X, 1f, 480f, 0.36f)
                        spring(view, DynamicAnimation.SCALE_Y, 1f, 480f, 0.36f)
                    }
                }
            }
            false
        }
    }
}
