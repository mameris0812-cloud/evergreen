package com.example.evergreen

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.PictureInPictureParams
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.RectF
import android.view.ViewOutlineProvider
import android.widget.ScrollView
import androidx.core.view.doOnLayout
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Rational
import android.util.TypedValue
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringForce
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Filter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import org.json.JSONArray
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class BrowserTab(val webView: WebView) {
    var progress: Int = 100
    var rate: Float = 1f

    /** 0 = 그룹 없음 */
    var groupId: Int = 0

    /** 이번 페이지 로드에서 광고 숨김 CSS를 이미 넣었는지 */
    var cosmeticInjected: Boolean = false

    var favicon: Bitmap? = null

    /** 탭 화면에 보여줄 페이지 미리보기 (탭을 떠날 때 / 탭 화면을 열 때 갱신) */
    var thumb: Bitmap? = null

    /** 이 탭을 연 탭 (뒤로가기로 탭을 닫으면 여기로 돌아간다) */
    var opener: BrowserTab? = null

    /** 데스크톱 사이트 요청 */
    var desktop: Boolean = false

    /** 새 탭 홈 화면을 보여주는 중인지 */
    var isHome: Boolean = false
}

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var adBlocker: AdBlocker

    private lateinit var urlBar: AutoCompleteTextView
    private lateinit var progressBar: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnTabs: View
    private lateinit var tabCount: TextView
    private lateinit var btnMenu: ImageButton
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var browserUi: View
    private lateinit var bottomBar: View
    private lateinit var tabStripBar: View
    private lateinit var tabStripScroll: HorizontalScrollView
    private lateinit var tabStrip: LinearLayout
    private lateinit var navGroup: View
    private lateinit var tbBack: ImageButton
    private lateinit var tbForward: ImageButton
    private lateinit var tbRefresh: ImageButton
    private lateinit var tbHome: ImageButton
    private lateinit var tbMenu: ImageButton
    private lateinit var homeView: View
    private lateinit var homeContent: View
    private lateinit var tabSwitcher: View
    private lateinit var tabList: LinearLayout
    private lateinit var tabScroll: ScrollView
    private lateinit var tabsTitle: TextView
    private lateinit var tabMorph: ImageView
    private var switcherOpen = false
    private var switcherBusy = false
    private val switcherRows = HashMap<BrowserTab, View>()
    private var morphRadius = 0f
    private lateinit var homeSearch: EditText

    /** 태블릿(넓은 화면) 레이아웃 사용 중인지 */
    private var expanded = false
    private var stripRefreshQueued = false
    private var lastStripCurrent: BrowserTab? = null
    private var baseUserAgent: String = ""

    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null

    private val groups = mutableListOf<TabGroup>()
    private var nextGroupId = 1

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    @Volatile
    private var adBlockEnabled = true

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val suggestItems = mutableListOf<String>()
    private lateinit var suggestAdapter: NoFilterAdapter
    private var suggestRunnable: Runnable? = null
    private var suppressWatcher = false
    private var askedNotificationPermission = false

    // ───────────────────────── 생명주기 ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlBar = findViewById(R.id.urlBar)
        progressBar = findViewById(R.id.progressBar)
        webContainer = findViewById(R.id.webContainer)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnHome = findViewById(R.id.btnHome)
        btnTabs = findViewById(R.id.btnTabs)
        tabCount = findViewById(R.id.tabCount)
        btnMenu = findViewById(R.id.btnMenu)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        browserUi = findViewById(R.id.browserUi)
        bottomBar = findViewById(R.id.bottomBar)
        tabStripBar = findViewById(R.id.tabStripBar)
        tabStripScroll = findViewById(R.id.tabStripScroll)
        tabStrip = findViewById(R.id.tabStrip)
        navGroup = findViewById(R.id.navGroup)
        tbBack = findViewById(R.id.tbBack)
        tbForward = findViewById(R.id.tbForward)
        tbRefresh = findViewById(R.id.tbRefresh)
        tbHome = findViewById(R.id.tbHome)
        tbMenu = findViewById(R.id.tbMenu)
        homeView = findViewById(R.id.homeView)
        homeContent = findViewById(R.id.homeContent)
        tabSwitcher = findViewById(R.id.tabSwitcher)
        tabList = findViewById(R.id.tabList)
        tabScroll = findViewById(R.id.tabScroll)
        tabsTitle = findViewById(R.id.tabsTitle)
        tabMorph = findViewById(R.id.tabMorph)
        homeSearch = findViewById(R.id.homeSearch)

        prefs = Prefs(this)
        adBlocker = AdBlocker(this)
        adBlockEnabled = prefs.adBlock
        io.execute { adBlocker.load() }
        autoUpdateAdBlockList()

        CookieManager.getInstance().setAcceptCookie(true)

        applyLayoutMode()
        setupUrlBar()
        setupControls()
        setupHome()
        setupBackHandler()
        setupTabSwitcher()

        val startUrl = intent?.data?.toString()

        createTab(startUrl, home = startUrl == null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayoutMode()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let { createTab(it.toString()) }
    }

    override fun onPause() {
        super.onPause()
        if (!isInPictureInPictureMode) tabs.forEach { it.webView.onPause() }
        CookieManager.getInstance().flush()
    }

    override fun onResume() {
        super.onResume()
        current?.webView?.onResume()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // 전체화면 영상 재생 중 홈으로 나가면 작은 창(PiP)으로 계속 재생
        if (customView != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (e: Exception) {
                // PiP 불가 시 무시
            }
        }
    }

    override fun onDestroy() {
        tabs.forEach {
            it.webView.stopLoading()
            (it.webView.parent as? ViewGroup)?.removeView(it.webView)
            it.webView.destroy()
        }
        tabs.clear()
        io.shutdown()
        super.onDestroy()
    }

    // ───────────────────────── 탭 ─────────────────────────

    private fun homeUrl(): String = SearchEngines.byKey(prefs.engineKey).homeUrl

    private fun createTab(
        url: String?,
        select: Boolean = true,
        opener: BrowserTab? = null,
        home: Boolean = false
    ): BrowserTab {
        val tab = BrowserTab(WebView(this))
        tab.webView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        tab.isHome = home
        configure(tab)
        // 링크/팝업으로 열린 탭은 연 탭 바로 옆에 두고, 같은 그룹에 넣는다.
        tab.opener = opener
        val at = if (opener != null) tabs.indexOf(opener) else -1
        if (opener != null && at >= 0) {
            tab.groupId = opener.groupId
            tabs.add(at + 1, tab)
        } else {
            tabs.add(tab)
        }
        if (select) selectTab(tab)
        if (url != null) tab.webView.loadUrl(url)
        updateTabCount()
        return tab
    }

    private fun selectTab(tab: BrowserTab) {
        current?.let {
            // 탭 화면의 카드에 보여줄 미리보기를 남겨 둔다 (탭 화면이 열려 있을 땐 이미 찍어 둠)
            if (it !== tab && !switcherOpen) it.thumb = captureContent()
            webContainer.removeView(it.webView)
            if (it !== tab) it.webView.onPause()
        }
        current = tab
        groupOf(tab)?.collapsed = false
        webContainer.addView(tab.webView)
        Motion.cancel(tab.webView)
        if (switcherOpen) {
            // 탭 화면에서 고른 경우: 카드가 펼쳐지는 전환이 대신 보여주므로 여기선 바로 표시
            tab.webView.alpha = 1f
            tab.webView.scaleX = 1f
            tab.webView.scaleY = 1f
        } else {
            tab.webView.alpha = 0f
            tab.webView.scaleX = 0.97f
            tab.webView.scaleY = 0.97f
            Motion.spring(tab.webView, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_X, 1f, 260f, 0.8f)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_Y, 1f, 260f, 0.8f)
        }
        tab.webView.onResume()
        tab.webView.requestFocus()
        updateUi()
    }

    private fun closeTab(tab: BrowserTab) {
        if (tabs.size == 1) {
            tab.groupId = 0
            pruneEmptyGroups()
            tab.isHome = true
            tab.thumb = null
            tab.webView.stopLoading()
            tab.webView.loadUrl("about:blank")
            updateUi()
            return
        }
        val index = tabs.indexOf(tab)
        tabs.remove(tab)
        tabs.forEach { if (it.opener === tab) it.opener = null }
        if (tab === current) {
            webContainer.removeView(tab.webView)
            current = null
            // 링크로 열린 탭을 닫으면 그 탭을 연 탭으로 돌아간다.
            val next = tab.opener?.takeIf { it in tabs } ?: tabs[minOf(index, tabs.size - 1)]
            selectTab(next)
        }
        tab.webView.stopLoading()
        tab.webView.destroy()
        pruneEmptyGroups()
        updateTabCount()
    }

    private fun updateTabCount() {
        val n = tabs.size.toString()
        if (tabCount.text.toString() != n) {
            tabCount.text = n
            Motion.pop(tabCount)
        }
        scheduleStripRefresh()
    }

    // ───────────────────────── 탭 그룹 ─────────────────────────

    private fun groupOf(tab: BrowserTab): TabGroup? =
        if (tab.groupId == 0) null else groups.firstOrNull { it.id == tab.groupId }

    private fun nextGroupColor(): Int = TabGroup.COLORS[groups.size % TabGroup.COLORS.size]

    private fun defaultGroupName(): String = "그룹 $nextGroupId"

    private fun createGroup(name: String, color: Int): TabGroup {
        val g = TabGroup(nextGroupId++, name, color)
        groups.add(g)
        return g
    }

    /** 탭이 하나도 없는 그룹은 자동으로 사라진다. */
    private fun pruneEmptyGroups() {
        groups.removeAll { g -> tabs.none { it.groupId == g.id } }
    }

    /** group == null 이면 그룹에서 빼낸다. 그룹으로 넣을 때는 그 그룹의 마지막 탭 바로 뒤로 옮겨 붙어 있게 한다. */
    private fun moveToGroup(tab: BrowserTab, group: TabGroup?) {
        if (group == null) {
            tab.groupId = 0
        } else {
            val old = tabs.indexOf(tab)
            tabs.remove(tab)
            val last = tabs.indexOfLast { it.groupId == group.id }
            tab.groupId = group.id
            if (last >= 0) tabs.add(last + 1, tab) else tabs.add(old.coerceIn(0, tabs.size), tab)
        }
        pruneEmptyGroups()
    }

    private fun ungroup(group: TabGroup) {
        tabs.filter { it.groupId == group.id }.forEach { it.groupId = 0 }
        groups.remove(group)
    }

    private fun closeGroup(group: TabGroup) {
        tabs.filter { it.groupId == group.id }.forEach { closeTab(it) }
        pruneEmptyGroups()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** 그룹 만들기 / 편집 대화상자 (이름 + 색상) */
    private fun showGroupEditor(existing: TabGroup?, onSave: (String, Int) -> Unit) {
        val view = layoutInflater.inflate(R.layout.dialog_group, null)
        val et = view.findViewById<EditText>(R.id.etGroupName)
        val grid = view.findViewById<GridLayout>(R.id.colorGrid)
        var selected = existing?.color ?: nextGroupColor()
        et.setText(existing?.name ?: defaultGroupName())
        et.setSelection(et.text.length)

        fun renderColors() {
            grid.removeAllViews()
            TabGroup.COLORS.forEach { c ->
                val swatch = View(this)
                swatch.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    if (c == selected) {
                        setStroke(
                            dp(3),
                            MaterialColors.getColor(
                                swatch,
                                com.google.android.material.R.attr.colorOnSurface
                            )
                        )
                    }
                }
                val lp = GridLayout.LayoutParams().apply {
                    width = dp(36)
                    height = dp(36)
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                }
                swatch.layoutParams = lp
                swatch.setOnClickListener {
                    selected = c
                    renderColors()
                }
                grid.addView(swatch)
            }
        }
        renderColors()

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "새 그룹" else "그룹 편집")
            .setView(view)
            .setNegativeButton("취소", null)
            .setPositiveButton("확인") { _, _ ->
                val name = et.text.toString().trim().ifEmpty { existing?.name ?: defaultGroupName() }
                onSave(name, selected)
            }
            .show()
    }

    private fun showTabMenu(tab: BrowserTab, onChanged: () -> Unit) {
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        labels.add("새 그룹에 추가")
        actions.add {
            showGroupEditor(null) { name, color ->
                val g = createGroup(name, color)
                moveToGroup(tab, g)
                onChanged()
            }
        }
        groups.filter { it.id != tab.groupId }.forEach { g ->
            labels.add("그룹으로 이동: ${g.name}")
            actions.add {
                moveToGroup(tab, g)
                onChanged()
            }
        }
        if (tab.groupId != 0) {
            labels.add("그룹에서 제거")
            actions.add {
                moveToGroup(tab, null)
                onChanged()
            }
        }

        AlertDialog.Builder(this)
            .setTitle(tab.webView.title?.takeIf { it.isNotBlank() } ?: "새 탭")
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }
            .show()
    }

    private fun showGroupMenu(group: TabGroup, inSwitcher: Boolean, onChanged: () -> Unit) {
        val labels = arrayOf("이 그룹에 새 탭", "이름·색상 변경", "그룹 해제", "그룹의 탭 모두 닫기")
        AlertDialog.Builder(this)
            .setTitle(group.name)
            .setItems(labels) { _, i ->
                when (i) {
                    0 -> {
                        openNewTabAndFocus(tabs.lastOrNull { it.groupId == group.id })
                        if (inSwitcher) closeTabSwitcher()
                    }
                    1 -> showGroupEditor(group) { name, color ->
                        group.name = name
                        group.color = color
                        onChanged()
                    }
                    2 -> {
                        ungroup(group)
                        onChanged()
                    }
                    3 -> {
                        val n = tabs.count { it.groupId == group.id }
                        AlertDialog.Builder(this)
                            .setMessage("'${group.name}' 그룹의 탭 ${n}개를 모두 닫을까요?")
                            .setNegativeButton("취소", null)
                            .setPositiveButton("닫기") { _, _ ->
                                closeGroup(group)
                                onChanged()
                            }
                            .show()
                    }
                }
            }
            .show()
    }

    // ───────────────────────── 태블릿 레이아웃 / 탭 스트립 ─────────────────────────

    /** 화면 폭(smallestScreenWidthDp) 600dp 이상이면 태블릿 레이아웃: 상단 탭 스트립 + 툴바에 내비게이션 */
    private fun applyLayoutMode() {
        val wide = resources.configuration.smallestScreenWidthDp >= 600
        expanded = wide
        tabStripBar.visibility = if (wide) View.VISIBLE else View.GONE
        navGroup.visibility = if (wide) View.VISIBLE else View.GONE
        tbMenu.visibility = if (wide) View.VISIBLE else View.GONE
        btnRefresh.visibility = if (wide) View.GONE else View.VISIBLE
        bottomBar.visibility = if (wide) View.GONE else View.VISIBLE
        urlBar.layoutParams = urlBar.layoutParams.apply { height = dp(if (wide) 40 else 44) }
        urlBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (wide) 16f else 15f)
        if (wide) scheduleStripRefresh()
    }

    private fun scheduleStripRefresh() {
        if (!expanded || stripRefreshQueued) return
        stripRefreshQueued = true
        ui.post {
            stripRefreshQueued = false
            refreshTabStrip()
        }
    }

    private fun refreshTabStrip() {
        if (!expanded) return
        tabStrip.removeAllViews()
        var selectedChip: View? = null
        val drawn = mutableSetOf<Int>()

        tabs.toList().forEach { tab ->
            val group = groupOf(tab)
            if (group != null && drawn.add(group.id)) addStripGroupPill(group)
            if (group != null && group.collapsed) return@forEach

            val chip = layoutInflater.inflate(R.layout.item_strip_tab, tabStrip, false)
            val title = tab.webView.title?.takeIf { it.isNotBlank() }
                ?: tab.webView.url?.takeIf { it != "about:blank" }?.let { Uri.parse(it).host }
                ?: "새 탭"
            chip.findViewById<TextView>(R.id.stripTitle).text = title

            val icon = chip.findViewById<ImageView>(R.id.stripIcon)
            val fav = tab.favicon
            if (fav != null) icon.setImageBitmap(fav) else icon.setImageResource(R.drawable.ic_globe)

            val bar = chip.findViewById<View>(R.id.stripGroupBar)
            if (group != null) {
                bar.visibility = View.VISIBLE
                bar.background.mutate().setTint(group.color)
            } else {
                bar.visibility = View.INVISIBLE
            }

            if (tab === current) {
                chip.setBackgroundResource(R.drawable.bg_strip_tab_selected)
                selectedChip = chip
            }
            chip.setOnClickListener { selectTab(tab) }
            chip.setOnLongClickListener {
                showTabMenu(tab) { scheduleStripRefresh() }
                true
            }
            chip.findViewById<ImageButton>(R.id.stripClose).setOnClickListener { closeTab(tab) }
            tabStrip.addView(chip)
        }

        // 선택한 탭이 바뀌었을 때만 그 탭이 보이도록 스크롤 (사용자가 직접 스크롤하는 중에는 건드리지 않음)
        val sel = selectedChip
        if (sel != null && lastStripCurrent !== current) {
            lastStripCurrent = current
            tabStripScroll.post {
                tabStripScroll.smoothScrollTo(maxOf(0, sel.left - dp(32)), 0)
            }
        }
    }

    private fun addStripGroupPill(group: TabGroup) {
        val pill = layoutInflater.inflate(R.layout.item_strip_group, tabStrip, false) as TextView
        val n = tabs.count { it.groupId == group.id }
        pill.text = if (group.collapsed) "${group.name} ($n)" else group.name
        pill.background.mutate().setTint(group.color)
        pill.setOnClickListener {
            group.collapsed = !group.collapsed
            scheduleStripRefresh()
        }
        pill.setOnLongClickListener {
            showGroupMenu(group, false) { scheduleStripRefresh() }
            true
        }
        tabStrip.addView(pill)
    }

    // ───────────────────────── 키보드 단축키 (태블릿 + 키보드) ─────────────────────────

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && handleShortcut(event)) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun handleShortcut(e: KeyEvent): Boolean {
        if (e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_T -> openNewTabAndFocus()
                KeyEvent.KEYCODE_W -> current?.let { closeTab(it) }
                KeyEvent.KEYCODE_L -> focusUrlBar()
                KeyEvent.KEYCODE_R -> current?.webView?.reload()
                KeyEvent.KEYCODE_TAB -> cycleTab(if (e.isShiftPressed) -1 else 1)
                in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9 -> {
                    val target = if (e.keyCode == KeyEvent.KEYCODE_9) {
                        tabs.lastOrNull()
                    } else {
                        tabs.getOrNull(e.keyCode - KeyEvent.KEYCODE_1)
                    }
                    if (target != null) selectTab(target)
                }
                else -> return false
            }
            return true
        }
        if (e.isAltPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> current?.webView?.let { if (it.canGoBack()) it.goBack() }
                KeyEvent.KEYCODE_DPAD_RIGHT -> current?.webView?.let { if (it.canGoForward()) it.goForward() }
                else -> return false
            }
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_F5) {
            current?.webView?.reload()
            return true
        }
        return false
    }

    private fun cycleTab(delta: Int) {
        if (tabs.size < 2) return
        val i = tabs.indexOf(current).coerceAtLeast(0)
        selectTab(tabs[(i + delta + tabs.size) % tabs.size])
    }

    private fun focusUrlBar() {
        urlBar.requestFocus()
        urlBar.selectAll()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(urlBar, InputMethodManager.SHOW_IMPLICIT)
    }

    // ───────────────────────── 탭 전환 화면 (전체 화면) ─────────────────────────

    private val thumbScale = 0.6f

    /** 지금 보이는 페이지 영역(웹뷰 + 홈 화면)을 비트맵으로 찍는다. */
    private fun captureContent(): Bitmap? {
        val area = webContainer.parent as? View ?: return null
        val w = area.width
        val h = area.height
        if (w <= 0 || h <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(
                (w * thumbScale).toInt().coerceAtLeast(1),
                (h * thumbScale).toInt().coerceAtLeast(1),
                Bitmap.Config.RGB_565
            )
            val c = Canvas(bmp)
            c.drawColor(MaterialColors.getColor(area, com.google.android.material.R.attr.colorSurface))
            c.scale(thumbScale, thumbScale)
            area.draw(c)
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    /** 이미지를 위쪽 기준으로 꽉 채워 보여주는 행렬 (페이지의 윗부분이 보이도록) */
    private fun topCropMatrix(bmp: Bitmap, w: Int, h: Int): Matrix {
        val s = maxOf(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        return Matrix().apply {
            setScale(s, s)
            postTranslate((w - bmp.width * s) / 2f, 0f)
        }
    }

    private fun setThumb(iv: ImageView, bmp: Bitmap?) {
        if (bmp == null) {
            iv.scaleType = ImageView.ScaleType.CENTER
            iv.alpha = 1f
            iv.setImageResource(R.drawable.ic_leaf_pixel)
            return
        }
        iv.scaleType = ImageView.ScaleType.MATRIX
        iv.setImageBitmap(bmp)
        fun apply() {
            if (iv.width > 0 && iv.height > 0) iv.imageMatrix = topCropMatrix(bmp, iv.width, iv.height)
        }
        iv.addOnLayoutChangeListener { _, l, tp, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - tp != ob - ot) apply()
        }
        apply()
    }

    private fun rectInRoot(v: View): RectF {
        val root = IntArray(2)
        val loc = IntArray(2)
        (tabMorph.parent as View).getLocationOnScreen(root)
        v.getLocationOnScreen(loc)
        return RectF(
            (loc[0] - root[0]).toFloat(), (loc[1] - root[1]).toFloat(),
            (loc[0] - root[0] + v.width).toFloat(), (loc[1] - root[1] + v.height).toFloat()
        )
    }

    private fun lerp(a: Float, b: Float, p: Float) = a + (b - a) * p

    /**
     * 스냅샷이 from 영역에서 to 영역으로 스프링으로 늘어나거나 줄어든다. (모서리 둥글기도 함께 변함)
     * 페이지 → 탭 카드, 탭 카드 → 페이지 전환에 모두 쓴다.
     */
    private fun runMorph(bmp: Bitmap, from: RectF, to: RectF, r0: Float, r1: Float, onEnd: () -> Unit) {
        tabMorph.scaleType = ImageView.ScaleType.MATRIX
        tabMorph.setImageBitmap(bmp)
        tabMorph.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, morphRadius)
            }
        }
        tabMorph.clipToOutline = true
        Motion.cancel(tabMorph)
        tabMorph.alpha = 1f
        tabMorph.visibility = View.VISIBLE
        val lp = FrameLayout.LayoutParams(1, 1)

        fun apply(p: Float) {
            val l = lerp(from.left, to.left, p)
            val tp = lerp(from.top, to.top, p)
            val w = maxOf(1f, lerp(from.width(), to.width(), p))
            val h = maxOf(1f, lerp(from.height(), to.height(), p))
            lp.leftMargin = l.toInt()
            lp.topMargin = tp.toInt()
            lp.width = w.toInt()
            lp.height = h.toInt()
            tabMorph.layoutParams = lp
            morphRadius = lerp(r0, r1, p.coerceIn(0f, 1f))
            tabMorph.imageMatrix = topCropMatrix(bmp, w.toInt(), h.toInt())
            tabMorph.invalidateOutline()
        }
        apply(0f)

        SpringAnimation(FloatValueHolder(0f))
            .setSpring(SpringForce(1f).setStiffness(320f).setDampingRatio(0.82f))
            .setMinimumVisibleChange(0.002f)
            .addUpdateListener { _, value, _ -> apply(value) }
            .addEndListener { _, _, _, _ ->
                apply(1f)
                onEnd()
            }
            .start()
    }

    private fun hideMorph(fade: Boolean) {
        if (fade && Motion.enabled(this)) {
            Motion.spring(tabMorph, DynamicAnimation.ALPHA, 0f, 700f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                tabMorph.visibility = View.GONE
                tabMorph.alpha = 1f
                tabMorph.setImageDrawable(null)
            }
        } else {
            Motion.cancel(tabMorph)
            tabMorph.visibility = View.GONE
            tabMorph.alpha = 1f
            tabMorph.setImageDrawable(null)
        }
    }

    private fun setupTabSwitcher() {
        tabSwitcher.findViewById<View>(R.id.btnCloseSheet).setOnClickListener { closeTabSwitcher() }
        tabSwitcher.findViewById<Button>(R.id.btnCloseAll).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            closeAllTabs()
            closeTabSwitcher()
        }
        tabSwitcher.findViewById<Button>(R.id.btnNewTab).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            openNewTabAndFocus()
            closeTabSwitcher()
        }
    }

    private fun openTabSwitcher() {
        if (switcherOpen || switcherBusy) return
        val cur = current ?: return
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)

        val area = webContainer.parent as View
        val shot = captureContent()
        cur.thumb = shot
        val from = rectInRoot(area)

        switcherOpen = true
        switcherBusy = true
        refreshSwitcher(animateIn = true, skipEnter = cur)
        tabSwitcher.alpha = 0f
        tabSwitcher.visibility = View.VISIBLE

        tabSwitcher.doOnLayout {
            val card = switcherRows[cur]
            val thumb = card?.findViewById<ImageView>(R.id.tabThumb)
            if (card != null) {
                val r = Rect()
                card.getDrawingRect(r)
                tabScroll.offsetDescendantRectToMyCoords(card, r)
                tabScroll.scrollTo(0, maxOf(0, r.top - dp(12)))
            }
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 1f, 240f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            if (shot == null || thumb == null || !Motion.enabled(this)) {
                tabSwitcher.alpha = 1f
                browserUi.visibility = View.INVISIBLE
                switcherBusy = false
                return@doOnLayout
            }
            val to = rectInRoot(thumb)
            thumb.alpha = 0f
            runMorph(shot, from, to, 0f, dp(10).toFloat()) {
                thumb.alpha = 1f
                hideMorph(false)
                browserUi.visibility = View.INVISIBLE
                switcherBusy = false
            }
        }
    }

    /** 탭 화면을 닫는다. target 탭의 카드가 있으면 카드가 펼쳐지며 페이지가 되고, 없으면 부드럽게 사라진다. */
    private fun closeTabSwitcher(target: BrowserTab? = null) {
        if (!switcherOpen || switcherBusy) return
        switcherBusy = true

        val tab = target ?: current ?: tabs.firstOrNull()
        val thumbView = tab?.let { switcherRows[it] }?.findViewById<ImageView>(R.id.tabThumb)
        val bmp = tab?.thumb
        val vis = Rect()
        val canMorph = tab != null && thumbView != null && bmp != null &&
            thumbView.getGlobalVisibleRect(vis) && Motion.enabled(this)
        val from = if (canMorph) rectInRoot(thumbView!!) else null

        if (tab != null && tab !== current) selectTab(tab)
        browserUi.visibility = View.VISIBLE

        fun finish() {
            tabSwitcher.visibility = View.GONE
            tabSwitcher.alpha = 1f
            tabList.removeAllViews()
            switcherRows.clear()
            switcherOpen = false
            switcherBusy = false
        }

        if (canMorph && from != null) {
            val to = rectInRoot(webContainer.parent as View)
            thumbView!!.alpha = 0f
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            runMorph(bmp!!, from, to, dp(10).toFloat(), 0f) {
                finish()
                hideMorph(true)
            }
        } else {
            // 카드가 없거나 화면 밖: 페이지가 살짝 커지며 나타나고 탭 화면은 사라진다.
            val chrome = browserUi
            if (Motion.enabled(this)) {
                Motion.cancel(chrome)
                chrome.alpha = 0f
                chrome.scaleX = 0.95f
                chrome.scaleY = 0.95f
                Motion.spring(chrome, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                Motion.spring(chrome, DynamicAnimation.SCALE_X, 1f, 260f, 0.78f)
                Motion.spring(chrome, DynamicAnimation.SCALE_Y, 1f, 260f, 0.78f)
                Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                    finish()
                }
            } else {
                finish()
            }
        }
    }

    private fun refreshSwitcher(animateIn: Boolean, skipEnter: BrowserTab? = null) {
        scheduleStripRefresh()

        // 다시 그리기 전 위치를 기억해 두었다가, 남은 카드들이 미끄러지듯 새 자리로 이동하게 한다.
        val before = HashMap<BrowserTab, Pair<Int, Int>>()
        if (!animateIn) {
            val loc = IntArray(2)
            switcherRows.forEach { (tb, v) ->
                v.getLocationOnScreen(loc)
                before[tb] = loc[0] to loc[1]
            }
        }
        switcherRows.clear()
        tabList.removeAllViews()
        tabsTitle.text = "탭 (${tabs.size})"
        val list = tabList

        var pending: LinearLayout? = null

        fun flushRow() {
            val p = pending ?: return
            if (p.childCount == 1) {
                p.addView(
                    View(this),
                    LinearLayout.LayoutParams(0, 1, 1f).apply { setMargins(dp(6), 0, dp(6), 0) }
                )
            }
            pending = null
        }

        // 탭 카드를 2열로 배치한다.
        fun addCell(v: View) {
            var p = pending
            if (p == null || p.childCount >= 2) {
                p = LinearLayout(this)
                p.orientation = LinearLayout.HORIZONTAL
                list.addView(
                    p,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(dp(12), 0, dp(12), 0) }
                )
                pending = p
            }
            p.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            )
        }

        fun addTabRow(tab: BrowserTab, group: TabGroup?) {
            val row = layoutInflater.inflate(R.layout.item_tab, list, false)
            switcherRows[tab] = row
            row.findViewById<TextView>(R.id.tabTitle).text =
                if (tab.isHome) "새 탭"
                else tab.webView.title?.takeIf { it.isNotBlank() } ?: "새 탭"
            val fav = row.findViewById<ImageView>(R.id.tabFavicon)
            val bmp = tab.favicon
            if (bmp != null) fav.setImageBitmap(bmp)
            setThumb(row.findViewById(R.id.tabThumb), tab.thumb)

            val bar = row.findViewById<View>(R.id.tabGroupBar)
            if (group != null) {
                bar.visibility = View.VISIBLE
                bar.background.mutate().setTint(group.color)
            } else {
                bar.visibility = View.GONE
            }

            if (tab === current) {
                row.setBackgroundResource(R.drawable.bg_tab_card_active)
            }
            row.setOnClickListener { closeTabSwitcher(tab) }
            row.setOnLongClickListener {
                showTabMenu(tab) { refreshSwitcher(false) }
                true
            }
            Motion.pressable(row, 0.96f)
            row.findViewById<ImageButton>(R.id.tabClose).setOnClickListener {
                if (switcherBusy) return@setOnClickListener
                it.isEnabled = false
                Motion.flyAway(row) {
                    closeTab(tab)
                    refreshSwitcher(false)
                }
            }
            if (animateIn && tab !== skipEnter) {
                Motion.enter(row, minOf(list.childCount * 45L + 80L, 380L))
            }
            addCell(row)
        }

        fun addGroupHeader(group: TabGroup) {
            val header = layoutInflater.inflate(R.layout.item_group_header, list, false)
            val members = tabs.count { it.groupId == group.id }
            header.findViewById<View>(R.id.groupDot).background.mutate().setTint(group.color)
            header.findViewById<TextView>(R.id.groupName).text = group.name
            header.findViewById<TextView>(R.id.groupCount).text = "${members}개 탭"
            header.findViewById<ImageView>(R.id.groupChevron).rotation =
                if (group.collapsed) 0f else 180f
            header.setOnClickListener {
                group.collapsed = !group.collapsed
                refreshSwitcher(false)
            }
            header.findViewById<ImageButton>(R.id.groupMenu).setOnClickListener {
                showGroupMenu(group, true) { refreshSwitcher(false) }
            }
            flushRow()
            list.addView(header)
        }

        // 탭 순서대로 훑으면서, 그룹은 처음 나온 자리에 헤더 + 소속 탭을 한 번에 그린다.
        val drawn = mutableSetOf<Int>()
        tabs.toList().forEach { tab ->
            val g = groupOf(tab)
            if (g == null) {
                addTabRow(tab, null)
            } else if (drawn.add(g.id)) {
                addGroupHeader(g)
                if (!g.collapsed) {
                    tabs.filter { it.groupId == g.id }.forEach { addTabRow(it, g) }
                }
                flushRow()
            }
        }
        flushRow()
        if (!animateIn) {
            Motion.glideFrom(list, before.mapNotNull { (tb, pos) -> switcherRows[tb]?.let { it to pos } }.toMap())
        }
    }

    private fun closeAllTabs() {
        val old = tabs.toList()
        createTab(null, home = true)
        old.forEach { closeTab(it) }
    }

    private fun openNewTabAndFocus(opener: BrowserTab? = null) {
        createTab(null, opener = opener, home = true)
        ui.postDelayed({
            urlBar.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(urlBar, InputMethodManager.SHOW_IMPLICIT)
        }, 150)
    }

    // ───────────────────────── 웹뷰 설정 ─────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(tab: BrowserTab) {
        val wv = tab.webView

        if (baseUserAgent.isEmpty()) baseUserAgent = wv.settings.userAgentString
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = false
            setGeolocationEnabled(false)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            // 일부 사이트(영상 서비스 등)가 WebView를 낮은 품질로 취급하는 것을 피하기 위해 UA에서 WebView 표시 제거
            userAgentString = mobileUserAgent()
        }
        // 영상 재생 최적화: 하드웨어 가속 렌더링
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                if (adBlockEnabled && !request.isForMainFrame && adBlocker.isBlocked(request.url.host)) {
                    adBlocker.blockedCount.incrementAndGet()
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "http" || scheme == "https") return false

                // 사용자 동작 없이 외부 앱/스토어를 여는 리다이렉트(광고)는 차단
                if (!request.hasGesture()) return true

                return try {
                    val intent = if (scheme == "intent") {
                        Intent.parseUri(request.url.toString(), Intent.URI_INTENT_SCHEME).apply {
                            addCategory(Intent.CATEGORY_BROWSABLE)
                            component = null
                            selector = null
                        }
                    } else {
                        Intent(Intent.ACTION_VIEW, request.url)
                    }
                    startActivity(intent)
                    true
                } catch (e: ActivityNotFoundException) {
                    toast("이 링크를 열 수 있는 앱이 없습니다")
                    true
                } catch (e: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                tab.cosmeticInjected = false
                tab.favicon = favicon
                if (url != "about:blank") tab.isHome = false
                if (tab === current) updateUi()
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (url == "about:blank") view.clearHistory()
                if (adBlockEnabled) view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                if (tab.rate != 1f) view.evaluateJavascript(speedJs(tab.rate), null)
                // (저장은 백그라운드 스레드에서 — 메인 스레드에서 JSON을 읽고 쓰면 페이지 전환이 버벅인다)
                if (url.startsWith("http")) {
                    val title = view.title
                    io.execute { prefs.addHistory(url, title) }
                }
                if (tab === current) updateUi()
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                tab.progress = newProgress
                // 진행률 이벤트마다 JS를 실행하면 로딩이 느려지므로 페이지당 한 번만 넣는다. (끝날 때 한 번 더 확인)
                if (adBlockEnabled && newProgress >= 30 && !tab.cosmeticInjected) {
                    tab.cosmeticInjected = true
                    view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                }
                if (tab === current) {
                    showProgress(newProgress)
                }
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                scheduleStripRefresh()
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                tab.favicon = icon
                scheduleStripRefresh()
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.keepScreenOn = true
                fullscreenContainer.visibility = View.VISIBLE
                browserUi.visibility = View.GONE
                setSystemBarsVisible(false)
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message
            ): Boolean {
                // 사용자 동작 없이 열리는 팝업(팝업 광고)은 차단
                if (!isUserGesture) return false
                val newTab = createTab(null, opener = tab)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = newTab.webView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val target = tabs.firstOrNull { it.webView === window } ?: return
                ui.post { closeTab(target) }
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        }

        wv.setOnLongClickListener {
            val result = wv.hitTestResult
            val extra = result.extra
            when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (extra != null) showLinkMenu(extra, null)
                    extra != null
                }
                WebView.HitTestResult.IMAGE_TYPE -> {
                    if (extra != null) showLinkMenu(null, extra)
                    extra != null
                }
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    if (extra != null) {
                        val msg = Handler(Looper.getMainLooper()) { m ->
                            showLinkMenu(m.data.getString("url"), extra)
                            true
                        }.obtainMessage()
                        wv.requestFocusNodeHref(msg)
                    }
                    extra != null
                }
                else -> false
            }
        }
    }

    // ───────────────────────── 주소창 / 빠른 검색 ─────────────────────────

    private fun setupUrlBar() {
        suggestAdapter = NoFilterAdapter(this, suggestItems)
        urlBar.setAdapter(suggestAdapter)
        urlBar.threshold = 1

        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadFromInput(urlBar.text.toString())
                true
            } else {
                false
            }
        }

        urlBar.setOnItemClickListener { _, _, position, _ ->
            suggestAdapter.getItem(position)?.let { loadFromInput(it) }
        }

        urlBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                // 입력할 때는 전체 주소를 보여주고 전체 선택
                setUrlText(
                    if (current?.isHome == true) ""
                    else current?.webView?.url?.takeIf { it != "about:blank" } ?: ""
                )
                urlBar.post { urlBar.selectAll() }
            } else {
                updateUi()
            }
        }

        urlBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher || !urlBar.hasFocus()) return
                suggestRunnable?.let { ui.removeCallbacks(it) }
                val q = s?.toString()?.trim().orEmpty()
                if (q.isEmpty()) {
                    setSuggestions(emptyList())
                    return
                }
                val r = Runnable { requestSuggestions(q) }
                suggestRunnable = r
                ui.postDelayed(r, 150)
            }
        })
    }

    /** 주소창에 평소 보여줄 짧은 주소 (https://www. 를 뗀 도메인) */
    private fun displayUrl(url: String?): String {
        if (url.isNullOrBlank() || url == "about:blank") return ""
        if (!url.startsWith("http")) return url
        val host = try { Uri.parse(url).host } catch (e: Exception) { null }
        return host?.removePrefix("www.") ?: url
    }

    /** 주소창 왼쪽 아이콘: https 면 자물쇠, 아니면 지구본 */
    private fun updateSecurityIcon(url: String?) {
        val blank = url.isNullOrBlank() || url == "about:blank"
        val secure = url?.startsWith("https://") == true
        val res = when {
            blank -> R.drawable.ic_search
            secure -> R.drawable.ic_lock
            else -> R.drawable.ic_globe
        }
        val icon = ContextCompat.getDrawable(this, res)?.mutate()
        icon?.setBounds(0, 0, dp(18), dp(18))
        icon?.setTint(MaterialColors.getColor(urlBar, com.google.android.material.R.attr.colorOnSurfaceVariant))
        urlBar.setCompoundDrawablesRelative(icon, null, null, null)
    }

    private fun setUrlText(text: String) {
        suppressWatcher = true
        suggestItems.clear()
        urlBar.setText(text)
        suppressWatcher = false
    }

    private fun requestSuggestions(q: String) {
        val local = prefs.history()
            .filter { it.first.contains(q, true) || it.second.contains(q, true) }
            .map { it.first }
            .take(3)
        setSuggestions(local)

        io.execute {
            try {
                val remote = Suggest.fetch(q)
                ui.post {
                    if (urlBar.text.toString().trim() == q) {
                        setSuggestions((local + remote.filter { it !in local }).take(8))
                    }
                }
            } catch (e: Exception) {
                // 자동완성 실패는 무시
            }
        }
    }

    private fun setSuggestions(items: List<String>) {
        suggestItems.clear()
        suggestItems.addAll(items)
        suggestAdapter.notifyDataSetChanged()
        if (items.isNotEmpty() && urlBar.hasFocus()) urlBar.showDropDown()
    }

    private fun resolveInput(input: String): String {
        if (input.startsWith("http://") || input.startsWith("https://")) return input

        // 빠른 검색 단축어 (예: "yt 노래", "n 날씨")
        val parts = input.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2) {
            SearchEngines.shortcuts[parts[0].lowercase()]?.let { return it + Uri.encode(parts[1]) }
        }

        val isLocal = input.startsWith("localhost") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(input)
        if (!input.contains(" ") && isLocal) return "http://$input"
        if (!input.contains(" ") && input.contains(".")) return "https://$input"

        return SearchEngines.byKey(prefs.engineKey).searchUrl + Uri.encode(input)
    }

    private fun loadFromInput(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        current?.isHome = false
        current?.webView?.loadUrl(resolveInput(input))
        updateUi()
        urlBar.dismissDropDown()
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ───────────────────────── 컨트롤 / 뒤로가기 / UI ─────────────────────────

    private fun setupControls() {
        val goBack = {
            val c = current
            if (c != null) {
                if (c.isHome) {
                    if (hasPage(c)) {
                        c.isHome = false
                        updateUi()
                    }
                } else if (c.webView.canGoBack()) {
                    c.webView.goBack()
                }
            }
            Unit
        }
        val goForward = {
            val c = current
            if (c != null && !c.isHome && c.webView.canGoForward()) c.webView.goForward()
            Unit
        }
        val reload = {
            val c = current
            if (c != null) {
                if (c.progress in 1..99) c.webView.stopLoading() else c.webView.reload()
            }
            Unit
        }
        val goHome = {
            current?.let {
                it.isHome = true
                updateUi()
            }
            Unit
        }

        btnBack.setOnClickListener { goBack() }
        tbBack.setOnClickListener { goBack() }
        btnForward.setOnClickListener { goForward() }
        tbForward.setOnClickListener { goForward() }
        btnRefresh.setOnClickListener { reload() }
        tbRefresh.setOnClickListener { reload() }
        btnHome.setOnClickListener { goHome() }
        tbHome.setOnClickListener { goHome() }
        btnTabs.setOnClickListener { openTabSwitcher() }
        btnMenu.setOnClickListener { showMenu() }
        tbMenu.setOnClickListener { showMenu() }
        findViewById<View>(R.id.btnStripNewTab).setOnClickListener { openNewTabAndFocus() }
        findViewById<View>(R.id.btnStripTabList).setOnClickListener { openTabSwitcher() }
        listOf<View>(
            btnBack, btnForward, btnRefresh, btnHome, btnTabs, btnMenu,
            tbBack, tbForward, tbRefresh, tbHome, tbMenu,
            findViewById(R.id.btnStripNewTab), findViewById(R.id.btnStripTabList)
        ).forEach { addPressAnim(it) }
    }

    private fun setupHome() {
        val go = {
            loadFromInput(homeSearch.text.toString())
            homeSearch.setText("")
            homeSearch.clearFocus()
        }
        homeSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                go()
                true
            } else {
                false
            }
        }
        findViewById<View>(R.id.homeSearchGo).setOnClickListener { go() }
        mapOf(
            R.id.scGoogle to "https://www.google.com",
            R.id.scNaver to "https://m.naver.com",
            R.id.scYoutube to "https://m.youtube.com",
            R.id.scWiki to "https://ko.wikipedia.org"
        ).forEach { (id, url) ->
            val v = findViewById<View>(id)
            v.setOnClickListener { loadFromInput(url) }
            addPressAnim(v)
        }
        if (resources.configuration.smallestScreenWidthDp >= 600) {
            homeContent.layoutParams = (homeContent.layoutParams as FrameLayout.LayoutParams).apply {
                width = dp(560)
                gravity = Gravity.CENTER_HORIZONTAL
            }
        }
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = current?.webView
                when {
                    switcherOpen -> closeTabSwitcher()
                    customView != null -> hideCustomView()
                    current?.isHome == true && current?.let { hasPage(it) } == true -> {
                        current?.isHome = false
                        updateUi()
                    }
                    wv != null && current?.isHome != true && wv.canGoBack() -> wv.goBack()
                    tabs.size > 1 -> current?.let { closeTab(it) }
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    private fun updateUi() {
        val tab = current ?: return
        val wv = tab.webView
        if (!urlBar.hasFocus()) {
            setUrlText(if (tab.isHome) "" else displayUrl(wv.url))
        }
        updateSecurityIcon(if (tab.isHome) null else wv.url)
        if (tab.isHome) {
            if (homeView.visibility != View.VISIBLE) {
                homeView.alpha = 1f
                homeView.visibility = View.VISIBLE
                (homeContent as? ViewGroup)?.let { Motion.stagger(it, 0, 55, 330) }
            }
        } else {
            homeView.visibility = View.GONE
        }
        showProgress(tab.progress)
        val canBack = if (tab.isHome) hasPage(tab) else wv.canGoBack()
        val canForward = !tab.isHome && wv.canGoForward()
        listOf(btnBack, tbBack).forEach {
            it.isEnabled = canBack
            it.alpha = if (canBack) 1f else 0.35f
        }
        listOf(btnForward, tbForward).forEach {
            it.isEnabled = canForward
            it.alpha = if (canForward) 1f else 0.35f
        }
        updateTabCount()
    }

    private var loadingIcon = false

    private fun hasPage(tab: BrowserTab): Boolean =
        tab.webView.url?.let { it != "about:blank" } == true

    /** 로딩 바를 부드럽게 채우고, 끝나면 서서히 사라지게. 로딩 중에는 새로고침 버튼이 X(중지)로 바뀐다. */
    private fun showProgress(p: Int) {
        val loading = p in 1..99
        if (loading) {
            progressBar.animate().cancel()
            progressBar.alpha = 1f
            progressBar.visibility = View.VISIBLE
            progressBar.setProgress(p, true)
        } else if (progressBar.visibility == View.VISIBLE) {
            progressBar.setProgress(100, true)
            progressBar.animate().alpha(0f).setStartDelay(150).setDuration(250).withEndAction {
                progressBar.visibility = View.GONE
                progressBar.progress = 0
                progressBar.animate().setStartDelay(0)
            }.start()
        }
        if (loading != loadingIcon) {
            loadingIcon = loading
            val res = if (loading) R.drawable.ic_close else R.drawable.ic_refresh
            btnRefresh.setImageResource(res)
            tbRefresh.setImageResource(res)
        }
    }

    /** 버튼을 누르면 쏙 들어갔다가 탄성 있게 튀어 돌아오는 효과 (스프링) */
    private fun addPressAnim(v: View) {
        Motion.pressable(v, 0.86f)
    }

    private fun hideCustomView() {
        val view = customView ?: return
        fullscreenContainer.removeView(view)
        fullscreenContainer.keepScreenOn = false
        fullscreenContainer.visibility = View.GONE
        browserUi.visibility = View.VISIBLE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        setSystemBarsVisible(true)
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ───────────────────────── 메뉴 ─────────────────────────

    private fun showMenu() {
        val dialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.dialog_menu, null)
        val list = view.findViewById<LinearLayout>(R.id.menuList)
        view.findViewById<View>(R.id.btnCloseMenu).setOnClickListener { dialog.dismiss() }

        fun newRow(icon: Int, title: String, sub: String?): View {
            val row = layoutInflater.inflate(R.layout.item_menu_row, list, false)
            row.findViewById<ImageView>(R.id.rowIcon).setImageResource(icon)
            row.findViewById<TextView>(R.id.rowTitle).text = title
            val st = row.findViewById<TextView>(R.id.rowSub)
            if (sub != null) {
                st.text = sub
                st.visibility = View.VISIBLE
            }
            list.addView(row)
            return row
        }

        fun addRow(icon: Int, title: String, sub: String? = null, action: () -> Unit) {
            val row = newRow(icon, title, sub)
            row.setOnClickListener {
                dialog.dismiss()
                action()
            }
        }

        // 스위치 행: 시트를 닫지 않고 바로 켜고 끈다.
        fun addToggle(
            icon: Int,
            title: String,
            sub: () -> String?,
            checked: Boolean,
            action: () -> Boolean
        ) {
            val row = newRow(icon, title, sub())
            val sw = row.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.rowSwitch)
            sw.visibility = View.VISIBLE
            sw.isChecked = checked
            row.setOnClickListener {
                sw.isChecked = action()
                row.findViewById<TextView>(R.id.rowSub).text = sub()
            }
        }

        addRow(R.drawable.ic_add, "새 탭") { openNewTabAndFocus() }
        addRow(R.drawable.ic_search, "검색 엔진", "현재: ${SearchEngines.byKey(prefs.engineKey).name}") { showEngineDialog() }
        addToggle(
            R.drawable.ic_shield, "광고 차단",
            { "${adBlocker.blockedCount.get()}건 차단됨" },
            adBlockEnabled
        ) {
            toggleAdBlock()
            adBlockEnabled
        }
        addRow(R.drawable.ic_refresh, "광고 차단 목록 업데이트") { updateAdBlockList() }
        addToggle(
            R.drawable.ic_desktop, "데스크톱 사이트",
            { "켜면 PC용 화면으로 다시 불러옵니다" },
            current?.desktop == true
        ) {
            toggleDesktopSite()
            current?.desktop == true
        }
        addRow(R.drawable.ic_play, "재생 속도", "현재: ${current?.rate ?: 1f}x") { showSpeedDialog() }
        addRow(R.drawable.ic_movie, "페이지의 영상 파일 찾기") { findVideos() }
        addRow(R.drawable.ic_download, "다운로드 목록") { openDownloads() }
        addRow(R.drawable.ic_tab, "현재 탭을 새 그룹으로") { groupCurrentTab() }
        addRow(R.drawable.ic_delete, "방문 기록·캐시·쿠키 삭제") { clearBrowsingData() }

        dialog.setContentView(view)
        dialog.behavior.maxWidth = dp(600)
        dialog.setOnShowListener { dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED }
        Motion.stagger(list, 90, 32, 360)
        dialog.show()
    }

    private fun mobileUserAgent(): String =
        baseUserAgent.replace("; wv", "").replace(" Version/4.0", "")

    private fun desktopUserAgent(): String {
        val ver = Regex("Chrome/([\\d.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$ver Safari/537.36"
    }

    private fun toggleDesktopSite() {
        val tab = current ?: return
        tab.desktop = !tab.desktop
        tab.webView.settings.userAgentString = if (tab.desktop) desktopUserAgent() else mobileUserAgent()
        tab.webView.reload()
        toast(if (tab.desktop) "데스크톱 사이트로 다시 불러옵니다" else "모바일 사이트로 다시 불러옵니다")
    }

    private fun groupCurrentTab() {
        val tab = current ?: return
        showGroupEditor(null) { name, color ->
            moveToGroup(tab, createGroup(name, color))
            toast("'$name' 그룹에 추가했습니다")
        }
    }

    private fun toggleAdBlock() {
        adBlockEnabled = !adBlockEnabled
        prefs.adBlock = adBlockEnabled
        toast(if (adBlockEnabled) "광고 차단 켜짐" else "광고 차단 꺼짐")
        current?.webView?.reload()
    }

    private fun updateAdBlockList() {
        toast("차단 목록을 내려받는 중…")
        io.execute {
            try {
                val n = adBlocker.update()
                ui.post { toast("차단 목록 적용 완료 (${n}개 도메인)") }
            } catch (e: Exception) {
                ui.post { toast("업데이트 실패: ${e.message}") }
            }
        }
    }

    private fun showEngineDialog() {
        val engines = SearchEngines.all
        val selected = engines.indexOfFirst { it.key == prefs.engineKey }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("검색 엔진")
            .setSingleChoiceItems(engines.map { it.name }.toTypedArray(), selected) { d, which ->
                prefs.engineKey = engines[which].key
                d.dismiss()
            }
            .show()
    }

    private fun clearBrowsingData() {
        tabs.forEach {
            it.webView.clearCache(true)
            it.webView.clearHistory()
        }
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies(null)
        prefs.clearHistory()
        toast("삭제했습니다")
    }

    // ───────────────────────── 영상 재생 속도 ─────────────────────────

    private fun speedJs(rate: Float): String = """
        (function(r){
          window.__sbRate = r;
          function apply(){
            document.querySelectorAll('video,audio').forEach(function(v){
              if (v.playbackRate !== window.__sbRate) v.playbackRate = window.__sbRate;
            });
          }
          apply();
          if (window.__sbRateTimer) { clearInterval(window.__sbRateTimer); window.__sbRateTimer = null; }
          if (r !== 1) window.__sbRateTimer = setInterval(apply, 800);
        })($rate);
    """.trimIndent()

    private fun showSpeedDialog() {
        val tab = current ?: return
        val rates = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
        val labels = rates.map { "${it}x" }.toTypedArray()
        val selected = rates.indexOfFirst { r -> r == tab.rate }.let { if (it < 0) 2 else it }
        AlertDialog.Builder(this)
            .setTitle("재생 속도")
            .setSingleChoiceItems(labels, selected) { d, which ->
                tab.rate = rates[which]
                tab.webView.evaluateJavascript(speedJs(tab.rate), null)
                d.dismiss()
            }
            .show()
    }

    // ───────────────────────── 다운로드 ─────────────────────────

    private fun findVideos() {
        val wv = current?.webView ?: return
        wv.evaluateJavascript(FIND_VIDEO_JS) { raw ->
            val found: List<String> = try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String ?: "[]"
                val arr = JSONArray(inner)
                (0 until arr.length()).map { arr.getString(it) }
            } catch (e: Exception) {
                emptyList()
            }
            val urls = found.filter {
                val path = it.substringBefore('?').lowercase()
                (it.startsWith("http://") || it.startsWith("https://")) &&
                    !path.endsWith(".m3u8") && !path.endsWith(".mpd")
            }.take(15)

            if (urls.isEmpty()) {
                AlertDialog.Builder(this)
                    .setTitle("영상 파일 없음")
                    .setMessage(
                        "직접 내려받을 수 있는 영상 파일을 찾지 못했습니다.\n\n" +
                            "blob/스트리밍(m3u8) 방식이거나 보호(DRM)된 영상, 다른 도메인의 iframe 안에 있는 영상은 지원하지 않습니다."
                    )
                    .setPositiveButton("확인", null)
                    .show()
            } else {
                val names = urls.map { URLUtil.guessFileName(it, null, null) }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("저장할 영상 선택")
                    .setItems(names) { _, i ->
                        startDownload(urls[i], wv.settings.userAgentString, null, null)
                    }
                    .setNegativeButton("취소", null)
                    .show()
            }
        }
    }

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("blob/data 형식 주소는 직접 다운로드할 수 없습니다")
            return
        }
        enqueueDownload(url, userAgent, contentDisposition, mimeType)
    }

    private fun enqueueDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        val referer = current?.webView?.url?.takeIf { it.startsWith("http") }

        // Android 10 이상: 여러 연결로 나눠 받는 빠른 다운로드
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            requestNotificationPermission()
            try {
                DownloadService.start(this, url, userAgent, contentDisposition, mimeType, referer)
                toast("다운로드 시작: ${URLUtil.guessFileName(url, contentDisposition, mimeType)}")
                return
            } catch (e: Exception) {
                // 서비스를 시작하지 못하면 시스템 다운로더로
            }
        }
        systemDownload(url, userAgent, contentDisposition, mimeType, referer)
    }

    private fun systemDownload(
        url: String, userAgent: String?, contentDisposition: String?, mimeType: String?, referer: String?
    ) {
        val name = SystemDownload.enqueue(this, url, userAgent, contentDisposition, mimeType, referer)
        toast(if (name != null) "다운로드 중: $name" else "다운로드에 실패했습니다")
    }

    /** Android 13+ 에서 다운로드 진행 알림을 보이려면 알림 권한이 필요하다. (거부해도 다운로드는 진행됨) */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || askedNotificationPermission) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotificationPermission = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun autoUpdateAdBlockList() {
        val week = 7L * 24 * 60 * 60 * 1000
        if (System.currentTimeMillis() - prefs.adblockLastTry < week) return
        prefs.adblockLastTry = System.currentTimeMillis()
        // 자동완성과 같은 스레드를 막지 않도록 별도 스레드에서 실행
        Thread {
            try {
                adBlocker.update()
            } catch (e: Exception) {
                // 실패하면 다음 주에 다시 시도
            }
        }.apply { isDaemon = true }.start()
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("다운로드 앱을 열 수 없습니다")
        }
    }

    private fun showLinkMenu(link: String?, image: String?) {
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        if (link != null && (link.startsWith("http://") || link.startsWith("https://"))) {
            labels.add("새 탭에서 열기")
            actions.add { createTab(link, opener = current) }
            labels.add("링크 주소 복사")
            actions.add { copyToClipboard(link) }
        }
        if (image != null && (image.startsWith("http://") || image.startsWith("https://"))) {
            labels.add("이미지 저장")
            actions.add { startDownload(image, current?.webView?.settings?.userAgentString, null, null) }
            labels.add("새 탭에서 이미지 열기")
            actions.add { createTab(image, opener = current) }
        }
        if (labels.isEmpty()) return
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }
            .show()
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", text))
        toast("복사했습니다")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val FIND_VIDEO_JS =
            "(function(){var r=[];document.querySelectorAll('video,video source,audio source')" +
                ".forEach(function(e){var u=e.currentSrc||e.src;if(u&&/^https?:/.test(u))r.push(u);});" +
                "return JSON.stringify(Array.from(new Set(r)));})()"
    }
}

/** 입력한 글자와 상관없이 전달받은 목록을 그대로 보여주는 자동완성 어댑터 */
class NoFilterAdapter(context: Context, private val data: MutableList<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, data) {

    private val noFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): Filter.FilterResults =
            Filter.FilterResults().also {
                it.values = data
                it.count = data.size
            }

        override fun publishResults(constraint: CharSequence?, results: Filter.FilterResults?) {
            if (data.isNotEmpty()) notifyDataSetChanged() else notifyDataSetInvalidated()
        }
    }

    override fun getFilter(): Filter = noFilter
}
