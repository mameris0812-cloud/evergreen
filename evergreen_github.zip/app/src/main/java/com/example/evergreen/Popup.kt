package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.DrawableRes

/**
 * 앱 전체가 함께 쓰는 팝업 (가운데에 뜨는 둥근 카드).
 * - menu(): 머리말 + 아이콘 달린 항목 목록
 * - confirm(): 제목 + 설명 + 취소/확인 버튼
 * 등장은 통통 튀는 확대, 항목은 위에서부터 차례로 떠오른다.
 */
object Popup {

    class Item(
        @DrawableRes val icon: Int,
        val label: String,
        val sub: String? = null,
        val danger: Boolean = false,
        /** 아이콘 대신 이 색의 동그라미를 보여준다 (탭 그룹 색 등) */
        val dotColor: Int? = null,
        val checked: Boolean = false,
        val action: () -> Unit
    )

    private const val DANGER = 0xFFD93025.toInt()

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun create(
        ctx: Context,
        title: String,
        subtitle: String?,
        headerIcon: Int?,
        headerColor: Int?
    ): Pair<Dialog, View> {
        val dialog = Dialog(ctx, R.style.Evergreen_Popup)
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null)

        view.findViewById<TextView>(R.id.popupTitle).text = title
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        val icon = view.findViewById<ImageView>(R.id.popupIcon)
        if (headerColor != null) {
            icon.setImageDrawable(null)
            icon.setPadding(0, 0, 0, 0)
            icon.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(headerColor)
            }
            icon.visibility = View.VISIBLE
        } else if (headerIcon != null) {
            icon.setImageResource(headerIcon)
            icon.visibility = View.VISIBLE
        }

        dialog.setContentView(view)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.apply {
            val maxW = minOf(dp(ctx, 340), (ctx.resources.displayMetrics.widthPixels * 0.88f).toInt())
            setLayout(maxW, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }
        return dialog to view
    }

    fun menu(
        ctx: Context,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        headerColor: Int? = null,
        items: List<Item>
    ): Dialog {
        val (dialog, view) = create(ctx, title, subtitle, headerIcon, headerColor)
        val list = view.findViewById<LinearLayout>(R.id.popupList)
        val inflater = LayoutInflater.from(ctx)

        items.forEach { it0 ->
            val row = inflater.inflate(R.layout.popup_item, list, false)
            val icon = row.findViewById<ImageView>(R.id.itemIcon)
            val label = row.findViewById<TextView>(R.id.itemTitle)
            if (it0.dotColor != null) {
                icon.imageTintList = null
                icon.setImageDrawable(GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(it0.dotColor)
                    setSize(dp(ctx, 16), dp(ctx, 16))
                })
            } else {
                icon.setImageResource(it0.icon)
            }
            label.text = it0.label
            if (it0.danger) {
                icon.imageTintList = android.content.res.ColorStateList.valueOf(DANGER)
                label.setTextColor(DANGER)
            }
            if (it0.sub != null) {
                row.findViewById<TextView>(R.id.itemSub).apply {
                    text = it0.sub
                    visibility = View.VISIBLE
                }
            }
            if (it0.checked) row.findViewById<View>(R.id.itemCheck).visibility = View.VISIBLE
            row.setOnClickListener {
                dialog.dismiss()
                it0.action()
            }
            list.addView(row)
        }

        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        Motion.stagger(list, 70, 30, 260)
        return dialog
    }

    fun confirm(
        ctx: Context,
        title: String,
        message: String,
        positive: String = "확인",
        danger: Boolean = false,
        onOk: () -> Unit
    ): Dialog {
        val (dialog, view) = create(ctx, title, null, null, null)
        view.findViewById<TextView>(R.id.popupMessage).apply {
            text = message
            visibility = View.VISIBLE
        }
        view.findViewById<View>(R.id.popupScroll).visibility = View.GONE
        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).setOnClickListener { dialog.dismiss() }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = positive
            if (danger) setTextColor(DANGER)
            setOnClickListener {
                dialog.dismiss()
                onOk()
            }
        }
        dialog.show()
        return dialog
    }
}
