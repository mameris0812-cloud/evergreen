package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.annotation.DrawableRes

/**
 * 앱 전체가 함께 쓰는 팝업 (가운데에 뜨는 둥근 카드).
 * - menu(): 머리말 + 아이콘 달린 항목 목록
 * - confirm(): 제목 + 설명 + 취소/확인 버튼
 * 등장은 통통 튀는 확대, 항목은 위에서부터 차례로 떠오른다.
 */
object Popup {

    class Item(
        @DrawableRes val icon: Int,
        val label: String,
        val sub: String? = null,
        val danger: Boolean = false,
        /** 아이콘 대신 이 색의 동그라미를 보여준다 (탭 그룹 색 등) */
        val dotColor: Int? = null,
        val checked: Boolean = false,
        /** 설명(sub)을 한 줄로 줄여 보여준다 (주소처럼 긴 글자용) */
        val compactSub: Boolean = false,
        val action: () -> Unit
    )

    private const val DANGER = 0xFFD93025.toInt()

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun create(
        ctx: Context,
        title: String,
        subtitle: String?,
        headerIcon: Int?,
        headerColor: Int?,
        widthDp: Int = 340
    ): Pair<Dialog, View> {
        val dialog = Dialog(ctx, R.style.Evergreen_Popup)
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null)

        view.findViewById<TextView>(R.id.popupTitle).text = title
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        val icon = view.findViewById<ImageView>(R.id.popupIcon)
        if (headerColor != null) {
            icon.setImageDrawable(null)
            icon.setPadding(0, 0, 0, 0)
            icon.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(headerColor)
            }
            icon.visibility = View.VISIBLE
        } else if (headerIcon != null) {
            icon.setImageResource(headerIcon)
            icon.visibility = View.VISIBLE
        }

        dialog.setContentView(view)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.apply {
            val maxW = minOf(dp(ctx, widthDp), (ctx.resources.displayMetrics.widthPixels * 0.92f).toInt())
            setLayout(maxW, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }
        // 뒤 페이지를 흐리게 + 카드를 반투명 유리처럼 (Android 12+ 에서 지원될 때만)
        if (Blur.behind(dialog.window, ctx)) {
            view.background = Blur.glass(ctx, com.google.android.material.R.attr.colorSurface, dp(ctx, 26).toFloat())
        }
        return dialog to view
    }

    fun menu(
        ctx: Context,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        headerColor: Int? = null,
        items: List<Item>
    ): Dialog {
        val (dialog, view) = create(ctx, title, subtitle, headerIcon, headerColor)
        val list = view.findViewById<LinearLayout>(R.id.popupList)

        fillRows(ctx, list, items) { dialog.dismiss() }

        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        Motion.stagger(list, 70, 30, 260)
        return dialog
    }


    /** 항목 줄들을 목록에 채운다. 항목을 누르면 먼저 onPick(팝업 닫기)을 부르고 그 동작을 실행한다. */
    private fun fillRows(ctx: Context, list: LinearLayout, items: List<Item>, onPick: () -> Unit) {
        val inflater = LayoutInflater.from(ctx)
        items.forEach { it0 ->
            val row = inflater.inflate(R.layout.popup_item, list, false)
            val icon = row.findViewById<ImageView>(R.id.itemIcon)
            val label = row.findViewById<TextView>(R.id.itemTitle)
            if (it0.dotColor != null) {
                icon.imageTintList = null
                icon.setImageDrawable(GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(it0.dotColor)
                    setSize(dp(ctx, 16), dp(ctx, 16))
                })
            } else {
                icon.setImageResource(it0.icon)
            }
            label.text = it0.label
            if (it0.danger) {
                icon.imageTintList = android.content.res.ColorStateList.valueOf(DANGER)
                label.setTextColor(DANGER)
            }
            if (it0.sub != null) {
                row.findViewById<TextView>(R.id.itemSub).apply {
                    text = it0.sub
                    visibility = View.VISIBLE
                    if (it0.compactSub) {
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    }
                }
            }
            if (it0.checked) row.findViewById<View>(R.id.itemCheck).visibility = View.VISIBLE
            row.setOnClickListener {
                onPick()
                it0.action()
            }
            list.addView(row)
        }
    }

    /**
     * 태블릿용: 누른 버튼 바로 아래에 붙어서 뜨는 목록 팝업 (뒤로/앞으로 기록 등).
     * 버튼의 왼쪽 끝에 맞추되 화면 밖으로는 나가지 않고, 남는 높이보다 길면 스크롤된다.
     */
    fun menuAnchored(
        ctx: Context,
        anchor: View,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        items: List<Item>
    ): PopupWindow {
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null)
        view.findViewById<TextView>(R.id.popupTitle).text = title
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        if (headerIcon != null) {
            view.findViewById<ImageView>(R.id.popupIcon).apply {
                setImageResource(headerIcon)
                visibility = View.VISIBLE
            }
        }
        val list = view.findViewById<LinearLayout>(R.id.popupList)

        val dm = ctx.resources.displayMetrics
        val width = minOf(dp(ctx, 380), dm.widthPixels - dp(ctx, 16))
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val below = loc[1] + anchor.height
        val maxH = (dm.heightPixels - below - dp(ctx, 12)).coerceAtLeast(dp(ctx, 240))

        var pw: PopupWindow? = null
        fillRows(ctx, list, items) { pw?.dismiss() }

        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val height = minOf(view.measuredHeight, maxH)

        val radius = dp(ctx, 16).toFloat()
        // 둥근 카드 모양은 팝업 창 배경이 맡는다 (그림자도 이 모양을 따라간다)
        view.background = null
        val glass = Blur.supported(ctx)
        val bg = GradientDrawable().apply {
            cornerRadius = radius
            setColor(Blur.surface(ctx, com.google.android.material.R.attr.colorSurfaceContainer, glass))
        }
        view.clipToOutline = true
        view.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, v.width, v.height, radius)
            }
        }
        val popup = PopupWindow(view, width, height, true).apply {
            setBackgroundDrawable(bg)
            isOutsideTouchable = true
            elevation = dp(ctx, 10).toFloat()
            animationStyle = R.style.Evergreen_MenuPopupAnim
        }
        pw = popup

        val wantLeft = loc[0].coerceIn(dp(ctx, 8), (dm.widthPixels - width - dp(ctx, 8)).coerceAtLeast(dp(ctx, 8)))
        view.pivotX = (loc[0] + anchor.width / 2f - wantLeft).coerceIn(0f, width.toFloat())
        view.pivotY = 0f
        view.alpha = 0f
        view.scaleX = 0.94f
        view.scaleY = 0.9f
        popup.showAsDropDown(anchor, wantLeft - loc[0], dp(ctx, 4))
        Blur.behindPopup(popup, ctx)
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        return popup
    }

    /**
     * 목록 대신 직접 만든 내용을 담는 팝업 (현황 화면 등).
     * 내용이 길면 화면의 60% 높이까지만 보이고 그 안에서 스크롤된다.
     * @param secondaryLabel 왼쪽 버튼 글자 (없으면 버튼을 숨김)
     */
    fun panel(
        ctx: Context,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        widthDp: Int = 360,
        secondaryLabel: String? = null,
        onSecondary: ((Dialog) -> Unit)? = null,
        closeLabel: String = "닫기",
        build: (list: LinearLayout, dialog: Dialog) -> Unit
    ): Dialog {
        val (dialog, view) = create(ctx, title, subtitle, headerIcon, null, widthDp)
        val list = view.findViewById<LinearLayout>(R.id.popupList)
        build(list, dialog)

        // 내용이 화면보다 길면 스크롤 영역 높이를 제한해서 아래 버튼이 밀려나지 않게 한다
        val dm = ctx.resources.displayMetrics
        val cap = (dm.heightPixels * 0.6f).toInt()
        val widthPx = minOf(dp(ctx, widthDp), (dm.widthPixels * 0.92f).toInt()) - dp(ctx, 16)
        list.measure(
            View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        if (list.measuredHeight > cap) {
            val scroll = view.findViewById<View>(R.id.popupScroll)
            scroll.layoutParams = scroll.layoutParams.apply { height = cap }
        }

        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).apply {
            if (secondaryLabel == null) {
                visibility = View.GONE
            } else {
                text = secondaryLabel
                setOnClickListener { onSecondary?.invoke(dialog) }
            }
        }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = closeLabel
            setOnClickListener { dialog.dismiss() }
        }
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        return dialog
    }

    fun confirm(
        ctx: Context,
        title: String,
        message: String,
        positive: String = "확인",
        danger: Boolean = false,
        onOk: () -> Unit
    ): Dialog {
        val (dialog, view) = create(ctx, title, null, null, null)
        view.findViewById<TextView>(R.id.popupMessage).apply {
            text = message
            visibility = View.VISIBLE
        }
        view.findViewById<View>(R.id.popupScroll).visibility = View.GONE
        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).setOnClickListener { dialog.dismiss() }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = positive
            if (danger) setTextColor(DANGER)
            setOnClickListener {
                dialog.dismiss()
                onOk()
            }
        }
        dialog.show()
        return dialog
    }
}
