package com.example.evergreen

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.InputType
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.color.MaterialColors
import com.google.android.material.textfield.TextInputEditText

/** 다운로드 목록 / 북마크 화면이 같이 쓰는 도우미 (폴더 칩, 폴더 선택, 이름 입력, 북마크 편집). */
object ListUi {

    /** "전체" 칩의 id (실제 폴더 id 는 항상 양수) */
    const val ALL = -1L

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    fun fmtSize(n: Long): String = when {
        n >= 1L shl 30 -> String.format("%.2f GB", n / (1024.0 * 1024 * 1024))
        n >= 1L shl 20 -> String.format("%.1f MB", n / (1024.0 * 1024))
        n >= 1L shl 10 -> String.format("%.0f KB", n / 1024.0)
        else -> "$n B"
    }

    // ───────────────────────── 글자 입력 대화상자 ─────────────────────────

    fun promptText(
        ctx: Context,
        title: String,
        initial: String,
        hint: String,
        onOk: (String) -> Unit
    ) {
        val et = EditText(ctx)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setSingleLine(true)
        et.hint = hint
        et.setText(initial)
        et.setSelection(et.text.length)

        val box = FrameLayout(ctx)
        box.setPadding(dp(ctx, 24), dp(ctx, 12), dp(ctx, 24), 0)
        box.addView(
            et,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val dialog = MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(box)
            .setNegativeButton("취소", null)
            .setPositiveButton("확인") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) onOk(s)
            }
            .create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        et.requestFocus()
    }

    // ───────────────────────── 폴더 칩 ─────────────────────────

    class ChipEntry(val id: Long, val label: String)

    /**
     * 화면 위쪽의 폴더 칩 줄을 다시 그린다.
     * 칩을 누르면 onSelect, 폴더 칩을 길게 누르면 onLongPress, 맨 끝 "＋ 폴더" 를 누르면 onAdd.
     */
    fun renderChips(
        row: LinearLayout,
        entries: List<ChipEntry>,
        selected: Long,
        onSelect: (Long) -> Unit,
        onLongPress: (Long) -> Unit,
        onAdd: (() -> Unit)? = null
    ) {
        val ctx = row.context
        row.removeAllViews()

        val onContainer = MaterialColors.getColor(row, com.google.android.material.R.attr.colorOnPrimaryContainer)
        val container = MaterialColors.getColor(row, com.google.android.material.R.attr.colorPrimaryContainer)
        val surfaceHigh = MaterialColors.getColor(row, com.google.android.material.R.attr.colorSurfaceContainerHigh)
        val onSurface = MaterialColors.getColor(row, com.google.android.material.R.attr.colorOnSurface)
        val outline = MaterialColors.getColor(row, com.google.android.material.R.attr.colorOutlineVariant)

        fun makeChip(text: String, on: Boolean, outlined: Boolean): TextView {
            val tv = TextView(ctx)
            tv.text = text
            tv.textSize = 13.5f
            tv.maxLines = 1
            tv.setPadding(dp(ctx, 14), dp(ctx, 7), dp(ctx, 14), dp(ctx, 7))
            tv.setTextColor(if (on) onContainer else onSurface)
            tv.background = GradientDrawable().apply {
                cornerRadius = dp(ctx, 18).toFloat()
                if (outlined) {
                    setColor(0)
                    setStroke(dp(ctx, 1), outline)
                } else {
                    setColor(if (on) container else surfaceHigh)
                }
            }
            tv.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(ctx, 4), 0, dp(ctx, 4), 0) }
            return tv
        }

        entries.forEach { e ->
            val chip = makeChip(e.label, e.id == selected, false)
            chip.setOnClickListener { onSelect(e.id) }
            if (e.id != ALL) {
                chip.setOnLongClickListener {
                    onLongPress(e.id)
                    true
                }
            }
            row.addView(chip)
        }
        if (onAdd != null) {
            val add = makeChip("＋ 폴더", false, true)
            add.setOnClickListener { onAdd() }
            row.addView(add)
        }
    }

    /** 폴더 칩을 길게 눌렀을 때: 이름 변경 / 삭제 */
    fun showFolderMenu(
        ctx: Context,
        prefs: Prefs,
        kind: String,
        folder: Folder,
        onChanged: () -> Unit
    ) {
        Popup.menu(
            ctx,
            title = folder.name,
            subtitle = "폴더",
            headerIcon = R.drawable.ic_folder,
            items = listOf(
                Popup.Item(R.drawable.ic_edit, "이름 변경") {
                    promptText(ctx, "폴더 이름 변경", folder.name, "폴더 이름") { name ->
                        prefs.renameFolder(kind, folder.id, name)
                        onChanged()
                    }
                },
                Popup.Item(R.drawable.ic_delete, "폴더 삭제", "안의 항목은 그대로 남습니다", danger = true) {
                    val what = if (kind == Prefs.KIND_BM) "북마크" else "파일"
                    Popup.confirm(
                        ctx, "폴더를 삭제할까요?",
                        "'${folder.name}' 폴더만 삭제되고, 안에 있던 ${what}은(는) 그대로 남습니다.",
                        "삭제", danger = true
                    ) {
                        prefs.removeFolder(kind, folder.id)
                        onChanged()
                    }
                }
            )
        )
    }

    /** 새 폴더 이름을 물어보고 만든다. */
    fun createFolder(ctx: Context, prefs: Prefs, kind: String, onCreated: (Folder) -> Unit) {
        promptText(ctx, "새 폴더", "", "폴더 이름") { name ->
            onCreated(prefs.addFolder(kind, name))
        }
    }

    /** 폴더 고르기: 폴더 없음 / 기존 폴더들 / 새 폴더 만들기. 고른 폴더 id (없음 = 0) 를 돌려준다. */
    fun pickFolder(
        ctx: Context,
        prefs: Prefs,
        kind: String,
        current: Long,
        onPick: (Long) -> Unit
    ) {
        val folders = prefs.folders(kind)
        val labels = ArrayList<String>()
        labels.add("폴더 없음")
        folders.forEach { labels.add(it.name) }
        labels.add("＋ 새 폴더 만들기")
        val checked = if (current == 0L) 0 else folders.indexOfFirst { it.id == current } + 1

        MaterialAlertDialogBuilder(ctx)
            .setTitle("폴더 선택")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                d.dismiss()
                when {
                    which == 0 -> onPick(0L)
                    which == labels.size - 1 -> createFolder(ctx, prefs, kind) { onPick(it.id) }
                    else -> onPick(folders[which - 1].id)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // ───────────────────────── 북마크 추가 / 수정 ─────────────────────────

    /** 주소가 http(s) 로 시작하지 않으면 https:// 를 붙인다. */
    fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        return if (s.startsWith("http://") || s.startsWith("https://")) s else "https://$s"
    }

    fun displayTitle(title: String, url: String): String =
        title.trim().ifEmpty { try { Uri.parse(url).host } catch (e: Exception) { null } ?: url }

    /**
     * 북마크 추가/수정 대화상자 (이름, 주소, 폴더). existing 이 있으면 수정 + 삭제 버튼이 나온다.
     * onDone 은 저장/삭제가 끝난 뒤 불린다.
     */
    fun showBookmarkEditor(
        activity: AppCompatActivity,
        prefs: Prefs,
        existing: Bookmark?,
        url: String,
        title: String,
        onDone: (message: String) -> Unit
    ) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_bookmark, null)
        val etTitle = view.findViewById<TextInputEditText>(R.id.etBmTitle)
        val etUrl = view.findViewById<TextInputEditText>(R.id.etBmUrl)
        val btnFolder = view.findViewById<Button>(R.id.btnBmFolder)

        etTitle.setText(existing?.title ?: title)
        etUrl.setText(existing?.url ?: url)

        var folderId = existing?.folderId ?: prefs.lastBookmarkFolder
        if (folderId != 0L && prefs.folders(Prefs.KIND_BM).none { it.id == folderId }) folderId = 0L

        fun showFolder() {
            btnFolder.text =
                prefs.folders(Prefs.KIND_BM).firstOrNull { it.id == folderId }?.name ?: "폴더 없음"
        }
        showFolder()
        btnFolder.setOnClickListener {
            pickFolder(activity, prefs, Prefs.KIND_BM, folderId) {
                folderId = it
                showFolder()
            }
        }

        val builder = MaterialAlertDialogBuilder(activity)
            .setTitle(if (existing == null) "북마크 추가" else "북마크 수정")
            .setView(view)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                val rawUrl = etUrl.text.toString().trim()
                if (rawUrl.isEmpty()) {
                    toast(activity, "주소를 입력하세요")
                } else {
                    val finalUrl = normalizeUrl(rawUrl)
                    val finalTitle = displayTitle(etTitle.text.toString(), finalUrl)
                    prefs.saveBookmark(finalUrl, finalTitle, folderId, existing?.id)
                    prefs.lastBookmarkFolder = folderId
                    onDone(if (existing == null) "북마크에 추가했습니다" else "북마크를 수정했습니다")
                }
            }
        if (existing != null) {
            builder.setNeutralButton("삭제") { _, _ ->
                prefs.removeBookmark(existing.id)
                onDone("북마크를 삭제했습니다")
            }
        }
        builder.show()
    }
}
