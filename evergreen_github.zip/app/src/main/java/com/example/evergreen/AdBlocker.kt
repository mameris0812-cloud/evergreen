package com.example.evergreen

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

/**
 * 도메인 기반 광고/트래커 차단기.
 * - 내장 목록 + (선택) 내려받은 목록을 합쳐서 사용
 * - 서브도메인도 함께 차단 (예: x.doubleclick.net -> doubleclick.net)
 */
class AdBlocker(private val context: Context) {

    @Volatile
    private var hosts: Set<String> = BUILTIN

    val blockedCount = AtomicInteger(0)

    private val listFile: File get() = File(context.filesDir, "adblock_hosts.txt")

    fun load() {
        val f = listFile
        if (!f.exists()) return
        try {
            val extra = f.readLines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            hosts = BUILTIN + extra
        } catch (e: Exception) {
            // 내장 목록만 사용
        }
    }

    fun isBlocked(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        val set = hosts
        var h = host.lowercase()
        while (true) {
            if (set.contains(h)) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
            if (!h.contains('.')) return false // TLD 단독은 검사하지 않음
        }
    }

    /** 네트워크 작업이므로 반드시 백그라운드 스레드에서 호출. 적용된 도메인 수를 반환. */
    fun update(): Int {
        val conn = URL(LIST_URL).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("User-Agent", "Evergreen/1.1")
            val lines = conn.inputStream.bufferedReader(Charsets.UTF_8).useLines { seq ->
                seq.map { it.trim().lowercase() }
                    .filter { it.isNotEmpty() && !it.startsWith("#") }
                    .map { it.substringAfterLast(' ').substringAfterLast('\t') } // hosts 파일 형식도 허용
                    .filter { HOST_REGEX.matches(it) && it != "localhost" }
                    .take(200_000)
                    .toList()
            }
            if (lines.isEmpty()) throw IOException("빈 목록")
            listFile.writeText(lines.joinToString("\n"))
            hosts = BUILTIN + lines
            return hosts.size
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private const val LIST_URL =
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext"

        private val HOST_REGEX =
            Regex("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")

        /** 화면에서 광고 영역을 숨기는 CSS 선택자 (네트워크 차단을 빠져나간 요소용) */
        private val COSMETIC_SELECTORS = listOf(
            "ins.adsbygoogle",
            ".adsbygoogle",
            ".google-auto-placed",
            "iframe[src*=\"doubleclick.net\"]",
            "iframe[src*=\"googlesyndication.com\"]",
            "iframe[src*=\"adnxs.com\"]",
            "iframe[id^=\"google_ads_iframe\"]",
            "div[id^=\"div-gpt-ad\"]",
            "div[id^=\"google_ads\"]",
            "[data-ad-slot]",
            "[data-google-query-id]",
            "div[class*=\"adsbox\"]",
            "div[id*=\"taboola\"]",
            "div[class*=\"taboola\"]",
            "div[id*=\"outbrain\"]",
            ".OUTBRAIN"
        ).joinToString(",")

        val COSMETIC_JS: String =
            "(function(){if(document.getElementById('__sb_adblock'))return;" +
                "var s=document.createElement('style');s.id='__sb_adblock';" +
                "s.textContent='" + COSMETIC_SELECTORS + "{display:none!important}';" +
                "(document.head||document.documentElement).appendChild(s);})();"

        val BUILTIN: Set<String> = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "google-analytics.com", "adservice.google.com", "2mdn.net", "admob.com",
            "adnxs.com", "adsrvr.org", "advertising.com", "amazon-adsystem.com",
            "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "rubiconproject.com", "pubmatic.com", "openx.net", "moatads.com",
            "scorecardresearch.com", "quantserve.com", "casalemedia.com", "adform.net",
            "smartadserver.com", "serving-sys.com", "yieldmo.com", "teads.tv",
            "popads.net", "propellerads.com", "exoclick.com", "juicyads.com",
            "trafficjunky.com", "popcash.net", "adsterra.com", "mgid.com",
            "revcontent.com", "zedo.com", "media.net", "bidswitch.net", "33across.com",
            "sharethrough.com", "indexww.com", "lijit.com", "sovrn.com",
            "contextweb.com", "yieldlab.net", "adcolony.com", "applovin.com",
            "mopub.com", "inmobi.com", "chartboost.com", "vungle.com", "hotjar.com",
            "adtechus.com", "adition.com", "richaudience.com", "triplelift.com",
            "gumgum.com", "smaato.net", "ads.yahoo.com",
            // 국내 광고 서버
            "adfit.kakao.com", "display.ad.daum.net", "veta.naver.com",
            "adcr.naver.com", "dable.io"
        )
    }
}
