package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.animation.DecelerateInterpolator
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 만화 한 장을 보여주는 이미지 뷰.
 * - 기본: 화면에 맞춰 보여주고, 세로로 아주 긴 이미지(웹툰)는 가로를 맞추고 위에서부터 보여준다.
 * - 두 손가락으로 확대/축소, 두 번 탭하면 확대/원래대로, 확대 중에는 드래그로 이동.
 * - 확대하지 않았거나 이미지 가장자리에 닿으면 터치를 페이저에게 넘겨 다음 장으로 넘어간다.
 */
class ZoomImageView(context: Context) : AppCompatImageView(context) {

    private val mtx = Matrix()
    private val vals = FloatArray(9)
    private val tmp = RectF()
    private var bmpW = 0
    private var bmpH = 0
    private var baseScale = 1f
    private var zoomAnim: ValueAnimator? = null

    /** 한 번 탭했을 때 (가로 위치 0..1) */
    var onTap: ((Float) -> Unit)? = null

    init {
        scaleType = ScaleType.MATRIX
    }

    // ───────────── 종이 넘김(말림) 효과 ─────────────
    // 페이지 넘길 때 이 뷰가 종이처럼 자유로운 끝부터 둥글게 말려 올라가며 넘어간다.
    // curl: 0 = 평평함 .. 1 = 완전히 넘어감 / spineOnLeft: 책등(묶인 쪽)이 왼쪽인지

    private var bitmap: Bitmap? = null

    var spineOnLeft = true

    var curl = 0f
        set(v) {
            val nv = v.coerceIn(0f, 1f)
            if (field != nv) {
                field = nv
                invalidate()
            }
        }

    private val meshPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    // 종이 뒷면: 앞면 그림이 희미하게 비쳐 보이는 밝은 종이색
    private val backPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    0.30f, 0f, 0f, 0f, 176f,
                    0f, 0.30f, 0f, 0f, 172f,
                    0f, 0f, 0.30f, 0f, 162f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    private val shadowPaint = Paint()
    private val curlVerts = FloatArray((CURL_COLS + 1) * (CURL_ROWS + 1) * 2)
    private val frontColors = IntArray((CURL_COLS + 1) * (CURL_ROWS + 1))
    private val backColors = IntArray((CURL_COLS + 1) * (CURL_ROWS + 1))
    private val pt = FloatArray(2)

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap
        if (curl <= 0.003f || bmp == null || width == 0 || height == 0 || bmpW == 0) {
            super.onDraw(canvas)
            return
        }
        try {
            drawCurl(canvas, bmp)
        } catch (e: Exception) {
            super.onDraw(canvas)
        }
    }

    private fun gray(alpha: Int, c: Int): Int = (alpha shl 24) or (c shl 16) or (c shl 8) or c

    private fun drawCurl(canvas: Canvas, bmp: Bitmap) {
        val w = width.toFloat()
        val h = height.toFloat()
        val p = curl
        val r = w * 0.075f                       // 종이가 말리는 둥근 부분의 반지름
        val fold = w - p * (w + r)               // 접히는 선 (책등 기준 가로 좌표 u)
        val cy = h / 2f
        val half = (Math.PI / 2).toFloat()
        val pi = Math.PI.toFloat()

        var vi = 0
        var ci = 0
        for (j in 0..CURL_ROWS) {
            for (i in 0..CURL_COLS) {
                pt[0] = bmpW * i / CURL_COLS.toFloat()
                pt[1] = bmpH * j / CURL_ROWS.toFloat()
                mtx.mapPoints(pt)
                val x = pt[0]
                val y = pt[1]
                val u = if (spineOnLeft) x else w - x

                var uu = u
                var z = 0f
                var light = 1f
                var isBack = false
                if (u > fold) {
                    val d = u - fold
                    val th = d / r
                    if (th <= pi) {
                        uu = fold + r * sin(th)
                        z = r * (1f - cos(th))
                        if (th <= half) {
                            light = 1f - 0.30f * sin(th)               // 앞면: 모서리로 갈수록 어두워짐
                        } else {
                            isBack = true
                            light = 0.72f + 0.28f * (1f - sin(th))     // 뒷면: 가장 높은 곳이 가장 어두움
                        }
                    } else {
                        uu = fold - (d - pi * r)                       // 뒤집혀 평평하게 덮인 부분
                        z = 2f * r
                        isBack = true
                        light = 1f
                    }
                }
                // 들린 부분은 눈에 가까워져 살짝 커 보인다
                val sc = 1f + z / (w * 1.4f)
                val yy = cy + (y - cy) * sc
                val xx = if (spineOnLeft) uu else w - uu
                curlVerts[vi++] = xx
                curlVerts[vi++] = yy

                val c = (light.coerceIn(0f, 1f) * 255f).toInt()
                frontColors[ci] = if (isBack) 0 else gray(255, c)
                backColors[ci] = if (isBack) gray(255, c) else 0
                ci++
            }
        }

        val fade = min(1f, min(p / 0.06f, (1f - p) / 0.12f)).coerceIn(0f, 1f)

        // 1) 아래 깔린 다음 장 위에 드리우는 그림자 (말린 부분 바깥쪽)
        val edge = fold + r
        if (edge < w) {
            shadowU(canvas, edge, edge + r * 2.6f, 0.42f * fade, 0f)
        }
        // 2) 앞면(평평한 부분 + 말려 올라가는 앞면)
        canvas.drawBitmapMesh(bmp, CURL_COLS, CURL_ROWS, curlVerts, 0, frontColors, 0, meshPaint)
        // 3) 뒤집혀 덮인 종이 끝이 아래 종이에 드리우는 그림자
        val flap = w - fold - pi * r
        if (flap > 0f) {
            val tip = fold - flap
            shadowU(canvas, tip - r * 1.6f, tip, 0f, 0.34f * fade)
        }
        // 4) 종이 뒷면
        canvas.drawBitmapMesh(bmp, CURL_COLS, CURL_ROWS, curlVerts, 0, backColors, 0, backPaint)
    }

    /** 책등 기준 좌표 u0..u1 구간에 가로 그라데이션 그림자를 그린다. (알파 a0 → a1) */
    private fun shadowU(canvas: Canvas, u0: Float, u1: Float, a0: Float, a1: Float) {
        val w = width.toFloat()
        val x0 = if (spineOnLeft) u0 else w - u0
        val x1 = if (spineOnLeft) u1 else w - u1
        val left = max(0f, min(x0, x1))
        val right = min(w, max(x0, x1))
        if (right - left < 1f || abs(x1 - x0) < 1f) return
        val c0 = ((a0.coerceIn(0f, 1f) * 255f).toInt() shl 24)
        val c1 = ((a1.coerceIn(0f, 1f) * 255f).toInt() shl 24)
        shadowPaint.shader = LinearGradient(x0, 0f, x1, 0f, c0, c1, Shader.TileMode.CLAMP)
        canvas.drawRect(left, 0f, right, height.toFloat(), shadowPaint)
    }

    fun setPage(bmp: Bitmap?) {
        zoomAnim?.cancel()
        bitmap = bmp
        curl = 0f
        setImageBitmap(bmp)
        bmpW = bmp?.width ?: 0
        bmpH = bmp?.height ?: 0
        resetFit()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resetFit()
    }

    private fun resetFit() {
        if (bmpW == 0 || bmpH == 0 || width == 0 || height == 0) return
        val fit = min(width.toFloat() / bmpW, height.toFloat() / bmpH)
        val fitW = width.toFloat() / bmpW
        // 화면 높이의 1.8배보다 길면 웹툰 형태로 보고 가로 맞춤
        baseScale = if (bmpH * fitW > height * 1.8f) fitW else fit
        mtx.reset()
        mtx.postScale(baseScale, baseScale)
        val dw = bmpW * baseScale
        val dh = bmpH * baseScale
        mtx.postTranslate((width - dw) / 2f, if (dh <= height) (height - dh) / 2f else 0f)
        imageMatrix = mtx
    }

    private fun curScale(): Float {
        mtx.getValues(vals)
        return vals[Matrix.MSCALE_X]
    }

    private fun isZoomed(): Boolean = curScale() > baseScale * 1.03f

    private fun bounds(): RectF {
        tmp.set(0f, 0f, bmpW.toFloat(), bmpH.toFloat())
        mtx.mapRect(tmp)
        return tmp
    }

    private fun fixBounds() {
        val r = bounds()
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) {
            dx = (width - r.width()) / 2f - r.left
        } else if (r.left > 0) {
            dx = -r.left
        } else if (r.right < width) {
            dx = width - r.right
        }
        if (r.height() <= height) {
            dy = (height - r.height()) / 2f - r.top
        } else if (r.top > 0) {
            dy = -r.top
        } else if (r.bottom < height) {
            dy = height - r.bottom
        }
        mtx.postTranslate(dx, dy)
    }

    private fun applyMatrix() {
        fixBounds()
        imageMatrix = mtx
    }

    private fun zoomBy(factor: Float, fx: Float, fy: Float) {
        if (bmpW == 0) return
        val cur = curScale()
        val target = (cur * factor).coerceIn(baseScale, baseScale * 5f)
        val f = target / cur
        mtx.postScale(f, f, fx, fy)
        applyMatrix()
    }

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomBy(detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (width > 0) onTap?.invoke(e.x / width)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (bmpW == 0) return true
            val from = curScale()
            val to = if (isZoomed()) baseScale else baseScale * 2.5f
            zoomAnim?.cancel()
            zoomAnim = ValueAnimator.ofFloat(from, to).apply {
                duration = 240
                interpolator = DecelerateInterpolator(1.6f)
                addUpdateListener {
                    val s = it.animatedValue as Float
                    zoomBy(s / curScale(), e.x, e.y)
                }
                start()
            }
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (scaleDetector.isInProgress || bmpW == 0) return false
            val r = bounds()
            val canLeft = r.right > width + 1f   // 손가락을 왼쪽으로 밀 여지
            val canRight = r.left < -1f          // 손가락을 오른쪽으로 밀 여지
            // 가장자리에 닿은 채 가로로 더 밀면 페이저가 다음 장으로 넘기도록 터치를 돌려준다.
            if (abs(distanceX) > abs(distanceY) &&
                ((distanceX > 0 && !canLeft) || (distanceX < 0 && !canRight))
            ) {
                parent?.requestDisallowInterceptTouchEvent(false)
                return false
            }
            mtx.postTranslate(-distanceX, -distanceY)
            applyMatrix()
            return true
        }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                parent?.requestDisallowInterceptTouchEvent(isZoomed())
            MotionEvent.ACTION_POINTER_DOWN ->
                parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    companion object {
        private const val CURL_COLS = 72
        private const val CURL_ROWS = 4
    }
}
