package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.animation.DecelerateInterpolator
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.abs
import kotlin.math.min

/**
 * 만화 한 장을 보여주는 이미지 뷰.
 * - 기본: 화면에 맞춰 보여주고, 세로로 아주 긴 이미지(웹툰)는 가로를 맞추고 위에서부터 보여준다.
 * - 두 손가락으로 확대/축소, 두 번 탭하면 확대/원래대로, 확대 중에는 드래그로 이동.
 * - 확대하지 않았거나 이미지 가장자리에 닿으면 터치를 페이저에게 넘겨 다음 장으로 넘어간다.
 */
class ZoomImageView(context: Context) : AppCompatImageView(context) {

    private val mtx = Matrix()
    private val vals = FloatArray(9)
    private val tmp = RectF()
    private var bmpW = 0
    private var bmpH = 0
    private var baseScale = 1f
    private var zoomAnim: ValueAnimator? = null

    /** 한 번 탭했을 때 (가로 위치 0..1) */
    var onTap: ((Float) -> Unit)? = null

    init {
        scaleType = ScaleType.MATRIX
    }

    fun setPage(bmp: Bitmap?) {
        zoomAnim?.cancel()
        setImageBitmap(bmp)
        bmpW = bmp?.width ?: 0
        bmpH = bmp?.height ?: 0
        resetFit()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resetFit()
    }

    private fun resetFit() {
        if (bmpW == 0 || bmpH == 0 || width == 0 || height == 0) return
        val fit = min(width.toFloat() / bmpW, height.toFloat() / bmpH)
        val fitW = width.toFloat() / bmpW
        // 화면 높이의 1.8배보다 길면 웹툰 형태로 보고 가로 맞춤
        baseScale = if (bmpH * fitW > height * 1.8f) fitW else fit
        mtx.reset()
        mtx.postScale(baseScale, baseScale)
        val dw = bmpW * baseScale
        val dh = bmpH * baseScale
        mtx.postTranslate((width - dw) / 2f, if (dh <= height) (height - dh) / 2f else 0f)
        imageMatrix = mtx
    }

    private fun curScale(): Float {
        mtx.getValues(vals)
        return vals[Matrix.MSCALE_X]
    }

    private fun isZoomed(): Boolean = curScale() > baseScale * 1.03f

    private fun bounds(): RectF {
        tmp.set(0f, 0f, bmpW.toFloat(), bmpH.toFloat())
        mtx.mapRect(tmp)
        return tmp
    }

    private fun fixBounds() {
        val r = bounds()
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) {
            dx = (width - r.width()) / 2f - r.left
        } else if (r.left > 0) {
            dx = -r.left
        } else if (r.right < width) {
            dx = width - r.right
        }
        if (r.height() <= height) {
            dy = (height - r.height()) / 2f - r.top
        } else if (r.top > 0) {
            dy = -r.top
        } else if (r.bottom < height) {
            dy = height - r.bottom
        }
        mtx.postTranslate(dx, dy)
    }

    private fun applyMatrix() {
        fixBounds()
        imageMatrix = mtx
    }

    private fun zoomBy(factor: Float, fx: Float, fy: Float) {
        if (bmpW == 0) return
        val cur = curScale()
        val target = (cur * factor).coerceIn(baseScale, baseScale * 5f)
        val f = target / cur
        mtx.postScale(f, f, fx, fy)
        applyMatrix()
    }

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomBy(detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (width > 0) onTap?.invoke(e.x / width)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (bmpW == 0) return true
            val from = curScale()
            val to = if (isZoomed()) baseScale else baseScale * 2.5f
            zoomAnim?.cancel()
            zoomAnim = ValueAnimator.ofFloat(from, to).apply {
                duration = 240
                interpolator = DecelerateInterpolator(1.6f)
                addUpdateListener {
                    val s = it.animatedValue as Float
                    zoomBy(s / curScale(), e.x, e.y)
                }
                start()
            }
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (scaleDetector.isInProgress || bmpW == 0) return false
            val r = bounds()
            val canLeft = r.right > width + 1f   // 손가락을 왼쪽으로 밀 여지
            val canRight = r.left < -1f          // 손가락을 오른쪽으로 밀 여지
            // 가장자리에 닿은 채 가로로 더 밀면 페이저가 다음 장으로 넘기도록 터치를 돌려준다.
            if (abs(distanceX) > abs(distanceY) &&
                ((distanceX > 0 && !canLeft) || (distanceX < 0 && !canRight))
            ) {
                parent?.requestDisallowInterceptTouchEvent(false)
                return false
            }
            mtx.postTranslate(-distanceX, -distanceY)
            applyMatrix()
            return true
        }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                parent?.requestDisallowInterceptTouchEvent(isZoomed())
            MotionEvent.ACTION_POINTER_DOWN ->
                parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }
}
