package com.example.evergreen

/**
 * Adblock Plus / uBlock Origin / AdGuard 문법의 네트워크 필터 엔진.
 * EasyList · EasyPrivacy · uBlock Origin · AdGuard · List-KR 같은 오픈소스 목록의 규칙을 그대로 읽어서 쓴다.
 *
 * 지원하는 문법
 *  - `||example.com^`(도메인 시작), `|`(주소 처음/끝), `*`(아무 글자), `^`(구분자)
 *  - `@@` 예외 규칙, `$important`
 *  - 옵션: `third-party` / `~third-party`, `domain=a.com|~b.com`, 요청 종류(script, image, stylesheet, xmlhttprequest,
 *    subdocument, media, font, ping, websocket, other, object 와 그 반대 ~종류)
 *  지원하지 않는 옵션(redirect, removeparam, csp, popup, 정규식 규칙 등)이 붙은 규칙은 잘못 막지 않도록 통째로 버린다.
 *
 * 속도: 규칙마다 가장 긴 영숫자 조각(토큰)을 뽑아 해시 색인에 넣고, 요청 주소의 조각들만 찾아본다 (uBlock/Brave 방식).
 * 이 파일은 안드로이드에 의존하지 않는다.
 */
class NetFilter {

    class Rule(
        val pattern: String,
        val hostAnchor: Boolean,
        val startAnchor: Boolean,
        val endAnchor: Boolean,
        /** 0 = 문서를 뺀 모든 종류 */
        val types: Int,
        /** 0 = 상관없음, 1 = 서드파티만, 2 = 퍼스트파티만 */
        val third: Int,
        val domainsIn: Array<String>?,
        val domainsEx: Array<String>?,
        val important: Boolean,
        val exception: Boolean
    ) {
        /** `||host^` 처럼 도메인 전체만 막는 단순 규칙인지 (호스트 목록으로 처리 가능) */
        val isPureHost: Boolean
            get() = hostAnchor && !endAnchor && types == 0 && third == 0 && domainsIn == null &&
                domainsEx == null && !important &&
                pattern.length > 1 && pattern.endsWith("^") &&
                pattern.indexOf('^') == pattern.length - 1 &&
                pattern.none { it == '/' || it == '*' || it == '?' || it == ':' }

        val host: String get() = pattern.removeSuffix("^")
    }

    private class Index {
        val map = HashMap<String, ArrayList<Rule>>()
        val noToken = ArrayList<Rule>()
        var size = 0

        fun add(r: Rule) {
            size++
            val t = tokenOf(r)
            if (t == null) {
                noToken.add(r)
            } else {
                map.getOrPut(t) { ArrayList(1) }.add(r)
            }
        }
    }

    @Volatile private var blocks = Index()
    @Volatile private var excepts = Index()

    /** 차단 규칙 + 예외 규칙 수 */
    val size: Int get() = blocks.size + excepts.size

    /** 규칙 줄들로 색인을 새로 만들어 한 번에 바꿔 끼운다 (읽는 쪽은 멈추지 않는다) */
    fun load(lines: Iterable<String>) {
        val b = Index()
        val e = Index()
        for (line in lines) {
            val r = parse(line) ?: continue
            if (r.exception) e.add(r) else b.add(r)
        }
        blocks = b
        excepts = e
    }

    /** 이 요청을 막아야 하는지 (예외 규칙이 풀어 주면 false) */
    fun shouldBlock(url: String, host: String, pageHost: String?, third: Boolean, type: Int): Boolean {
        val u = prepare(url)
        val hs = hostStart(u)
        val he = hostEnd(u, hs)
        val hit = find(blocks, u, hs, he, pageHost, third, type) ?: return false
        if (hit.important) return true
        return find(excepts, u, hs, he, pageHost, third, type) == null
    }

    /** 예외 규칙(@@)에 걸리는지: 목록에 오른 도메인을 사이트가 동작하도록 풀어 줄 때 쓴다 */
    fun isException(url: String, host: String, pageHost: String?, third: Boolean, type: Int): Boolean {
        if (excepts.size == 0) return false
        val u = prepare(url)
        val hs = hostStart(u)
        return find(excepts, u, hs, hostEnd(u, hs), pageHost, third, type) != null
    }

    // ───────────────────────── 찾기 ─────────────────────────

    private fun prepare(url: String): String {
        val s = if (url.length > MAX_URL) url.substring(0, MAX_URL) else url
        return s.lowercase()
    }

    private fun hostStart(u: String): Int {
        val i = u.indexOf("://")
        return if (i < 0) 0 else i + 3
    }

    private fun hostEnd(u: String, start: Int): Int {
        var i = start
        while (i < u.length) {
            val c = u[i]
            if (c == '/' || c == '?' || c == '#') break
            i++
        }
        return i
    }

    private fun find(
        ix: Index, u: String, hs: Int, he: Int,
        pageHost: String?, third: Boolean, type: Int
    ): Rule? {
        if (ix.size == 0) return null
        val n = u.length
        var i = 0
        while (i < n) {
            if (isAlnum(u[i])) {
                var j = i + 1
                while (j < n && isAlnum(u[j])) j++
                if (j - i >= MIN_TOKEN) {
                    val list = ix.map[u.substring(i, j)]
                    if (list != null) {
                        for (r in list) if (matches(r, u, hs, he, pageHost, third, type)) return r
                    }
                }
                i = j
            } else {
                i++
            }
        }
        for (r in ix.noToken) if (matches(r, u, hs, he, pageHost, third, type)) return r
        return null
    }

    private fun matches(
        r: Rule, u: String, hs: Int, he: Int,
        pageHost: String?, third: Boolean, type: Int
    ): Boolean {
        if (r.types == 0) {
            if (type == T_DOC) return false
        } else if (r.types and type == 0) {
            return false
        }
        if (r.third == 1 && !third) return false
        if (r.third == 2 && third) return false
        val din = r.domainsIn
        if (din != null) {
            if (pageHost == null || !inDomains(pageHost, din)) return false
        }
        val dex = r.domainsEx
        if (dex != null && pageHost != null && inDomains(pageHost, dex)) return false

        val p = r.pattern
        if (r.hostAnchor) {
            var i = hs
            while (i < he) {
                if (i == hs || u[i - 1] == '.') {
                    if (matchAt(p, 0, u, i, r.endAnchor)) return true
                }
                i++
            }
            return false
        }
        if (r.startAnchor) return matchAt(p, 0, u, 0, r.endAnchor)
        val c0 = p[0]
        val any = c0 == '*' || c0 == '^'
        var i = 0
        while (i <= u.length) {
            if (any || (i < u.length && u[i] == c0)) {
                if (matchAt(p, 0, u, i, r.endAnchor)) return true
            }
            i++
        }
        return false
    }

    private fun inDomains(host: String, list: Array<String>): Boolean {
        for (d in list) {
            if (host == d) return true
            if (host.length > d.length && host.endsWith(d) && host[host.length - d.length - 1] == '.') return true
        }
        return false
    }

    /** 패턴 p(pi 부터)가 주소 u(ui 부터)와 맞는지. '*' 는 되돌아가며 시도하고 '^' 는 구분자 한 글자(또는 주소 끝). */
    private fun matchAt(p: String, pStart: Int, u: String, uStart: Int, endAnchor: Boolean): Boolean {
        var pi = pStart
        var ui = uStart
        while (pi < p.length) {
            val c = p[pi]
            if (c == '*') {
                while (pi < p.length && p[pi] == '*') pi++
                if (pi == p.length) return true
                val next = p[pi]
                var k = ui
                while (k <= u.length) {
                    if (next == '^' || (k < u.length && u[k] == next)) {
                        if (matchAt(p, pi, u, k, endAnchor)) return true
                    }
                    k++
                }
                return false
            }
            if (c == '^') {
                if (ui == u.length) {
                    pi++
                    continue
                }
                if (!isSeparator(u[ui])) return false
                ui++
                pi++
                continue
            }
            if (ui >= u.length || u[ui] != c) return false
            ui++
            pi++
        }
        return !endAnchor || ui == u.length
    }

    // ───────────────────────── 규칙 읽기 ─────────────────────────

    companion object {
        const val T_DOC = 1
        const val T_SCRIPT = 1 shl 1
        const val T_IMAGE = 1 shl 2
        const val T_CSS = 1 shl 3
        const val T_XHR = 1 shl 4
        const val T_SUBDOC = 1 shl 5
        const val T_MEDIA = 1 shl 6
        const val T_FONT = 1 shl 7
        const val T_PING = 1 shl 8
        const val T_WS = 1 shl 9
        const val T_OTHER = 1 shl 10
        const val T_OBJECT = 1 shl 11

        /** 문서를 뺀 모든 종류 */
        private const val T_ALL = T_SCRIPT or T_IMAGE or T_CSS or T_XHR or T_SUBDOC or T_MEDIA or
            T_FONT or T_PING or T_WS or T_OTHER or T_OBJECT

        /** 종류를 알 수 없을 때(확장자 없는 스크립트/XHR/fetch): 이 세 가지 중 하나로 본다 */
        const val T_ANY = T_SCRIPT or T_XHR or T_OTHER

        private const val MAX_URL = 2000
        private const val MIN_TOKEN = 3

        private fun isAlnum(c: Char) = (c in 'a'..'z') || (c in '0'..'9')

        /** 광고 필터에서 '^' 가 가리키는 구분자: 영문·숫자·_ - . % 를 뺀 모든 글자 */
        private fun isSeparator(c: Char) =
            !((c in 'a'..'z') || (c in '0'..'9') || c == '_' || c == '-' || c == '.' || c == '%')

        /** 규칙을 색인할 토큰: 양옆이 주소 조각 경계로 확실한 영숫자 덩어리 중 가장 긴 것 */
        private fun tokenOf(r: Rule): String? {
            val p = r.pattern
            var best: String? = null
            var i = 0
            while (i < p.length) {
                if (isAlnum(p[i])) {
                    var j = i + 1
                    while (j < p.length && isAlnum(p[j])) j++
                    val leftOk = if (i == 0) (r.hostAnchor || r.startAnchor) else p[i - 1] != '*'
                    val rightOk = if (j == p.length) r.endAnchor else p[j] != '*'
                    if (leftOk && rightOk && j - i >= MIN_TOKEN && (best == null || j - i > best.length)) {
                        best = p.substring(i, j)
                    }
                    i = j
                } else {
                    i++
                }
            }
            return best
        }

        /** 주소·Accept 헤더로 요청 종류를 짐작한다 (WebView 는 종류를 알려 주지 않는다) */
        fun inferType(url: String, accept: String?, isMainFrame: Boolean): Int {
            if (isMainFrame) return T_DOC
            val q = url.indexOfAny(charArrayOf('?', '#'))
            val path = if (q >= 0) url.substring(0, q) else url
            val dot = path.lastIndexOf('.')
            val slash = path.lastIndexOf('/')
            if (dot > slash && path.length - dot <= 6) {
                when (path.substring(dot + 1).lowercase()) {
                    "js", "mjs" -> return T_SCRIPT
                    "css" -> return T_CSS
                    "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "avif", "bmp" -> return T_IMAGE
                    "woff", "woff2", "ttf", "otf", "eot" -> return T_FONT
                    "mp4", "webm", "m4v", "mp3", "m4a", "ogg", "mov", "ts" -> return T_MEDIA
                    "html", "htm" -> return T_SUBDOC
                }
            }
            val a = accept?.lowercase().orEmpty()
            return when {
                a.contains("text/css") -> T_CSS
                a.startsWith("image/") -> T_IMAGE
                a.contains("text/html") -> T_SUBDOC
                a.startsWith("video/") || a.startsWith("audio/") -> T_MEDIA
                else -> T_ANY
            }
        }

        /** 줄 하나를 규칙으로. 주석·화면 숨김 규칙·지원하지 않는 문법이면 null */
        fun parse(line: String): Rule? {
            var s = line.trim()
            if (s.length < 3) return null
            val c0 = s[0]
            if (c0 == '!' || c0 == '[' || c0 == '#') return null
            if (s.contains("##") || s.contains("#@#") || s.contains("#?#") || s.contains("#$#") ||
                s.contains("#%#") || s.contains("#@$#") || s.contains("#@?#") || s.contains("+js(")
            ) return null

            var exception = false
            if (s.startsWith("@@")) {
                exception = true
                s = s.substring(2)
            }

            var opts: String? = null
            val d = s.lastIndexOf('$')
            if (d >= 0) {
                val cand = s.substring(d + 1)
                if (cand.isNotEmpty() && cand.all { it.isLetterOrDigit() || it in "~_,=|.-*:" }) {
                    opts = cand
                    s = s.substring(0, d)
                }
            }
            // 정규식 규칙(/.../)은 지원하지 않는다
            if (s.length > 2 && s.startsWith("/") && s.endsWith("/")) return null

            var host = false
            var start = false
            var end = false
            if (s.startsWith("||")) {
                host = true
                s = s.substring(2)
            } else if (s.startsWith("|")) {
                start = true
                s = s.substring(1)
            }
            if (s.endsWith("|")) {
                end = true
                s = s.substring(0, s.length - 1)
            }
            if (s.isEmpty() || s == "*") return null
            val pattern = s.lowercase()
            if (pattern.count { it == '*' } > 4) return null
            // 너무 짧고 막연한 규칙(예: "/ad")은 멀쩡한 주소를 막을 수 있어 버린다
            if (!host && pattern.length < 6) return null
            if (pattern.any { it == ' ' || it == '\t' }) return null

            var types = 0
            var negTypes = 0
            var third = 0
            var important = false
            var din: ArrayList<String>? = null
            var dex: ArrayList<String>? = null
            if (opts != null) {
                for (o in opts.split(',')) {
                    if (o.isEmpty()) continue
                    val neg = o.startsWith("~")
                    val body = if (neg) o.substring(1) else o
                    val name = body.substringBefore('=').lowercase()
                    when (name) {
                        "third-party", "3p" -> third = if (neg) 2 else 1
                        "first-party", "1p" -> third = if (neg) 1 else 2
                        "important" -> important = true
                        "match-case" -> Unit
                        "script" -> if (neg) negTypes = negTypes or T_SCRIPT else types = types or T_SCRIPT
                        "image" -> if (neg) negTypes = negTypes or T_IMAGE else types = types or T_IMAGE
                        "stylesheet", "css" -> if (neg) negTypes = negTypes or T_CSS else types = types or T_CSS
                        "xmlhttprequest", "xhr" -> if (neg) negTypes = negTypes or T_XHR else types = types or T_XHR
                        "subdocument", "frame" -> if (neg) negTypes = negTypes or T_SUBDOC else types = types or T_SUBDOC
                        "media" -> if (neg) negTypes = negTypes or T_MEDIA else types = types or T_MEDIA
                        "font" -> if (neg) negTypes = negTypes or T_FONT else types = types or T_FONT
                        "ping" -> if (neg) negTypes = negTypes or T_PING else types = types or T_PING
                        "websocket" -> if (neg) negTypes = negTypes or T_WS else types = types or T_WS
                        "other" -> if (neg) negTypes = negTypes or T_OTHER else types = types or T_OTHER
                        "object", "object-subrequest" -> if (neg) negTypes = negTypes or T_OBJECT else types = types or T_OBJECT
                        "domain", "from" -> {
                            if (neg || !o.contains('=')) return null
                            for (dm in body.substringAfter('=').split('|')) {
                                val x = dm.trim().lowercase()
                                val ex = x.startsWith("~")
                                val name2 = if (ex) x.substring(1) else x
                                if (name2.isEmpty() || name2.contains('*') || name2.contains('/') || name2.contains(' ')) return null
                                if (ex) (dex ?: ArrayList<String>().also { dex = it }).add(name2)
                                else (din ?: ArrayList<String>().also { din = it }).add(name2)
                            }
                        }
                        // 그 밖의 옵션(redirect, removeparam, csp, popup, document, all, badfilter ...)은 지원하지 않는다
                        else -> return null
                    }
                }
            }
            if (types == 0 && negTypes != 0) types = T_ALL and negTypes.inv()
            else if (types != 0) types = types and negTypes.inv()
            if (types == 0 && negTypes != 0) return null

            val r = Rule(
                pattern, host, start, end, types, third,
                din?.toTypedArray(), dex?.toTypedArray(), important, exception
            )
            // 색인할 토큰이 없는 규칙은 요청마다 모두 검사하게 되므로, 충분히 구체적일 때만 둔다
            if (tokenOf(r) == null && pattern.length < 8) return null
            return r
        }
    }
}
