package com.example.evergreen

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.webkit.CookieManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.doOnLayout
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/** 만화 이미지 내려받기 + 화면에 맞게 줄여서 읽기 (쿠키·Referer 를 같이 보내 막힌 사이트도 열린다). */
object MangaLoader {
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val waiting = HashMap<String, MutableList<(Bitmap?) -> Unit>>()

    /** 원본 파일을 내려받아 두는 곳 (디코딩 전 바이트). 한 번 받은 이미지는 다시 받지 않는다. */
    private var diskDir: File? = null
    private val locks = ConcurrentHashMap<String, Any>()

    /** 이미지 원본의 세로/가로 비율. 줄여서 읽어도 원본 비율로 자리를 잡기 위해 따로 기억한다. */
    private val aspectMap = ConcurrentHashMap<String, Float>()

    /** 순서대로 미리 받아 두는 전용 스레드 (화면에 필요한 이미지 요청과 섞이지 않게 분리) */
    private val preloadPool = Executors.newSingleThreadExecutor()
    @Volatile private var preloadGen = 0

    fun init(dir: File) {
        dir.mkdirs()
        diskDir = dir
        // 너무 많이 쌓였으면 비운다
        val files = dir.listFiles() ?: return
        if (files.sumOf { it.length() } > 400L * 1024 * 1024) files.forEach { it.delete() }
    }

    fun aspect(url: String): Float? = aspectMap[url]

    /** 이미지 전체를 문서 순서대로 미리 받아 둔다. 화면을 넘길 때 바로 뜨고, 크기·비율도 미리 알아 둔다. */
    fun preloadAll(urls: List<String>, referer: String?, ua: String?) {
        val gen = ++preloadGen
        preloadPool.execute {
            for (u in urls) {
                if (gen != preloadGen) return@execute
                try {
                    val b = bytes(u, referer, ua) ?: continue
                    if (aspectMap[u] == null) {
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(b, 0, b.size, o)
                        if (o.outWidth > 0 && o.outHeight > 0) aspectMap[u] = o.outHeight.toFloat() / o.outWidth
                    }
                } catch (e: Throwable) {
                    // 못 받은 장은 화면에서 다시 시도한다
                }
            }
        }
    }

    fun cancelPreload() {
        preloadGen++
    }

    private fun keyOf(url: String): String =
        MessageDigest.getInstance("SHA-1").digest(url.toByteArray()).joinToString("") { "%02x".format(it) }

    /** 디스크에 있으면 거기서, 없으면 내려받아 저장하고 돌려준다. */
    private fun bytes(url: String, referer: String?, ua: String?): ByteArray? {
        if (url.startsWith("data:")) return decodeData(url)
        val dir = diskDir
        val lock = locks.getOrPut(url) { Any() }
        synchronized(lock) {
            val f = if (dir != null) File(dir, keyOf(url)) else null
            if (f != null && f.exists() && f.length() > 0) {
                try { return f.readBytes() } catch (e: Exception) { f.delete() }
            }
            val b = download(url, referer, ua) ?: return null
            if (f != null) {
                try {
                    val tmp = File(f.path + ".tmp")
                    tmp.writeBytes(b)
                    tmp.renameTo(f)
                } catch (e: Exception) {
                    // 저장 실패해도 화면에는 보여준다
                }
            }
            return b
        }
    }

    private val cache = object : LruCache<String, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun get(url: String): Bitmap? = cache.get(url)

    fun clear() {
        cache.evictAll()
    }

    /** 결과는 항상 메인 스레드로 돌려준다. 같은 주소를 동시에 요청하면 한 번만 받는다. */
    fun load(url: String, referer: String?, ua: String?, cb: (Bitmap?) -> Unit) {
        cache.get(url)?.let {
            cb(it)
            return
        }
        synchronized(waiting) {
            val list = waiting[url]
            if (list != null) {
                list.add(cb)
                return
            }
            waiting[url] = mutableListOf(cb)
        }
        pool.execute {
            val bmp = try {
                fetch(url, referer, ua)
            } catch (e: Throwable) {
                null
            }
            if (bmp != null) cache.put(url, bmp)
            val cbs = synchronized(waiting) { waiting.remove(url) } ?: mutableListOf()
            main.post { cbs.forEach { it(bmp) } }
        }
    }

    fun prefetch(url: String, referer: String?, ua: String?) {
        if (cache.get(url) == null) load(url, referer, ua) { }
    }

    private fun fetch(url: String, referer: String?, ua: String?): Bitmap? {
        val bytes = bytes(url, referer, ua) ?: return null
        // 메모리가 모자라 실패하면 캐시를 비우고 더 작게 줄여서 다시 시도한다 (앱이 꺼지는 것 방지)
        for (extra in 0..2) {
            try {
                return decode(url, bytes, extra)
            } catch (e: OutOfMemoryError) {
                cache.evictAll()
                System.gc()
            }
        }
        return null
    }

    private fun decodeData(url: String): ByteArray? {
        val i = url.indexOf(',')
        if (i < 0) return null
        val head = url.substring(0, i)
        val body = url.substring(i + 1)
        return if (head.contains(";base64")) Base64.decode(body, Base64.DEFAULT) else Uri.decode(body).toByteArray()
    }

    private fun download(url: String, referer: String?, ua: String?): ByteArray? {
        var target = url
        for (hop in 0..5) {
            val conn = URL(target).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 15000
                conn.readTimeout = 25000
                conn.instanceFollowRedirects = false
                if (ua != null) conn.setRequestProperty("User-Agent", ua)
                if (referer != null) conn.setRequestProperty("Referer", referer)
                CookieManager.getInstance().getCookie(target)?.let { conn.setRequestProperty("Cookie", it) }
                conn.setRequestProperty("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location") ?: return null
                    target = URL(URL(target), loc).toString()
                    continue
                }
                if (code !in 200..299) return null
                val out = ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                conn.inputStream.use { input ->
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        if (out.size() > 30 * 1024 * 1024) return null
                    }
                }
                return out.toByteArray()
            } finally {
                conn.disconnect()
            }
        }
        return null
    }

    /**
     * 가능한 한 원본 크기 그대로 읽는다. 기기가 한 번에 그릴 수 있는 한계(한 변 8192px)나 메모리(1600만 화소)를
     * 넘는 경우에만 정수 배로 줄이고, 어느 경우든 원본의 가로세로 비율은 따로 기억해 둔다.
     */
    private fun decode(url: String, b: ByteArray, extraShift: Int = 0): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        val w = o.outWidth
        val h = o.outHeight
        aspectMap[url] = h.toFloat() / w
        var s = 1
        while (max(w, h) / s > 8192 || (w.toLong() / s) * (h.toLong() / s) > 16_000_000L) s *= 2
        repeat(extraShift) { s *= 2 }
        val d = BitmapFactory.Options().apply {
            inSampleSize = s
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeByteArray(b, 0, b.size, d)
    }
}

/**
 * 만화 모드 화면: 페이지의 이미지를 한 장씩 넘겨 보는 전체 화면 뷰어.
 * 화면 가운데를 누르면 메뉴가 보이고/숨고, 양쪽 가장자리를 누르거나 밀면 다음/이전 장으로 넘어간다.
 */
class MangaViewer(
    private val activity: AppCompatActivity,
    private val host: FrameLayout,
    private val prefs: Prefs,
    /** 만화 화면 뒤에 깔리는 브라우저 화면 (열릴 때 살짝 뒤로 물러나 깊이감을 준다) */
    private val backdrop: View,
    private val setImmersive: (Boolean) -> Unit,
    private val onClosed: () -> Unit,
    private val onRescan: () -> Unit
) {
    var isOpen = false
        private set

    private val ctx: Context = activity
    private var urls: List<String> = emptyList()
    private var referer: String? = null
    private var ua: String? = null

    private var built = false
    private lateinit var pager: ViewPager2
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var titleView: TextView
    private lateinit var dirChip: TextView
    private lateinit var modeChip: TextView
    private lateinit var widthChip: TextView
    private val isTablet get() = ctx.resources.configuration.smallestScreenWidthDp >= 600
    private lateinit var strip: RecyclerView
    private val stripAdapter = StripAdapter()
    private val aspects = HashMap<String, Float>()
    private var webtoon = false
    private lateinit var counter: TextView
    private lateinit var seek: SeekBar
    private var barsShown = true
    private var seeking = false
    private val adapter = PageAdapter()
    private var originX = 0f
    private var originY = 0f
    private var flipping = false

    private val revealEase = PathInterpolator(0.2f, 0f, 0f, 1f)
    private val flipEase = PathInterpolator(0.22f, 1f, 0.36f, 1f)

    private fun dp(n: Int): Int = (n * ctx.resources.displayMetrics.density).toInt()

    private fun iconButton(res: Int, desc: String): ImageButton = ImageButton(ctx).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(Color.WHITE)
        contentDescription = desc
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        setBackgroundResource(tv.resourceId)
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
    }

    private fun build() {
        if (built) return
        built = true
        host.setBackgroundColor(Color.BLACK)

        pager = ViewPager2(ctx).apply {
            offscreenPageLimit = 1
            adapter = this@MangaViewer.adapter
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    onPage(position)
                }
            })
        }
        pager.setPageTransformer(stackTransformer)
        host.addView(pager, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // 웹툰 모드: 이미지를 세로로 이어 붙여 끊김 없이 스크롤
        strip = RecyclerView(ctx).apply {
            layoutManager = LinearLayoutManager(ctx)
            adapter = stripAdapter
            itemAnimator = null
            overScrollMode = View.OVER_SCROLL_NEVER
            visibility = View.GONE
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                    if (!webtoon || seeking) return
                    val first = (rv.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                    if (first >= 0) onPage(first)
                }
            })
        }
        host.addView(strip, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // 화면 크기가 바뀌면(회전, 분할 화면) 웹툰 너비를 다시 맞춘다.
        host.addOnLayoutChangeListener { _, l, _, r, _, ol, _, or2, _ ->
            if (r - l != or2 - ol && webtoon) applyStripWidth()
        }

        // 위쪽 바: 닫기 / 제목 / 읽는 방향 / 다시 찾기
        val closeBtn = iconButton(R.drawable.ic_close, "만화 모드 끄기")
        closeBtn.setOnClickListener { this@MangaViewer.close() }
        titleView = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(4)
                marginEnd = dp(8)
            }
        }
        dirChip = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(0x33FFFFFF)
            }
            setOnClickListener { setRtl(!prefs.mangaRtl) }
        }
        modeChip = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(0x33FFFFFF)
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(6)
            }
            setOnClickListener { setWebtoon(!webtoon) }
        }
        widthChip = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(0x33FFFFFF)
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(6)
            }
            setOnClickListener {
                prefs.webtoonWidth = (prefs.webtoonWidth + 1) % 3
                applyStripWidth()
            }
        }
        val rescan = iconButton(R.drawable.ic_refresh, "이미지 다시 찾기")
        rescan.setOnClickListener { onRescan() }
        topBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(8), dp(8), dp(26))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
            addView(closeBtn)
            addView(titleView)
            addView(modeChip)
            addView(widthChip)
            addView(dirChip)
            addView(rescan)
        }
        host.addView(
            topBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )

        // 아래쪽 바: 쪽수 / 이동 막대
        counter = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            minWidth = dp(64)
            gravity = Gravity.CENTER
        }
        seek = SeekBar(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        counter.text = "${progress + 1} / ${urls.size}"
                        if (webtoon) (strip.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(progress, 0)
                        else pager.setCurrentItem(progress, false)
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {
                    seeking = true
                }

                override fun onStopTrackingTouch(sb: SeekBar) {
                    seeking = false
                }
            })
        }
        bottomBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(26), dp(18), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xCC000000.toInt(), 0x00000000))
            addView(counter)
            addView(seek)
        }
        host.addView(
            bottomBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
    }

    /**
     * 만화 모드를 연다. (originX, originY) 는 화면에서 원이 퍼져 나가기 시작하는 지점(보통 메뉴 버튼).
     */
    fun open(pages: List<String>, title: String?, referer: String?, ua: String?, originX: Float, originY: Float, webtoon: Boolean = false) {
        build()
        this.urls = pages
        this.referer = referer
        this.ua = ua
        this.originX = originX
        this.originY = originY
        titleView.text = title?.takeIf { it.isNotBlank() } ?: "만화 모드"
        aspects.clear()
        MangaLoader.init(File(ctx.cacheDir, "manga"))
        MangaLoader.preloadAll(pages, referer, ua)
        this.webtoon = webtoon
        applyDirection()
        adapter.notifyDataSetChanged()
        stripAdapter.notifyDataSetChanged()
        pager.setCurrentItem(0, false)
        strip.scrollToPosition(0)
        applyMode()
        seek.max = max(0, pages.size - 1)
        onPage(0)

        isOpen = true
        setImmersive(true)
        resetTransforms()
        showBars(true, animate = false)
        host.visibility = View.VISIBLE
        if (Motion.enabled(ctx)) playOpen()
    }

    /** 메뉴 버튼 자리에서 검은 원이 번지며 화면을 덮고, 그 위로 첫 장이 떠오른다. */
    private fun playOpen() {
        pager.alpha = 0f
        pager.scaleX = 0.86f
        pager.scaleY = 0.86f
        pager.translationY = dp(36).toFloat()
        topBar.translationY = -dp(48).toFloat()
        bottomBar.translationY = dp(48).toFloat()
        topBar.alpha = 0f
        bottomBar.alpha = 0f

        // 뒤의 브라우저는 살짝 작아지며 물러난다
        Motion.spring(backdrop, DynamicAnimation.SCALE_X, 0.92f, 180f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(backdrop, DynamicAnimation.SCALE_Y, 0.92f, 180f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(backdrop, DynamicAnimation.ALPHA, 0.6f, 180f, SpringForce.DAMPING_RATIO_NO_BOUNCY)

        host.doOnLayout {
            try {
                val cx = originX.toInt().coerceIn(0, host.width)
                val cy = originY.toInt().coerceIn(0, host.height)
                val r = hypot(host.width.toFloat(), host.height.toFloat())
                ViewAnimationUtils.createCircularReveal(host, cx, cy, 0f, r).apply {
                    duration = 520
                    interpolator = revealEase
                    start()
                }
            } catch (e: Exception) {
                // 원형 효과를 못 쓰는 경우엔 그냥 나타난다.
            }
        }

        host.postDelayed({
            if (!isOpen) return@postDelayed
            Motion.spring(pager, DynamicAnimation.ALPHA, 1f, 220f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            Motion.spring(pager, DynamicAnimation.SCALE_X, 1f, 200f, 0.72f)
            Motion.spring(pager, DynamicAnimation.SCALE_Y, 1f, 200f, 0.72f)
            Motion.spring(pager, DynamicAnimation.TRANSLATION_Y, 0f, 190f, 0.78f)
        }, 110)
        host.postDelayed({
            if (!isOpen) return@postDelayed
            for (bar in listOf(topBar, bottomBar)) {
                Motion.spring(bar, DynamicAnimation.ALPHA, 1f, 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                Motion.spring(bar, DynamicAnimation.TRANSLATION_Y, 0f, 260f, 0.8f)
            }
        }, 260)
    }

    /** 이미지를 다시 찾은 결과로 목록을 바꾼다 (보던 쪽은 최대한 유지). */
    fun update(pages: List<String>) {
        if (!isOpen || pages.isEmpty()) return
        val at = pager.currentItem
        val added = pages.size - urls.size
        urls = pages
        MangaLoader.preloadAll(pages, referer, ua)
        adapter.notifyDataSetChanged()
        stripAdapter.notifyDataSetChanged()
        seek.max = max(0, pages.size - 1)
        val keep = at.coerceIn(0, pages.size - 1)
        pager.setCurrentItem(keep, false)
        onPage(keep)
        Toast.makeText(
            ctx,
            if (added > 0) "이미지 ${added}장을 더 찾았어요" else "새로 찾은 이미지가 없어요",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun close() {
        if (!isOpen) return
        isOpen = false
        MangaLoader.cancelPreload()
        setImmersive(false)
        if (!Motion.enabled(ctx)) {
            finishClose()
            return
        }
        // 위로 올라온 화면이 작아지며 물러나고, 원이 처음 눌렀던 자리로 오므라든다.
        Motion.spring(pager, DynamicAnimation.SCALE_X, 0.9f, 320f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(pager, DynamicAnimation.SCALE_Y, 0.9f, 320f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(pager, DynamicAnimation.ALPHA, 0.2f, 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(topBar, DynamicAnimation.TRANSLATION_Y, -dp(48).toFloat(), 420f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(bottomBar, DynamicAnimation.TRANSLATION_Y, dp(48).toFloat(), 420f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(topBar, DynamicAnimation.ALPHA, 0f, 500f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(bottomBar, DynamicAnimation.ALPHA, 0f, 500f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(backdrop, DynamicAnimation.SCALE_X, 1f, 260f, 0.7f)
        Motion.spring(backdrop, DynamicAnimation.SCALE_Y, 1f, 260f, 0.7f)
        Motion.spring(backdrop, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)

        try {
            val cx = originX.toInt().coerceIn(0, max(1, host.width))
            val cy = originY.toInt().coerceIn(0, max(1, host.height))
            val r = hypot(host.width.toFloat(), host.height.toFloat())
            ViewAnimationUtils.createCircularReveal(host, cx, cy, r, 0f).apply {
                duration = 440
                startDelay = 60
                interpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        finishClose()
                    }
                })
                start()
            }
        } catch (e: Exception) {
            finishClose()
        }
    }

    private fun resetTransforms() {
        for (v in listOf<View>(pager, topBar, bottomBar, backdrop)) Motion.cancel(v)
        pager.alpha = 1f
        pager.scaleX = 1f
        pager.scaleY = 1f
        pager.translationY = 0f
        topBar.alpha = 1f
        bottomBar.alpha = 1f
        topBar.translationY = 0f
        bottomBar.translationY = 0f
        backdrop.scaleX = 1f
        backdrop.scaleY = 1f
        backdrop.alpha = 1f
    }

    private fun finishClose() {
        host.visibility = View.GONE
        resetTransforms()
        urls = emptyList()
        adapter.notifyDataSetChanged()
        stripAdapter.notifyDataSetChanged()
        MangaLoader.clear()
        onClosed()
    }

    /** 페이지 넘김 ↔ 웹툰(세로 이어 보기) 전환. 보던 위치는 유지한다. */
    private fun setWebtoon(on: Boolean) {
        if (on == webtoon) return
        val at = if (webtoon) (strip.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition().coerceAtLeast(0)
        else pager.currentItem
        webtoon = on
        applyMode()
        if (on) (strip.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(at, 0)
        else pager.setCurrentItem(at, false)
        onPage(at)
    }

    /** 태블릿에서는 웹툰을 화면 가운데의 읽기 좋은 너비로 모아 보여준다 (양옆은 검은 여백). */
    private fun applyStripWidth() {
        val mode = prefs.webtoonWidth
        widthChip.text = when (mode) {
            0 -> "너비 보통"
            1 -> "너비 넓게"
            else -> "너비 전체"
        }
        val screenW = if (host.width > 0) host.width else ctx.resources.displayMetrics.widthPixels
        val maxW = when (mode) {
            0 -> dp(720)
            1 -> dp(960)
            else -> Int.MAX_VALUE
        }
        val w = if (isTablet && maxW < screenW) maxW else ViewGroup.LayoutParams.MATCH_PARENT
        val lp = strip.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.gravity != Gravity.CENTER_HORIZONTAL) {
            lp.width = w
            lp.gravity = Gravity.CENTER_HORIZONTAL
            strip.layoutParams = lp
        }
        // 너비가 바뀌면 이미지 높이도 달라지므로 보던 위치를 유지한 채 다시 그린다.
        val lm = strip.layoutManager as LinearLayoutManager
        val at = lm.findFirstVisibleItemPosition().coerceAtLeast(0)
        strip.post {
            stripAdapter.notifyDataSetChanged()
            lm.scrollToPositionWithOffset(at, 0)
        }
    }

    private fun applyMode() {
        pager.visibility = if (webtoon) View.GONE else View.VISIBLE
        strip.visibility = if (webtoon) View.VISIBLE else View.GONE
        dirChip.visibility = if (webtoon) View.GONE else View.VISIBLE
        modeChip.text = if (webtoon) "웹툰 ↕" else "페이지 ↔"
        widthChip.visibility = if (webtoon && isTablet) View.VISIBLE else View.GONE
        if (webtoon) applyStripWidth()
        seek.layoutDirection = if (!webtoon && prefs.mangaRtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    private fun setRtl(rtl: Boolean) {
        prefs.mangaRtl = rtl
        val at = pager.currentItem
        applyDirection()
        adapter.notifyDataSetChanged()
        pager.setCurrentItem(at, false)
    }

    private fun applyDirection() {
        val rtl = prefs.mangaRtl
        val dir = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        pager.layoutDirection = dir
        seek.layoutDirection = if (webtoon) View.LAYOUT_DIRECTION_LTR else dir
        dirChip.text = if (rtl) "읽는 방향 ←" else "읽는 방향 →"
    }

    private fun onPage(position: Int) {
        if (urls.isEmpty()) {
            counter.text = "0 / 0"
            return
        }
        val label = "${position + 1} / ${urls.size}"
        if (counter.text.toString() != label) {
            counter.text = label
            if (isOpen && !seeking) Motion.pop(counter, 0.82f)
        }
        if (!seeking) seek.progress = position
        // 앞뒤 장을 미리 받아 둔다
        urls.getOrNull(position + 1)?.let { MangaLoader.prefetch(it, referer, ua) }
        urls.getOrNull(position - 1)?.let { MangaLoader.prefetch(it, referer, ua) }
    }

    private fun showBars(show: Boolean, animate: Boolean = true) {
        barsShown = show
        val a = if (show) 1f else 0f
        val shift = dp(20).toFloat()
        if (show) {
            topBar.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE
        }
        if (!animate || !Motion.enabled(ctx)) {
            topBar.alpha = a
            bottomBar.alpha = a
            topBar.translationY = if (show) 0f else -shift
            bottomBar.translationY = if (show) 0f else shift
            if (!show) {
                topBar.visibility = View.INVISIBLE
                bottomBar.visibility = View.INVISIBLE
            }
            return
        }
        // 숨긴 뒤에는 보이지 않는 버튼이 터치를 가로채지 않도록 INVISIBLE 로 바꾼다.
        Motion.spring(topBar, DynamicAnimation.ALPHA, a, 420f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
            if (!barsShown) topBar.visibility = View.INVISIBLE
        }
        Motion.spring(bottomBar, DynamicAnimation.ALPHA, a, 420f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
            if (!barsShown) bottomBar.visibility = View.INVISIBLE
        }
        Motion.spring(topBar, DynamicAnimation.TRANSLATION_Y, if (show) 0f else -shift, 360f, 0.82f)
        Motion.spring(bottomBar, DynamicAnimation.TRANSLATION_Y, if (show) 0f else shift, 360f, 0.82f)
    }

    /**
     * 탭으로 넘길 때: 이웃 페이지의 실제 위치까지의 거리를 재서, 부드럽게 멈추는 곡선으로 직접 굴린다.
     * (읽는 방향이 바뀌어도 실제 위치로 계산하므로 방향이 맞다.)
     */
    private fun flip(delta: Int) {
        val to = pager.currentItem + delta
        if (to < 0 || to >= urls.size) {
            Toast.makeText(ctx, if (to < 0) "첫 페이지예요" else "마지막 페이지예요", Toast.LENGTH_SHORT).show()
            return
        }
        if (flipping) return
        val rv = pager.getChildAt(0) as? RecyclerView
        val cur = rv?.findViewHolderForAdapterPosition(pager.currentItem)?.itemView
        val tgt = rv?.findViewHolderForAdapterPosition(to)?.itemView
        if (rv == null || cur == null || tgt == null || !Motion.enabled(ctx)) {
            pager.setCurrentItem(to, true)
            return
        }
        val dx = tgt.left - cur.left
        if (dx == 0) {
            pager.setCurrentItem(to, true)
            return
        }
        flipping = true
        val dur = 420
        rv.smoothScrollBy(dx, 0, flipEase, dur)
        host.postDelayed({
            flipping = false
            // 혹시 도착 위치가 어긋났다면 바로잡는다.
            if (isOpen && pager.currentItem != to) pager.setCurrentItem(to, false)
        }, dur + 90L)
    }

    private fun handleTap(fx: Float) {
        val rtl = prefs.mangaRtl
        when {
            fx < 0.28f -> flip(if (rtl) 1 else -1)
            fx > 0.72f -> flip(if (rtl) -1 else 1)
            else -> showBars(!barsShown)
        }
    }

    /**
     * 종이를 넘기는 효과: 넘어가는 페이지는 그 자리에 붙은 채 자유로운 끝부터 둥글게 말려 올라가며
     * 뒷면(희미하게 비치는 종이)이 보이고, 말린 가장자리가 아래의 다음 장에 그림자를 드리운다.
     * 앞으로 넘길 때는 현재 장이 말려 넘어가고, 뒤로 돌아올 때는 이전 장이 거꾸로 펴지며 덮인다.
     * 책등은 읽는 방향에 따라 왼쪽/오른쪽으로 바뀐다.
     */
    private val stackTransformer = ViewPager2.PageTransformer { page, position ->
        val w = page.width.toFloat()
        val h = page.height.toFloat()
        val s = if (prefs.mangaRtl) -1f else 1f
        val img = (page as? ViewGroup)?.getChildAt(0) as? ZoomImageView
        page.rotation = 0f
        when {
            abs(position) >= 1f -> {
                page.alpha = 1f
                page.scaleX = 1f
                page.scaleY = 1f
                page.translationX = 0f
                page.translationZ = 0f
                img?.curl = 0f
            }
            position <= 0f -> {
                // 말려 넘어가는 종이: 움직이는 대신 제자리에서 말린다
                page.translationX = -s * position * w
                page.translationZ = 2f
                page.alpha = 1f
                page.scaleX = 1f
                page.scaleY = 1f
                img?.spineOnLeft = s > 0f
                img?.curl = -position
            }
            else -> {
                // 아래 깔려 있다가 드러나는 장: 제자리에서 살짝 커지며 또렷해진다
                page.pivotX = w / 2f
                page.pivotY = h / 2f
                page.translationX = -s * position * w
                page.translationZ = 0f
                val k = 0.965f + 0.035f * (1f - position)
                page.scaleX = k
                page.scaleY = k
                page.alpha = 1f
                img?.curl = 0f
            }
        }
    }

    // ───────────────────────── 페이지 어댑터 ─────────────────────────

    private inner class PageVH(
        val root: FrameLayout,
        val img: ZoomImageView,
        val spin: ProgressBar,
        val err: TextView
    ) : RecyclerView.ViewHolder(root) {
        var url: String? = null
    }

    private inner class PageAdapter : RecyclerView.Adapter<PageVH>() {
        override fun getItemCount(): Int = urls.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val root = FrameLayout(ctx)
            root.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            val img = ZoomImageView(ctx)
            root.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val spin = ProgressBar(ctx).apply {
                isIndeterminate = true
                indeterminateTintList = ColorStateList.valueOf(Color.WHITE)
            }
            root.addView(spin, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
            val err = TextView(ctx).apply {
                setTextColor(0xFFCCCCCC.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                text = "이미지를 불러오지 못했어요\n눌러서 다시 시도"
                visibility = View.GONE
            }
            root.addView(err, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val vh = PageVH(root, img, spin, err)
            img.onTap = { fx -> handleTap(fx) }
            err.setOnClickListener {
                vh.url?.let { u -> bindPage(vh, u) }
            }
            return vh
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            bindPage(holder, urls[position])
        }

        override fun onViewRecycled(holder: PageVH) {
            holder.url = null
            holder.img.setPage(null)
        }
    }

    private inner class StripVH(val root: FrameLayout, val img: ImageView, val spin: ProgressBar) :
        RecyclerView.ViewHolder(root) {
        var url: String? = null
    }

    private inner class StripAdapter : RecyclerView.Adapter<StripVH>() {
        override fun getItemCount(): Int = urls.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StripVH {
            val root = FrameLayout(ctx)
            root.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(400))
            val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.FIT_XY }
            root.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val spin = ProgressBar(ctx).apply {
                isIndeterminate = true
                indeterminateTintList = ColorStateList.valueOf(Color.WHITE)
            }
            root.addView(spin, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
            root.setOnClickListener { showBars(!barsShown) }
            return StripVH(root, img, spin)
        }

        override fun onBindViewHolder(holder: StripVH, position: Int) {
            val u = urls[position]
            holder.url = u
            val w = (strip.width.takeIf { it > 0 } ?: ctx.resources.displayMetrics.widthPixels)
            fun sizeTo(aspect: Float) {
                val lp = holder.root.layoutParams
                lp.height = (w * aspect).toInt().coerceAtLeast(dp(40))
                holder.root.layoutParams = lp
            }
            // 높이를 알면 처음부터 정확히 잡아 두어, 이미지가 늦게 와도 화면이 튀지 않는다.
            sizeTo(MangaLoader.aspect(u) ?: aspects[u] ?: 1.4f)
            val cached = MangaLoader.get(u)
            if (cached != null) {
                aspects[u] = MangaLoader.aspect(u) ?: (cached.height.toFloat() / cached.width)
                sizeTo(aspects[u]!!)
                holder.spin.visibility = View.GONE
                holder.img.setImageBitmap(cached)
                return
            }
            holder.img.setImageDrawable(null)
            holder.spin.visibility = View.VISIBLE
            MangaLoader.load(u, referer, ua) { bmp ->
                if (holder.url == u) {
                    holder.spin.visibility = View.GONE
                    if (bmp != null) {
                        aspects[u] = MangaLoader.aspect(u) ?: (bmp.height.toFloat() / bmp.width)
                        sizeTo(aspects[u]!!)
                        holder.img.setImageBitmap(bmp)
                    }
                }
            }
            // 아래쪽 몇 장을 미리 받아 둔다
            for (d in 1..2) urls.getOrNull(position + d)?.let { MangaLoader.prefetch(it, referer, ua) }
        }

        override fun onViewRecycled(holder: StripVH) {
            holder.url = null
            holder.img.setImageDrawable(null)
        }
    }

    /** 늦게 도착한 이미지가 투명하게 시작해 살짝 커지며 또렷해진다. */
    private fun fadeIn(v: View) {
        if (!Motion.enabled(ctx)) return
        Motion.cancel(v)
        v.alpha = 0f
        v.scaleX = 0.96f
        v.scaleY = 0.96f
        Motion.spring(v, DynamicAnimation.ALPHA, 1f, 240f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(v, DynamicAnimation.SCALE_X, 1f, 220f, 0.8f)
        Motion.spring(v, DynamicAnimation.SCALE_Y, 1f, 220f, 0.8f)
    }

    private fun bindPage(h: PageVH, u: String) {
        h.url = u
        Motion.cancel(h.img)
        h.img.alpha = 1f
        h.img.scaleX = 1f
        h.img.scaleY = 1f
        h.err.visibility = View.GONE
        val cached = MangaLoader.get(u)
        if (cached != null) {
            h.spin.visibility = View.GONE
            h.img.setPage(cached)
            return
        }
        h.img.setPage(null)
        h.spin.visibility = View.VISIBLE
        MangaLoader.load(u, referer, ua) { bmp ->
            if (h.url == u) {
                h.spin.visibility = View.GONE
                if (bmp != null) {
                    h.img.setPage(bmp)
                    fadeIn(h.img)
                } else {
                    h.err.visibility = View.VISIBLE
                }
            }
        }
    }
}
