package com.example.evergreen

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SearchEngine(
    val key: String,
    val name: String,
    val searchUrl: String,
    val homeUrl: String
)

object SearchEngines {
    val all = listOf(
        SearchEngine("google", "Google", "https://www.google.com/search?q=", "https://www.google.com"),
        SearchEngine("naver", "네이버", "https://search.naver.com/search.naver?query=", "https://m.naver.com"),
        SearchEngine("ddg", "DuckDuckGo", "https://duckduckgo.com/?q=", "https://duckduckgo.com"),
        SearchEngine("bing", "Bing", "https://www.bing.com/search?q=", "https://www.bing.com")
    )

    fun byKey(key: String): SearchEngine = all.firstOrNull { it.key == key } ?: all[0]

    /** 빠른 검색 단축어: 주소창에 "yt 노래", "n 날씨" 처럼 입력 */
    val shortcuts: Map<String, String> = mapOf(
        "g" to "https://www.google.com/search?q=",
        "n" to "https://search.naver.com/search.naver?query=",
        "d" to "https://duckduckgo.com/?q=",
        "b" to "https://www.bing.com/search?q=",
        "yt" to "https://m.youtube.com/results?search_query=",
        "w" to "https://ko.wikipedia.org/w/index.php?search=",
        "map" to "https://www.google.com/maps/search/"
    )
}

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("browser", Context.MODE_PRIVATE)

    var adBlock: Boolean
        get() = sp.getBoolean("adblock", true)
        set(v) = sp.edit().putBoolean("adblock", v).apply()

    /** 1. 트래커 차단(엄격): 사이트 동작에 필요한 것만 허용 */
    var strictTrackers: Boolean
        get() = sp.getBoolean("strict_trackers", false)
        set(v) = sp.edit().putBoolean("strict_trackers", v).apply()

    /** 2. 인증 과정 데이터로 추적하지 못하도록 캡차 건너뛰기(자동 인증) 우선 */
    var skipCaptchaTracking: Boolean
        get() = sp.getBoolean("skip_captcha_tracking", false)
        set(v) = sp.edit().putBoolean("skip_captcha_tracking", v).apply()

    /** 3. 악성 사이트 접속 시 알림 (Safe Browsing) */
    var malwareWarning: Boolean
        get() = sp.getBoolean("malware_warning", true)
        set(v) = sp.edit().putBoolean("malware_warning", v).apply()

    /** 4. 사용자 동작 없는 자동 다운로드 차단 */
    var blockAutoDownload: Boolean
        get() = sp.getBoolean("block_auto_download", true)
        set(v) = sp.edit().putBoolean("block_auto_download", v).apply()

    /** 스크롤할 때 주소창·하단 메뉴바를 자동으로 숨김 */
    var hideBarsOnScroll: Boolean
        get() = sp.getBoolean("hide_bars_on_scroll", true)
        set(v) = sp.edit().putBoolean("hide_bars_on_scroll", v).apply()

    /** 만화 모드: true 면 오른쪽에서 왼쪽으로 넘김 (일본 만화 방식) */
    var mangaRtl: Boolean
        get() = sp.getBoolean("manga_rtl", false)
        set(v) = sp.edit().putBoolean("manga_rtl", v).apply()

    /** Gemini API 키 (기기 보안 저장소 키로 암호화해서 보관) */
    var geminiKey: String
        get() = sp.getString("gemini_key", null)?.let { KeyVault.decrypt(it) } ?: ""
        set(v) {
            if (v.isBlank()) sp.edit().remove("gemini_key").apply()
            else sp.edit().putString("gemini_key", KeyVault.encrypt(v.trim())).apply()
        }

    var geminiModel: String
        get() = GeminiModels.byId(sp.getString("gemini_model", "") ?: "").id
        set(v) = sp.edit().putString("gemini_model", v).apply()

    /** AI 에게 질문할 때 지금 보는 페이지 내용을 함께 보낼지 */
    var assistantUsePage: Boolean
        get() = sp.getBoolean("assistant_use_page", true)
        set(v) = sp.edit().putBoolean("assistant_use_page", v).apply()

    /** 태블릿 웹툰 보기 너비: 0 = 보통(720dp), 1 = 넓게(960dp), 2 = 화면 전체 */
    var webtoonWidth: Int
        get() = sp.getInt("webtoon_width", 0)
        set(v) = sp.edit().putInt("webtoon_width", v).apply()

    var engineKey: String
        get() = sp.getString("engine", "google") ?: "google"
        set(v) = sp.edit().putString("engine", v).apply()

    /** 광고 차단 목록을 마지막으로 자동 업데이트 시도한 시각 (ms) */
    var adblockLastTry: Long
        get() = sp.getLong("adblock_try", 0L)
        set(v) = sp.edit().putLong("adblock_try", v).apply()

    @Synchronized
    fun history(): List<Pair<String, String>> {
        val raw = sp.getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                o.getString("u") to o.optString("t")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun addHistory(url: String, title: String?) {
        val list = history().filter { it.first != url }.toMutableList()
        list.add(0, url to (title ?: ""))
        val times = historyItems().associate { it.url to it.time }
        val now = System.currentTimeMillis()
        val arr = JSONArray()
        list.take(300).forEachIndexed { i, e ->
            val t = if (i == 0) now else times[e.first] ?: 0L
            arr.put(JSONObject().put("u", e.first).put("t", e.second).put("d", t))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    /** 방문 시각이 들어 있는 기록 목록 (최근 방문이 앞). 시각이 없던 옛 기록은 time = 0 */
    @Synchronized
    fun historyItems(): List<HistoryItem> {
        val raw = sp.getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                HistoryItem(o.getString("u"), o.optString("t"), o.optLong("d", 0L))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun removeHistory(url: String) {
        val arr = JSONArray()
        historyItems().filter { it.url != url }.forEach {
            arr.put(JSONObject().put("u", it.url).put("t", it.title).put("d", it.time))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    @Synchronized
    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    // ───────────────────────── 폴더 (kind: KIND_BM = 북마크, KIND_DL = 다운로드) ─────────────────────────

    @Synchronized
    fun folders(kind: String): List<Folder> {
        val raw = sp.getString("folders_$kind", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Folder(o.getLong("i"), o.getString("n"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveFolders(kind: String, list: List<Folder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("i", it.id).put("n", it.name)) }
        sp.edit().putString("folders_$kind", arr.toString()).apply()
    }

    private fun newId(used: Collection<Long>): Long =
        maxOf(System.currentTimeMillis(), (used.maxOrNull() ?: 0L) + 1L)

    @Synchronized
    fun addFolder(kind: String, name: String): Folder {
        val list = folders(kind)
        val f = Folder(newId(list.map { it.id }), name)
        saveFolders(kind, list + f)
        return f
    }

    @Synchronized
    fun renameFolder(kind: String, id: Long, name: String) {
        saveFolders(kind, folders(kind).map { if (it.id == id) Folder(id, name) else it })
    }

    /** 폴더만 지운다. 안에 있던 북마크/다운로드 파일은 지워지지 않고 '폴더 없음' 상태가 된다. */
    @Synchronized
    fun removeFolder(kind: String, id: Long) {
        saveFolders(kind, folders(kind).filter { it.id != id })
        if (kind == KIND_BM) {
            saveBookmarks(bookmarks().map { if (it.folderId == id) it.copy(folderId = 0L) else it })
        } else {
            val map = downloadFolderMap().filterValues { it != id }
            saveDownloadFolderMap(map)
        }
    }

    // ───────────────────────── 북마크 ─────────────────────────

    /** 새 북마크를 만들 때 기본으로 선택할 폴더 (마지막으로 쓴 폴더) */
    var lastBookmarkFolder: Long
        get() = sp.getLong("bm_last_folder", 0L)
        set(v) = sp.edit().putLong("bm_last_folder", v).apply()

    /** 최근에 추가한 것이 앞에 온다. */
    @Synchronized
    fun bookmarks(): List<Bookmark> {
        val raw = sp.getString("bookmarks", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Bookmark(o.getLong("i"), o.getString("u"), o.optString("t"), o.optLong("f", 0L))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveBookmarks(list: List<Bookmark>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("i", it.id).put("u", it.url).put("t", it.title).put("f", it.folderId))
        }
        sp.edit().putString("bookmarks", arr.toString()).apply()
    }

    private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

    @Synchronized
    fun findBookmark(url: String): Bookmark? = bookmarks().firstOrNull { sameUrl(it.url, url) }

    /** id 가 같은 북마크가 있으면 고치고, 없으면 맨 앞에 추가한다. */
    @Synchronized
    fun saveBookmark(url: String, title: String, folderId: Long, existingId: Long? = null): Bookmark {
        val list = bookmarks()
        val id = existingId ?: newId(list.map { it.id })
        val b = Bookmark(id, url, title, folderId)
        // 같은 주소가 이미 다른 항목으로 있으면 하나로 합친다.
        val out = if (existingId != null && list.any { it.id == existingId }) {
            list.filter { it.id == id || !sameUrl(it.url, url) }.map { if (it.id == id) b else it }
        } else {
            listOf(b) + list.filter { !sameUrl(it.url, url) }
        }
        saveBookmarks(out)
        return b
    }

    @Synchronized
    fun moveBookmark(id: Long, folderId: Long) {
        saveBookmarks(bookmarks().map { if (it.id == id) it.copy(folderId = folderId) else it })
    }

    @Synchronized
    fun removeBookmark(id: Long) {
        saveBookmarks(bookmarks().filter { it.id != id })
    }

    // ───────────────────────── 다운로드 파일 → 폴더 ─────────────────────────

    /** 다운로드 항목 키("m:123" 등) → 폴더 id. 폴더가 없는 항목은 들어 있지 않다. */
    @Synchronized
    fun downloadFolderMap(): Map<String, Long> {
        val raw = sp.getString("dl_folder_map", null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            val m = HashMap<String, Long>()
            o.keys().forEach { k -> m[k] = o.getLong(k) }
            m
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun saveDownloadFolderMap(map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        sp.edit().putString("dl_folder_map", o.toString()).apply()
    }

    /** folderId 가 0 이면 폴더에서 뺀다. */
    @Synchronized
    fun setDownloadFolder(key: String, folderId: Long) {
        val m = downloadFolderMap().toMutableMap()
        if (folderId == 0L) m.remove(key) else m[key] = folderId
        saveDownloadFolderMap(m)
    }

    companion object {
        const val KIND_BM = "bm"
        const val KIND_DL = "dl"
    }
}

data class HistoryItem(val url: String, val title: String, val time: Long)

data class Folder(val id: Long, val name: String)

data class Bookmark(val id: Long, val url: String, val title: String, val folderId: Long)
