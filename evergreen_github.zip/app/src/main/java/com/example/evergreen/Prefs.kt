package com.example.evergreen

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SearchEngine(
    val key: String,
    val name: String,
    val searchUrl: String,
    val homeUrl: String
)

object SearchEngines {
    val all = listOf(
        SearchEngine("google", "Google", "https://www.google.com/search?q=", "https://www.google.com"),
        SearchEngine("naver", "네이버", "https://search.naver.com/search.naver?query=", "https://m.naver.com"),
        SearchEngine("ddg", "DuckDuckGo", "https://duckduckgo.com/?q=", "https://duckduckgo.com"),
        SearchEngine("bing", "Bing", "https://www.bing.com/search?q=", "https://www.bing.com")
    )

    fun byKey(key: String): SearchEngine = all.firstOrNull { it.key == key } ?: all[0]

    /** 빠른 검색 단축어: 주소창에 "yt 노래", "n 날씨" 처럼 입력 */
    val shortcuts: Map<String, String> = mapOf(
        "g" to "https://www.google.com/search?q=",
        "n" to "https://search.naver.com/search.naver?query=",
        "d" to "https://duckduckgo.com/?q=",
        "b" to "https://www.bing.com/search?q=",
        "yt" to "https://m.youtube.com/results?search_query=",
        "w" to "https://ko.wikipedia.org/w/index.php?search=",
        "map" to "https://www.google.com/maps/search/"
    )
}

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("browser", Context.MODE_PRIVATE)

    var adBlock: Boolean
        get() = sp.getBoolean("adblock", true)
        set(v) = sp.edit().putBoolean("adblock", v).apply()

    var engineKey: String
        get() = sp.getString("engine", "google") ?: "google"
        set(v) = sp.edit().putString("engine", v).apply()

    /** 광고 차단 목록을 마지막으로 자동 업데이트 시도한 시각 (ms) */
    var adblockLastTry: Long
        get() = sp.getLong("adblock_try", 0L)
        set(v) = sp.edit().putLong("adblock_try", v).apply()

    @Synchronized
    fun history(): List<Pair<String, String>> {
        val raw = sp.getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                o.getString("u") to o.optString("t")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun addHistory(url: String, title: String?) {
        val list = history().filter { it.first != url }.toMutableList()
        list.add(0, url to (title ?: ""))
        val arr = JSONArray()
        list.take(300).forEach { arr.put(JSONObject().put("u", it.first).put("t", it.second)) }
        sp.edit().putString("history", arr.toString()).apply()
    }

    @Synchronized
    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    companion object {
    }
}
