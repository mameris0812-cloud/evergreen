package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * 키 한도(Gemini 429 · 키 거부) 처리 테스트: [GeminiKeyPool] 의 한도 판별 · 쉬는 시간 · 키/모델 선택 · 키 바뀜 알림.
 *
 * 풀은 싱글톤이라 [reset] 으로 매번 비운다. 시계는 실제 시계를 쓰므로 남은 시간은 범위로 확인한다.
 * 실행: ./gradlew :app:testDebugUnitTest
 */
class GeminiKeyPoolTest {
    private val a = "key-A"
    private val b = "key-B"
    private val c = "key-C"
    // 키 풀은 모델 이름을 글자로만 다루므로, 앱에서 뺀 모델 이름이어도 시험에는 영향이 없다
    private val pro = "gemini-3.8-flash"
    private val lite = GeminiModels.LITE.id
    private val hydrogen = GeminiModels.HYDROGEN.id

    private fun field(name: String) = GeminiKeyPool::class.java.getDeclaredField(name).apply { isAccessible = true }

    @Suppress("UNCHECKED_CAST")
    private fun coolModelMap() = field("coolModel").get(GeminiKeyPool) as ConcurrentHashMap<String, Long>

    private fun resetThrottle() = (field("lastEventAt").get(GeminiKeyPool) as AtomicLong).set(0L)

    @Before
    fun reset() {
        (field("cool").get(GeminiKeyPool) as ConcurrentHashMap<*, *>).clear()
        (field("rejected").get(GeminiKeyPool) as ConcurrentHashMap<*, *>).clear()
        coolModelMap().clear()
        (field("counter").get(GeminiKeyPool) as AtomicInteger).set(0)
        resetThrottle()
        GeminiKeyPool.onEvent = null
        GeminiKeyPool.pick(emptyList())
        GeminiKeyPool.used("")
    }

    /** 등록한 키로 알려 준다 (앱에서는 Prefs.geminiKey 가 pick 을 부르며 알려 준다) */
    private fun register(vararg keys: String) {
        GeminiKeyPool.pick(keys.toList())
        (field("counter").get(GeminiKeyPool) as AtomicInteger).set(0)
    }

    /** 이 모델만의 분당 한도 응답 (모델 이름 · PerModel · retryDelay 포함) */
    private fun perModelBody(model: String, retry: String? = "34s"): String {
        val info = if (retry != null) ""","retryDelay":"$retry"""" else ""
        return """{"error":{"code":429,"message":"You exceeded your current quota","status":"RESOURCE_EXHAUSTED","details":[""" +
            """{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaMetric":"generate_content_requests",""" +
            """"quotaId":"GenerateRequestsPerMinutePerProjectPerModel","quotaDimensions":{"model":"$model"}}]}""" +
            (if (retry != null) """,{"@type":"type.googleapis.com/google.rpc.RetryInfo"$info}""" else "") + "]}}"
    }

    /** 어느 모델의 한도인지 알 수 없는 한도 응답 */
    private fun unscopedBody(retry: String? = null): String =
        """{"error":{"code":429,"message":"You exceeded your current quota, please check your plan"""" +
            (if (retry != null) ""","details":[{"retryDelay":"$retry"}]""" else "") + "}}"

    private fun left(model: String): Long = GeminiKeyPool.restingModels()[model] ?: -1L

    // ───────── 한도 응답 판별 (isQuota) ─────────

    @Test
    fun 한도_응답이면_한도로_본다() {
        assertTrue(GeminiKeyPool.isQuota(perModelBody(pro)))
        assertTrue(GeminiKeyPool.isQuota("""{"error":{"details":[{"@type":"x.QuotaFailure"}]}}"""))
        assertTrue(GeminiKeyPool.isQuota("""{"error":{"message":"You exceeded your current quota"}}"""))
        assertTrue(GeminiKeyPool.isQuota("""{"retryDelay":"20s"}"""))
        assertTrue(GeminiKeyPool.isQuota("Quota exceeded for metric: requests per minute"))
        assertTrue(GeminiKeyPool.isQuota("Quota exceeded: GenerateRequestsPerDayPerProjectPerModel"))
    }

    @Test
    fun 서버가_붐빌_때의_429는_한도가_아니다() {
        assertFalse(GeminiKeyPool.isQuota(null))
        assertFalse(GeminiKeyPool.isQuota(""))
        assertFalse(GeminiKeyPool.isQuota("""{"error":{"code":429,"message":"Resource has been exhausted (e.g. check quota)."}}"""))
        assertFalse(GeminiKeyPool.isQuota("""{"error":{"code":503,"message":"The model is overloaded."}}"""))
    }

    // ───────── 한도가 찼을 때 얼마나 쉬는지 (onLimit) ─────────

    @Test
    fun 분당_한도는_알려_준_시간만큼_이_모델만_쉰다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro, "34s"), badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 32_000L..34_000L)
        assertEquals(setOf(pro), GeminiKeyPool.restingModels().keys)
    }

    @Test
    fun 한도가_차도_키_전체는_쉬지_않는다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        assertFalse(GeminiKeyPool.resting(a))
        assertFalse(GeminiKeyPool.resting(b))
    }

    @Test
    fun 한도가_찬_키도_다른_모델에는_계속_쓴다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        assertEquals(a, GeminiKeyPool.forModel(a, lite))
        assertEquals(b, GeminiKeyPool.forModel(a, pro))
        assertTrue(GeminiKeyPool.usable(lite))
    }

    @Test
    fun 대기_시간이_없으면_분당_한도는_60초() {
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro, retry = null), badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 58_000L..60_000L)
    }

    @Test
    fun 응답에_모델_이름만_있어도_모델_한도로_본다() {
        GeminiKeyPool.onLimit(a, pro, """{"error":{"message":"Quota exceeded for $pro"}}""", badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 58_000L..60_000L)
    }

    @Test
    fun 대기_시간이_너무_짧으면_5초로_올린다() {
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro, "1s"), badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 3_000L..5_000L)
    }

    @Test
    fun 대기_시간이_너무_길면_5분으로_줄인다() {
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro, "900s"), badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 298_000L..300_000L)
    }

    @Test
    fun 소수_대기_시간도_읽는다() {
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro, "12.5s"), badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 10_500L..12_500L)
    }

    @Test
    fun 하루_한도는_10분_쉰다() {
        val body = """{"error":{"message":"You exceeded your current quota","details":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel","quotaDimensions":{"model":"$pro"}}]}}"""
        GeminiKeyPool.onLimit(a, pro, body, badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 598_000L..600_000L)
    }

    @Test
    fun 하루_한도에_더_긴_대기_시간이_있으면_그만큼_쉰다() {
        val body = """{"error":{"message":"quota","details":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel"},{"retryDelay":"900s"}]}}"""
        GeminiKeyPool.onLimit(a, pro, body, badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 898_000L..900_000L)
    }

    @Test
    fun 한도_0이면_30분_쉰다() {
        val body = """{"error":{"message":"Quota exceeded for metric generate_content_free_tier_requests, limit: 0, model: $pro"}}"""
        GeminiKeyPool.onLimit(a, pro, body, badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 1_798_000L..1_800_000L)
    }

    @Test
    fun 한도_05나_한도_10은_한도_0이_아니다() {
        GeminiKeyPool.onLimit(a, pro, """{"error":{"message":"quota limit: 05 per minute for $pro"}}""", badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 58_000L..60_000L)
        GeminiKeyPool.onLimit(a, lite, """{"error":{"message":"quota limit: 10 per minute for $lite"}}""", badKey = false)
        assertTrue("남은 시간 ${left(lite)}", left(lite) in 58_000L..60_000L)
    }

    @Test
    fun 어느_모델의_한도인지_몰라도_키_전체는_쉬지_않고_이_모델만_30초_쉰다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, unscopedBody(), badKey = false)
        assertFalse(GeminiKeyPool.resting(a))
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 28_000L..30_000L)
    }

    @Test
    fun 어느_모델의_한도인지_몰라도_알려_준_대기_시간은_따른다() {
        GeminiKeyPool.onLimit(a, pro, unscopedBody("20s"), badKey = false)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 18_000L..20_000L)
    }

    @Test
    fun 본문이_없는_한도도_이_모델만_30초_쉰다() {
        GeminiKeyPool.onLimit(a, pro, null, badKey = false)
        assertFalse(GeminiKeyPool.resting(a))
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 28_000L..30_000L)
    }

    @Test
    fun 같은_모델이_여러_키에서_쉬면_가장_짧게_남은_시간을_보여_준다() {
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro, "120s"), badKey = false)
        GeminiKeyPool.onLimit(b, pro, perModelBody(pro, "30s"), badKey = false)
        assertEquals(1, GeminiKeyPool.restingModels().size)
        assertTrue("남은 시간 ${left(pro)}", left(pro) in 28_000L..30_000L)
    }

    // ───────── 키가 거부됐을 때 ─────────

    @Test
    fun 키가_거부돼도_키를_쉬게_하지_않는다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, """{"error":{"code":400,"message":"API key not valid. Please pass a valid API key."}}""", badKey = true)
        assertFalse(GeminiKeyPool.resting(a))
        assertTrue(GeminiKeyPool.restingModels().isEmpty())
        assertNull(GeminiKeyPool.statusOf(a))
        assertEquals(setOf(a, b), (1..4).map { GeminiKeyPool.pick(listOf(a, b)) }.toSet())
    }

    @Test
    fun 특정_모델만_권한이_없는_403은_그_모델만_10분_쉰다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, hydrogen, """{"error":{"code":403,"message":"The caller does not have permission to use model $hydrogen"}}""", badKey = true)
        assertTrue("남은 시간 ${left(hydrogen)}", left(hydrogen) in 598_000L..600_000L)
        assertFalse(GeminiKeyPool.resting(a))
        assertEquals(a, GeminiKeyPool.forModel(a, pro))
        assertEquals(b, GeminiKeyPool.forModel(a, hydrogen))
    }

    // ───────── 키 고르기 (pick · 번갈아 쓰기) ─────────

    @Test
    fun 키가_없으면_빈_글을_돌려준다() {
        assertEquals("", GeminiKeyPool.pick(emptyList()))
    }

    @Test
    fun 키를_번갈아_쓴다() {
        val keys = listOf(a, b, c)
        assertEquals(listOf(a, b, c, a), (1..4).map { GeminiKeyPool.pick(keys) })
    }

    @Test
    fun 모델_한도가_차도_키는_번갈아_쓰는_순서에_그대로_있다() {
        val keys = listOf(a, b)
        GeminiKeyPool.pick(keys)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        assertEquals(setOf(a, b), (1..4).map { GeminiKeyPool.pick(keys) }.toSet())
    }

    @Test
    fun 쉬는_키는_건너뛴다() {
        val keys = listOf(a, b)
        GeminiKeyPool.cooldown(a, 60_000L)
        assertTrue(GeminiKeyPool.resting(a))
        assertEquals(setOf(b), (1..5).map { GeminiKeyPool.pick(keys) }.toSet())
    }

    @Test
    fun 키가_모두_쉬면_가장_빨리_풀리는_키를_쓴다() {
        val keys = listOf(a, b, c)
        GeminiKeyPool.cooldown(a, 120_000L)
        GeminiKeyPool.cooldown(b, 30_000L)
        GeminiKeyPool.cooldown(c, 60_000L)
        assertEquals(b, GeminiKeyPool.pick(keys))
    }

    @Test
    fun 쉬는_시간이_지난_키는_다시_쓴다() {
        val keys = listOf(a, b)
        GeminiKeyPool.cooldown(a, -1L)
        assertFalse(GeminiKeyPool.resting(a))
        assertEquals(setOf(a, b), (1..4).map { GeminiKeyPool.pick(keys) }.toSet())
    }

    // ───────── 다른 키 · 다른 모델 찾기 ─────────

    @Test
    fun 이미_써_본_키는_빼고_다른_키를_찾는다() {
        register(a, b, c)
        assertEquals(b, GeminiKeyPool.alternative(setOf(a)))
        assertEquals(c, GeminiKeyPool.alternative(setOf(a, b)))
        assertNull(GeminiKeyPool.alternative(setOf(a, b, c)))
    }

    @Test
    fun 이_모델에서_한도가_찬_키는_다른_키_후보에서_뺀다() {
        register(a, b, c)
        GeminiKeyPool.onLimit(b, pro, perModelBody(pro), badKey = false)
        assertEquals(c, GeminiKeyPool.alternative(setOf(a), pro))
        // 모델을 주지 않으면 모델별 한도는 보지 않는다
        assertEquals(b, GeminiKeyPool.alternative(setOf(a)))
        // 다른 모델에서는 b 도 쓸 수 있다
        assertEquals(b, GeminiKeyPool.alternative(setOf(a), lite))
    }

    @Test
    fun 이_모델에서_쓸_다른_키가_없으면_null() {
        register(a, b, c)
        GeminiKeyPool.onLimit(b, pro, perModelBody(pro), badKey = false)
        GeminiKeyPool.onLimit(c, pro, perModelBody(pro), badKey = false)
        assertNull(GeminiKeyPool.alternative(setOf(a), pro))
    }

    @Test
    fun 키_전체가_쉬는_키도_다른_키_후보에서_뺀다() {
        register(a, b, c)
        GeminiKeyPool.cooldown(b, 60_000L)
        assertEquals(c, GeminiKeyPool.alternative(setOf(a)))
    }

    @Test
    fun 키를_하나만_등록했으면_다른_키가_없다() {
        register(a)
        assertNull(GeminiKeyPool.alternative(setOf(a)))
    }

    @Test
    fun 이_모델에서_막힌_키는_막히지_않은_키로_바꿔_준다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        assertEquals(b, GeminiKeyPool.forModel(a, pro))
        assertEquals(b, GeminiKeyPool.forModel(b, pro))
    }

    @Test
    fun 모든_키가_이_모델에서_막혔으면_키를_그대로_돌려준다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        GeminiKeyPool.onLimit(b, pro, perModelBody(pro), badKey = false)
        assertEquals(a, GeminiKeyPool.forModel(a, pro))
    }

    // ───────── 모델을 쓸 수 있는지 (usable) ─────────

    @Test
    fun 키를_아직_모르면_모델을_쓸_수_있다고_본다() {
        assertTrue(GeminiKeyPool.usable(pro))
    }

    @Test
    fun 키_하나라도_쓸_수_있으면_모델은_쓸_수_있다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        assertTrue(GeminiKeyPool.usable(pro))
        assertTrue(GeminiKeyPool.anyUsable(pro))
    }

    @Test
    fun 모든_키가_한도면_그_모델만_못_쓴다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        GeminiKeyPool.onLimit(b, pro, perModelBody(pro), badKey = false)
        assertFalse(GeminiKeyPool.usable(pro))
        assertFalse(GeminiKeyPool.anyUsable(pro))
        assertTrue(GeminiKeyPool.usable(lite))
    }

    @Test
    fun 쉬는_시간이_지나면_모델을_다시_쓴다() {
        register(a)
        coolModelMap()["$a|$pro"] = System.currentTimeMillis() - 1
        assertTrue(GeminiKeyPool.usable(pro))
        assertTrue(GeminiKeyPool.restingModels().isEmpty())
    }

    @Test
    fun 키_전체가_쉬면_모든_모델을_못_쓴다() {
        register(a)
        GeminiKeyPool.cooldown(a, 60_000L)
        assertFalse(GeminiKeyPool.usable(pro))
        assertFalse(GeminiKeyPool.usable(lite))
    }

    @Test
    fun 쉬는_모델이면_쓸_수_있는_다른_모델로_바꾼다() {
        register(a, b)
        assertEquals(pro, GeminiAuto.usableOrFallback(pro))
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        assertEquals(pro, GeminiAuto.usableOrFallback(pro)) // b 가 아직 쓸 수 있다
        GeminiKeyPool.onLimit(b, pro, perModelBody(pro), badKey = false)
        assertEquals(hydrogen, GeminiAuto.usableOrFallback(pro))
        GeminiKeyPool.onLimit(a, hydrogen, perModelBody(hydrogen), badKey = false)
        GeminiKeyPool.onLimit(b, hydrogen, perModelBody(hydrogen), badKey = false)
        assertEquals(lite, GeminiAuto.usableOrFallback(pro))
    }

    @Test
    fun 쓸_수_있는_모델이_하나도_없으면_그_모델_그대로() {
        register(a)
        for (m in GeminiModels.all) GeminiKeyPool.onLimit(a, m.id, perModelBody(m.id), badKey = false)
        assertEquals(pro, GeminiAuto.usableOrFallback(pro))
    }

    // ───────── 설정 화면 · 오류 안내 표시 (statusOf · restingSummary) ─────────

    @Test
    fun 멀쩡한_키는_상태가_없다() {
        register(a, b)
        assertNull(GeminiKeyPool.statusOf(a))
    }

    @Test
    fun 모델_한도는_어느_모델인지와_다른_모델은_쓸_수_있다고_알려_준다() {
        register(a, b)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        val s = GeminiKeyPool.statusOf(a)
        assertNotNull(s)
        assertEquals("${GeminiAuto.label(pro)} 한도 도달 · 다른 모델은 사용 가능", s)
        assertNull(GeminiKeyPool.statusOf(b))
    }

    @Test
    fun 여러_모델이_쉬면_이름을_모두_보여_준다() {
        register(a)
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        GeminiKeyPool.onLimit(a, lite, perModelBody(lite), badKey = false)
        val s = GeminiKeyPool.statusOf(a)!!
        assertTrue(s, s.contains(GeminiAuto.label(pro)) && s.contains(GeminiAuto.label(lite)))
    }

    @Test
    fun 키_전체_휴식은_분_단위로_올림해서_보여_준다() {
        GeminiKeyPool.cooldown(a, 150_000L)
        assertEquals("한도 도달 · 3분 뒤 다시 사용", GeminiKeyPool.statusOf(a))
    }

    @Test
    fun 키_전체_휴식이_1분_미만이면_초로_보여_준다() {
        GeminiKeyPool.cooldown(a, 30_000L)
        val s = GeminiKeyPool.statusOf(a)!!
        assertTrue(s, Regex("한도 도달 · \\d+초 뒤 다시 사용").matches(s))
    }

    @Test
    fun 거부된_키는_거부됐다고_보여_준다() {
        GeminiKeyPool.cooldown(a, 150_000L, bad = true)
        assertEquals("키가 거부됐어요 · 3분 뒤 다시 확인", GeminiKeyPool.statusOf(a))
    }

    @Test
    fun 쉬는_모델이_없으면_요약은_빈_글() {
        assertTrue(GeminiKeyPool.restingModels().isEmpty())
        assertEquals("", GeminiKeyPool.restingSummary())
    }

    @Test
    fun 쉬는_모델_요약은_모델_이름과_남은_시간() {
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro, "30s"), badKey = false)
        val s = GeminiKeyPool.restingSummary()
        assertTrue(s, Regex("${Regex.escape(GeminiAuto.label(pro))} \\d+(초|분)").matches(s))
    }

    @Test
    fun 쉬는_모델이_여럿이면_가운뎃점으로_이어_준다() {
        GeminiKeyPool.onLimit(a, pro, perModelBody(pro), badKey = false)
        GeminiKeyPool.onLimit(a, lite, perModelBody(lite), badKey = false)
        val parts = GeminiKeyPool.restingSummary().split(" · ")
        assertEquals(2, parts.size)
        assertTrue(parts.any { it.startsWith(GeminiAuto.label(pro)) })
        assertTrue(parts.any { it.startsWith(GeminiAuto.label(lite)) })
    }

    // ───────── 키가 바뀌었다는 알림 (notifySwitch · KeySwitchEvent) ─────────

    @Test
    fun 키_바뀜_알림_글() {
        assertEquals("키 1 한도 도달 → 키 2 사용", KeySwitchEvent(1, 2, 2, bad = false).text)
        assertEquals("키 2 거부됨 → 키 3 사용", KeySwitchEvent(2, 3, 3, bad = true).text)
    }

    @Test
    fun 키가_바뀌면_몇_번에서_몇_번으로_바뀌었는지_알린다() {
        register(a, b, c)
        val got = ArrayList<KeySwitchEvent>()
        GeminiKeyPool.onEvent = { got.add(it) }
        GeminiKeyPool.notifySwitch(b, c, bad = false)
        assertEquals(1, got.size)
        val e = got[0]
        assertEquals(2, e.from)
        assertEquals(3, e.to)
        assertEquals(3, e.total)
        assertFalse(e.bad)
    }

    @Test
    fun 키가_거부돼서_바뀌면_거부로_알린다() {
        register(a, b)
        val got = ArrayList<KeySwitchEvent>()
        GeminiKeyPool.onEvent = { got.add(it) }
        GeminiKeyPool.notifySwitch(a, b, bad = true)
        assertEquals(1, got.size)
        assertTrue(got[0].bad)
        assertEquals("키 1 거부됨 → 키 2 사용", got[0].text)
    }

    @Test
    fun 키가_하나뿐이면_알리지_않는다() {
        register(a)
        val got = ArrayList<KeySwitchEvent>()
        GeminiKeyPool.onEvent = { got.add(it) }
        GeminiKeyPool.notifySwitch(a, a, bad = false)
        assertTrue(got.isEmpty())
    }

    @Test
    fun 알림은_3초에_한_번만_낸다() {
        register(a, b)
        val got = ArrayList<KeySwitchEvent>()
        GeminiKeyPool.onEvent = { got.add(it) }
        GeminiKeyPool.notifySwitch(a, b, bad = false)
        GeminiKeyPool.notifySwitch(b, a, bad = false)
        GeminiKeyPool.notifySwitch(a, b, bad = false)
        assertEquals(1, got.size)
        // 3초가 지났다고 치면 다시 알린다
        (field("lastEventAt").get(GeminiKeyPool) as AtomicLong).set(System.currentTimeMillis() - 3_001L)
        GeminiKeyPool.notifySwitch(b, a, bad = false)
        assertEquals(2, got.size)
    }

    @Test
    fun 알림을_안_내도_지금_쓰는_키_번호는_바뀐다() {
        register(a, b)
        GeminiKeyPool.notifySwitch(a, b, bad = false)
        GeminiKeyPool.notifySwitch(b, a, bad = false) // 3초 안이라 알림은 없지만
        assertEquals(1, GeminiKeyPool.currentNo())
    }

    @Test
    fun 키_개수와_지금_쓰는_키_번호() {
        assertEquals(0, GeminiKeyPool.count())
        register(a, b, c)
        assertEquals(3, GeminiKeyPool.count())
        GeminiKeyPool.used(c)
        assertEquals(3, GeminiKeyPool.currentNo())
        GeminiKeyPool.used("모르는-키")
        assertEquals(0, GeminiKeyPool.currentNo())
    }

    // ───────── 요청 한 번의 흐름 (Gemini.kt 의 stream 이 429 를 받았을 때와 같은 순서) ─────────

    @Test
    fun 한도를_맞으면_다음_키로_바꾸고_모든_키가_한도면_다른_모델로_간다() {
        val keys = listOf(a, b)
        val tried = mutableSetOf<String>()
        var cur = GeminiKeyPool.pick(keys)
        val first = cur
        // 첫 키가 한도 → 다른 키가 있다
        GeminiKeyPool.onLimit(cur, pro, perModelBody(pro), badKey = false)
        tried.add(cur)
        cur = GeminiKeyPool.alternative(tried, pro)!!
        assertEquals(if (first == a) b else a, cur)
        // 둘째 키도 한도 → 더 쓸 키가 없다
        GeminiKeyPool.onLimit(cur, pro, perModelBody(pro), badKey = false)
        tried.add(cur)
        assertNull(GeminiKeyPool.alternative(tried, pro))
        // 이 모델은 쉬는 중이고 오류 안내에 쉬는 모델이 나온다
        assertFalse(GeminiKeyPool.usable(pro))
        assertTrue(GeminiKeyPool.restingSummary().startsWith(GeminiAuto.label(pro)))
        // 다음 요청은 처음부터 다른 모델로 보낸다
        assertEquals(hydrogen, GeminiAuto.usableOrFallback(pro))
        // 다른 모델에서는 키를 처음부터 다시 쓸 수 있다
        assertEquals(a, GeminiKeyPool.forModel(a, hydrogen))
    }

    // ───────── 웹 검색 한도 (채팅 한도와 따로 센다) ─────────

    @Test
    fun 한도_응답에서_한도_이름을_읽는다() {
        assertEquals("GenerateRequestsPerMinutePerProjectPerModel", GeminiKeyPool.quotaName(perModelBody(pro)))
        // quotaId 가 없으면 quotaMetric 의 마지막 이름
        val metricOnly = """{"error":{"code":429,"details":[{"violations":[{"quotaMetric":"generativelanguage.googleapis.com/generate_content_grounding_requests"}]}]}}"""
        assertEquals("generate_content_grounding_requests", GeminiKeyPool.quotaName(metricOnly))
        assertEquals("", GeminiKeyPool.quotaName("Resource has been exhausted"))
        assertEquals("", GeminiKeyPool.quotaName(null))
    }

    @Test
    fun 검색을_쉬게_하면_그_시간_동안만_쉬고_풀_수_있다() {
        GeminiSearch.clearRest()
        assertFalse(GeminiSearch.resting())
        GeminiSearch.rest(60_000L)
        assertTrue(GeminiSearch.resting())
        GeminiSearch.clearRest()
        assertFalse(GeminiSearch.resting())
        // 이미 지난 시간이면 쉬지 않는다
        GeminiSearch.rest(-1L)
        assertFalse(GeminiSearch.resting())
    }

    // ───────── 모델이 검색 도구를 못 받을 때 ─────────

    @Test
    fun 검색_도구를_탓하는_400_글을_알아본다() {
        assertTrue(GeminiSearch.blamesSearch("""{"error":{"message":"google_search is not supported for this model"}}"""))
        assertTrue(GeminiSearch.blamesSearch("""{"error":{"message":"Search Grounding is not supported."}}"""))
        assertTrue(GeminiSearch.blamesSearch("""{"error":{"message":"Tool use with function calling is unsupported"}}"""))
        // 키 오류는 검색 탓이 아니다
        assertFalse(GeminiSearch.blamesSearch("""{"error":{"message":"API key not valid. Please pass a valid API key."}}"""))
        assertFalse(GeminiSearch.blamesSearch("""{"error":{"message":"Invalid value at generation_config"}}"""))
    }

    @Test
    fun 검색을_거부한_모델은_잠시_기억하고_검색_탓이_아니면_기억하지_않는다() {
        GeminiSearch.clearUnsupported()
        val body = """{"error":{"message":"Search Grounding is not supported."}}"""
        // 검색을 붙이지 않았거나 400 이 아니면 기억하지 않는다
        assertFalse(GeminiSearch.rejected(400, body, pro, applied = false))
        assertFalse(GeminiSearch.rejected(429, body, pro, applied = true))
        assertFalse(GeminiSearch.isUnsupported(pro))
        // 검색 탓이 아닌 400 도 기억하지 않는다
        assertFalse(GeminiSearch.rejected(400, """{"error":{"message":"API key not valid"}}""", pro, applied = true))
        assertFalse(GeminiSearch.isUnsupported(pro))
        // 검색 탓이면 그 모델만 기억한다
        assertTrue(GeminiSearch.rejected(400, body, pro, applied = true))
        assertTrue(GeminiSearch.isUnsupported(pro))
        assertFalse(GeminiSearch.isUnsupported(lite))
        GeminiSearch.clearUnsupported()
        assertFalse(GeminiSearch.isUnsupported(pro))
    }
}
