package com.example.evergreen

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 어떤 질문을 에이전트(도구를 쓰는 쪽)로 보낼지 가르는 [AgentRouting] 테스트.
 * 도구가 있는 앱 조작이 일반 채팅으로 새서 「지원하지 않는다」 는 답이 나오지 않아야 한다.
 * 실행: ./gradlew :app:testDebugUnitTest
 */
class AgentRoutingTest {
    @Test
    fun 앱_조작_말은_에이전트로_간다() {
        val asks = listOf(
            "탭 다 닫아 줘", "구글 열어봐", "새 창으로 옮겨 줘", "시크릿 탭 열어 줘", "다크 모드 켜줘",
            "데스크톱 사이트로 바꿔 줘", "글자 크기 키워 줘", "광고 차단 꺼 줘", "북마크 폴더 정리해 줘",
            "닫힌 창에 넣어 줘", "창 2로 옮겨 줘", "2번 창에 보내 줘", "열린 창으로 옮겨줘",
            "웹스토어에서 확장 설치해 줘", "페이지 확대해 줘", "맨 아래로 스크롤해 줘", "항상 번역 켜 줘", "시작 페이지 바꿔 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 사진_낱말이_있어도_앱_조작이_분명하면_에이전트로_간다() {
        assertTrue(AgentRouting.useAgent("이 이미지 다운로드해 줘"))
        assertTrue(AgentRouting.useAgent("사진 있는 탭 닫아 줘"))
        assertTrue(AgentRouting.useAgent("이 그림 북마크해 줘"))
    }

    @Test
    fun 사진을_읽어야_하는_말과_잡담은_일반_채팅으로_간다() {
        assertFalse(AgentRouting.useAgent("이 사진 뭐야?"))
        assertFalse(AgentRouting.useAgent("이 그래프 설명해 줘"))
        assertFalse(AgentRouting.useAgent("안녕"))
        assertFalse(AgentRouting.useAgent("고마워"))
    }

    @Test
    fun 웹_페이지_조작_말은_에이전트로_간다() {
        val asks = listOf(
            "로그인 버튼 눌러 줘", "장바구니에 담아 줘", "좋아요 눌러줘", "구독해 줘", "검색창에 날씨 입력해 줘",
            "더보기 펼쳐 줘", "팝업 닫아 줘", "웹 조작 해 봐", "이거 대신 해 줘", "영상 재생해 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 에이전트가_하던_일의_짧은_이어_말하기는_에이전트로_간다() {
        assertTrue(AgentRouting.isFollowUp("응 그걸로 해", true))
        assertTrue(AgentRouting.isFollowUp("두 번째 걸로", true))
        assertFalse(AgentRouting.isFollowUp("응 그걸로 해", false))
        assertFalse(AgentRouting.isFollowUp("고마워", true))
        assertFalse(AgentRouting.isFollowUp("이 사진 뭐야?", true))
        assertFalse(AgentRouting.isFollowUp("a".repeat(41), true))
    }
}
