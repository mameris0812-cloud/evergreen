package com.example.evergreen

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.content.Intent
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * 앱 안에서 보는 다운로드 목록.
 * - 받은 파일을 최근 순으로 보여주고, 누르면 열기 / 공유 / 폴더로 이동 / 삭제
 * - 받는 중인 파일은 맨 위에 진행률과 함께 보이고 취소할 수 있다
 * - 폴더: 위쪽 칩으로 폴더를 만들고, 파일을 폴더로 옮겨 정리한다 (앱 안에서만 쓰는 분류 — 실제 파일 위치는 그대로)
 */
class DownloadsActivity : AppCompatActivity() {

    private class Item(
        /** "m:123" = 미디어 저장소, "d:55" = 시스템 다운로드 관리자, "a:1000" = 지금 받는 중 */
        val key: String,
        val name: String,
        val size: Long,
        val time: Long,
        val mime: String?,
        val uri: Uri?,
        val activeId: Int = -1,
        val downloaded: Long = 0L,
        val speed: Long = 0L
    ) {
        val active: Boolean get() = activeId >= 0
    }

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var chipRow: LinearLayout
    private val adapter = RowAdapter()
    private lateinit var select: ListSelect<String>

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var stored: List<Item> = emptyList()
    private var active: List<ActiveDownload> = emptyList()
    private val shown = ArrayList<Item>()
    private var folderNames: Map<Long, String> = emptyMap()
    private var folderMap: Map<String, Long> = emptyMap()
    private var selected = ListUi.ALL
    private var loaded = false
    private var hadActive = false

    private val dateFormat = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        ThemeColors.skin(findViewById(android.R.id.content))   // XML 의 ?attr 색에도 테마 색 입히기 (목록 줄은 만들어질 때마다 자동)
        ListUi.fitSystemBars(this)
        ListUi.applyTabletPopup(this)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "다운로드"
        findViewById<View>(R.id.btnListBack).setOnClickListener { ListUi.closeSheet(this, backToMenu = true) }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        chipRow = findViewById(R.id.chipRow)
        listView.adapter = adapter
        select = ListSelect(
            this, listView, findViewById(R.id.btnListAction), findViewById(R.id.listTitle),
            // 받는 중인 파일은 고를 수 없다 (먼저 취소해야 한다)
            visibleKeys = { shown.filter { !it.active }.map { it.key } },
            onChanged = { adapter.notifyDataSetChanged() },
            onDelete = { keys -> confirmDeleteMany(keys) }
        )

        refreshView()
    }

    override fun onResume() {
        super.onResume()
        reload()
        ui.postDelayed(tick, 1000)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        io.shutdown()
        super.onDestroy()
    }

    /** 1초마다: 받는 중인 파일이 있으면 진행률을 갱신하고, 방금 끝난 파일도 목록에 나타나게 한다. */
    private val tick = object : Runnable {
        override fun run() {
            val now = DownloadService.snapshot()
            val busy = now.isNotEmpty() || hadActive
            hadActive = now.isNotEmpty()
            active = now
            if (busy) reload()
            ui.postDelayed(this, 1000)
        }
    }

    // ───────────────────────── 목록 읽기 ─────────────────────────

    private fun reload() {
        if (isDestroyed || io.isShutdown) return
        io.execute {
            val items = try {
                queryDownloads()
            } catch (e: Exception) {
                emptyList()
            }
            ui.post {
                if (isFinishing || isDestroyed) return@post
                stored = items
                loaded = true
                refreshView()
            }
        }
    }

    private fun queryDownloads(): List<Item> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) queryMediaStore() else queryDownloadManager()

    /** Android 10+: 이 앱이 받은 파일 (빠른 다운로드 + 시스템 다운로더) 이 미디어 저장소에 모두 올라온다. */
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun queryMediaStore(): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.MIME_TYPE
        )
        contentResolver.query(
            base, projection, null, null,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    Item(
                        key = "m:$id",
                        name = c.getString(iName) ?: "(이름 없음)",
                        size = c.getLong(iSize),
                        time = c.getLong(iDate) * 1000L,
                        mime = c.getString(iMime),
                        uri = ContentUris.withAppendedId(base, id)
                    )
                )
            }
        }
        return out
    }

    /** Android 9 이하: 시스템 다운로드 관리자에 맡긴 파일 목록 (저장소 권한이 필요 없다). */
    private fun queryDownloadManager(): List<Item> {
        val out = ArrayList<Item>()
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        dm.query(DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL))?.use { c ->
            val iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
            val iTitle = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
            val iSize = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val iMime = c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)
            val iTime = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    Item(
                        key = "d:$id",
                        name = c.getString(iTitle) ?: "(이름 없음)",
                        size = c.getLong(iSize),
                        time = c.getLong(iTime),
                        mime = c.getString(iMime),
                        uri = dm.getUriForDownloadedFile(id)
                    )
                )
            }
        }
        return out.sortedByDescending { it.time }
    }

    // ───────────────────────── 화면 그리기 ─────────────────────────

    private fun activeItems(): List<Item> = active.map {
        Item(
            key = "a:${it.id}",
            name = it.name.ifEmpty { "다운로드 준비 중…" },
            size = it.total,
            time = 0L,
            mime = null,
            uri = null,
            activeId = it.id,
            downloaded = it.downloaded,
            speed = it.speedBps
        )
    }

    private fun refreshView() {
        val folders = prefs.folders(Prefs.KIND_DL)
        folderNames = folders.associate { it.id to it.name }
        folderMap = prefs.downloadFolderMap()
        if (selected != ListUi.ALL && folders.none { it.id == selected }) selected = ListUi.ALL

        // 폴더 칩 (개수 포함)
        val counts = HashMap<Long, Int>()
        stored.forEach {
            val f = folderMap[it.key] ?: 0L
            counts[f] = (counts[f] ?: 0) + 1
        }
        val entries = ArrayList<ListUi.ChipEntry>()
        entries.add(ListUi.ChipEntry(ListUi.ALL, "전체 (${stored.size + active.size})"))
        folders.forEach { entries.add(ListUi.ChipEntry(it.id, "${it.name} (${counts[it.id] ?: 0})")) }
        ListUi.renderChips(
            chipRow, entries, selected,
            onSelect = {
                selected = it
                select.exit()
                refreshView()
            },
            onLongPress = { id ->
                folders.firstOrNull { it.id == id }?.let { f ->
                    ListUi.showFolderMenu(this, prefs, Prefs.KIND_DL, f) { refreshView() }
                }
            },
            onAdd = {
                ListUi.createFolder(this, prefs, Prefs.KIND_DL) {
                    selected = it.id
                    refreshView()
                }
            }
        )

        // 목록
        shown.clear()
        if (selected == ListUi.ALL) {
            shown.addAll(activeItems())
            shown.addAll(stored)
        } else {
            shown.addAll(stored.filter { folderMap[it.key] == selected })
        }
        select.retain()
        adapter.notifyDataSetChanged()

        if (shown.isEmpty() && loaded) {
            emptyView.text =
                if (selected == ListUi.ALL) "받은 파일이 없습니다"
                else "이 폴더는 비어 있습니다\n파일의 ⋮ 메뉴 → '폴더로 이동' 으로 정리해 보세요"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    /** PDF · 워드 · 엑셀 · 파워포인트 · 텍스트 문서는 색이 있는 배지 아이콘 */
    private fun docBadge(name: String, mime: String?): Int? {
        val ext = name.substringAfterLast('.', "").lowercase()
        val m = mime ?: ""
        return when {
            ext == "pdf" || m == "application/pdf" -> R.drawable.ic_doc_pdf
            ext in setOf("doc", "docx", "dot", "dotx", "hwp", "hwpx", "rtf", "odt", "pages") ||
                m.contains("msword") || m.contains("wordprocessingml") -> R.drawable.ic_doc_word
            ext in setOf("xls", "xlsx", "csv", "ods", "numbers") ||
                m.contains("ms-excel") || m.contains("spreadsheetml") -> R.drawable.ic_doc_excel
            ext in setOf("ppt", "pptx", "odp", "key") ||
                m.contains("ms-powerpoint") || m.contains("presentationml") -> R.drawable.ic_doc_ppt
            ext in setOf("html", "htm", "xhtml", "mhtml") || m == "text/html" -> R.drawable.ic_doc_html
            ext in setOf("txt", "md", "srt", "vtt", "epub", "log") || m == "text/plain" -> R.drawable.ic_doc_text
            else -> null
        }
    }

    /** 파일 종류별 아이콘 (미리보기가 없을 때 / 만들어지는 동안 보인다) */
    private fun fileIcon(name: String, mime: String?): Int {
        val ext = name.substringAfterLast('.', "").lowercase()
        val m = mime ?: ""
        return when {
            m.startsWith("video") || ext in setOf("mp4", "mkv", "webm", "mov", "avi", "3gp", "m4v", "ts") -> R.drawable.ic_movie
            m.startsWith("image") || ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "svg") -> R.drawable.ic_image
            m.startsWith("audio") || ext in setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus") -> R.drawable.ic_music
            ext in setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz") -> R.drawable.ic_archive
            ext == "apk" || ext == "xapk" || ext == "apks" -> R.drawable.ic_phone
            else -> R.drawable.ic_file
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)
            val item = shown[position]

            val icon = v.findViewById<ImageView>(R.id.rowIcon)
            val title = v.findViewById<TextView>(R.id.rowTitle)
            val sub = v.findViewById<TextView>(R.id.rowSub)
            val bar = v.findViewById<ProgressBar>(R.id.rowProgress)
            val more = v.findViewById<ImageButton>(R.id.rowMore)

            title.text = item.name
            select.bindRow(
                v, item.key,
                when {
                    item.active -> R.drawable.ic_download
                    else -> fileIcon(item.name, item.mime)
                },
                selectable = !item.active
            )
            if (!item.active && !(select.active && select.isSelected(item.key))) {
                val badge = docBadge(item.name, item.mime)
                if (badge != null) Thumbs.badge(icon, badge)
                else Thumbs.apply(icon, item.uri, item.name, item.mime)
            } else Thumbs.reset(icon)

            if (item.active) {
                val speed = if (item.speed > 0) " · ${ListUi.fmtSize(item.speed)}/s" else ""
                if (item.size > 0) {
                    val pct = (item.downloaded * 100 / item.size).toInt().coerceIn(0, 100)
                    bar.isIndeterminate = false
                    bar.progress = pct
                    sub.text = "$pct% · ${ListUi.fmtSize(item.downloaded)} / ${ListUi.fmtSize(item.size)}$speed"
                } else {
                    bar.isIndeterminate = true
                    sub.text = "${ListUi.fmtSize(item.downloaded)}$speed"
                }
                bar.visibility = View.VISIBLE
            } else {
                bar.visibility = View.GONE
                val folder = folderMap[item.key]?.let { folderNames[it] }
                val parts = ArrayList<String>()
                if (item.size > 0) parts.add(ListUi.fmtSize(item.size))
                if (item.time > 0) parts.add(dateFormat.format(Date(item.time)))
                if (folder != null && selected == ListUi.ALL) parts.add(folder)
                sub.text = parts.joinToString(" · ")
            }

            v.setOnClickListener {
                if (select.active) { if (!item.active) select.toggle(item.key) }
                else if (!item.active) open(item)
            }
            v.setOnLongClickListener {
                if (item.active) showItemMenu(item)
                else if (select.active) select.toggle(item.key)
                else select.enter(item.key)
                true
            }
            more.setOnClickListener { showItemMenu(item) }
            return v
        }
    }

    // ───────────────────────── 항목 동작 ─────────────────────────

    private fun showItemMenu(item: Item) {
        if (item.active) {
            Popup.menu(
                this, title = item.name, subtitle = "다운로드 중", headerIcon = R.drawable.ic_download,
                items = listOf(
                    Popup.Item(R.drawable.ic_close, "다운로드 취소", danger = true) {
                        DownloadService.cancelJob(item.activeId)
                        ListUi.toast(this, "다운로드를 취소합니다")
                    }
                )
            )
            return
        }
        Popup.menu(
            this, title = item.name, headerIcon = R.drawable.ic_file,
            items = listOf(
                Popup.Item(R.drawable.ic_file, "열기") { open(item) },
                Popup.Item(R.drawable.ic_share, "공유") { share(item) },
                Popup.Item(R.drawable.ic_folder, "폴더로 이동") { moveToFolder(item) },
                Popup.Item(R.drawable.ic_delete, "삭제", danger = true) { confirmDelete(item) }
            )
        )
    }

    private fun open(item: Item, apkConfirmed: Boolean = false) {
        val uri = item.uri ?: return
        val lower = item.name.lowercase()
        // HTML 파일은 다른 앱이 아니라 이 브라우저의 새 탭으로 연다
        if (lower.endsWith(".html") || lower.endsWith(".htm") || lower.endsWith(".xhtml") ||
            item.mime == "text/html" || item.mime == "application/xhtml+xml"
        ) {
            setResult(
                RESULT_OK,
                Intent().putExtra(BookmarksActivity.EXTRA_URL, uri.toString())
                    .putExtra(BookmarksActivity.EXTRA_NEW_TAB, true)
            )
            ListUi.closeSheet(this)
            return
        }
        val isApk = lower.endsWith(".apk") || item.mime == "application/vnd.android.package-archive"
        if (isApk && !apkConfirmed) {
            ThemedDialogBuilder(this)
                .setTitle("앱(APK)을 설치할까요?")
                .setMessage("${item.name}\n\n출처를 알 수 없는 앱은 기기와 개인정보를 위험하게 할 수 있어요. 직접 내려받은 파일이고 믿을 수 있는 곳에서 받은 것일 때만 설치하세요.")
                .setPositiveButton("계속") { _, _ -> open(item, true) }
                .setNegativeButton("취소", null)
                .show()
            return
        }
        try {
            if (isApk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
                // 이 앱에 '출처를 알 수 없는 앱 설치'를 허용해야 설치 화면이 열린다
                ListUi.toast(this, "이 앱에 '알 수 없는 앱 설치'를 허용한 뒤 다시 눌러 주세요")
                startActivity(
                    Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                )
                return
            }
            val type = if (isApk) "application/vnd.android.package-archive"
            else item.mime?.takeIf { it.isNotBlank() && !FileNames.isGeneric(it) }
                ?: FileNames.mimeFor(item.name, item.mime) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, type)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            ListUi.toast(this, "이 파일을 열 수 있는 앱이 없습니다")
        } catch (e: Exception) {
            ListUi.toast(this, "파일을 열 수 없습니다")
        }
    }

    private fun share(item: Item) {
        val uri = item.uri ?: return
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = item.mime?.takeIf { it.isNotBlank() } ?: "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "공유"))
        } catch (e: Exception) {
            ListUi.toast(this, "공유할 수 없습니다")
        }
    }

    private fun moveToFolder(item: Item) {
        ListUi.pickFolder(this, prefs, Prefs.KIND_DL, folderMap[item.key] ?: 0L) { folderId ->
            prefs.setDownloadFolder(item.key, folderId)
            refreshView()
            val name = folderNames[folderId] ?: prefs.folders(Prefs.KIND_DL).firstOrNull { it.id == folderId }?.name
            ListUi.toast(this, if (folderId == 0L || name == null) "폴더에서 뺐습니다" else "'$name' 폴더로 옮겼습니다")
        }
    }

    private fun confirmDelete(item: Item) {
        ThemedDialogBuilder(this)
            .setMessage("'${item.name}' 파일을 삭제할까요?\n기기에서도 완전히 지워집니다.")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                if (io.isShutdown) return@setPositiveButton
                io.execute {
                    val ok = removeFile(item)
                    ui.post {
                        if (isFinishing || isDestroyed) return@post
                        if (ok) {
                            prefs.setDownloadFolder(item.key, 0L)
                            ListUi.toast(this, "삭제했습니다")
                        } else {
                            ListUi.toast(this, "삭제하지 못했습니다")
                        }
                        reload()
                    }
                }
            }
            .show()
    }

    /** 고른 파일들을 한 번에 지운다 (기기에서도 완전히 지워진다) */
    private fun confirmDeleteMany(keys: Set<String>) {
        val items = stored.filter { it.key in keys }
        if (items.isEmpty()) return
        val n = items.size
        val total = items.sumOf { it.size.coerceAtLeast(0L) }
        val sizeText = if (total > 0L) " (${ListUi.fmtSize(total)})" else ""
        ThemedDialogBuilder(this)
            .setTitle("파일 ${n}개 삭제")
            .setMessage("선택한 파일 ${n}개${sizeText}를 삭제할까요?\n기기에서도 완전히 지워지고 되돌릴 수 없습니다.")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                if (io.isShutdown) return@setPositiveButton
                select.finishDelete()
                io.execute {
                    val done = items.filter { removeFile(it) }
                    ui.post {
                        if (isFinishing || isDestroyed) return@post
                        prefs.clearDownloadFolders(done.map { it.key })
                        ListUi.toast(
                            this,
                            if (done.size == n) "${n}개를 삭제했습니다" else "${done.size}개 삭제 · ${n - done.size}개는 삭제하지 못했습니다"
                        )
                        reload()
                    }
                }
            }
            .show()
    }

    private fun removeFile(item: Item): Boolean = try {
        if (item.key.startsWith("m:")) {
            val uri = item.uri
            uri != null && contentResolver.delete(uri, null, null) > 0
        } else {
            val id = item.key.substring(2).toLong()
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).remove(id) > 0
        }
    } catch (e: Exception) {
        false
    }
}
