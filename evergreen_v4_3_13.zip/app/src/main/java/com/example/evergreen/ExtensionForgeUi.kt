package com.example.evergreen

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

/**
 * 'AI로 만들기' 화면. 어시스턴트 창과 같은 시트 · 같은 색(파랑 #4285F4 · 청록 #14A89A)으로 세 화면을 한 시트 안에서 바꿔 보여 준다.
 *  1) 입력(한 줄 설명 + 적용 범위 3택)  2) 만드는 중  3) 미리보기 카드(적용 / 다시 만들기)
 */
object ExtensionForgeUi {

    private val BLUE = 0xFF4285F4.toInt()
    private val BLUE_TEXT = 0xFF1A73E8.toInt()
    private val TEAL = 0xFF14A89A.toInt()
    private val WARN_BG = 0xFFF9DDA6.toInt()
    private val WARN_FG = 0xFF7A4A00.toInt()
    private val ui = Handler(Looper.getMainLooper())

    private val SUGGESTIONS = listOf(
        "다크 모드" to "이 페이지를 어두운 색으로 바꿔 줘",
        "광고 숨기기" to "이 페이지의 광고를 숨겨 줘",
        "자동 스크롤" to "이 페이지를 천천히 자동으로 스크롤해 줘",
        "단축키 추가" to "단축키로 맨 위 · 맨 아래로 이동하게 해 줘"
    )

    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    private fun round(color: Int, rDp: Float, a: Activity, strokeColor: Int? = null, strokeDp: Float = 1f) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = rDp * a.resources.displayMetrics.density
        if (strokeColor != null) setStroke(maxOf(1, (strokeDp * a.resources.displayMetrics.density).toInt()), strokeColor)
    }

    private class Pal(a: Activity) {
        val surface = ThemeColors.get(a, com.google.android.material.R.attr.colorSurface, Color.WHITE)
        val onSurface = ThemeColors.get(a, com.google.android.material.R.attr.colorOnSurface, 0xFF1F1F1F.toInt())
        val muted = ThemeColors.get(a, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val outline = ThemeColors.get(a, com.google.android.material.R.attr.colorOutline, 0xFFBDBDBD.toInt())
    }

    private fun label(a: Activity, text: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(a).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 0, a: Activity? = null) =
        LinearLayout.LayoutParams(w, h).apply { if (a != null) topMargin = dp(a, top) }

    /** 시트를 만든다. [content] 는 세로로 쌓이는 본문 칸이다 */
    private fun makeSheet(a: Activity): Pair<BottomSheetDialog, LinearLayout> {
        val p = Pal(a)
        val d = BottomSheetDialog(a)
        val body = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 20))
        }
        val scroll = ScrollView(a).apply {
            isFillViewport = false
            addView(body, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        d.setContentView(scroll)
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        d.behavior.apply {
            skipCollapsed = true
            maxWidth = dp(a, 640)
            state = BottomSheetBehavior.STATE_EXPANDED
        }
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.background = GradientDrawable().apply {
                setColor(p.surface)
                val r = dp(a, 28).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        return d to body
    }

    // ───────────────────────── 시작 ─────────────────────────

    /**
     * 'AI로 만들기' 시트를 연다. 설치까지 끝나면 [onInstalled] 가 불린다.
     * @param pageUrl 지금 보는 탭 주소 ('이 사이트만'의 기본값)
     */
    fun show(
        a: Activity,
        mgr: ExtensionManager,
        pageUrl: String?,
        prefill: String? = null,
        onInstalled: (ExtensionManager.Ext) -> Unit
    ) {
        if (Prefs(a).geminiKey.isBlank()) {
            AppToast.show(a, "설정에서 Gemini API 키를 먼저 저장해 주세요")
            return
        }
        val (d, body) = makeSheet(a)
        var request = prefill.orEmpty()
        var kind = if (ExtensionForge.siteScope(pageUrl) != null) ExtensionForge.ScopeKind.THIS_SITE else ExtensionForge.ScopeKind.CUSTOM
        var customText = ""
        var alive = true
        d.setOnDismissListener { alive = false }

        fun input() {
            body.removeAllViews()
            buildInput(a, body, d, pageUrl, request, kind, customText) { req, k, custom ->
                request = req; kind = k; customText = custom
                val scope = when (k) {
                    ExtensionForge.ScopeKind.THIS_SITE -> ExtensionForge.siteScope(pageUrl)
                    ExtensionForge.ScopeKind.ALL -> ExtensionForge.allSitesScope()
                    ExtensionForge.ScopeKind.CUSTOM -> ExtensionForge.customScope(custom)
                }
                if (req.isBlank()) { AppToast.show(a, "어떤 확장 프로그램을 만들지 적어 주세요"); return@buildInput }
                if (scope == null) { AppToast.show(a, "적용할 사이트 주소를 확인해 주세요"); return@buildInput }
                startRun(a, mgr, d, body, req, scope, pageUrl, null, { alive }, ::input, onInstalled)
            }
        }
        input()
        d.show()
    }

    // ───────────────────────── 고치기 ─────────────────────────

    /** 설치된 AI 확장을 말로 고친다 ("버튼 색 바꿔줘"). 고친 결과도 미리보기 카드를 거쳐 '적용'해야 바뀐다 */
    fun showEdit(a: Activity, mgr: ExtensionManager, e: ExtensionManager.Ext, onInstalled: (ExtensionManager.Ext) -> Unit) {
        val prev = mgr.draftOf(e)
        if (prev == null) { AppToast.show(a, "이 확장 프로그램은 AI로 고칠 수 없어요"); return }
        if (Prefs(a).geminiKey.isBlank()) { AppToast.show(a, "설정에서 Gemini API 키를 먼저 저장해 주세요"); return }
        val diag = mgr.diagLines(e.id).takeLast(6)
        val (d, body) = makeSheet(a)
        var alive = true
        var text = ""
        var histOpen = false
        d.setOnDismissListener { alive = false }
        fun input() {
            body.removeAllViews()
            val p = Pal(a)
            body.addView(LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(ImageView(a).apply { setImageResource(R.drawable.ic_ai); imageTintList = ColorStateList.valueOf(BLUE) }, LinearLayout.LayoutParams(dp(a, 22), dp(a, 22)))
                addView(label(a, "AI로 고치기 · ${e.name}", 17f, BLUE_TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 8) })
                addView(ImageView(a).apply {
                    setImageResource(R.drawable.ic_close); imageTintList = ColorStateList.valueOf(p.muted)
                    setPadding(dp(a, 6), dp(a, 6), dp(a, 6), dp(a, 6)); setOnClickListener { d.dismiss() }
                }, LinearLayout.LayoutParams(dp(a, 36), dp(a, 36)))
            })
            val field = EditText(a).apply {
                hint = "예: 버튼 색을 파랗게 바꿔줘"
                setText(text); minLines = 3; maxLines = 6
                gravity = Gravity.TOP or Gravity.START
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                textSize = 15f; setTextColor(p.onSurface); setHintTextColor(p.muted)
                background = round(Color.TRANSPARENT, 16f, a, p.outline)
                setPadding(dp(a, 14), dp(a, 12), dp(a, 14), dp(a, 12))
            }
            body.addView(field, lp(top = 12, a = a))
            val hist = prev.revs
            if (hist.length() > 0) {
                // 지금까지의 판: 요청이 길면 …, 판이 많으면 최근 3개만 (누르면 전부 펼치고 다시 누르면 접는다)
                val shown = if (histOpen) hist.length() else minOf(3, hist.length())
                val first = hist.length() - shown
                val txt = (first until hist.length()).joinToString(" → ") { k ->
                    val o = hist.optJSONObject(k)
                    val v = o?.optString("ver")?.ifBlank { null } ?: o?.optInt("rev") ?: "?"
                    val r = o?.optString("request").orEmpty()
                    "v$v " + if (!histOpen && r.length > 20) r.take(20) + "…" else r
                }
                val more = if (first > 0) "…(앞의 ${first}개 · 눌러서 펼치기) → " else ""
                body.addView(label(a, "지금까지: " + more + txt + if (histOpen && hist.length() > 3) "  (눌러서 접기)" else "", 12f, p.muted).apply {
                    isClickable = hist.length() > 3
                    setOnClickListener { histOpen = !histOpen; input() }
                }, lp(top = 8, a = a))
            }
            if (diag.isNotEmpty())
                body.addView(label(a, "최근 진단 로그의 오류도 AI에게 함께 보내요", 12f, p.muted), lp(top = 4, a = a))
            body.addView(TextView(a).apply {
                this.text = "고치기"; textSize = 15f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = round(TEAL, 100f, a)
                setOnClickListener {
                    text = field.text?.toString().orEmpty().trim()
                    if (text.isEmpty() && diag.isEmpty()) { AppToast.show(a, "무엇을 고칠지 적어 주세요"); return@setOnClickListener }
                    val change = (text.ifEmpty { "진단 로그의 오류를 고쳐 줘" }) +
                        if (diag.isEmpty()) "" else "\n\n[최근 진단 로그]\n" + diag.joinToString("\n") { if (it.length > 200) it.take(200) + "…" else it }
                    startRun(a, mgr, d, body, prev.request, prev.scope, null, prev, { alive }, ::input, onInstalled, change)
                }
            }, lp(h = dp(a, 48), top = 14, a = a))
        }
        input()
        d.show()
    }

    // ───────────────────────── 직접 편집 ─────────────────────────

    /**
     * 설치된 AI 확장을 AI 없이 직접 고친다: 설명 · 적용 범위(모든 사이트 / 지정한 사이트) · 제외할 사이트 · 코드.
     * 저장하면 버전이 올라가고, 코드를 바꿨으면 AI 가 만든 것과 같은 검사를 한 번 거친다.
     */
    fun showManualEdit(a: Activity, mgr: ExtensionManager, e: ExtensionManager.Ext, onInstalled: (ExtensionManager.Ext) -> Unit) {
        val prev = mgr.draftOf(e)
        if (prev == null) { AppToast.show(a, "이 확장 프로그램은 직접 편집할 수 없어요"); return }
        val (d, body) = makeSheet(a)
        var alive = true
        d.setOnDismissListener { alive = false }

        // 편집 중인 값 (화면을 다시 그려도 남는다)
        var desc = prev.description
        var allSites = prev.scope.isAll
        var sitesText = if (prev.scope.isAll) "" else ExtensionForge.patternsToText(prev.scope.patterns)
        var exclText = ExtensionForge.patternsToText(prev.scope.excludes)
        val edited = LinkedHashMap<String, String>(prev.files)
        val curVer = ExtensionForge.shownVersion(prev.manifest)
        var pickedVer: String? = null   // 이미 있는 버전으로 바꿀 때 그 버전 (null 이면 지금 판을 고쳐도 버전 번호는 그대로)
        val snaps = (0 until prev.revs.length()).mapNotNull { prev.revs.optJSONObject(it) }
            .filter { it.optJSONObject("snap") != null && it.optString("ver") != curVer }
            .reversed().distinctBy { it.optString("ver") }.take(9)

        var formFn: () -> Unit = { }   // 화면을 다시 그리는 함수 (아래 form 이 정해진다. 로컬 함수는 앞질러 부를 수 없어서)

        fun save() {
            val scope = if (allSites) {
                ExtensionForge.Scope(ExtensionForge.ScopeKind.ALL, listOf("<all_urls>"), ExtensionForge.parseSites(exclText).filter { it != "<all_urls>" })
            } else {
                val s = ExtensionForge.customScope(sitesText)
                if (s == null || s.isAll) { AppToast.show(a, "적용할 사이트 주소를 확인해 주세요"); return }
                ExtensionForge.Scope(ExtensionForge.ScopeKind.CUSTOM, s.patterns, ExtensionForge.parseSites(exclText).filter { it != "<all_urls>" })
            }
            if (exclText.isNotBlank() && ExtensionForge.parseSites(exclText).isEmpty()) { AppToast.show(a, "제외할 사이트 주소를 확인해 주세요"); return }
            val p = Pal(a)
            body.removeAllViews()
            body.addView(label(a, "저장하는 중…", 16f, p.onSurface, true))
            body.addView(ProgressBar(a).apply { indeterminateTintList = ColorStateList.valueOf(TEAL) }, lp(w = dp(a, 28), h = dp(a, 28), top = 16, a = a))
            Thread {
                val r = try { Result.success(ExtensionForge.applyManualEdit(a, prev, desc, scope, edited, pickedVer, { })) } catch (ex: Exception) { Result.failure<ExtensionForge.Draft>(ex) }
                ui.post {
                    if (!alive) return@post
                    val draft = r.getOrNull()
                    if (draft == null) {
                        AppToast.show(a, r.exceptionOrNull()?.message ?: "저장하지 못했어요")
                        formFn(); return@post
                    }
                    fun install() {
                        Thread {
                            val ir = try { Result.success(mgr.installDraft(draft)) } catch (ex: Exception) { Result.failure<ExtensionManager.Ext>(ex) }
                            ui.post {
                                val ext = ir.getOrNull()
                                if (ext == null) {
                                    if (alive) { AppToast.show(a, "저장하지 못했어요: ${ir.exceptionOrNull()?.message ?: "알 수 없는 오류"}"); formFn() }
                                } else {
                                    d.dismiss()
                                    onInstalled(ext)
                                    AppToast.show(a, "'${ext.name}' 을(를) 저장했어요 · v${ExtensionForge.shownVersion(draft.manifest)}")
                                }
                            }
                        }.start()
                    }
                    if (draft.passed) install() else {
                        // 코드에 문제가 있으면 알려 주고, 그래도 저장할지 묻는다
                        ThemedDialogBuilder(a).setTitle("코드에 문제가 있어요")
                            .setMessage(draft.problems.take(3).joinToString("\n") { "· $it" } + "\n\n그래도 저장할까요?")
                            .setPositiveButton("그래도 저장") { _, _ -> install() }
                            .setNegativeButton("돌아가기") { _, _ -> if (alive) formFn() }
                            .setOnCancelListener { if (alive) formFn() }
                            .show()
                    }
                }
            }.start()
        }

        fun editFile(path: String) {
            val p = Pal(a)
            val box = EditText(a).apply {
                setText(edited[path].orEmpty())
                typeface = Typeface.MONOSPACE
                textSize = 12f
                setTextColor(p.onSurface)
                gravity = Gravity.TOP or Gravity.START
                minLines = 12
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                setHorizontallyScrolling(true)
                setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10))
            }
            val scroll = ScrollView(a).apply { addView(box) }
            ThemedDialogBuilder(a).setTitle(path).setView(scroll)
                .setPositiveButton("확인") { _, _ ->
                    edited[path] = box.text?.toString().orEmpty()
                    formFn()
                }
                .setNegativeButton("취소", null).show()
        }

        fun form() {
            body.removeAllViews()
            val p = Pal(a)
            val iconBmp = mgr.iconBitmap(e)

            // 제목줄
            body.addView(LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                if (iconBmp != null) addView(ImageView(a).apply { setImageBitmap(iconBmp) }, LinearLayout.LayoutParams(dp(a, 28), dp(a, 28)))
                else addView(ImageView(a).apply { setImageResource(R.drawable.ic_edit); imageTintList = ColorStateList.valueOf(BLUE) }, LinearLayout.LayoutParams(dp(a, 22), dp(a, 22)))
                addView(label(a, "직접 편집 · ${e.name}", 17f, BLUE_TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 8) })
                addView(ImageView(a).apply {
                    setImageResource(R.drawable.ic_close); imageTintList = ColorStateList.valueOf(p.muted)
                    setPadding(dp(a, 6), dp(a, 6), dp(a, 6), dp(a, 6)); contentDescription = "닫기"; setOnClickListener { d.dismiss() }
                }, LinearLayout.LayoutParams(dp(a, 36), dp(a, 36)))
            })
            body.addView(label(a, "지금 v$curVer · 이전 버전을 고르면 그 내용으로 바뀌어요", 12f, p.muted), lp(top = 2, a = a))

            fun field(hint: String, text: String, lines: Int, uri: Boolean = false) = EditText(a).apply {
                this.hint = hint
                setText(text)
                minLines = lines; maxLines = lines + 4
                gravity = Gravity.TOP or Gravity.START
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or (if (uri) InputType.TYPE_TEXT_VARIATION_URI else 0)
                textSize = 14f; setTextColor(p.onSurface); setHintTextColor(p.muted)
                background = round(Color.TRANSPARENT, 12f, a, p.outline)
                setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
            }

            // 버전: 지금 판을 고치면 번호는 그대로, 이미 있는 버전을 고르면 그 버전의 내용으로 바뀐다
            body.addView(label(a, "버전", 13.5f, p.onSurface, true), lp(top = 16, a = a))
            fun verRow(ver: String?, title: String, sub: String, snap: JSONObject?) {
                val sel = pickedVer == ver
                body.addView(LinearLayout(a).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    background = if (sel) round(ColorUtils.setAlphaComponent(BLUE, 0x1F), 14f, a, BLUE) else round(Color.TRANSPARENT, 14f, a, p.outline)
                    setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10))
                    addView(label(a, title, 14.5f, p.onSurface, true))
                    addView(label(a, sub, 12f, p.muted), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 10) })
                    if (sel) addView(ImageView(a).apply { setImageResource(R.drawable.ic_check); imageTintList = ColorStateList.valueOf(BLUE) }, LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)))
                    isClickable = true
                    setOnClickListener {
                        if (pickedVer == ver) return@setOnClickListener
                        // 그 버전의 설명 · 적용 범위 · 코드를 불러온다 (지금 입력해 둔 것은 바뀐다)
                        val m = snap?.optJSONObject("manifest") ?: prev.manifest
                        val fl = snap?.optJSONObject("snap")?.optJSONObject("files")
                        edited.clear()
                        if (fl != null) fl.keys().forEach { k -> edited[k] = fl.optString(k) } else edited.putAll(prev.files)
                        val sm = snap?.optJSONObject("snap")?.optJSONObject("manifest") ?: prev.manifest
                        desc = sm.optString("description").ifBlank { prev.description }
                        val sc = ExtensionForge.scopeOf(sm)
                        allSites = sc.isAll
                        sitesText = if (sc.isAll) "" else ExtensionForge.patternsToText(sc.patterns)
                        exclText = ExtensionForge.patternsToText(sc.excludes)
                        pickedVer = ver
                        AppToast.show(a, if (ver == null) "지금 버전으로 돌아왔어요" else "v${ExtensionForge.shownVersion(sm)} 의 내용을 불러왔어요 · 고치기를 누르면 이 버전이 돼요")
                        formFn()
                    }
                }, lp(top = 6, a = a))
            }
            verRow(null, "v$curVer (지금)", "고쳐도 버전은 그대로예요", null)
            snaps.forEach { s0 ->
                val sm = s0.optJSONObject("snap")?.optJSONObject("manifest") ?: return@forEach
                verRow(sm.optString("version"), "v${ExtensionForge.shownVersion(sm)}", s0.optString("request").take(24), s0)
            }
            if (snaps.isEmpty()) body.addView(label(a, "이전 버전은 앞으로 고칠 때부터 여기에 쌓여요", 12f, p.muted), lp(top = 4, a = a))

            // 설명
            body.addView(label(a, "설명", 13.5f, p.onSurface, true), lp(top = 16, a = a))
            val descBox = field("이 확장 프로그램이 하는 일", desc, 2)
            body.addView(descBox, lp(top = 6, a = a))

            // 적용 범위
            body.addView(label(a, "적용 범위", 13.5f, p.onSurface, true), lp(top = 16, a = a))
            val rows = ArrayList<Triple<Boolean, LinearLayout, View>>()
            val sitesBox = field("주소를 한 줄에 하나씩 적어 주세요 (예: example.com)", sitesText, 2, uri = true)
            val warn = LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = round(WARN_BG, 12f, a)
                setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
                addView(ImageView(a).apply { setImageResource(R.drawable.ic_warning); imageTintList = ColorStateList.valueOf(WARN_FG) }, LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)))
                addView(label(a, "모든 사이트를 고르면 로그인 화면 등 방문하는 모든 페이지를 읽고 바꿀 수 있어요.", 12.5f, WARN_FG),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 8) })
            }
            fun refresh() {
                rows.forEach { (all, row, dot) ->
                    val sel = all == allSites
                    row.background = if (sel) round(ColorUtils.setAlphaComponent(BLUE, 0x1F), 14f, a, BLUE) else round(Color.TRANSPARENT, 14f, a, p.outline)
                    dot.visibility = if (sel) View.VISIBLE else View.INVISIBLE
                }
                sitesBox.visibility = if (allSites) View.GONE else View.VISIBLE
                warn.visibility = if (allSites) View.VISIBLE else View.GONE
            }
            fun option(all: Boolean, title: String, sub: String) {
                val dot = View(a).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BLUE) } }
                val ring = FrameLayout(a).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(a, 2), BLUE) }
                    addView(dot, FrameLayout.LayoutParams(dp(a, 10), dp(a, 10), Gravity.CENTER))
                }
                val texts = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(label(a, title, 14.5f, p.onSurface, true))
                    addView(label(a, sub, 12f, p.muted))
                }
                val row = LinearLayout(a).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(a, 14), dp(a, 11), dp(a, 14), dp(a, 11))
                    addView(ring, LinearLayout.LayoutParams(dp(a, 20), dp(a, 20)))
                    addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 12) })
                    isClickable = true
                    setOnClickListener { allSites = all; refresh() }
                }
                rows.add(Triple(all, row, dot))
                body.addView(row, lp(top = 8, a = a))
            }
            option(false, "지정한 사이트만", "아래에 적은 사이트에서만 켜져요")
            body.addView(sitesBox, lp(top = 8, a = a))
            option(true, "모든 사이트", "방문하는 모든 페이지에 적용돼요")
            body.addView(warn, lp(top = 8, a = a))

            // 제외할 사이트
            body.addView(label(a, "적용하지 않을 사이트 (선택)", 13.5f, p.onSurface, true), lp(top = 16, a = a))
            val exclBox = field("여기 적은 사이트에서는 켜지지 않아요 (예: bank.example.com)", exclText, 2, uri = true)
            body.addView(exclBox, lp(top = 6, a = a))

            // 코드
            body.addView(label(a, "코드 (${edited.size}개 파일)", 13.5f, p.onSurface, true), lp(top = 16, a = a))
            edited.forEach { (path, text) ->
                val changed = prev.files[path] != text
                body.addView(LinearLayout(a).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    background = round(Color.TRANSPARENT, 12f, a, p.outline)
                    setPadding(dp(a, 14), dp(a, 11), dp(a, 10), dp(a, 11))
                    addView(label(a, path, 14f, p.onSurface, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    addView(label(a, (if (changed) "수정됨 · " else "") + "${text.count { it == '\n' } + 1}줄", 12f, if (changed) TEAL else p.muted))
                    addView(ImageView(a).apply { setImageResource(R.drawable.ic_chevron_right); imageTintList = ColorStateList.valueOf(p.muted) },
                        LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)).apply { marginStart = dp(a, 4) })
                    isClickable = true
                    setOnClickListener {
                        desc = descBox.text?.toString().orEmpty(); sitesText = sitesBox.text?.toString().orEmpty(); exclText = exclBox.text?.toString().orEmpty()
                        editFile(path)
                    }
                }, lp(top = 6, a = a))
            }
            body.addView(label(a, "manifest.json 과 아이콘은 앱이 관리해요. 코드를 바꾸면 저장할 때 문법과 권한을 한 번 검사해요.", 12f, p.muted), lp(top = 8, a = a))

            // 버튼
            body.addView(LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(TextView(a).apply {
                    text = "취소"; textSize = 15f; setTextColor(p.onSurface); gravity = Gravity.CENTER
                    background = round(Color.TRANSPARENT, 100f, a, p.outline)
                    isClickable = true
                    setOnClickListener { d.dismiss() }
                }, LinearLayout.LayoutParams(0, dp(a, 48), 1f).apply { marginEnd = dp(a, 8) })
                addView(TextView(a).apply {
                    text = "고치기"; textSize = 15f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    background = round(TEAL, 100f, a)
                    isClickable = true
                    setOnClickListener {
                        desc = descBox.text?.toString().orEmpty(); sitesText = sitesBox.text?.toString().orEmpty(); exclText = exclBox.text?.toString().orEmpty()
                        save()
                    }
                }, LinearLayout.LayoutParams(0, dp(a, 48), 1.4f))
            }, lp(top = 18, a = a))
            refresh()
        }
        formFn = ::form
        form()
        d.show()
    }

    // ───────────────────────── 1) 입력 ─────────────────────────

    private fun buildInput(
        a: Activity, body: LinearLayout, d: BottomSheetDialog, pageUrl: String?,
        request: String, kind0: ExtensionForge.ScopeKind, custom0: String,
        onMake: (String, ExtensionForge.ScopeKind, String) -> Unit
    ) {
        val p = Pal(a)
        var kind = kind0
        val site = ExtensionForge.siteScope(pageUrl)
        val siteHost = try { android.net.Uri.parse(pageUrl ?: "").host?.removePrefix("www.") } catch (e: Exception) { null }

        // 제목줄: 반짝이 + 제목(파랑) + 닫기
        body.addView(LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(a).apply {
                setImageResource(R.drawable.ic_ai)
                imageTintList = ColorStateList.valueOf(BLUE)
            }, LinearLayout.LayoutParams(dp(a, 22), dp(a, 22)))
            addView(label(a, "AI로 만들기", 17f, BLUE_TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 8) })
            addView(ImageView(a).apply {
                setImageResource(R.drawable.ic_close)
                imageTintList = ColorStateList.valueOf(p.muted)
                setPadding(dp(a, 6), dp(a, 6), dp(a, 6), dp(a, 6))
                contentDescription = "닫기"
                setOnClickListener { d.dismiss() }
            }, LinearLayout.LayoutParams(dp(a, 36), dp(a, 36)))
        })

        val field = EditText(a).apply {
            hint = "이 페이지 광고를 숨기고 글자를 크게 보여줘"
            setText(request)
            minLines = 3
            maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            textSize = 15f
            setTextColor(p.onSurface)
            setHintTextColor(p.muted)
            background = round(Color.TRANSPARENT, 16f, a, p.outline)
            setPadding(dp(a, 14), dp(a, 12), dp(a, 14), dp(a, 12))
        }
        body.addView(field, lp(top = 12, a = a))

        // 추천 칩: 누르면 입력칸에 채운다
        val chips = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val chipsScroll = android.widget.HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false; addView(chips) }
        SUGGESTIONS.forEach { (label, text) ->
            chips.addView(TextView(a).apply {
                this.text = label
                textSize = 12.5f
                setTextColor(TEAL)
                background = round(ColorUtils.setAlphaComponent(TEAL, 0x24), 100f, a)
                setPadding(dp(a, 12), dp(a, 7), dp(a, 12), dp(a, 7))
                setOnClickListener { field.setText(text); field.setSelection(text.length) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(a, 6) })
        }
        body.addView(chipsScroll, lp(top = 10, a = a))

        body.addView(label(a, "어디에 적용할까요", 13.5f, p.onSurface, true), lp(top = 16, a = a))

        // 적용 범위 3택
        val rows = ArrayList<Triple<ExtensionForge.ScopeKind, LinearLayout, View>>()
        val customBox = EditText(a).apply {
            hint = "주소를 한 줄에 하나씩 적어 주세요 (예: example.com)"
            setText(custom0)
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_VARIATION_URI
            textSize = 14f
            setTextColor(p.onSurface)
            setHintTextColor(p.muted)
            background = round(Color.TRANSPARENT, 12f, a, p.outline)
            setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
        }

        fun refreshRows() {
            rows.forEach { (k, row, dot) ->
                val sel = k == kind
                row.background = if (sel) round(ColorUtils.setAlphaComponent(BLUE, 0x1F), 14f, a, BLUE)
                else round(Color.TRANSPARENT, 14f, a, p.outline)
                dot.visibility = if (sel) View.VISIBLE else View.INVISIBLE
            }
            customBox.visibility = if (kind == ExtensionForge.ScopeKind.CUSTOM) View.VISIBLE else View.GONE
        }

        fun option(k: ExtensionForge.ScopeKind, title: String, sub: String, enabled: Boolean = true) {
            val dot = View(a).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BLUE) } }
            val ring = FrameLayout(a).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(a, 2), BLUE) }
                addView(dot, FrameLayout.LayoutParams(dp(a, 10), dp(a, 10), Gravity.CENTER))
            }
            val texts = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                addView(label(a, title, 14.5f, p.onSurface, true))
                addView(label(a, sub, 12f, p.muted))
            }
            val row = LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(a, 14), dp(a, 11), dp(a, 14), dp(a, 11))
                addView(ring, LinearLayout.LayoutParams(dp(a, 20), dp(a, 20)))
                addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 12) })
                alpha = if (enabled) 1f else 0.45f
                isClickable = enabled
                if (enabled) setOnClickListener { kind = k; refreshRows() }
            }
            rows.add(Triple(k, row, dot))
            body.addView(row, lp(top = 8, a = a))
        }
        option(ExtensionForge.ScopeKind.THIS_SITE, "이 사이트만", if (site != null && siteHost != null) siteHost else "지금 보는 탭에서는 쓸 수 없어요", site != null)
        option(ExtensionForge.ScopeKind.ALL, "모든 사이트", "방문하는 모든 페이지에 적용돼요")
        option(ExtensionForge.ScopeKind.CUSTOM, "직접 입력", "주소를 여러 개 넣을 수 있어요")
        body.addView(customBox, lp(top = 8, a = a))

        body.addView(LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(WARN_BG, 12f, a)
            setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
            addView(ImageView(a).apply { setImageResource(R.drawable.ic_warning); imageTintList = ColorStateList.valueOf(WARN_FG) }, LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)))
            addView(label(a, "모든 사이트를 고르면 로그인 화면 등 방문하는 모든 페이지를 읽고 바꿀 수 있어요.", 12.5f, WARN_FG),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 8) })
        }, lp(top = 12, a = a))

        body.addView(TextView(a).apply {
            text = "만들기"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = round(TEAL, 100f, a)
            isClickable = true
            setOnClickListener { onMake(field.text?.toString().orEmpty().trim(), kind, customBox.text?.toString().orEmpty()) }
        }, lp(h = dp(a, 48), top = 14, a = a))

        refreshRows()
    }

    // ───────────────────────── 2) 만드는 중 ─────────────────────────

    private fun startRun(
        a: Activity, mgr: ExtensionManager, d: BottomSheetDialog, body: LinearLayout,
        request: String, scope: ExtensionForge.Scope, pageUrl: String?, previous: ExtensionForge.Draft?,
        alive: () -> Boolean, backToInput: () -> Unit, onInstalled: (ExtensionManager.Ext) -> Unit,
        feedback: String? = null
    ) {
        val p = Pal(a)
        body.removeAllViews()
        body.addView(label(a, "확장 프로그램 만드는 중…", 16f, p.onSurface, true))

        val names = listOf("코드와 아이콘 작성", "문법 · 권한 · 아이콘 검사", "시험 실행", "미리보기 준비")
        val marks = ArrayList<FrameLayout>()
        val details = ArrayList<TextView>()
        val titles = ArrayList<TextView>()
        names.forEachIndexed { i, n ->
            val mark = FrameLayout(a)
            val t = label(a, n, 14.5f, p.onSurface)
            val det = label(a, if (i == 0) "4 Hydrogen" else "", 12f, p.muted)
            body.addView(LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(mark, LinearLayout.LayoutParams(dp(a, 22), dp(a, 22)))
                addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 12) })
                addView(det)
            }, lp(top = if (i == 0) 14 else 12, a = a))
            marks.add(mark); details.add(det); titles.add(t)
        }
        val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 8
            progressTintList = ColorStateList.valueOf(TEAL)
            progressBackgroundTintList = ColorStateList.valueOf(ColorUtils.setAlphaComponent(p.outline, 0x55))
        }
        body.addView(bar, lp(h = dp(a, 4), top = 16, a = a))

        // 0 = 기다림, 1 = 하는 중, 2 = 끝
        fun state(i: Int, s: Int) {
            val m = marks[i]
            m.removeAllViews()
            when (s) {
                2 -> m.addView(ImageView(a).apply { setImageResource(R.drawable.ic_check_bold); imageTintList = ColorStateList.valueOf(TEAL) }, FrameLayout.LayoutParams(dp(a, 20), dp(a, 20), Gravity.CENTER))
                1 -> m.addView(ProgressBar(a).apply { indeterminateTintList = ColorStateList.valueOf(TEAL) }, FrameLayout.LayoutParams(dp(a, 20), dp(a, 20), Gravity.CENTER))
                else -> m.addView(View(a).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(a, 2), p.outline) } }, FrameLayout.LayoutParams(dp(a, 18), dp(a, 18), Gravity.CENTER))
            }
            titles[i].setTypeface(null, if (s == 1) Typeface.BOLD else Typeface.NORMAL)
        }
        state(0, 1); state(1, 0); state(2, 0); state(3, 0)

        Thread {
            val result: Result<ExtensionForge.Draft> = try {
                Result.success(ExtensionForge.generate(a, request, scope, pageUrl, { step ->
                    ui.post {
                        if (!alive()) return@post
                        when {
                            step == "write" -> { state(0, 1); bar.progress = 15 }
                            step == "check" -> { state(0, 2); state(1, 1); state(2, 0); details[2].text = ""; bar.progress = 40 }
                            step == "run" -> { state(0, 2); state(1, 2); state(2, 1); details[2].text = ""; bar.progress = 65 }
                            step.startsWith("fix:") -> { state(0, 2); state(1, 2); state(2, 1); details[2].text = "오류 고치는 중 ${step.removePrefix("fix:")}/${ExtensionForge.MAX_FIX}"; bar.progress = 50 }
                        }
                    }
                }, previous, feedback))
            } catch (e: Exception) {
                Result.failure(e)
            }
            ui.post {
                if (!alive()) return@post
                val draft = result.getOrNull()
                if (draft == null) {
                    AppToast.show(a, result.exceptionOrNull()?.message ?: "확장 프로그램을 만들지 못했어요")
                    backToInput()
                    return@post
                }
                state(1, 2); state(2, 2); state(3, 2); bar.progress = 100
                ui.postDelayed({
                    if (!alive()) return@postDelayed
                    body.removeAllViews()
                    body.addView(
                        previewCard(a, draft,
                            onApply = { applyDraft(a, mgr, d, draft, onInstalled) },
                            onRedo = { startRun(a, mgr, d, body, request, scope, pageUrl, draft, alive, backToInput, onInstalled, feedback) })
                    )
                }, 350)
            }
        }.start()
    }

    private fun applyDraft(a: Activity, mgr: ExtensionManager, d: BottomSheetDialog, draft: ExtensionForge.Draft, onInstalled: (ExtensionManager.Ext) -> Unit) {
        Thread {
            val r = try { Result.success(mgr.installDraft(draft)) } catch (e: Exception) { Result.failure<ExtensionManager.Ext>(e) }
            ui.post {
                val ext = r.getOrNull()
                if (ext == null) {
                    AppToast.show(a, "적용하지 못했어요: ${r.exceptionOrNull()?.message ?: "알 수 없는 오류"}")
                } else {
                    d.dismiss()
                    onInstalled(ext)
                    AppToast.show(a, "'${ext.name}' 을(를) 적용했어요")
                }
            }
        }.start()
    }

    // ───────────────────────── 3) 미리보기 카드 ─────────────────────────

    /** 만든 확장 프로그램을 보여 주는 카드. 사용자가 '적용'을 누르기 전에는 설치하지 않는다 */
    fun previewCard(a: Activity, d: ExtensionForge.Draft, onApply: () -> Unit, onRedo: () -> Unit): View {
        val p = Pal(a)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }

        // 머리: 아이콘 타일 + 이름 + "AI가 만들었어요 · v" + d.manifest.optString("version").substringBefore('.').ifBlank { "1" }
        root.addView(LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            val iconBmp = d.icons[ExtensionForge.ICON_128]?.let { b -> try { BitmapFactory.decodeByteArray(b, 0, b.size) } catch (e: Exception) { null } }
            addView(FrameLayout(a).apply {
                if (iconBmp != null) {
                    addView(ImageView(a).apply {
                        setImageBitmap(iconBmp)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        contentDescription = "확장 프로그램 아이콘"
                    }, FrameLayout.LayoutParams(dp(a, 48), dp(a, 48), Gravity.CENTER))
                } else {
                    background = round(ColorUtils.setAlphaComponent(BLUE, 0x26), 14f, a)
                    addView(ImageView(a).apply { setImageResource(R.drawable.ic_extension); imageTintList = ColorStateList.valueOf(BLUE_TEXT) },
                        FrameLayout.LayoutParams(dp(a, 26), dp(a, 26), Gravity.CENTER))
                }
            }, LinearLayout.LayoutParams(dp(a, 48), dp(a, 48)))
            addView(LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                addView(label(a, d.name, 17f, p.onSurface, true))
                addView(label(a, "AI가 만들었어요 · v" + ExtensionForge.shownVersion(d.manifest), 12.5f, p.muted))
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 12) })
        })
        if (d.description.isNotBlank()) root.addView(label(a, d.description, 14f, p.onSurface), lp(top = 12, a = a))

        // 적용되는 사이트
        root.addView(label(a, "적용되는 사이트", 12f, p.muted), lp(top = 14, a = a))
        val sites = android.widget.HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false }
        val siteRow = LinearLayout(a)
        sites.addView(siteRow)
        fun chip(text: String, fg: Int, bg: Int, icon: Int? = null): View = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(bg, 100f, a)
            setPadding(dp(a, 10), dp(a, 5), dp(a, 12), dp(a, 5))
            if (icon != null) addView(ImageView(a).apply { setImageResource(icon); imageTintList = ColorStateList.valueOf(fg) }, LinearLayout.LayoutParams(dp(a, 15), dp(a, 15)).apply { marginEnd = dp(a, 5) })
            else setPadding(dp(a, 12), dp(a, 5), dp(a, 12), dp(a, 5))
            addView(label(a, text, 12.5f, fg))
        }
        if (d.scope.isAll) {
            siteRow.addView(chip("모든 사이트", WARN_FG, WARN_BG, R.drawable.ic_warning), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(a, 6) })
        } else {
            val shown = d.scope.patterns.map { it.removePrefix("*://").removePrefix("*.").removeSuffix("/*") }.distinct().take(4)
            shown.forEach { siteRow.addView(chip(it, p.onSurface, ColorUtils.setAlphaComponent(p.outline, 0x40)), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(a, 6) }) }
        }
        root.addView(sites, lp(top = 6, a = a))
        if (d.scope.isAll) {
            root.addView(LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = round(WARN_BG, 12f, a)
                setPadding(dp(a, 12), dp(a, 9), dp(a, 12), dp(a, 9))
                addView(ImageView(a).apply { setImageResource(R.drawable.ic_warning); imageTintList = ColorStateList.valueOf(WARN_FG) }, LinearLayout.LayoutParams(dp(a, 17), dp(a, 17)))
                addView(label(a, "방문하는 모든 페이지를 읽고 바꿀 수 있어요. 코드를 확인한 뒤 적용하세요.", 12.5f, WARN_FG),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 8) })
            }, lp(top = 10, a = a))
        }

        // 쓰는 기능
        if (d.features.isNotEmpty()) {
            root.addView(label(a, "쓰는 기능", 12f, p.muted), lp(top = 14, a = a))
            val fs = android.widget.HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false }
            val fr = LinearLayout(a)
            fs.addView(fr)
            d.features.forEach { fr.addView(chip(it, TEAL, ColorUtils.setAlphaComponent(TEAL, 0x24)), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(a, 6) }) }
            root.addView(fs, lp(top = 6, a = a))
        }

        // 고친 내용: 모델이 적은 이번에 바꾼 점 + 파일별 달라진 줄 수 (AI로 고친 결과일 때만)
        val ps = d.prevSource
        if (ps != null) {
            val oldFiles = LinkedHashMap<String, String>()
            ps.optJSONObject("files")?.let { fo -> fo.keys().forEach { k -> oldFiles[k] = fo.optString(k) } }
            val fc = ExtensionForge.fileChanges(oldFiles, d.files)
            val from = ps.optString("ver").ifBlank { ps.optInt("rev", 1).toString() }
            root.addView(label(a, "고친 내용 · v$from → v${ExtensionForge.shownVersion(d.manifest)}", 12f, p.muted), lp(top = 14, a = a))
            if (d.changes.isEmpty() && fc.isEmpty()) root.addView(label(a, "· 코드는 그대로예요", 13.5f, p.onSurface), lp(top = 3, a = a))
            d.changes.forEach { root.addView(label(a, "· $it", 13.5f, p.onSurface), lp(top = 3, a = a)) }
            if (fc.isNotEmpty()) root.addView(label(a, fc.joinToString("  ·  "), 12f, p.muted), lp(top = 4, a = a))
        }

        // 코드 요약: 모델이 적은 한 줄들 + 파일별 줄 수
        val lines = d.summary
        val fileInfo = d.files.entries.joinToString(" · ") { (path, text) -> "$path ${text.count { it == '\n' } + 1}줄" }
        if (lines.isNotEmpty() || fileInfo.isNotEmpty()) {
            root.addView(label(a, "코드 요약", 12f, p.muted), lp(top = 14, a = a))
            lines.forEach { root.addView(label(a, "· $it", 13.5f, p.onSurface), lp(top = 3, a = a)) }
            if (fileInfo.isNotEmpty()) root.addView(label(a, fileInfo, 12f, p.muted), lp(top = 4, a = a))
        }

        // 검사 결과
        if (d.passed) {
            root.addView(LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = round(ColorUtils.setAlphaComponent(TEAL, 0x24), 12f, a)
                setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
                addView(ImageView(a).apply { setImageResource(R.drawable.ic_shield_check_filled); imageTintList = ColorStateList.valueOf(TEAL) }, LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)))
                addView(label(a, "검사 통과 · 시작 오류 없음", 13f, TEAL), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 8) })
            }, lp(top = 14, a = a))
        } else {
            root.addView(LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                background = round(WARN_BG, 12f, a)
                setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
                addView(label(a, "일부 기능이 동작하지 않을 수 있어요", 13f, WARN_FG, true))
                d.problems.take(3).forEach { addView(label(a, "· $it", 12f, WARN_FG)) }
            }, lp(top = 14, a = a))
        }

        // 코드 보기
        root.addView(LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(a, 6), 0, dp(a, 6))
            addView(ImageView(a).apply { setImageResource(R.drawable.ic_extension); imageTintList = ColorStateList.valueOf(BLUE_TEXT) }, LinearLayout.LayoutParams(dp(a, 16), dp(a, 16)))
            addView(label(a, "코드 보기 (${d.files.size + 1}개 파일)", 13.5f, BLUE_TEXT), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(a, 6) })
            isClickable = true
            setOnClickListener { showCode(a, d) }
        }, lp(top = 8, a = a))

        // 버튼: 다시 만들기 / 적용 (진한 건 '적용' 하나)
        root.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(TextView(a).apply {
                text = "다시 만들기"; textSize = 15f; setTextColor(p.onSurface); gravity = Gravity.CENTER
                background = round(Color.TRANSPARENT, 100f, a, p.outline)
                isClickable = true
                setOnClickListener { onRedo() }
            }, LinearLayout.LayoutParams(0, dp(a, 48), 1f).apply { marginEnd = dp(a, 8) })
            addView(TextView(a).apply {
                text = "적용"; textSize = 15f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = round(TEAL, 100f, a)
                isClickable = true
                setOnClickListener { isEnabled = false; onApply() }
            }, LinearLayout.LayoutParams(0, dp(a, 48), 1.4f))
        }, lp(top = 8, a = a))
        return root
    }

    private fun showCode(a: Activity, d: ExtensionForge.Draft) {
        val p = Pal(a)
        val sb = StringBuilder()
        sb.append("── manifest.json ──\n").append(d.manifest.toString(2)).append("\n")
        d.files.forEach { (path, text) -> sb.append("\n── ").append(path).append(" ──\n").append(text).append("\n") }
        val tv = TextView(a).apply {
            text = sb.toString()
            typeface = Typeface.MONOSPACE
            textSize = 11.5f
            setTextColor(p.onSurface)
            setTextIsSelectable(true)
            setPadding(dp(a, 20), dp(a, 8), dp(a, 20), dp(a, 8))
        }
        val scroll = ScrollView(a).apply { addView(tv) }
        ThemedDialogBuilder(a).setTitle("코드 (${d.files.size + 1}개 파일)").setView(scroll).setPositiveButton("닫기", null).show()
    }

    // ───────────────────────── AI 어시스턴트가 만들 때 ─────────────────────────

    /** 어시스턴트의 create_extension 도구가 쓴다. 미리보기 카드를 띄우고 사용자의 선택을 기다린다 (화면 스레드가 아닌 곳에서 부른다) */
    fun previewAndWait(a: Activity, draft: ExtensionForge.Draft): String {
        val latch = java.util.concurrent.CountDownLatch(1)
        val box = arrayOf("cancel")
        ui.post {
            if (a.isFinishing || a.isDestroyed) { latch.countDown(); return@post }
            val (d, body) = makeSheet(a)
            d.setOnDismissListener { latch.countDown() }
            body.addView(previewCard(a, draft,
                onApply = { box[0] = "apply"; d.dismiss() },
                onRedo = { box[0] = "redo"; d.dismiss() }))
            d.show()
        }
        if (!latch.await(5, java.util.concurrent.TimeUnit.MINUTES)) return "timeout"
        return box[0]
    }
}
