package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 에이전트: 삭제 도구.
 * - 읽기(자동): list_downloads (받은 파일 목록)
 * - 위험(실행할 때마다 확인): delete_bookmarks · delete_history · delete_downloads
 *
 * 북마크 · 방문 기록은 지우기 직전 상태를 붙들어 둬서 「되돌리기」로 되살릴 수 있다.
 * 받은 파일은 기기에서 완전히 지워지므로 되돌릴 수 없다 (그래서 확인 카드에 파일 이름을 보여 준다).
 * 대상은 search_bookmarks · search_history · list_downloads 가 돌려준 주소 · id 로만 고른다.
 */
object AgentDeleteTools {
    const val MAX_BOOKMARKS = 30
    const val MAX_HISTORY = 50
    const val MAX_DOWNLOADS = 20

    fun build(): List<AgentTool> = listOf(listDownloads(), deleteBookmarks(), deleteHistory(), deleteDownloads())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    private fun stamp(t: Long): String =
        if (t <= 0L) "" else SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date(t))

    /** 글 목록 인자를 읽는다. 비어 있는 것은 빼고, 같은 것은 하나로 */
    private fun strsOf(a: JSONObject, key: String): List<String> {
        val arr = a.optJSONArray(key) ?: return emptyList()
        val out = LinkedHashSet<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty()) out.add(s)
        }
        return out.toList()
    }

    private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

    /** 확인 카드에 보여 줄 이름 목록: 앞의 몇 개 + 나머지 개수 */
    private fun namesLabel(names: List<String>, total: Int): String {
        val shown = names.take(3).joinToString(", ") { "「${short(it, 22)}」" }
        return if (total > 3) "$shown 외 ${total - 3}개" else shown
    }

    private fun removedResult(o: AgentOutcome): AgentResult =
        if (!o.ok) AgentResult.fail(o.message)
        else AgentResult.ok(JSONObject().put("message", o.message).put("removed", o.number), o.message)

    // ───────────────────────── 읽기 ─────────────────────────

    private fun listDownloads() = AgentTool(
        name = "list_downloads",
        description = "기기에 받아 둔 파일(다운로드 목록)을 최근 순으로 돌려줍니다. 파일마다 id · 이름 · 크기 · 받은 시각이 나오고, id 는 delete_downloads 에 씁니다. " +
            "query 를 주면 이름에 그 글이 든 것만 찾습니다. 지금 받는 중인 파일은 나오지 않습니다.",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "query" to AgentSchema.str("이름에 들어 있는 말 (비워도 됨)"),
                "limit" to AgentSchema.int("가져올 개수 (기본 10, 최대 30)")
            )
        ),
        doing = { a ->
            val q = a.optString("query").trim()
            if (q.isEmpty()) "받은 파일 보는 중…" else "받은 파일 찾는 중: ${short(q, 20)}…"
        },
        run = { a, ctx ->
            val limit = a.optInt("limit", 10).coerceIn(1, 30)
            val list = ctx.host.downloads(a.optString("query").trim(), limit)
            val arr = JSONArray()
            for (d in list) {
                arr.put(
                    JSONObject().put("id", d.key).put("name", d.name.take(120))
                        .put("size", ListUi.fmtSize(d.size.coerceAtLeast(0L))).put("downloaded", stamp(d.time))
                )
            }
            // 파일 이름은 웹사이트가 정한 글이라 자료로만 다룬다
            AgentResult.ok(JSONObject().put("count", list.size).put("files", arr), "받은 파일 ${list.size}개를 찾았어요", untrusted = true)
        }
    )

    // ───────────────────────── 위험: 삭제 ─────────────────────────

    private fun deleteBookmarks() = AgentTool(
        name = "delete_bookmarks",
        description = "북마크를 지웁니다. urls 에 search_bookmarks 가 돌려준 북마크 주소(url)를 그대로 줍니다 (한 번에 최대 ${MAX_BOOKMARKS}개). " +
            "사용자가 북마크를 지우라고 분명히 시켰을 때만 쓰고, 먼저 search_bookmarks 로 지울 북마크를 정확히 확인하세요. 실행할 때마다 사용자의 확인을 받습니다.",
        risk = AgentRisk.DANGER,
        askDetail = "지운 뒤에도 「되돌리기」로 다시 살릴 수 있어요. 이 작업은 실행할 때마다 물어봐요.",
        params = AgentSchema.obj(
            listOf("urls" to AgentSchema.strList("지울 북마크 주소들 (search_bookmarks 의 url)")),
            listOf("urls")
        ),
        doing = { a -> "북마크 ${strsOf(a, "urls").size}개 지우는 중…" },
        run = { a, ctx ->
            val urls = strsOf(a, "urls")
            when {
                urls.isEmpty() -> AgentResult.fail("urls 가 비어 있어요 (search_bookmarks 의 url 을 주세요)")
                urls.size > MAX_BOOKMARKS -> AgentResult.fail("한 번에 ${MAX_BOOKMARKS}개까지만 지울 수 있어요. 나눠서 다시 불러 주세요")
                else -> removedResult(ctx.host.deleteBookmarks(urls))
            }
        },
        undoPlan = { _, ctx ->
            val snap = ctx.host.bookmarkSnapshot()
            if (snap == null) null else {
                { r ->
                    if (r.data.optInt("removed", 0) <= 0) null
                    else AgentUndo("지운 북마크 ${r.data.optInt("removed")}개 되살리기") { h -> h.restoreBookmarkSnapshot(snap) }
                }
            }
        },
        ask = { a, ctx ->
            val urls = strsOf(a, "urls")
            val all = ctx.host.bookmarks("", Int.MAX_VALUE)
            val names = urls.map { u -> all.firstOrNull { sameUrl(it.url, u) }?.title?.ifBlank { null } ?: u }
            "북마크 ${urls.size}개 삭제: " + namesLabel(names, urls.size)
        }
    )

    private fun deleteHistory() = AgentTool(
        name = "delete_history",
        description = "방문 기록을 지웁니다. urls 에 search_history 가 돌려준 주소(url)를 주면 그 기록만 지우고(한 번에 최대 ${MAX_HISTORY}개), " +
            "clear_all 을 true 로 주면 방문 기록을 전부 지웁니다. 사용자가 기록을 지우라고 분명히 시켰을 때만 쓰고, 일부만 지울 때는 먼저 search_history 로 확인하세요. " +
            "실행할 때마다 사용자의 확인을 받습니다.",
        risk = AgentRisk.DANGER,
        askDetail = "지운 뒤에도 「되돌리기」로 다시 살릴 수 있어요. 이 작업은 실행할 때마다 물어봐요.",
        params = AgentSchema.obj(
            listOf(
                "urls" to AgentSchema.strList("지울 기록의 주소들 (search_history 의 url)"),
                "clear_all" to AgentSchema.flag("true 면 방문 기록 전체 삭제 (기본 false)")
            )
        ),
        doing = { a -> if (a.optBoolean("clear_all", false)) "방문 기록 전체 지우는 중…" else "방문 기록 ${strsOf(a, "urls").size}건 지우는 중…" },
        run = { a, ctx ->
            val all = a.optBoolean("clear_all", false)
            val urls = strsOf(a, "urls")
            when {
                !all && urls.isEmpty() -> AgentResult.fail("지울 기록의 주소(urls)를 주거나 clear_all 을 true 로 주세요")
                !all && urls.size > MAX_HISTORY -> AgentResult.fail("한 번에 ${MAX_HISTORY}건까지만 지울 수 있어요. 나눠서 다시 불러 주세요")
                else -> removedResult(ctx.host.deleteHistory(urls, all))
            }
        },
        undoPlan = { _, ctx ->
            val snap = ctx.host.historySnapshot()
            if (snap == null) null else {
                { r ->
                    if (r.data.optInt("removed", 0) <= 0) null
                    else AgentUndo("지운 방문 기록 ${r.data.optInt("removed")}건 되살리기") { h -> h.restoreHistorySnapshot(snap) }
                }
            }
        },
        ask = { a, ctx ->
            if (a.optBoolean("clear_all", false)) {
                "방문 기록 전체 삭제 (" + ctx.host.history("", Int.MAX_VALUE).size + "건)"
            } else {
                val urls = strsOf(a, "urls")
                val all = ctx.host.history("", Int.MAX_VALUE)
                val names = urls.map { u -> all.firstOrNull { it.url == u }?.title?.ifBlank { null } ?: u }
                "방문 기록 ${urls.size}건 삭제: " + namesLabel(names, urls.size)
            }
        }
    )

    private fun deleteDownloads() = AgentTool(
        name = "delete_downloads",
        description = "받아 둔 파일을 기기에서 완전히 지웁니다. ids 에 list_downloads 가 돌려준 파일 id 를 줍니다 (한 번에 최대 ${MAX_DOWNLOADS}개). " +
            "지운 파일은 되돌릴 수 없습니다. 사용자가 파일을 지우라고 분명히 시켰을 때만 쓰고, 먼저 list_downloads 로 지울 파일을 정확히 확인하세요. 실행할 때마다 사용자의 확인을 받습니다.",
        risk = AgentRisk.DANGER,
        askDetail = "파일이 기기에서 완전히 지워지고 되돌릴 수 없어요. 이 작업은 실행할 때마다 물어봐요.",
        params = AgentSchema.obj(
            listOf("ids" to AgentSchema.strList("지울 파일 id들 (list_downloads 의 id)")),
            listOf("ids")
        ),
        doing = { a -> "받은 파일 ${strsOf(a, "ids").size}개 지우는 중…" },
        run = { a, ctx ->
            val ids = strsOf(a, "ids")
            when {
                ids.isEmpty() -> AgentResult.fail("ids 가 비어 있어요 (list_downloads 의 id 를 주세요)")
                ids.size > MAX_DOWNLOADS -> AgentResult.fail("한 번에 ${MAX_DOWNLOADS}개까지만 지울 수 있어요. 나눠서 다시 불러 주세요")
                else -> removedResult(ctx.host.deleteDownloads(ids))
            }
        },
        ask = { a, ctx ->
            val ids = strsOf(a, "ids")
            val all = ctx.host.downloads("", Int.MAX_VALUE)
            val found = ids.mapNotNull { id -> all.firstOrNull { it.key == id } }
            val size = found.sumOf { it.size.coerceAtLeast(0L) }
            val sizeText = if (size > 0L) " (" + ListUi.fmtSize(size) + ")" else ""
            "받은 파일 ${ids.size}개 삭제$sizeText: " + namesLabel(found.map { it.name }.ifEmpty { ids }, ids.size)
        }
    )
}
