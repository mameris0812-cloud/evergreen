package com.example.evergreen

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.text.InputType
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * AI 창에 뜨는 에이전트 진행 카드. AI 가 앱 기능(도구)을 쓰는 동안 "열린 탭 확인하는 중…" 같은 줄이 하나씩 쌓이고,
 * 줄마다 돌아가는 표시 → ✓(성공) / ✕(실패) 로 바뀐다. 머리글의 「중지」 로 바로 멈출 수 있다.
 */
class AgentProgressCard(
    context: Context,
    private val fg: Int,
    private val fgDim: Int,
    private val accent: Int,
    private val bad: Int,
    private val fill: Int,
    private val line: Int,
    private val onStop: () -> Unit
) : LinearLayout(context) {

    private class Row(val spinner: ProgressBar, val mark: TextView, val text: TextView)

    private val rows = LinkedHashMap<Int, Row>()

    /** 자율 모드 계획의 한 줄 */
    private class PlanRow(val mark: TextView, val text: TextView)

    private val planRows = ArrayList<PlanRow>()
    private val planBox = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        visibility = View.GONE
    }
    private var undoBtn: TextView? = null
    private var settingsBox: LinearLayout? = null
    private val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val status = TextView(context)
    private val stop = TextView(context)
    private var finished = false
    private var failedSteps = 0

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), line)
        }

        status.apply {
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fgDim)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            text = "작업 준비 중…"
        }
        stop.apply {
            text = "중지"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(bad)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), bad)
            }
            contentDescription = "AI 작업 중지"
            setOnClickListener {
                if (finished) return@setOnClickListener
                // 눌렀다는 걸 바로 보여 주고, 실제 중지는 AI 창이 맡는다
                isEnabled = false
                alpha = 0.5f
                status.text = "중지하는 중…"
                onStop()
            }
            Motion.pressable(this, 0.93f)
        }
        val head = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) })
        }
        addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(planBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    /** 자율 모드: 승인된 계획을 단계별 체크 목록으로 보여 준다 (계획이 다시 세워지면 새로 그린다) */
    fun setPlan(steps: List<String>) {
        if (finished) return
        planBox.removeAllViews()
        planRows.clear()
        planBox.visibility = View.VISIBLE
        planBox.addView(TextView(context).apply {
            text = "계획"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fgDim)
        })
        steps.forEachIndexed { i, s ->
            val mark = TextView(context).apply {
                text = "○"
                textSize = 13f
                setTextColor(fgDim)
                gravity = Gravity.CENTER
            }
            val tv = TextView(context).apply {
                text = "${i + 1}. $s"
                textSize = 13f
                setTextColor(fg)
                setLineSpacing(0f, 1.1f)
            }
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(mark, LinearLayout.LayoutParams(dp(20), ViewGroup.LayoutParams.WRAP_CONTENT))
                addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
            }
            planBox.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
            planRows.add(PlanRow(mark, tv))
        }
    }

    /** 계획의 [index] 번(1부터) 단계 상태: done → ✓, failed → ✕, skipped → – */
    fun markPlan(index: Int, status: String) {
        val r = planRows.getOrNull(index - 1) ?: return
        when (status) {
            "done" -> {
                r.mark.text = "✓"
                r.mark.setTextColor(accent)
            }
            "failed" -> {
                r.mark.text = "✕"
                r.mark.setTextColor(bad)
                r.text.setTextColor(bad)
            }
            else -> {
                r.mark.text = "–"
                r.mark.setTextColor(fgDim)
                r.text.setTextColor(fgDim)
            }
        }
    }

    /**
     * 에이전트가 바꾼 설정을 토글 · 세 칸 선택 · −/+ 로 보여 준다. 누르면 그 설정만 바로 바뀐다 ([onChange]).
     * [values] 는 이름 → 지금 값 (ad_block · bookmark_bar: on/off, web_dark_mode: off/device/always, text_zoom: 50~200)
     */
    fun showSettingControls(values: Map<String, String>, onChange: (name: String, value: String) -> Unit) {
        if (settingsBox != null || values.isEmpty()) return
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        box.addView(View(context).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(match, dp(1)).apply { topMargin = dp(10) })
        var added = 0
        for ((name, v0) in values) {
            val def = AgentSettings.find(name) ?: continue
            val label = def.label
            val control: View = when {
                name == "web_dark_mode" -> settingSegment(listOf("off" to "끔", "device" to "기기", "always" to "항상"), v0) { onChange(name, it) }
                name == "text_zoom" -> settingStepper(v0.toIntOrNull() ?: 100) { onChange(name, it.toString()) }
                // 켜고 끄는 설정은 모두 스위치로 (광고 차단 · 북마크바 · 번역 · 보안 …)
                def.kind == AgentSettings.Kind.BOOL -> settingSwitch(v0 == "on") { on -> onChange(name, if (on) "on" else "off") }
                else -> continue
            }
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(TextView(context).apply {
                    text = label
                    textSize = 13f
                    setTextColor(fg)
                }, LinearLayout.LayoutParams(0, wrap, 1f))
                addView(control, LinearLayout.LayoutParams(wrap, wrap))
            }
            box.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
            added++
        }
        if (added == 0) return
        box.addView(TextView(context).apply {
            text = "누르면 그 설정만 바로 바뀌어요"
            textSize = 11f
            setTextColor(fgDim)
        }, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(6) })
        settingsBox = box
        addView(box, LinearLayout.LayoutParams(match, wrap))
    }

    private fun settingSwitch(on: Boolean, onToggle: (Boolean) -> Unit): View = android.widget.Switch(context).apply {
        isChecked = on
        val checked = intArrayOf(android.R.attr.state_checked)
        thumbTintList = ColorStateList(arrayOf(checked, intArrayOf()), intArrayOf(accent, fgDim))
        trackTintList = ColorStateList(arrayOf(checked, intArrayOf()), intArrayOf((accent and 0x00FFFFFF) or 0x66000000, line))
        contentDescription = "설정 켜고 끄기"
        setOnCheckedChangeListener { _, c -> onToggle(c) }
    }

    private fun settingSegment(options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit): View {
        var sel = current
        val cells = ArrayList<Pair<String, TextView>>()
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadius = dp(15).toFloat()
                setStroke(dp(1), accent)
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        fun paint() {
            for ((key, tv) in cells) {
                val on = key == sel
                tv.setTextColor(if (on) fill else accent)
                tv.background = if (on) GradientDrawable().apply {
                    cornerRadius = dp(13).toFloat()
                    setColor(accent)
                } else null
            }
        }
        for ((key, text) in options) {
            val tv = TextView(context).apply {
                this.text = text
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(4), dp(10), dp(4))
                isClickable = true
                setOnClickListener {
                    if (sel == key) return@setOnClickListener
                    sel = key
                    paint()
                    onPick(key)
                }
            }
            cells.add(key to tv)
            bar.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        paint()
        return bar
    }

    private fun settingStepper(start: Int, onValue: (Int) -> Unit): View {
        var v = start
        val value = TextView(context).apply {
            text = "$v%"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fg)
            gravity = Gravity.CENTER
            minWidth = dp(46)
        }
        fun btn(label: String, delta: Int) = TextView(context).apply {
            text = label
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(1), accent)
            }
            isClickable = true
            contentDescription = if (delta > 0) "글자 크기 키우기" else "글자 크기 줄이기"
            setOnClickListener {
                val n = (v + delta).coerceIn(50, 200)
                if (n == v) return@setOnClickListener
                v = n
                value.text = "$v%"
                onValue(v)
            }
        }
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(btn("−", -10), LinearLayout.LayoutParams(dp(28), dp(28)))
            addView(value, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(btn("+", 10), LinearLayout.LayoutParams(dp(28), dp(28)))
        }
    }

    /** 끝난 뒤 맨 아래에 「되돌리기」 버튼을 단다 ([count] 건을 되돌릴 수 있다). 누르면 [onUndo] 로 알린다 */
    fun showUndo(count: Int, onUndo: () -> Unit) {
        if (undoBtn != null || count <= 0) return
        val b = TextView(context).apply {
            text = "↶ 한 일 되돌리기 ($count)"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), accent)
            }
            isClickable = true
            contentDescription = "에이전트가 한 일 되돌리기"
            setOnClickListener {
                isEnabled = false
                alpha = 0.5f
                text = "되돌리는 중…"
                onUndo()
            }
            Motion.pressable(this, 0.94f)
        }
        undoBtn = b
        addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
            gravity = Gravity.END
        })
    }

    /** 되돌리기가 끝났다: 버튼에 결과를 적고, 못 되돌린 건 이유를 아래에 보여 준다 */
    fun setUndoResult(results: List<Pair<Boolean, String>>) {
        val ok = results.count { it.first }
        undoBtn?.apply {
            text = if (ok == results.size) "↶ ${ok}건 되돌렸어요" else "↶ ${ok}건 되돌림 · ${results.size - ok}건은 그대로예요"
            setTextColor(fgDim)
            background = null
        }
        for ((good, line) in results) {
            if (good) continue
            addView(TextView(context).apply {
                text = "✕ $line"
                textSize = 12f
                setTextColor(bad)
                setLineSpacing(0f, 1.1f)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
    }

    /** 머리글 한 줄 ("생각하는 중… (2/10단계)" 등). 끝난 뒤에는 바뀌지 않는다 */
    fun setStatus(text: String) {
        if (finished) return
        // 중지 버튼을 누른 뒤에는 "중지하는 중…" 을 덮어쓰지 않는다
        if (!stop.isEnabled) return
        status.text = text
    }

    /** 새 줄: 도구 하나를 실행하기 시작했다 */
    fun addStep(id: Int, label: String) {
        if (finished || rows.containsKey(id)) return
        val spinner = ProgressBar(context, null, android.R.attr.progressBarStyleSmall).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(accent)
        }
        val mark = TextView(context).apply {
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        val icon = FrameLayout(context).apply {
            addView(spinner, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER))
            addView(mark, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }
        val tv = TextView(context).apply {
            textSize = 13f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
            text = label
        }
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        }
        body.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        rows[id] = Row(spinner, mark, tv)
    }

    /** 줄 하나가 끝났다: 성공이면 ✓, 실패면 ✕ 와 이유 */
    fun finishStep(id: Int, ok: Boolean, summary: String) {
        val r = rows[id] ?: return
        if (!ok) failedSteps++
        r.spinner.visibility = View.GONE
        r.mark.visibility = View.VISIBLE
        r.mark.text = if (ok) "✓" else "✕"
        r.mark.setTextColor(if (ok) accent else bad)
        if (summary.isNotBlank()) {
            r.text.text = summary
            r.text.setTextColor(if (ok) fg else bad)
        }
    }

    /** 실행이 끝났다: 중지 버튼을 치우고 머리글에 결과를 적는다. 아직 돌던 줄은 멈춘 걸로 바꾼다 */
    fun finish(end: AgentEnd) {
        if (finished) return
        finished = true
        stop.visibility = View.GONE
        for ((_, r) in rows) {
            if (r.spinner.visibility == View.VISIBLE) {
                r.spinner.visibility = View.GONE
                r.mark.visibility = View.VISIBLE
                r.mark.text = "–"
                r.mark.setTextColor(fgDim)
            }
        }
        val (label, color) = when (end) {
            AgentEnd.DONE -> if (failedSteps > 0) "마쳤지만 일부는 못 했어요" to bad else "작업을 마쳤어요" to accent
            AgentEnd.STOPPED -> "중지했어요" to fgDim
            AgentEnd.LIMIT -> "단계 한도에 도달해서 멈췄어요" to bad
            AgentEnd.ERROR -> "오류로 멈췄어요" to bad
        }
        status.text = label
        status.setTextColor(color)
    }
}

/**
 * 에이전트가 읽기가 아닌 일(탭 열기 · 설정 바꾸기 · 다운로드 등)을 하기 전에 AI 창에 뜨는 확인 카드.
 * 「허락」 / 「거절」 중 하나를 누르면 [onAnswer] 로 알리고, 이후 카드를 치우는 일은 부른 쪽이 맡는다.
 * [danger] 면 위험한 작업이라는 표시로 강조색을 쓴다.
 */
class AgentConfirmCard(
    context: Context,
    what: String,
    detail: String,
    danger: Boolean,
    fg: Int,
    private val fgDim: Int,
    accent: Int,
    bad: Int,
    private val fill: Int,
    line: Int,
    private val onAnswer: (Boolean) -> Unit
) : LinearLayout(context) {

    private var answered = false

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun button(label: String, color: Int, filled: Boolean, answer: Boolean) = TextView(context).apply {
        text = label
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setTextColor(if (filled) fill else color)
        setPadding(dp(18), dp(8), dp(18), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            if (filled) setColor(color) else setStroke(dp(1), color)
        }
        isClickable = true
        contentDescription = label
        setOnClickListener {
            if (answered) return@setOnClickListener
            answered = true
            // 두 번 눌러도 한 번만 전달되고, 눌렀다는 걸 바로 보여 준다
            this@AgentConfirmCard.alpha = 0.6f
            onAnswer(answer)
        }
        Motion.pressable(this, 0.94f)
    }

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        val tone = if (danger) bad else accent
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), tone)
        }
        addView(TextView(context).apply {
            text = if (danger) "⚠ 이 작업을 해도 될까요?" else "AI가 앱을 조작하려고 해요"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(tone)
        })
        addView(TextView(context).apply {
            text = what
            textSize = 14f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        if (detail.isNotBlank()) {
            addView(TextView(context).apply {
                text = detail
                textSize = 12f
                setTextColor(fgDim)
                setLineSpacing(0f, 1.1f)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            addView(button("거절", fgDim, filled = false, answer = false))
            addView(button("허락", tone, filled = true, answer = true), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
    }
}

/**
 * 자율 모드에서 에이전트가 막혔을 때 사용자에게 묻는 카드. 선택지 버튼을 누르거나 직접 입력해서 답한다.
 * 「건너뛰기」 는 답하지 않겠다는 뜻이라 [onAnswer] 에 null 을 준다. 한 번 답하면 다시 눌러도 전달되지 않는다.
 */
class AgentAskCard(
    context: Context,
    question: String,
    options: List<String>,
    private val fg: Int,
    private val fgDim: Int,
    private val accent: Int,
    private val fill: Int,
    private val line: Int,
    private val onAnswer: (String?) -> Unit
) : LinearLayout(context) {

    private var answered = false

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun answer(v: String?) {
        if (answered) return
        answered = true
        alpha = 0.6f
        onAnswer(v)
    }

    private fun optionButton(label: String) = TextView(context).apply {
        text = label
        textSize = 13f
        setTextColor(accent)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), accent)
        }
        isClickable = true
        contentDescription = label
        setOnClickListener { answer(label) }
        Motion.pressable(this, 0.97f)
    }

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), accent)
        }
        addView(TextView(context).apply {
            text = "AI가 물어봐요"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
        })
        addView(TextView(context).apply {
            text = question
            textSize = 14f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        for (o in options) {
            addView(optionButton(o), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        val input = EditText(context).apply {
            hint = if (options.isEmpty()) "답을 입력하세요" else "직접 입력"
            textSize = 14f
            setTextColor(fg)
            setHintTextColor(fgDim)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            maxLines = 3
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), line)
            }
        }
        val send = {
            val v = input.text.toString().trim()
            if (v.isNotEmpty()) answer(v)
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else false
        }
        val sendBtn = TextView(context).apply {
            text = "보내기"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fill)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(accent)
            }
            isClickable = true
            contentDescription = "답 보내기"
            setOnClickListener { send() }
            Motion.pressable(this, 0.94f)
        }
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(sendBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        addView(TextView(context).apply {
            text = "건너뛰기"
            textSize = 12f
            setTextColor(fgDim)
            setPadding(dp(4), dp(8), dp(4), dp(2))
            isClickable = true
            contentDescription = "답하지 않고 건너뛰기"
            setOnClickListener { answer(null) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END })
    }
}
