package com.example.evergreen

import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.MaterialColors
import com.google.android.material.progressindicator.LinearProgressIndicator

/**
 * 다운로드하는 동안 창 아래에 떠 있는 앱 자체 진행 카드.
 * 파일 이름 · 퍼센트 · 속도 · 진행 막대와 '취소' 버튼을 보여 주고, 누르면 다운로드 목록이 열린다.
 * 받는 게 모두 끝나면 스스로 사라진다 (완료 안내는 기존 알림이 따로 띄운다).
 * 진행 정보는 빠른 다운로드([DownloadService])의 것이다.
 */
class DownloadProgressCard(
    private val activity: MainActivity,
    private val openList: () -> Unit
) {
    companion object {
        const val TAG = "evergreen_download_card"
        private const val GAP_DP = 8
        /** 진행 카드는 바텀시트 · 대화상자 위에도 보이려고 별도 창에 그린다. 그 창의 카드 뷰 (없으면 null) */
        @Volatile private var windowCard: View? = null
        /** 진행 카드가 떠 있으면, 일반 알림(토스트)이 그 위로 올라가야 하는 높이(px). 없으면 0 */
        fun occupiedHeight(root: ViewGroup): Int {
            val v = root.findViewWithTag<View>(TAG) ?: windowCard ?: return 0
            if (v.parent == null) return 0
            var h = v.height
            if (h <= 0) {
                val w = (v.layoutParams?.width ?: 0).takeIf { it > 0 } ?: root.width
                v.measure(
                    View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                h = v.measuredHeight
            }
            return h + (GAP_DP * root.resources.displayMetrics.density).toInt()
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var card: LinearLayout? = null
    private var title: TextView? = null
    private var info: TextView? = null
    private var bar: LinearProgressIndicator? = null
    private var cancel: TextView? = null
    private var polling = false
    private var startedAt = 0L
    private var sawJob = false
    private var winParams: WindowManager.LayoutParams? = null
    private var wasFocused = true

    private val tick = object : Runnable {
        override fun run() {
            if (!polling) return
            update()
            if (polling) ui.postDelayed(this, 400)
        }
    }

    /** 다운로드를 시작한 직후 부른다. 서비스가 작업을 등록할 때까지 잠깐 '준비 중'으로 보여 준다. */
    fun begin() {
        startedAt = SystemClock.uptimeMillis()
        sawJob = false
        ensureCard()
        render("다운로드 준비 중…", "", -1)
        if (!polling) {
            polling = true
            ui.post(tick)
        }
    }

    fun destroy() {
        polling = false
        ui.removeCallbacks(tick)
        removeCard(false)
    }

    private fun update() {
        // 앱 화면이 초점을 잃으면(대화상자 · 바텀시트가 새로 열림) 그 창이 카드 위로 올라오므로, 카드 창을 다시 띄워 맨 위로 올린다
        val focused = activity.hasWindowFocus()
        if (wasFocused && !focused) raiseWindowCard()
        wasFocused = focused
        val jobs = DownloadService.snapshot()
        if (jobs.isEmpty()) {
            // 등록 전이면 잠깐 기다리고, 한 번이라도 보였다가 비면 다 끝난 것이다
            if (sawJob || SystemClock.uptimeMillis() - startedAt > 6000) finish()
            return
        }
        sawJob = true
        val done = jobs.sumOf { it.downloaded }
        val knownTotal = jobs.all { it.total > 0 }
        val total = if (knownTotal) jobs.sumOf { it.total } else -1L
        val speed = jobs.sumOf { it.speedBps }
        val name = if (jobs.size == 1) jobs[0].name.ifEmpty { "다운로드 중…" } else "${jobs.size}개 다운로드 중"
        val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 100) else -1
        val sizeText = if (total > 0) "${fmt(done)} / ${fmt(total)}" else fmt(done)
        val speedText = if (speed > 0) " · ${fmt(speed)}/s" else ""
        render(name, (if (pct >= 0) "$pct% · " else "") + sizeText + speedText, pct)
    }

    private fun finish() {
        polling = false
        ui.removeCallbacks(tick)
        removeCard(true)
    }

    private fun render(name: String, infoText: String, pct: Int) {
        title?.text = name
        info?.text = infoText
        bar?.let {
            if (pct < 0) {
                if (!it.isIndeterminate) it.isIndeterminate = true
            } else {
                if (it.isIndeterminate) it.isIndeterminate = false
                it.setProgressCompat(pct, true)
            }
        }
    }

    private fun ensureCard() {
        if (card?.parent != null) return
        winParams = null
        val root = activity.window.decorView as? ViewGroup ?: return
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val bg = ThemeColors.get(root, com.google.android.material.R.attr.colorOnSurface, 0xFF303030.toInt())
        val fg = ThemeColors.get(root, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val accent = if (androidx.core.graphics.ColorUtils.calculateLuminance(bg) < 0.5) 0xFF5FDB8A.toInt() else 0xFF1E8E4E.toInt()

        val t = TextView(activity).apply {
            setTextColor(fg); textSize = 14f; maxLines = 1; ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val i = TextView(activity).apply {
            setTextColor((fg and 0x00FFFFFF) or 0xB3000000.toInt()); textSize = 12f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val b = LinearProgressIndicator(activity).apply {
            max = 100
            trackThickness = dp(4)
            trackCornerRadius = dp(2)
            setIndicatorColor(accent)
            trackColor = (fg and 0x00FFFFFF) or 0x33000000
            isIndeterminate = true
        }
        val texts = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(t)
            addView(i)
        }
        val c = TextView(activity).apply {
            text = "취소"
            setTextColor(accent); textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener {
                DownloadService.snapshot().forEach { DownloadService.cancelJob(it.id) }
                finish()
            }
        }
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(c)
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(8), dp(12))
            background = GradientDrawable().apply {
                setColor((bg and 0x00FFFFFF) or 0xF0000000.toInt())
                cornerRadius = dp(22).toFloat()
            }
            AppToast.raiseToTop(this, dp(AppToast.CARD_Z_DP))
            addView(row)
            addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6); marginEnd = dp(10)
            })
            // 카드를 누르면 다운로드 목록 (취소 버튼은 자기 클릭을 먼저 받는다)
            setOnClickListener { openList() }
        }
        title = t; info = i; bar = b; cancel = c; card = box

        val availW = if (root.width > 0) root.width else activity.resources.displayMetrics.widthPixels
        val bottomInset = ViewCompat.getRootWindowInsets(root)
            ?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val lift = activity.toastLift()
        // 진행 카드가 아래 자리(알림이 뜨던 기본 자리)를 쓰고, 일반 알림은 그 위로 올라간다
        val base = if (lift > 0) lift else bottomInset + dp(88)
        box.tag = TAG
        val cardW = (availW * 0.92f).toInt().coerceAtMost(dp(520))
        // 별도 창(맨 위)에 그린다. 못 띄우면 예전처럼 이 창 안에 그린다
        val wp = WindowManager.LayoutParams(
            cardW, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = base
            windowAnimations = 0
        }
        val inWindow = try { activity.windowManager.addView(box, wp); true } catch (e: Exception) { false }
        if (inWindow) { winParams = wp; windowCard = box; wasFocused = activity.hasWindowFocus() } else {
            winParams = null
            root.addView(
                box,
                FrameLayout.LayoutParams(cardW, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                    .apply { bottomMargin = base }
            )
        }
        // 이미 떠 있는 일반 알림이 있으면 카드 위로 밀어 올린다
        root.post {
            val toast = root.findViewWithTag<View>("evergreen_app_toast") ?: return@post
            (toast.layoutParams as? FrameLayout.LayoutParams)?.let {
                it.bottomMargin = base + DownloadProgressCard.occupiedHeight(root)
                toast.layoutParams = it
            }
        }
        if (Motion.enabled(activity)) {
            box.alpha = 0f
            box.translationY = dp(14).toFloat()
            box.animate().alpha(1f).translationY(0f).setDuration(180).start()
        }
    }

    /** 카드 창을 뺐다가 다시 띄워 가장 위 창으로 올린다 (별도 창으로 그리고 있을 때만) */
    private fun raiseWindowCard() {
        val v = card ?: return
        val wp = winParams ?: return
        try {
            activity.windowManager.removeViewImmediate(v)
            activity.windowManager.addView(v, wp)
        } catch (e: Exception) { /* 창이 이미 사라짐 */ }
    }

    private fun detachCard(v: View) {
        if (winParams != null && windowCard === v) {
            windowCard = null; winParams = null
            try { activity.windowManager.removeViewImmediate(v) } catch (e: Exception) { /* 이미 사라짐 */ }
        } else (v.parent as? ViewGroup)?.removeView(v)
    }

    private fun removeCard(animate: Boolean) {
        val v = card ?: return
        card = null; title = null; info = null; bar = null; cancel = null
        if (animate && Motion.enabled(activity) && v.parent != null) {
            v.animate().alpha(0f).translationY(v.height * 0.2f).setDuration(200)
                .withEndAction { detachCard(v) }.start()
        } else {
            detachCard(v)
        }
    }

    private fun fmt(n: Long): String = when {
        n >= 1L shl 30 -> "%.2f GB".format(n / (1L shl 30).toDouble())
        n >= 1L shl 20 -> "%.1f MB".format(n / (1L shl 20).toDouble())
        n >= 1L shl 10 -> "%.0f KB".format(n / (1L shl 10).toDouble())
        else -> "$n B"
    }
}
