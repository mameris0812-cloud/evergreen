package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject

/**
 * 에이전트: 북마크 정리 도구.
 * - 읽기(자동): list_bookmark_folders
 * - 변경(요청당 한 번 확인): rename_bookmark · move_bookmarks
 *
 * 폴더를 정해서 담는 건 add_bookmark 의 folder 인자(AgentAppTools). 대상 북마크는 search_bookmarks 가 돌려준 주소(url)로만 고른다.
 * 바꾸기 직전 북마크 상태를 붙들어 둬서 「되돌리기」로 제목 · 폴더를 원래대로 돌릴 수 있다.
 */
object AgentBookmarkTools {
    const val MAX_MOVE = 30

    fun build(): List<AgentTool> = listOf(listFolders(), renameBookmark(), moveBookmarks())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    private fun outcome(o: AgentOutcome): AgentResult =
        if (!o.ok) AgentResult.fail(o.message)
        else AgentResult.ok(JSONObject().put("message", o.message).put("changed", o.number), o.message)

    private fun strsOf(a: JSONObject, key: String): List<String> {
        val arr = a.optJSONArray(key) ?: return emptyList()
        val out = LinkedHashSet<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty()) out.add(s)
        }
        return out.toList()
    }

    private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

    private fun titleOf(ctx: AgentContext, url: String): String =
        ctx.host.bookmarks("", Int.MAX_VALUE).firstOrNull { sameUrl(it.url, url) }?.title?.ifBlank { null } ?: url

    // ───────────────────────── 읽기 ─────────────────────────

    private fun listFolders() = AgentTool(
        name = "list_bookmark_folders",
        description = "북마크 폴더 목록과 폴더마다 든 북마크 수를 돌려줍니다. 북마크를 폴더에 담거나 옮기기 전에 어떤 폴더가 있는지 볼 때 쓰세요. " +
            "폴더에 들어 있지 않은 북마크(맨 위)의 수는 top_level_count 로 나옵니다.",
        risk = AgentRisk.READ,
        doing = { "북마크 폴더 확인하는 중…" },
        run = { _, ctx ->
            val fs = ctx.host.bookmarkFolders()
            val top = ctx.host.bookmarks("", Int.MAX_VALUE).count { it.folder.isEmpty() }
            val arr = JSONArray()
            for (f in fs) arr.put(JSONObject().put("name", f.name.take(60)).put("count", f.count))
            AgentResult.ok(
                JSONObject().put("count", fs.size).put("folders", arr).put("top_level_count", top),
                "북마크 폴더 ${fs.size}개를 확인했어요",
                untrusted = true
            )
        }
    )

    // ───────────────────────── 변경 ─────────────────────────

    private fun renameBookmark() = AgentTool(
        name = "rename_bookmark",
        description = "북마크의 이름(제목)을 바꿉니다. url 에 search_bookmarks 가 돌려준 북마크 주소를 그대로 주고, new_title 에 새 이름을 줍니다. " +
            "사용자가 이름을 바꾸라고 했을 때만 쓰고, 먼저 search_bookmarks 로 대상을 정확히 확인하세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "url" to AgentSchema.str("이름을 바꿀 북마크의 주소 (search_bookmarks 의 url)"),
                "new_title" to AgentSchema.str("새 이름 (200자 이내)")
            ),
            listOf("url", "new_title")
        ),
        doing = { a -> "북마크 이름 바꾸는 중: ${short(a.optString("new_title").trim(), 20)}…" },
        run = { a, ctx ->
            val url = a.optString("url").trim()
            val title = a.optString("new_title").trim()
            when {
                url.isEmpty() -> AgentResult.fail("url 이 비어 있어요 (search_bookmarks 의 url 을 주세요)")
                title.isEmpty() -> AgentResult.fail("new_title 이 비어 있어요")
                else -> outcome(ctx.host.renameBookmark(url, title))
            }
        },
        undoPlan = { a, ctx ->
            val snap = ctx.host.bookmarkSnapshot()
            val url = a.optString("url").trim()
            if (snap == null || url.isEmpty()) null else {
                { r ->
                    if (r.data.optInt("changed", 0) <= 0) null
                    else AgentUndo("북마크 이름 되돌리기") { h -> h.restoreBookmarkEdits(snap, listOf(url)) }
                }
            }
        },
        ask = { a, ctx ->
            "북마크 이름 바꾸기: 「${short(titleOf(ctx, a.optString("url").trim()), 22)}」 → 「${short(a.optString("new_title").trim(), 22)}」"
        }
    )

    private fun moveBookmarks() = AgentTool(
        name = "move_bookmarks",
        description = "북마크들을 폴더로 옮깁니다 (한 번에 최대 ${MAX_MOVE}개). urls 에 search_bookmarks 가 돌려준 주소를 그대로 주고, folder 에 옮길 폴더 이름을 줍니다. " +
            "그 이름의 폴더가 없으면 새로 만들어 넣습니다. 폴더에서 빼서 맨 위로 되돌리려면 folder 에 \"없음\" 을 주세요. " +
            "사용자가 북마크를 옮기거나 폴더로 정리해 달라고 했을 때만 쓰고, 먼저 list_bookmark_folders 로 있는 폴더를 보고 알맞은 폴더가 있으면 그 이름을 그대로 쓰세요. " +
            "주제별로 정리할 때는 주제마다 한 번씩 부르세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "urls" to AgentSchema.strList("옮길 북마크 주소들 (search_bookmarks 의 url)"),
                "folder" to AgentSchema.str("옮길 폴더 이름 (없으면 새로 만듦, 폴더에서 빼려면 \"없음\")")
            ),
            listOf("urls", "folder")
        ),
        doing = { a -> "북마크 옮기는 중: ${short(a.optString("folder").trim(), 20)}…" },
        run = { a, ctx ->
            val urls = strsOf(a, "urls")
            when {
                urls.isEmpty() -> AgentResult.fail("urls 가 비어 있어요 (search_bookmarks 의 url 을 주세요)")
                urls.size > MAX_MOVE -> AgentResult.fail("한 번에 ${MAX_MOVE}개까지만 옮길 수 있어요. 나눠서 다시 불러 주세요")
                a.optString("folder").isBlank() -> AgentResult.fail("folder 가 비어 있어요 (폴더에서 빼려면 \"없음\")")
                else -> outcome(ctx.host.moveBookmarks(urls, a.optString("folder")))
            }
        },
        undoPlan = { a, ctx ->
            val snap = ctx.host.bookmarkSnapshot()
            val urls = strsOf(a, "urls")
            if (snap == null || urls.isEmpty()) null else {
                { r ->
                    if (r.data.optInt("changed", 0) <= 0) null
                    else AgentUndo("북마크 ${r.data.optInt("changed")}개 폴더 되돌리기") { h -> h.restoreBookmarkEdits(snap, urls) }
                }
            }
        },
        ask = { a, ctx ->
            val urls = strsOf(a, "urls")
            val names = urls.take(3).joinToString(", ") { "「${short(titleOf(ctx, it), 22)}」" } +
                if (urls.size > 3) " 외 ${urls.size - 3}개" else ""
            val f = a.optString("folder").trim()
            val to = if (f.isEmpty() || f == "없음") "폴더에서 빼기" else "'${short(f, 20)}' 폴더로"
            "북마크 ${urls.size}개 $to: $names"
        }
    )
}
