package com.example.evergreen

import android.Manifest
import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.RectF
import android.view.ViewOutlineProvider
import android.widget.ScrollView
import androidx.core.view.doOnLayout
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Rational
import android.util.TypedValue
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringForce
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Filter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

/** 한 프레임에서 재생 중인 미디어 정보 (영상이면 가로·세로 크기) */
class MediaFrame(val video: Boolean, val w: Int, val h: Int)

class BrowserTab(initial: WebView? = null) {
    private var wv: WebView? = initial

    /** 복원된 탭은 실제로 열 때까지 WebView 만들기를 미룬다 (앱 시작이 빨라진다). 처음 webView 에 접근할 때 한 번 실행된다 */
    var lazyInit: (() -> Unit)? = null

    var webView: WebView
        get() {
            if (wv == null) {
                val init = lazyInit
                lazyInit = null
                init?.invoke()
            }
            return wv ?: error("WebView 가 아직 만들어지지 않았습니다")
        }
        set(v) { wv = v }

    /** 이미 만들어진 WebView (없으면 null). 모든 탭을 훑는 작업에서 WebView 를 억지로 만들지 않기 위해 쓴다 */
    val liveWebView: WebView? get() = wv

    /** 시크릿 탭: 방문 기록·탭 복원에 남지 않고, 쿠키·저장소는 별도 프로필에 담겼다가 탭을 다 닫으면 지워진다 */
    var incognito: Boolean = false

    /** HTTPS 우선: 이 탭이 https 로 올려서 연결을 시도 중인 원래 http 주소 */
    var upgradedFrom: String? = null

    /** 이번 페이지 로드에서 강제 다크(CSS) 스타일을 이미 넣었는지 */
    var darkInjected: Boolean = false

    /** 지금 재생 중인 미디어가 있는 프레임들 (키: 프레임 id). 비어 있으면 재생 중이 아님 */
    val mediaFrames = HashMap<String, MediaFrame>()

    /** 불러오지 못해 오류 화면을 보여 주는 중인 주소 (새로고침하면 이 주소를 다시 불러온다) */
    var errorUrl: String? = null

    /** 이 페이지에서 오간 영상/스트리밍 주소 (내장 플레이어용). 페이지가 바뀌면 비운다. */
    val sniffed: MutableSet<String> = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    /** 이 페이지에서 오간 자막 파일 주소 (.vtt/.srt/.ass/.ttml). 자바스크립트 플레이어가 따로 불러오는 자막까지 내장 플레이어에 넘기려고 모은다 */
    val sniffedSubs: MutableSet<String> = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    var progress: Int = 100
    var rate: Float = 1f

    /** 홈으로 나가면서 로딩을 중단시킨 탭: 페이지로 돌아오면 다시 불러온다 */
    var stoppedByHome: Boolean = false

    /** 0 = 그룹 없음 */
    var groupId: Int = 0

    /** 이번 페이지 로드에서 광고 숨김 CSS를 이미 넣었는지 */
    var cosmeticInjected: Boolean = false

    /** 이 페이지(이번 주소 이동)에서 막은 광고 건수 — 백그라운드 스레드에서 올라간다 */
    val adBlocked = java.util.concurrent.atomic.AtomicInteger(0)

    var favicon: Bitmap? = null

    /** 탭 화면에 보여줄 페이지 미리보기 (탭을 떠날 때 / 탭 화면을 열 때 갱신) */
    var thumb: Bitmap? = null

    /** 이 탭을 연 탭 (뒤로가기로 탭을 닫으면 여기로 돌아간다) */
    var opener: BrowserTab? = null

    /** 데스크톱 사이트 요청 */
    var desktop: Boolean = false

    /** 이 페이지에 데스크톱 뷰포트를 이미 적용했는지 */
    var desktopInjected: Boolean = false

    /** 이 탭에만 적용한 페이지 확대/축소 (%). null 이면 전체 설정(prefs.pageZoom)을 따른다 */
    var pageZoom: Int? = null

    /** 이 페이지에 확대/축소를 이미 적용했는지 */
    var zoomInjected: Boolean = false

    /** 앱을 다시 켰을 때 복원된 탭: 선택하기 전까지는 불러오지 않고 주소/제목만 들고 있다 */
    var pendingUrl: String? = null
    var pendingTitle: String? = null

    /** 새 탭 홈 화면을 보여주는 중인지 (홈 화면은 웹 기록에 들어 있는 항목이라 뒤로/앞으로 가기로 오갈 수 있다) */
    var isHome: Boolean = false

    /** 홈 항목이 다 불러와지면 웹 기록을 비운다 (마지막 탭을 닫아 새 탭으로 되돌릴 때) */
    var clearAtHome: Boolean = false

    /** 탭 음소거: true 면 이 탭의 모든 소리(video/audio/WebAudio)를 끈다 */
    @Volatile var muted: Boolean = false

    /** 홈에서 다른 페이지로 넘어가는 중: 새 페이지의 첫 화면이 그려질 때까지 웹뷰(이전 페이지 잔상)를 가리고 홈을 보여 준다 */
    var awaitCommit: Boolean = false

    /** WebView 를 onPause 시켜 둔 상태인지 (홈 화면이거나 다른 탭을 보는 중) */
    var paused: Boolean = false

    /** 페이지 스크립트(window.open)가 연 팝업 탭인지: 광고 팝업 판별에 쓴다 */
    var scriptPopup: Boolean = false

    /** JS 알림창 도배 방지용: 최근 몇 번 띄웠는지 / 마지막 시각 */
    var jsDialogCount: Int = 0
    var jsDialogAt: Long = 0L

    /** 렌더러가 마지막으로 죽은 시각 (같은 페이지가 계속 죽는지 보려고) */
    var crashAt: Long = 0L

    /** 마지막으로 뒤로가기를 한 시각 (uptimeMillis) */
    var backAt: Long = 0L

    /** 뒤로가기로 돌아오면 스스로 다른 곳으로 되돌려 보내는 페이지 주소 (뒤로가기 때 건너뛴다) */
    val redirectSources = HashSet<String>()
}

open class MainActivity : AppCompatActivity() {

    /** 첫 번째 창만 탭을 저장·복원한다 (여러 창이 같은 저장소를 덮어쓰지 않게) */
    private var isPrimary = false

    /** 창 번호 (창 1, 창 2 …). 열려 있는 동안 바뀌지 않는다 */
    private var windowNo = 0

    /** 새 창을 따로 띄운다 (최근 앱에 별개 항목으로 생기고, 멀티윈도우에서는 옆에 붙는다) */
    private fun openNewWindow() {
        startActivity(
            Intent(this, BrowserWindowActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                    Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
            )
        )
    }


    private lateinit var prefs: Prefs
    private lateinit var adBlocker: AdBlocker

    private lateinit var urlBar: AutoCompleteTextView
    private lateinit var progressBar: ProgressBar
    private lateinit var webContainer: PullRefreshLayout
    private lateinit var pageScrollBar: WebPageScrollBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnTabs: View
    private lateinit var tabCount: TextView
    private lateinit var btnBottomTabs: View
    private lateinit var tabCountBottom: TextView
    private lateinit var stripTabCount: TextView
    private lateinit var btnMenu: ImageButton
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var homeTagline: TextView
    private var homeTaglineDefault: CharSequence = ""
    private lateinit var findBar: View
    private lateinit var etFind: EditText
    private lateinit var findCount: TextView
    private lateinit var browserUi: View
    private lateinit var bottomBar: View
    private lateinit var tabStripBar: View
    private lateinit var tabStripScroll: HorizontalScrollView
    private lateinit var tabStrip: LinearLayout
    private lateinit var navGroup: View
    private lateinit var tbBack: ImageButton
    private lateinit var tbForward: ImageButton
    private lateinit var tbHome: ImageButton
    private lateinit var tbMenu: ImageButton
    private lateinit var tbDesktop: ImageButton
    private lateinit var tbAi: ImageButton
    private lateinit var tabletActions: View
    private lateinit var homeView: View
    private lateinit var homeContent: View
    private lateinit var tabSwitcher: View
    private lateinit var tabList: LinearLayout
    private lateinit var tabScroll: ScrollView
    private lateinit var tabsTitle: TextView
    private lateinit var tabMorph: ImageView
    private var switcherOpen = false
    private var switcherBusy = false
    private val switcherRows = HashMap<BrowserTab, View>()
    private val switcherBoxes = HashMap<Int, View>()
    private var morphRadius = 0f
    private var assistant: AssistantUi? = null

    /** 태블릿(넓은 화면) 레이아웃 사용 중인지 */
    private var expanded = false
    private var stripRefreshQueued = false
    private var lastStripCurrent: BrowserTab? = null
    private var baseUserAgent: String = ""
    @Volatile private var lastTouchAt = 0L
    private fun recentTouch(windowMs: Long = 5000L) = android.os.SystemClock.uptimeMillis() - lastTouchAt < windowMs

    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null

    private val groups = mutableListOf<TabGroup>()
    private var nextGroupId = 1

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    @Volatile
    private var adBlockEnabled = true
    private val trackerBlocker = TrackerBlocker()
    private var strictTrackers = false
    private var skipCaptchaTracking = false
    private var malwareWarning = true
    private var blockAutoDownload = true
    // 스크롤 시 메뉴바 숨김 기능은 설정에서 제거됨 (항상 꺼짐)
    private val hideBarsOnScroll = false
    private val hideStatusBarOnScroll = false
    private var statusBarHiddenByScroll = false
    private var barsFraction = 0f      // 0 = 보임, 1 = 숨김
    private var barsTarget = 0f
    private var barsAnim: android.animation.ValueAnimator? = null
    private var barsLayoutHidden = false     // true: 레이아웃이 '바 숨김' 형태(웹 영역이 화면 전체 크기)
    private var barsStartRunnable: Runnable? = null
    private var barsGestureActive = false     // 손가락으로 스크롤 중 (바가 손가락을 따라 움직이는 중)
    private var barsGestureDy = 0
    private var barsLastDir = 0
    private var barsConsumeAfter = 0L
    private var barsIgnoreScrollUntil = 0L  // 바 애니메이션 중 웹뷰 크기 변화로 생기는 가짜 스크롤 무시
    private var scrollAcc = 0
    private val toolbarView by lazy { findViewById<View>(R.id.toolbar) }

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val suggestItems = mutableListOf<String>()
    private lateinit var suggestAdapter: SuggestAdapter
    private var suggestRunnable: Runnable? = null
    private var suppressWatcher = false
    private var askedNotificationPermission = false

    /** 웹페이지의 <input type="file"> 업로드: 파일 선택 화면을 띄우고 결과를 WebView 에 돌려준다. */
    private var fileChooserCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileChooserCallback
            fileChooserCallback = null
            val uris = if (result.resultCode == RESULT_OK) {
                // 파일 관리자마다 결과를 담는 방식이 달라, 표준 해석이 비면 직접 꺼내 본다
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
                    ?.takeIf { it.isNotEmpty() }
                    ?: result.data?.let { d ->
                        val cd = d.clipData
                        when {
                            cd != null && cd.itemCount > 0 ->
                                Array(cd.itemCount) { i -> cd.getItemAt(i).uri }
                            d.data != null -> arrayOf(d.data!!)
                            else -> null
                        }
                    }
            } else null
            cb?.onReceiveValue(uris)
        }

    /** 북마크 화면에서 고른 주소를 받아 현재 탭(또는 새 탭)에서 연다. */
    private val bookmarksLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            val url = data?.getStringExtra(BookmarksActivity.EXTRA_URL)
            if (data == null || url == null) {
                // 주소를 고르지 않고 뒤로 나왔다 → 이 화면을 열었던 메뉴로 돌아간다
                reopenMenuAfterList()
                return@registerForActivityResult
            }
            if (data.getBooleanExtra(BookmarksActivity.EXTRA_NEW_TAB, false)) {
                createTab(url, opener = current)
            } else {
                loadFromInput(url)
            }
        }

    // ───────────────────────── 생명주기 ─────────────────────────

    // ───────────────────────── 크래시 기록 ─────────────────────────
    // 앱이 꺼지면 원인(스택 트레이스)을 파일에 남기고, 다시 켰을 때 화면에 보여 준다.

    private val crashFile get() = java.io.File(filesDir, "last_crash.txt")

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        val file = crashFile
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = java.io.StringWriter()
                throwable.printStackTrace(java.io.PrintWriter(sw))
                file.writeText(
                    "시각: ${java.util.Date()}\n스레드: ${thread.name}\n" +
                        "기기: ${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n" +
                        sw.toString().take(6000)
                )
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    private fun showLastCrashIfAny() {
        val f = crashFile
        if (!f.exists()) return
        val text = try { f.readText() } catch (e: Exception) { return }
        f.delete()
        if (text.isBlank()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("앱이 꺼진 원인 기록")
            .setMessage(text.take(1500))
            .setPositiveButton("복사") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", text))
                toast("복사했어요. 개발자에게 붙여넣어 보내 주세요")
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instances.add(this)
        if (instances.size == 1) windowSeq = 0
        windowNo = ++windowSeq
        isPrimary = primary == null
        if (isPrimary) primary = this
        installCrashLogger()
        window.decorView.post { showLastCrashIfAny() }
        setContentView(R.layout.activity_main)
        installCaptionIntegration()

        urlBar = findViewById(R.id.urlBar)
        progressBar = findViewById(R.id.progressBar)
        webContainer = findViewById(R.id.webContainer)
        // WebView 위에 겹쳐지는 우측 드래그 스크롤바. 페이지 자체의 세로 스크롤과 직접 동기화한다.
        pageScrollBar = WebPageScrollBar(this)
        (webContainer.parent as? FrameLayout)?.addView(
            pageScrollBar,
            FrameLayout.LayoutParams(dp(32), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
        )
        // 손가락 움직임을 메뉴바가 먼저 받아 쓰고, 남는 만큼만 페이지가 스크롤된다 (크롬 방식)
        webContainer.onNestedStart = { onBarsGestureStart() }
        webContainer.onNestedPreScrollDy = { dy -> onBarsPreScroll(dy) }
        webContainer.onNestedStop = { onBarsGestureStop() }
        // 바 높이가 바뀌거나(탭 스트립 표시 등) 키보드가 나타났다 사라지면 전체 크기 고정 레이아웃을 다시 맞춘다
        val barsSizeListener = View.OnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) browserUi.post { barsSyncFullLayout() }
        }
        barsSizeListenerRef = barsSizeListener
        // 페이지가 맨 위일 때(그리고 홈 화면이 아닐 때)만 아래로 당겨 새로고침
        webContainer.canChildScrollUp = {
            val c = current
            c == null || c.isHome || c.webView.scrollY > 0
        }
        // 핀치로 확대해 둔 페이지에서는 당겨서 새로고침을 하지 않는다 (확대 후 끌어내리는 동작은 화면 이동이다)
        webContainer.isPullBlocked = {
            val c = current
            c == null || c.isHome || (c.webView as? NestedWebView)?.isZoomedIn == true
        }
        MediaBridge.onStop = { instances.toList().forEach { a -> a.ui.post { a.pauseAllMedia() } } }
        webContainer.onRefresh = {
            val c = current
            if (c == null || c.isHome) {
                webContainer.endRefresh()
            } else {
                reloadTab(c)
                // 로딩 완료 신호가 안 오더라도 표시기가 남지 않게
                webContainer.postDelayed({ webContainer.endRefresh() }, 8000)
            }
        }
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnHome = findViewById(R.id.btnHome)
        btnTabs = findViewById(R.id.btnTabs)
        tabCount = findViewById(R.id.tabCount)
        btnBottomTabs = findViewById(R.id.btnBottomTabs)
        tabCountBottom = findViewById(R.id.tabCountBottom)
        stripTabCount = findViewById(R.id.stripTabCount)
        btnMenu = findViewById(R.id.btnMenu)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        // 전체화면 동영상을 아래로 끌어내리면 전체화면 해제
        homeTagline = findViewById(R.id.homeTagline)
        homeTaglineDefault = homeTagline.text
        findBar = findViewById(R.id.findBar)
        etFind = findViewById(R.id.etFind)
        findCount = findViewById(R.id.findCount)
        browserUi = findViewById(R.id.browserUi)
        bottomBar = findViewById(R.id.bottomBar)
        tabStripBar = findViewById(R.id.tabStripBar)
        // 탭 줄 자체는 그림자를 만들지 않는다.
        tabStripBar.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) { outline.setEmpty() }
        }
        tabStripScroll = findViewById(R.id.tabStripScroll)
        tabStrip = findViewById(R.id.tabStrip)
        navGroup = findViewById(R.id.navGroup)
        tbBack = findViewById(R.id.tbBack)
        tbForward = findViewById(R.id.tbForward)
        tbHome = findViewById(R.id.tbHome)
        tbMenu = findViewById(R.id.tbMenu)
        tbDesktop = findViewById(R.id.tbDesktop)
        tbAi = findViewById(R.id.tbAi)
        tabletActions = findViewById(R.id.tabletActions)
        homeView = findViewById(R.id.homeView)
        barsSizeListenerRef?.let {
            toolbarView.addOnLayoutChangeListener(it)
            tabStripBar.addOnLayoutChangeListener(it)
        }
        browserUi.viewTreeObserver.addOnGlobalLayoutListener {
            val ime = androidx.core.view.ViewCompat.getRootWindowInsets(browserUi)
                ?.isVisible(WindowInsetsCompat.Type.ime()) == true
            if (ime != imeVisible) {
                imeVisible = ime
                browserUi.post { barsSyncFullLayout() }
            }
        }
        homeContent = findViewById(R.id.homeContent)
        tabSwitcher = findViewById(R.id.tabSwitcher)
        applySwitcherCaptionInset(switcherCaptionInset)
        tabList = findViewById(R.id.tabList)
        tabScroll = findViewById(R.id.tabScroll)
        // 끄는 카드가 첫 줄 아래에서 잘리지 않도록 목록 쪽은 항상 잘라내기를 끈다
        // (스크롤 영역 가장자리는 바깥 레이아웃이 계속 잘라 주므로 스크롤된 카드가 머리글 위로 번지지 않는다)
        tabScroll.clipChildren = false
        tabList.clipChildren = false
        tabsTitle = findViewById(R.id.tabsTitle)
        tabMorph = findViewById(R.id.tabMorph)

        prefs = Prefs(this)
        // 악성 사이트 검사(Safe Browsing)를 미리 깨워 두어 첫 페이지 이동이 느려지지 않게
        if (prefs.malwareWarning && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            WebView.startSafeBrowsing(applicationContext, null)
        }
        adBlocker = AdBlocker(this)
        adBlockEnabled = prefs.adBlock
        strictTrackers = prefs.strictTrackers
        skipCaptchaTracking = prefs.skipCaptchaTracking
        malwareWarning = prefs.malwareWarning
        blockAutoDownload = prefs.blockAutoDownload
        autofillEnabled = prefs.autofill
        httpsFirst = prefs.httpsFirst
        darkMode = prefs.webDarkMode
        textZoom = prefs.textZoom
        assistant = AssistantUi(
            activity = this,
            prefs = prefs,
            fetchPage = { cb -> fetchPageForAssistant(cb) },
            runPageJs = { js, cb -> runJsOnCurrentPage(js, cb) },
            openUrl = { url -> createTab(url, opener = current) }
        )
        io.execute { adBlocker.load() }
        autoUpdateAdBlockList()

        CookieManager.getInstance().setAcceptCookie(true)
        // 지난번에 앱이 갑자기 꺼졌다면 남아 있는 시크릿 데이터를 지운다 (다른 창이 떠 있으면 그 창의 시크릿 탭이 있을 수 있으니 건드리지 않는다)
        if (instances.size == 1) purgeIncognitoIfUnused()

        applyLayoutMode()
        setupUrlBar()
        setupControls()
        setupHome()
        setupBackHandler()
        setupTabSwitcher()

        // 화면 회전·테마 변경으로 다시 만들어질 때는 같은 인텐트를 또 처리하지 않는다
        val startUrl = if (savedInstanceState == null) launchTarget(intent) else null

        val restored = if (isPrimary) restoreTabs() else false
        if (startUrl != null) createTab(startUrl)
        else if (!restored) createTab(null, home = true)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayoutMode()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        launchTarget(intent)?.let { createTab(it) }
    }

    /**
     * 밖에서 들어온 인텐트가 열어 달라는 주소를 돌려준다.
     * - 링크(VIEW) → 그 주소
     * - 다른 앱의 공유(SEND) / 글자 선택 메뉴(PROCESS_TEXT) → 글에 주소가 있으면 그 주소, 없으면 검색 주소
     */
    private fun launchTarget(intent: Intent?): String? {
        intent ?: return null
        intent.data?.let { d ->
            // 다른 앱이 보낸 주소는 웹 주소만 연다 (file:, content:, javascript: 등은 무시)
            val sc = d.scheme?.lowercase()
            return if (sc == "http" || sc == "https") d.toString() else null
        }
        val text = when (intent.action) {
            Intent.ACTION_SEND ->
                if (intent.type?.startsWith("text/") == true) intent.getStringExtra(Intent.EXTRA_TEXT) else null
            Intent.ACTION_PROCESS_TEXT ->
                intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }?.trim()
        if (text.isNullOrEmpty()) return null
        // "제목\n https://..." 처럼 공유된 글에서는 주소만 골라 연다
        Regex("https?://[^\\s<>\"']+").find(text)?.let { return it.value.trimEnd('.', ',', ')', ']') }
        // 그 밖의 글은 한 줄로 정리해서 검색 (너무 길면 자른다). 단축어("yt 노래" 등)는 적용하지 않는다.
        val query = text.replace(Regex("\\s+"), " ").take(300)
        return SearchEngines.byKey(prefs.engineKey).searchUrl + Uri.encode(query)
    }

    override fun onStop() {
        super.onStop()
        saveTabs()
    }

    override fun onPause() {
        super.onPause()
        saveTabs()
        adBlocker.flush()
        if (!isInPictureInPictureMode) {
            // 백그라운드 재생이 켜져 있으면 소리가 나는 탭은 멈추지 않는다
            tabs.forEach {
                if (!(prefs.backgroundAudio && it.mediaFrames.isNotEmpty())) it.liveWebView?.onPause()
            }
        }
        CookieManager.getInstance().flush()
    }

    override fun onResume() {
        super.onResume()
        // 앱을 나갔다 올 때 멈춘 모든 탭을 다시 깨운다 (안 보이는 탭도 계속 돌아가야 하므로)
        tabs.forEach { it.liveWebView?.onResume(); it.paused = false }
        current?.webView?.onResume()
        autoUpdateAdBlockList()
        // 다른 창에 다녀왔을 때 탭 화면의 창 목록도 최신으로
        if (switcherOpen) refreshWindowStrip()
        // 북마크 / 방문 기록 / 다운로드 팝업의 ← 로 돌아왔으면 메뉴를 다시 띄운다
        if (ListUi.reopenMenu) {
            ListUi.reopenMenu = false
            val a = menuAnchorRef?.get()
            if (a != null) window.decorView.post { if (!isFinishing && a.isShown) showMenu(a) }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // 영상을 전체화면으로 보는 중에 앱을 나가면 작은 창으로 바뀐다.
        // Android 12+ 는 refreshPipParams() 의 자동 진입이 처리한다. 그 이전 버전은 여기서 직접 들어간다.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && autoPipWanted()) enterPip()
    }

    // ───────────────────────── PiP (작은 창 재생) ─────────────────────────

    private var pipKey = ""

    private fun pipWanted(): Boolean {
        if (customView != null) return true
        val t = current ?: return false
        return !t.isHome && t.mediaFrames.values.any { it.video }
    }

    /** 앱을 나갈 때 저절로 작은 창이 되는 경우: 영상을 전체화면으로 보고 있을 때만 */
    private fun autoPipWanted(): Boolean = customView != null

    private fun pipRatio(): android.util.Rational {
        val f = current?.mediaFrames?.values?.firstOrNull { it.video && it.w > 0 && it.h > 0 }
        var w = f?.w ?: 16
        var h = f?.h ?: 9
        val r = w.toFloat() / h
        if (r > 2.39f) { w = 239; h = 100 } else if (r < 0.4184f) { w = 100; h = 239 }
        return android.util.Rational(w, h)
    }

    private fun enterPip(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || isInPictureInPictureMode) return false
        return try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(pipRatio()).build())
            true
        } catch (e: Exception) {
            false
        }
    }

    /** 영상 비율을 맞춰 두고, Android 12+ 에서는 홈으로 나갈 때 저절로 작은 창으로 바뀌게 한다. */
    private fun refreshPipParams() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val want = autoPipWanted()
        val r = pipRatio()
        val key = "$want $r"
        if (key == pipKey) return
        pipKey = key
        try {
            val b = PictureInPictureParams.Builder().setAspectRatio(r)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) b.setAutoEnterEnabled(want)
            setPictureInPictureParams(b.build())
        } catch (e: Exception) {
            // PiP 불가 시 무시
        }
    }

    private fun startPipFromMenu() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            toast("이 기기는 PiP 를 지원하지 않아요")
        } else if (!pipWanted()) {
            toast("재생 중인 동영상이 없어요")
        } else if (!enterPip()) {
            toast("PiP 를 시작할 수 없어요")
        }
    }

    private fun isInPictureInPictureModeCompat(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (customView != null) return
        if (isInPictureInPictureMode) {
            // 주소창·탭바 등을 숨기고 재생 중인 동영상만 창 가득 보이게
            tabStripBar.visibility = View.GONE
            toolbarView.visibility = View.GONE
            bottomBar.visibility = View.GONE
            progressBar.visibility = View.GONE
            current?.webView?.evaluateJavascript(MediaScripts.PIP_ON, null)
        } else {
            toolbarView.visibility = View.VISIBLE
            applyLayoutMode(pip = false)
            current?.webView?.evaluateJavascript(MediaScripts.PIP_OFF, null)
        }
    }

    // ───────────────────────── 백그라운드 재생 ─────────────────────────

    private val stopMediaRunnable = Runnable {
        if (tabs.none { it.mediaFrames.isNotEmpty() } || !prefs.backgroundAudio) {
            mediaKey = ""
            MediaService.stop(this)
        }
    }
    private var mediaKey = ""

    /** 페이지가 재생 상태를 알려 올 때 (메인 스레드) */
    private inner class MediaJs(val tab: BrowserTab) {
        /** true 면 페이지에 "숨겨지지 않았다"고 알려 스스로 멈추지 못하게 한다. 지금 안 보이는 탭도 계속 돌게 하려고 항상 true */
        @JavascriptInterface
        fun bg(): Boolean = prefs.backgroundAudio || tab !== current

        /** 이 탭이 음소거인지 (페이지 스크립트가 소리를 끌지 판단) */
        @JavascriptInterface
        fun muted(): Boolean = tab.muted

        /** 손가락이 닿은 자리가 페이지 안쪽에서 이미 스크롤되어 있다/스크롤 중이다 → 당겨서 새로고침 금지 (백그라운드 스레드에서 불린다) */
        @JavascriptInterface
        fun pullInner(v: Boolean) {
            if (tab === current) webContainer.innerScrolled = v
        }

        @JavascriptInterface
        fun adblock(): Boolean = adBlockEnabled

        /** 이 주소가 광고인지 (페이지 스크립트의 팝업/링크 확인용) */
        @JavascriptInterface
        fun adurl(url: String?): Boolean = adBlockEnabled && adBlocker.isAdUrl(url)

        /**
         * 페이지 스크립트가 보내려는 요청(fetch/XHR/sendBeacon)이 광고·추적인지.
         * 맞으면 페이지 쪽에서 진짜 차단기처럼 '네트워크 오류'로 실패시키고 차단 건수에 센다.
         */
        @JavascriptInterface
        fun adreq(url: String?, pageHost: String?): Boolean {
            if (!adBlockEnabled || url.isNullOrEmpty()) return false
            val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return false
            val blocked = adBlocker.shouldBlock(host, pageHost, url, NetFilter.inferType(url, null, false))
            if (blocked) {
                adBlocker.record(host, AdBlocker.KIND_REQUEST)
                tab.adBlocked.incrementAndGet()
            }
            return blocked
        }

        /**
         * 페이지의 <video> 가 가리키는 주소가 광고 영상(배너)인지: 광고 서버 목록, 영상 배너 주소 모양, 예외 규칙까지 본다.
         * 영상 배너 감지 스크립트가 쓴다 (차단 건수는 실제로 가렸을 때 [adhid] 로 센다).
         */
        @JavascriptInterface
        fun advid(url: String?, pageHost: String?): Boolean = adBlockEnabled && adBlocker.isAdVideoUrl(url, pageHost)

        /** 영상 배너를 화면에서 가렸을 때: 차단 건수에 센다 */
        @JavascriptInterface
        fun adhid(pageHost: String?) {
            if (!adBlockEnabled) return
            adBlocker.record(pageHost, AdBlocker.KIND_REQUEST)
            tab.adBlocked.incrementAndGet()
        }

        /** 이 사이트에서 사용자가 직접 고른 광고의 선택자 목록 (JSON 배열 글자) */
        @JavascriptInterface
        fun aduser(host: String?): String {
            if (!adBlockEnabled) return "[]"
            val arr = org.json.JSONArray()
            for (s in adBlocker.userSelectors(host)) arr.put(s)
            return arr.toString()
        }

        /** '광고 직접 선택' 에서 '차단' 을 눌렀을 때 */
        @JavascriptInterface
        fun adpick(host: String?, selector: String?, label: String?, src: String?): Boolean =
            adBlocker.addUserRule(host, selector, label, src)

        /** '광고 직접 선택' 이 끝났을 때 (blocked = 이번에 고른 개수) */
        @JavascriptInterface
        fun adpickEnd(blocked: Int) {
            ui.post {
                if (tab !in tabs) return@post
                if (blocked > 0) toast("광고 ${blocked}건을 직접 차단했어요 · 설정에서 관리할 수 있어요")
                if (tab === current) updateUi()
            }
        }

        /** 오류 화면의 '다시 시도' (오류 화면은 loadDataWithBaseURL 이라 location.replace 로는 다시 불러와지지 않는다) */
        @JavascriptInterface
        fun errRetry() {
            ui.post { if (tab in tabs && tab.errorUrl != null) reloadTab(tab) }
        }

        /** 오류 화면의 '이전으로' */
        @JavascriptInterface
        fun errBack() {
            ui.post {
                if (tab !in tabs || tab.errorUrl == null) return@post
                if (canGoBackSmart(tab)) {
                    goBackSmart(tab)
                } else {
                    // 돌아갈 페이지가 없으면 시작 화면으로
                    loadHome(tab)
                }
            }
        }

        /** 첫 화면에만 적용하는 광고 영역 숨김 CSS (내려받은 목록 기준) */
        @JavascriptInterface
        fun adcss(host: String?): String = adBlocker.topCss(host)

        @JavascriptInterface
        fun state(fid: String, playing: Boolean, video: Boolean, w: Int, h: Int) {
            ui.post {
                if (tab !in tabs) return@post
                if (playing) tab.mediaFrames[fid] = MediaFrame(video, w, h) else {
                    tab.mediaFrames.remove(fid)
                }
                onMediaChanged()
            }
        }
    }

    // ── 보고 있지 않은 탭이 소리·영상을 계속 내도록, 화면 뒤 1px 칸에 붙여 둔다 ──

    private var parkHost: FrameLayout? = null

    private fun parkHost(): FrameLayout? {
        parkHost?.let { return it }
        val area = webContainer.parent as? FrameLayout ?: return null
        val h = FrameLayout(this).apply {
            clipChildren = true
            alpha = 0.01f
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
        area.addView(h, 0, FrameLayout.LayoutParams(1, 1))
        parkHost = h
        return h
    }

    private fun parkIfPlaying(tab: BrowserTab) {
        val wv = tab.liveWebView ?: return
        if (tab.mediaFrames.isEmpty() || wv.parent != null) return
        val host = parkHost() ?: return
        // 웹뷰 크기는 화면과 똑같이 유지해서 페이지 배치가 바뀌지 않게 한다
        val w = webContainer.width.coerceAtLeast(dp(320))
        val h = webContainer.height.coerceAtLeast(dp(480))
        wv.layoutParams = FrameLayout.LayoutParams(w, h)
        host.addView(wv)
    }

    /** 다시 화면에 올리기 전에 보이지 않는 칸에서 떼고, 크기를 화면에 맞게 되돌린다 */
    private fun unparkWebView(tab: BrowserTab) {
        val wv = tab.liveWebView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    /** 더 이상 소리가 나지 않는 탭은 보이지 않는 칸에서 내려 자원을 아낀다 */
    private val sweepParked = Runnable {
        val host = parkHost ?: return@Runnable
        tabs.forEach { t ->
            val wv = t.liveWebView ?: return@forEach
            if (wv.parent === host && t.mediaFrames.isEmpty()) host.removeView(wv)
        }
    }

    private fun onMediaChanged() {
        // 보고 있지 않은 탭에서 재생이 시작됐다면 그 탭도 붙여 둔다
        tabs.forEach { if (it !== current) parkIfPlaying(it) }
        ui.removeCallbacks(sweepParked)
        ui.postDelayed(sweepParked, 4000)
        val playing = tabs.filter { it.mediaFrames.isNotEmpty() }
        if (playing.isEmpty() || !prefs.backgroundAudio) {
            // 버퍼링이나 다음 영상으로 넘어가는 짧은 끊김에는 알림을 유지한다
            ui.removeCallbacks(stopMediaRunnable)
            ui.postDelayed(stopMediaRunnable, 2500)
        } else {
            ui.removeCallbacks(stopMediaRunnable)
            val t = playing.firstOrNull { it === current } ?: playing.first()
            val host = runCatching { Uri.parse(t.liveWebView?.url).host }.getOrNull().orEmpty()
            val title = t.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" } ?: host
            val key = "${System.identityHashCode(t)}|$title"
            if (key != mediaKey) {
                mediaKey = key
                // 알림 권한을 따로 요청하지 않는다 (재생 알림을 띄우지 않기 위해)
                MediaService.start(this, title, host)
            }
        }
        refreshPipParams()
    }

    private fun pauseAllMedia() {
        tabs.forEach { it.liveWebView?.evaluateJavascript(MediaScripts.PAUSE_ALL, null) }
    }

    override fun onDestroy() {
        spareWebView?.destroy()
        spareWebView = null
        instances.remove(this)
        if (primary === this) {
            primary = null
            // 대표 창이 닫히면 남은 창 하나가 탭 저장을 이어받는다 (사용자가 닫은 경우에만)
            if (isFinishing) instances.firstOrNull()?.let { it.isPrimary = true; primary = it }
        }
        ui.removeCallbacks(stopMediaRunnable)
        ui.removeCallbacks(sweepParked)
        if (instances.isEmpty()) {
            MediaBridge.onStop = null
            MediaService.stop(this)
        }
        tabs.forEach {
            val w = it.liveWebView ?: return@forEach
            w.stopLoading()
            (w.parent as? ViewGroup)?.removeView(w)
            w.destroy()
        }
        tabs.clear()
        if (instances.isEmpty()) purgeIncognitoIfUnused(false)
        io.shutdown()
        super.onDestroy()
    }

    // ───────────────────────── 탭 ─────────────────────────

    // ───────────────────────── 탭 저장 / 복원 ─────────────────────────

    /** 열려 있는 탭(주소·그룹·데스크톱 여부·선택한 탭)을 저장한다. 앱을 껐다 켜도 그대로 남는다. */
    private fun saveTabs() {
        if (!isPrimary) return
        try {
            // 시크릿 탭은 저장하지 않는다 (앱을 다시 켜면 사라진다)
            val saved = tabs.filter { !it.incognito }
            if (tabs.isEmpty()) return
            val arr = JSONArray()
            for (t in saved) {
                val lw = t.liveWebView
                val live = lw?.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                val url = if (t.isHome) null else (live ?: t.pendingUrl)
                val title = (if (live != null) lw?.title else t.pendingTitle).orEmpty()
                arr.put(
                    JSONObject()
                        .put("url", url ?: "")
                        .put("title", title)
                        .put("home", url == null)
                        .put("desktop", t.desktop)
                        .put("group", t.groupId)
                )
            }
            val gs = JSONArray()
            for (g in groups) {
                gs.put(
                    JSONObject().put("id", g.id).put("name", g.name)
                        .put("color", g.color).put("collapsed", g.collapsed)
                )
            }
            val root = JSONObject()
                .put("tabs", arr)
                .put("groups", gs)
                .put("cur", (current?.let { saved.indexOf(it) } ?: 0).coerceAtLeast(0))
                .put("nextGid", nextGroupId)
            prefs.savedTabs = root.toString()
        } catch (e: Exception) {
            // 저장 실패는 무시
        }
    }

    /** 저장된 탭을 되살린다. 선택한 탭만 바로 불러오고 나머지는 선택할 때 불러온다. 복원한 탭이 있으면 true. */
    private fun restoreTabs(): Boolean {
        val raw = prefs.savedTabs ?: return false
        return try {
            val root = JSONObject(raw)
            val arr = root.getJSONArray("tabs")
            if (arr.length() == 0) return false
            val gs = root.optJSONArray("groups")
            if (gs != null) {
                for (i in 0 until gs.length()) {
                    val g = gs.getJSONObject(i)
                    groups.add(TabGroup(g.getInt("id"), g.getString("name"), g.getInt("color"), g.optBoolean("collapsed", false)))
                }
            }
            nextGroupId = maxOf(root.optInt("nextGid", 1), (groups.maxOfOrNull { it.id } ?: 0) + 1)
            for (i in 0 until minOf(arr.length(), 40)) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url").takeIf { it.isNotEmpty() }
                val home = o.optBoolean("home", false) || url == null
                val tab = createTab(null, select = false, home = home, lazy = true)
                val gid = o.optInt("group", 0)
                tab.groupId = if (groups.any { it.id == gid }) gid else 0
                if (!home) {
                    tab.pendingUrl = url
                    tab.pendingTitle = o.optString("title").takeIf { it.isNotBlank() }
                }
            }
            val idx = root.optInt("cur", 0).coerceIn(0, tabs.size - 1)
            selectTab(tabs[idx])
            pruneEmptyGroups()
            true
        } catch (e: Exception) {
            // 일부만 만들어졌더라도 있는 탭으로 시작
            if (tabs.isNotEmpty()) {
                if (current == null) selectTab(tabs[0])
                true
            } else false
        }
    }

    /** 탭 제목: 불러온 페이지 제목 → (복원만 된 탭이면) 저장해 둔 제목/주소 → "새 탭" */
    private fun tabTitle(tab: BrowserTab): String {
        // 홈(새 탭)이거나 빈 페이지면 WebView 가 돌려주는 "about:blank" 제목을 쓰지 않는다
        if (tab.isHome) return if (tab.incognito) "시크릿 탭" else "새 탭"
        val lw = tab.liveWebView
        val blank = lw?.url == "about:blank" || lw?.url == HOME_URL
        return lw?.title?.takeIf { it.isNotBlank() && !blank && it != "about:blank" }
            ?: tab.pendingTitle
            ?: tab.pendingUrl?.let { runCatching { Uri.parse(it).host }.getOrNull() }
            ?: "새 탭"
    }

    private fun homeUrl(): String = SearchEngines.byKey(prefs.engineKey).homeUrl

    // ───────────────────────── 로딩 속도 ─────────────────────────

    private val docStartScripts: Boolean by lazy {
        WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
    }

    /** 새 탭을 바로 열 수 있도록 미리 만들어 둔 빈 웹뷰 한 개 (화면이 한가할 때 만든다) */
    private var spareWebView: WebView? = null

    private fun prepareSpareWebView() {
        if (spareWebView != null) return
        Looper.myQueue().addIdleHandler {
            if (spareWebView == null && !isFinishing && !isDestroyed) {
                spareWebView = NestedWebView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            }
            false
        }
    }

    private val dnsWarm: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** 곧 열 가능성이 높은 주소(입력한 주소, 첫 자동완성 등)의 도메인 조회를 미리 해 둔다 */
    private fun prefetchDns(url: String?) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return
        val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return
        if (dnsWarm.size > 300) dnsWarm.clear()
        if (!dnsWarm.add(host)) return
        // 조회가 오래 걸려도 다른 백그라운드 작업(기록 저장, 자동완성)을 막지 않게 별도 스레드에서
        Thread {
            try {
                java.net.InetAddress.getAllByName(host)
            } catch (e: Exception) {
                dnsWarm.remove(host)
            }
        }.apply { isDaemon = true }.start()
    }

    // ───────────────────────── 시크릿 탭 ─────────────────────────

    private val incognitoProfileName = "incognito"
    private var incognitoWarned = false

    private val profilesSupported: Boolean by lazy {
        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
    }

    /** 시크릿 전용 프로필에 붙은 웹뷰. 프로필이 쿠키·캐시·저장소를 따로 들고 있다. 지원하지 않는 기기면 기록만 남기지 않는다. */
    private fun newIncognitoWebView(): WebView {
        val wv = NestedWebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        if (profilesSupported) {
            try {
                androidx.webkit.WebViewCompat.setProfile(wv, incognitoProfileName)
            } catch (e: Exception) {
                warnNoIsolation()
            }
        } else {
            warnNoIsolation()
        }
        return wv
    }

    private fun warnNoIsolation() {
        if (incognitoWarned) return
        incognitoWarned = true
        toast("이 기기의 WebView는 쿠키 분리를 지원하지 않아 방문 기록만 남기지 않습니다")
    }

    /** 이 탭이 쓰는 쿠키 저장소 (시크릿이면 시크릿 프로필 것) */
    private fun cookieManagerFor(tab: BrowserTab?): CookieManager {
        if (tab?.incognito == true && profilesSupported) {
            try {
                return androidx.webkit.ProfileStore.getInstance()
                    .getOrCreateProfile(incognitoProfileName).cookieManager
            } catch (e: Exception) {
                // 아래 기본값
            }
        }
        return CookieManager.getInstance()
    }

    /** 시크릿 탭이 하나도 없으면 시크릿 프로필(쿠키·캐시·저장소)을 통째로 지운다. */
    private fun purgeIncognitoIfUnused(retry: Boolean = true) {
        if (!profilesSupported || tabs.any { it.incognito }) return
        try {
            androidx.webkit.ProfileStore.getInstance().deleteProfile(incognitoProfileName)
        } catch (e: Exception) {
            // 웹뷰가 아직 정리되는 중이면 잠시 뒤 한 번 더 시도한다
            if (retry) ui.postDelayed({ purgeIncognitoIfUnused(false) }, 800)
        }
    }

    /** 시크릿 탭이 보이는 동안에는 스크린샷·최근 앱 미리보기를 막는다 */
    private fun updateSecureFlag() {
        val secure = current?.incognito == true || (switcherOpen && tabs.any { it.incognito })
        if (secure) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }

    private var urlTextDefault: android.content.res.ColorStateList? = null
    private var urlHintDefault: android.content.res.ColorStateList? = null
    private val incognitoBarColor = 0xFF3C4043.toInt()
    private val incognitoTextColor = 0xFFE8EAED.toInt()

    /** 시크릿 탭이면 주소창을 어둡게, 아니면 원래대로 */
    private fun applyIncognitoUi(on: Boolean) {
        if (urlTextDefault == null) {
            urlTextDefault = urlBar.textColors
            urlHintDefault = urlBar.hintTextColors
        }
        urlBar.backgroundTintList = if (on) android.content.res.ColorStateList.valueOf(incognitoBarColor) else null
        urlBar.setTextColor(if (on) android.content.res.ColorStateList.valueOf(incognitoTextColor) else urlTextDefault)
        urlBar.setHintTextColor(if (on) android.content.res.ColorStateList.valueOf(0xFF9AA0A6.toInt()) else urlHintDefault)
        homeTagline.text = if (on) "시크릿 탭 · 방문 기록과 쿠키가 저장되지 않아요" else homeTaglineDefault
    }

    private fun createTab(
        url: String?,
        select: Boolean = true,
        opener: BrowserTab? = null,
        home: Boolean = false,
        incognito: Boolean = false,
        lazy: Boolean = false
    ): BrowserTab {
        // 시크릿 탭에서 연 링크·팝업도 시크릿으로 이어진다
        val incog = incognito || opener?.incognito == true
        val tab = BrowserTab()
        tab.incognito = incog
        tab.isHome = home
        if (prefs.desktopSite || opener?.desktop == true) tab.desktop = true
        tab.lazyInit = {
            tab.webView = if (incog) newIncognitoWebView()
            else spareWebView?.also { spareWebView = null } ?: NestedWebView(this)
            tab.webView.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            configure(tab)
            if (tab.desktop) applyUserAgent(tab.webView, true)
            // 새 탭은 홈 화면을 웹 기록의 첫 항목으로 가진다 → 첫 페이지에서 뒤로가기를 하면 홈으로 돌아온다
            if (home) tab.webView.loadDataWithBaseURL(HOME_URL, HOME_HTML, "text/html", "utf-8", HOME_URL)
        }
        if (!lazy) tab.webView
        // 링크/팝업으로 열린 탭은 연 탭 바로 옆에 두고, 같은 그룹에 넣는다.
        tab.opener = opener
        val at = if (opener != null) tabs.indexOf(opener) else -1
        if (opener != null && at >= 0) {
            if (!incog) tab.groupId = opener.groupId
            tabs.add(at + 1, tab)
        } else {
            tabs.add(tab)
        }
        if (select) selectTab(tab)
        if (url != null) {
            prefetchDns(url)
            tab.webView.loadUrl(url)
        }
        updateTabCount()
        prepareSpareWebView()
        return tab
    }

    private fun selectTab(tab: BrowserTab) {
        val alreadyCurrent = current === tab
        if (!alreadyCurrent) closeFind()
        current?.let {
            // 탭 화면의 카드에 보여줄 미리보기를 남겨 둔다 (탭 화면이 열려 있을 땐 이미 찍어 둠)
            if (it !== tab && !switcherOpen) it.thumb = captureContent()
            webContainer.removeView(it.webView)
            // 다른 탭으로 옮겨도 이전 탭을 멈추지 않는다 (영상·소리·스크립트가 계속 동작)
            // 소리·영상이 나오는 중이면 화면 뒤의 보이지 않는 칸에 계속 붙여 둔다 (떼어 놓으면 멈추는 경우가 있다)
            if (it !== tab) parkIfPlaying(it)
        }
        current = tab
        scrollAcc = 0
        webContainer.reset()
        setBarsHidden(false)
        groupOf(tab)?.collapsed = false
        unparkWebView(tab)
        webContainer.addView(tab.webView)
        pageScrollBar.bind(if (tab.isHome) null else tab.webView)
        Motion.cancel(tab.webView)
        if (switcherOpen || alreadyCurrent) {
            // 탭 화면에서 고른 경우: 카드가 펼쳐지는 전환이 대신 보여주므로 여기선 바로 표시
            // 이미 보고 있는 탭을 다시 고른 경우: 페이드 없이 그대로 둔다
            tab.webView.alpha = 1f
            tab.webView.scaleX = 1f
            tab.webView.scaleY = 1f
        } else {
            tab.webView.alpha = 0f
            tab.webView.scaleX = 0.97f
            tab.webView.scaleY = 0.97f
            Motion.spring(tab.webView, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_X, 1f, 260f, 0.8f)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_Y, 1f, 260f, 0.8f)
        }
        tab.pendingUrl?.let { u ->
            tab.pendingUrl = null
            tab.isHome = false
            tab.stoppedByHome = false
            tab.webView.loadUrl(u)
        }
        tab.webView.onResume()
        tab.paused = false
        tab.webView.requestFocus()
        updateUi()
    }

    /**
     * @param quitIfLast 사용자가 직접 마지막 탭을 닫은 경우 true: 탭을 비운 뒤 앱을 끈다.
     *   (페이지 스크립트가 닫는 경우 등은 false 로 두어 앱이 갑자기 꺼지지 않게 한다)
     */
    private fun closeTab(tab: BrowserTab, quitIfLast: Boolean = false) {
        val wasLast = tabs.size == 1
        // 마지막 탭이 시크릿이면 일반 새 탭을 하나 만들어 두고 시크릿 탭을 닫는다
        if (tabs.size == 1 && tab.incognito) createTab(null, select = false, home = true)
        if (tabs.size == 1) {
            tab.groupId = 0
            pruneEmptyGroups()
            tab.isHome = true
            if (tab === current) pageScrollBar.bind(null)
            tab.redirectSources.clear()
            tab.thumb = null
            tab.mediaFrames.clear()
            onMediaChanged()
            tab.webView.stopLoading()
            tab.favicon = null
            tab.pendingUrl = null
            tab.pendingTitle = null
            // 이미 홈 항목이면 기록만 비운다. 아니면 홈을 불러오고, 다 불러와지면 기록을 비운다
            if (tab.webView.url == HOME_URL) tab.webView.clearHistory()
            else loadHome(tab, clear = true)
            updateUi()
            scheduleStripRefresh()
            if (quitIfLast && wasLast) finishAndRemoveTask()
            return
        }
        val index = tabs.indexOf(tab)
        tabs.remove(tab)
        tabs.forEach { if (it.opener === tab) it.opener = null }
        if (tab === current) {
            webContainer.removeView(tab.webView)
            current = null
            // 링크로 열린 탭을 닫으면 그 탭을 연 탭으로 돌아간다.
            val next = tab.opener?.takeIf { it in tabs } ?: tabs[minOf(index, tabs.size - 1)]
            selectTab(next)
        }
        tab.mediaFrames.clear()
        tab.lazyInit = null
        tab.liveWebView?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading(); it.destroy()
        }
        if (tab.incognito) purgeIncognitoIfUnused()
        pruneEmptyGroups()
        updateTabCount()
        onMediaChanged()
        if (quitIfLast && wasLast) finishAndRemoveTask()
    }

    private fun updateTabCount() {
        val n = tabs.size
        val text = if (n > 99) "99+" else n.toString()
        for (tv in listOf(tabCount, tabCountBottom, stripTabCount)) {
            if (tv.text.toString() != text) {
                tv.text = text
                // 자리수가 늘어나도 상자 안에 딱 맞도록 글자 크기 조절
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (n > 99) 8f else if (n >= 10) 10f else 12f)
                Motion.pop(tv)
            }
        }
        scheduleStripRefresh()
    }

    // ───────────────────────── 탭 그룹 ─────────────────────────

    private fun groupOf(tab: BrowserTab): TabGroup? =
        if (tab.groupId == 0) null else groups.firstOrNull { it.id == tab.groupId }

    private fun nextGroupColor(): Int = TabGroup.COLORS[groups.size % TabGroup.COLORS.size]

    private fun defaultGroupName(): String = "그룹 $nextGroupId"

    private fun createGroup(name: String, color: Int): TabGroup {
        val g = TabGroup(nextGroupId++, name, color)
        groups.add(g)
        return g
    }

    /** 탭이 하나도 없는 그룹은 자동으로 사라진다. */
    private fun pruneEmptyGroups() {
        groups.removeAll { g -> tabs.none { it.groupId == g.id } }
    }

    /** group == null 이면 그룹에서 빼낸다. 그룹으로 넣을 때는 그 그룹의 마지막 탭 바로 뒤로 옮겨 붙어 있게 한다. */
    private fun moveToGroup(tab: BrowserTab, group: TabGroup?) {
        if (tab.incognito && group != null) {
            toast("시크릿 탭은 그룹에 넣을 수 없어요")
            return
        }
        if (group == null) {
            tab.groupId = 0
        } else {
            val old = tabs.indexOf(tab)
            tabs.remove(tab)
            val last = tabs.indexOfLast { it.groupId == group.id }
            tab.groupId = group.id
            if (last >= 0) tabs.add(last + 1, tab) else tabs.add(old.coerceIn(0, tabs.size), tab)
        }
        pruneEmptyGroups()
    }

    private fun ungroup(group: TabGroup) {
        tabs.filter { it.groupId == group.id }.forEach { it.groupId = 0 }
        groups.remove(group)
    }

    private fun closeGroup(group: TabGroup) {
        tabs.filter { it.groupId == group.id }.forEach { closeTab(it) }
        pruneEmptyGroups()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** 그룹 만들기 / 편집 대화상자 (이름 + 색상). 위쪽 미리보기로 탭 줄에 보일 모습을 바로 확인한다. */
    private fun showGroupEditor(existing: TabGroup?, onSave: (String, Int) -> Unit) {
        val view = layoutInflater.inflate(R.layout.dialog_group, null)
        val et = view.findViewById<EditText>(R.id.etGroupName)
        val grid = view.findViewById<GridLayout>(R.id.colorGrid)
        val preview = view.findViewById<TextView>(R.id.groupPreview)
        var selected = existing?.color ?: nextGroupColor()
        et.setText(existing?.name ?: defaultGroupName())
        et.setSelection(et.text.length)

        fun updatePreview() {
            preview.text = et.text.toString().trim().ifEmpty { existing?.name ?: defaultGroupName() }
            preview.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(selected)
            }
        }

        fun renderColors(popColor: Int? = null) {
            grid.removeAllViews()
            TabGroup.COLORS.forEach { c ->
                val swatch = TextView(this)
                swatch.gravity = android.view.Gravity.CENTER
                swatch.textSize = 16f
                swatch.setTextColor(0xFFFFFFFF.toInt())
                swatch.contentDescription = "색상 선택"
                swatch.text = if (c == selected) "✓" else ""
                swatch.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                }
                swatch.layoutParams = GridLayout.LayoutParams().apply {
                    width = dp(40)
                    height = dp(40)
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                }
                swatch.setOnClickListener {
                    selected = c
                    renderColors(c)
                    updatePreview()
                }
                grid.addView(swatch)
                if (c == popColor) Motion.pop(swatch, 0.7f)
            }
        }
        renderColors()
        updatePreview()
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updatePreview() }
            override fun afterTextChanged(s: Editable?) {}
        })

        MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "새 그룹" else "그룹 편집")
            .setView(view)
            .setNegativeButton("취소", null)
            .setPositiveButton(if (existing == null) "만들기" else "저장") { _, _ ->
                val name = et.text.toString().trim().ifEmpty { existing?.name ?: defaultGroupName() }
                onSave(name, selected)
            }
            .show()
    }

    /** 북마크할 수 있는 탭의 웹 주소 (홈 화면이거나 웹페이지가 아니면 null). 아직 불러오지 않은 복원 탭은 저장된 주소를 쓴다. */
    private fun tabBookmarkUrl(tab: BrowserTab): String? {
        if (tab.isHome) return null
        val u = tab.liveWebView?.url ?: tab.pendingUrl
        return u?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    /**
     * 화면에 보이는 순서대로 한 덩어리씩 센다: 그룹에 속하지 않은 탭 하나, 또는 그룹 하나(안의 탭들).
     * 그룹에 속한 탭은 그룹 안에서만, 그룹 밖의 탭은 덩어리(탭/그룹 상자) 단위로 움직인다.
     */
    private fun tabUnits(): List<List<BrowserTab>> {
        val units = ArrayList<List<BrowserTab>>()
        val seen = HashSet<Int>()
        for (t in tabs) {
            val g = groupOf(t)
            if (g == null) units.add(listOf(t))
            else if (seen.add(g.id)) units.add(tabs.filter { it.groupId == g.id })
        }
        return units
    }

    /** 탭을 앞(-1)/뒤(+1)로 한 칸 옮긴다 (데이터만). 그룹 안의 탭은 그룹 안에서, 그룹에 없는 탭은 그룹 덩어리를 통째로 건너뛴다. */
    private fun reorderTab(tab: BrowserTab, dir: Int) {
        val g = groupOf(tab)
        if (g != null) {
            val m = tabs.filter { it.groupId == g.id }
            val other = m.getOrNull(m.indexOf(tab) + dir) ?: return
            val i = tabs.indexOf(tab)
            val j = tabs.indexOf(other)
            tabs[i] = other
            tabs[j] = tab
        } else {
            val units = tabUnits()
            val u = units.indexOfFirst { it.size == 1 && it[0] === tab && groupOf(it[0]) == null }
            if (u < 0) return
            val neighbor = units.getOrNull(u + dir) ?: return
            tabs.remove(tab)
            if (dir < 0) tabs.add(tabs.indexOf(neighbor.first()), tab)
            else tabs.add(tabs.indexOf(neighbor.last()) + 1, tab)
        }
    }

    // ───────────────────────── 끌어서 탭 순서 바꾸기 ─────────────────────────

    /**
     * 길게 눌러 끌기 공통 터치 처리.
     * 길게 누르면 끌기가 시작되고(onStart 가 true), 손가락을 움직이는 동안 onMove, 떼면 onEnd 가 불린다.
     * 끌지 않고 그냥 뗐으면 onEnd 의 moved 가 false 라서 호출한 쪽이 메뉴를 띄우면 된다.
     * pressedScale 이 있으면 누르는 동안 카드가 쏙 들어가는 효과도 같이 준다.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun bindDragGesture(
        v: View,
        pressedScale: Float?,
        onStart: (rawX: Float, rawY: Float) -> Boolean,
        onMove: (rawX: Float, rawY: Float) -> Unit,
        onEnd: (moved: Boolean, canceled: Boolean) -> Unit,
        // 옆으로 밀어서 치우는 동작 (주면 켜진다). 충분히 밀거나 빠르게 튕기면 불리고, 아니면 제자리로 돌아온다.
        onSwipeDismiss: (() -> Unit)? = null,
        canSwipe: () -> Boolean = { true }
    ) {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        var dragging = false
        var moved = false
        var swiping = false
        var crossed = false
        var vt: android.view.VelocityTracker? = null
        var downX = 0f
        var downY = 0f
        var lastX = 0f
        var lastY = 0f

        fun releaseTracker() {
            vt?.recycle()
            vt = null
        }
        // 놓았을 때 제자리로: 손가락 속도를 이어받아 살짝 튕기며 돌아온다
        fun springBack(view: View, vx: Float = 0f) {
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.7f)
                .setStartVelocity(vx)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, 0f, 420f, 0.7f)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 500f, 1f)
        }
        // 놓았을 때 치우기: 손가락이 움직이던 속도 그대로 날아가며 투명해지고, 거의 사라지면 목록을 다시 그려 빈자리를 메운다
        fun flyOff(view: View, dir: Float, vx: Float) {
            val w = view.width.toFloat().coerceAtLeast(1f)
            if (!Motion.enabled(view.context)) {
                onSwipeDismiss?.invoke()
                return
            }
            var fired = false
            fun fire() {
                if (fired) return
                fired = true
                onSwipeDismiss?.invoke()
            }
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, dir * w * 1.5f, 320f, 1f) { fire() }
                .setStartVelocity(vx)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, dir * 12f, 260f, 1f)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 0f, 520f, 1f) { fire() }
        }
        fun finishSwipe(view: View, dx: Float, vx: Float) {
            val w = view.width.toFloat().coerceAtLeast(1f)
            val sameDir = vx * dx > 0f
            val flung = sameDir && Math.abs(vx) > 1200f && Math.abs(dx) > w * 0.1f
            if (Math.abs(dx) > w * 0.4f || flung) {
                flyOff(view, if (dx > 0) 1f else -1f, vx)
            } else {
                springBack(view, vx)
            }
        }

        val handler: (View, MotionEvent) -> Boolean = { view, e ->
            lastX = e.rawX
            lastY = e.rawY
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    moved = false
                    swiping = false
                    crossed = false
                    downX = e.rawX
                    downY = e.rawY
                    if (onSwipeDismiss != null) {
                        releaseTracker()
                        vt = android.view.VelocityTracker.obtain().also { it.addMovement(e) }
                    }
                    false
                }
                MotionEvent.ACTION_MOVE -> when {
                    dragging -> {
                        if (!moved && Math.hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > slop) moved = true
                        onMove(e.rawX, e.rawY)
                        true
                    }
                    onSwipeDismiss != null -> {
                        vt?.addMovement(e)
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        // 가로로 뚜렷하게 움직일 때만 밀기로 본다 (세로 스크롤과 구분)
                        if (!swiping && canSwipe() && Math.abs(dx) > slop * 2 && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            swiping = true
                            view.cancelLongPress()
                            view.isPressed = false
                            view.parent?.requestDisallowInterceptTouchEvent(true)
                            // 이전에 돌던 이동/투명도 스프링을 멈추고 손가락이 직접 움직이게 한다 (크기는 눌린 상태 유지)
                            Motion.cancel(view)
                            view.scaleX = pressedScale ?: 1f
                            view.scaleY = pressedScale ?: 1f
                        }
                        if (swiping) {
                            val w = view.width.toFloat().coerceAtLeast(1f)
                            view.translationX = dx
                            // 밀수록 살짝 기울고 옅어진다
                            view.rotation = (dx / w * 10f).coerceIn(-12f, 12f)
                            view.alpha = (1f - Math.abs(dx) / (w * 1.2f)).coerceIn(0.2f, 1f)
                            val past = Math.abs(dx) > view.width * 0.4f
                            if (past != crossed) {
                                crossed = past
                                view.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                            }
                            true
                        } else false
                    }
                    else -> false
                }
                MotionEvent.ACTION_UP -> when {
                    dragging -> {
                        dragging = false
                        view.isPressed = false
                        onEnd(moved, false)
                        true
                    }
                    swiping -> {
                        swiping = false
                        vt?.let {
                            it.addMovement(e)
                            it.computeCurrentVelocity(1000)
                            finishSwipe(view, e.rawX - downX, it.xVelocity)
                        } ?: springBack(view)
                        releaseTracker()
                        true
                    }
                    else -> {
                        releaseTracker()
                        false
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        onEnd(moved, true)
                    }
                    if (swiping) {
                        swiping = false
                        springBack(view)
                    }
                    releaseTracker()
                    false
                }
                else -> false
            }
        }
        v.setOnLongClickListener { view ->
            dragging = onStart(lastX, lastY)
            if (dragging) {
                view.isPressed = false
                // 끄는 동안 스크롤 뷰가 터치를 가로채지 않게 한다
                view.parent?.requestDisallowInterceptTouchEvent(true)
            }
            true
        }
        if (pressedScale != null) Motion.pressable(v, pressedScale, handler)
        else v.setOnTouchListener { view, e -> handler(view, e) }
    }

    // ── 상단 탭 줄 (가로) ──

    private var stripDrag: StripChip? = null
    private var stripGrab = 0f
    private var stripRawX = 0f
    private var stripSwapped = false

    /** 끌고 있는 탭이 줄의 양 끝에 가까워지면 탭 줄이 알아서 그쪽으로 스크롤된다 */
    private val stripAutoScroll = object : Runnable {
        override fun run() {
            if (stripDrag == null) return
            val loc = IntArray(2)
            tabStripScroll.getLocationOnScreen(loc)
            val rel = stripRawX - loc[0]
            val edge = dp(56).toFloat()
            val w = tabStripScroll.width
            val dx = when {
                rel < edge -> -(edge - rel) / edge * dp(14)
                rel > w - edge -> (rel - (w - edge)) / edge * dp(14)
                else -> 0f
            }
            if (dx != 0f) {
                val step = if (dx > 0) maxOf(1, dx.toInt()) else minOf(-1, dx.toInt())
                val before = tabStripScroll.scrollX
                tabStripScroll.scrollBy(step, 0)
                if (tabStripScroll.scrollX != before) updateStripDrag()
            }
            tabStripScroll.postOnAnimation(this)
        }
    }

    private val stripClipSaved = ArrayList<Pair<ViewGroup, Boolean>>()

    /** 끄는 동안 탭 줄과 그 바깥 레이아웃의 '자식 영역 밖 잘라내기'를 풀어, 끄는 탭이 가장자리에서 잘리지 않게 한다 */
    private fun setStripUnclipped(unclipped: Boolean) {
        if (unclipped) {
            var p: android.view.ViewParent? = tabStrip
            while (p is ViewGroup) {
                stripClipSaved.add(p to p.clipChildren)
                p.clipChildren = false
                p = p.parent
            }
        } else {
            stripClipSaved.forEach { (g, old) -> g.clipChildren = old }
            stripClipSaved.clear()
        }
    }

    private fun startStripDrag(tab: BrowserTab, rawX: Float): Boolean {
        val c = stripChips[tab] ?: return false
        if (stripDrag != null) return false
        stripDrag = c
        stripSwapped = false
        stripRawX = rawX
        val loc = IntArray(2)
        tabStrip.getLocationOnScreen(loc)
        stripGrab = rawX - loc[0] - c.view.left
        c.view.translationZ = dp(5).toFloat()
        // 탭 줄을 올리지 않는다: 툴바가 탭 줄 위에 그려져서 끄는 탭의 그림자가 탭 줄 아래(툴바 쪽)로 번지지 않는다
        c.bg?.alpha = 255 // 선택되지 않은 탭도 끄는 동안은 카드처럼 보이게
        setStripUnclipped(true)
        tabStripScroll.postOnAnimation(stripAutoScroll)
        return true
    }

    /** 끌고 있는 탭이 손가락을 따라가는 위치 (탭 줄 안쪽으로 제한) */
    private fun stripDragWant(c: StripChip): Float {
        val maxLeft = (tabStrip.width - c.view.width).coerceAtLeast(0)
        return stripDragRaw().coerceIn(0f, maxLeft.toFloat())
    }

    /** 손가락 위치만으로 계산한 탭의 왼쪽 위치 (탭 줄 밖으로 나가도 제한하지 않음) */
    private fun stripDragRaw(): Float {
        val loc = IntArray(2)
        tabStrip.getLocationOnScreen(loc)
        return stripRawX - loc[0] - stripGrab
    }

    /** dir 쪽으로 이웃한 덩어리(탭 하나, 또는 그룹 알약 + 그 탭들)의 뷰들 */
    private fun stripNeighbor(tab: BrowserTab, dir: Int): List<View>? {
        val g = groupOf(tab)
        if (g != null) {
            val m = tabs.filter { it.groupId == g.id }
            val n = m.getOrNull(m.indexOf(tab) + dir) ?: return null
            return stripChips[n]?.view?.let { listOf(it) }
        }
        val units = tabUnits()
        val u = units.indexOfFirst { it.size == 1 && it[0] === tab && groupOf(it[0]) == null }
        if (u < 0) return null
        val unit = units.getOrNull(u + dir) ?: return null
        val g2 = groupOf(unit[0])
        val views = ArrayList<View>()
        if (g2 != null) stripPills[g2.id]?.let { views.add(it) }
        if (g2 == null || !g2.collapsed) unit.forEach { t -> stripChips[t]?.view?.let { views.add(it) } }
        return views.takeIf { it.isNotEmpty() }
    }

    private fun stripDesiredOrder(): List<View> {
        val out = ArrayList<View>()
        val seen = HashSet<Int>()
        for (t in tabs) {
            val g = groupOf(t)
            if (g != null && seen.add(g.id)) stripPills[g.id]?.let { out.add(it) }
            if (g != null && g.collapsed) continue
            stripChips[t]?.view?.let { out.add(it) }
        }
        return out
    }

    private fun updateStripDrag() {
        val c = stripDrag ?: return
        if (stripChips[c.tab] !== c || c.view.parent == null) {
            stripDrag = null
            return
        }
        val v = c.view
        val want = stripDragWant(c)
        v.translationX = want - v.left
        // 순서를 바꿀지는 제한하기 전의 손가락 위치로 판단한다.
        // (제한한 위치로 보면 맨 앞/맨 뒤 탭과는 중심이 절대 넘어가지 못해 첫 번째 자리로 옮길 수 없었다)
        val cx = stripDragRaw() + v.width / 2f
        var dir = 0
        stripNeighbor(c.tab, 1)?.last()?.let { e ->
            if (e.parent != null && cx > e.left + e.width / 2f) dir = 1
        }
        if (dir == 0) {
            stripNeighbor(c.tab, -1)?.first()?.let { e ->
                if (e.parent != null && cx < e.left + e.width / 2f) dir = -1
            }
        }
        if (dir != 0) swapStripDrag(c, dir)
    }

    /** 데이터 순서를 바꾸고, 끌고 있는 뷰는 그대로 둔 채 나머지 뷰들만 새 순서로 다시 끼운다 (이웃 탭은 미끄러지듯 자리를 옮긴다) */
    private fun swapStripDrag(c: StripChip, dir: Int) {
        val v = c.view
        val oldLeft = HashMap<View, Int>()
        for (i in 0 until tabStrip.childCount) {
            val ch = tabStrip.getChildAt(i)
            if (ch !== v) oldLeft[ch] = ch.left
        }
        reorderTab(c.tab, dir)
        stripSwapped = true
        val desired = stripDesiredOrder()
        val di = desired.indexOf(v)
        if (di < 0) return
        val others = desired.filter { it !== v }
        others.forEach { tabStrip.removeView(it) }
        var at = tabStrip.indexOfChild(v)
        for (i in 0 until di) {
            tabStrip.addView(desired[i], at)
            at++
        }
        var after = at + 1
        for (i in di + 1 until desired.size) {
            tabStrip.addView(desired[i], after)
            after++
        }
        tabStrip.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                tabStrip.viewTreeObserver.removeOnPreDrawListener(this)
                others.forEach { ov ->
                    val o = oldLeft[ov] ?: return@forEach
                    val dx = o - ov.left
                    if (dx != 0) {
                        ov.animate().cancel()
                        ov.translationX = dx + ov.translationX
                        ov.animate().translationX(0f).setDuration(180).setInterpolator(stripEase).start()
                    }
                }
                if (stripDrag === c) v.translationX = stripDragWant(c) - v.left
                return true
            }
        })
    }

    private fun endStripDrag(moved: Boolean, canceled: Boolean) {
        val c = stripDrag ?: return
        stripDrag = null
        tabStripScroll.removeCallbacks(stripAutoScroll)
        val v = c.view
        v.animate().translationX(0f).setDuration(160).setInterpolator(stripEase)
            .withEndAction {
                v.translationZ = 0f
                if (stripDrag == null) {
                    setStripUnclipped(false)
                }
            }.start()
        applyChipSelection(c)
        if (stripSwapped) saveTabs()
        scheduleStripRefresh()
        // 끌지 않고 그냥 뗐으면 예전처럼 탭 메뉴
        if (!canceled && !moved && !stripSwapped) showTabMenu(c.tab, c.view) { scheduleStripRefresh() }
    }

    // ── 탭 화면 (카드 격자) ──

    private class SwitcherDrag(
        val tab: BrowserTab,
        val view: View,
        val scope: List<BrowserTab>,
        val from: Int,
        val slots: List<Rect>,   // 스크롤 내용 기준 좌표의 각 카드 자리
        val grabX: Float,        // 카드 왼쪽 위 모서리에서 손가락까지의 거리
        val grabY: Float,
        val boxes: Map<Int, Rect>  // 이 탭을 넣을 수 있는 그룹 상자들의 자리
    ) {
        var targetGroup = 0
        var to = from
        var rawX = 0f
        var rawY = 0f
    }

    private var swDrag: SwitcherDrag? = null

    private val swAutoScroll = object : Runnable {
        override fun run() {
            val d = swDrag ?: return
            val loc = IntArray(2)
            tabScroll.getLocationOnScreen(loc)
            val top = loc[1]
            val bottom = top + tabScroll.height
            val edge = dp(80).toFloat()
            val dy = when {
                d.rawY < top + edge -> -(top + edge - d.rawY) / edge * dp(18)
                d.rawY > bottom - edge -> (d.rawY - (bottom - edge)) / edge * dp(18)
                else -> 0f
            }
            if (dy != 0f) {
                val step = if (dy > 0) maxOf(1, dy.toInt()) else minOf(-1, dy.toInt())
                val before = tabScroll.scrollY
                tabScroll.scrollBy(0, step)
                if (tabScroll.scrollY != before) updateSwitcherDrag()
            }
            tabScroll.postOnAnimation(this)
        }
    }

    /** 끄는 카드가 이웃 줄·상자 위에 그려지도록 위로 띄운다 */
    private fun liftCard(v: View, lift: Boolean) {
        v.translationZ = if (lift) dp(10).toFloat() else 0f
        var p = v.parent
        while (p is ViewGroup && p !== tabScroll) {
            // 카드 줄과 목록은 평소에도 잘라내기를 끈 상태로 둔다
            p.clipChildren = if (lift) false else !(p === tabList || p.tag == CARD_ROW_TAG)
            if (p !== tabList) {
                // 그룹 상자(배경 있음)는 둥근 모서리 클립을 잠깐 풀어 카드가 상자 밖으로 나갈 수 있게 한다
                if (p.background != null) p.clipToOutline = !lift
                p.translationZ = if (lift) dp(10).toFloat() else 0f
            }
            p = p.parent
        }
        // 스크롤 뷰도 자식(tabList)의 영역 밖은 잘라 버리므로 같이 풀어 준다 (안 그러면 카드가 첫 줄 아래에서 잘린다)
        tabScroll.clipChildren = false
    }

    /** 스크롤 내용 기준 좌표에서의 뷰 자리 */
    private fun contentRect(v: View): Rect {
        var x = 0
        var y = 0
        var c: View = v
        while (c !== tabScroll) {
            x += c.left
            y += c.top
            c = c.parent as? View ?: break
        }
        return Rect(x, y, x + v.width, y + v.height)
    }

    private fun setBoxHighlight(groupId: Int, on: Boolean) {
        if (groupId == 0) return
        val s = if (on) 1.03f else 1f
        switcherBoxes[groupId]?.animate()?.scaleX(s)?.scaleY(s)?.setDuration(140)?.start()
    }

    private fun startSwitcherDrag(tab: BrowserTab, rawX: Float, rawY: Float): Boolean {
        if (switcherBusy || groupToggling || swDrag != null) return false
        val g = groupOf(tab)
        // 같은 그룹 안에서, 또는 그룹에 속하지 않은 탭끼리 순서를 바꾼다
        val scope = tabs.filter { groupOf(it)?.id == g?.id && switcherRows.containsKey(it) }
        val from = scope.indexOf(tab)
        val view = switcherRows[tab]
        if (from < 0 || view == null) return false
        val slots = scope.map { t -> contentRect(switcherRows[t]!!) }
        // 시크릿 탭은 그룹에 넣을 수 없다. 자기 그룹 상자는 제외.
        val boxes = if (tab.incognito) emptyMap() else
            switcherBoxes.filter { it.key != tab.groupId }.mapValues { contentRect(it.value) }
        val loc = IntArray(2)
        tabScroll.getLocationOnScreen(loc)
        val fx = rawX - loc[0]
        val fy = rawY - loc[1] + tabScroll.scrollY
        val s = slots[from]
        swDrag = SwitcherDrag(tab, view, scope, from, slots, fx - s.left, fy - s.top, boxes).also {
            it.rawX = rawX
            it.rawY = rawY
        }
        liftCard(view, true)
        Motion.spring(view, DynamicAnimation.SCALE_X, 1.06f, 600f, 0.7f)
        Motion.spring(view, DynamicAnimation.SCALE_Y, 1.06f, 600f, 0.7f)
        tabScroll.postOnAnimation(swAutoScroll)
        return true
    }

    private fun updateSwitcherDrag() {
        val d = swDrag ?: return
        if (switcherRows[d.tab] !== d.view || d.view.parent == null) {
            swDrag = null
            return
        }
        val loc = IntArray(2)
        tabScroll.getLocationOnScreen(loc)
        val fx = d.rawX - loc[0]
        val fy = d.rawY - loc[1] + tabScroll.scrollY
        val s = d.slots[d.from]
        val left = fx - d.grabX
        val top = fy - d.grabY
        d.view.translationX = left - s.left
        d.view.translationY = top - s.top
        val cx = (left + s.width() / 2f).toInt()
        val cy = (top + s.height() / 2f).toInt()
        // 다른 그룹 상자 위로 가져가면 '그룹에 넣기' 대상이 되어 상자가 커지며 강조된다
        val gid = d.boxes.entries.firstOrNull { it.value.contains(cx, cy) }?.key ?: 0
        if (gid != d.targetGroup) {
            setBoxHighlight(d.targetGroup, false)
            d.targetGroup = gid
            setBoxHighlight(gid, true)
            if (gid != 0 && d.to != d.from) {
                d.to = d.from
                previewSwitcherOrder(d)
            }
        }
        if (gid != 0) return
        val j = d.slots.indexOfFirst { it.contains(cx, cy) }
        if (j >= 0 && j != d.to) {
            d.to = j
            previewSwitcherOrder(d)
        }
    }

    private fun switcherOrder(d: SwitcherDrag): List<BrowserTab> =
        d.scope.toMutableList().also { it.add(d.to, it.removeAt(d.from)) }

    /** 놓으면 이렇게 된다는 걸 미리 보여 주기: 나머지 카드들이 새 자리로 비켜 준다 */
    private fun previewSwitcherOrder(d: SwitcherDrag) {
        val order = switcherOrder(d)
        d.scope.forEachIndexed { k, t ->
            if (k == d.from) return@forEachIndexed
            val a = d.slots[k]
            val b = d.slots[order.indexOf(t)]
            switcherRows[t]?.animate()
                ?.translationX((b.left - a.left).toFloat())
                ?.translationY((b.top - a.top).toFloat())
                ?.setDuration(180)?.start()
        }
    }

    private fun endSwitcherDrag(moved: Boolean, canceled: Boolean) {
        val d = swDrag ?: return
        swDrag = null
        tabScroll.removeCallbacks(swAutoScroll)
        val v = d.view
        setBoxHighlight(d.targetGroup, false)
        if (!canceled && d.targetGroup != 0 && switcherRows[d.tab] === v && v.parent != null) {
            val g = groups.firstOrNull { it.id == d.targetGroup }
            if (g != null) {
                moveToGroup(d.tab, g)
                saveTabs()
                d.scope.forEach { t -> if (t !== d.tab) switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(120)?.start() }
                v.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setDuration(140).start()
                ui.postDelayed({
                    if (switcherOpen) {
                        liftCard(v, false)
                        refreshSwitcher(false)
                    }
                }, 150)
                return
            }
        }
        Motion.spring(v, DynamicAnimation.SCALE_X, 1f, 480f, 0.6f)
        Motion.spring(v, DynamicAnimation.SCALE_Y, 1f, 480f, 0.6f)
        val live = switcherRows[d.tab] === v && v.parent != null
        if (canceled || !live || d.to == d.from) {
            d.scope.forEach { t ->
                switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(180)?.start()
            }
            v.postDelayed({ liftCard(v, false) }, 220)
            // 끌지 않고 그냥 뗐으면 예전처럼 탭 메뉴
            if (!canceled && live && !moved) showTabMenu(d.tab) { refreshSwitcher(false) }
            return
        }
        // 새 순서를 저장: 이 범위의 탭들이 차지하던 자리에 새 순서대로 다시 넣는다 (다른 탭·그룹은 그대로)
        val order = switcherOrder(d)
        val idx = tabs.indices.filter { tabs[it] in d.scope }
        idx.forEachIndexed { n, i -> tabs[i] = order[n] }
        saveTabs()
        val a = d.slots[d.from]
        val b = d.slots[d.to]
        v.animate().translationX((b.left - a.left).toFloat()).translationY((b.top - a.top).toFloat())
            .setDuration(180).start()
        ui.postDelayed({
            if (switcherOpen) {
                liftCard(v, false)
                refreshSwitcher(false)
            }
        }, 200)
    }

    /** anchor 가 있으면(상단 탭 줄) 그 탭 바로 아래에 붙여 띄우고, 없으면 화면 가운데 팝업 */
    private fun showTabMenu(tab: BrowserTab, anchor: View? = null, onChanged: () -> Unit) {
        val items = mutableListOf<Popup.Item>()
        val own = groupOf(tab)

        // 탭 음소거: 꾹 누른 그 탭의 소리만 끄고 켠다 (다른 탭에서 계속 재생되는 탭도 포함)
        items.add(
            Popup.Item(
                if (tab.muted) R.drawable.ic_volume_up else R.drawable.ic_volume_off,
                if (tab.muted) "탭 음소거 해제" else "탭 음소거",
                if (tab.muted) "이 탭의 소리를 다시 켭니다" else "이 탭의 소리를 끕니다"
            ) {
                setTabMuted(tab, !tab.muted)
                onChanged()
            }
        )

        // 꾹 누른 그 탭의 페이지를 북마크에 추가(이미 있으면 수정). 현재 보는 탭이 아니어도 된다.
        tabBookmarkUrl(tab)?.let { url ->
            val saved = prefs.findBookmark(url)
            val title = tab.liveWebView?.title?.takeIf { it.isNotBlank() } ?: tab.pendingTitle.orEmpty()
            items.add(
                Popup.Item(
                    if (saved != null) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border,
                    if (saved != null) "북마크 수정" else "북마크에 추가",
                    Uri.parse(url).host?.removePrefix("www.")
                ) {
                    ListUi.showBookmarkEditor(this, prefs, saved, url, title) { msg -> toast(msg) }
                }
            )
        }
        // 탭 위치는 메뉴가 아니라 탭을 길게 누른 채 끌어서 바꾼다
        items.add(Popup.Item(R.drawable.ic_add, "새 그룹 만들기", "이 탭을 새 그룹에 담습니다") {
            showGroupEditor(null) { name, color ->
                val g = createGroup(name, color)
                moveToGroup(tab, g)
                onChanged()
            }
        })
        groups.filter { it.id != tab.groupId }.forEach { g ->
            val n = tabs.count { it.groupId == g.id }
            items.add(Popup.Item(R.drawable.ic_tab, "'${g.name}' 그룹에 추가", "탭 ${n}개", dotColor = g.color) {
                moveToGroup(tab, g)
                onChanged()
            })
        }
        if (own != null) {
            items.add(Popup.Item(R.drawable.ic_close, "'${own.name}' 그룹에서 빼기", "탭은 그대로 남습니다") {
                moveToGroup(tab, null)
                onChanged()
            })
        }

        val subtitle = (if (own != null) "그룹: ${own.name}" else "그룹에 속해 있지 않음") +
            if (tab.muted) " · 음소거 중" else ""
        if (anchor != null && anchor.isAttachedToWindow) {
            Popup.menuAnchored(
                this, anchor,
                title = tabTitle(tab),
                subtitle = subtitle,
                headerIcon = R.drawable.ic_tab,
                headerColor = own?.color,
                items = items
            )
        } else {
            Popup.menu(
                this,
                title = tabTitle(tab),
                subtitle = subtitle,
                headerColor = own?.color,
                headerIcon = R.drawable.ic_tab,
                items = items
            )
        }
    }

    /** 탭을 음소거하거나 해제한다. 보고 있지 않은 탭, 화면 뒤에 붙여 둔 탭, iframe 안의 영상까지 모두 적용된다 */
    private fun setTabMuted(tab: BrowserTab, mute: Boolean) {
        tab.muted = mute
        tab.liveWebView?.evaluateJavascript(MediaScripts.MUTE_SYNC, null)
        toast(if (mute) "탭을 음소거했어요" else "탭 음소거를 해제했어요")
    }

    private fun showGroupMenu(group: TabGroup, inSwitcher: Boolean, onChanged: () -> Unit) {
        val n = tabs.count { it.groupId == group.id }
        val items = listOf(
            Popup.Item(R.drawable.ic_add, "이 그룹에 새 탭") {
                openNewTabAndFocus(tabs.lastOrNull { it.groupId == group.id })
                if (inSwitcher) closeTabSwitcher()
            },
            Popup.Item(
                R.drawable.ic_expand_more,
                if (group.collapsed) "그룹 펼치기" else "그룹 접기",
                if (group.collapsed) "숨겨 둔 탭을 다시 보여줍니다" else "탭을 한 줄로 접어 둡니다"
            ) {
                group.collapsed = !group.collapsed
                onChanged()
            },
            Popup.Item(R.drawable.ic_edit, "이름·색상 변경") {
                showGroupEditor(group) { name, color ->
                    group.name = name
                    group.color = color
                    onChanged()
                }
            },
            Popup.Item(R.drawable.ic_folder, "그룹 해제", "탭은 닫지 않고 그룹만 없앱니다") {
                ungroup(group)
                onChanged()
            },
            Popup.Item(R.drawable.ic_delete, "그룹의 탭 모두 닫기", "탭 ${n}개가 닫힙니다", danger = true) {
                Popup.confirm(
                    this, "탭 ${n}개를 닫을까요?",
                    "'${group.name}' 그룹의 탭이 모두 닫힙니다.", "모두 닫기", danger = true
                ) {
                    closeGroup(group)
                    onChanged()
                }
            }
        )
        Popup.menu(
            this,
            title = group.name,
            subtitle = "탭 ${n}개" + if (group.collapsed) " · 접힘" else "",
            headerColor = group.color,
            items = items
        )
    }

    // ───────────────────────── 태블릿 레이아웃 / 탭 스트립 ─────────────────────────

    /** 화면 폭(smallestScreenWidthDp) 600dp 이상이면 태블릿 레이아웃: 상단 탭 스트립 + 툴바에 내비게이션 */
    private fun applyLayoutMode(pip: Boolean = isInPictureInPictureModeCompat()) {
        val wide = resources.configuration.smallestScreenWidthDp >= 600
        expanded = wide
        // PiP 로 들어가면 화면 크기 변경 알림이 와서 이 함수가 불리는데, 그때 바를 다시 보이게 하면 안 된다
        if (pip && customView == null) {
            tabStripBar.visibility = View.GONE
            toolbarView.visibility = View.GONE
            bottomBar.visibility = View.GONE
            progressBar.visibility = View.GONE
            return
        }
        tabStripBar.visibility = if (wide) View.VISIBLE else View.GONE
        navGroup.visibility = if (wide) View.VISIBLE else View.GONE
        tabletActions.visibility = if (wide) View.VISIBLE else View.GONE
        tbMenu.visibility = if (wide) View.VISIBLE else View.GONE
        // 폰: 탭 버튼은 하단 바에 있다 / 태블릿: 주소창 오른쪽 툴바에 있다
        btnTabs.visibility = if (wide) View.VISIBLE else View.GONE
        bottomBar.visibility = if (wide) View.GONE else View.VISIBLE
        urlBar.layoutParams = urlBar.layoutParams.apply { height = dp(if (wide) 40 else 44) }
        urlBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (wide) 16f else 15f)
        // 폰 → 태블릿: 탭 줄이 방금 보이게 돼서 아직 배치 전(폭 0)이다. 배치가 끝난 뒤 실제 폭으로 탭 크기를 다시 계산한다.
        if (wide) {
            tabStripScroll.doOnLayout {
                lastStripViewportW = tabStripScroll.width
                refreshTabStrip()
                updateStripPlus()
            }
        }
        // 탭 전환 화면이 열려 있으면 새 화면 폭에 맞춰 열 수·카드 크기를 다시 계산한다
        if (switcherOpen) refreshSwitcher(false)
        // 폰 ↔ 태블릿 전환 시 숨김 상태 초기화 (남은 마진 때문에 바가 잘리는 것 방지)
        barsAnim?.cancel()
        barsStartRunnable?.let { webContainer.removeCallbacks(it) }
        barsStartRunnable = null
        barsLayoutHidden = false
        barsViewportReady = true
        barsGestureActive = false
        (webContainer.parent as? View)?.translationY = 0f
        barsFraction = 0f
        barsTarget = 0f
        for (v in listOf(tabStripBar, toolbarView)) {
            (v.layoutParams as? LinearLayout.LayoutParams)?.let { it.topMargin = 0; v.layoutParams = it }
        }
        (bottomBar.layoutParams as? LinearLayout.LayoutParams)?.let { it.bottomMargin = 0; bottomBar.layoutParams = it }
        for (v in listOf(tabStripBar, toolbarView, progressBar, bottomBar)) v.translationY = 0f
        barsSyncedTopH = -1
        homeView.setPadding(0, 0, 0, 0)
        browserUi.post { barsSyncFullLayout() }
        updateStatusBarColor()
        // 제목줄 통합 중이면 탭 줄이 보이는지에 따라 위 여백이 달라지므로 인셋을 다시 적용
        if (captionEdgeToEdge) (browserUi.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
    }

    // ───────────────────── 창 모드(프리폼) 제목줄 통합 ─────────────────────

    /**
     * 데스크톱/프리폼 창에서는 시스템이 제목줄(캡션 바)을 앱 위에 따로 그려서,
     * 탭 줄이 제목줄 아래 한 줄을 더 차지한다. 크롬처럼 탭 줄을 그 제목줄 자리에 그리도록
     * 캡션 바 인셋이 있을 때만 가장자리까지 그리기로 바꾼다. (폰·전체 화면에서는 아무것도 바뀌지 않는다)
     */
    private var captionEdgeToEdge = false
    private var captionActive = false
    private var captionTopApplied = -1
    private var captionStartApplied = -1
    private var captionEndApplied = -1

    private fun installCaptionIntegration() {
        if (Build.VERSION.SDK_INT < 30) return
        // Android 15+ (targetSdk 35): 가장자리까지 그리기가 기본이라 처음부터 인셋을 직접 처리한다
        if (Build.VERSION.SDK_INT >= 35) {
            captionEdgeToEdge = true
            enableCaptionEdgeToEdge()
            return
        }
        val decor = window.decorView
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(decor) { v, insets ->
            if (!captionEdgeToEdge &&
                insets.getInsets(WindowInsetsCompat.Type.captionBar()).top > 0
            ) {
                captionEdgeToEdge = true
                v.post { enableCaptionEdgeToEdge() }
            }
            androidx.core.view.ViewCompat.onApplyWindowInsets(v, insets)
        }
    }

    private fun enableCaptionEdgeToEdge() {
        val decor = window.decorView
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(decor, null)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // 데스크톱 창 제목줄을 투명하게 만들어야(APPEARANCE_TRANSPARENT_CAPTION_BAR_BACKGROUND = 1 shl 7, Android 15+)
        // 앱이 제목줄 자리에 그릴 수 있고 캡션 바 인셋도 들어온다. 탭 줄 배경이 밝으면 시스템 버튼은 어두운 색
        // (APPEARANCE_LIGHT_CAPTION_BARS = 1 shl 8).
        try {
            val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
            val transparent = 1 shl 7
            val light = 1 shl 8
            window.insetsController?.setSystemBarsAppearance(
                transparent or (if (night) 0 else light), transparent or light
            )
        } catch (_: Throwable) {}

        val root = findViewById<View>(R.id.browserUi)?.parent as? View ?: return
        statusBand = StatusBandDrawable(getColor(R.color.ev_surface), getColor(R.color.ev_surface)).also { root.background = it }
        updateStatusBarColor()
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val cap = insets.getInsets(WindowInsetsCompat.Type.captionBar())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // 제목줄이 있으면 위 여백은 0: 탭 줄이 그 자리를 쓴다. 없으면(전체 화면 등) 보통 시스템 바 여백.
            val stripInCaption = cap.top > 0 && captionHasWindowControls(insets, v.width, cap.top) &&
                tabStripBar.visibility == View.VISIBLE
            val top = if (stripInCaption) 0 else sys.top
            v.setPadding(sys.left, top, sys.right, maxOf(sys.bottom, ime.bottom))
            statusBand?.h = top
            applyCaptionToStrip(if (stripInCaption) cap.top else 0)
            // 탭 목록 화면은 제목줄(시스템 버튼) 아래에서 시작하도록 그 높이만큼 위 여백을 준다
            applySwitcherCaptionInset(if (stripInCaption) cap.top else 0)
            WindowInsetsCompat.CONSUMED
        }
        androidx.core.view.ViewCompat.requestApplyInsets(root)
    }

    /**
     * 팝업 창의 제목줄 방식: 창 버튼(최소화·최대화·닫기)이 있는 일반 제목줄이면 true, 가운데 손잡이만 있는 얇은 방식이면 false.
     * 삼성 인터넷처럼 일반 제목줄일 때만 탭을 제목줄 안에 넣고, 손잡이 방식이면 탭 줄을 그 아래에 보통대로 둔다.
     * 시스템이 알려주는 시스템 요소 위치(getBoundingRects)에 오른쪽 요소가 있으면 일반 제목줄,
     * 알려주지 않으면 제목줄 높이(32dp 이상)로 판단한다.
     */
    private fun captionHasWindowControls(insets: WindowInsetsCompat, width: Int, capTop: Int): Boolean {
        val byHeight = capTop >= dp(32)
        if (Build.VERSION.SDK_INT < 30 || width <= 0) return byHeight
        return try {
            val wi = insets.toWindowInsets() ?: return byHeight
            val m = android.view.WindowInsets::class.java.getMethod("getBoundingRects", Int::class.javaPrimitiveType)
            val rects = (m.invoke(wi, android.view.WindowInsets.Type.captionBar()) as? List<*>)
                ?.filterIsInstance<Rect>()?.filter { it.width() > 0 } ?: return byHeight
            if (rects.isEmpty()) byHeight else rects.any { it.centerX() > width * 0.6f }
        } catch (_: Throwable) { byHeight }
    }

    private var switcherCaptionInset = 0

    /** 팝업(프리폼) 창에서 탭 목록 헤더가 시스템 창 버튼(…, 최소화, 최대화, 닫기)과 겹치지 않게 위 여백을 맞춘다. */
    private fun applySwitcherCaptionInset(top: Int) {
        switcherCaptionInset = top
        if (!::tabSwitcher.isInitialized) return
        if (tabSwitcher.paddingTop != top) {
            tabSwitcher.setPadding(tabSwitcher.paddingLeft, top, tabSwitcher.paddingRight, tabSwitcher.paddingBottom)
        }
    }

    private var captionTouchInstalled = false

    /**
     * 제목줄 영역의 터치는 기본적으로 시스템이 창 이동용으로 가져간다. 탭·+ 버튼이 있는 부분만
     * setSystemGestureExclusionRects 로 앱이 터치(탭 선택·스크롤)를 받게 하고, 나머지 빈 곳은 창 끌기용으로 남긴다.
     */
    private fun installCaptionTouchRegion() {
        if (captionTouchInstalled) return
        captionTouchInstalled = true
        val l = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateCaptionTouchRegion() }
        tabStripBar.addOnLayoutChangeListener(l)
        tabStrip.addOnLayoutChangeListener(l)
        tabStripScroll.addOnLayoutChangeListener(l)
    }

    private fun updateCaptionTouchRegion() {
        if (Build.VERSION.SDK_INT < 29) return
        val rects = if (captionActive && tabStripBar.height > 0 && tabStripScroll.width > 0) {
            val left = tabStripScroll.left
            val contentW = tabStripScroll.paddingStart + tabStrip.width + dp(44)
            val right = left + minOf(contentW, tabStripScroll.width)
            listOf(Rect(left, 0, right, tabStripBar.height))
        } else emptyList()
        if (tabStripBar.systemGestureExclusionRects != rects) tabStripBar.systemGestureExclusionRects = rects
    }

    /**
     * 캡션 높이(px)에 맞춰 탭 줄 높이·탭 위치·좌우 비움 폭을 정한다. capTop = 0 이면 원래 모양으로 되돌린다.
     * 탭 줄 높이는 제목줄 높이와 똑같이 해서 탭의 세로 가운데가 시스템 버튼의 가운데와 같게 한다.
     * 좌우 비움 폭은 시스템 아이콘·메뉴(왼쪽)와 최소화·최대화·닫기 버튼(오른쪽)이 실제로 차지하는 폭에 맞춘 값이다.
     */
    private fun applyCaptionToStrip(capTop: Int) {
        val inCaption = capTop > 0
        val h = if (inCaption) maxOf(capTop, dp(32)) else dp(44)
        // 탭 위쪽 여백: 기본 6dp, 제목줄 안에서는 2dp (탭 높이는 최대 42dp)
        val pt = if (inCaption) maxOf(dp(2), h - dp(42)) else dp(6)
        val start = if (inCaption) dp(68) else 0
        val end = if (inCaption) dp(176) else 0
        if (h == captionTopApplied && start == captionStartApplied && end == captionEndApplied) return
        captionTopApplied = h; captionStartApplied = start; captionEndApplied = end
        captionActive = inCaption

        tabStripBar.layoutParams = tabStripBar.layoutParams.apply { height = h }
        tabStripBar.setPadding(start, 0, end, 0)
        tabStripScroll.setPadding(tabStripScroll.paddingLeft, pt, tabStripScroll.paddingRight, 0)
        // + 버튼·탭 목록 버튼은 탭과 같은 세로 가운데 (기본 모양: 탭 위 여백 6dp 일 때 버튼 위 여백 3dp)
        val plusTop = pt - dp(3)
        for (id in intArrayOf(R.id.btnStripNewTab, R.id.btnStripTabList)) {
            val v = findViewById<View>(id) ?: continue
            (v.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.topMargin = plusTop; v.layoutParams = it }
        }
        installCaptionTouchRegion()
        updateCaptionTouchRegion()
        browserUi.post {
            if (expanded) {
                tabStripScroll.doOnLayout {
                    lastStripViewportW = tabStripScroll.width
                    refreshTabStrip()
                    updateStripPlus()
                }
            }
            barsSyncFullLayout()
        }
    }

    private var statusBarAnim: android.animation.ValueAnimator? = null
    private var bandAnim: android.animation.ValueAnimator? = null
    private var statusBand: StatusBandDrawable? = null

    /** 바탕색으로 채우고, 맨 위 h px 만 band 색으로 덮는 배경 (상태표시줄 자리를 탭 줄/주소창 색과 맞추기 위해) */
    private class StatusBandDrawable(private val base: Int, var band: Int) : android.graphics.drawable.Drawable() {
        var h = 0
            set(v) { if (field != v) { field = v; invalidateSelf() } }
        private val paint = android.graphics.Paint()
        override fun draw(canvas: android.graphics.Canvas) {
            val b = bounds
            paint.color = base
            canvas.drawRect(b, paint)
            if (h > 0) {
                paint.color = band
                canvas.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), (b.top + h).toFloat(), paint)
            }
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = android.graphics.PixelFormat.OPAQUE
    }

    /** 상태표시줄을 화면 맨 위에 있는 영역(탭바 / 주소창 / 탭 목록)의 배경색과 똑같이 맞춘다. */
    private fun updateStatusBarColor(switcher: Boolean = switcherOpen) {
        val target = getColor(
            when {
                switcher -> R.color.ev_bg          // 탭 목록 화면 배경
                expanded -> R.color.ev_tabbar       // 태블릿 상단 탭바 배경
                else -> R.color.ev_surface         // 폰 상단 주소창 배경
            }
        )
        // targetSdk 35 에서는 window.statusBarColor 가 무시되므로, 상태표시줄 자리는 루트 배경의 윗부분을 직접 칠한다
        statusBand?.let { b ->
            if (b.band != target) {
                bandAnim?.cancel()
                bandAnim = android.animation.ValueAnimator.ofArgb(b.band, target).apply {
                    duration = 180
                    addUpdateListener { b.band = it.animatedValue as Int; b.invalidateSelf() }
                    start()
                }
            }
        }
        if (window.statusBarColor == target) return
        statusBarAnim?.cancel()
        statusBarAnim = android.animation.ValueAnimator.ofArgb(window.statusBarColor, target).apply {
            duration = 180
            addUpdateListener { window.statusBarColor = it.animatedValue as Int }
            start()
        }
    }

    private fun scheduleStripRefresh() {
        if (!expanded || stripRefreshQueued) return
        stripRefreshQueued = true
        ui.post {
            stripRefreshQueued = false
            refreshTabStrip()
        }
    }

    /** 상단 탭바의 탭 하나 (뷰를 재사용하면서 제목·아이콘·선택 상태만 바꾼다) */
    private class StripChip(val view: View, val tab: BrowserTab) {
        val title: TextView = view.findViewById(R.id.stripTitle)
        val icon: ImageView = view.findViewById(R.id.stripIcon)
        val bar: View = view.findViewById(R.id.stripGroupBar)
        var bg: android.graphics.drawable.Drawable? = null
        var width = 0
        var selected = false
        var selFraction = 0f
        var iconKey: Any? = null
        var iconKind: String? = null   // 아이콘 종류가 바뀔 때만 살짝 페이드 (같은 종류의 파비콘 교체는 조용히)
        var following = false
        var widthAnim: android.animation.ValueAnimator? = null
        var selAnim: android.animation.ValueAnimator? = null
    }

    private val stripChips = HashMap<BrowserTab, StripChip>()
    private val stripPills = HashMap<Int, TextView>()
    private var stripReady = false
    private val stripEase by lazy { android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f) }

    private fun setViewWidth(v: View, w: Int) {
        val lp = v.layoutParams ?: return
        if (lp.width != w) {
            lp.width = w
            v.layoutParams = lp
        }
    }

    private fun animateChipWidth(c: StripChip, to: Int, animate: Boolean) {
        c.widthAnim?.cancel()
        c.width = to
        val from = c.view.layoutParams.width
        if (!animate || from == to) {
            setViewWidth(c.view, to)
            c.following = false
            return
        }
        c.widthAnim = android.animation.ValueAnimator.ofInt(from, to).apply {
            duration = 280
            interpolator = stripEase
            addUpdateListener {
                setViewWidth(c.view, it.animatedValue as Int)
                if (c.following) ensureStripVisible(c, false)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    c.following = false
                }
            })
            start()
        }
    }

    private fun applyChipSelection(c: StripChip) {
        c.bg?.alpha = (255 * c.selFraction).toInt()
        c.title.setTextColor(
            androidx.core.graphics.ColorUtils.blendARGB(
                getColor(R.color.ev_muted), getColor(R.color.ev_text), c.selFraction
            )
        )
    }

    private fun animateChipSelection(c: StripChip, selected: Boolean, animate: Boolean) {
        c.selAnim?.cancel()
        c.selected = selected
        val to = if (selected) 1f else 0f
        if (!animate) {
            c.selFraction = to
            applyChipSelection(c)
            return
        }
        c.selAnim = android.animation.ValueAnimator.ofFloat(c.selFraction, to).apply {
            duration = 220
            interpolator = stripEase
            addUpdateListener {
                c.selFraction = it.animatedValue as Float
                applyChipSelection(c)
            }
            start()
        }
    }

    /** 탭(또는 그룹 알약)을 폭을 줄이며 사라지게 한 뒤 떼어낸다. 오른쪽 탭들이 부드럽게 왼쪽으로 당겨진다. */
    private fun retireStripView(v: View, c: StripChip?, animate: Boolean) {
        c?.widthAnim?.cancel()
        c?.selAnim?.cancel()
        c?.following = false
        if (!animate || v.parent == null || v.width == 0) {
            tabStrip.removeView(v)
            return
        }
        v.isEnabled = false
        v.isClickable = false
        v.isLongClickable = false
        v.animate().alpha(0f).setDuration(170).start()
        setViewWidth(v, v.width)
        android.animation.ValueAnimator.ofInt(v.width, 0).apply {
            duration = 260
            interpolator = stripEase
            addUpdateListener { setViewWidth(v, it.animatedValue as Int) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    tabStrip.removeView(v)
                }
            })
            start()
        }
    }

    /** 탭이 가려지지 않게 스크롤 (이미 다 보이면 가만히 둔다) */
    private fun ensureStripVisible(c: StripChip, smooth: Boolean) {
        val vw = tabStripScroll.width
        if (vw <= 0) return
        val sx = tabStripScroll.scrollX
        val left = c.view.left
        val right = left + maxOf(c.width, c.view.width)
        val pad = dp(28)
        val target = when {
            left - pad < sx -> left - pad
            right + pad > sx + vw -> right + pad - vw
            else -> return
        }.coerceAtLeast(0)
        if (smooth) tabStripScroll.smoothScrollTo(target, 0) else tabStripScroll.scrollTo(target, 0)
    }

    private fun bindStripChip(tab: BrowserTab, group: TabGroup?, width: Int, animate: Boolean): View {
        var c = stripChips[tab]
        val isNew = c == null
        if (c == null) {
            val v = layoutInflater.inflate(R.layout.item_strip_tab, tabStrip, false)
            c = StripChip(v, tab)
            stripChips[tab] = c
            // 파비콘 모서리를 살짝 둥글게
            c.icon.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(4).toFloat())
                }
            }
            c.icon.clipToOutline = true
            c.bg = getDrawable(R.drawable.bg_strip_tab_selected)?.mutate()?.also { it.alpha = 0 }
            v.background = c.bg
            v.setOnClickListener { if (tab !== current) selectTab(tab) }
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 탭 메뉴
            bindDragGesture(
                v, null,
                onStart = { x, _ -> startStripDrag(tab, x) },
                onMove = { x, _ -> stripRawX = x; updateStripDrag() },
                onEnd = { moved, canceled -> endStripDrag(moved, canceled) }
            )
            c.view.findViewById<ImageButton>(R.id.stripClose).setOnClickListener { closeTab(tab, quitIfLast = true) }
        }
        val chip = c

        // 제목: 홈(새 탭)이면 항상 "새 탭" — 이전 페이지 제목이 남아 있어도 쓰지 않는다
        val title = if (tab.isHome) "새 탭"
            else tab.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" }
                ?: tab.liveWebView?.url?.takeIf { it != "about:blank" && it != HOME_URL }?.let { Uri.parse(it).host }
                ?: tabTitle(tab)
        if (chip.title.text.toString() != title) {
            chip.title.text = title
            if (animate && !isNew) {
                chip.title.alpha = 0.25f
                chip.title.animate().alpha(1f).setDuration(220).start()
            }
        }

        // 아이콘: 홈이면 잎사귀, 페이지면 파비콘(없으면 지구본)
        val fav = if (tab.isHome) null else tab.favicon
        val key: Any = if (tab.incognito) "incognito" else fav ?: if (tab.isHome) "home" else "globe"
        val kind = when {
            tab.incognito -> "incognito"
            fav != null -> "fav"
            tab.isHome -> "home"
            else -> "globe"
        }
        if (chip.iconKey != key) {
            val kindChanged = chip.iconKind != kind
            chip.iconKind = kind
            chip.iconKey = key
            chip.icon.imageTintList = if (tab.incognito)
                MaterialColors.getColor(chip.icon, com.google.android.material.R.attr.colorOnSurface)
                    .let { android.content.res.ColorStateList.valueOf(it) }
            else null
            when {
                tab.incognito -> chip.icon.setImageResource(R.drawable.ic_incognito)
                fav != null -> chip.icon.setImageBitmap(fav)
                tab.isHome -> chip.icon.setImageResource(R.drawable.ic_leaf_pixel)
                else -> chip.icon.setImageResource(R.drawable.ic_globe)
            }
            // 사이트가 파비콘을 여러 번 보내도 통통 튀지 않게: 크기 변화·오버슛은 쓰지 않고,
            // 아이콘 종류가 바뀔 때(지구본 → 파비콘 등)만 부드럽게 페이드한다.
            chip.icon.animate().cancel()
            chip.icon.scaleX = 1f; chip.icon.scaleY = 1f
            if (animate && !isNew && kindChanged) {
                chip.icon.alpha = 0f
                chip.icon.animate().alpha(1f).setDuration(180).start()
            } else {
                chip.icon.alpha = 1f
            }
        }

        if (group != null) {
            chip.bar.visibility = View.VISIBLE
            chip.bar.background.mutate().setTint(group.color)
        } else {
            chip.bar.visibility = View.INVISIBLE
        }

        val sel = tab === current
        if (isNew) {
            chip.selected = sel
            chip.selFraction = if (sel) 1f else 0f
            applyChipSelection(chip)
        } else if (chip.selected != sel) {
            animateChipSelection(chip, sel, animate)
        }

        if (isNew) {
            chip.width = width
            if (animate) {
                chip.view.layoutParams.width = 0
                chip.view.alpha = 0f
                chip.following = sel
                chip.view.animate().alpha(1f).setStartDelay(50).setDuration(220).start()
                // 실제 너비 애니메이션은 뷰가 붙은 뒤 시작 (아래 refreshTabStrip 에서)
                chip.view.tag = width
            } else {
                chip.view.layoutParams.width = width
            }
        } else if (chip.width != width) {
            animateChipWidth(chip, width, animate)
        }
        return chip.view
    }

    private fun bindStripPill(group: TabGroup, animate: Boolean): View {
        var pill = stripPills[group.id]
        val isNew = pill == null
        if (pill == null) {
            pill = layoutInflater.inflate(R.layout.item_strip_group, tabStrip, false) as TextView
            stripPills[group.id] = pill
            pill.setOnClickListener {
                group.collapsed = !group.collapsed
                scheduleStripRefresh()
            }
            pill.setOnLongClickListener {
                showGroupMenu(group, false) { scheduleStripRefresh() }
                true
            }
            Motion.pressable(pill, 0.92f)
            if (animate) pill.alpha = 0f
        }
        val n = tabs.count { it.groupId == group.id }
        pill.text = if (group.collapsed) "${group.name} ($n)" else group.name
        pill.background.mutate().setTint(group.color)
        // 접힘/펼침이 바뀌면 알약이 톡 튀어 변화를 알려 준다
        val wasCollapsed = pill.tag as? Boolean
        if (wasCollapsed != null && wasCollapsed != group.collapsed && animate) Motion.pop(pill, 0.8f)
        pill.tag = group.collapsed
        if (isNew && animate) {
            pill.animate().alpha(1f).setDuration(220).start()
            Motion.pop(pill, 0.7f)
        }
        return pill
    }

    private var lastStripViewportW = 0

    private fun refreshTabStrip() {
        if (!expanded) return
        // 아직 배치 전이면 폭을 알 수 없다 (임의의 폭으로 만들면 비율이 틀어진다). 배치되면 레이아웃 리스너가 다시 부른다.
        if (tabStripScroll.width <= 0) return
        val animate = stripReady && tabStripScroll.width > 0 && Motion.enabled(this)

        val visible = tabs.count { val g = groupOf(it); g == null || !g.collapsed }

        // 탭 너비는 고정 범위(124~220dp)로 계산해서 지정 → 탭이 한없이 길어지지 않게 함.
        // 탭이 많으면 최소 너비로 줄고 스크롤, 적으면 최대 너비에서 멈춤.
        val avail = tabStripScroll.width - dp(60)
        val chipWidth = if (avail > 0) {
            (avail / maxOf(1, visible)).coerceIn(dp(124), dp(220))
        } else dp(180)

        val desired = ArrayList<View>()
        val keepTabs = HashSet<BrowserTab>()
        val keepPills = HashSet<Int>()
        tabs.toList().forEach { tab ->
            val group = groupOf(tab)
            if (group != null && keepPills.add(group.id)) desired.add(bindStripPill(group, animate))
            if (group != null && group.collapsed) return@forEach
            desired.add(bindStripChip(tab, group, chipWidth, animate))
            keepTabs.add(tab)
        }

        // 없어진 탭/그룹은 폭을 줄이며 사라지게
        stripChips.entries.toList().forEach { (t, c) ->
            if (t !in keepTabs) {
                stripChips.remove(t)
                retireStripView(c.view, c, animate)
            }
        }
        stripPills.entries.toList().forEach { (id, p) ->
            if (id !in keepPills) {
                stripPills.remove(id)
                retireStripView(p, null, animate)
            }
        }

        // 순서대로 배치 (새 뷰는 이전 뷰 바로 뒤에 끼우고, 순서가 어긋난 뷰만 옮긴다)
        var prev: View? = null
        for (v in desired) {
            if (v.parent == null) {
                tabStrip.addView(v, prev?.let { tabStrip.indexOfChild(it) + 1 } ?: 0)
            } else if (prev != null && tabStrip.indexOfChild(v) < tabStrip.indexOfChild(prev)) {
                tabStrip.removeView(v)
                tabStrip.addView(v, tabStrip.indexOfChild(prev) + 1)
            }
            prev = v
        }

        // 새로 생긴 탭: 폭 0 에서 목표 폭까지 자라나게
        stripChips.values.forEach { c ->
            val target = c.view.tag as? Int ?: return@forEach
            c.view.tag = null
            animateChipWidth(c, target, true)
        }

        // 선택한 탭이 바뀌었거나 새로 생겼을 때만 그 탭이 보이도록 스크롤 (직접 스크롤 중에는 건드리지 않음)
        val cur = current?.let { stripChips[it] }
        if (cur != null && lastStripCurrent !== current) {
            lastStripCurrent = current
            if (!cur.following) tabStripScroll.post { ensureStripVisible(cur, true) }
        }

        if (tabStripScroll.width > 0) stripReady = true
    }

    // ───────────────────────── 키보드 단축키 (태블릿 + 키보드) ─────────────────────────

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && handleShortcut(event)) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun handleShortcut(e: KeyEvent): Boolean {
        if (e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_T -> openNewTabAndFocus()
                KeyEvent.KEYCODE_W -> current?.let { closeTab(it, quitIfLast = true) }
                KeyEvent.KEYCODE_L -> focusUrlBar()
                KeyEvent.KEYCODE_F -> openFind()
                KeyEvent.KEYCODE_R -> current?.let { reloadTab(it) }
                KeyEvent.KEYCODE_D -> bookmarkCurrent()
                KeyEvent.KEYCODE_TAB -> cycleTab(if (e.isShiftPressed) -1 else 1)
                in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9 -> {
                    val target = if (e.keyCode == KeyEvent.KEYCODE_9) {
                        tabs.lastOrNull()
                    } else {
                        tabs.getOrNull(e.keyCode - KeyEvent.KEYCODE_1)
                    }
                    if (target != null) selectTab(target)
                }
                else -> return false
            }
            return true
        }
        if (e.isAltPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> navBack()
                KeyEvent.KEYCODE_DPAD_RIGHT -> navForward()
                else -> return false
            }
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_F5) {
            current?.let { reloadTab(it) }
            return true
        }
        return false
    }

    /** 주소창 입력 중 다른 화면 영역을 누르면 키보드와 입력 포커스를 함께 닫는다. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && ::urlBar.isInitialized && urlBar.hasFocus()) {
            val rect = Rect()
            urlBar.getGlobalVisibleRect(rect)
            val outsideAddressBar = !rect.contains(ev.rawX.toInt(), ev.rawY.toInt())
            if (outsideAddressBar) hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun cycleTab(delta: Int) {
        if (tabs.size < 2) return
        val i = tabs.indexOf(current).coerceAtLeast(0)
        selectTab(tabs[(i + delta + tabs.size) % tabs.size])
    }

    /** 키보드를 내리고 입력창에서 포커스를 뺀다. (홈 화면에서 키보드가 저절로 뜨지 않게) */
    private fun hideKeyboard() {
        urlBar.dismissDropDown()
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    private fun focusUrlBar() {
        urlBar.requestFocus()
        urlBar.selectAll()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(urlBar, InputMethodManager.SHOW_IMPLICIT)
    }

    // ───────────────────────── 탭 전환 화면 (전체 화면) ─────────────────────────

    private val thumbScale = 0.6f

    /** 지금 보이는 페이지 영역(웹뷰 + 홈 화면)을 비트맵으로 찍는다. */
    private fun captureContent(): Bitmap? {
        val area = webContainer.parent as? View ?: return null
        val w = area.width
        val h = area.height
        if (w <= 0 || h <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(
                (w * thumbScale).toInt().coerceAtLeast(1),
                (h * thumbScale).toInt().coerceAtLeast(1),
                Bitmap.Config.RGB_565
            )
            val c = Canvas(bmp)
            c.drawColor(MaterialColors.getColor(area, com.google.android.material.R.attr.colorSurface))
            c.scale(thumbScale, thumbScale)
            area.draw(c)
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    /** 이미지를 위쪽 기준으로 꽉 채워 보여주는 행렬 (페이지의 윗부분이 보이도록) */
    private fun topCropMatrix(bmp: Bitmap, w: Int, h: Int): Matrix {
        val s = maxOf(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        return Matrix().apply {
            setScale(s, s)
            postTranslate((w - bmp.width * s) / 2f, 0f)
        }
    }

    private fun setThumb(iv: ImageView, bmp: Bitmap?) {
        if (bmp == null) {
            iv.scaleType = ImageView.ScaleType.CENTER
            iv.alpha = 1f
            iv.setImageResource(R.drawable.ic_leaf_pixel)
            return
        }
        iv.scaleType = ImageView.ScaleType.MATRIX
        iv.setImageBitmap(bmp)
        fun apply() {
            if (iv.width > 0 && iv.height > 0) iv.imageMatrix = topCropMatrix(bmp, iv.width, iv.height)
        }
        iv.addOnLayoutChangeListener { _, l, tp, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - tp != ob - ot) apply()
        }
        apply()
    }

    private fun rectInRoot(v: View): RectF {
        val root = IntArray(2)
        val loc = IntArray(2)
        (tabMorph.parent as View).getLocationOnScreen(root)
        v.getLocationOnScreen(loc)
        return RectF(
            (loc[0] - root[0]).toFloat(), (loc[1] - root[1]).toFloat(),
            (loc[0] - root[0] + v.width).toFloat(), (loc[1] - root[1] + v.height).toFloat()
        )
    }

    private fun lerp(a: Float, b: Float, p: Float) = a + (b - a) * p

    /**
     * 스냅샷이 from 영역에서 to 영역으로 스프링으로 늘어나거나 줄어든다. (모서리 둥글기도 함께 변함)
     * 페이지 → 탭 카드, 탭 카드 → 페이지 전환에 모두 쓴다.
     */
    private fun runMorph(bmp: Bitmap, from: RectF, to: RectF, r0: Float, r1: Float, onEnd: () -> Unit) {
        tabMorph.scaleType = ImageView.ScaleType.MATRIX
        tabMorph.setImageBitmap(bmp)
        tabMorph.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, morphRadius)
            }
        }
        tabMorph.clipToOutline = true
        Motion.cancel(tabMorph)
        tabMorph.alpha = 1f
        tabMorph.visibility = View.VISIBLE
        val lp = FrameLayout.LayoutParams(1, 1)

        fun apply(p: Float) {
            val l = lerp(from.left, to.left, p)
            val tp = lerp(from.top, to.top, p)
            val w = maxOf(1f, lerp(from.width(), to.width(), p))
            val h = maxOf(1f, lerp(from.height(), to.height(), p))
            lp.leftMargin = l.toInt()
            lp.topMargin = tp.toInt()
            lp.width = w.toInt()
            lp.height = h.toInt()
            tabMorph.layoutParams = lp
            morphRadius = lerp(r0, r1, p.coerceIn(0f, 1f))
            tabMorph.imageMatrix = topCropMatrix(bmp, w.toInt(), h.toInt())
            tabMorph.invalidateOutline()
        }
        apply(0f)

        SpringAnimation(FloatValueHolder(0f))
            .setSpring(SpringForce(1f).setStiffness(320f).setDampingRatio(0.82f))
            .setMinimumVisibleChange(0.002f)
            .addUpdateListener { _, value, _ -> apply(value) }
            .addEndListener { _, _, _, _ ->
                apply(1f)
                onEnd()
            }
            .start()
    }

    private fun hideMorph(fade: Boolean) {
        if (fade && Motion.enabled(this)) {
            Motion.spring(tabMorph, DynamicAnimation.ALPHA, 0f, 700f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                tabMorph.visibility = View.GONE
                tabMorph.alpha = 1f
                tabMorph.setImageDrawable(null)
            }
        } else {
            Motion.cancel(tabMorph)
            tabMorph.visibility = View.GONE
            tabMorph.alpha = 1f
            tabMorph.setImageDrawable(null)
        }
    }

    private fun setupTabSwitcher() {
        tabSwitcher.findViewById<View>(R.id.btnCloseSheet).setOnClickListener { closeTabSwitcher() }
        tabSwitcher.findViewById<Button>(R.id.btnCloseAll).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            closeAllTabs()
            closeTabSwitcher()
        }
        tabSwitcher.findViewById<Button>(R.id.btnNewIncognito).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            openNewTabAndFocus(incognito = true)
            closeTabSwitcher()
        }
        tabSwitcher.findViewById<Button>(R.id.btnNewTab).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            openNewTabAndFocus()
            closeTabSwitcher()
        }
    }

    // ───────────────────────── 탭 화면 배경 블러 ─────────────────────────

    private var switcherBlurAnim: android.animation.ValueAnimator? = null
    private var switcherBlurRadius = 0f

    /** 탭 화면 뒤의 웹 페이지를 흐리게(유리 느낌) 할 수 있는지. 안 되는 기기는 예전처럼 불투명 배경. */
    private fun switcherGlass() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && Blur.supported(this)

    /** 뒤쪽 페이지의 블러 반경을 부드럽게 바꾼다 (0 이면 끄기) */
    private fun animateSwitcherBlur(toDp: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val to = Blur.dp(this, toDp).toFloat()
        switcherBlurAnim?.cancel()
        if (!Motion.enabled(this)) {
            switcherBlurRadius = to
            Blur.blurView(browserUi, to)
            return
        }
        switcherBlurAnim = android.animation.ValueAnimator.ofFloat(switcherBlurRadius, to).apply {
            duration = 240
            addUpdateListener {
                switcherBlurRadius = it.animatedValue as Float
                Blur.blurView(browserUi, switcherBlurRadius)
            }
            start()
        }
    }

    private fun clearSwitcherBlur() {
        switcherBlurAnim?.cancel()
        switcherBlurRadius = 0f
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Blur.blurView(browserUi, 0f)
    }

    private fun openTabSwitcher() {
        if (switcherOpen || switcherBusy) return
        val cur = current ?: return
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)

        val area = webContainer.parent as View
        val shot = captureContent()
        cur.thumb = shot
        val from = rectInRoot(area)

        switcherOpen = true
        updateSecureFlag()
        switcherBusy = true
        updateStatusBarColor()
        refreshSwitcher(animateIn = true, skipEnter = cur)
        tabSwitcher.alpha = 0f
        val glass = switcherGlass()
        tabSwitcher.setBackgroundColor(
            Blur.surface(this, com.google.android.material.R.attr.colorSurfaceContainer, glass, 0xB8)
        )
        tabSwitcher.visibility = View.VISIBLE

        tabSwitcher.doOnLayout {
            if (glass) animateSwitcherBlur(24)
            val card = switcherRows[cur]
            val thumb = card?.findViewById<ImageView>(R.id.tabThumb)
            if (card != null) {
                val r = Rect()
                card.getDrawingRect(r)
                tabScroll.offsetDescendantRectToMyCoords(card, r)
                tabScroll.scrollTo(0, maxOf(0, r.top - dp(12)))
            }
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 1f, 240f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            if (shot == null || thumb == null || !Motion.enabled(this)) {
                tabSwitcher.alpha = 1f
                if (!glass) browserUi.visibility = View.INVISIBLE
                switcherBusy = false
                return@doOnLayout
            }
            val to = rectInRoot(thumb)
            thumb.alpha = 0f
            runMorph(shot, from, to, 0f, dp(10).toFloat()) {
                thumb.alpha = 1f
                hideMorph(false)
                if (!glass) browserUi.visibility = View.INVISIBLE
                switcherBusy = false
            }
        }
    }

    /** 탭 화면을 닫는다. target 탭의 카드가 있으면 카드가 펼쳐지며 페이지가 되고, 없으면 부드럽게 사라진다. */
    private fun closeTabSwitcher(target: BrowserTab? = null) {
        if (!switcherOpen || switcherBusy) return
        switcherBusy = true
        updateStatusBarColor(switcher = false)

        val tab = target ?: current ?: tabs.firstOrNull()
        val thumbView = tab?.let { switcherRows[it] }?.findViewById<ImageView>(R.id.tabThumb)
        val bmp = tab?.thumb
        val vis = Rect()
        val canMorph = tab != null && thumbView != null && bmp != null &&
            thumbView.getGlobalVisibleRect(vis) && Motion.enabled(this)
        val from = if (canMorph) rectInRoot(thumbView!!) else null

        if (tab != null && tab !== current) selectTab(tab)
        browserUi.visibility = View.VISIBLE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && switcherBlurRadius > 0f) animateSwitcherBlur(0)

        fun finish() {
            clearSwitcherBlur()
            tabSwitcher.visibility = View.GONE
            tabSwitcher.alpha = 1f
            tabList.removeAllViews()
            switcherRows.clear()
            switcherOpen = false
            updateSecureFlag()
            switcherBusy = false
        }

        if (canMorph && from != null) {
            val to = rectInRoot(webContainer.parent as View)
            thumbView!!.alpha = 0f
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            runMorph(bmp!!, from, to, dp(10).toFloat(), 0f) {
                finish()
                hideMorph(true)
            }
        } else {
            // 카드가 없거나 화면 밖: 페이지가 살짝 커지며 나타나고 탭 화면은 사라진다.
            val chrome = browserUi
            if (Motion.enabled(this)) {
                Motion.cancel(chrome)
                chrome.alpha = 0f
                chrome.scaleX = 0.95f
                chrome.scaleY = 0.95f
                Motion.spring(chrome, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                Motion.spring(chrome, DynamicAnimation.SCALE_X, 1f, 260f, 0.78f)
                Motion.spring(chrome, DynamicAnimation.SCALE_Y, 1f, 260f, 0.78f)
                Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                    finish()
                }
            } else {
                finish()
            }
        }
    }

    /** 탭 화면에서 마지막으로 그린 그룹별 접힘 상태 (화살표가 돌아가는 방향을 정하려고) */
    private val groupRendered = HashMap<Int, Boolean>()
    private var groupToggling = false

    // ───────────────────────── 탭 화면의 창 관리 ─────────────────────────

    /**
     * 탭 화면 위쪽에 열려 있는 창들을 가로로 보여 준다 (창이 2개 이상일 때만).
     * 창을 누르면 그 창으로 가고, 창의 X 를 누르면 그 창을 닫는다. 맨 끝의 "＋ 새 창"으로 창을 더 연다.
     */
    private fun refreshWindowStrip(skip: MainActivity? = null) {
        val strip = tabSwitcher.findViewById<View>(R.id.windowStrip)
        val box = tabSwitcher.findViewById<LinearLayout>(R.id.windowStripList)
        box.removeAllViews()
        val wins = instances.filter { it !== skip && !it.isFinishing && !it.isDestroyed }
        if (wins.size < 2) {
            strip.visibility = View.GONE
            return
        }
        strip.visibility = View.VISIBLE

        val attrSurface = com.google.android.material.R.attr.colorSurface
        val surface = MaterialColors.getColor(box, attrSurface, 0)
        val activeBg = MaterialColors.getColor(box, com.google.android.material.R.attr.colorPrimaryContainer, 0)
        val activeFg = MaterialColors.getColor(box, com.google.android.material.R.attr.colorOnPrimaryContainer, 0)
        val textMain = MaterialColors.getColor(box, com.google.android.material.R.attr.colorOnSurface, 0)
        val textSub = MaterialColors.getColor(box, com.google.android.material.R.attr.colorOnSurfaceVariant, 0)

        fun styled(chip: View, bg: Int) {
            val shape = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(bg) }
            val mask = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFFFFFFFF.toInt()) }
            chip.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x22000000), shape, mask
            )
        }

        wins.forEach { w ->
            val chip = layoutInflater.inflate(R.layout.item_window_chip, box, false)
            val me = w === this
            val fg = if (me) activeFg else textMain
            val sub = if (me) activeFg else textSub
            styled(chip, if (me) activeBg else surface)
            chip.findViewById<TextView>(R.id.windowTitle).apply {
                text = if (me) "창 ${w.windowNo} · 현재" else "창 ${w.windowNo}"
                setTextColor(fg)
            }
            // 다른 창의 시크릿 탭 제목은 보여 주지 않는다
            val cur = w.current
            val pageName = when {
                cur == null || cur.isHome -> "새 탭"
                cur.incognito -> "시크릿 탭"
                else -> w.tabTitle(cur)
            }
            chip.findViewById<TextView>(R.id.windowSub).apply {
                text = "탭 ${w.tabs.size}개 · $pageName"
                setTextColor(sub)
            }
            val close = chip.findViewById<ImageButton>(R.id.windowClose)
            close.imageTintList = android.content.res.ColorStateList.valueOf(sub)
            if (me) {
                // 지금 보고 있는 창은 여기서 닫지 않는다
                close.visibility = View.GONE
                chip.setPadding(chip.paddingLeft, 0, dp(14), 0)
            } else {
                chip.setOnClickListener { bringWindowToFront(w) }
                close.setOnClickListener { confirmCloseWindow(w) }
            }
            box.addView(chip)
        }

        // 맨 끝: 새 창
        val add = layoutInflater.inflate(R.layout.item_window_chip, box, false)
        styled(add, surface)
        add.findViewById<TextView>(R.id.windowTitle).apply { text = "＋ 새 창"; setTextColor(textMain) }
        add.findViewById<View>(R.id.windowSub).visibility = View.GONE
        add.findViewById<View>(R.id.windowClose).visibility = View.GONE
        add.setPadding(dp(16), 0, dp(16), 0)
        add.setOnClickListener { openNewWindow() }
        box.addView(add)
    }

    /** 다른 창을 맨 앞으로 가져온다 */
    @Suppress("DEPRECATION")
    private fun bringWindowToFront(w: MainActivity) {
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
            val target = am.appTasks.firstOrNull { t ->
                val info = t.taskInfo
                val id = if (Build.VERSION.SDK_INT >= 29) info.taskId else info.id
                id == w.taskId
            }
            if (target != null) target.moveToFront() else toast("창을 찾지 못했어요")
        } catch (e: Throwable) {
            toast("창을 전환하지 못했어요")
        }
    }

    /** 창 닫기: 안에 열린 페이지가 있으면 한 번 물어본다 */
    private fun confirmCloseWindow(w: MainActivity) {
        val pages = w.tabs.count { !it.isHome }
        fun doClose() {
            w.finishAndRemoveTask()
            refreshWindowStrip(skip = w)
        }
        if (pages == 0) {
            doClose()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("창 ${w.windowNo} 닫기")
            .setMessage("그 창에 열려 있는 탭 ${w.tabs.size}개가 함께 닫혀요.")
            .setNegativeButton("취소", null)
            .setPositiveButton("창 닫기") { _, _ -> doClose() }
            .show()
    }

    private fun refreshSwitcher(animateIn: Boolean, skipEnter: BrowserTab? = null) {
        scheduleStripRefresh()

        // 다시 그리기 전 위치를 기억해 두었다가, 남은 카드들이 미끄러지듯 새 자리로 이동하게 한다.
        val before = HashMap<BrowserTab, Pair<Int, Int>>()
        if (!animateIn) {
            val loc = IntArray(2)
            switcherRows.forEach { (tb, v) ->
                v.getLocationOnScreen(loc)
                before[tb] = loc[0] to loc[1]
            }
        }
        switcherRows.clear()
        switcherBoxes.clear()
        tabList.removeAllViews()
        tabsTitle.text = "탭 (${tabs.size})"
        refreshWindowStrip()
        val list = tabList

        var pending: LinearLayout? = null
        // 카드/헤더를 붙이는 곳: 평소엔 목록 자체, 그룹을 그리는 동안엔 그 그룹의 둥근 상자
        var target: LinearLayout = list
        var enterIndex = 0

        // 정사각형 카드: 폰은 2열, 화면이 넓을수록 열이 늘어난다 (카드가 너무 커지지 않도록).
        val cols = (resources.configuration.screenWidthDp / 170).coerceIn(2, 5)

        fun flushRow() {
            val p = pending ?: return
            while (p.childCount < cols) {
                p.addView(
                    View(this),
                    LinearLayout.LayoutParams(0, 1, 1f).apply { setMargins(dp(6), 0, dp(6), 0) }
                )
            }
            pending = null
        }

        fun addCell(v: View) {
            var p = pending
            if (p == null || p.childCount >= cols) {
                p = LinearLayout(this)
                p.orientation = LinearLayout.HORIZONTAL
                p.clipChildren = false
                p.tag = CARD_ROW_TAG
                // 그룹 상자 안은 상자 여백이 있어서 카드가 바깥 카드와 같은 선에 맞도록 여백을 줄인다
                val side = if (target === list) dp(12) else dp(4)
                target.addView(
                    p,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(side, 0, side, 0) }
                )
                pending = p
            }
            p.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            )
        }

        fun addTabRow(tab: BrowserTab, group: TabGroup?) {
            val row = layoutInflater.inflate(R.layout.item_tab, list, false)
            switcherRows[tab] = row
            row.findViewById<TextView>(R.id.tabTitle).text =
                if (tab.isHome) (if (tab.incognito) "시크릿 탭" else "새 탭")
                else tabTitle(tab)
            val fav = row.findViewById<ImageView>(R.id.tabFavicon)
            val bmp = if (tab.isHome) null else tab.favicon
            if (tab.incognito) {
                // 시크릿 탭 카드는 어둡게, 아이콘은 시크릿 모양으로
                row.findViewById<TextView>(R.id.tabTitle).setTextColor(incognitoTextColor)
                row.findViewById<ImageView>(R.id.tabClose).imageTintList =
                    android.content.res.ColorStateList.valueOf(incognitoTextColor)
                fav.setImageResource(R.drawable.ic_incognito)
                fav.imageTintList = android.content.res.ColorStateList.valueOf(incognitoTextColor)
            } else if (bmp != null) fav.setImageBitmap(bmp) else fav.setImageResource(R.drawable.ic_leaf_pixel)
            setThumb(row.findViewById(R.id.tabThumb), tab.thumb)

            val bar = row.findViewById<View>(R.id.tabGroupBar)
            if (group != null) {
                bar.visibility = View.VISIBLE
                bar.background.mutate().setTint(group.color)
            } else {
                bar.visibility = View.GONE
            }

            row.setBackgroundResource(
                when {
                    tab.incognito && tab === current -> R.drawable.bg_tab_card_incognito_active
                    tab.incognito -> R.drawable.bg_tab_card_incognito
                    tab === current -> R.drawable.bg_tab_card_active
                    else -> R.drawable.bg_tab_card
                }
            )
            row.setOnClickListener { closeTabSwitcher(tab) }
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 탭 메뉴
            bindDragGesture(
                row, 0.96f,
                onStart = { x, y -> startSwitcherDrag(tab, x, y) },
                onMove = { x, y -> swDrag?.let { it.rawX = x; it.rawY = y; updateSwitcherDrag() } },
                onEnd = { moved, canceled -> endSwitcherDrag(moved, canceled) },
                // 카드를 옆으로 밀어서 닫기 (X 버튼과 같은 동작)
                onSwipeDismiss = {
                    if (!switcherBusy) {
                        // 탭 목록 화면에서는 마지막 탭을 닫아도 앱을 끄지 않고 빈 새 탭(홈)만 남긴다
                        closeTab(tab, quitIfLast = false)
                        refreshSwitcher(false)
                    }
                },
                canSwipe = { !switcherBusy && !groupToggling && swDrag == null }
            )
            row.findViewById<ImageButton>(R.id.tabClose).setOnClickListener {
                if (switcherBusy) return@setOnClickListener
                it.isEnabled = false
                Motion.flyAway(row) {
                    closeTab(tab, quitIfLast = false)
                    refreshSwitcher(false)
                }
            }
            if (animateIn && tab !== skipEnter) {
                Motion.enter(row, minOf(enterIndex++ * 45L + 80L, 380L))
            }
            addCell(row)
        }

        fun addGroupHeader(group: TabGroup) {
            val header = layoutInflater.inflate(R.layout.item_group_header, target, false)
            val members = tabs.filter { it.groupId == group.id }
            header.findViewById<View>(R.id.groupDot).background.mutate().setTint(group.color)
            header.findViewById<TextView>(R.id.groupName).text = group.name
            // 개수: 그룹 색을 옅게 깐 알약 모양
            header.findViewById<TextView>(R.id.groupCount).apply {
                text = "${members.size}"
                setPadding(dp(9), dp(2), dp(9), dp(2))
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor(ColorUtils.setAlphaComponent(group.color, 0x40))
                }
            }
            // 접혀 있을 때는 안에 든 탭들의 아이콘을 작게 겹쳐 보여 준다
            val surfaceColor = MaterialColors.getColor(header, com.google.android.material.R.attr.colorSurface, 0)
            header.findViewById<LinearLayout>(R.id.groupPreview).apply {
                removeAllViews()
                if (group.collapsed) {
                    members.take(3).forEachIndexed { i, t ->
                        addView(ImageView(this@MainActivity).apply {
                            val bmp = if (t.isHome) null else t.favicon
                            if (bmp != null) setImageBitmap(bmp) else setImageResource(
                                if (t.isHome) R.drawable.ic_leaf_pixel else R.drawable.ic_globe
                            )
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            setPadding(dp(2), dp(2), dp(2), dp(2))
                            background = GradientDrawable().apply {
                                shape = GradientDrawable.OVAL
                                setColor(surfaceColor)
                                setStroke(dp(1), group.color)
                            }
                        }, LinearLayout.LayoutParams(dp(20), dp(20)).apply {
                            if (i > 0) marginStart = -dp(6)
                        })
                    }
                    visibility = View.VISIBLE
                } else {
                    visibility = View.GONE
                }
            }
            // 펼침/접힘 화살표: 이전 상태에서 새 상태로 부드럽게 돌아간다
            val chevron = header.findViewById<ImageView>(R.id.groupChevron)
            val goal = if (group.collapsed) 0f else 180f
            val prev = groupRendered[group.id]
            if (prev != null && prev != group.collapsed && Motion.enabled(this)) {
                chevron.rotation = if (prev) 0f else 180f
                Motion.spring(chevron, DynamicAnimation.ROTATION, goal, 300f, 0.6f)
                Motion.pop(header.findViewById(R.id.groupCount), 0.7f)
            } else {
                chevron.rotation = goal
            }
            groupRendered[group.id] = group.collapsed
            header.setOnClickListener {
                if (groupToggling) return@setOnClickListener
                if (!group.collapsed && Motion.enabled(this)) {
                    // 접을 때: 카드들이 먼저 작아지며 사라진 뒤 목록을 다시 그린다
                    groupToggling = true
                    members.forEach { m ->
                        switcherRows[m]?.animate()?.alpha(0f)?.scaleX(0.85f)?.scaleY(0.85f)?.setDuration(140)?.start()
                    }
                    ui.postDelayed({
                        group.collapsed = true
                        groupToggling = false
                        refreshSwitcher(false)
                    }, 150)
                } else {
                    group.collapsed = !group.collapsed
                    refreshSwitcher(false)
                }
            }
            header.findViewById<ImageButton>(R.id.groupMenu).setOnClickListener {
                showGroupMenu(group, true) { refreshSwitcher(false) }
            }
            Motion.pressable(header, 0.98f)
            flushRow()
            target.addView(header)
        }

        /** 그룹을 담는 둥근 상자: 그룹 색을 옅게 깔고 테두리를 둘러 같은 그룹임을 한눈에 보여 준다 */
        fun newGroupBox(group: TabGroup): LinearLayout {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(0, dp(2), 0, dp(6))
            box.background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(ColorUtils.setAlphaComponent(group.color, 0x24))
                setStroke(dp(1), ColorUtils.setAlphaComponent(group.color, 0x66))
            }
            box.clipToOutline = true
            switcherBoxes[group.id] = box
            list.addView(
                box,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(8), dp(6), dp(8), dp(6)) }
            )
            return box
        }

        // 탭 순서대로 훑으면서, 그룹은 처음 나온 자리에 헤더 + 소속 탭을 한 번에 그린다.
        val drawn = mutableSetOf<Int>()
        tabs.toList().forEach { tab ->
            val g = groupOf(tab)
            if (g == null) {
                addTabRow(tab, null)
            } else if (drawn.add(g.id)) {
                flushRow()
                target = newGroupBox(g)
                addGroupHeader(g)
                if (!g.collapsed) {
                    tabs.filter { it.groupId == g.id }.forEach { addTabRow(it, g) }
                }
                flushRow()
                target = list
            }
        }
        flushRow()
        if (!animateIn) {
            Motion.glideFrom(list, before.mapNotNull { (tb, pos) -> switcherRows[tb]?.let { it to pos } }.toMap())
            // 그룹을 펼칠 때처럼 새로 나타나는 카드는 차례로 떠오르게 한다
            if (before.isNotEmpty()) {
                var i = 0
                switcherRows.forEach { (tb, row) ->
                    if (tb !in before) Motion.enter(row, minOf(i++ * 45L + 30L, 300L))
                }
            }
        }
    }

    private fun closeAllTabs() {
        val old = tabs.toList()
        createTab(null, home = true)
        old.forEach { closeTab(it) }
    }

    private fun openNewTabAndFocus(opener: BrowserTab? = null, incognito: Boolean = false) {
        createTab(null, opener = opener, home = true, incognito = incognito)
        // 새 탭(홈)에서 키보드가 저절로 올라오지 않게 한다. 입력하려면 검색창을 누르면 된다.
        hideKeyboard()
    }

    // ───────────────────────── 웹뷰 설정 ─────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    // ───────────────────────── 웹 대화상자 · 권한 · 인증 · 렌더러 복구 ─────────────────────────

    // ── JS 알림창 (alert / confirm / prompt) ──

    /** 보이는 탭에서만 띄우고, 짧은 시간에 계속 띄우는 페이지(알림창 도배)는 막는다 */
    private fun jsDialogAllowed(tab: BrowserTab): Boolean {
        if (tab !== current || isFinishing || isDestroyed || switcherOpen) return false
        val now = android.os.SystemClock.uptimeMillis()
        if (now - tab.jsDialogAt > 4000L) tab.jsDialogCount = 0
        tab.jsDialogAt = now
        return ++tab.jsDialogCount <= 3
    }

    private fun jsDialogTitle(url: String?): String {
        val host = runCatching { Uri.parse(url).host }.getOrNull()
        return if (host.isNullOrBlank()) "페이지 메시지" else "$host 의 메시지"
    }

    /** kind: 0 = alert, 1 = confirm, 2 = prompt */
    private fun showJsDialog(
        url: String?, message: String?, kind: Int,
        defaultValue: String?, result: android.webkit.JsResult
    ) {
        var done = false
        fun finish(ok: Boolean, text: String? = null) {
            if (done) return
            done = true
            try {
                if (ok) {
                    if (result is android.webkit.JsPromptResult) result.confirm(text ?: "") else result.confirm()
                } else {
                    result.cancel()
                }
            } catch (e: Exception) {
                // 페이지가 이미 사라졌으면 무시
            }
        }
        val b = MaterialAlertDialogBuilder(this).setTitle(jsDialogTitle(url))
        var input: EditText? = null
        if (kind == 2) {
            val pad = dp(20)
            val box = FrameLayout(this)
            val field = EditText(this).apply {
                setText(defaultValue.orEmpty())
                setSelectAllOnFocus(true)
                setSingleLine()
            }
            Popup.styleInput(field)
            input = field
            box.setPadding(pad, dp(4), pad, 0)
            box.addView(field)
            b.setMessage(message.orEmpty()).setView(box)
        } else {
            b.setMessage(message.orEmpty())
        }
        b.setPositiveButton("확인") { _, _ -> finish(true, input?.text?.toString()) }
        if (kind != 0) b.setNegativeButton("취소") { _, _ -> finish(false) }
        // 뒤로가기/바깥 터치: alert 는 '확인'으로, confirm/prompt 는 '취소'로 처리
        b.setOnCancelListener { finish(kind == 0) }
        b.setOnDismissListener { finish(false) }
        b.show()
    }

    // ── 카메라 · 마이크 · 위치 권한 ──

    private val webPermDecisions = HashMap<String, Boolean>()
    private var webPermDialog: AlertDialog? = null
    private var webPermDone: (() -> Unit)? = null
    private val webPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val cb = webPermDone
            webPermDone = null
            cb?.invoke()
        }

    /**
     * 사이트가 카메라/마이크/위치를 쓰려 할 때: 사이트별로 허용/차단을 묻고(이번 실행 동안 기억),
     * 안드로이드 권한이 없으면 시스템 권한 창을 이어서 띄운다. anyOf: 목록 중 하나만 허용돼도 충분한지(위치).
     */
    private fun askWebPermission(
        origin: String, label: String, osPerms: List<String>, anyOf: Boolean, onDone: (Boolean) -> Unit
    ) {
        fun osOk() = if (anyOf) osPerms.any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        else osPerms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

        fun withOs() {
            if (osOk()) { onDone(true); return }
            webPermDone?.invoke()
            webPermDone = { onDone(osOk()) }
            webPermLauncher.launch(osPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray())
        }

        val key = "$origin|$label"
        when (webPermDecisions[key]) {
            true -> { withOs(); return }
            false -> { onDone(false); return }
            null -> Unit
        }
        if (isFinishing || isDestroyed) { onDone(false); return }
        webPermDialog?.dismiss()
        var answered = false
        val host = runCatching { Uri.parse(origin).host }.getOrNull() ?: origin
        webPermDialog = MaterialAlertDialogBuilder(this)
            .setTitle(host)
            .setMessage("이 사이트가 ${label}을(를) 사용하려고 합니다. 허용할까요?")
            .setPositiveButton("허용") { _, _ ->
                answered = true
                webPermDecisions[key] = true
                withOs()
            }
            .setNegativeButton("차단") { _, _ ->
                answered = true
                webPermDecisions[key] = false
                onDone(false)
            }
            .setOnDismissListener { if (!answered) onDone(false) }
            .show()
    }

    private fun handleWebPermissionRequest(request: android.webkit.PermissionRequest) {
        val res = request.resources.toList()
        val cam = android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE in res
        val mic = android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE in res
        val granted = ArrayList<String>()
        // 보호된 콘텐츠(DRM) 재생은 그대로 허용
        if (android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID in res) {
            granted.add(android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID)
        }
        if (!cam && !mic) {
            try {
                if (granted.isEmpty()) request.deny() else request.grant(granted.toTypedArray())
            } catch (e: Exception) { }
            return
        }
        val os = ArrayList<String>()
        if (cam) os.add(Manifest.permission.CAMERA)
        if (mic) os.add(Manifest.permission.RECORD_AUDIO)
        val label = when {
            cam && mic -> "카메라와 마이크"
            cam -> "카메라"
            else -> "마이크"
        }
        askWebPermission(request.origin.toString(), label, os, anyOf = false) { ok ->
            try {
                if (ok) {
                    if (cam) granted.add(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    if (mic) granted.add(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    request.grant(granted.toTypedArray())
                } else {
                    request.deny()
                }
            } catch (e: Exception) {
                // 요청이 이미 취소됨
            }
        }
    }

    private fun handleGeolocationRequest(origin: String, callback: android.webkit.GeolocationPermissions.Callback) {
        askWebPermission(
            origin, "위치",
            listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            anyOf = true
        ) { ok ->
            try { callback.invoke(origin, ok, false) } catch (e: Exception) { }
        }
    }

    // ── HTTP 로그인(Basic/Digest) 과 인증서 오류 ──

    private val pendingAuth = ArrayList<android.webkit.HttpAuthHandler>()

    @Suppress("DEPRECATION")
    private fun askHttpAuth(view: WebView, handler: android.webkit.HttpAuthHandler, host: String?, realm: String?) {
        if (isFinishing || isDestroyed) { handler.cancel(); return }
        // 같은 주소가 여러 요청으로 동시에 물어도 창은 하나만 띄우고 같은 답을 모두에게 준다
        if (pendingAuth.isNotEmpty()) { pendingAuth.add(handler); return }
        pendingAuth.add(handler)
        val saved = try { view.getHttpAuthUsernamePassword(host, realm) } catch (e: Exception) { null }
        val etUser = EditText(this).apply {
            hint = "사용자 이름"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setText(saved?.getOrNull(0).orEmpty())
        }
        val etPass = EditText(this).apply {
            hint = "비밀번호"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(saved?.getOrNull(1).orEmpty())
        }
        Popup.styleInput(etUser)
        Popup.styleInput(etPass)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
            addView(etUser)
            addView(etPass, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) })
        }
        val plain = view.url?.startsWith("http://") == true
        var done = false
        fun finish(ok: Boolean) {
            if (done) return
            done = true
            val list = pendingAuth.toList()
            pendingAuth.clear()
            for (h in list) {
                try {
                    if (ok) h.proceed(etUser.text.toString(), etPass.text.toString()) else h.cancel()
                } catch (e: Exception) { }
            }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("로그인이 필요합니다")
            .setMessage(
                (host ?: "") + (if (!realm.isNullOrBlank()) " · $realm" else "") +
                    (if (plain) "\n\n⚠ 이 연결은 암호화되어 있지 않아 입력한 비밀번호가 노출될 수 있어요." else "")
            )
            .setView(box)
            .setPositiveButton("로그인") { _, _ -> finish(true) }
            .setNegativeButton("취소") { _, _ -> finish(false) }
            .setOnDismissListener { finish(false) }
            .show()
    }

    private val sslAllowed = HashSet<String>()
    private val pendingSsl = ArrayList<android.webkit.SslErrorHandler>()

    private fun sslMessage(error: android.net.http.SslError): String = when (error.primaryError) {
        android.net.http.SslError.SSL_UNTRUSTED -> "이 사이트의 인증서를 신뢰할 수 없습니다. (발급 기관을 확인할 수 없음)"
        android.net.http.SslError.SSL_EXPIRED -> "이 사이트의 인증서가 만료되었습니다."
        android.net.http.SslError.SSL_IDMISMATCH -> "인증서가 이 사이트 주소와 일치하지 않습니다."
        android.net.http.SslError.SSL_NOTYETVALID -> "이 사이트의 인증서가 아직 유효하지 않습니다. (기기의 날짜·시간도 확인해 보세요)"
        android.net.http.SslError.SSL_DATE_INVALID -> "인증서의 날짜가 올바르지 않습니다. (기기의 날짜·시간도 확인해 보세요)"
        else -> "인증서에 문제가 있습니다."
    }

    /** 페이지 자체의 인증서 오류만 묻는다. 이미지·스크립트 같은 하위 요청의 오류는 조용히 막는다. */
    private fun askSslError(pageHost: String?, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
        val errHost = runCatching { Uri.parse(error.url).host }.getOrNull()
        if (errHost == null || errHost != pageHost || isFinishing || isDestroyed) {
            handler.cancel()
            return
        }
        val key = "$errHost|${error.primaryError}"
        if (key in sslAllowed) { handler.proceed(); return }
        if (pendingSsl.isNotEmpty()) { pendingSsl.add(handler); return }
        pendingSsl.add(handler)
        var done = false
        fun finish(proceed: Boolean) {
            if (done) return
            done = true
            if (proceed) sslAllowed.add(key)
            val list = pendingSsl.toList()
            pendingSsl.clear()
            for (h in list) {
                try { if (proceed) h.proceed() else h.cancel() } catch (e: Exception) { }
            }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("보안 연결이 아닙니다")
            .setMessage("$errHost\n\n${sslMessage(error)}\n\n계속하면 비밀번호나 카드 정보 같은 중요한 정보가 노출될 수 있어요.")
            .setPositiveButton("돌아가기") { _, _ -> finish(false) }
            .setNegativeButton("위험을 감수하고 계속") { _, _ -> finish(true) }
            .setOnDismissListener { finish(false) }
            .show()
    }

    // ── 렌더러 프로세스가 죽었을 때 (메모리 부족 등): 앱이 같이 꺼지지 않게 WebView 를 새로 만든다 ──

    private fun recoverRenderer(tab: BrowserTab, dead: WebView) {
        if (tab !in tabs || tab.liveWebView !== dead) {
            runCatching { dead.destroy() }
            return
        }
        val url = (if (tab.isHome) null else dead.url?.takeIf { it != "about:blank" && it != HOME_URL }) ?: tab.pendingUrl
        tab.pendingTitle = dead.title?.takeIf { it.isNotBlank() } ?: tab.pendingTitle
        val wasCurrent = tab === current
        val now = android.os.SystemClock.uptimeMillis()
        val looping = now - tab.crashAt < 10_000L
        tab.crashAt = now

        (dead.parent as? ViewGroup)?.removeView(dead)
        runCatching { dead.destroy() }
        val fresh = if (tab.incognito) newIncognitoWebView() else NestedWebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        tab.webView = fresh
        tab.mediaFrames.clear(); tab.sniffed.clear(); tab.sniffedSubs.clear()
        tab.progress = 100
        tab.errorUrl = null
        configure(tab)
        if (tab.desktop) applyUserAgent(fresh, true)
        onMediaChanged()

        if (wasCurrent) {
            tab.paused = false
            webContainer.addView(fresh)
            fresh.requestFocus()
            when {
                url == null -> if (tab.isHome) loadHome(tab)
                looping -> {
                    // 같은 페이지가 계속 죽으면 무한 새로고침 대신 안내 화면을 보여 준다
                    tab.errorUrl = url
                    fresh.loadDataWithBaseURL(
                        url, errorPageHtml(url, -1, "이 페이지를 열다가 계속 종료되었습니다"),
                        "text/html", "utf-8", url
                    )
                }
                else -> {
                    toast("메모리가 부족해 페이지가 종료되어 다시 불러옵니다")
                    fresh.loadUrl(url)
                }
            }
            updateUi()
        } else {
            // 보고 있지 않던 탭은 다시 선택할 때 불러온다
            tab.pendingUrl = url
            tab.paused = true
            fresh.onPause()
        }
        scheduleStripRefresh()
    }

    private fun configure(tab: BrowserTab) {
        val wv = tab.webView
        // 백그라운드 재생이 켜져 있고 이 탭에서 소리가 나는 중이면, 앱을 나가도 웹뷰가 멈추지 않게 한다
        (wv as? NestedWebView)?.keepPlaying = { prefs.backgroundAudio && tab.mediaFrames.isNotEmpty() }

        if (baseUserAgent.isEmpty()) baseUserAgent = wv.settings.userAgentString
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (tab.incognito && !profilesSupported) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            // 파일 업로드(<input type=file>)로 고른 파일은 content:// 주소로 오므로 켜 둬야 올라간다.
            // (웹페이지가 content:// 를 직접 불러올 수는 없어서 보안상 문제는 없다)
            allowContentAccess = true
            setGeolocationEnabled(true)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }
        // 일부 사이트(영상 서비스 등)가 WebView를 낮은 품질로 취급하는 것을 피하기 위해 UA(및 Client Hints)에서 WebView 표시 제거
        applyUserAgent(wv, false)
        // 재생 상태 감지 (백그라운드 재생 / PiP 용)
        wv.addJavascriptInterface(MediaJs(tab), "EvMedia")
        if (docStartScripts) {
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, MediaScripts.INJECT, setOf("*"))
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, MediaScripts.PULL_GUARD, setOf("*"))
            // 광고 영역 숨김 / 유튜브 영상 광고 건너뛰기 (페이지가 그려지기 전부터 적용)
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, AdBlocker.COSMETIC_START_JS, setOf("*"))
        }
        // WebView가 보내는 X-Requested-With(앱 패키지명) 헤더 제거 — 구글 등 로그인 차단/보안 경고의 주원인
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(wv.settings, emptySet())
        }
        // 사용자가 최근 화면을 만졌는지 기록 (로그인 팝업·앱 연동은 허용, 자동 팝업 광고는 계속 차단)
        wv.setOnTouchListener { _, _ -> lastTouchAt = android.os.SystemClock.uptimeMillis(); false }
        // 액티비티가 이미 hardwareAccelerated 이므로 WebView 에 별도 하드웨어 레이어를 씌우지 않는다.
        // 레이어를 씌우면 스크롤로 상단 메뉴가 숨겨져 WebView 가 커질 때, 늘어난 아래쪽 영역이
        // 레이어에 다시 그려지지 않아 흰 네모가 남는다.
        wv.setLayerType(View.LAYER_TYPE_NONE, null)
        applySecurity(wv, tab)
        applyWebAppearance(wv)
        applyAutofill(tab)
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.setOnScrollChangeListener { _, _, y, _, oldY ->
            if (tab === current) pageScrollBar.refresh()
            onPageScroll(tab, y, oldY)
        }

        // 현재 페이지의 호스트. shouldInterceptRequest 는 백그라운드 스레드에서 불리는데
        // 거기서 view.url 을 읽으면 WebView 스레드 위반으로 앱이 꺼지므로, 값을 따로 저장해서 쓴다.
        val pageHostRef = java.util.concurrent.atomic.AtomicReference<String?>(null)

        wv.webViewClient = object : WebViewClient() {
            override fun onScaleChanged(view: WebView, oldScale: Float, newScale: Float) {
                super.onScaleChanged(view, oldScale, newScale)
                (view as? NestedWebView)?.onPageScaleChanged(newScale)
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                if (request.isForMainFrame) {
                    // 스크립트가 띄운 팝업이 광고 서버로 가면 아무것도 안 보여주고 탭을 닫는다
                    if (adBlockEnabled && tab.scriptPopup && adBlocker.isAdHost(request.url.host)) {
                        adBlocker.record(request.url.host, AdBlocker.KIND_POPUP)
                        tab.adBlocked.incrementAndGet()
                        ui.post {
                            if (tab in tabs) {
                                toast("광고 팝업을 차단했습니다")
                                closeTab(tab)
                            }
                        }
                        return blockedResponse(request.url)
                    }
                    pageHostRef.set(request.url.host)
                    tab.adBlocked.set(0) // 새 페이지로 가면 '이 페이지' 차단 건수를 다시 센다
                    return null
                }
                val reqUrl = request.url.toString()
                if (adBlockEnabled &&
                    adBlocker.shouldBlock(
                        request.url.host, pageHostRef.get(), reqUrl,
                        NetFilter.inferType(
                            reqUrl, request.requestHeaders?.get("Accept"), false,
                            request.requestHeaders?.containsKey("Range") == true
                        )
                    )
                ) {
                    adBlocker.record(request.url.host, AdBlocker.KIND_REQUEST)
                    tab.adBlocked.incrementAndGet()
                    return blockedResponse(request.url, true)
                }
                sniffMedia(tab, request.url)
                if (strictTrackers) {
                    val block = try {
                        trackerBlocker.shouldBlock(request.url.host, pageHostRef.get())
                    } catch (e: Exception) {
                        false
                    }
                    if (block) {
                        trackerBlocker.blockedCount.incrementAndGet()
                        return blockedResponse(request.url, true)
                    }
                }
                return null
            }

            // 페이지를 불러오지 못하면 기본 오류 화면 대신 앱의 오류 화면을 보여 준다.
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (!request.isForMainFrame) return
                val url = request.url.toString()
                if (!(url.startsWith("http://") || url.startsWith("https://"))) return
                val desc = error.description?.toString().orEmpty()
                // 사용자가 직접 멈추거나 다운로드로 바뀐 경우는 오류가 아니다
                if (error.errorCode == WebViewClient.ERROR_UNKNOWN && desc.contains("ERR_ABORTED")) return
                // HTTPS 우선으로 올린 연결이 안 되면, 사용자가 허락할 때만 http 로 되돌아간다
                val orig = tab.upgradedFrom
                if (orig != null && url.startsWith("https://") &&
                    request.url.host == runCatching { Uri.parse(orig).host }.getOrNull() &&
                    error.errorCode != WebViewClient.ERROR_HOST_LOOKUP
                ) {
                    ui.post { askHttpFallback(tab, view, orig) }
                }
                tab.errorUrl = url
                val html = errorPageHtml(url, error.errorCode, desc)
                ui.post { view.loadDataWithBaseURL(url, html, "text/html", "utf-8", url) }
            }

            // 렌더러가 죽어도 앱이 꺼지지 않게 하고, 그 탭만 새로 만든다 (API 26+)
            override fun onRenderProcessGone(
                view: WebView,
                detail: android.webkit.RenderProcessGoneDetail
            ): Boolean {
                ui.post { recoverRenderer(tab, view) }
                return true
            }

            override fun onReceivedHttpAuthRequest(
                view: WebView, handler: android.webkit.HttpAuthHandler, host: String?, realm: String?
            ) {
                askHttpAuth(view, handler, host, realm)
            }

            override fun onReceivedSslError(
                view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError
            ) {
                askSslError(pageHostRef.get(), handler, error)
            }

            // 악성·피싱 사이트로 접속하려 하면 경고 화면을 띄우고 알려 준다.
            override fun onSafeBrowsingHit(
                view: WebView,
                request: WebResourceRequest,
                threatType: Int,
                callback: android.webkit.SafeBrowsingResponse
            ) {
                callback.showInterstitial(true)
                if (request.isForMainFrame) toast("⚠ 악성 사이트로 의심되어 접속을 막았습니다")
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "http" || scheme == "https") {
                    // 사용자 동작 없는 광고 서버 이동 / 스크립트 팝업의 광고 이동은 막는다
                    if (adBlockEnabled && request.isForMainFrame &&
                        (!request.hasGesture() || tab.scriptPopup) &&
                        adBlocker.isAdHost(request.url.host)
                    ) {
                        adBlocker.record(request.url.host, AdBlocker.KIND_POPUP)
                        tab.adBlocked.incrementAndGet()
                        if (tab.scriptPopup) {
                            ui.post {
                                if (tab in tabs) {
                                    toast("광고 팝업을 차단했습니다")
                                    closeTab(tab)
                                }
                            }
                        }
                        return true
                    }
                    // 뒤로가기 직후, 사용자 동작 없이 페이지가 스스로 다른 곳으로 보내려 하면 막는다.
                    // (뒤로가기를 눌러도 같은 페이지로 계속 튕겨 돌아오는 "뒤로가기 함정" 방지)
                    val from = view.url
                    if (prefs.blockBackRedirect && request.isForMainFrame && !request.hasGesture() && from != null &&
                        android.os.SystemClock.uptimeMillis() - tab.backAt < BACK_GUARD_MS
                    ) {
                        tab.redirectSources.add(from)
                        tab.backAt = 0L
                        toast("뒤로가기 중 자동 이동을 차단했습니다")
                        ui.post { if (canGoBackSmart(tab)) goBackSmart(tab) }
                        return true
                    }
                    // HTTPS 우선: http 링크는 https 로 올려서 연결한다
                    if (request.isForMainFrame) {
                        val prev = tab.upgradedFrom
                        if (prev != null && runCatching { Uri.parse(prev).host }.getOrNull() == request.url.host) {
                            // https 로 올렸더니 서버가 스스로 http 로 되돌려 보낸 경우: 무한 반복을 막고 그대로 둔다
                            request.url.host?.lowercase()?.let { httpAllowed.add(it) }
                            tab.upgradedFrom = null
                            return false
                        }
                        val up = upgradeUrl(request.url.toString())
                        if (up != null) {
                            tab.upgradedFrom = request.url.toString()
                            ui.post { view.loadUrl(up) }
                            return true
                        }
                    }
                    return false
                }

                // 웹 페이지가 내 기기 파일이나 다른 앱의 데이터로 이동하게 두지 않는다
                if (scheme == "about") return false
                if (scheme in BLOCKED_NAV_SCHEMES) return true

                // 사용자 동작 없이 외부 앱/스토어를 여는 리다이렉트(광고)는 차단
                if (!request.hasGesture() && !recentTouch()) return true

                return try {
                    val intent = if (scheme == "intent") {
                        Intent.parseUri(request.url.toString(), Intent.URI_INTENT_SCHEME).apply {
                            addCategory(Intent.CATEGORY_BROWSABLE)
                            component = null
                            selector = null
                            // 페이지가 파일 접근 권한을 끼워 넘기거나 내 파일을 가리키지 못하게 한다
                            flags = flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION).inv()
                            val ds = data?.scheme?.lowercase()
                            if (ds == "file" || ds == "content") throw SecurityException("blocked")
                        }
                    } else {
                        Intent(Intent.ACTION_VIEW, request.url)
                    }
                    startActivity(intent)
                    true
                } catch (e: ActivityNotFoundException) {
                    toast("이 링크를 열 수 있는 앱이 없습니다")
                    true
                } catch (e: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                (view as? NestedWebView)?.resetZoomTracking()
                // 홈 항목으로 들어가는 중: 덮개(홈 화면)만 보여 준다
                if (url == HOME_URL) {
                    tab.isHome = true
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                    return
                }
                pageHostRef.set(try { Uri.parse(url).host } catch (e: Exception) { null })
                tab.cosmeticInjected = false
                tab.desktopInjected = false
                tab.zoomInjected = false
                tab.darkInjected = false
                if (tab === current) { scrollAcc = 0; setBarsHidden(false) }
                // 다른 페이지로 넘어가면 이전 페이지의 찾기 결과는 의미가 없다
                if (tab.webView === findWebView) closeFind()
                tab.favicon = favicon
                if (url != "about:blank" && !url.startsWith("data:")) {
                    if (tab.isHome) tab.awaitCommit = true
                    tab.isHome = false
                }
                tab.stoppedByHome = false
                tab.sniffed.clear()
                tab.sniffedSubs.clear()
                if (tab.mediaFrames.isNotEmpty()) { tab.mediaFrames.clear(); onMediaChanged() }
                if (tab === current) updateUi()
            }

            // 새 페이지의 첫 화면이 그려졌다: 이제 웹뷰를 보여 준다 (그 전엔 이전 페이지가 비쳐 보였다)
            override fun onPageCommitVisible(view: WebView, url: String) {
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    ui.post { if (tab === current) updateUi() }
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (tab.awaitCommit) { tab.awaitCommit = false; if (tab === current) updateUi() }
                if (url == "about:blank") view.clearHistory()
                if (url == HOME_URL || view.url == HOME_URL) {
                    tab.isHome = true
                    tab.awaitCommit = false
                    if (tab.clearAtHome) { tab.clearAtHome = false; view.clearHistory() }
                }
                if (url.startsWith("https://")) tab.upgradedFrom = null
                // 문서 시작 스크립트로 이미 들어가 있으면 다시 실행하지 않는다 (페이지 완료 직후 JS 실행을 줄임)
                if (!docStartScripts) view.evaluateJavascript(MediaScripts.INJECT, null)
                // 문서 시작 스크립트를 못 쓰는 기기에서는 영상 배너 감지/팝업 차단 스크립트를 여기서 넣는다 (한 번만 돈다)
                if (!docStartScripts && adBlockEnabled) view.evaluateJavascript(AdBlocker.COSMETIC_START_JS, null)
                if (adBlockEnabled) view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                if (tab.desktop) view.evaluateJavascript(desktopViewportJs(), null)
                if (effectiveZoom(tab) != 100) view.evaluateJavascript(pageZoomJs(tab), null)
                if (tab.rate != 1f) view.evaluateJavascript(speedJs(tab.rate), null)
                if (needCssDark()) view.evaluateJavascript(forceDarkJs(true), null)
                // (저장은 백그라운드 스레드에서 — 메인 스레드에서 JSON을 읽고 쓰면 페이지 전환이 버벅인다)
                if (tab.errorUrl != null && url != tab.errorUrl) tab.errorUrl = null
                if (url.startsWith("http") && tab.errorUrl == null && !tab.incognito) {
                    val title = view.title
                    io.execute { prefs.addHistory(url, title) }
                }
                if (tab === current) {
                    updateUi()
                    pageScrollBar.bind(if (tab.isHome) null else view)
                    view.post { pageScrollBar.refresh() }
                    view.postDelayed({ pageScrollBar.refresh() }, 350)
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                tab.progress = if (tab.isHome) 100 else newProgress
                // 진행률 이벤트마다 JS를 실행하면 로딩이 느려지므로 페이지당 한 번만 넣는다. (끝날 때 한 번 더 확인)
                if (adBlockEnabled && newProgress >= 30 && !tab.cosmeticInjected) {
                    tab.cosmeticInjected = true
                    view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                }
                if (needCssDark() && newProgress >= 20 && !tab.darkInjected) {
                    tab.darkInjected = true
                    view.evaluateJavascript(forceDarkJs(true), null)
                }
                if (tab.desktop && newProgress >= 25 && !tab.desktopInjected) {
                    tab.desktopInjected = true
                    view.evaluateJavascript(desktopViewportJs(), null)
                }
                if (newProgress >= 25 && !tab.zoomInjected && effectiveZoom(tab) != 100) {
                    tab.zoomInjected = true
                    view.evaluateJavascript(pageZoomJs(tab), null)
                }
                if (tab === current) {
                    if (newProgress >= 100) webContainer.endRefresh()
                    showProgress(newProgress)
                }
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: android.webkit.JsResult): Boolean {
                if (!jsDialogAllowed(tab)) { result.confirm(); return true }
                showJsDialog(url, message, 0, null, result)
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: android.webkit.JsResult): Boolean {
                if (!jsDialogAllowed(tab)) { result.cancel(); return true }
                showJsDialog(url, message, 1, null, result)
                return true
            }

            override fun onJsPrompt(
                view: WebView, url: String?, message: String?, defaultValue: String?,
                result: android.webkit.JsPromptResult
            ): Boolean {
                if (!jsDialogAllowed(tab)) { result.cancel(); return true }
                showJsDialog(url, message, 2, defaultValue, result)
                return true
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                handleWebPermissionRequest(request)
            }

            override fun onPermissionRequestCanceled(request: android.webkit.PermissionRequest) {
                webPermDialog?.dismiss()
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String, callback: android.webkit.GeolocationPermissions.Callback
            ) {
                handleGeolocationRequest(origin, callback)
            }

            override fun onGeolocationPermissionsHidePrompt() {
                webPermDialog?.dismiss()
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                // 이전 선택창이 남아 있으면 취소 처리 (콜백을 안 부르면 이후 업로드가 먹통이 됨)
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    // 허용 형식(accept)을 처리하는 선택창이 없으면 모든 파일 선택창으로 다시 시도한다
                    try {
                        val any = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                            if (fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                            }
                        }
                        fileChooserLauncher.launch(Intent.createChooser(any, fileChooserParams.title ?: "파일 선택"))
                        true
                    } catch (e2: Exception) {
                        fileChooserCallback = null
                        filePathCallback.onReceiveValue(null)
                        toast("파일 선택 화면을 열 수 없어요")
                        false
                    }
                }
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                scheduleStripRefresh()
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                // 홈(새 탭) 화면에선 뒤에 남은 이전 페이지가 보내는 아이콘을 받지 않는다
                if (!tab.isHome) tab.favicon = icon
                scheduleStripRefresh()
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.keepScreenOn = true
                fullscreenContainer.visibility = View.VISIBLE
                browserUi.visibility = View.GONE
                setSystemBarsVisible(false)
                refreshPipParams()
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message
            ): Boolean {
                // 사용자 동작 없이 열리는 팝업(팝업 광고)은 차단
                if (!isUserGesture && !recentTouch()) return false
                val newTab = createTab(null, opener = tab)
                newTab.scriptPopup = true
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = newTab.webView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val target = tabs.firstOrNull { it.liveWebView === window } ?: return
                ui.post { closeTab(target) }
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            // 사용자가 화면을 만지지 않았는데 시작된 다운로드는 자동 다운로드로 보고 차단
            if (blockAutoDownload && !recentTouch(DOWNLOAD_TOUCH_MS)) {
                toast("자동 다운로드를 차단했습니다")
            } else {
                startDownload(url, userAgent, contentDisposition, mimeType)
            }
        }

        wv.setOnLongClickListener {
            val result = wv.hitTestResult
            val extra = result.extra
            when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (extra != null) showLinkMenu(extra, null)
                    extra != null
                }
                WebView.HitTestResult.IMAGE_TYPE -> {
                    if (extra != null) showLinkMenu(null, extra)
                    extra != null
                }
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    if (extra != null) {
                        val msg = Handler(Looper.getMainLooper()) { m ->
                            showLinkMenu(m.data.getString("url"), extra)
                            true
                        }.obtainMessage()
                        wv.requestFocusNodeHref(msg)
                    }
                    extra != null
                }
                else -> false
            }
        }
    }

    // ───────────────────────── 주소창 / 빠른 검색 ─────────────────────────

    private fun setupUrlBar() {
        suggestAdapter = SuggestAdapter(this, suggestItems)
        suggestAdapter.onRemove = { q ->
            prefs.removeRecentSearch(q)
            showRecentSearches()
        }
        suggestAdapter.onClearAll = {
            prefs.clearRecentSearches()
            showRecentSearches()
        }
        urlBar.setAdapter(suggestAdapter)
        urlBar.threshold = 1
        // 추천 / 최근 검색 창: 메뉴 팝업과 같은 연한 면 + 둥근 모서리 + 얇은 테두리, 주소창과 살짝 띄운다
        // 블러가 켜져 있으면 뒤가 비치는 반투명 유리 + 팝업 뒤 블러, 아니면 예전처럼 불투명
        suggestAdapter.onShown = { v -> Blur.behindRootOf(v, this, 10) }
        urlBar.setDropDownBackgroundDrawable(GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Blur.surface(this@MainActivity, com.google.android.material.R.attr.colorSurfaceContainer, Blur.supported(this@MainActivity)))
            setStroke(
                dp(1),
                ColorUtils.setAlphaComponent(
                    MaterialColors.getColor(urlBar, com.google.android.material.R.attr.colorOutlineVariant), 0x99
                )
            )
        })
        urlBar.dropDownVerticalOffset = dp(6)
        // 이미 입력창에 들어와 있을 때 빈 칸을 다시 누르면 최근 검색을 다시 보여 준다
        urlBar.setOnClickListener {
            if (urlBar.hasFocus() && !urlBar.isPopupShowing && urlBar.text.isNullOrBlank()) showRecentSearches()
        }

        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadFromInput(urlBar.text.toString())
                true
            } else {
                false
            }
        }

        urlBar.setOnItemClickListener { _, _, position, _ ->
            suggestAdapter.getItem(position)?.let { loadFromInput(it) }
        }

        urlBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                setBarsHidden(false)
                // 입력할 때는 전체 주소를 보여주고 전체 선택
                setUrlText(
                    if (current?.isHome == true) ""
                    else current?.webView?.url?.takeIf { it != "about:blank" && it != HOME_URL } ?: ""
                )
                urlBar.post {
                    urlBar.selectAll()
                    showRecentSearches()
                }
            } else {
                urlBar.dismissDropDown()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(urlBar.windowToken, 0)
                updateUi()
            }
        }

        urlBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher || !urlBar.hasFocus()) return
                suggestRunnable?.let { ui.removeCallbacks(it) }
                val q = s?.toString()?.trim().orEmpty()
                if (q.isEmpty()) {
                    showRecentSearches()
                    return
                }
                val r = Runnable { requestSuggestions(q) }
                suggestRunnable = r
                ui.postDelayed(r, 150)
            }
        })
    }

    /** 주소창에 평소 보여줄 짧은 주소 (https://www. 를 뗀 도메인) */
    private fun displayUrl(url: String?): String {
        if (url.isNullOrBlank() || url == "about:blank" || url == HOME_URL) return ""
        if (!url.startsWith("http")) return url
        val host = try { Uri.parse(url).host } catch (e: Exception) { null }
        return host?.removePrefix("www.") ?: url
    }

    /** 주소창 왼쪽 아이콘: https 면 자물쇠, 아니면 지구본 */
    private fun updateSecurityIcon(url: String?, incognito: Boolean = false) {
        val blank = url.isNullOrBlank() || url == "about:blank" || url == HOME_URL
        val secure = url?.startsWith("https://") == true
        val res = when {
            blank && incognito -> R.drawable.ic_incognito
            blank -> R.drawable.ic_search
            secure -> R.drawable.ic_lock
            else -> R.drawable.ic_globe
        }
        val icon = ContextCompat.getDrawable(this, res)?.mutate()
        icon?.setBounds(0, 0, dp(18), dp(18))
        icon?.setTint(
            if (incognito) incognitoTextColor
            else MaterialColors.getColor(urlBar, com.google.android.material.R.attr.colorOnSurfaceVariant)
        )
        urlBar.setCompoundDrawablesRelative(icon, null, null, null)
    }

    private fun setUrlText(text: String) {
        suppressWatcher = true
        suggestItems.clear()
        urlBar.setText(text)
        suppressWatcher = false
    }

    private fun requestSuggestions(q: String) {
        // 북마크를 먼저, 그다음 방문 기록
        val marks = prefs.bookmarks()
            .filter { it.url.contains(q, true) || it.title.contains(q, true) }
            .map { it.url }
            .take(2)
        val local = (marks + prefs.history()
            .filter { it.first.contains(q, true) || it.second.contains(q, true) }
            .map { it.first })
            .distinct()
            .take(4)
        setSuggestions(local)

        io.execute {
            try {
                val remote = Suggest.fetch(q)
                ui.post {
                    if (urlBar.text.toString().trim() == q) {
                        setSuggestions((local + remote.filter { it !in local }).take(8))
                    }
                }
            } catch (e: Exception) {
                // 자동완성 실패는 무시
            }
        }
    }

    /** 주소창에 들어오거나 입력을 모두 지웠을 때: 최근에 직접 검색한 글자를 보여 준다 (시크릿 탭에서는 보여 주지 않는다) */
    private fun showRecentSearches() {
        if (!urlBar.hasFocus()) return
        val items = if (current?.incognito == true) emptyList() else prefs.recentSearches().take(8)
        suggestAdapter.recentMode = items.isNotEmpty()
        suggestItems.clear()
        suggestItems.addAll(items)
        suggestAdapter.notifyDataSetChanged()
        if (items.isEmpty()) urlBar.dismissDropDown() else urlBar.showDropDown()
    }

    /** 주소가 아니라 검색어로 처리될 입력인가 (resolveInput 과 같은 기준) */
    private fun isSearchQuery(input: String): Boolean {
        if (input.startsWith("http://") || input.startsWith("https://")) return false
        val parts = input.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2 && SearchEngines.shortcuts.containsKey(parts[0].lowercase())) return true
        val isLocal = input.startsWith("localhost") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(input)
        if (!input.contains(" ") && (isLocal || input.contains("."))) return false
        return true
    }

    private fun setSuggestions(items: List<String>) {
        suggestAdapter.recentMode = false
        suggestItems.clear()
        suggestItems.addAll(items)
        suggestAdapter.notifyDataSetChanged()
        // 맨 위 추천이 주소면 사용자가 고르기 전에 도메인 조회를 해 둔다
        items.firstOrNull()?.let { if (it.startsWith("http")) prefetchDns(it) }
        if (items.isNotEmpty() && urlBar.hasFocus()) urlBar.showDropDown()
    }

    private fun resolveInput(input: String): String {
        if (input.startsWith("http://") || input.startsWith("https://")) return input

        // 빠른 검색 단축어 (예: "yt 노래", "n 날씨")
        val parts = input.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2) {
            SearchEngines.shortcuts[parts[0].lowercase()]?.let { return it + Uri.encode(parts[1]) }
        }

        val isLocal = input.startsWith("localhost") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(input)
        if (!input.contains(" ") && isLocal) return "http://$input"
        if (!input.contains(" ") && input.contains(".")) return "https://$input"

        return SearchEngines.byKey(prefs.engineKey).searchUrl + Uri.encode(input)
    }

    private fun loadFromInput(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val tab = current
        // 직접 검색한 글자는 최근 검색으로 남긴다 (시크릿 탭 제외)
        if (tab?.incognito != true && isSearchQuery(input)) prefs.addRecentSearch(input)
        val wasHome = tab?.isHome == true
        tab?.isHome = false
        // 홈 화면에서 연 주소는 홈을 그대로 보여 준 채 로딩하고, 새 페이지의 첫 화면이 그려지면 넘어간다
        // (예전에는 로딩 시작과 동시에 빈 웹뷰로 바뀌었다)
        if (tab != null && wasHome) {
            tab.awaitCommit = true
            ui.postDelayed({
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                }
            }, 12000)
        }
        var target = resolveInput(input)
        // HTTPS 우선: 직접 입력한 http 주소도 https 로 먼저 연결한다
        upgradeUrl(target)?.let {
            current?.upgradedFrom = target
            target = it
        }
        prefetchDns(target)
        current?.stoppedByHome = false
        current?.webView?.loadUrl(target)
        updateUi()
        urlBar.dismissDropDown()
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ───────────────────────── 컨트롤 / 뒤로가기 / UI ─────────────────────────

    private fun setupControls() {
        val goBack = { navBack(); Unit }
        val goForward = { navForward(); Unit }
        val reload = {
            val c = current
            if (c != null) {
                if (c.progress in 1..99) c.webView.stopLoading() else reloadTab(c)
            }
            Unit
        }
        val goHome = {
            // 홈도 하나의 기록으로 남긴다: 홈 → 뒤로가기 = 보던 페이지, 다시 앞으로가기 = 홈
            current?.let { if (!it.isHome) loadHome(it) }
            Unit
        }

        btnBack.setOnClickListener { goBack() }
        tbBack.setOnClickListener { goBack() }
        btnForward.setOnClickListener { goForward() }
        tbForward.setOnClickListener { goForward() }
        // 뒤로/앞으로 버튼을 꾹 누르면 기록 목록 → 누르면 그 페이지로 이동
        listOf(btnBack, tbBack).forEach {
            it.setOnLongClickListener { v -> showNavHistory(forward = false, anchor = v); true }
        }
        listOf(btnForward, tbForward).forEach {
            it.setOnLongClickListener { v -> showNavHistory(forward = true, anchor = v); true }
        }
        btnRefresh.setOnClickListener { reload() }
        btnHome.setOnClickListener { goHome() }
        tbHome.setOnClickListener { goHome() }
        tbDesktop.setOnClickListener { toggleDesktopSite() }
        tbAi.setOnClickListener { assistant?.show(tbAi) }
        btnTabs.setOnClickListener { openTabSwitcher() }
        btnBottomTabs.setOnClickListener { openTabSwitcher() }
        // 탭 버튼을 꾹 누르면 새 탭 추가
        listOf(btnTabs, btnBottomTabs, findViewById<View>(R.id.btnStripTabList)).forEach {
            it.setOnLongClickListener { v ->
                if (switcherOpen) return@setOnLongClickListener false
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                openNewTabAndFocus()
                true
            }
        }
        btnMenu.setOnClickListener { showMenu(it) }
        tbMenu.setOnClickListener { showMenu(it) }
        findViewById<View>(R.id.btnStripNewTab).setOnClickListener { openNewTabAndFocus() }
        // + 는 마지막 탭 옆을 따라가다 오른쪽 끝에서 멈춘다 (위치만 연속으로 바뀜)
        val stripLayoutWatcher = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateStripPlus() }
        tabStripScroll.addOnLayoutChangeListener(stripLayoutWatcher)
        tabStrip.addOnLayoutChangeListener(stripLayoutWatcher)
        tabStripScroll.setOnScrollChangeListener { _, _, _, _, _ -> updateStripPlus() }
        // 탭 줄 폭이 바뀌면(창 크기 조절·접이식 펼침·분할 화면) 탭 폭을 다시 계산한다
        tabStripScroll.addOnLayoutChangeListener { v, l, _, r, _, _, _, _, _ ->
            val w = r - l
            if (w != lastStripViewportW) {
                lastStripViewportW = w
                if (expanded && w > 0) scheduleStripRefresh()
            }
        }
        updateStripPlus()
        findViewById<View>(R.id.btnStripTabList).setOnClickListener { openTabSwitcher() }
        setupFindBar()
        listOf<View>(
            btnBack, btnForward, btnRefresh, btnHome, btnTabs, btnBottomTabs, btnMenu,
            tbBack, tbForward, tbHome, tbMenu, tbDesktop, tbAi,
            findViewById(R.id.btnStripNewTab), findViewById(R.id.btnStripTabList)
        ).forEach { addPressAnim(it) }
    }

    /**
     * 상단 탭 줄의 새 탭(+) 위치. + 는 하나만 두고 translationX 로 움직인다.
     *  - 탭이 적으면 마지막 탭 바로 옆
     *  - 탭이 많아 넘치면 오른쪽 끝에 멈춰 스크롤해도 항상 보임
     * 보이기/숨기기 전환이 없고 탭 폭 애니메이션·스크롤 중에도 매 프레임 연속으로 따라가므로 깜박이거나 튀지 않는다.
     */
    private var stripPlusBg: android.graphics.drawable.ColorDrawable? = null

    private fun updateStripPlus() {
        val holder = findViewById<View>(R.id.stripPlusHolder) ?: return
        val fade = findViewById<View>(R.id.stripPlusFade) ?: return
        val viewport = tabStripScroll.width
        if (viewport <= 0) return

        if (stripPlusBg == null) {
            val c = getColor(R.color.ev_tabbar)
            stripPlusBg = android.graphics.drawable.ColorDrawable(c)
            holder.background = stripPlusBg
            fade.background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(c and 0x00FFFFFF, c)
            )
        }

        // 따라가는 위치(마지막 탭 옆)와 오른쪽 끝 멈춤 위치 중 더 왼쪽
        val follow = tabStripScroll.paddingStart + tabStrip.width - tabStripScroll.scrollX
        val rightStop = viewport - holder.width
        val x = minOf(follow, rightStop).coerceAtLeast(0)
        holder.translationX = x.toFloat()
        fade.translationX = (x - fade.width).toFloat()

        // 멈춤 위치를 넘어 탭이 + 밑으로 들어오기 시작하면 배경·그라데이션을 부드럽게 켠다
        val covered = ((follow - rightStop) / dp(16).toFloat()).coerceIn(0f, 1f)
        stripPlusBg?.alpha = (255 * covered).toInt()
        fade.alpha = covered
    }

    // ───────────────────────── 페이지 내 찾기 ─────────────────────────

    /** 지금 찾기 결과를 칠해 둔 WebView (탭을 옮기거나 닫을 때 이 뷰의 표시를 지운다) */
    private var findWebView: WebView? = null

    private fun setupFindBar() {
        etFind.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = runFind(s?.toString().orEmpty())
        })
        etFind.setOnEditorActionListener { _, actionId, ev ->
            val enter = ev?.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                findStep(!(ev?.isShiftPressed ?: false))
                true
            } else false
        }
        findViewById<View>(R.id.findNext).setOnClickListener { findStep(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { findStep(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }
        listOf<View>(
            findViewById(R.id.findNext), findViewById(R.id.findPrev), findViewById(R.id.findClose)
        ).forEach { addPressAnim(it) }
    }

    private fun openFind() {
        val tab = current ?: return
        if (tab.isHome) {
            toast("웹 페이지를 연 뒤에 찾을 수 있어요")
            return
        }
        // 위쪽 바가 스크롤로 숨겨져 있으면 찾기 바도 같이 올라가 버리므로 먼저 되돌린다.
        setBarsHidden(false)
        findBar.visibility = View.VISIBLE
        findWebView = tab.webView
        etFind.requestFocus()
        etFind.selectAll()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(etFind, InputMethodManager.SHOW_IMPLICIT)
        runFind(etFind.text.toString())
    }

    private fun closeFind() {
        if (findBar.visibility != View.VISIBLE) return
        findWebView?.let {
            // 탭이 닫히며 WebView가 이미 정리된 뒤일 수 있다
            try { it.clearMatches(); it.setFindListener(null) } catch (_: Exception) {}
        }
        findWebView = null
        findBar.visibility = View.GONE
        findCount.text = ""
        etFind.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etFind.windowToken, 0)
        current?.webView?.requestFocus()
    }

    private fun runFind(query: String) {
        val wv = findWebView ?: return
        if (query.isEmpty()) {
            wv.clearMatches()
            findCount.text = ""
            return
        }
        wv.setFindListener { active, total, _ ->
            findCount.text = if (total == 0) "없음" else "${active + 1}/$total"
        }
        wv.findAllAsync(query)
    }

    private fun findStep(forward: Boolean) {
        if (etFind.text.isNullOrEmpty()) return
        findWebView?.findNext(forward)
    }

    private fun setupHome() {
        // 위쪽에 연한 초록빛이 번지는 배경
        val base = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorSurfaceContainer)
        val tint = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorPrimaryContainer)
        homeView.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(androidx.core.graphics.ColorUtils.blendARGB(base, tint, 0.65f), base, base)
        )
        refreshHomeShortcuts()
        // 창 크기가 바뀔 때마다(분할 화면·플로팅 창 등) 홈 폭을 다시 맞춘다.
        homeView.addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
            if (right - left != oldRight - oldLeft) homeContent.post { applyHomeWidth() }
        }
        homeContent.post { applyHomeWidth() }
    }

    /** 넓은 창에서는 560dp 로 가운데 정렬, 그보다 좁으면 창 폭에 꽉 맞춰 양쪽이 잘리지 않게 한다. */
    private fun applyHomeWidth() {
        val parentW = homeView.width
        if (parentW <= 0) return
        val lp = homeContent.layoutParams as? FrameLayout.LayoutParams ?: return
        val target = if (parentW > dp(560)) dp(560) else ViewGroup.LayoutParams.MATCH_PARENT
        if (lp.width != target) {
            lp.width = target
            lp.gravity = Gravity.CENTER_HORIZONTAL
            homeContent.layoutParams = lp
        }
    }

    // ───────────────────────── 홈 즐겨찾기 ─────────────────────────

    /** 저장된 즐겨찾기로 홈 타일을 다시 그린다. 누르면 열고, 길게 누르면 편집·삭제·이동. */
    private fun refreshHomeShortcuts() {
        val box = findViewById<LinearLayout>(R.id.homeShortcuts)
        box.removeAllViews()
        val list = prefs.homeShortcuts()

        val onSurface = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorOnSurface)
        val surface = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorSurface)
        val muted = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorOnSurfaceVariant)
        // 즐겨찾기 아이콘은 흑백: 면은 테마 글자색을 연하게 섞고, 글자는 테마 글자색 그대로

        fun tile(
            glyph: String, label: String, accent: Int?,
            onClick: () -> Unit, onLong: (() -> Unit)?
        ): View {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
                if (onLong != null) setOnLongClickListener {
                    it.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    onLong()
                    true
                }
            }
            val face = FrameLayout(this).apply {
                // 타일 면: 라이트 모드는 흰색, 다크 모드는 검은색. 글자·아이콘은 면과 대비되는 색
                val night = systemNight()
                val faceColor = if (night) android.graphics.Color.BLACK else android.graphics.Color.WHITE
                val lineColor = androidx.core.graphics.ColorUtils.setAlphaComponent(muted, if (night) 0x40 else 0x33)
                val bg = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(22).toFloat()
                    if (accent != null) {
                        setColor(faceColor)
                        setStroke(dp(1), androidx.core.graphics.ColorUtils.setAlphaComponent(muted, 0x22))
                    } else {
                        // '추가' 칸: 비어 있는 자리처럼 보이게 점선 테두리만
                        setColor(android.graphics.Color.TRANSPARENT)
                        setStroke((1.5f * resources.displayMetrics.density).toInt(), lineColor, dp(5).toFloat(), dp(4).toFloat())
                    }
                }
                if (accent != null) elevation = dp(3).toFloat()
                val fg: Int = when {
                    night -> if (accent != null) 0xFFE8EAED.toInt() else 0xFF9AA0A6.toInt()
                    else -> if (accent != null) 0xFF202124.toInt() else 0xFF5F6368.toInt()
                }
                background = bg
                if (accent != null) {
                    addView(TextView(context).apply {
                        text = glyph
                        gravity = Gravity.CENTER
                        textSize = 22f
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        setTextColor(fg)
                    }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                } else {
                    addView(ImageView(context).apply {
                        setImageResource(R.drawable.ic_add)
                        imageTintList = android.content.res.ColorStateList.valueOf(fg)
                        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
                }
            }
            col.addView(face, LinearLayout.LayoutParams(dp(62), dp(62)))
            col.addView(
                TextView(this).apply {
                    text = label
                    textSize = 12.5f
                    maxLines = 1
                    gravity = Gravity.CENTER
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(muted)
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(9)
                    marginStart = dp(2); marginEnd = dp(2)
                }
            )
            addPressAnim(col)
            return col
        }

        val tiles = ArrayList<View>()
        list.forEachIndexed { i, sc ->
            val glyph = sc.glyph.ifBlank { sc.name.trim().take(1).uppercase() }.ifBlank { "•" }
            tiles.add(tile(glyph, sc.name, onSurface, { loadFromInput(sc.url) }, { showShortcutMenu(i) }))
        }
        if (list.size < MAX_HOME_SHORTCUTS) {
            tiles.add(tile("+", "추가", null, { showShortcutDialog(null, -1) }, null))
        }
        val perRow = 4
        tiles.chunked(perRow).forEachIndexed { r, rowTiles ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowTiles.forEach { line.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
            repeat(perRow - rowTiles.size) { line.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            box.addView(
                line,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (r > 0) topMargin = dp(24)
                }
            )
        }
    }

    private fun showShortcutMenu(index: Int) {
        val list = prefs.homeShortcuts()
        val sc = list.getOrNull(index) ?: return
        val items = mutableListOf<Popup.Item>()
        items.add(Popup.Item(R.drawable.ic_edit, "편집", sc.url) { showShortcutDialog(sc, index) })
        if (index > 0) {
            items.add(Popup.Item(R.drawable.ic_back, "앞으로 옮기기") {
                val m = list.toMutableList()
                m.add(index - 1, m.removeAt(index))
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
            })
        }
        if (index < list.size - 1) {
            items.add(Popup.Item(R.drawable.ic_forward, "뒤로 옮기기") {
                val m = list.toMutableList()
                m.add(index + 1, m.removeAt(index))
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
            })
        }
        items.add(Popup.Item(R.drawable.ic_delete, "삭제", danger = true) {
            prefs.saveHomeShortcuts(list.filterIndexed { i, _ -> i != index })
            refreshHomeShortcuts()
        })
        Popup.menu(this, sc.name, items = items)
    }

    /** 추가(existing == null) 또는 편집 창. 주소에 https:// 가 없으면 붙여 준다. */
    private fun showShortcutDialog(existing: HomeShortcut?, index: Int) {
        val v = layoutInflater.inflate(R.layout.dialog_shortcut, null)
        val etName = v.findViewById<EditText>(R.id.etScName)
        val etUrl = v.findViewById<EditText>(R.id.etScUrl)
        val til = v.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilScUrl)
        if (existing != null) {
            etName.setText(existing.name)
            etUrl.setText(existing.url)
        }
        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "즐겨찾기 추가" else "즐겨찾기 편집")
            .setView(v)
            .setPositiveButton("저장", null)
            .setNegativeButton("취소", null)
        if (existing == null) builder.setNeutralButton("기본값으로", null)
        val dlg = builder.create()
        dlg.setOnShowListener {
            dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var url = etUrl.text.toString().trim()
                if (url.isEmpty() || url.contains(' ')) {
                    til.error = "올바른 주소를 입력해 주세요"
                    return@setOnClickListener
                }
                if (!Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(url)) url = "https://$url"
                val host = Uri.parse(url).host?.removePrefix("www.")
                if (host.isNullOrBlank()) {
                    til.error = "올바른 주소를 입력해 주세요"
                    return@setOnClickListener
                }
                val name = etName.text.toString().trim().ifEmpty { host }
                val glyph = if (existing != null && existing.name == name) existing.glyph else ""
                val m = prefs.homeShortcuts().toMutableList()
                val sc = HomeShortcut(name, url, glyph)
                if (existing != null && index in m.indices) m[index] = sc else m.add(sc)
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
                dlg.dismiss()
            }
            if (existing == null) {
                dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    prefs.resetHomeShortcuts()
                    refreshHomeShortcuts()
                    dlg.dismiss()
                    toast("기본 즐겨찾기로 되돌렸어요")
                }
            }
        }
        dlg.show()
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    switcherOpen -> closeTabSwitcher()
                    findBar.visibility == View.VISIBLE -> closeFind()
                    customView != null -> hideCustomView()
                    navBack() -> Unit
                    tabs.size > 1 -> current?.let { closeTab(it) }
                    else -> {
                        // 더 이동할 기록이 없을 때: 한 번만 눌러서 앱이 꺼지지 않게, 2초 안에 한 번 더 눌러야 종료
                        val now = android.os.SystemClock.uptimeMillis()
                        if (now - lastExitBackAt < 2000L) {
                            // 종료(홈으로 나가기) 동작을 시스템에 넘기되, 앱이 살아 있는 채로 돌아올 수 있으니
                            // 바로 다시 켜 둔다. (꺼진 채로 두면 이후 뒤로가기가 전부 앱 종료로 처리된다)
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        } else {
                            lastExitBackAt = now
                            toast("한 번 더 누르면 앱이 종료돼요")
                        }
                    }
                }
            }
        })
    }

    /** 마지막으로 "종료하려고 뒤로가기"를 누른 시각 (두 번 눌러야 종료) */
    private var lastExitBackAt = 0L

    private fun updateUi() {
        val tab = current ?: return
        val wv = tab.webView
        if (!urlBar.hasFocus()) {
            setUrlText(if (tab.isHome) "" else displayUrl(wv.url))
        }
        applyIncognitoUi(tab.incognito)
        updateSecureFlag()
        updateSecurityIcon(if (tab.isHome) null else wv.url, tab.incognito)
        updateDesktopButton()
        // 홈 화면은 웹 기록의 한 항목이라 이전 페이지는 이미 내려가 있다 (영상·소리도 같이 멈춘다).
        if (tab.isHome) {
            tab.awaitCommit = false
            wv.visibility = View.INVISIBLE
        } else {
            wv.visibility = if (tab.awaitCommit) View.INVISIBLE else View.VISIBLE
            if (tab.paused) {
                tab.paused = false
                wv.onResume()
            }
            if (tab.stoppedByHome) {
                tab.stoppedByHome = false
                reloadTab(tab)
            }
        }
        if (tab.isHome || tab.awaitCommit) {
            if (homeView.visibility != View.VISIBLE) {
                hideKeyboard()
                homeView.alpha = 1f
                homeView.visibility = View.VISIBLE
                (homeContent as? ViewGroup)?.let { Motion.stagger(it, 0, 55, 330) }
            }
        } else {
            homeView.visibility = View.GONE
        }
        showProgress(tab.progress)
        val canBack = canNavBack(tab)
        val canForward = canNavForward(tab)
        listOf(btnBack, tbBack).forEach {
            it.isEnabled = canBack
            it.alpha = if (canBack) 1f else 0.35f
        }
        listOf(btnForward, tbForward).forEach {
            it.isEnabled = canForward
            it.alpha = if (canForward) 1f else 0.35f
        }
        updateTabCount()
        refreshPipParams()
    }

    private var loadingIcon = false

    /** 뒤로 갈 때 '스스로 되돌려 보내는 페이지'를 건너뛰어 도착할 기록의 상대 위치 (없으면 0). */
    private fun backTarget(tab: BrowserTab): Int {
        val list = tab.webView.copyBackForwardList()
        var i = list.currentIndex - 1
        // 차단 옵션을 끄면 예전에 기록해 둔 '튕기는 페이지'도 건너뛰지 않고 그냥 한 칸씩 간다
        if (prefs.blockBackRedirect) {
            while (i >= 0 && tab.redirectSources.contains(list.getItemAtIndex(i).url)) i--
        }
        return if (i >= 0) i - list.currentIndex else 0
    }

    private fun canGoBackSmart(tab: BrowserTab): Boolean = backTarget(tab) != 0

    /** 홈 항목을 불러온다 (새 탭 화면). 웹 기록에 한 칸으로 남는다. clear 면 다 불러온 뒤 기록을 비운다. */
    private fun loadHome(tab: BrowserTab, clear: Boolean = false) {
        tab.errorUrl = null
        tab.isHome = true
        tab.awaitCommit = false
        tab.clearAtHome = clear
        tab.webView.loadDataWithBaseURL(HOME_URL, HOME_HTML, "text/html", "utf-8", HOME_URL)
        if (tab === current) {
            pageScrollBar.bind(null)
            updateUi()
        }
    }

    /** 기록 이동으로 도착할 항목(target)이 홈인지에 맞춰, 홈 화면 덮개를 바로 켜거나 끈다 */
    private fun applyHomeFor(tab: BrowserTab, target: String?) {
        val toHome = target == HOME_URL
        if (toHome == tab.isHome) return
        tab.isHome = toHome
        if (!toHome) {
            // 홈에서 페이지로 돌아가는 중: 새 페이지의 첫 화면이 그려질 때까지 홈을 보여 준다
            tab.awaitCommit = true
            ui.postDelayed({
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                }
            }, 12000)
        }
        if (tab === current) {
            pageScrollBar.bind(if (toHome) null else tab.webView)
            updateUi()
        }
    }

    /** 뒤로가기. 새 탭(홈) 화면도 웹 기록의 한 칸이라서, 페이지 → 뒤로 → 홈 → 앞으로 → 페이지 로 오갈 수 있다. */
    private fun navBack(): Boolean {
        val c = current ?: return false
        if (!canGoBackSmart(c)) return false
        goBackSmart(c)
        return true
    }

    /** 앞으로 가기 (홈 항목 포함) */
    private fun navForward(): Boolean {
        val c = current ?: return false
        val wv = c.webView
        if (!wv.canGoForward()) return false
        val list = wv.copyBackForwardList()
        val target = list.getItemAtIndex(list.currentIndex + 1)?.url
        wv.goForward()
        applyHomeFor(c, target)
        return true
    }

    private fun canNavBack(tab: BrowserTab): Boolean = canGoBackSmart(tab)

    private fun canNavForward(tab: BrowserTab): Boolean = tab.webView.canGoForward()

    /** 같은 페이지인지 비교하는 열쇠: 추적/세션용 주소 꼬리표는 무시한다 (구글 검색은 검색어만 본다). */
    private fun historyKey(url: String): String {
        val u = runCatching { Uri.parse(url) }.getOrNull() ?: return url
        val host = (u.host ?: return url.substringBefore('#').trimEnd('/')).lowercase().removePrefix("www.")
        val path = (u.path ?: "").trimEnd('/')
        if (host.startsWith("google.") || host.contains(".google.")) {
            if (path == "/search") return "google-search:" + (u.getQueryParameter("q") ?: "")
            if (path == "/webhp" || path.isEmpty()) return "google-home"
        }
        val noise = setOf(
            "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
            "fbclid", "gclid", "sxsrf", "ved", "ei", "iflsig", "sca_esv", "source",
            "uact", "oq", "gs_lp", "sclient", "biw", "bih", "dpr", "fbs", "si", "sa"
        )
        val query = runCatching { u.queryParameterNames }.getOrNull().orEmpty()
            .filter { it !in noise }.sorted()
            .joinToString("&") { "$it=${u.getQueryParameter(it).orEmpty()}" }
        return "$host$path" + if (query.isEmpty()) "" else "?$query"
    }

    /** 기록 목록에 보여줄 짧은 주소: 사이트 + 경로만, 검색은 검색어만, 너무 길면 …로 줄인다. */
    private fun shortUrl(url: String): String {
        val u = runCatching { Uri.parse(url) }.getOrNull() ?: return url.take(48)
        val host = u.host?.removePrefix("www.") ?: return url.removePrefix("https://").removePrefix("http://").take(48)
        val path = (u.path ?: "").trimEnd('/')
        val q = u.getQueryParameter("q") ?: u.getQueryParameter("query") ?: u.getQueryParameter("search_query")
        val tail = when {
            !q.isNullOrBlank() -> "  ·  검색: $q"
            u.query.isNullOrEmpty() -> ""
            else -> "?…"
        }
        val full = host + path + tail
        return if (full.length <= 48) full else full.take(47) + "…"
    }

    /** 뒤로/앞으로 버튼을 꾹 눌렀을 때: 이 탭의 이동 기록을 목록으로 보여주고, 고르면 그 페이지로 이동한다. */
    private fun showNavHistory(forward: Boolean, anchor: View? = null) {
        val tab = current ?: return
        val wv = tab.webView
        val list = try { wv.copyBackForwardList() } catch (e: Exception) { return }
        val cur = list.currentIndex
        // 뒤로: 가까운(최근) 기록부터 / 앞으로: 가까운 기록부터
        val indices = if (forward) (cur + 1 until list.size).toList() else (cur - 1 downTo 0).toList()
        if (indices.isEmpty()) {
            toast(if (forward) "앞으로 갈 기록이 없어요" else "뒤로 갈 기록이 없어요")
            return
        }
        // 중복 정리: 지금 보는 페이지와 같거나, 앞에서 이미 나온 페이지는 건너뛴다 (가장 가까운 것만 남김)
        val seen = HashSet<String>()
        list.getItemAtIndex(cur)?.url?.let { seen.add(historyKey(it)) }
        val items = ArrayList<Popup.Item>()
        for (i in indices) {
            if (items.size >= 30) break
            val entry = list.getItemAtIndex(i) ?: continue
            val url = entry.url ?: continue
            if (!seen.add(historyKey(url))) continue
            val isHomeEntry = url == HOME_URL
            val host = runCatching { Uri.parse(url).host }.getOrNull()
            val label = if (isHomeEntry) (if (tab.incognito) "시크릿 탭" else "새 탭")
                else entry.title?.takeIf { it.isNotBlank() } ?: host ?: url
            items.add(
                Popup.Item(
                    icon = if (isHomeEntry) R.drawable.ic_leaf_pixel else R.drawable.ic_globe,
                    label = label,
                    sub = if (isHomeEntry) null else shortUrl(url),
                    compactSub = true
                ) {
                    val offset = i - wv.copyBackForwardList().currentIndex
                    if (offset != 0) wv.goBackOrForward(offset)
                    applyHomeFor(tab, url)
                    updateUi()
                }
            )
        }
        if (items.isEmpty()) {
            toast(if (forward) "앞으로 갈 기록이 없어요" else "뒤로 갈 기록이 없어요")
            return
        }
        val title = if (forward) "앞으로 가기 기록" else "뒤로 가기 기록"
        val icon = if (forward) R.drawable.ic_forward else R.drawable.ic_back
        val tablet = resources.configuration.smallestScreenWidthDp >= 600
        if (tablet && anchor != null && anchor.isShown) {
            // 태블릿: 누른 뒤로/앞으로 버튼 바로 아래에 붙여서 띄운다
            Popup.menuAnchored(
                this, anchor,
                title = title,
                subtitle = "누르면 그 페이지로 이동해요",
                headerIcon = icon,
                items = items
            )
        } else {
            Popup.menu(
                this,
                title = title,
                subtitle = "누르면 그 페이지로 이동해요",
                headerIcon = icon,
                items = items
            )
        }
    }

    private fun goBackSmart(tab: BrowserTab) {
        val offset = backTarget(tab)
        if (offset == 0) return
        tab.backAt = android.os.SystemClock.uptimeMillis()
        val list = tab.webView.copyBackForwardList()
        val target = list.getItemAtIndex(list.currentIndex + offset)?.url
        tab.webView.goBackOrForward(offset)
        applyHomeFor(tab, target)
    }

    private fun hasPage(tab: BrowserTab): Boolean =
        tab.webView.url?.let { it != "about:blank" && it != HOME_URL } == true

    /** 로딩 바를 부드럽게 채우고, 끝나면 서서히 사라지게. 로딩 중에는 새로고침 버튼이 X(중지)로 바뀐다. */
    private fun showProgress(p: Int) {
        if (isInPictureInPictureModeCompat() && customView == null) return   // PiP 에서는 로딩 바도 숨긴 채로 둔다
        val loading = p in 1..99
        if (loading) {
            progressBar.animate().cancel()
            progressBar.alpha = 1f
            progressBar.visibility = View.VISIBLE
            progressBar.setProgress(p, true)
        } else if (progressBar.visibility == View.VISIBLE) {
            progressBar.setProgress(100, true)
            progressBar.animate().alpha(0f).setStartDelay(150).setDuration(250).withEndAction {
                progressBar.visibility = View.GONE
                progressBar.progress = 0
                progressBar.animate().setStartDelay(0)
            }.start()
        }
        if (loading != loadingIcon) {
            loadingIcon = loading
            val res = if (loading) R.drawable.ic_close else R.drawable.ic_refresh
            btnRefresh.setImageResource(res)
        }
    }

    /** 버튼을 누르면 쏙 들어갔다가 탄성 있게 튀어 돌아오는 효과 (스프링) */
    private fun addPressAnim(v: View) {
        Motion.pressable(v, 0.86f)
    }

    private fun hideCustomView() {
        val view = customView ?: return
        fullscreenContainer.removeView(view)
        fullscreenContainer.keepScreenOn = false
        fullscreenContainer.visibility = View.GONE
        browserUi.visibility = View.VISIBLE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        setSystemBarsVisible(true)
        refreshPipParams()
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
            // 전체화면 영상이 끝나면, 스크롤로 바가 숨겨진 상태일 때 상태표시줄도 다시 숨김
            statusBarHiddenByScroll = false
            if (customView == null) applyStatusBarForScroll(barsTarget == 1f)
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ───────────────────────── 메뉴 ─────────────────────────

    /**
     * 메뉴. 폰에서는 아래에서 올라오는 시트, 태블릿(최소 폭 600dp 이상)에서는 누른 버튼 바로 아래에 뜨는 팝업.
     * @param anchor 눌린 메뉴 버튼 (태블릿 팝업을 붙일 기준)
     */
    private var menuAnchorRight = -1
    private var menuAnchorBottom = -1
    /** 태블릿 메뉴를 띄운 버튼 (목록 팝업의 ← 로 돌아올 때 메뉴를 같은 자리에 다시 띄우려고) */
    private var menuAnchorRef: java.lang.ref.WeakReference<View>? = null

    /** 목록 팝업(다운로드 / 방문 기록 / 북마크)을 여는 intent. 태블릿이면 메뉴가 떠 있던 자리를 같이 넘긴다. */
    private fun listIntent(cls: Class<*>): Intent = Intent(this, cls).apply {
        if (resources.configuration.smallestScreenWidthDp >= 600 && menuAnchorRight > 0 && menuAnchorBottom > 0) {
            putExtra(ListUi.EXTRA_ANCHOR_RIGHT, menuAnchorRight)
            putExtra(ListUi.EXTRA_ANCHOR_BOTTOM, menuAnchorBottom)
        }
    }

    private var menuReopenAnchor: java.lang.ref.WeakReference<View>? = null

    /** 북마크·방문 기록·다운로드 화면에서 뒤로 나오면 그 화면을 열었던 메뉴를 다시 연다. */
    private fun reopenMenuAfterList() {
        // 태블릿: 목록 팝업의 ←/뒤로가기가 ListUi.reopenMenu 를 켜 두면 onResume 이 메뉴를 다시 띄운다
        // (바깥을 눌러 닫은 경우는 일부러 메뉴 없이 닫힌다). 여기서 또 열면 메뉴가 두 번 뜬다.
        if (resources.configuration.smallestScreenWidthDp >= 600) return
        ui.post {
            if (isFinishing || isDestroyed) return@post
            val a = menuReopenAnchor?.get()?.takeIf { it.isAttachedToWindow }
                ?: (if (tbMenu.isShown) tbMenu else btnMenu)
            showMenu(a)
        }
    }

    private fun showMenu(anchor: View? = null, settings: Boolean = false) {
        menuReopenAnchor = anchor?.let { java.lang.ref.WeakReference(it) }
        val tabletPopup = anchor != null && anchor.isShown &&
            resources.configuration.smallestScreenWidthDp >= 600
        if (tabletPopup) menuAnchorRef = java.lang.ref.WeakReference(anchor)
        val sheet = if (tabletPopup) null else BottomSheetDialog(this)
        var popup: PopupWindow? = null
        var closedByUs = false
        fun dismissMenu() {
            closedByUs = true
            sheet?.dismiss()
            popup?.dismiss()
        }
        val view = layoutInflater.inflate(R.layout.dialog_menu, null)
        val list = view.findViewById<LinearLayout>(R.id.menuList)
        // 손잡이는 아래에서 올라오는 시트에만 (태블릿 카드 팝업에는 필요 없다)
        if (sheet == null) view.findViewById<View>(R.id.sheetHandle).visibility = View.GONE
        view.findViewById<View>(R.id.btnCloseMenu).setOnClickListener { dismissMenu() }
        if (settings) {
            view.findViewById<TextView>(R.id.menuTitle).text = "설정"
            view.findViewById<View>(R.id.btnMenuBack).apply {
                visibility = View.VISIBLE
                setOnClickListener {
                    dismissMenu()
                    showMenu(anchor)
                }
            }
        }

        // 맨 위: 지금 보는 페이지의 링크 공유 카드 (미리보기 · 제목 · 주소 · 공유 버튼)
        val shareCur = current
        val shareUrl = shareCur?.webView?.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        if (!settings && shareCur != null && !shareCur.isHome && shareUrl != null) {
            view.findViewById<View>(R.id.shareCard).visibility = View.VISIBLE
            view.findViewById<TextView>(R.id.shareTitle).text =
                shareCur.webView.title?.takeIf { it.isNotBlank() } ?: displayUrl(shareUrl)
            view.findViewById<TextView>(R.id.shareHost).text = displayUrl(shareUrl)
            view.findViewById<ImageView>(R.id.shareLock).setImageResource(
                if (shareUrl.startsWith("https://")) R.drawable.ic_lock else R.drawable.ic_globe
            )
            setThumb(view.findViewById(R.id.shareThumb), captureContent())
            view.findViewById<View>(R.id.btnShareLink).setOnClickListener {
                dismissMenu()
                shareText(shareUrl)
            }
        }

        // 항목들은 제목(머리말) 아래 둥근 카드 안에 묶어서 보여 준다.
        var card: LinearLayout? = null
        fun currentCard(): LinearLayout {
            card?.let { return it }
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                tag = "menuCard"
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setColor(MaterialColors.getColor(list, com.google.android.material.R.attr.colorSurface, 0))
                }
                clipToOutline = true
            }
            list.addView(
                c,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(14), 0, dp(14), dp(4)) }
            )
            card = c
            return c
        }

        // 누르면 다른 화면이나 선택창이 열리는 항목에는 오른쪽에 화살표를 붙인다.
        val navTitles = setOf(
            "설정", "북마크", "방문 기록", "다운로드 목록", "검색 엔진", "웹 페이지 다크 모드", "글자 크기",
            "재생 속도", "광고 차단 현황", "직접 선택한 광고 관리", "자동완성 서비스"
        )

        fun newRow(icon: Int, title: String, sub: String?): View {
            val parent = currentCard()
            val row = layoutInflater.inflate(R.layout.item_menu_row, parent, false)
            val iconView = row.findViewById<ImageView>(R.id.rowIcon)
            iconView.setImageResource(icon)
            row.findViewById<TextView>(R.id.rowTitle).text = title
            val st = row.findViewById<TextView>(R.id.rowSub)
            if (sub != null) {
                st.text = sub
                st.visibility = View.VISIBLE
            }
            if (title in navTitles) row.findViewById<View>(R.id.rowChevron).visibility = View.VISIBLE
            // 지우는 항목은 붉은 색으로 눈에 띄게
            if (title.endsWith("삭제")) {
                iconView.backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.ev_danger_soft))
                iconView.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.ev_danger))
                row.findViewById<TextView>(R.id.rowTitle).setTextColor(getColor(R.color.ev_danger))
            }
            parent.addView(row)
            return row
        }

        fun addHeader(text: String) {
            val h = layoutInflater.inflate(R.layout.item_menu_header, list, false) as TextView
            h.text = text
            list.addView(h)
            card = null   // 다음 항목부터 새 카드
        }

        fun addRow(icon: Int, title: String, sub: String? = null, action: () -> Unit) {
            val row = newRow(icon, title, sub)
            row.setOnClickListener {
                dismissMenu()
                action()
            }
        }

        // 스위치 행: 시트를 닫지 않고 바로 켜고 끈다.
        fun addToggle(
            icon: Int,
            title: String,
            sub: () -> String?,
            checked: Boolean,
            action: () -> Boolean
        ) {
            val row = newRow(icon, title, sub())
            val sw = row.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.rowSwitch)
            sw.visibility = View.VISIBLE
            sw.isChecked = checked
            row.contentDescription = title
            row.setOnClickListener {
                row.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                sw.isChecked = action()
                row.findViewById<TextView>(R.id.rowSub).text = sub()
            }
        }

        if (!settings) {
            // 메뉴 = 지금 바로 쓰는 것(탭 · 이 페이지 · 동영상 · 보관함). 바꿔 두고 쓰는 것은 모두 설정으로 보낸다.
            val onPage = current?.isHome != true

            addHeader("탭")
            addRow(R.drawable.ic_add, "새 탭") { openNewTabAndFocus() }
            addRow(R.drawable.ic_incognito, "새 시크릿 탭", "방문 기록과 쿠키가 남지 않아요") { openNewTabAndFocus(incognito = true) }
            addRow(R.drawable.ic_tab, "새 창", "앱을 한 개 더 띄워 나란히 사용합니다") { openNewWindow() }
            addRow(R.drawable.ic_folder, "현재 탭을 새 그룹으로") { groupCurrentTab() }

            addHeader(if (onPage) "이 페이지" else "도구")
            if (onPage) {
                val bookmarked = currentBookmark() != null
                addRow(
                    if (bookmarked) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border,
                    if (bookmarked) "북마크 수정" else "북마크에 추가"
                ) { bookmarkCurrent() }
                addRow(R.drawable.ic_search, "페이지에서 찾기", "이 페이지 안의 글자를 찾아 표시합니다") { openFind() }
                addRow(
                    R.drawable.ic_globe, "페이지 번역",
                    "API 키 없이 한국어로 번역해요 · 번역된 페이지에서 다시 누르면 원문으로"
                ) { assistant?.togglePageTranslation() }
                addRow(
                    R.drawable.ic_text, "화면 확대/축소",
                    "현재: ${current?.let { effectiveZoom(it) } ?: 100}%" + if (current?.pageZoom != null) " (이 탭만)" else ""
                ) { showPageZoomDialog() }
            }
            addRow(
                R.drawable.ic_ai, "AI 어시스턴트",
                if (prefs.geminiKey.isBlank()) "Gemini API 키를 넣으면 요약·번역·질문을 할 수 있어요"
                else "${GeminiModels.byId(prefs.geminiModel).label} · 이 페이지 요약, 번역, 질문"
            ) { assistant?.show(if (tbAi.isShown) tbAi else null) }
            addToggle(
                R.drawable.ic_desktop, "데스크톱 사이트",
                { "켜면 PC용 화면으로 다시 불러옵니다" },
                current?.desktop == true
            ) {
                toggleDesktopSite()
                current?.desktop == true
            }
            addToggle(
                R.drawable.ic_shield, "광고 차단",
                { "이 페이지 ${current?.adBlocked?.get() ?: 0}건 · 오늘 ${adBlocker.stats(0).today}건 차단됨" },
                adBlockEnabled
            ) {
                toggleAdBlock()
                adBlockEnabled
            }
            if (onPage) {
                addRow(
                    R.drawable.ic_edit, "광고 직접 선택",
                    "페이지에서 차단할 광고를 직접 눌러 고릅니다"
                ) { startAdPicker() }

                addHeader("동영상")
                addRow(R.drawable.ic_pip, "동영상 PiP", "재생 중인 동영상을 작은 창으로 띄웁니다") { startPipFromMenu() }
                addRow(R.drawable.ic_play, "내장 플레이어로 재생", "페이지의 영상을 앱 안의 플레이어로 엽니다") { openInternalPlayer() }
                addRow(R.drawable.ic_movie, "페이지의 영상 파일 찾기") { findVideos() }
            }

            addHeader("보관함")
            addRow(R.drawable.ic_bookmark, "북마크", "${prefs.bookmarks().size}개") { openBookmarks() }
            addRow(R.drawable.ic_history, "방문 기록", "${prefs.historyItems().size}개") { openHistory() }
            addRow(R.drawable.ic_download, "다운로드 목록") { openDownloads() }

            addHeader("더 보기")
            addRow(R.drawable.ic_settings, "설정", "검색 엔진 · 화면 · 재생 · 광고 차단 · 보안 · 개인정보") {
                showMenu(anchor, settings = true)
            }
        } else {
            addHeader("일반")
            addRow(R.drawable.ic_search, "검색 엔진", "현재: ${SearchEngines.byKey(prefs.engineKey).name}") { showEngineDialog() }

            addHeader("화면")
            addRow(R.drawable.ic_dark, "웹 페이지 다크 모드", "현재: ${darkModeLabel()}") { showDarkModeDialog() }
            addRow(R.drawable.ic_text, "글자 크기", "현재: ${textZoom}%") { showTextSizeDialog() }

            addHeader("재생")
            addRow(R.drawable.ic_play, "재생 속도", "현재: ${current?.rate ?: 1f}x") { showSpeedDialog() }
            addToggle(
                R.drawable.ic_play, "백그라운드 재생",
                { "앱을 나가거나 화면을 꺼도 소리가 계속 나옵니다" },
                prefs.backgroundAudio
            ) {
                prefs.backgroundAudio = !prefs.backgroundAudio
                onMediaChanged()
                prefs.backgroundAudio
            }

            addHeader("광고 차단")
            addToggle(
                R.drawable.ic_shield, "광고 차단",
                { "이 페이지 ${current?.adBlocked?.get() ?: 0}건 · 오늘 ${adBlocker.stats(0).today}건 차단됨" },
                adBlockEnabled
            ) {
                toggleAdBlock()
                adBlockEnabled
            }
            addRow(
                R.drawable.ic_shield, "광고 차단 현황",
                "오늘 ${adBlocker.stats(0).today}건 · 전체 ${adBlocker.stats(0).total}건 차단"
            ) { showAdBlockStats() }
            addRow(
                R.drawable.ic_delete, "직접 선택한 광고 관리",
                if (adBlocker.userRuleCount == 0) "아직 직접 고른 광고가 없어요" else "${adBlocker.userRuleCount}개 · 보기 · 삭제"
            ) { showUserAdRules() }
            addRow(
                R.drawable.ic_refresh, "광고 차단 목록 업데이트",
                "마지막 업데이트: ${AdBlockStatsUi.agoText(adBlocker.lastUpdated)}"
            ) { updateAdBlockList() }

            addHeader("보안")
            addToggle(
                R.drawable.ic_shield, "악성 사이트 접속 알림",
                { "위험한 사이트에 접속하면 경고하고 막습니다" },
                malwareWarning
            ) {
                toggleMalwareWarning()
                malwareWarning
            }
            addToggle(
                R.drawable.ic_lock, "HTTPS 우선 연결",
                { "http 주소도 먼저 보안 연결로 시도하고, 안 되면 허락을 구합니다" },
                httpsFirst
            ) {
                toggleHttpsFirst()
                httpsFirst
            }
            addToggle(
                R.drawable.ic_download, "자동 다운로드 차단",
                { "직접 누르지 않은 파일 다운로드를 막습니다" },
                blockAutoDownload
            ) {
                toggleBlockAutoDownload()
                blockAutoDownload
            }
            addToggle(
                R.drawable.ic_back, "뒤로가기 중 자동 이동 차단",
                { "뒤로가기 직후 페이지가 스스로 다른 곳으로 보내는 것을 막습니다" },
                prefs.blockBackRedirect
            ) {
                prefs.blockBackRedirect = !prefs.blockBackRedirect
                toast(if (prefs.blockBackRedirect) "뒤로가기 중 자동 이동 차단 켜짐" else "뒤로가기 중 자동 이동 차단 꺼짐")
                prefs.blockBackRedirect
            }

            addHeader("개인정보")
            addToggle(
                R.drawable.ic_shield, "트래커 차단 (엄격)",
                {
                    if (strictTrackers) "필요한 트래커만 허용 · ${trackerBlocker.blockedCount.get()}건 차단됨"
                    else "필요한 것 외 모든 트래커 차단 · 맞춤 광고가 줄어듭니다"
                },
                strictTrackers
            ) {
                toggleStrictTrackers()
                strictTrackers
            }
            addToggle(
                R.drawable.ic_lock, "캡차 건너뛰기",
                { "인증 데이터로 추적하지 못하게 함 · 자동 인증 지원 사이트에서만" },
                skipCaptchaTracking
            ) {
                toggleSkipCaptcha()
                skipCaptchaTracking
            }
            addToggle(
                R.drawable.ic_lock, "비밀번호·자동완성",
                { "로그인 정보 저장과 입력을 기기의 자동완성 서비스에 맡깁니다 · 시크릿 탭에서는 쓰지 않아요" },
                autofillEnabled
            ) {
                toggleAutofill()
                autofillEnabled
            }
            addRow(R.drawable.ic_phone, "자동완성 서비스", autofillServiceStatus()) { openAutofillSettings() }
            addRow(R.drawable.ic_delete, "방문 기록·캐시·쿠키 삭제") { clearBrowsingData() }
        }

        // 카드의 마지막 항목 아래 구분선은 지운다
        for (i in 0 until list.childCount) {
            val c = list.getChildAt(i) as? LinearLayout ?: continue
            if (c.tag != "menuCard" || c.childCount == 0) continue
            c.getChildAt(c.childCount - 1).findViewById<View>(R.id.rowDivider)?.visibility = View.GONE
        }

        if (sheet != null) {
            if (settings) {
                sheet.onBackPressedDispatcher.addCallback(sheet, object : OnBackPressedCallback(true) {
                    override fun handleOnBackPressed() {
                        dismissMenu()
                        showMenu(anchor)
                    }
                })
            }
            // 바깥(흐린 배경)을 눌러 닫아도 메뉴로 (뒤로가기는 위 콜백이 처리하고 dismiss 라서 여기로 오지 않는다)
            if (settings) sheet.setOnCancelListener { showMenu(anchor) }
            sheet.setContentView(view)
            sheet.behavior.maxWidth = dp(600)
            Motion.stagger(list, 90, 32, 360)
            // 뒤 페이지를 흐리게 + 시트를 반투명 유리처럼 (Android 12+ 에서 지원될 때만)
            // 시트 색은 태블릿 메뉴 팝업과 같은 colorSurfaceContainer 로 맞춘다 (블러 여부와 상관없이)
            val glass = Blur.behind(sheet.window, this)
            sheet.setOnShowListener {
                sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
                // 시트가 처음 배치될 때 기본 배경을 입히므로, 그 뒤에 같은 색의 배경으로 바꾼다
                sheet.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.let { v ->
                    v.post {
                        val r = dp(28).toFloat()
                        v.background = if (glass) {
                            Blur.glass(
                                this, com.google.android.material.R.attr.colorSurfaceContainer, r, topOnly = true
                            )
                        } else {
                            GradientDrawable().apply {
                                setColor(Blur.surface(this@MainActivity, com.google.android.material.R.attr.colorSurfaceContainer, false))
                                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                            }
                        }
                    }
                }
            }
            sheet.show()
            return
        }

        // 태블릿: 버튼 바로 아래, 버튼의 오른쪽 끝에 맞춰 뜨는 둥근 카드 팝업
        val anchorView = anchor ?: return
        // 팝업 창·프리폼 창에서도 맞도록 위치는 창 안 좌표(getLocationInWindow)와 창 크기로 계산한다
        val screenW = anchorView.rootView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val screenH = anchorView.rootView.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        val width = minOf(dp(360), screenW - dp(16))
        val loc = IntArray(2)
        anchorView.getLocationInWindow(loc)
        val locScreen = IntArray(2)
        anchorView.getLocationOnScreen(locScreen)
        val below = loc[1] + anchorView.height
        val maxH = (screenH - below - dp(12)).coerceAtLeast(dp(240))
        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val height = minOf(view.measuredHeight, maxH)
        val bg = Popup.anchoredBackground(this, view)
        val pw = PopupWindow(view, width, height, true).apply {
            setBackgroundDrawable(bg)
            isOutsideTouchable = true
            elevation = dp(Popup.ANCHORED_ELEVATION_DP).toFloat()
            animationStyle = R.style.Evergreen_MenuPopupAnim
        }
        popup = pw
        if (settings) {
            // 설정 팝업이 우리가 닫은 게 아니면(뒤로가기·바깥 누름) 메뉴로 돌아간다
            pw.setOnDismissListener {
                if (!closedByUs && !isFinishing && !isDestroyed && !isChangingConfigurations) showMenu(anchor)
            }
        }
        // 북마크 / 방문 기록 / 다운로드 팝업이 이 메뉴와 같은 자리에 뜨도록 기억해 둔다
        menuAnchorRight = locScreen[0] + anchorView.width   // 다른 창(목록 팝업)에 넘기는 값이라 화면 좌표
        menuAnchorBottom = locScreen[1] + anchorView.height
        // 버튼의 오른쪽 끝에 맞추되 화면 밖으로는 나가지 않게
        val wantLeft = (loc[0] + anchorView.width - width).coerceIn(dp(8), (screenW - width - dp(8)).coerceAtLeast(dp(8)))
        Popup.prepareAnchoredEnter(view, loc[0] + anchorView.width / 2f - wantLeft, width)
        pw.showAsDropDown(anchorView, wantLeft - loc[0], dp(4))
        Blur.behindPopup(pw, this)
        Popup.playAnchoredEnter(view, list)
    }

    /**
     * UA 문자열과 Client Hints(Sec-CH-UA)를 함께 바꾼다.
     * WebView 는 UA 에서 "wv"를 지워도 Sec-CH-UA / navigator.userAgentData 에 "Android WebView" 브랜드를 실어 보내서,
     * 구글이 "브라우저 또는 앱이 안전하지 않을 수 있습니다"로 로그인을 막는다. 브랜드를 일반 Chrome 으로 맞춘다.
     */
    private fun applyUserAgent(wv: WebView, desktop: Boolean) {
        wv.settings.userAgentString = if (desktop) desktopUserAgent() else mobileUserAgent()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) return
        try {
            val full = Regex("Chrome/([\\d.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
            val major = full.substringBefore('.')
            val brands = listOf(
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Not)A;Brand").setMajorVersion("99").setFullVersion("99.0.0.0").build(),
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Chromium").setMajorVersion(major).setFullVersion(full).build(),
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Google Chrome").setMajorVersion(major).setFullVersion(full).build()
            )
            val md = androidx.webkit.UserAgentMetadata.Builder()
                .setBrandVersionList(brands)
                .setFullVersion(full)
                .setPlatform(if (desktop) "Linux" else "Android")
                .setPlatformVersion(if (desktop) "6.5.0" else (Build.VERSION.RELEASE + ".0.0"))
                .setMobile(!desktop)
                .setModel(if (desktop) "" else Build.MODEL)
                .setArchitecture(if (desktop) "x86" else "")
                .setBitness(if (desktop) 64 else 0)
                .build()
            WebSettingsCompat.setUserAgentMetadata(wv.settings, md)
        } catch (e: Exception) {
            // 지원하지 않는 WebView 면 UA 문자열 변경만 적용
        }
    }

    private fun mobileUserAgent(): String =
        baseUserAgent.replace("; wv", "").replace(" Version/4.0", "")

    private fun desktopUserAgent(): String {
        val ver = Regex("Chrome/([\\d.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$ver Safari/537.36"
    }

    /** PC용 화면 폭으로 레이아웃되도록 viewport 를 덮어쓴다. (UA 만 바꿔서는 모바일 폭으로 그려지는 사이트가 많음) */
    private fun desktopViewportJs(): String {
        val w = maxOf(resources.configuration.screenWidthDp, 1024)
        return "(function(){var m=document.querySelector('meta[name=viewport]');" +
            "if(!m){m=document.createElement('meta');m.name='viewport';" +
            "(document.head||document.documentElement).appendChild(m);}" +
            "m.setAttribute('content','width=$w');})();"
    }

    /** m.example.com / en.m.wikipedia.org 같은 모바일 전용 주소를 PC 주소로 바꾼다. */
    private fun toDesktopUrl(url: String): String {
        val host = Uri.parse(url).host ?: return url
        val newHost = when {
            host.startsWith("m.") -> {
                val rest = host.removePrefix("m.")
                if (rest.count { it == '.' } >= 2) rest else "www.$rest"
            }
            host.contains(".m.") -> host.replaceFirst(".m.", ".")
            else -> host
        }
        return if (newHost == host) url else url.replaceFirst(host, newHost)
    }

    /** 태블릿 툴바의 데스크톱/모바일 버튼: 지금 모드가 아니라 '누르면 바뀔 모드'를 아이콘으로 보여준다. */
    private fun updateDesktopButton() {
        val desktop = current?.desktop == true
        tbDesktop.setImageResource(if (desktop) R.drawable.ic_phone else R.drawable.ic_desktop)
        tbDesktop.contentDescription = if (desktop) "모바일 사이트로 보기" else "데스크톱 사이트로 보기"
    }

    private fun toggleDesktopSite() {
        val tab = current ?: return
        val on = !tab.desktop
        // 한 번 켜면 모든 탭·새 탭·앱을 다시 켠 뒤에도 유지된다 (끄기 전까지).
        prefs.desktopSite = on
        for (t in tabs) {
            t.desktop = on
            t.desktopInjected = false
            t.liveWebView?.let { applyUserAgent(it, on) }
        }
        updateDesktopButton()

        val url = tab.webView.url
        if (tab.isHome || url == null || url == "about:blank" || url == HOME_URL) {
            toast(if (tab.desktop) "데스크톱 모드: 이 탭에서 여는 페이지부터 적용됩니다" else "모바일 모드로 돌아갑니다")
            return
        }
        val target = if (tab.desktop && url.startsWith("http")) toDesktopUrl(url) else url
        if (target != url) tab.webView.loadUrl(target) else reloadTab(tab)
        toast(if (tab.desktop) "데스크톱 사이트로 다시 불러옵니다" else "모바일 사이트로 다시 불러옵니다")
    }

    private fun groupCurrentTab() {
        val tab = current ?: return
        showGroupEditor(null) { name, color ->
            moveToGroup(tab, createGroup(name, color))
            // 상단 탭줄(그룹 알약·색 막대)과 탭 전환 화면을 다시 그린다
            scheduleStripRefresh()
            if (switcherOpen) refreshSwitcher(false)
            toast("'$name' 그룹에 추가했습니다")
        }
    }

    // ───────────────────────── 스크롤 시 바 숨김 ─────────────────────────

    private fun onPageScroll(tab: BrowserTab, y: Int, oldY: Int) {
        if (tab === current) pageScrollBar.refresh()
        if (!hideBarsOnScroll || tab !== current || switcherOpen || urlBar.hasFocus() ||
            findBar.visibility == View.VISIBLE) return
        // 손가락으로 스크롤하는 동안은 바가 손가락을 따라가므로 여기서 건드리지 않는다
        if (barsGestureActive) return
        // 위로 스크롤해서(관성 포함) 맨 위에 닿으면 바를 다시 보여 준다
        if (y <= dp(8) && y < oldY) {
            scrollAcc = 0
            setBarsHidden(false)
        }
    }

    private class BarsGeom(
        val first: View,
        val other: View,
        val flp: LinearLayout.LayoutParams,
        val olp: LinearLayout.LayoutParams,
        val blp: LinearLayout.LayoutParams,
        val frame: View,
        val topH: Int,
        val bh: Int
    )

    private var imeVisible = false
    private var barsViewportReady = true
    private var barsWaitToken = Any()

    /**
     * 웹 영역을 키운 뒤, 페이지의 viewport(window.innerHeight)가 실제로 새 높이가 될 때까지 기다렸다가 block 실행.
     * 고정된 지연(120~180ms) 대신 확인하므로 느린 페이지에서도 하단에 흰 줄이 보이지 않는다. 최대 700ms 까지만 기다린다.
     * @param minHeightPx 레이아웃이 다시 잡혔다고 볼 수 있는 WebView 최소 높이
     */
    private fun whenViewportMatches(wv: WebView?, minHeightPx: Int, block: () -> Unit) {
        val token = Any()
        barsWaitToken = token
        if (wv == null || wv.parent !== webContainer) { block(); return }
        val start = android.os.SystemClock.uptimeMillis()
        fun check() {
            if (barsWaitToken !== token) return
            if (android.os.SystemClock.uptimeMillis() - start > 700) { block(); return }
            if (wv.height < minHeightPx) { wv.postDelayed({ check() }, 30); return }
            @Suppress("DEPRECATION")
            val scale = wv.scale.takeIf { it > 0f } ?: resources.displayMetrics.density
            val expected = wv.height / scale
            wv.evaluateJavascript("window.innerHeight") { r ->
                if (barsWaitToken !== token) return@evaluateJavascript
                val h = r?.trim('"')?.toFloatOrNull()
                if (h != null && h >= expected * 0.97f) block() else wv.postDelayed({ check() }, 40)
            }
        }
        check()
    }
    private var barsSizeListenerRef: View.OnLayoutChangeListener? = null
    private var barsSyncedTopH = -1

    /** 태블릿 + 키보드 없음 (스크롤 숨김 설정과 무관) → 웹 영역을 처음부터 전체 화면 크기로 고정한다. */
    private fun barsFullWanted(): Boolean = false   // 항상 전체 크기로 두면 바가 보일 때 페이지 아래가 잘려서 사용하지 않는다

    /** 전체 크기 고정 레이아웃을 맞춘다 (바 높이가 바뀌었을 때, 설정·키보드 상태가 바뀌었을 때 호출). */
    private fun barsSyncFullLayout() {
        val g = barsGeom() ?: return
        if (g.topH <= 0) return
        if (barsFullWanted()) {
            if (barsLayoutHidden && barsSyncedTopH == g.topH) return
            barsEnterHidden(g)
            barsApply(g, barsFraction)
            barsSyncedTopH = g.topH
            homeView.setPadding(0, 0, 0, g.topH)   // 홈 화면은 보이는 영역 가운데에 오도록
            barsResync()
        } else {
            homeView.setPadding(0, 0, 0, 0)
            barsSyncedTopH = -1
            if (barsLayoutHidden && barsFraction == 0f && barsAnim?.isRunning != true && !barsGestureActive) {
                barsEnterShown(g)
            }
        }
    }

    private fun barsGeom(): BarsGeom? {
        val stripShown = tabStripBar.visibility == View.VISIBLE
        val first: View = if (stripShown) tabStripBar else toolbarView
        val other: View = if (stripShown) toolbarView else tabStripBar
        val flp = first.layoutParams as? LinearLayout.LayoutParams ?: return null
        val olp = other.layoutParams as? LinearLayout.LayoutParams ?: return null
        val blp = bottomBar.layoutParams as? LinearLayout.LayoutParams ?: return null
        val frame = webContainer.parent as? View ?: return null
        val topH = (if (stripShown) tabStripBar.height else 0) + toolbarView.height
        val bh = if (bottomBar.visibility == View.VISIBLE) bottomBar.height else 0
        return BarsGeom(first, other, flp, olp, blp, frame, topH, bh)
    }

    /** '숨김 형태' 레이아웃에서의 표시 상태. f = 0 보임, 1 숨김. 바와 웹 영역이 같은 만큼 함께 움직인다. */
    private fun barsApply(g: BarsGeom, f: Float) {
        barsFraction = f
        val ty = g.topH * (1f - f)
        g.first.translationY = ty
        g.other.translationY = ty
        progressBar.translationY = ty
        g.frame.translationY = ty
        bottomBar.translationY = -g.bh * (1f - f)
    }

    /** 웹 영역을 화면 전체 크기로 키운다. 눈에 보이는 모습은 그대로이고 늘어난 부분은 화면 밖(아래)에 있다. */
    private fun barsEnterHidden(g: BarsGeom) {
        g.olp.topMargin = 0
        g.flp.topMargin = -g.topH
        g.blp.bottomMargin = -g.bh
        g.first.layoutParams = g.flp
        g.other.layoutParams = g.olp
        bottomBar.layoutParams = g.blp
        barsLayoutHidden = true
    }

    /** 바가 완전히 보이는 보통 레이아웃으로 되돌린다 (웹 영역이 줄어드는 쪽이라 빈 영역이 생기지 않는다). */
    private fun barsEnterShown(g: BarsGeom) {
        if (barsFullWanted()) {
            // 태블릿: 웹 영역은 항상 화면 전체 크기. 바가 보일 때는 아래로 밀기만 한다 (크기 변화 없음 → 흰 줄 없음)
            barsApply(g, 0f)
            barsLayoutHidden = true
            barsResync()
            return
        }
        g.olp.topMargin = 0
        g.flp.topMargin = 0
        g.blp.bottomMargin = 0
        g.first.layoutParams = g.flp
        g.other.layoutParams = g.olp
        bottomBar.layoutParams = g.blp
        g.first.translationY = 0f
        g.other.translationY = 0f
        progressBar.translationY = 0f
        g.frame.translationY = 0f
        bottomBar.translationY = 0f
        barsFraction = 0f
        barsLayoutHidden = false
        barsViewportReady = true
        barsResync()
    }

    private fun barsResync() {
        browserUi.requestLayout()
        webContainer.requestLayout()
        browserUi.invalidate()
        webContainer.invalidate()
        pageScrollBar.refresh()
        current?.webView?.let { wv ->
            wv.requestLayout()
            wv.invalidate()
            wv.post {
                if (wv.parent === webContainer) {
                    wv.requestLayout()
                    wv.invalidate()
                    wv.postInvalidateOnAnimation()
                    pageScrollBar.refresh()
                }
            }
        }
    }

    private fun barsAnimateTo(g: BarsGeom, to: Float) {
        barsAnim?.cancel()
        val duration = (220f * kotlin.math.abs(to - barsFraction)).toLong().coerceAtLeast(120L)
        barsAnim = android.animation.ValueAnimator.ofFloat(barsFraction, to).apply {
            this.duration = duration
            interpolator = android.view.animation.PathInterpolator(0.4f, 0f, 0.2f, 1f)
            var cancelled = false
            addUpdateListener { barsApply(g, it.animatedValue as Float) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationCancel(a: android.animation.Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (cancelled || barsGestureActive) return
                    if (to == 0f) barsEnterShown(g) else barsResync()
                }
            })
            start()
        }
    }

    /**
     * 메뉴바를 숨기거나 되돌린다 (탭 전환·맨 위 도달 등 손가락 스크롤이 아닐 때).
     * 손가락으로 스크롤할 때는 onBarsPreScroll 이 바를 손가락에 맞춰 직접 움직인다.
     *
     * 웹 영역의 크기를 애니메이션 도중에 바꾸면 WebView 가 늘어난 영역을 바로 못 그려서 하단에
     * 흰 네모가 보인다. 그래서 크기가 바뀌는 순간은 항상 화면 밖에서 일어나게 한다.
     *  - 숨길 때: 웹 영역을 먼저 '전체 크기'로 키우고(늘어난 부분은 화면 밖), WebView 가 새 크기로
     *    그려질 시간을 준 뒤 바와 웹 영역을 함께 위로 밀어 올린다.
     *  - 보일 때: 바와 웹 영역을 함께 내린 다음, 끝난 뒤에 웹 영역을 줄인다.
     */
    private fun setBarsHidden(hide: Boolean) {
        val target = if (hide) 1f else 0f
        if (barsTarget == target) return
        barsTarget = target
        barsGestureActive = false   // 탭 전환 등으로 손가락 스크롤이 끊겼을 때 상태가 남지 않게
        barsAnim?.cancel()
        barsStartRunnable?.let { webContainer.removeCallbacks(it) }
        barsStartRunnable = null
        val g = barsGeom() ?: return
        applyStatusBarForScroll(hide)
        if (hide) {
            if (!barsLayoutHidden) {
                val heightBefore = current?.webView?.height ?: 0
                barsEnterHidden(g)
                barsApply(g, 0f)
                if (!Motion.enabled(this)) {
                    val wv0 = current?.webView?.takeIf { it.parent === webContainer }
                    whenViewportMatches(wv0, heightBefore + g.topH - dp(6)) {
                        if (barsTarget == 1f) { barsApply(g, 1f); barsResync() }
                    }
                    return
                }
                val starter = object : Runnable {
                    override fun run() {
                        if (barsStartRunnable !== this) return
                        barsStartRunnable = null
                        if (barsTarget == 1f) barsAnimateTo(g, 1f)
                    }
                }
                barsStartRunnable = starter
                val wv = current?.webView?.takeIf { it.parent === webContainer }
                whenViewportMatches(wv, heightBefore + g.topH - dp(6)) { webContainer.post(starter) }
            } else if (!Motion.enabled(this)) {
                barsApply(g, 1f)
                barsResync()
            } else {
                barsAnimateTo(g, 1f)
            }
        } else {
            if (!barsLayoutHidden) return
            if (!Motion.enabled(this)) barsEnterShown(g) else barsAnimateTo(g, 0f)
        }
    }

    // ───────────────────────── 손가락을 따라가는 메뉴바 ─────────────────────────

    private fun barsGestureAllowed(): Boolean {
        if (!hideBarsOnScroll || switcherOpen || urlBar.hasFocus() || findBar.visibility == View.VISIBLE) return false
        val c = current ?: return false
        return !c.isHome
    }

    private fun onBarsGestureStart() {
        barsGestureActive = true
        barsGestureDy = 0
        barsLastDir = 0
        barsAnim?.cancel()
        barsStartRunnable?.let { webContainer.removeCallbacks(it) }
        barsStartRunnable = null
    }

    /** 손가락이 dy 만큼 움직일 때 바가 먼저 쓰고 남은 만큼을 페이지가 스크롤한다. 쓴 양을 돌려준다. */
    private fun onBarsPreScroll(dy: Int): Int {
        if (dy == 0 || !barsGestureAllowed()) return 0
        barsGestureDy += dy
        barsLastDir = if (dy > 0) 1 else -1
        val g = barsGeom() ?: return 0
        val travel = maxOf(1, g.topH).toFloat()
        val now = android.os.SystemClock.uptimeMillis()
        if (dy > 0) {
            if (!barsLayoutHidden) {
                // 살짝 스친 정도로는 크기를 바꾸지 않는다
                if (barsGestureDy < dp(8)) return 0
                // 웹 영역을 먼저 키우고 WebView 가 새 크기로 그려질 시간을 준 뒤부터 바가 움직인다
                val wv = current?.webView?.takeIf { it.parent === webContainer }
                val heightBefore = wv?.height ?: 0
                barsEnterHidden(g)
                barsApply(g, 0f)
                barsViewportReady = false
                whenViewportMatches(wv, heightBefore + g.topH - dp(6)) {
                    barsViewportReady = true
                    if (!barsGestureActive) barsStartRunnable?.let { webContainer.post(it) }
                }
                return 0
            }
            if (!barsViewportReady) return 0
            val avail = ((1f - barsFraction) * travel + 0.5f).toInt()
            val c = minOf(dy, avail)
            if (c <= 0) return 0
            barsApply(g, minOf(1f, barsFraction + c / travel))
            return c
        } else {
            if (!barsLayoutHidden || barsFraction <= 0f || !barsViewportReady) return 0
            val avail = (barsFraction * travel + 0.5f).toInt()
            val c = maxOf(dy, -avail)
            if (c >= 0) return 0
            barsApply(g, maxOf(0f, barsFraction + c / travel))
            return c
        }
    }

    /** 손가락을 떼면 움직이던 방향으로 끝까지 숨기거나 보여 준다. */
    private fun onBarsGestureStop() {
        if (!barsGestureActive) return
        barsGestureActive = false
        if (!barsLayoutHidden) return
        val g = barsGeom() ?: return
        val hide = when {
            barsFraction >= 1f -> true
            barsLastDir > 0 -> true
            barsLastDir < 0 -> false
            else -> barsFraction >= 0.5f
        }
        barsTarget = if (hide) 1f else 0f
        applyStatusBarForScroll(hide)
        if (!Motion.enabled(this)) {
            if (hide) { barsApply(g, 1f); barsResync() } else barsEnterShown(g)
            return
        }
        if (hide && !barsViewportReady) {
            // 빠르게 튕긴 경우: WebView 가 새 크기로 그려질 때까지 조금 기다렸다가 올린다
            val starter = object : Runnable {
                override fun run() {
                    if (barsStartRunnable !== this) return
                    barsStartRunnable = null
                    if (barsTarget == 1f && !barsGestureActive) barsGeom()?.let { barsAnimateTo(it, 1f) }
                }
            }
            barsStartRunnable = starter   // 렌더링 확인이 끝나면 whenViewportMatches 콜백이 실행한다
        } else {
            barsAnimateTo(g, if (hide) 1f else 0f)
        }
    }

    /** 스크롤 숨김과 함께 상태표시줄도 숨기거나 되돌린다. 전체화면 영상 중에는 건드리지 않는다. */
    private fun applyStatusBarForScroll(hide: Boolean) {
        if (customView != null) return
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (hide && hideStatusBarOnScroll) {
            if (statusBarHiddenByScroll) return
            statusBarHiddenByScroll = true
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.statusBars())
        } else if (statusBarHiddenByScroll) {
            statusBarHiddenByScroll = false
            controller.show(WindowInsetsCompat.Type.statusBars())
        }
    }

    /** 탭의 웹뷰에 보안 설정(Safe Browsing, 서드파티 쿠키)을 적용한다. */
    private fun applySecurity(wv: WebView, tab: BrowserTab? = null) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
            WebSettingsCompat.setSafeBrowsingEnabled(wv.settings, malwareWarning)
        }
        // 서드파티 쿠키를 막으면 인증(캡차) 제공업체가 사이트 간에 나를 따라다니며 추적하기 어렵다.
        cookieManagerFor(tab).setAcceptThirdPartyCookies(wv, !skipCaptchaTracking)
    }

    private fun toggleStrictTrackers() {
        strictTrackers = !strictTrackers
        prefs.strictTrackers = strictTrackers
        toast(if (strictTrackers) "트래커 차단(엄격) 켜짐" else "트래커 차단(엄격) 꺼짐")
        current?.let { reloadTab(it) }
    }

    private fun toggleSkipCaptcha() {
        skipCaptchaTracking = !skipCaptchaTracking
        prefs.skipCaptchaTracking = skipCaptchaTracking
        tabs.forEach { t -> t.liveWebView?.let { applySecurity(it, t) } }
        toast(if (skipCaptchaTracking) "캡차 건너뛰기 켜짐 (지원 사이트에서만 동작)" else "캡차 건너뛰기 꺼짐")
    }

    private fun toggleMalwareWarning() {
        malwareWarning = !malwareWarning
        prefs.malwareWarning = malwareWarning
        tabs.forEach { t -> t.liveWebView?.let { applySecurity(it, t) } }
        toast(if (malwareWarning) "악성 사이트 알림 켜짐" else "악성 사이트 알림 꺼짐")
    }

    private fun toggleBlockAutoDownload() {
        blockAutoDownload = !blockAutoDownload
        prefs.blockAutoDownload = blockAutoDownload
        toast(if (blockAutoDownload) "자동 다운로드 차단 켜짐" else "자동 다운로드 차단 꺼짐")
    }

    private fun toggleAdBlock() {
        adBlockEnabled = !adBlockEnabled
        prefs.adBlock = adBlockEnabled
        toast(if (adBlockEnabled) "광고 차단 켜짐" else "광고 차단 꺼짐")
        current?.let { reloadTab(it) }
    }

    private fun showAdBlockStats() {
        val tab = current
        AdBlockStatsUi.show(
            ctx = this,
            blocker = adBlocker,
            enabled = adBlockEnabled,
            pageBlocked = if (tab == null || tab.isHome) null else tab.adBlocked.get(),
            trackerBlocked = if (strictTrackers) trackerBlocker.blockedCount.get() else null,
            onUpdate = { updateAdBlockList() }
        )
    }

    /** 설정 > 광고 직접 선택: 지금 보는 페이지를 선택 모드로 바꾼다 */
    private fun startAdPicker() {
        val tab = current
        if (tab == null || tab.isHome || tab.errorUrl != null) {
            toast("먼저 광고가 있는 페이지를 열어 주세요")
            return
        }
        if (!adBlockEnabled) {
            toast("광고 차단을 먼저 켜 주세요")
            return
        }
        // 메뉴는 이미 닫혔다. 페이지 안에 선택 화면(안내 막대)이 뜨고, 누르는 요소가 빨갛게 표시된다
        tab.webView.evaluateJavascript(AdScripts.PICKER_JS, null)
        toast("차단할 광고를 눌러 주세요")
    }

    private fun showUserAdRules() {
        AdBlockUserRulesUi.show(this, adBlocker, false) {
            // 삭제한 규칙은 새로 불러와야 화면에 되살아난다
            current?.let { if (!it.isHome) reloadTab(it) }
        }
    }

    private fun updateAdBlockList() {
        toast("차단 목록을 내려받는 중…")
        io.execute {
            try {
                val n = adBlocker.update()
                ui.post { toast("차단 목록 적용 완료 (${n}개 도메인)") }
            } catch (e: Exception) {
                ui.post { toast("업데이트 실패: ${e.message}") }
            }
        }
    }

    private fun showEngineDialog() {
        val engines = SearchEngines.all
        val selected = engines.indexOfFirst { it.key == prefs.engineKey }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("검색 엔진")
            .setSingleChoiceItems(engines.map { it.name }.toTypedArray(), selected) { d, which ->
                prefs.engineKey = engines[which].key
                d.dismiss()
            }
            .show()
    }

    private fun clearBrowsingData() {
        tabs.forEach {
            it.liveWebView?.clearCache(true)
            it.liveWebView?.clearHistory()
            it.redirectSources.clear()
        }
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies(null)
        prefs.clearHistory()
        toast("삭제했습니다")
    }

    // ───────────────────────── 영상 재생 속도 ─────────────────────────

    private fun speedJs(rate: Float): String = """
        (function(r){
          window.__sbRate = r;
          function apply(){
            document.querySelectorAll('video,audio').forEach(function(v){
              if (v.playbackRate !== window.__sbRate) v.playbackRate = window.__sbRate;
            });
          }
          apply();
          if (window.__sbRateTimer) { clearInterval(window.__sbRateTimer); window.__sbRateTimer = null; }
          if (r !== 1) window.__sbRateTimer = setInterval(apply, 800);
        })($rate);
    """.trimIndent()

    // ───────────────────────── HTTPS 우선 연결 ─────────────────────────

    private var httpsFirst = true

    /** 이번 실행 동안 http 로 열기로 허락받은 사이트 */
    private val httpAllowed: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** http 주소를 https 로 올린 주소를 돌려준다. 올리지 않을 주소(이미 https, 내부망·IP, 허락받은 사이트)는 null */
    private fun upgradeUrl(url: String): String? {
        if (!httpsFirst || !url.startsWith("http://")) return null
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return null
        val internal = !host.contains('.') || host == "localhost" || host.endsWith(".local") ||
            host.endsWith(".lan") || host.endsWith(".internal") || host.endsWith(".home") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host) || host.contains(':')
        if (internal || host in httpAllowed) return null
        return "https://" + url.removePrefix("http://")
    }

    private fun askHttpFallback(tab: BrowserTab, view: WebView, httpUrl: String) {
        if (isFinishing || isDestroyed || tab !in tabs || tab !== current) return
        val host = runCatching { Uri.parse(httpUrl).host }.getOrNull() ?: return
        MaterialAlertDialogBuilder(this)
            .setTitle("보안 연결(HTTPS)을 쓸 수 없어요")
            .setMessage("$host\n\n이 사이트는 보안 연결을 지원하지 않는 것 같아요. 보안되지 않은 연결(http)로 계속하면 주고받는 내용이 다른 사람에게 보일 수 있어요.")
            .setPositiveButton("http로 계속") { _, _ ->
                httpAllowed.add(host.lowercase())
                tab.upgradedFrom = null
                view.loadUrl(httpUrl)
            }
            .setNegativeButton("취소") { _, _ -> tab.upgradedFrom = null }
            .setOnCancelListener { tab.upgradedFrom = null }
            .show()
    }

    private fun toggleHttpsFirst() {
        httpsFirst = !httpsFirst
        prefs.httpsFirst = httpsFirst
        toast(if (httpsFirst) "HTTPS 우선 연결 켜짐" else "HTTPS 우선 연결 꺼짐")
    }

    // ───────────────────────── 비밀번호 · 자동완성 ─────────────────────────

    private var autofillEnabled = true

    /**
     * 웹뷰의 로그인 폼을 안드로이드 자동완성 프레임워크(Google·삼성 패스·Bitwarden 등)에 연결한다.
     * 시크릿 탭은 저장·입력 대상에서 뺀다.
     */
    private fun applyAutofill(tab: BrowserTab) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        tab.webView.importantForAutofill =
            if (autofillEnabled && !tab.incognito) View.IMPORTANT_FOR_AUTOFILL_YES
            else View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
    }

    private fun toggleAutofill() {
        autofillEnabled = !autofillEnabled
        prefs.autofill = autofillEnabled
        tabs.forEach { applyAutofill(it) }
        if (!autofillEnabled && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            // 입력 중이던 폼이 있으면 저장 안내가 뜨지 않도록 취소
            getSystemService(android.view.autofill.AutofillManager::class.java)?.cancel()
        }
        toast(if (autofillEnabled) "비밀번호·자동완성 켜짐" else "비밀번호·자동완성 꺼짐")
    }

    private fun autofillServiceStatus(): String {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) {
            return "Android 8.0 이상에서 지원됩니다"
        }
        val afm = getSystemService(android.view.autofill.AutofillManager::class.java)
        return when {
            afm == null || !afm.isAutofillSupported -> "이 기기에서는 자동완성을 쓸 수 없어요"
            afm.hasEnabledAutofillServices() -> "사용 중인 서비스가 있어요 · 눌러서 바꾸기"
            else -> "선택된 서비스가 없어요 · 눌러서 비밀번호 관리자 고르기"
        }
    }

    /** 기기의 자동완성 서비스 선택 화면을 연다 (없으면 설정 앱의 일반 화면) */
    private fun openAutofillSettings() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        val intent = Intent(android.provider.Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE)
            .setData(Uri.parse("package:$packageName"))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
                toast("설정 화면을 열 수 없어요")
            }
        }
    }

    // ───────────────────────── 웹 화면: 다크 모드 · 글자 크기 ─────────────────────────

    /** 0 = 끔, 1 = 기기가 다크 모드일 때만, 2 = 항상 */
    private var darkMode = 1
    private var textZoom = 100

    private fun systemNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** 기기가 밝은 모드인데 "항상 켜기"인 경우: 시스템 기능으로는 안 되므로 CSS 로 색을 뒤집는다 */
    private fun needCssDark(): Boolean = darkMode == 2 && !systemNight()

    private fun darkModeLabel(): String = when (darkMode) {
        0 -> "끄기"
        2 -> "항상 켜기"
        else -> "기기가 다크 모드일 때"
    }

    private fun forceDarkJs(on: Boolean): String = if (on) {
        "(function(){if(document.getElementById('ev-dark'))return;var s=document.createElement('style');" +
            "s.id='ev-dark';s.textContent='html{background:#fff!important;filter:invert(1) hue-rotate(180deg)!important}" +
            "img,picture,video,canvas,iframe{filter:invert(1) hue-rotate(180deg)!important}';" +
            "(document.head||document.documentElement).appendChild(s)})()"
    } else {
        "(function(){var s=document.getElementById('ev-dark');if(s)s.remove()})()"
    }

    /** 웹뷰에 글자 크기와 다크 모드를 적용한다 */
    private fun applyWebAppearance(wv: WebView) {
        wv.settings.textZoom = textZoom
        val dark = darkMode != 0 && systemNight()
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(wv.settings, dark)
            } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                @Suppress("DEPRECATION")
                WebSettingsCompat.setForceDark(
                    wv.settings,
                    if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
                )
            }
        } catch (e: Exception) {
            // 지원하지 않는 WebView 면 그대로 둔다
        }
    }

    private fun showDarkModeDialog() {
        val labels = arrayOf("끄기", "기기가 다크 모드일 때", "항상 켜기")
        MaterialAlertDialogBuilder(this)
            .setTitle("웹 페이지 다크 모드")
            .setSingleChoiceItems(labels, darkMode) { d, which ->
                darkMode = which
                prefs.webDarkMode = which
                tabs.forEach { t ->
                    t.liveWebView?.let { applyWebAppearance(it) }
                    t.darkInjected = false
                    // 지금 열려 있는 페이지에도 바로 반영 (CSS 방식은 켜고 끄기를 스크립트로)
                    if (!t.isHome) t.liveWebView?.evaluateJavascript(forceDarkJs(needCssDark()), null)
                    if (needCssDark()) t.darkInjected = true
                }
                d.dismiss()
                toast("다크 모드: ${darkModeLabel()}")
            }
            .show()
    }

    // ───────────────────────── 페이지 확대/축소 (50% ~ 500%) ─────────────────────────

    private fun effectiveZoom(tab: BrowserTab): Int = (tab.pageZoom ?: prefs.pageZoom).coerceIn(50, 500)

    /**
     * 핀치 줌이 아니라 페이지 자체를 키우고 줄인다 (PC 브라우저의 Ctrl +/- 와 같은 방식).
     * 레이아웃 뷰포트 너비를 (화면 너비 ÷ 배율) 로 바꿔서, 글자·이미지·여백이 함께 커지고 줄이 다시 나뉜다.
     * 100% 면 원래 뷰포트로 되돌린다. 사이트가 뷰포트 설정을 다시 바꾸면 곧바로 다시 덮어쓴다.
     */
    private fun pageZoomJs(tab: BrowserTab, zoom: Int? = null): String {
        val z = (zoom ?: effectiveZoom(tab)).coerceIn(50, 500)
        if (z == 100) return PAGE_ZOOM_OFF_JS
        val wv = tab.liveWebView
        val dp = if (wv != null && wv.width > 0) (wv.width / resources.displayMetrics.density).toInt()
        else resources.configuration.screenWidthDp
        val base = if (tab.desktop) maxOf(dp, 1024) else maxOf(dp, 1)
        val w = (base * 100f / z).coerceAtLeast(1f)
        return "(function(){var W=${"%.2f".format(java.util.Locale.US, w)};" + PAGE_ZOOM_ON_JS + "})();"
    }

    private fun applyPageZoom(tab: BrowserTab) {
        if (tab.isHome) return
        tab.zoomInjected = true
        tab.liveWebView?.evaluateJavascript(pageZoomJs(tab), null)
    }

    private fun showPageZoomDialog() {
        val tab = current ?: return
        val zMin = 50
        val zMax = 500
        val zStep = 10
        var applied = false

        // 테마 색 (라이트/다크 모두 따라간다)
        fun themeColor(attr: Int, fallback: Int) = MaterialColors.getColor(this, attr, ContextCompat.getColor(this, fallback))
        val cPrimary = themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)
        val cOnSurface = themeColor(com.google.android.material.R.attr.colorOnSurface, R.color.ev_text)
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val cTrack = themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill)
        val medium = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)

        var zoom = (Math.round((effectiveZoom(tab) - zMin) / zStep.toFloat()) * zStep + zMin).coerceIn(zMin, zMax)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(0), dp(24), dp(8))
        }

        // 1) 큰 배율 숫자
        val label = TextView(this).apply {
            textSize = 52f
            typeface = medium
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(cPrimary)
            setPadding(0, dp(4), 0, dp(14))
        }

        // 2) 게이지바 + 양 끝 값
        val gauge = ZoomGauge(this).apply {
            min = zMin; max = zMax; step = zStep; defaultValue = 100
            activeColor = cPrimary
            inactiveColor = cTrack
            dotOnActiveColor = android.graphics.Color.WHITE
            value = zoom
            contentDescription = "화면 확대/축소"
        }
        fun endLabel(t: String) = TextView(this).apply {
            text = t
            textSize = 13f
            setTextColor(cMuted)
        }
        val ends = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, 0)
            addView(endLabel("${zMin}%"))
            addView(android.view.View(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(endLabel("${zMax}%"))
        }

        // 3) '이 탭에만 적용': 카드 없이 한 줄 (제목 + 설명 / 스위치)
        val tabOnly = com.google.android.material.materialswitch.MaterialSwitch(this).apply {
            isChecked = tab.pageZoom != null
        }
        val tabOnlyTitle = TextView(this).apply {
            text = "이 탭에만 적용"
            textSize = 16f
            setTextColor(cOnSurface)
        }
        val hint = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(3), 0, 0)
            setTextColor(cMuted)
        }
        fun refreshHint() {
            hint.text = if (tabOnly.isChecked) "다른 탭은 전체 설정(${prefs.pageZoom}%)을 따라요"
            else "모든 탭과 새 탭에 적용돼요"
        }
        refreshHint()
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(6))
            isClickable = true
            isFocusable = true
            setOnClickListener { tabOnly.toggle() }
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(tabOnlyTitle)
                addView(hint)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(tabOnly)
        }
        tabOnly.setOnCheckedChangeListener { _, _ -> refreshHint() }

        // 실시간 미리보기: 움직이는 동안 지금 보는 페이지에 바로 반영한다 (저장은 '적용'을 눌러야)
        val handler = Handler(Looper.getMainLooper())
        val previewRun = Runnable {
            if (!tab.isHome) tab.liveWebView?.evaluateJavascript(pageZoomJs(tab, zoom), null)
        }
        fun setZoomLabel() {
            val sp = android.text.SpannableString("${zoom}%")
            sp.setSpan(android.text.style.RelativeSizeSpan(0.5f), sp.length - 1, sp.length,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            label.text = sp
        }
        gauge.onValueChange = { v ->
            zoom = v
            setZoomLabel()
            handler.removeCallbacks(previewRun)
            handler.postDelayed(previewRun, 60L)
        }
        setZoomLabel()

        box.addView(label)
        box.addView(gauge)
        box.addView(ends)
        // 게이지 영역과 설정 영역을 가는 선으로 나눈다
        val divider = android.view.View(this).apply { setBackgroundColor(cTrack) }
        box.addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
            topMargin = dp(18)
        })
        box.addView(tabRow)

        MaterialAlertDialogBuilder(this)
            .setTitle("화면 확대/축소")
            .setView(android.widget.ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(box) })
            .setPositiveButton("적용") { _, _ ->
                applied = true
                val z = zoom
                if (tabOnly.isChecked) {
                    tab.pageZoom = z
                    applyPageZoom(tab)
                } else {
                    prefs.pageZoom = z
                    tab.pageZoom = null
                    // 이 탭만 따로 정해 둔 탭은 그 값을 유지하고, 나머지 탭에 새 값을 적용한다
                    tabs.filter { it.pageZoom == null }.forEach { applyPageZoom(it) }
                }
                toast("화면 확대/축소: ${z}%" + if (tabOnly.isChecked) " (이 탭만)" else "")
            }
            .setNegativeButton("취소", null)
            .setOnDismissListener {
                handler.removeCallbacks(previewRun)
                // 적용을 누르지 않고 닫았다면 미리보기를 걷어내고 원래 배율로 되돌린다
                if (!applied) applyPageZoom(tab)
            }
            .show()
            .also { dlg ->
                // 큰 화면에서 팝업이 옆으로 퍼지지 않게 폭을 제한한다
                val w = minOf(dp(344), resources.displayMetrics.widthPixels - dp(48))
                dlg.window?.setLayout(w, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
            }
    }

    private fun showTextSizeDialog() {
        val original = textZoom
        val min = 50
        val step = 10
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(4))
        }
        val label = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface))
        }
        val sample = TextView(this).apply {
            text = "가나다라 ABC abc 123"
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant))
        }
        val bar = android.widget.SeekBar(this).apply {
            max = (200 - min) / step
            progress = ((textZoom - min) / step).coerceIn(0, max)
        }
        fun show(zoom: Int) {
            label.text = "${zoom}%"
            sample.textSize = 16f * zoom / 100f
        }
        show(textZoom)
        bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                val z = min + p * step
                show(z)
                // 보고 있는 페이지에 바로 반영해서 미리 볼 수 있게
                current?.webView?.settings?.textZoom = z
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
        box.addView(label)
        box.addView(sample)
        box.addView(bar)
        MaterialAlertDialogBuilder(this)
            .setTitle("글자 크기")
            .setView(box)
            .setPositiveButton("적용") { _, _ ->
                textZoom = min + bar.progress * step
                prefs.textZoom = textZoom
                tabs.forEach { it.liveWebView?.settings?.textZoom = textZoom }
            }
            .setNeutralButton("기본값") { _, _ ->
                textZoom = 100
                prefs.textZoom = 100
                tabs.forEach { it.liveWebView?.settings?.textZoom = 100 }
            }
            .setNegativeButton("취소", null)
            .setOnCancelListener { current?.webView?.settings?.textZoom = original }
            .setOnDismissListener {
                // 적용/기본값을 누르지 않고 닫았다면 원래 크기로 되돌린다
                current?.webView?.settings?.textZoom = textZoom
            }
            .show()
    }

    private fun showSpeedDialog() {
        val tab = current ?: return
        val rates = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
        val labels = rates.map { "${it}x" }.toTypedArray()
        val selected = rates.indexOfFirst { r -> r == tab.rate }.let { if (it < 0) 2 else it }
        MaterialAlertDialogBuilder(this)
            .setTitle("재생 속도")
            .setSingleChoiceItems(labels, selected) { d, which ->
                tab.rate = rates[which]
                tab.webView.evaluateJavascript(speedJs(tab.rate), null)
                d.dismiss()
            }
            .show()
    }

    // ───────────────────────── 다운로드 ─────────────────────────

    private val errorTemplate: String by lazy {
        assets.open("error.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun htmlEscape(t: String) =
        t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** 불러오지 못했을 때 보여 주는 오류 화면 (찢어져 바닥에 떨어진 도트 나뭇잎) */
    private fun errorPageHtml(url: String, code: Int, desc: String): String {
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.takeIf { it.isNotBlank() } ?: url
        val (title, msg) = when (code) {
            WebViewClient.ERROR_HOST_LOOKUP ->
                "사이트를 찾을 수 없어요" to "주소가 맞는지 확인하거나, 잠시 뒤에 다시 시도해 보세요."
            WebViewClient.ERROR_CONNECT, WebViewClient.ERROR_IO, WebViewClient.ERROR_TIMEOUT ->
                "연결할 수 없어요" to "서버가 응답하지 않거나 인터넷 연결이 불안정해요."
            WebViewClient.ERROR_FAILED_SSL_HANDSHAKE ->
                "보안 연결에 실패했어요" to "이 사이트와 안전하게 연결할 수 없어요."
            WebViewClient.ERROR_REDIRECT_LOOP ->
                "페이지가 계속 다른 곳으로 이동해요" to "사이트 설정에 문제가 있을 수 있어요. 쿠키를 지우고 다시 시도해 보세요."
            WebViewClient.ERROR_BAD_URL ->
                "주소가 올바르지 않아요" to "주소를 다시 확인해 주세요."
            else ->
                "웹페이지를 사용할 수 없어요" to "페이지를 불러오는 중 문제가 생겼어요."
        }
        return errorTemplate
            .replace("__TITLE__", htmlEscape(title))
            .replace("__MSG__", htmlEscape(msg))
            .replace("__HOST__", htmlEscape(host))
            .replace("__CODE__", htmlEscape(desc))
            .replace("__URL_JSON__", JSONObject.quote(url))
    }

    /** 오류 화면을 보여 주는 중이면 그 주소를 다시 불러오고, 아니면 보통 새로고침 */
    private fun reloadTab(tab: BrowserTab) {
        if (tab.isHome && tab.errorUrl == null) return
        val err = tab.errorUrl
        if (err != null) {
            tab.errorUrl = null
            tab.webView.loadUrl(err)
        } else {
            tab.webView.reload()
        }
    }

    /** 차단한 요청에 돌려줄 빈 403 응답. 종류에 맞는 MIME 을 달아 두면 페이지 스크립트가 덜 깨진다. */
    private fun blockedResponse(uri: Uri, subResource: Boolean = false): WebResourceResponse {
        // WebResourceResponse 는 3xx 상태 코드를 허용하지 않는다(IllegalArgumentException).
        // 하위 요청도 403 으로 막는다: img/script 는 onerror, CORS fetch/XHR 은 네트워크 오류로 실패한다.
        val p = uri.path?.lowercase().orEmpty()
        val mime = when {
            p.endsWith(".js") || p.contains("/js/") -> "application/javascript"
            p.endsWith(".css") -> "text/css"
            p.endsWith(".gif") || p.endsWith(".png") || p.endsWith(".jpg") || p.endsWith(".jpeg") || p.endsWith(".webp") -> "image/gif"
            else -> "text/plain"
        }
        val headers = if (subResource) mapOf("Cache-Control" to "no-store") else emptyMap()
        return WebResourceResponse(mime, "utf-8", 403, "Blocked", headers, ByteArrayInputStream(ByteArray(0)))
    }

    private fun looksLikeMediaUrl(path: String): Boolean {
        val p = path.lowercase()
        return listOf(
            ".m3u8", ".mpd", ".mp4", ".webm", ".m4v", ".mov", ".mkv", ".avi", ".flv",
            ".3gp", ".ogv", ".wmv", ".mpg", ".mpeg", ".ism/manifest"
        ).any { p.endsWith(it) }
    }

    /** 영상 파일 / HLS / DASH 요청이면 내장 플레이어 후보로 기억해 둔다. (백그라운드 스레드에서 불림) */
    private fun sniffMedia(tab: BrowserTab, uri: Uri) {
        val path = uri.path?.lowercase() ?: return
        val full = uri.toString().lowercase()
        if (path.endsWith(".vtt") || path.endsWith(".srt") || path.endsWith(".ass") || path.endsWith(".ssa") ||
            path.endsWith(".ttml") || path.endsWith(".dfxp")
        ) {
            synchronized(tab.sniffedSubs) {
                if (tab.sniffedSubs.size >= 12) tab.sniffedSubs.remove(tab.sniffedSubs.first())
                tab.sniffedSubs.add(uri.toString())
            }
            return
        }
        val isMedia = looksLikeMediaUrl(path) ||
            // 확장자가 주소 뒤쪽(쿼리)에 붙어 있는 스트리밍 주소도 잡는다 (예: ...?file=index.m3u8)
            full.contains(".m3u8") || full.contains(".mpd")
        if (!isMedia) return
        val u = uri.toString()
        synchronized(tab.sniffed) {
            if (tab.sniffed.size >= 30) tab.sniffed.remove(tab.sniffed.first())
            tab.sniffed.add(u)
        }
    }

    /** 지금 페이지의 영상을 앱 안의 플레이어로 연다. 재생 중이던 위치에서 이어서 재생한다. */
    private fun openInternalPlayer() {
        val tab = current ?: return
        val wv = tab.webView
        wv.evaluateJavascript(MediaScripts.FIND_MEDIA) { raw ->
            class Cand(val url: String, val posMs: Long, val playing: Boolean = false)
            val cands = ArrayList<Cand>()
            var pageTitle = wv.title.orEmpty()
            var subsJson: String? = null // 페이지의 <track> 자막 (있으면 플레이어에 같이 넘긴다)
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    val o = JSONObject(inner)
                    pageTitle = o.optString("title", pageTitle)
                    subsJson = o.optJSONArray("subs")?.takeIf { it.length() > 0 }?.toString()
                    val a = o.getJSONArray("items")
                    for (i in 0 until a.length()) {
                        val e = a.getJSONObject(i)
                        cands.add(Cand(e.getString("u"), (e.optDouble("t", 0.0) * 1000).toLong(), e.optBoolean("p", false)))
                    }
                }
            } catch (e: Exception) {
                // 페이지에서 못 찾으면 요청 목록만 사용
            }
            // 페이지가 자바스크립트로 따로 불러온 자막 파일도 같이 넘긴다 (<track> 태그가 없는 플레이어용)
            val extraSubs = synchronized(tab.sniffedSubs) { tab.sniffedSubs.toList() }
            if (extraSubs.isNotEmpty()) {
                try {
                    val arr = JSONArray(subsJson?.takeIf { it.isNotBlank() } ?: "[]")
                    val known = HashSet<String>()
                    for (i in 0 until arr.length()) known.add(arr.getJSONObject(i).optString("u"))
                    for (u in extraSubs) {
                        if (arr.length() >= 8) break
                        if ((u.startsWith("http://") || u.startsWith("https://")) && known.add(u)) {
                            arr.put(JSONObject().put("u", u).put("l", "").put("g", ""))
                        }
                    }
                    if (arr.length() > 0) subsJson = arr.toString()
                } catch (e: Exception) { }
            }
            val have = cands.map { it.url }.toHashSet()
            val sn = synchronized(tab.sniffed) { tab.sniffed.toList() }
            sn.sortedBy {
                val p = it.lowercase()
                if (p.contains(".m3u8") || p.contains(".mpd")) 0 else 1
            }.forEach { if (it !in have) cands.add(Cand(it, 0L)) }
            // 영상 파일 주소를 바로 연 탭이면 그 주소 자체가 영상이다
            wv.url?.let { u ->
                if (u !in have && (looksLikeMediaUrl(Uri.parse(u).path.orEmpty()) || u.lowercase().contains(".m3u8"))) {
                    cands.add(0, Cand(u, 0L))
                }
            }
            val list = cands.filter { it.url.startsWith("http://") || it.url.startsWith("https://") }.take(15)

            fun launch(c: Cand) {
                PlayerActivity.start(
                    this, c.url, pageTitle, wv.url, wv.settings.userAgentString,
                    cookieManagerFor(tab).getCookie(c.url), c.posMs, subsJson
                )
                pauseAllMedia()
                if (customView != null) hideCustomView()
            }

            when {
                list.isEmpty() -> MaterialAlertDialogBuilder(this)
                    .setTitle("재생할 영상을 찾지 못했어요")
                    .setMessage(
                        "영상을 먼저 한 번 재생한 뒤 다시 눌러 보세요.\n\n" +
                            "암호화(DRM)된 영상이나 blob 방식으로만 재생되는 영상, 다른 도메인의 iframe 안에 있는 영상은 열 수 없습니다."
                    )
                    .setPositiveButton("확인", null)
                    .show()
                list.size == 1 -> launch(list[0])
                // 지금 재생 중인 영상이 있으면 고르게 하지 않고 바로 그 영상을 연다 (이어서 재생)
                list.any { it.playing } -> launch(list.first { it.playing })
                else -> {
                    val names = list.map {
                        val host = runCatching { Uri.parse(it.url).host }.getOrNull().orEmpty()
                        val file = it.url.substringBefore('?').substringAfterLast('/').ifBlank { "영상" }
                        "$host · $file"
                    }.toTypedArray()
                    MaterialAlertDialogBuilder(this)
                        .setTitle("내장 플레이어로 재생")
                        .setItems(names) { _, i -> launch(list[i]) }
                        .setNegativeButton("취소", null)
                        .show()
                }
            }
        }
    }

    private fun findVideos() {
        val wv = current?.webView ?: return
        wv.evaluateJavascript(FIND_VIDEO_JS) { raw ->
            val found: List<String> = try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String ?: "[]"
                val arr = JSONArray(inner)
                (0 until arr.length()).map { arr.getString(it) }
            } catch (e: Exception) {
                emptyList()
            }
            val urls = found.filter {
                val path = it.substringBefore('?').lowercase()
                (it.startsWith("http://") || it.startsWith("https://")) &&
                    !path.endsWith(".m3u8") && !path.endsWith(".mpd")
            }.take(15)

            if (urls.isEmpty()) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("영상 파일 없음")
                    .setMessage(
                        "직접 내려받을 수 있는 영상 파일을 찾지 못했습니다.\n\n" +
                            "blob/스트리밍(m3u8) 방식이거나 보호(DRM)된 영상, 다른 도메인의 iframe 안에 있는 영상은 지원하지 않습니다."
                    )
                    .setPositiveButton("확인", null)
                    .show()
            } else {
                val names = urls.map { URLUtil.guessFileName(it, null, null) }.toTypedArray()
                MaterialAlertDialogBuilder(this)
                    .setTitle("저장할 영상 선택")
                    .setItems(names) { _, i ->
                        startDownload(urls[i], wv.settings.userAgentString, null, null)
                    }
                    .setNegativeButton("취소", null)
                    .show()
            }
        }
    }

    // ───────────────────────── AI 어시스턴트 ─────────────────────────

    /** 지금 보는 페이지의 제목·주소·본문·선택한 글을 모아 AI 에게 넘긴다. 열린 페이지가 없으면 null. */
    private fun fetchPageForAssistant(cb: (PageSnapshot?) -> Unit) {
        val tab = current
        if (tab == null || tab.isHome || !hasPage(tab)) {
            cb(null)
            return
        }
        tab.webView.evaluateJavascript(PAGE_TEXT_JS) { raw ->
            val snap: PageSnapshot? = try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner == null) {
                    null
                } else {
                    val o = JSONObject(inner)
                    PageSnapshot(
                        o.optString("url"), o.optString("title"),
                        o.optString("text"), o.optString("sel")
                    )
                }
            } catch (e: Exception) {
                null
            }
            cb(snap)
        }
    }

    /** 지금 보는 페이지에서 JS 를 실행한다. 열린 페이지가 없으면 null 을 돌려준다. */
    private fun runJsOnCurrentPage(js: String, cb: (String?) -> Unit) {
        val tab = current
        if (tab == null || tab.isHome || !hasPage(tab)) {
            cb(null)
            return
        }
        tab.webView.evaluateJavascript(js) { raw -> cb(raw) }
    }

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("blob/data 형식 주소는 직접 다운로드할 수 없습니다")
            return
        }
        enqueueDownload(url, userAgent, contentDisposition, mimeType)
    }

    private fun enqueueDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        val referer = current?.webView?.url?.takeIf { it.startsWith("http") }

        // Android 10 이상: 여러 연결로 나눠 받는 빠른 다운로드
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            requestNotificationPermission()
            try {
                DownloadService.start(this, url, userAgent, contentDisposition, mimeType, referer)
                toast("다운로드 시작: ${FileNames.guess(url, contentDisposition, mimeType)}")
                return
            } catch (e: Exception) {
                // 서비스를 시작하지 못하면 시스템 다운로더로
            }
        }
        systemDownload(url, userAgent, contentDisposition, mimeType, referer)
    }

    private fun systemDownload(
        url: String, userAgent: String?, contentDisposition: String?, mimeType: String?, referer: String?
    ) {
        val name = SystemDownload.enqueue(this, url, userAgent, contentDisposition, mimeType, referer)
        toast(if (name != null) "다운로드 중: $name" else "다운로드에 실패했습니다")
    }

    /** Android 13+ 에서 다운로드 진행 알림을 보이려면 알림 권한이 필요하다. (거부해도 다운로드는 진행됨) */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || askedNotificationPermission) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotificationPermission = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private var adListTryAt = 0L

    /**
     * 차단 목록이 없거나 3일이 지났으면 내려받는다.
     * 실패해도 일주일을 기다리지 않고, 앱을 다시 열 때(30분 간격 이상) 또 시도한다.
     */
    private fun autoUpdateAdBlockList() {
        val now = System.currentTimeMillis()
        val threeDays = 3L * 24 * 60 * 60 * 1000
        if (now - adBlocker.lastUpdated < threeDays) return
        if (now - adListTryAt < 30L * 60 * 1000) return
        adListTryAt = now
        prefs.adblockLastTry = now
        // 자동완성과 같은 스레드를 막지 않도록 별도 스레드에서 실행
        Thread {
            try {
                adBlocker.update()
            } catch (e: Exception) {
                // 실패하면 다음에 앱을 열 때 다시 시도
            }
        }.apply { isDaemon = true }.start()
    }

    /** 앱 안의 다운로드 목록 화면 (폴더로 정리 가능) */
    private fun openDownloads() {
        bookmarksLauncher.launch(listIntent(DownloadsActivity::class.java))
    }

    // ───────────────────────── 북마크 ─────────────────────────

    /** 지금 보고 있는 웹페이지 주소 (홈 화면이거나 웹페이지가 아니면 null) */
    private fun currentPageUrl(): String? {
        val tab = current ?: return null
        if (tab.isHome) return null
        return tab.webView.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun currentBookmark(): Bookmark? = currentPageUrl()?.let { prefs.findBookmark(it) }

    /** 현재 페이지를 북마크에 추가하거나, 이미 있으면 수정/삭제 대화상자를 연다. */
    private fun bookmarkCurrent() {
        val url = currentPageUrl()
        if (url == null) {
            toast("북마크할 웹페이지가 없습니다")
            return
        }
        val title = current?.webView?.title.orEmpty()
        ListUi.showBookmarkEditor(this, prefs, prefs.findBookmark(url), url, title) { msg -> toast(msg) }
    }

    private fun openHistory() {
        bookmarksLauncher.launch(listIntent(HistoryActivity::class.java))
    }

    private fun openBookmarks() {
        bookmarksLauncher.launch(listIntent(BookmarksActivity::class.java))
    }

    private fun showLinkMenu(link: String?, image: String?) {
        fun isWeb(u: String?) = u != null && (u.startsWith("http://") || u.startsWith("https://"))
        val webLink = link?.takeIf { isWeb(it) }
        val webImage = image?.takeIf { isWeb(it) }
        if (webLink == null && webImage == null) return

        val target = webLink ?: webImage!!
        val items = mutableListOf<Popup.Item>()
        if (webLink != null) {
            items.add(Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { createTab(webLink, opener = current) })
            items.add(Popup.Item(R.drawable.ic_copy, "링크 주소 복사") { copyToClipboard(webLink) })
            items.add(Popup.Item(R.drawable.ic_share, "링크 공유") { shareText(webLink) })
        }
        if (webImage != null) {
            items.add(Popup.Item(R.drawable.ic_download, "이미지 저장") {
                startDownload(webImage, current?.webView?.settings?.userAgentString, null, null)
            })
            items.add(Popup.Item(R.drawable.ic_image, "새 탭에서 이미지 열기") { createTab(webImage, opener = current) })
            if (webLink != null) items.add(Popup.Item(R.drawable.ic_copy, "이미지 주소 복사") { copyToClipboard(webImage) })
        }
        window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        Popup.menu(
            this,
            title = Uri.parse(target).host?.removePrefix("www.") ?: if (webLink != null) "링크" else "이미지",
            subtitle = target,
            headerIcon = if (webLink != null) R.drawable.ic_globe else R.drawable.ic_image,
            items = items
        )
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        try {
            startActivity(Intent.createChooser(send, "공유"))
        } catch (e: Exception) {
            toast("공유할 수 있는 앱이 없습니다")
        }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", text))
        toast("복사했습니다")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        /** 새 탭(홈) 화면이 웹 기록에 남을 때 쓰는 주소 */
        const val HOME_URL = "evergreen://home"
        private const val HOME_HTML =
            "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>html,body{margin:0;background:transparent}</style></head><body></body></html>"

        /** 지금 떠 있는 창(인스턴스)들. 앱을 여러 창으로 띄울 수 있어서, 하나만 가진 자원은 이걸로 조율한다 */
        private val instances = ArrayList<MainActivity>()
        private var primary: MainActivity? = null
        private var windowSeq = 0

        /** 탭 화면의 카드 줄(가로 한 줄) 표시용 태그 */
        private const val CARD_ROW_TAG = "cardRow"

        /** 웹 페이지가 이동할 수 없게 막는 주소 형식 */
        private val BLOCKED_NAV_SCHEMES = setOf("file", "content", "javascript", "data", "filesystem")

        private const val MAX_HOME_SHORTCUTS = 8

        /** 뒤로가기 후 이 시간(ms) 안에 일어나는 '사용자 동작 없는' 페이지 이동은 자동 리다이렉트로 보고 막는다 */
        private const val BACK_GUARD_MS = 4000L
        private const val DOWNLOAD_TOUCH_MS = 15_000L

        /** AI 어시스턴트에 넘길 페이지 내용 (본문은 3만 자까지) */
        private const val PAGE_TEXT_JS = """(function(){
var t=(document.body&&document.body.innerText)||'';
var s='';try{s=String(window.getSelection())}catch(e){}
return JSON.stringify({url:location.href,title:document.title||'',text:t.slice(0,30000),sel:s.slice(0,4000)});
})()"""

        private const val FIND_VIDEO_JS =
            "(function(){var r=[];document.querySelectorAll('video,video source,audio source')" +
                ".forEach(function(e){var u=e.currentSrc||e.src;if(u&&/^https?:/.test(u))r.push(u);});" +
                "return JSON.stringify(Array.from(new Set(r)));})()"
    }
}

/** 입력한 글자와 상관없이 전달받은 목록을 그대로 보여주는 자동완성 어댑터 */
class NoFilterAdapter(context: Context, private val data: MutableList<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, data) {

    private val noFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): Filter.FilterResults =
            Filter.FilterResults().also {
                it.values = data
                it.count = data.size
            }

        override fun publishResults(constraint: CharSequence?, results: Filter.FilterResults?) {
            if (data.isNotEmpty()) notifyDataSetChanged() else notifyDataSetInvalidated()
        }
    }

    override fun getFilter(): Filter = noFilter
}

/** 페이지 확대/축소: 뷰포트 너비를 W 로 바꾼다 (W = 화면 너비 ÷ 배율). 위에서 `var W=...;` 를 먼저 붙여 쓴다. */
private const val PAGE_ZOOM_ON_JS = """
var d=document,h=d.head||d.documentElement;
var m=d.querySelector('meta[name=viewport]');
if(!window.__evZ){window.__evZ={}}
var Z=window.__evZ;
Z.w=W;
Z.fix=function(){
 var mm=d.querySelector('meta[name=viewport]');
 var c='width='+Z.w+',minimum-scale=0.05,maximum-scale=10,user-scalable=yes';
 if(!mm){mm=d.createElement('meta');mm.name='viewport';mm.setAttribute('data-ev-added','1');(d.head||d.documentElement).appendChild(mm)}
 if(mm.getAttribute('data-ev-orig')===null&&!mm.hasAttribute('data-ev-added'))mm.setAttribute('data-ev-orig',mm.getAttribute('content')||'');
 if(mm.getAttribute('content')!==c)mm.setAttribute('content',c);
};
Z.fix();
if(!Z.obs){
 Z.obs=new MutationObserver(function(){
  var mm=d.querySelector('meta[name=viewport]');
  if(!mm||mm.getAttribute('content')!=='width='+Z.w+',minimum-scale=0.05,maximum-scale=10,user-scalable=yes'){
   if(mm&&mm.getAttribute('data-ev-orig')===null&&!mm.hasAttribute('data-ev-added'))mm.setAttribute('data-ev-orig',mm.getAttribute('content')||'');
   Z.fix();
  }
 });
 Z.obs.observe(d.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['content','name']});
}
"""

/** 페이지 확대/축소 해제: 원래 뷰포트로 되돌린다 */
private const val PAGE_ZOOM_OFF_JS = """
(function(){
 var Z=window.__evZ; if(!Z)return;
 if(Z.obs){Z.obs.disconnect();Z.obs=null}
 var mm=document.querySelector('meta[name=viewport]');
 if(mm){
  if(mm.hasAttribute('data-ev-added')){mm.remove()}
  else if(mm.getAttribute('data-ev-orig')!==null){mm.setAttribute('content',mm.getAttribute('data-ev-orig'));mm.removeAttribute('data-ev-orig')}
 }
 window.__evZ=null;
})();
"""
