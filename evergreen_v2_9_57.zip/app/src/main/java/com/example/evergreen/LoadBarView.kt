package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import android.widget.ProgressBar
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * 웹사이트 로딩 바.
 *
 * 웹뷰가 알려 주는 진행률은 10 → 70 → 100 처럼 뚝뚝 끊겨 온다. 예전에는 소식이 올 때마다 새 애니메이터를 시작해서
 * 그때마다 속도가 0 부터 다시 붙었다(바가 멈칫하며 출발). 여기서는 바 안에 스프링 하나를 두고,
 * 목표가 바뀌어도 지금의 위치와 속도를 그대로 이어서 새 목표로 향한다. 감쇠를 임계값으로 잡아 목표를 넘어서지 않는다.
 *
 * 그리기: 채워진 부분 위로 빛이 흐르고(쉬머), 맨 앞은 살짝 밝게 번진다 — 로딩 중임이 한눈에 보이게.
 * 시스템의 "애니메이션 끄기"를 따른다 (끄면 쉬머 없이 바로 그 위치로 간다).
 *
 * progress / max 는 기존 ProgressBar 그대로라서 [ProgressBar] 로 다루는 코드는 바꿀 필요가 없다.
 */
class LoadBarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.progressBarStyleHorizontal
) : ProgressBar(context, attrs, defStyleAttr) {

    private var pos = 0f
    private var vel = 0f
    private var goalValue = 0f
    private var stiffness = 90f
    private var driving = false
    private var lastNanos = 0L
    private var animOn = true
    private var internalSet = false

    private val dens = resources.displayMetrics.density
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenMatrix = Matrix()
    private val tipMatrix = Matrix()
    private var sheenShader: LinearGradient? = null
    private var tipShader: LinearGradient? = null

    /** 지금 향하고 있는 목표 위치 (0..max) */
    val goal: Int get() = goalValue.roundToInt()

    /** 바깥에서 progress 를 직접 넣으면(0 으로 되돌리기 등) 스프링도 그 값에서 새로 시작한다 */
    override fun setProgress(progress: Int) {
        if (!internalSet) {
            pos = progress.toFloat()
            vel = 0f
            goalValue = pos
            halt()
        }
        super.setProgress(progress)
    }

    /** 현재 위치에서 [to] 로 부드럽게 달린다. 이미 달리는 중이면 속도를 이어받는다. stiffness 가 클수록 빠르다. */
    fun glideTo(to: Int, stiffness: Float = 90f) {
        val t = to.coerceIn(0, max).toFloat()
        goalValue = t
        this.stiffness = stiffness
        if (!animOn) {
            pos = t
            vel = 0f
            halt()
            applyPos()
            return
        }
        if (abs(t - pos) < 0.5f && abs(vel) < 1f) return
        if (!driving) {
            driving = true
            lastNanos = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    /** 달리던 스프링을 멈춘다 (위치는 그대로 둔다). */
    fun halt() {
        if (!driving) return
        driving = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!driving) return
            // 프레임이 길게 밀려도 건너뛰지 않는다 (SmoothAnim 과 같은 규칙)
            var left = SmoothAnim.step(lastNanos, frameTimeNanos) / 1000f
            lastNanos = frameTimeNanos
            val damp = 2f * sqrt(stiffness)
            while (left > 0f) {
                val h = minOf(left, 0.004f)
                vel += (stiffness * (goalValue - pos) - damp * vel) * h
                pos += vel * h
                left -= h
            }
            if (pos < 0f) { pos = 0f; if (vel < 0f) vel = 0f }
            if (pos > max) { pos = max.toFloat(); if (vel > 0f) vel = 0f }
            if (abs(goalValue - pos) < 0.4f && abs(vel) < 2f) {
                pos = goalValue
                vel = 0f
                driving = false
                applyPos()
                return
            }
            applyPos()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun applyPos() {
        internalSet = true
        try { super.setProgress(pos.roundToInt()) } finally { internalSet = false }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animOn = Motion.enabled(context)
    }

    override fun onDetachedFromWindow() {
        halt()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == View.VISIBLE) animOn = Motion.enabled(context)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        sheenShader = null
        tipShader = null
    }

    /** 종 모양(가우시안)으로 부드럽게 퍼지는 빛 모양: 가장자리가 뚝 끊기지 않고 서서히 사라진다. [peak] = 가운데 밝기(0..255) */
    private fun bellColors(peak: Int, n: Int = 9): Pair<IntArray, FloatArray> {
        val colors = IntArray(n)
        val pos = FloatArray(n)
        for (k in 0 until n) {
            val t = k / (n - 1f)
            val g = Math.exp((-((t - 0.5) / 0.19) * ((t - 0.5) / 0.19)))
            // 양 끝은 완전히 투명해지도록 살짝 눌러 준다
            val edge = (1.0 - Math.pow(Math.abs(t - 0.5) * 2.0, 6.0)).coerceIn(0.0, 1.0)
            colors[k] = Color.argb((peak * g * edge).roundToInt().coerceIn(0, 255), 255, 255, 255)
            pos[k] = t
        }
        return colors to pos
    }

    private fun easeInOut(p: Float): Float =
        if (p < 0.5f) 4f * p * p * p else 1f - Math.pow((-2.0 * p + 2.0), 3.0).toFloat() / 2f

    @Synchronized
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!animOn) return
        val w = width.toFloat()
        val h = height.toFloat()
        val filled = w * (pos / max.toFloat()).coerceIn(0f, 1f)
        if (filled < 2f * dens || w <= 0f) {
            postInvalidateOnAnimation()
            return
        }
        val sheenW = 96f * dens
        val tipW = 56f * dens
        val sheen = sheenShader ?: bellColors(170).let { (c, p) ->
            LinearGradient(0f, 0f, sheenW, 0f, c, p, Shader.TileMode.CLAMP)
        }.also { sheenShader = it }
        // 맨 앞 번짐: 채워진 끝에서 가장 밝고, 끝 너머로도 살짝 번진다 (왼쪽은 서서히 밝아지고 오른쪽은 짧게 사라진다)
        val tip = tipShader ?: LinearGradient(
            0f, 0f, tipW, 0f,
            intArrayOf(
                Color.TRANSPARENT, Color.argb(40, 255, 255, 255), Color.argb(120, 255, 255, 255),
                Color.argb(210, 255, 255, 255), Color.argb(120, 255, 255, 255), Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.3f, 0.6f, 0.78f, 0.9f, 1f), Shader.TileMode.CLAMP
        ).also { tipShader = it }

        val now = SystemClock.uptimeMillis()

        // 빛줄기: 느리게 출발해서 빨라졌다가 끝에서 다시 느려지며 지나가고, 잠깐 쉰다. 양 끝에서는 서서히 나타나고 사라진다
        val travel = 1100f + minOf(filled / dens, 400f) * 1.5f
        val rest = 450f
        val t = (now % (travel + rest).toLong()).toFloat()
        val save = canvas.save()
        canvas.clipRect(0f, 0f, filled, h)
        if (t < travel) {
            val p = t / travel
            val e = easeInOut(p)
            val x = -sheenW + e * (filled + sheenW)
            val fade = (minOf(p / 0.18f, (1f - p) / 0.22f)).coerceIn(0f, 1f)
            sheenPaint.alpha = (255f * fade * fade * (3f - 2f * fade)).roundToInt().coerceIn(0, 255)
            sheenMatrix.setTranslate(x, 0f)
            sheen.setLocalMatrix(sheenMatrix)
            sheenPaint.shader = sheen
            canvas.drawRect(x, 0f, x + sheenW, h, sheenPaint)
        }
        canvas.restoreToCount(save)

        // 맨 앞: 숨 쉬듯 은은하게 밝아졌다 어두워지고, 달리는 중(속도가 있을 때)일수록 더 밝다. 끝 너머로도 번진다
        val boost = (abs(vel) / 220f).coerceIn(0f, 1f)
        val breathe = 0.86f + 0.14f * Math.sin(now / 380.0).toFloat()
        tipPaint.alpha = ((150 + 90 * boost) * breathe).roundToInt().coerceIn(0, 255)
        val tipRight = filled + tipW * 0.22f
        val tipLeft = tipRight - tipW
        val save2 = canvas.save()
        canvas.clipRect(0f, 0f, w, h)
        tipMatrix.setTranslate(tipLeft, 0f)
        tip.setLocalMatrix(tipMatrix)
        tipPaint.shader = tip
        canvas.drawRect(tipLeft, 0f, tipRight, h, tipPaint)
        canvas.restoreToCount(save2)

        postInvalidateOnAnimation()
    }
}
