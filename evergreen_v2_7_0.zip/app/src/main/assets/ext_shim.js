function __evxMake(ID, M, MSG, B, T) {
  var BASE = "https://ext.evergreen.invalid/" + ID + "/";
  function ev() {
    var L = [];
    return {
      addListener: function (f) { if (typeof f === "function") L.push(f); },
      removeListener: function (f) { var i = L.indexOf(f); if (i >= 0) L.splice(i, 1); },
      hasListener: function (f) { return L.indexOf(f) >= 0; },
      hasListeners: function () { return L.length > 0; },
      _d: function (a) { L.slice().forEach(function (f) { try { f.apply(null, a); } catch (e) { console.error(e); } }); }
    };
  }
  // 값을 돌려주는 함수를 콜백/프로미스 양쪽 방식으로 부를 수 있게 감싼다
  function cb(args, fn) {
    var last = args[args.length - 1];
    if (typeof last === "function") {
      var v, err = null;
      try { v = fn(); } catch (e) { err = e; }
      setTimeout(function () { if (err) console.error(err); else last(v); }, 0);
      return undefined;
    }
    try { return Promise.resolve(fn()); } catch (e) { return Promise.reject(e); }
  }
  // 지원하지 않는 API: 호출해도 오류 없이 조용히 넘어간다
  function stub() {
    var f = function () {
      var c = arguments[arguments.length - 1];
      if (typeof c === "function") { setTimeout(function () { try { c(); } catch (e) {} }, 0); return undefined; }
      return Promise.resolve();
    };
    return new Proxy(f, {
      get: function (t, k) {
        if (k === "then" || typeof k === "symbol") return undefined;
        if (k === "addListener" || k === "removeListener") return function () {};
        if (k === "hasListener" || k === "hasListeners") return function () { return false; };
        return stub();
      }
    });
  }
  function ns(o) {
    return new Proxy(o, {
      get: function (t, k) {
        if (k in t) return t[k];
        if (typeof k === "symbol" || k === "then") return undefined;
        return stub();
      }
    });
  }

  var onChanged = ev();
  function fire(ch, area) { onChanged._d([ch, area]); }
  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }
  function area(name) {
    function load() { try { return JSON.parse(B.sget(ID, name, T) || "{}"); } catch (e) { return {}; } }
    function save(o) { B.sset(ID, name, JSON.stringify(o), T); }
    return {
      get: function (keys) {
        return cb(arguments, function () {
          var o = load();
          if (keys == null || typeof keys === "function") return o;
          var r = {};
          if (typeof keys === "string") keys = [keys];
          if (Array.isArray(keys)) keys.forEach(function (k) { if (k in o) r[k] = o[k]; });
          else if (typeof keys === "object") Object.keys(keys).forEach(function (k) { r[k] = (k in o) ? o[k] : keys[k]; });
          return r;
        });
      },
      set: function (items) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(items || {}).forEach(function (k) {
            var nv = clone(items[k]);
            ch[k] = { oldValue: o[k], newValue: nv };
            o[k] = nv;
          });
          save(o);
          fire(ch, name);
        });
      },
      remove: function (keys) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          (Array.isArray(keys) ? keys : [keys]).forEach(function (k) {
            if (typeof k === "string" && k in o) { ch[k] = { oldValue: o[k] }; delete o[k]; }
          });
          save(o);
          fire(ch, name);
        });
      },
      clear: function () {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(o).forEach(function (k) { ch[k] = { oldValue: o[k] }; });
          save({});
          fire(ch, name);
        });
      },
      getBytesInUse: function () { return cb(arguments, function () { return JSON.stringify(load()).length; }); },
      onChanged: onChanged
    };
  }

  var runtime = ns({
    id: ID,
    getURL: function (p) { return BASE + String(p).replace(/^\//, ""); },
    getManifest: function () { return clone(M); },
    getPlatformInfo: function () { return cb(arguments, function () { return { os: "android", arch: "arm64", nacl_arch: "arm" }; }); },
    sendMessage: function () { var a = [].slice.call(arguments); return cb(a, function () { return undefined; }); },
    connect: function () {
      return { name: "", postMessage: function () {}, disconnect: function () {}, onMessage: ev(), onDisconnect: ev() };
    },
    openOptionsPage: function () {
      var o = (M.options_ui && M.options_ui.page) || M.options_page;
      if (o) window.open(BASE + o, "_blank");
      return cb(arguments, function () {});
    },
    reload: function () {},
    onMessage: ev(), onConnect: ev(), onInstalled: ev(), onStartup: ev(), onSuspend: ev(), onUpdateAvailable: ev()
  });

  var C = {
    runtime: runtime,
    extension: ns({
      getURL: runtime.getURL, inIncognitoContext: false,
      getBackgroundPage: function () { return null; }, getViews: function () { return []; },
      isAllowedIncognitoAccess: function () { return cb(arguments, function () { return false; }); }
    }),
    storage: ns({
      local: area("local"), sync: area("sync"), session: area("session"), managed: area("managed"),
      onChanged: onChanged
    }),
    i18n: ns({
      getMessage: function (n, s) {
        var m = MSG[String(n).toLowerCase()];
        if (m == null) return "";
        if (s == null) s = []; else if (!Array.isArray(s)) s = [s];
        return m.replace(/\$(\d)/g, function (_, i) { var v = s[+i - 1]; return v == null ? "" : v; }).replace(/\$\$/g, "$");
      },
      getUILanguage: function () { return navigator.language; },
      getAcceptLanguages: function () { return cb(arguments, function () { return (navigator.languages || [navigator.language]).slice(); }); }
    }),
    tabs: ns({
      create: function (o) { try { window.open(o && o.url, "_blank"); } catch (e) {} return cb(arguments, function () {}); },
      query: function () { return cb(arguments, function () { return []; }); },
      getCurrent: function () { return cb(arguments, function () { return undefined; }); },
      sendMessage: function () { return cb([].slice.call(arguments), function () {}); }
    }),
    permissions: ns({
      contains: function () { return cb(arguments, function () { return true; }); },
      request: function () { return cb(arguments, function () { return true; }); },
      getAll: function () { return cb(arguments, function () { return { permissions: M.permissions || [], origins: [] }; }); }
    })
  };
  return new Proxy(C, {
    get: function (t, k) {
      if (k in t) return t[k];
      if (typeof k === "symbol" || k === "then") return undefined;
      return ns({});
    }
  });
}
