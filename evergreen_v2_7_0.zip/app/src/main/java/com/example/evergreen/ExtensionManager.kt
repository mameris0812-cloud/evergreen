package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.Collections
import java.util.Locale
import java.util.UUID
import java.util.WeakHashMap
import java.util.zip.ZipInputStream

/**
 * 크롬 확장 프로그램 지원.
 *
 * 안드로이드 WebView 는 크롬 확장을 그대로 돌릴 수 없어서, 확장 프로그램의 '콘텐츠 스크립트'(웹페이지에 끼워 넣는
 * JS/CSS)를 매니페스트의 주소 조건(matches)에 맞는 페이지에 직접 넣어 주고, 자주 쓰는 chrome.* API
 * (runtime · storage · i18n · tabs 일부)를 흉내 내어 제공한다.
 * 백그라운드(service worker) · webRequest · 팝업 ↔ 페이지 메시지 같은 기능은 지원하지 않는다.
 */
class ExtensionManager(private val ctx: Context) {

    class Entry(
        val matches: List<String>,
        val excludes: List<String>,
        val js: List<String>,
        val css: List<String>,
        val runAt: String,
        val allFrames: Boolean
    )

    class Ext(
        val id: String,
        val name: String,
        val version: String,
        val description: String,
        val manifestVersion: Int,
        val dir: File,
        val manifest: JSONObject,
        val entries: List<Entry>,
        val hasBackground: Boolean,
        val options: String?,
        val popup: String?,
        val icon: String?,
        val messages: Map<String, String>,
        var enabled: Boolean
    )

    companion object {
        const val HOST = "ext.evergreen.invalid"
        private const val MAX_ZIP = 80L * 1024 * 1024
        private const val MAX_UNPACKED = 150L * 1024 * 1024
        private const val MAX_AREA_JSON = 5_000_000
    }

    private val root = File(ctx.filesDir, "extensions")
    private val dataDir = File(root, ".data")
    private val indexFile = File(root, "index.json")
    private val lock = Any()
    private var exts: List<Ext> = emptyList()
    private val scriptCache = HashMap<String, String>()
    private val shim: String by lazy {
        ctx.assets.open("ext_shim.js").use { String(it.readBytes(), Charsets.UTF_8) }
    }

    // 페이지가 마음대로 확장 저장소를 읽지 못하게, 매 실행마다 새로 만드는 이름과 열쇠
    private val bridgeName = "EvExt" + UUID.randomUUID().toString().replace("-", "").take(12)
    private val token = UUID.randomUUID().toString().replace("-", "")
    private val session = HashMap<String, String>()
    private val handlers = Collections.synchronizedMap(WeakHashMap<WebView, MutableList<ScriptHandler>>())

    val supported: Boolean by lazy { WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) }

    init {
        root.mkdirs()
        reload()
    }

    // ───────────────────────── 목록 ─────────────────────────

    fun list(): List<Ext> = synchronized(lock) { exts }

    private fun disabledIds(): MutableSet<String> {
        val set = HashSet<String>()
        try {
            if (indexFile.exists()) {
                val a = JSONObject(indexFile.readText()).optJSONArray("disabled")
                if (a != null) for (i in 0 until a.length()) set.add(a.getString(i))
            }
        } catch (e: Exception) { /* 읽지 못하면 모두 켜짐 */ }
        return set
    }

    private fun saveIndex() {
        val dis = JSONArray()
        exts.filter { !it.enabled }.forEach { dis.put(it.id) }
        try { indexFile.writeText(JSONObject().put("disabled", dis).toString()) } catch (e: Exception) { }
    }

    fun reload() = synchronized(lock) {
        scriptCache.clear()
        val dis = disabledIds()
        val out = ArrayList<Ext>()
        root.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name }?.forEach { d ->
            try { parse(d, d.name)?.let { it.enabled = it.id !in dis; out.add(it) } } catch (e: Exception) { }
        }
        exts = out.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    fun setEnabled(id: String, on: Boolean) = synchronized(lock) {
        exts.find { it.id == id }?.enabled = on
        scriptCache.keys.removeAll { it.startsWith("$id:") }
        saveIndex()
    }

    fun remove(id: String) = synchronized(lock) {
        File(root, id).deleteRecursively()
        File(dataDir, id).deleteRecursively()
        exts = exts.filter { it.id != id }
        scriptCache.keys.removeAll { it.startsWith("$id:") }
        saveIndex()
    }

    // ───────────────────────── 설치 ─────────────────────────

    /** .zip 또는 .crx 를 풀어 설치한다. 성공하면 이름을, 실패하면 예외(메시지는 사용자에게 보여 줄 말)를 던진다. */
    fun install(uri: Uri): Ext {
        val raw = ByteArrayOutputStream()
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                raw.write(buf, 0, n)
                if (raw.size() > MAX_ZIP) throw IllegalStateException("파일이 너무 커요 (80MB 이하만 가능)")
            }
        } ?: throw IllegalStateException("파일을 열 수 없어요")
        val bytes = raw.toByteArray()
        if (bytes.size < 4) throw IllegalStateException("올바른 확장 프로그램 파일이 아니에요")

        // crx 머리글 건너뛰기
        var start = 0
        if (bytes[0] == 'C'.code.toByte() && bytes[1] == 'r'.code.toByte() && bytes[2] == '2'.code.toByte() && bytes[3] == '4'.code.toByte()) {
            fun le(o: Int) = (bytes[o].toInt() and 0xFF) or ((bytes[o + 1].toInt() and 0xFF) shl 8) or
                ((bytes[o + 2].toInt() and 0xFF) shl 16) or ((bytes[o + 3].toInt() and 0xFF) shl 24)
            start = when (le(4)) {
                3 -> 12 + le(8)
                2 -> 16 + le(8) + le(12)
                else -> throw IllegalStateException("지원하지 않는 crx 형식이에요")
            }
            if (start <= 0 || start >= bytes.size) throw IllegalStateException("crx 파일이 손상됐어요")
        }

        val tmp = File(root, ".tmp_" + UUID.randomUUID().toString().take(8))
        tmp.mkdirs()
        try {
            var total = 0L
            val tmpCanon = tmp.canonicalPath
            ZipInputStream(ByteArrayInputStream(bytes, start, bytes.size - start)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val name = e.name.replace('\\', '/')
                    if (name.startsWith("__MACOSX/") || name.isEmpty()) continue
                    val f = File(tmp, name)
                    if (!f.canonicalPath.startsWith(tmpCanon + File.separator)) continue // 폴더 밖으로 나가는 경로 차단
                    if (e.isDirectory) { f.mkdirs(); continue }
                    f.parentFile?.mkdirs()
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_UNPACKED) throw IllegalStateException("압축을 풀면 너무 커요")
                            out.write(buf, 0, n)
                        }
                    }
                }
            }
            // manifest.json 이 있는 가장 얕은 폴더를 확장 프로그램 폴더로 본다
            val manifest = tmp.walkTopDown().filter { it.isFile && it.name == "manifest.json" }
                .minByOrNull { it.relativeTo(tmp).path.count { c -> c == File.separatorChar } }
                ?: throw IllegalStateException("manifest.json 이 없어요 (확장 프로그램 zip/crx 가 아니에요)")
            val base = manifest.parentFile!!
            val mj = readJson(manifest)
            val name0 = mj.optString("name")
            if (name0.isBlank() || mj.optString("version").isBlank()) throw IllegalStateException("manifest.json 에 name/version 이 없어요")
            val id = makeId(mj, name0)
            val dest = File(root, id)
            synchronized(lock) {
                dest.deleteRecursively()
                if (!base.renameTo(dest)) {
                    base.copyRecursively(dest, true)
                }
            }
            val ext = parse(dest, id) ?: throw IllegalStateException("manifest.json 을 읽지 못했어요")
            synchronized(lock) {
                ext.enabled = true
                exts = (exts.filter { it.id != id } + ext).sortedBy { it.name.lowercase(Locale.ROOT) }
                scriptCache.keys.removeAll { it.startsWith("$id:") }
                saveIndex()
            }
            return ext
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun readJson(f: File): JSONObject {
        var s = f.readText(Charsets.UTF_8)
        if (s.startsWith("\uFEFF")) s = s.substring(1)
        return JSONObject(s)
    }

    private fun makeId(mj: JSONObject, name: String): String {
        val seed = mj.optString("key").ifEmpty { "evergreen:$name" }
        val d = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        val sb = StringBuilder()
        for (i in 0 until 16) {
            val b = d[i].toInt() and 0xFF
            sb.append(('a' + (b shr 4))).append(('a' + (b and 0x0F)))
        }
        return sb.toString()
    }

    // ───────────────────────── 매니페스트 읽기 ─────────────────────────

    private fun loadMessages(dir: File, mj: JSONObject): Map<String, String> {
        val loc = File(dir, "_locales")
        if (!loc.isDirectory) return emptyMap()
        val names = loc.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: return emptyMap()
        val lang = Locale.getDefault().language
        val def = mj.optString("default_locale")
        val pick = listOf(Locale.getDefault().toString(), lang, def, "en", "en_US", "en_GB")
            .firstOrNull { it.isNotEmpty() && it in names } ?: names.firstOrNull() ?: return emptyMap()
        val f = File(loc, "$pick/messages.json")
        if (!f.exists()) return emptyMap()
        val out = HashMap<String, String>()
        try {
            val o = readJson(f)
            for (k in o.keys()) {
                val item = o.optJSONObject(k) ?: continue
                var msg = item.optString("message")
                item.optJSONObject("placeholders")?.let { ph ->
                    for (pk in ph.keys()) {
                        val c = ph.optJSONObject(pk)?.optString("content") ?: continue
                        msg = msg.replace("\$$pk\$", c, ignoreCase = true)
                    }
                }
                out[k.lowercase(Locale.ROOT)] = msg
            }
        } catch (e: Exception) { }
        return out
    }

    private fun parse(dir: File, id: String): Ext? {
        val mf = File(dir, "manifest.json")
        if (!mf.exists()) return null
        val mj = readJson(mf)
        val msgs = loadMessages(dir, mj)
        fun loc(s: String): String = Regex("__MSG_([A-Za-z0-9_@]+)__").replace(s) { m ->
            msgs[m.groupValues[1].lowercase(Locale.ROOT)] ?: m.value
        }
        val entries = ArrayList<Entry>()
        val cs = mj.optJSONArray("content_scripts")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.optJSONObject(i) ?: continue
            fun strs(k: String): List<String> {
                val a = c.optJSONArray(k) ?: return emptyList()
                return (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
            }
            val m = strs("matches")
            if (m.isEmpty()) continue
            entries.add(
                Entry(
                    m, strs("exclude_matches"), strs("js"), strs("css"),
                    c.optString("run_at", "document_idle"), c.optBoolean("all_frames", false)
                )
            )
        }
        val bg = mj.optJSONObject("background")
        val action = mj.optJSONObject("action") ?: mj.optJSONObject("browser_action") ?: mj.optJSONObject("page_action")
        val optUi = mj.optJSONObject("options_ui")?.optString("page")?.takeIf { it.isNotEmpty() }
        val options = optUi ?: mj.optString("options_page").takeIf { it.isNotEmpty() }
        val popup = action?.optString("default_popup")?.takeIf { it.isNotEmpty() }
        var icon: String? = null
        fun bestIcon(o: JSONObject?): String? {
            o ?: return null
            val best = o.keys().asSequence().mapNotNull { it.toIntOrNull() }.maxOrNull() ?: return null
            return o.optString(best.toString()).takeIf { it.isNotEmpty() }
        }
        icon = bestIcon(mj.optJSONObject("icons"))
        if (icon == null) {
            val di = action?.opt("default_icon")
            icon = when (di) {
                is String -> di
                is JSONObject -> bestIcon(di)
                else -> null
            }
        }
        return Ext(
            id = id,
            name = loc(mj.optString("name")),
            version = mj.optString("version"),
            description = loc(mj.optString("description")),
            manifestVersion = mj.optInt("manifest_version", 2),
            dir = dir,
            manifest = mj,
            entries = entries,
            hasBackground = bg != null && (bg.has("service_worker") || bg.has("scripts") || bg.has("page")),
            options = options,
            popup = popup,
            icon = icon,
            messages = msgs,
            enabled = true
        )
    }

    fun iconBitmap(e: Ext): Bitmap? {
        val p = e.icon ?: return null
        return try {
            val f = File(e.dir, p.removePrefix("/"))
            if (f.canonicalPath.startsWith(e.dir.canonicalPath) && f.exists()) BitmapFactory.decodeFile(f.path) else null
        } catch (ex: Exception) { null }
    }

    /** 새 탭에서 열 수 있는 확장 프로그램 내부 페이지 주소 (옵션 · 팝업) */
    fun pageUrl(e: Ext, path: String): String = "https://$HOST/${e.id}/" + path.removePrefix("/")

    // ───────────────────────── 웹페이지에 넣기 ─────────────────────────

    private fun esc(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in ".+?^$()|[]{}\\") sb.append('\\')
            sb.append(c)
        }
        return sb.toString()
    }

    /** 크롬의 match pattern 을 JS 정규식 문자열로 바꾼다 (잘못된 패턴이면 null) */
    private fun patternToRegex(p: String): String? {
        if (p == "<all_urls>") return "^https?://.*$"
        val m = Regex("^(\\*|https?|file|ftp)://([^/]*)(/.*)$").matchEntire(p) ?: return null
        val scheme = m.groupValues[1]
        val host = m.groupValues[2]
        val path = m.groupValues[3]
        val s = if (scheme == "*") "https?" else scheme
        val h = when {
            scheme == "file" -> esc(host)
            host == "*" -> "[^/:]+"
            host.startsWith("*.") -> "([^/:]+\\.)?" + esc(host.substring(2))
            else -> esc(host)
        }
        val port = if (scheme == "file") "" else "(:\\d+)?"
        val pa = path.split("*").joinToString(".*") { esc(it) }
        return "^$s://$h$port$pa$"
    }

    private fun readText(e: Ext, rel: String): String? {
        return try {
            val f = File(e.dir, rel.removePrefix("/"))
            if (!f.canonicalPath.startsWith(e.dir.canonicalPath + File.separator) || !f.isFile) null
            else f.readText(Charsets.UTF_8)
        } catch (ex: Exception) { null }
    }

    private fun msgsJson(e: Ext): String {
        val o = JSONObject()
        e.messages.forEach { (k, v) -> o.put(k, v) }
        return o.toString()
    }

    private fun makeCall(e: Ext): String =
        "__evxMake(${JSONObject.quote(e.id)},${e.manifest},${msgsJson(e)},window[${JSONObject.quote(bridgeName)}],${JSONObject.quote(token)})"

    private fun buildScript(e: Ext, idx: Int): String? {
        val en = e.entries[idx]
        val key = "${e.id}:$idx"
        synchronized(lock) { scriptCache[key]?.let { return it } }
        val inc = en.matches.mapNotNull { patternToRegex(it) }
        if (inc.isEmpty()) return null
        val exc = en.excludes.mapNotNull { patternToRegex(it) }
        val js = StringBuilder()
        for (f in en.js) readText(e, f)?.let { js.append(it).append("\n;\n") }
        val css = StringBuilder()
        for (f in en.css) readText(e, f)?.let { css.append(it).append("\n") }
        if (js.isEmpty() && css.isEmpty()) return null
        val sb = StringBuilder()
        sb.append("(function(){\n")
        sb.append("if(location.hostname===${JSONObject.quote(HOST)})return;\n")
        sb.append("var __h=location.href.split('#')[0];\n")
        sb.append("var __i=").append(JSONArray(inc)).append(",__x=").append(JSONArray(exc)).append(";\n")
        sb.append("function __t(a){for(var i=0;i<a.length;i++){try{if(new RegExp(a[i]).test(__h))return true}catch(e){}}return false}\n")
        sb.append("if(!__t(__i)||__t(__x))return;\n")
        if (!en.allFrames) sb.append("if(window.top!==window)return;\n")
        sb.append("var __k=${JSONObject.quote("__evx_$key")};\n")
        sb.append("if(window[__k])return;try{Object.defineProperty(window,__k,{value:1})}catch(e){window[__k]=1}\n")
        sb.append(shim).append("\n")
        sb.append("var chrome=").append(makeCall(e)).append(",browser=chrome;\n")
        if (css.isNotEmpty()) {
            sb.append("function __css(){var s=document.createElement('style');s.textContent=")
                .append(JSONObject.quote(css.toString()))
                .append(";(document.head||document.documentElement).appendChild(s)}\n")
            sb.append("if(document.documentElement)__css();else{var __mo=new MutationObserver(function(){if(document.documentElement){__mo.disconnect();__css()}});__mo.observe(document,{childList:true})}\n")
        }
        if (js.isNotEmpty()) {
            sb.append("function __run(){try{(function(chrome,browser){\n").append(js).append("\n})(chrome,browser)}catch(e){console.error(${JSONObject.quote("[Evergreen 확장] " + e.name)},e)}}\n")
            when (en.runAt) {
                "document_start" -> sb.append("__run();\n")
                "document_end" -> sb.append("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',__run,{once:true});else __run();\n")
                else -> sb.append("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(__run,0)},{once:true});else setTimeout(__run,0);\n")
            }
        }
        sb.append("})();")
        val out = sb.toString()
        synchronized(lock) { scriptCache[key] = out }
        return out
    }

    inner class Bridge {
        @JavascriptInterface
        fun sget(id: String, area: String, t: String): String {
            if (t != token) return "{}"
            return readArea(id, area)
        }

        @JavascriptInterface
        fun sset(id: String, area: String, json: String, t: String) {
            if (t != token || json.length > MAX_AREA_JSON) return
            writeArea(id, area, json)
        }
    }

    private val bridge = Bridge()

    private fun areaFile(id: String, area: String): File? {
        if (id.isEmpty() || !id.all { it in 'a'..'z' }) return null
        if (area !in listOf("local", "sync", "managed")) return null
        return File(dataDir, "$id/$area.json")
    }

    private fun readArea(id: String, area: String): String {
        if (area == "session") return synchronized(session) { session["$id:$area"] ?: "{}" }
        val f = areaFile(id, area) ?: return "{}"
        return try { if (f.exists()) f.readText() else "{}" } catch (e: Exception) { "{}" }
    }

    private fun writeArea(id: String, area: String, json: String) {
        if (area == "session") { synchronized(session) { session["$id:$area"] = json }; return }
        val f = areaFile(id, area) ?: return
        try {
            f.parentFile?.mkdirs()
            f.writeText(json)
        } catch (e: Exception) { }
    }

    /** 웹뷰 하나에 확장 프로그램을 연결한다. 이미 연결돼 있으면 먼저 떼고 다시 붙인다. */
    fun attach(wv: WebView, incognito: Boolean) {
        detach(wv)
        try { wv.addJavascriptInterface(bridge, bridgeName) } catch (e: Exception) { }
        if (incognito || !supported) return // 크롬처럼 시크릿 탭에서는 확장 프로그램을 쓰지 않는다
        val hs = ArrayList<ScriptHandler>()
        for (e in list()) {
            if (!e.enabled) continue
            for (i in e.entries.indices) {
                val s = buildScript(e, i) ?: continue
                try { hs.add(WebViewCompat.addDocumentStartJavaScript(wv, s, setOf("*"))) } catch (ex: Exception) { }
            }
        }
        if (hs.isNotEmpty()) handlers[wv] = hs
    }

    fun detach(wv: WebView) {
        handlers.remove(wv)?.forEach { try { it.remove() } catch (e: Exception) { } }
    }

    // ───────────────────────── 확장 프로그램 파일 제공 ─────────────────────────

    /** https://ext.evergreen.invalid/<id>/<경로> 요청에 확장 프로그램 안의 파일을 돌려준다 */
    fun serve(uri: Uri): WebResourceResponse? {
        val segs = uri.pathSegments
        if (segs.isEmpty()) return notFound()
        val e = list().find { it.id == segs[0] } ?: return notFound()
        val rel = segs.drop(1).joinToString("/")
        val f = File(e.dir, rel)
        try {
            if (!f.canonicalPath.startsWith(e.dir.canonicalPath + File.separator) || !f.isFile) return notFound()
        } catch (ex: Exception) { return notFound() }
        val ext = f.extension.lowercase(Locale.ROOT)
        val mime = when (ext) {
            "js", "mjs" -> "text/javascript"
            "json" -> "application/json"
            "css" -> "text/css"
            "html", "htm" -> "text/html"
            "svg" -> "image/svg+xml"
            "woff2" -> "font/woff2"
            "woff" -> "font/woff"
            "wasm" -> "application/wasm"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
        val headers = hashMapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache")
        val stream: InputStream = if (mime == "text/html") {
            // 옵션/팝업 페이지: 맨 앞에 chrome.* 를 넣어 준다
            val html = f.readText(Charsets.UTF_8)
            val inject = "<script>$shim\nwindow.chrome=window.browser=${makeCall(e)};</script>"
            val at = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
            val merged = if (at != null) html.substring(0, at.range.last + 1) + inject + html.substring(at.range.last + 1) else inject + html
            ByteArrayInputStream(merged.toByteArray(Charsets.UTF_8))
        } else f.inputStream()
        return WebResourceResponse(mime, if (mime.startsWith("text/") || mime == "application/json") "utf-8" else null, 200, "OK", headers, stream)
    }

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", hashMapOf("Access-Control-Allow-Origin" to "*"),
        ByteArrayInputStream(ByteArray(0))
    )
}
