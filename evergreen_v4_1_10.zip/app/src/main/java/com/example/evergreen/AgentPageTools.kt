package com.example.evergreen

import org.json.JSONObject

/**
 * 에이전트: 웹 페이지 안 조작 도구.
 * - 읽기(자동): read_page(페이지 글 + 누르거나 쓸 수 있는 요소 목록), scroll_page(스크롤)
 * - 변경(요청당 한 번 확인): click_element(요소 누르기), fill_field(입력칸 쓰기 · 선택 · 체크)
 * - 위험(매번 확인): 결제 · 삭제 · 전송 · 동의 같은 버튼이나 제출 버튼, 파일 내려받기 링크 누르기, 입력 뒤 Enter 로 제출
 *
 * 요소는 read_page 가 번호(element)를 붙여 주고, 그 번호는 마지막으로 읽은 결과에서만 유효하다.
 * 페이지 안 스크립트는 [AgentHost.pageScript] 로만 돌린다. 지금 보는 탭에서만 동작한다.
 * 비밀번호 · 카드번호 · 인증번호 칸은 값을 읽지도 쓰지도 않는다 (사용자가 직접 입력).
 * 가짜(스크립트) 클릭이라 사용자 제스처가 필요한 동작(팝업 창 · 파일 선택 · 전체 화면)은 사이트가 막을 수 있다.
 */
object AgentPageTools {
    fun build(): List<AgentTool> = listOf(readPage(), scrollPage(), clickElement(), fillField())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    /** 누르기 전에 사용자에게 매번 물어야 하는 버튼 글자 (되돌리기 어려운 동작) */
    private val RISKY = Regex(
        "결제|구매|주문|송금|이체|입금|삭제|제거|탈퇴|해지|로그아웃|전송|보내기|제출|가입|동의|확인|승인|게시|발행|신고|초기화|" +
            "\\b(buy|purchase|pay|payment|checkout|order|delete|remove|erase|send|submit|confirm|transfer|withdraw|unsubscribe|" +
            "sign ?out|log ?out|post|publish|accept|agree|subscribe|donate|install)\\b",
        RegexOption.IGNORE_CASE
    )

    // ───────────────────────── 페이지 안에서 돌리는 스크립트 ─────────────────────────

    /** 모든 스크립트가 같이 쓰는 도우미 함수들. 요소 목록은 페이지 안 `window.__evgS` 에 둔다 (나열되지 않게 숨김) */
    private const val PRE = """
var S=window.__evgS;
if(!S){S={els:[null]};try{Object.defineProperty(window,'__evgS',{value:S,configurable:true,writable:true,enumerable:false});}catch(e){window.__evgS=S;}}
function fail(m,x){var o={ok:false,error:m};if(x){for(var k in x)o[k]=x[k];}return JSON.stringify(o);}
function cut(s,n){s=(s||'').replace(/\s+/g,' ').trim();return s.length>n?s.slice(0,n)+'…':s;}
function isVis(el){var r=el.getBoundingClientRect();if(r.width<1||r.height<1)return false;var cs=getComputedStyle(el);return !(cs.visibility==='hidden'||cs.display==='none'||parseFloat(cs.opacity)===0);}
function inView(el){var r=el.getBoundingClientRect();return r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;}
function secret(el){
  if(el.tagName!=='INPUT'&&el.tagName!=='TEXTAREA')return false;
  var t=(el.type||'').toLowerCase();
  if(t==='password')return true;
  var ac=(el.getAttribute('autocomplete')||'').toLowerCase();
  if(/cc-|password|one-time-code/.test(ac))return true;
  var nm=((el.name||'')+' '+(el.id||'')).toLowerCase();
  return /passw|pwd|cvc|cvv|card.?num|cardnum|ssn|otp|\bpin\b|주민/.test(nm);
}
function kindOf(el){
  var tg=el.tagName;
  if(tg==='A')return 'link';
  if(tg==='SELECT')return 'select';
  if(tg==='TEXTAREA')return 'textarea';
  if(tg==='INPUT'){
    var t=(el.type||'text').toLowerCase();
    if(t==='checkbox')return 'checkbox';
    if(t==='radio')return 'radio';
    if(t==='file')return 'file';
    if(t==='submit'||t==='button'||t==='reset'||t==='image')return 'button';
    if(t==='range')return 'slider';
    return 'text';
  }
  if(tg==='BUTTON'||tg==='SUMMARY')return 'button';
  if(el.isContentEditable)return 'text';
  var r=(el.getAttribute('role')||'').toLowerCase();
  if(r==='link')return 'link';
  if(r==='checkbox'||r==='switch')return 'checkbox';
  return 'button';
}
function label(el){
  var t=el.getAttribute('aria-label')||'';
  if(!t&&el.labels&&el.labels.length)t=el.labels[0].innerText||el.labels[0].textContent||'';
  var tg=el.tagName;
  var isIn=(tg==='INPUT'||tg==='TEXTAREA'||tg==='SELECT');
  if(!t&&isIn)t=el.getAttribute('placeholder')||'';
  if(!t&&!isIn)t=el.innerText||el.textContent||'';
  if(!t)t=el.getAttribute('title')||el.getAttribute('alt')||'';
  if(!t&&el.querySelector){var im=el.querySelector('img[alt]');if(im)t=im.getAttribute('alt')||'';}
  if(!t&&tg==='INPUT'){var ty=(el.type||'').toLowerCase();if(ty==='submit'||ty==='button'||ty==='reset')t=el.value||'';}
  if(!t)t=el.getAttribute('name')||'';
  return cut(t,60);
}
function isSubmit(el){
  var tg=el.tagName;
  if(tg==='INPUT'){var t=(el.type||'').toLowerCase();return t==='submit'||t==='image';}
  if(tg==='BUTTON')return !!el.form&&((el.getAttribute('type')||'submit').toLowerCase()==='submit');
  return false;
}
function hrefOf(el){
  var h=el.href||'';
  try{var u=new URL(h,location.href);return u.origin===location.origin?cut(u.pathname+u.search,90):cut(u.origin+u.pathname+u.search,100);}catch(e){return cut(h,100);}
}
function pick(id){var el=S.els[id];return (el&&el.isConnected)?el:null;}
var GONE='그 요소를 찾을 수 없어요. 페이지가 바뀌었을 수 있으니 read_page 로 다시 읽어 주세요';
"""

    /** 페이지 글 + 요소 목록. __SCOPE__ = viewport | all, __TEXT__ = true | false */
    private const val READ = """
var scope='__SCOPE__',withText=__TEXT__;
var sel='a[href],button,input:not([type=hidden]),textarea,select,summary,[role=button],[role=link],[role=checkbox],[role=switch],[role=tab],[role=menuitem],[role=option],[contenteditable=""],[contenteditable="true"],[onclick]';
var found=[];
function collect(root){var l=root.querySelectorAll(sel);for(var i=0;i<l.length;i++)found.push(l[i]);}
collect(document);
var every=document.querySelectorAll('*');
if(every.length<6000){for(var q=0;q<every.length;q++){if(every[q].shadowRoot)collect(every[q].shadowRoot);}}
var seen=new Set(),inc=new Set(),list=[];
for(var i=0;i<found.length;i++){
  var el=found[i];
  if(seen.has(el))continue;
  seen.add(el);
  var tg=el.tagName;
  if(tg==='BODY'||tg==='HTML')continue;
  if(!isVis(el))continue;
  var isIn=(tg==='INPUT'||tg==='TEXTAREA'||tg==='SELECT');
  if(!isIn){
    var up=el.parentElement&&el.parentElement.closest('a[href],button,[role=button],[role=link]');
    if(up&&up!==el&&inc.has(up))continue;
    var rr=el.getBoundingClientRect();
    if(tg!=='A'&&tg!=='BUTTON'&&rr.width*rr.height>0.7*innerWidth*innerHeight)continue;
  }
  inc.add(el);
  list.push(el);
}
S.els=[null];
var out=[],total=list.length;
for(var j=0;j<list.length;j++){
  var e=list[j];
  if(scope==='viewport'&&!inView(e))continue;
  if(out.length>=60)break;
  S.els.push(e);
  var k=kindOf(e);
  var o={element:S.els.length-1,kind:k,label:label(e)};
  if(k==='link'){o.href=hrefOf(e);if(e.target==='_blank')o.new_tab=true;}
  if(k==='text'||k==='textarea'||k==='slider'){
    if(secret(e))o.secret=true;
    else{var v=(e.value!==undefined)?e.value:e.textContent;if(v)o.value=cut(v,60);}
  }
  if(k==='checkbox'||k==='radio'){o.checked=(e.checked!==undefined)?!!e.checked:(e.getAttribute('aria-checked')==='true');}
  if(k==='select'){
    var op=[];
    for(var m=0;m<e.options.length&&m<10;m++)op.push(cut(e.options[m].text,30)+(e.options[m].selected?' *':''));
    o.options=op;
    if(e.options.length>10)o.option_count=e.options.length;
  }
  if(isSubmit(e))o.submit=true;
  if(e.disabled)o.disabled=true;
  if(scope==='all'&&!inView(e))o.offscreen=true;
  out.push(o);
}
var se=document.scrollingElement||document.documentElement;
var res={url:cut(location.href,300),title:cut(document.title,100),loading:document.readyState!=='complete',
  scroll:{y:Math.round(window.pageYOffset),max:Math.max(0,Math.round(se.scrollHeight-innerHeight)),view:innerHeight},
  shown:out.length,total:total,elements:out};
var dlg=document.querySelector('[role=dialog],[role=alertdialog],[aria-modal=true],dialog[open]');
if(dlg&&isVis(dlg))res.popup=cut(dlg.innerText,120);
if(withText)res.text=cut(document.body?document.body.innerText:'',2000);
var nf=document.querySelectorAll('iframe').length;
if(nf)res.iframes=nf;
return JSON.stringify(res);
"""

    /** 요소 한 개의 이름 · 종류 · 위험 신호만 알아 온다 (확인 카드와 위험도 판단에 쓴다). __ID__ = 요소 번호 */
    private const val INFO = """
var el=pick(__ID__);
if(!el)return fail(GONE);
var h=(el.tagName==='A')?(el.href||''):'';
var dl=el.hasAttribute('download')||/\.(apk|exe|msi|dmg|zip|rar|7z|jar)(?![a-z0-9])/i.test(h.split(/[?#]/)[0]);
return JSON.stringify({ok:true,label:label(el),kind:kindOf(el),submit:isSubmit(el),secret:secret(el),download:dl,href:cut(h,120)});
"""

    /** 요소 누르기. __ID__ = 요소 번호 */
    private const val CLICK = """
var el=pick(__ID__);
if(!el)return fail(GONE);
if(el.disabled||el.getAttribute('aria-disabled')==='true')return fail('비활성화된 요소라 누를 수 없어요');
if(el.tagName==='A'){
  var h=el.href||'';
  if(/^(javascript|intent|mailto|tel|sms|market|file|content|data|blob):/i.test(h))return fail('앱을 부르거나 스크립트를 실행하는 링크는 누르지 않아요');
  if(el.target==='_blank')return fail('새 탭으로 열리는 링크예요. open_tab 으로 이 주소를 열어 주세요',{href:cut(h,300)});
}
el.scrollIntoView({block:'center',inline:'center'});
var r=el.getBoundingClientRect();
var x=Math.min(innerWidth-1,Math.max(0,r.left+r.width/2)),y=Math.min(innerHeight-1,Math.max(0,r.top+r.height/2));
var top=document.elementFromPoint(x,y);
if(top&&top!==el&&!el.contains(top)&&!top.contains(el)){
  var rt=el.getRootNode&&el.getRootNode();
  if(!(rt&&rt.host&&(rt.host===top||rt.host.contains(top)))){
    return fail('다른 요소가 가리고 있어요: '+(label(top)||top.tagName.toLowerCase())+' (팝업이나 광고를 먼저 닫아야 할 수 있어요)');
  }
}
var base={bubbles:true,cancelable:true,composed:true,view:window,clientX:x,clientY:y,button:0};
function send(type,C,buttons){try{var o={};for(var k in base)o[k]=base[k];o.buttons=buttons;el.dispatchEvent(new C(type,o));}catch(e){}}
if(window.PointerEvent)send('pointerdown',PointerEvent,1);
send('mousedown',MouseEvent,1);
if(window.PointerEvent)send('pointerup',PointerEvent,0);
send('mouseup',MouseEvent,0);
el.click();
return JSON.stringify({ok:true,label:label(el),kind:kindOf(el)});
"""

    /** 입력칸 쓰기 · 선택 상자 고르기 · 체크 켜고 끄기. __ID__ = 요소 번호, __VAL__ = 값(JS 글자), __SUBMIT__ = true | false */
    private const val FILL = """
var el=pick(__ID__),V=String(__VAL__),submit=__SUBMIT__;
if(!el)return fail(GONE);
if(el.disabled||el.readOnly)return fail('쓸 수 없는 칸이에요 (비활성화 또는 읽기 전용)');
if(secret(el))return fail('비밀번호 · 카드번호 · 인증번호 같은 칸은 안전을 위해 직접 입력해 주세요');
var k=kindOf(el),tg=el.tagName;
if(k==='file')return fail('파일 선택은 직접 해 주세요. 에이전트는 파일을 고를 수 없어요');
if(k==='button'||k==='link')return fail('입력칸이 아니에요. 누르려면 click_element 를 쓰세요');
el.scrollIntoView({block:'center',inline:'nearest'});
function fire(t,type,I){try{t.dispatchEvent(new (I||Event)(type,{bubbles:true,cancelable:true,composed:true}));}catch(e){}}
var shown='';
if(k==='select'){
  var want=V.trim().toLowerCase(),idx=-1,i;
  for(i=0;i<el.options.length;i++){var op=el.options[i];if(op.value.toLowerCase()===want||op.text.trim().toLowerCase()===want){idx=i;break;}}
  if(idx<0){for(i=0;i<el.options.length;i++){if(el.options[i].text.toLowerCase().indexOf(want)>=0){idx=i;break;}}}
  if(idx<0)return fail('그런 선택지가 없어요: '+cut(V,40),{options:Array.prototype.slice.call(el.options,0,12).map(function(o){return cut(o.text,30);})});
  el.selectedIndex=idx;fire(el,'input');fire(el,'change');
  shown=cut(el.options[idx].text,40);
}else if(k==='checkbox'||k==='radio'){
  var on=/^(true|on|1|yes|checked|켜기|켬|체크)(?![\s\S])/i.test(V.trim());
  var cur=(el.checked!==undefined)?!!el.checked:(el.getAttribute('aria-checked')==='true');
  if(k==='radio'){if(!cur)el.click();}
  else if(cur!==on)el.click();
  shown=((el.checked!==undefined)?!!el.checked:(el.getAttribute('aria-checked')==='true'))?'체크됨':'체크 안 됨';
}else if(tg==='INPUT'||tg==='TEXTAREA'){
  var proto=(tg==='TEXTAREA')?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  var setter=Object.getOwnPropertyDescriptor(proto,'value');
  if(setter&&setter.set)setter.set.call(el,V);else el.value=V;
  try{el.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:V}));}catch(e){fire(el,'input');}
  fire(el,'change');
  shown=cut(el.value,40);
}else if(el.isContentEditable){
  el.focus();
  try{document.execCommand('selectAll',false,null);document.execCommand('insertText',false,V);}catch(e){el.textContent=V;}
  fire(el,'input');
  shown=cut(el.textContent,40);
}else{
  return fail('이 요소에는 쓸 수 없어요');
}
if(submit){
  var f=el.form;
  var kopt={key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true,composed:true};
  var go=el.dispatchEvent(new KeyboardEvent('keydown',kopt));
  el.dispatchEvent(new KeyboardEvent('keypress',kopt));
  el.dispatchEvent(new KeyboardEvent('keyup',kopt));
  if(go&&f){if(f.requestSubmit)f.requestSubmit();else f.submit();}
}
return JSON.stringify({ok:true,label:label(el),value:shown,submitted:submit});
"""

    /** 스크롤. __DIR__ = up | down | top | bottom, __AMT__ = 픽셀(0 이면 화면 높이의 80%), __ID__ = 요소 번호(0 이면 없음) */
    private const val SCROLL = """
var dir='__DIR__',amt=__AMT__,id=__ID__;
function best(){
  var se=document.scrollingElement||document.documentElement;
  if(se.scrollHeight-se.clientHeight>4)return se;
  var c=null,ca=0,all=document.querySelectorAll('*');
  for(var i=0;i<all.length&&i<5000;i++){
    var e=all[i];
    if(e.scrollHeight-e.clientHeight<=40)continue;
    var oy=getComputedStyle(e).overflowY;
    if(oy!=='auto'&&oy!=='scroll'&&oy!=='overlay')continue;
    if(!inView(e))continue;
    var a=e.clientWidth*e.clientHeight;
    if(a>ca){ca=a;c=e;}
  }
  return c||se;
}
var sc=best();
var isDoc=(sc===document.scrollingElement||sc===document.documentElement||sc===document.body);
function pos(){
  var y=isDoc?(window.pageYOffset||sc.scrollTop):sc.scrollTop;
  var vh=isDoc?innerHeight:sc.clientHeight;
  return {y:Math.round(y),max:Math.max(0,Math.round(sc.scrollHeight-vh)),view:Math.round(vh)};
}
function to(t){
  if(isDoc){try{window.scrollTo({top:t,left:0,behavior:'instant'});}catch(e){window.scrollTo(0,t);}}
  else sc.scrollTop=t;
}
var before=pos();
if(id>0){
  var el=pick(id);
  if(!el)return fail(GONE);
  el.scrollIntoView({block:'center',inline:'nearest'});
}else{
  var step=amt>0?amt:Math.round(before.view*0.8);
  var t=dir==='top'?0:(dir==='bottom'?before.max:(dir==='up'?before.y-step:before.y+step));
  to(Math.max(0,Math.min(before.max,t)));
}
var after=pos();
return JSON.stringify({ok:true,y:after.y,max:after.max,view:after.view,moved:after.y!==before.y,
  at_top:after.y<=2,at_bottom:after.y>=after.max-2,percent:after.max>0?Math.round(after.y*100/after.max):100,inner_scroll:!isDoc});
"""

    private fun wrap(body: String): String =
        "(function(){" + PRE + "try{" + body +
            "}catch(e){return JSON.stringify({ok:false,error:'페이지 스크립트 오류: '+(e&&e.message?e.message:e)});}})()"

    // ───────────────────────── 도우미 ─────────────────────────

    /** 페이지 안에서 스크립트를 돌려 JSON 결과를 받는다. 실패하면 (null, 이유) */
    private fun runJson(ctx: AgentContext, js: String): Pair<JSONObject?, String> {
        val o = ctx.host.pageScript(js)
        if (!o.ok) return null to o.message
        return try {
            JSONObject(o.message) to ""
        } catch (e: Exception) {
            null to "페이지에서 받은 결과를 읽지 못했어요"
        }
    }

    /** 스크립트 결과를 도구 결과로 바꾼다. 스크립트가 ok=false 로 돌려주면 그 이유를 실패로 낸다 */
    private fun asResult(o: JSONObject?, err: String, summary: (JSONObject) -> String, untrusted: Boolean = false): AgentResult {
        if (o == null) return AgentResult.fail(err)
        if (!o.optBoolean("ok", true)) {
            val d = JSONObject().put("error", o.optString("error"))
            o.optString("href").takeIf { it.isNotEmpty() }?.let { d.put("href", it) }
            if (o.has("options")) d.put("options", o.opt("options"))
            return AgentResult(false, d, o.optString("error"), untrusted)
        }
        return AgentResult.ok(o, summary(o), untrusted)
    }

    private fun elInfo(ctx: AgentContext, id: Int): JSONObject? {
        if (id <= 0) return null
        val (o, _) = runJson(ctx, wrap(INFO.replace("__ID__", id.toString())))
        return if (o != null && o.optBoolean("ok", false)) o else null
    }

    private fun describe(ctx: AgentContext, id: Int): String {
        val info = elInfo(ctx, id) ?: return "${id}번 요소"
        val l = info.optString("label")
        return if (l.isEmpty()) "${id}번 ${info.optString("kind")}" else "「${short(l, 30)}」"
    }

    // ───────────────────────── 읽기 ─────────────────────────

    private fun readPage() = AgentTool(
        name = "read_page",
        description = "지금 보고 있는 탭의 웹 페이지 글과, 누르거나 입력할 수 있는 요소(링크 · 버튼 · 입력칸 · 선택 상자 · 체크 상자)의 목록을 읽어 옵니다. " +
            "요소마다 element 번호가 붙고, 이 번호를 click_element · fill_field · scroll_page 에 씁니다. 번호는 마지막으로 읽은 결과에서만 맞으니, 페이지가 바뀌면(이동 · 클릭 · 스크롤로 새 내용이 뜰 때) 다시 읽으세요. " +
            "scope 는 viewport(지금 화면에 보이는 것만, 기본) 또는 all(페이지 전체, 최대 60개)입니다. 화면 밖 요소는 scroll_page 로 내린 뒤 다시 읽어도 됩니다. " +
            "비밀번호 · 카드번호 칸은 값이 보이지 않고 secret 으로 표시됩니다. 새 탭(홈) 화면에서는 쓸 수 없습니다.",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "scope" to AgentSchema.oneOf("읽을 범위 (기본 viewport)", "viewport", "all"),
                "text" to AgentSchema.flag("페이지 글도 함께 읽을지 (기본 true)")
            )
        ),
        doing = { "페이지 읽는 중…" },
        run = { a, ctx ->
            val scope = if (a.optString("scope") == "all") "all" else "viewport"
            val text = a.optBoolean("text", true)
            val (o, err) = runJson(ctx, wrap(READ.replace("__SCOPE__", scope).replace("__TEXT__", text.toString())))
            // 페이지 글 · 요소 이름은 웹페이지가 정한 글이라 자료로만 다룬다
            asResult(o, err, { "페이지를 읽었어요 · 요소 ${it.optInt("shown")}개" }, untrusted = true)
        }
    )

    private fun scrollPage() = AgentTool(
        name = "scroll_page",
        description = "지금 탭의 페이지를 스크롤합니다. direction: down(아래, 기본) · up(위) · top(맨 위) · bottom(맨 아래). amount 는 픽셀(비우면 화면 높이의 약 80%). " +
            "element 를 주면 그 요소가 화면 가운데 오도록 스크롤합니다. 결과에 지금 위치(percent)와 맨 위 · 맨 아래인지가 나옵니다. 스크롤한 뒤 새로 보이는 요소는 read_page 로 다시 읽어야 번호를 쓸 수 있습니다.",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "direction" to AgentSchema.oneOf("스크롤 방향 (기본 down)", "down", "up", "top", "bottom"),
                "amount" to AgentSchema.int("스크롤할 픽셀 (비우면 화면 높이의 80%)"),
                "element" to AgentSchema.int("화면 가운데로 가져올 요소 번호 (read_page 의 element)")
            )
        ),
        doing = { a ->
            when (a.optString("direction")) {
                "top" -> "맨 위로 스크롤하는 중…"
                "bottom" -> "맨 아래로 스크롤하는 중…"
                "up" -> "위로 스크롤하는 중…"
                else -> if (a.optInt("element", 0) > 0) "요소 쪽으로 스크롤하는 중…" else "아래로 스크롤하는 중…"
            }
        },
        run = { a, ctx ->
            val dir = when (a.optString("direction")) {
                "up", "top", "bottom" -> a.optString("direction")
                else -> "down"
            }
            val amt = a.optInt("amount", 0).coerceIn(0, 20000)
            val id = a.optInt("element", 0).coerceAtLeast(0)
            val js = wrap(SCROLL.replace("__DIR__", dir).replace("__AMT__", amt.toString()).replace("__ID__", id.toString()))
            val (o, err) = runJson(ctx, js)
            asResult(o, err, { if (it.optBoolean("moved")) "스크롤했어요 (${it.optInt("percent")}%)" else "더 갈 곳이 없어요" })
        }
    )

    // ───────────────────────── 변경 ─────────────────────────

    /** 누를 요소의 위험도: 제출 · 내려받기 · 결제 같은 글자의 버튼이면 매번 확인(DANGER), 아니면 요청당 한 번(CHANGE) */
    private fun clickRisk(ctx: AgentContext, id: Int): AgentRisk {
        val info = elInfo(ctx, id) ?: return AgentRisk.CHANGE
        return if (info.optBoolean("submit") || info.optBoolean("download") || RISKY.containsMatchIn(info.optString("label"))) {
            AgentRisk.DANGER
        } else AgentRisk.CHANGE
    }

    private fun clickElement() = AgentTool(
        name = "click_element",
        description = "read_page 로 읽은 요소 하나를 누릅니다(링크 · 버튼 · 탭 · 메뉴 항목 등). element 는 read_page 의 번호입니다. " +
            "결제 · 삭제 · 전송 · 제출 · 동의 같은 버튼과 파일 내려받기 링크는 누를 때마다 사용자 확인을 받습니다. " +
            "새 탭으로 열리는 링크(new_tab)는 눌리지 않으니 open_tab 으로 주소를 여세요. 팝업 · 광고가 가리고 있으면 눌리지 않고 그 이유가 나옵니다. " +
            "누른 뒤 페이지가 바뀔 수 있으니 결과를 보려면 read_page 로 다시 읽으세요.",
        risk = AgentRisk.CHANGE,
        riskFor = { a, ctx -> clickRisk(ctx, a.optInt("element", 0)) },
        params = AgentSchema.obj(
            listOf("element" to AgentSchema.int("누를 요소 번호 (read_page 의 element)")),
            listOf("element")
        ),
        doing = { a -> "페이지의 ${a.optInt("element", 0)}번 요소를 누르는 중…" },
        run = { a, ctx ->
            val id = a.optInt("element", 0)
            if (id <= 0) {
                AgentResult.fail("element 번호가 필요해요 (read_page 로 먼저 읽으세요)")
            } else {
                val (o, err) = runJson(ctx, wrap(CLICK.replace("__ID__", id.toString())))
                val r = asResult(o, err, { "눌렀어요: " + short(it.optString("label").ifEmpty { "${id}번 요소" }, 24) }, untrusted = true)
                if (r.ok) {
                    // 누른 뒤 이동이 시작되거나 새 내용이 뜰 시간을 조금 준다
                    try { Thread.sleep(700) } catch (e: InterruptedException) { }
                    val cur = try { ctx.host.tabs().firstOrNull { it.current } } catch (e: Exception) { null }
                    if (cur != null) {
                        r.data.put("now_url", cur.url.take(300)).put("loading", cur.loading)
                        r.data.put("hint", "페이지가 바뀌었을 수 있어요. 결과를 보려면 read_page 로 다시 읽으세요")
                    }
                }
                r
            }
        },
        ask = { a, ctx -> "페이지에서 누르기: " + describe(ctx, a.optInt("element", 0)) }
    )

    private fun fillField() = AgentTool(
        name = "fill_field",
        description = "read_page 로 읽은 입력칸에 글을 쓰거나, 선택 상자의 항목을 고르거나, 체크 상자 · 라디오를 켜고 끕니다. element 는 read_page 의 번호입니다. " +
            "value 는 쓸 글(입력칸 · 텍스트 영역), 고를 항목의 글이나 값(선택 상자), true/false(체크 상자)입니다. 기존 내용은 value 로 바뀝니다. " +
            "submit 이 true 면 쓴 뒤 Enter 를 눌러 제출합니다(검색창 · 폼). 제출은 매번 사용자 확인을 받습니다. " +
            "비밀번호 · 카드번호 · 인증번호 칸과 파일 선택은 쓸 수 없으니 사용자에게 직접 하라고 알리세요. 사용자가 시키지 않은 개인정보를 지어내서 쓰지 마세요.",
        risk = AgentRisk.CHANGE,
        riskFor = { a, _ -> if (a.optBoolean("submit", false)) AgentRisk.DANGER else AgentRisk.CHANGE },
        params = AgentSchema.obj(
            listOf(
                "element" to AgentSchema.int("쓸 요소 번호 (read_page 의 element)"),
                "value" to AgentSchema.str("쓸 글 · 고를 항목 · true/false"),
                "submit" to AgentSchema.flag("쓴 뒤 Enter 로 제출할지 (기본 false)")
            ),
            listOf("element", "value")
        ),
        doing = { a -> "페이지의 ${a.optInt("element", 0)}번 칸에 입력하는 중…" },
        run = { a, ctx ->
            val id = a.optInt("element", 0)
            if (id <= 0 || !a.has("value")) {
                AgentResult.fail("element 번호와 value 가 필요해요 (read_page 로 먼저 읽으세요)")
            } else {
                val value = a.optString("value").take(2000)
                val submit = a.optBoolean("submit", false)
                val js = wrap(FILL.replace("__ID__", id.toString()).replace("__VAL__", JSONObject.quote(value)).replace("__SUBMIT__", submit.toString()))
                val (o, err) = runJson(ctx, js)
                val r = asResult(o, err, { "입력했어요: " + short(it.optString("label").ifEmpty { "${id}번 칸" }, 20) + (if (submit) " (제출)" else "") }, untrusted = true)
                if (r.ok && submit) {
                    try { Thread.sleep(700) } catch (e: InterruptedException) { }
                    val cur = try { ctx.host.tabs().firstOrNull { it.current } } catch (e: Exception) { null }
                    if (cur != null) r.data.put("now_url", cur.url.take(300)).put("loading", cur.loading)
                }
                r
            }
        },
        ask = { a, ctx ->
            val what = describe(ctx, a.optInt("element", 0))
            "입력하기: $what ← “${short(a.optString("value"), 40)}”" + if (a.optBoolean("submit", false)) " 그리고 Enter 로 제출" else ""
        }
    )
}
