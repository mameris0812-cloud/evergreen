package com.example.evergreen

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * AI 모델이 종료되거나 새 버전으로 바뀌어도 앱을 고치지 않고 이어 쓰게 한다.
 *
 * 구글의 모델 목록(models.list)을 받아서, 칸마다(Flash-Lite · 3.8 Flash · Hydrogen) 지금 쓰는 모델이
 * 목록에서 사라졌거나 종료 예정(deprecated · retired · 곧 종료)으로 표시됐으면 같은 계열의 새 모델로 바꾼다.
 * 더 새 것 중 가장 가까운 것을 고르고(다른 칸이 쓰는 것은 되도록 피함), 같은 계열에 대신할 게 없으면 그대로 둔다.
 *
 * - 앱을 켤 때 저장해 둔 결과를 바로 쓰고, 12시간이 지났으면 백그라운드에서 새로 받는다 ([refreshIfStale]).
 * - 요청이 모델 없음(404)으로 실패하면 그 자리에서 새로 받아 바뀐 모델로 다시 보낸다 ([refreshNow]).
 * - 목록을 못 받거나 이상하면(Flash 계열이 하나도 없는 등) 아무것도 바꾸지 않는다.
 */
object GeminiModelSync {
    private const val PREFS = "gemini_model_sync"
    private const val STALE_MS = 12L * 60L * 60L * 1000L
    private const val RETRY_GAP_MS = 10L * 60L * 1000L
    private const val JUST_FETCHED_MS = 20_000L
    /** 종료까지 이 기간 안으로 남은 모델은 미리 바꾼다 */
    private const val SOON_MS = 7L * 24L * 60L * 60L * 1000L

    @Volatile
    private var sp: SharedPreferences? = null

    /** 마지막으로 목록을 받은 시각 / 마지막으로 시도한 시각 */
    @Volatile
    private var lastFetch = 0L

    @Volatile
    private var lastTry = 0L

    /** 앱을 켤 때 한 번: 저장해 둔 교체 결과를 적용한다 (앱이 업데이트되어 기본 모델이 바뀌었으면 버린다) */
    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        sp = p
        lastFetch = p.getLong("at", 0L)
        try {
            if (p.getString("base", null) != GeminiModels.baseKey()) return
            val o = JSONObject(p.getString("map", null) ?: return)
            val m = HashMap<String, String>()
            for (k in o.keys()) m[k] = o.optString(k)
            GeminiModels.apply(m)
        } catch (e: Exception) {
            // 깨진 값은 없는 걸로 본다
        }
    }

    /** 목록을 받은 지 오래됐으면 백그라운드에서 새로 받는다. 기다리지 않는다 */
    fun refreshIfStale(key: String) {
        if (key.isBlank()) return
        val t = System.currentTimeMillis()
        if (t - lastFetch < STALE_MS || t - lastTry < RETRY_GAP_MS) return
        lastTry = t
        Thread { refreshNow(key) }.apply { isDaemon = true; name = "model-sync" }.start()
    }

    /**
     * 구글에서 모델 목록을 받아 칸별 모델을 다시 정한다. 반드시 백그라운드 스레드에서 부른다.
     * 방금 받았거나 새로 받았으면 true, 못 받았으면 false.
     */
    @Synchronized
    fun refreshNow(key: String): Boolean {
        if (key.isBlank()) return false
        val t = System.currentTimeMillis()
        if (t - lastFetch < JUST_FETCHED_MS) return true
        lastTry = t
        val avail = fetch(key) ?: return false
        lastFetch = System.currentTimeMillis()
        val next = resolveAll(avail)
        if (next != null) GeminiModels.apply(next)
        save()
        return true
    }

    private fun save() {
        try {
            val o = JSONObject()
            for ((k, v) in GeminiModels.currentMap()) o.put(k, v)
            sp?.edit()?.putString("base", GeminiModels.baseKey())?.putString("map", o.toString())?.putLong("at", lastFetch)?.apply()
        } catch (e: Exception) {
            // 저장 못 해도 이번 실행에서는 쓴다
        }
    }

    /** id → 종료 예정 여부. generateContent 를 쓸 수 있는 모델만. 못 받으면 null */
    private fun fetch(key: String): Map<String, Boolean>? {
        val out = LinkedHashMap<String, Boolean>()
        var token = ""
        try {
            for (page in 0 until 5) {
                var u = "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000"
                if (token.isNotEmpty()) u += "&pageToken=" + URLEncoder.encode(token, "UTF-8")
                val c = URL(u).openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 8000
                    c.readTimeout = 10000
                    c.setRequestProperty("x-goog-api-key", key)
                    if (c.responseCode !in 200..299) return null
                    val body = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val o = JSONObject(body)
                    val arr = o.optJSONArray("models")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val m = arr.optJSONObject(i) ?: continue
                            val id = m.optString("name").removePrefix("models/")
                            if (id.isEmpty()) continue
                            val methods = m.optJSONArray("supportedGenerationMethods")
                            var gen = methods == null
                            if (methods != null) {
                                for (j in 0 until methods.length()) if (methods.optString(j) == "generateContent") gen = true
                            }
                            if (!gen) continue
                            out[id] = isEnding(m.optJSONObject("modelStatus"))
                        }
                    }
                    token = o.optString("nextPageToken", "")
                } finally {
                    c.disconnect()
                }
                if (token.isEmpty()) break
            }
        } catch (e: Exception) {
            return null
        }
        return if (out.isEmpty()) null else out
    }

    /** 모델 상태(modelStatus)가 종료됨·종료 예정이거나, 종료 시각이 일주일 안이면 true */
    private fun isEnding(st: JSONObject?): Boolean {
        if (st == null) return false
        val stage = st.optString("modelStage", "").uppercase()
        if (stage.contains("DEPRECAT") || stage.contains("RETIRE")) return true
        val rt = st.optString("retirementTime", "")
        if (rt.length >= 19) {
            try {
                val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
                f.timeZone = java.util.TimeZone.getTimeZone("UTC")
                val d = f.parse(rt.substring(0, 19))
                if (d != null) return d.time < System.currentTimeMillis() + SOON_MS
            } catch (e: Exception) {
                // 읽지 못하면 종료 예정이 아닌 것으로 본다
            }
        }
        return false
    }

    /** 칸별로 쓸 모델. 목록이 이상해 보이면(Flash 계열이 하나도 없음) null */
    private fun resolveAll(avail: Map<String, Boolean>): Map<String, String>? {
        val flashRe = GeminiModels.FAMILY.getValue("PRO")
        if (avail.keys.none { flashRe.matches(it) }) return null
        val ok = avail.filterValues { !it }.keys
        val result = LinkedHashMap<String, String>()
        val taken = HashSet<String>()
        // 위쪽 칸부터 정해서, 아래 칸이 윗칸이 쓰는 모델과 겹치지 않게 한다
        for (slot in listOf("HYDROGEN", "PRO", "LITE")) {
            val pick = pickFor(GeminiModels.idOf(slot), GeminiModels.FAMILY.getValue(slot), ok, taken)
            result[slot] = pick
            taken.add(pick)
        }
        return result
    }

    private fun pickFor(cur: String, re: Regex, ok: Set<String>, taken: Set<String>): String {
        if (cur in ok) return cur
        val curV = GeminiModels.versionOf(cur, re) ?: listOf(0)
        val cands = ok.mapNotNull { id -> GeminiModels.versionOf(id, re)?.let { v -> id to v } }
            .sortedWith { a, b -> GeminiModels.cmpVer(a.second, b.second) }
        if (cands.isEmpty()) return cur
        val newer = cands.filter { GeminiModels.cmpVer(it.second, curV) > 0 }
        return newer.firstOrNull { it.first !in taken }?.first ?: newer.lastOrNull()?.first ?: cands.last().first
    }
}
