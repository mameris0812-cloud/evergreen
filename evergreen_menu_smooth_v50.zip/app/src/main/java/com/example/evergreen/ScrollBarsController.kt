package com.example.evergreen

import android.animation.ValueAnimator
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 페이지를 스크롤하면 상단 바(탭 줄 · 주소창)와 하단 바가 손가락을 따라 사라지고 나타나는 동작.
 *
 * 방식은 하나뿐이다: 진행도 f (0 = 모두 보임, 1 = 모두 숨김) 에 맞춰
 *  - 맨 위 바의 위쪽 여백을 -(상단 바 높이 × f)
 *  - 하단 바의 아래쪽 여백을 -(하단 바 높이 × f)
 * 로 두는 것이 전부다. 세로 LinearLayout 이 알아서 바를 화면 밖으로 밀어내고 웹 영역을 늘려 준다.
 * (translation 과 레이아웃 크기를 따로 맞추거나 '숨김 형태 레이아웃'으로 바꿨다 되돌리는 단계가 없다.)
 *
 * 하단에 흰 줄이 생기지 않게 하는 방법 (미리 키워 두기):
 * 웹 영역이 움직이는 도중에 커지면 WebView 가 늘어난 부분을 바로 못 그려서 흰 줄이 보인다. 그래서
 *  1) 스크롤이 시작되면 먼저 웹 영역을 '화면 전체 크기'로 키운다 (늘어난 부분은 화면 밖 · 하단 바 뒤에 있어 보이지 않는다).
 *  2) WebView 가 새 크기로 그려질 시간을 준 뒤부터 바를 움직인다 (그동안은 페이지만 평소처럼 스크롤된다).
 *  3) 바가 움직이는 동안 웹 영역의 크기는 바뀌지 않는다. 웹 영역의 아래쪽 여백을 -(바 높이 합 × (1 - f)) 로 두면
 *     위쪽이 올라가는 만큼 아래쪽이 줄어서, 높이가 늘 화면 전체와 같다.
 *  4) 바가 완전히 돌아온 뒤(손가락도 뗀 뒤)에 웹 영역을 원래 크기로 줄인다 (줄어드는 쪽이라 흰 줄이 없다).
 *
 * 손가락이 움직이는 동안(PullRefreshLayout 의 중첩 스크롤)에는 바가 움직임을 먼저 쓰고 남는 만큼만 페이지가 스크롤된다.
 * 손가락을 떼면 움직이던 방향으로 끝까지 숨기거나 보여 준다.
 */
class ScrollBarsController(
    /** 위에서부터 차례로 늘어선 상단 바들 (보이지 않는 것은 건너뛴다) */
    private val topBars: () -> List<View>,
    /** 하단 바 (태블릿처럼 없으면 null 이나 보이지 않는 상태) */
    private val bottomBar: () -> View?,
    /** 지금 이 동작을 써도 되는 상황인지 (설정, 홈 화면, 주소 입력 중, 찾기 중 …) */
    private val allowed: () -> Boolean,
    private val animationsOn: () -> Boolean,
    /** 웹 영역(WebView 를 담은 칸) */
    private val webFrame: () -> View?,
    /** 8dp 에 해당하는 픽셀 (이만큼 움직여야 스크롤로 본다) */
    private val slopPx: () -> Int
) {
    /** 0 = 모두 보임, 1 = 모두 숨김 */
    var fraction = 0f
        private set

    private var lastDir = 0
    private var anim: ValueAnimator? = null
    private var touching = false
    private var dragAcc = 0

    /** 웹 영역이 '화면 전체 크기'로 키워진 상태인지 */
    private var grown = false

    /** 키운 웹 영역이 새 크기로 그려질 시간이 지났는지 (그 전에는 바를 움직이지 않는다) */
    private var ready = false
    private var readyToken = Any()

    private fun visibleTops(): List<View> = topBars().filter { it.visibility == View.VISIBLE }

    private fun topHeight(): Int = visibleTops().sumOf { it.height }

    private fun setMargin(v: View, top: Int?, bottom: Int?) {
        val lp = v.layoutParams as? LinearLayout.LayoutParams ?: return
        val t = top ?: lp.topMargin
        val b = bottom ?: lp.bottomMargin
        if (lp.topMargin == t && lp.bottomMargin == b) return
        lp.topMargin = t
        lp.bottomMargin = b
        v.layoutParams = lp
    }

    /** 진행도를 화면에 반영한다. 보이는 바의 구성이 바뀌었을 때도 다시 불러 맞춘다. */
    fun apply(f: Float) {
        fraction = f.coerceIn(0f, 1f)
        val tops = visibleTops()
        val first = tops.firstOrNull()
        val topH = tops.sumOf { it.height }
        // 맨 위 바만 위로 올라가고, 나머지 바는 그 아래에 이어 붙어 함께 올라간다
        for (v in topBars()) {
            setMargin(v, if (v === first) -(topH * fraction).roundToInt() else 0, null)
        }
        val bottom = bottomBar()
        var bh = 0
        if (bottom != null) {
            bh = if (bottom.visibility == View.VISIBLE) bottom.height else 0
            setMargin(bottom, null, -(bh * fraction).roundToInt())
        }
        // 미리 키운 동안: 웹 영역 높이를 늘 화면 전체 크기로 고정한다 (위가 올라간 만큼 아래가 줄어든다)
        webFrame()?.let { setMargin(it, null, if (grown) -((topH + bh) * (1f - fraction)).roundToInt() else 0) }
    }

    /** 웹 영역을 화면 전체 크기로 먼저 키우고, 새 크기로 그려질 때까지 기다린 뒤 ready 로 만든다 */
    private fun grow() {
        if (grown) return
        grown = true
        ready = false
        apply(fraction)
        val token = Any()
        readyToken = token
        val f = webFrame() ?: run { ready = true; return }
        // 레이아웃이 끝나고 WebView 가 새 크기로 한두 프레임 그릴 시간을 준다
        f.post {
            f.postDelayed({ if (readyToken === token) ready = true }, 90L)
        }
    }

    /** 웹 영역을 원래 크기로 줄인다 (바가 모두 보이고 손가락도 뗐을 때) */
    private fun leaveGrown() {
        if (!grown) return
        grown = false
        ready = false
        readyToken = Any()
        apply(fraction)
    }

    /** 레이아웃이 바뀐 뒤(탭 줄이 나타나는 등) 지금 진행도로 다시 맞춘다 */
    fun reapply() = apply(fraction)

    /** 애니메이션 없이 곧바로 모두 보이게 되돌린다 (탭 전환 · 설정 변경 · 화면 구성 변경) */
    fun reset() {
        anim?.cancel()
        anim = null
        lastDir = 0
        dragAcc = 0
        grown = false
        ready = false
        readyToken = Any()
        apply(0f)
    }

    private fun animateTo(target: Float) {
        anim?.cancel()
        if (!animationsOn()) {
            apply(target)
            if (target <= 0f && !touching) leaveGrown()
            return
        }
        if (fraction == target) {
            if (target <= 0f && !touching) leaveGrown()
            return
        }
        anim = ValueAnimator.ofFloat(fraction, target).apply {
            duration = (240f * kotlin.math.abs(target - fraction)).toLong().coerceAtLeast(120L)
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { apply(it.animatedValue as Float) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (!cancelled && fraction <= 0f && !touching) leaveGrown()
                }
            })
            start()
        }
    }

    /** 바를 다시 보여 준다 (페이지 이동 · 주소창 선택 · 맨 위 도달 · 찾기 열기 등) */
    fun show(animate: Boolean = true) {
        if (fraction == 0f && anim?.isRunning != true) {
            if (!touching) leaveGrown()
            return
        }
        if (animate) animateTo(0f) else reset()
    }

    /** 손가락이 닿았다 */
    fun onTouchStart() {
        anim?.cancel()
        anim = null
        lastDir = 0
        dragAcc = 0
        touching = true
    }

    /**
     * 손가락이 dy 만큼 움직였다 (dy > 0 : 내용을 아래로 보는 방향).
     * 바가 쓴 만큼을 돌려주며, 그 부분은 페이지가 스크롤하지 않는다.
     */
    fun onPreScroll(dy: Int): Int {
        if (dy == 0 || !allowed()) return 0
        lastDir = if (dy > 0) 1 else -1
        // 처음 아래로 스크롤하기 시작하면, 바를 움직이기 전에 웹 영역부터 미리 키운다
        if (!grown) {
            if (dy < 0) return 0
            dragAcc += dy
            if (dragAcc >= slopPx()) grow()
            return 0
        }
        if (!ready) return 0
        val travel = max(1, topHeight()).toFloat()
        return if (dy > 0) {
            val room = ((1f - fraction) * travel).roundToInt()
            val use = min(dy, room)
            if (use <= 0) return 0
            apply(fraction + use / travel)
            use
        } else {
            val room = (fraction * travel).roundToInt()
            val use = max(dy, -room)
            if (use >= 0) return 0
            apply(fraction + use / travel)
            use
        }
    }

    /** 손가락을 뗐다: 움직이던 방향으로 마저 숨기거나 보여 준다 */
    fun onTouchEnd() {
        touching = false
        if (fraction <= 0f) {
            leaveGrown()
            return
        }
        if (fraction >= 1f) return
        animateTo(
            when {
                lastDir > 0 -> 1f
                lastDir < 0 -> 0f
                else -> if (fraction >= 0.5f) 1f else 0f
            }
        )
    }
}
