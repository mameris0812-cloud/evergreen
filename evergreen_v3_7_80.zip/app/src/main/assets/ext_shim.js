function __evxMake(ID, M, MSG, B, T) {
  var BASE = "https://ext.evergreen.invalid/" + ID + "/";
  function ev() {
    var L = [];
    return {
      addListener: function (f) { if (typeof f === "function") L.push(f); },
      removeListener: function (f) { var i = L.indexOf(f); if (i >= 0) L.splice(i, 1); },
      hasListener: function (f) { return L.indexOf(f) >= 0; },
      hasListeners: function () { return L.length > 0; },
      _a: function () { return L.slice(); },
      _d: function (a) { L.slice().forEach(function (f) { try { f.apply(null, a); } catch (e) { console.error(e); } }); }
    };
  }
  // windows.* 에 populate 가 오면 창 안에 tabs 목록을 넣어 준다 (확장이 w.tabs.some(...) 으로 읽음)
  function winOf(a) {
    var o = null; for (var i = 0; i < a.length; i++) if (a[i] && typeof a[i] === "object") { o = a[i]; break; }
    var w = { id: 1, focused: true, type: "normal", state: "maximized", incognito: false };
    if (o && o.populate) { try { w.tabs = JSON.parse(B.tabinfo(ID, T)); } catch (e) { w.tabs = []; } }
    return w;
  }
  // 값을 돌려주는 함수를 콜백/프로미스 양쪽 방식으로 부를 수 있게 감싼다
  function cb(args, fn) {
    var last = args[args.length - 1];
    if (typeof last === "function") {
      var v, err = null;
      try { v = fn(); } catch (e) { err = e; }
      setTimeout(function () { if (err) console.error(err); else last(v); }, 0);
      return undefined;
    }
    try { return Promise.resolve(fn()); } catch (e) { return Promise.reject(e); }
  }
  // 지원하지 않는 API: 호출해도 오류 없이 조용히 넘어간다
  function stub() {
    var f = function () {
      var c = arguments[arguments.length - 1];
      if (typeof c === "function") { setTimeout(function () { try { c(); } catch (e) {} }, 0); return undefined; }
      return Promise.resolve();
    };
    return new Proxy(f, {
      get: function (t, k) {
        if (k === "then" || typeof k === "symbol") return undefined;
        if (k === "addListener" || k === "removeListener") return function () {};
        if (k === "hasListener" || k === "hasListeners") return function () { return false; };
        return stub();
      }
    });
  }
  function ns(o) {
    return new Proxy(o, {
      get: function (t, k) {
        if (k in t) return t[k];
        if (typeof k === "symbol" || k === "then") return undefined;
        return stub();
      }
    });
  }

  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }
  // 크롬처럼 getManifest() 는 __MSG_이름__ 을 번역한 값으로 돌려준다
  function localize(v) {
    if (typeof v === "string") {
      var mm = /^__MSG_(.+)__$/.exec(v);
      if (mm) { var t = MSG[mm[1].toLowerCase()]; return t == null ? v : t; }
      return v;
    }
    if (Array.isArray(v)) return v.map(localize);
    if (v && typeof v === "object") { var o = {}; Object.keys(v).forEach(function (k) { o[k] = localize(v[k]); }); return o; }
    return v;
  }
  // 진단: 백그라운드 · 팝업 · 옵션 페이지에서만 앱 '진단' 기록에 남긴다 (콘텐츠 스크립트는 따로 남긴다)
  var DIAG = !!window.__evxIsBg || location.href.indexOf(BASE) === 0;
  var WHERE = window.__evxIsBg ? "백그라운드" : "페이지";
  function lg(k, m) { if (!DIAG) return; try { B.log(ID, k, String(m).slice(0, 300), T); } catch (e) { } }
  var offUrl = null; // chrome.offscreen 으로 만든 문서 주소
  function msgName(m) { return m && typeof m === "object" ? String(m.command || m.type || m.cmd || m.action || m.message || m.name || m.method || Object.keys(m).slice(0, 3).join("+")) : String(m); }
  // 같은 페이지(창) 안의 여러 콘텐츠 스크립트 묶음이 리스너를 함께 쓰도록, 확장 프로그램별 이벤트를 창에 하나만 둔다
  var SH = window.__evxSh;
  if (!SH) { SH = {}; try { Object.defineProperty(window, "__evxSh", { value: SH }); } catch (e) { window.__evxSh = SH; } }
  function shared(n) { var k = ID + ":" + n; return SH[k] || (SH[k] = ev()); }
  // 이 창을 가리키는 id (저장소 변경을 다른 창에 알릴 때 자기 자신에게는 다시 안 보내려고)
  var CTX = window.__evxCtx;
  if (!CTX) { CTX = rid(); try { Object.defineProperty(window, "__evxCtx", { value: CTX }); } catch (e) { window.__evxCtx = CTX; } }
  function fire(ch, area) {
    if (!Object.keys(ch).length) return;
    shared("ch")._d([clone(ch), area]);
    shared("ch_" + area)._d([clone(ch)]);
    try { B.sbcast(ID, area, JSON.stringify(ch), CTX, T); } catch (e) { }
  }
  // 다른 창(백그라운드 · 팝업 · 탭)에서 저장소가 바뀌었다는 알림
  if (!window.__evxSc) {
    try {
      Object.defineProperty(window, "__evxSc", {
        value: function (id, area, j, src) {
          if (src === CTX) return;
          var ch = parseJ(j);
          if (!ch) return;
          var a = SH[id + ":ch"], b = SH[id + ":ch_" + area];
          if (a) a._d([clone(ch), area]);
          if (b) b._d([clone(ch)]);
        }
      });
    } catch (e) { }
  }

  // ── 네이티브와 주고받는 비동기 호출 (메시지 · fetch · 탭 메시지) ──
  var ROOT = "https://ext.evergreen.invalid/";
  var G = window.__evxPending;
  if (!G) { G = {}; try { Object.defineProperty(window, "__evxPending", { value: G }); } catch (e) { window.__evxPending = G; } }
  if (!window.__evxResp) {
    try { Object.defineProperty(window, "__evxResp", { value: function (id, j) { var f = G[id]; if (f) { delete G[id]; f(j); } } }); } catch (e) { }
  }
  function rid() { return Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function ask(start, ms) {
    return new Promise(function (res) {
      var cid = rid();
      var t = setTimeout(function () { delete G[cid]; res(""); }, ms || 30000);
      G[cid] = function (j) { clearTimeout(t); res(j); };
      try { start(cid); } catch (e) { delete G[cid]; clearTimeout(t); res(""); }
    });
  }
  function parseJ(j) { if (j === "" || j == null) return undefined; try { return JSON.parse(j); } catch (e) { return undefined; } }
  function str(m) { var j = JSON.stringify(m === undefined ? null : m); return j === undefined ? "null" : j; }
  function withCb(done, p) {
    if (typeof done === "function") { p.then(function (v) { try { done(v); } catch (e) { console.error(e); } }); return undefined; }
    return p;
  }
  function openTab(u) {
    try { u = new URL(String(u || ""), BASE).href; B.opentab(ID, u, T); } catch (e) { }
  }
  // 크롬처럼: 리스너가 true 를 돌려주면 나중에 sendResponse, 아니면 바로 닫는다.
  // 다만 파이어폭스 방식(리스너가 Promise 를 돌려주면 그 값이 응답)으로 짠 확장 프로그램도 많다: 크롬에서는 polyfill 이 대신 처리해 주는데,
  // 여기서는 browser 가 이미 있어서 polyfill 이 끼어들지 않으므로 Promise 를 돌려준 리스너의 값을 응답으로 쓴다 (값이 없으면 응답 없음)
  function dispatch(evObj, msg, sender, reply, tries) {
    var ls = evObj ? evObj._a() : [], done = false, waitTrue = false, pend = 0;
    // 페이지가 막 열려 아직 onMessage 리스너를 달기 전에 메시지가 오면(예: 백그라운드가 탭을 열자마자 보냄) 잠깐(최대 3초) 기다렸다가 전달한다.
    // 크롬은 페이지 스크립트가 도는 동안 리스너가 달릴 시간이 있어서 이런 확장이 그대로 동작한다
    if (!ls.length && evObj && !window.__evxIsBg && (tries || 0) < 30) {
      setTimeout(function () { dispatch(evObj, msg, sender, reply, (tries || 0) + 1); }, 100);
      return;
    }
    if (!ls.length) lg("메시지 받을 곳 없음", WHERE + "에 onMessage 리스너가 없어요: " + msgName(msg));
    function respond(v) { if (done) return; done = true; reply(v); }
    function settle() { if (!done && !waitTrue && pend === 0) respond(undefined); }
    for (var i = 0; i < ls.length && !done; i++) {
      var r;
      try { r = ls[i](clone(msg), sender, respond); } catch (e) { console.error(e); lg("메시지 처리 오류", msgName(msg) + ": " + ((e && e.stack) || e)); continue; }
      if (r === true) waitTrue = true;
      else if (r && typeof r.then === "function") {
        pend++;
        r.then(function (v) { pend--; if (v !== undefined) respond(v); else settle(); },
          function (e) { pend--; lg("메시지 처리 오류", msgName(msg) + ": " + ((e && (e.stack || e.message)) || e)); settle(); });
      }
    }
    settle();
  }
  // 알람 (백그라운드 페이지가 살아 있는 동안만 울린다)
  var onAlarm = ev(), AL = {}, ALT = {};
  function clearA(n) { if (ALT[n] != null) { clearTimeout(ALT[n]); delete ALT[n]; } var had = n in AL; delete AL[n]; return had; }
  var alarms = ns({
    create: function (name, info) {
      if (name && typeof name === "object") { info = name; name = ""; }
      info = info || {}; name = name || "";
      clearA(name);
      var d = info.when != null ? Math.max(0, info.when - Date.now()) : (info.delayInMinutes != null ? info.delayInMinutes * 60000 : (info.periodInMinutes || 0) * 60000);
      var per = info.periodInMinutes ? Math.max(info.periodInMinutes, 0.5) * 60000 : 0;
      var al = { name: name, scheduledTime: Date.now() + d };
      if (info.periodInMinutes) al.periodInMinutes = info.periodInMinutes;
      AL[name] = al;
      var fire = function () {
        if (!AL[name] || AL[name] !== al) return;
        var copy = JSON.parse(JSON.stringify(al));
        if (per) { al.scheduledTime = Date.now() + per; ALT[name] = setTimeout(fire, per); } else { delete AL[name]; delete ALT[name]; }
        onAlarm._d([copy]);
      };
      ALT[name] = setTimeout(fire, d);
      return cb(arguments, function () {});
    },
    get: function (name) { var a = arguments; return cb(a, function () { return clone(AL[typeof name === "string" ? name : ""]); }); },
    getAll: function () { return cb(arguments, function () { return Object.keys(AL).map(function (k) { return clone(AL[k]); }); }); },
    clear: function (name) { var a = arguments; return cb(a, function () { return clearA(typeof name === "string" ? name : ""); }); },
    clearAll: function () { return cb(arguments, function () { var any = Object.keys(AL).length > 0; Object.keys(AL).forEach(clearA); return any; }); },
    onAlarm: onAlarm
  });
  function area(name) {
    function load() { try { return JSON.parse(B.sget(ID, name, T) || "{}"); } catch (e) { return {}; } }
    function save(o) { B.sset(ID, name, JSON.stringify(o), T); }
    return {
      get: function (keys) {
        return cb(arguments, function () {
          var o = load();
          if (keys == null || typeof keys === "function") return o;
          var r = {};
          if (typeof keys === "string") keys = [keys];
          if (Array.isArray(keys)) keys.forEach(function (k) { if (k in o) r[k] = o[k]; });
          else if (typeof keys === "object") Object.keys(keys).forEach(function (k) { r[k] = (k in o) ? o[k] : keys[k]; });
          return r;
        });
      },
      set: function (items) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(items || {}).forEach(function (k) {
            var nv = clone(items[k]);
            ch[k] = { oldValue: o[k], newValue: nv };
            o[k] = nv;
          });
          save(o);
          fire(ch, name);
        });
      },
      remove: function (keys) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          (Array.isArray(keys) ? keys : [keys]).forEach(function (k) {
            if (typeof k === "string" && k in o) { ch[k] = { oldValue: o[k] }; delete o[k]; }
          });
          save(o);
          fire(ch, name);
        });
      },
      clear: function () {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(o).forEach(function (k) { ch[k] = { oldValue: o[k] }; });
          save({});
          fire(ch, name);
        });
      },
      getBytesInUse: function () { return cb(arguments, function () { return JSON.stringify(load()).length; }); },
      getKeys: function () { return cb(arguments, function () { return Object.keys(load()); }); },
      setAccessLevel: function () { return cb(arguments, function () { }); },
      QUOTA_BYTES: name === "sync" ? 102400 : (name === "session" ? 10485760 : 10485760),
      onChanged: shared("ch_" + name)
    };
  }

  // ── 포트 (runtime.connect / tabs.connect) ──
  // 열기·메시지·닫기를 보통 메시지로 감싸서 주고받는다 (콘텐츠 스크립트·팝업 → 백그라운드는 B.send, 백그라운드 → 열린 페이지는 B.bgbcast, 백그라운드 → 보고 있는 탭은 B.tabsend)
  var PORTS = window.__evxPorts;
  if (!PORTS) { PORTS = {}; try { Object.defineProperty(window, "__evxPorts", { value: PORTS }); } catch (e) { window.__evxPorts = PORTS; } }
  function envOf(op, pid, x) { var o = { __evxPort: 1, op: op, pid: pid }; if (x) for (var k in x) o[k] = x[k]; return o; }
  function toBg(env) { ask(function (cid) { B.send(ID, str(env), location.href, T, cid); }, 8000); }
  function toPages(env) { ask(function (cid) { B.bgbcast(ID, str(env), T, cid); }, 8000); }
  function toTab(env) { ask(function (cid) { B.tabsend(ID, str(env), T, cid); }, 8000); }
  function mkPort(pid, name, sender, out) {
    var p = { name: name || "", onMessage: ev(), onDisconnect: ev(), _c: false };
    if (sender) p.sender = sender;
    p.postMessage = function (m) {
      if (p._c) throw new Error("Attempting to use a disconnected port object");
      out(envOf("msg", pid, { data: m === undefined ? null : m }));
    };
    p.disconnect = function () {
      if (p._c) return;
      p._c = true; delete PORTS[pid + ID];
      out(envOf("close", pid));
    };
    p._in = function (op, data) {
      if (p._c) return;
      if (op === "msg") p.onMessage._d([clone(data), p]);
      else if (op === "close") { p._c = true; delete PORTS[pid + ID]; p.onDisconnect._d([p]); }
    };
    PORTS[pid + ID] = p;
    return p;
  }
  function handlePort(env, sender, out) {
    var p = PORTS[env.pid + ID];
    if (env.op === "open") {
      if (p) return;
      var oc = shared("oc");
      var np = mkPort(env.pid, env.name, sender, out);
      if (!oc.hasListeners()) { np.disconnect(); return; }
      oc._d([np]);
    } else if (p) {
      p._in(env.op, env.data);
    }
  }

  // ── 보고 있는 탭에 스크립트·스타일 넣기 (scripting / tabs.executeScript · insertCSS) ──
  function tabExec(spec) {
    return ask(function (cid) { B.tabexec(ID, str(spec), T, cid); }, 60000).then(function (j) {
      var r = parseJ(j);
      if (!r) return [];
      if (r.error) throw new Error(r.error);
      return r.results || [];
    });
  }
  function tabArgs(args) {
    var a = [].slice.call(args), done = null;
    if (typeof a[a.length - 1] === "function") done = a.pop();
    if (typeof a[0] === "number") a.shift();
    return { d: a[0] || {}, done: done };
  }
  function tabCmd(cmd, arg) { try { B.tabcmd(ID, cmd, arg || "", T); } catch (e) { } }

  // ── 페이지 저장 (pageCapture.saveAsMHTML): 웹뷰의 웹 아카이브로 근사한다 ──
  function pageCap(args) {
    var a = [].slice.call(args), done = null;
    if (typeof a[a.length - 1] === "function") done = a.pop();
    var p = ask(function (cid) { B.pagecap(ID, T, cid); }, 60000).then(function (j) {
      var r = parseJ(j);
      if (!r) throw new Error("Failed to save the page.");
      if (r.error) throw new Error(r.error);
      var bin = atob(r.mhtml), n = bin.length, u8 = new Uint8Array(n);
      for (var i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
      return new Blob([u8], { type: "multipart/related" });
    });
    if (done) { p.then(function (b) { try { done(b); } catch (e) { console.error(e); } }, function (e) { try { C.runtime.lastError = { message: e.message }; done(undefined); } catch (x) { console.error(x); } finally { C.runtime.lastError = undefined; } }); return undefined; }
    return p;
  }

  // ── 쿠키 ──
  function cookieUrl(d) {
    if (d && d.url) return String(d.url);
    if (d && d.domain) return "https://" + String(d.domain).replace(/^\./, "") + "/";
    return "";
  }
  function cookieList(d) {
    var u = cookieUrl(d);
    if (!u) return [];
    var l; try { l = JSON.parse(B.cookieget(ID, u, T)); } catch (e) { return []; }
    return l.filter(function (c) { return !d.name || c.name === d.name; });
  }
  function cookieWrite(d, rm) {
    var o = clone(d || {}); if (rm) o.remove = true;
    var r = parseJ(B.cookieset(ID, JSON.stringify(o), T));
    if (!r) throw new Error("Invalid cookie");
    if (r.error) throw new Error(r.error);
    return r;
  }

  // ── declarativeNetRequest (요청 차단 규칙) ──
  function dnrGet(kind) { return parseJ(B.dnrget(ID, kind, T)) || []; }
  function dnrUpd(kind, o, args) {
    return cb(args, function () {
      var r = parseJ(B.dnrupd(ID, kind, str(o || {}), T));
      if (r && r.error) throw new Error(r.error);
    });
  }

  var runtime = ns({
    id: ID,
    lastError: undefined,
    getURL: function (p) { return BASE + String(p).replace(/^\//, ""); },
    getManifest: function () { return localize(clone(M)); },
    getContexts: function () {
      return cb(arguments, function () {
        return offUrl ? [{ contextType: "OFFSCREEN_DOCUMENT", contextId: "evx-off", documentUrl: offUrl, tabId: -1, windowId: -1, frameId: -1, incognito: false }] : [];
      });
    },
    getPlatformInfo: function () { return cb(arguments, function () { return { os: "android", arch: "arm64", nacl_arch: "arm" }; }); },
    sendMessage: function () {
      var a = [].slice.call(arguments), done = null;
      if (typeof a[a.length - 1] === "function") done = a.pop();
      if (a.length >= 2 && typeof a[0] === "string" && /^[a-p]{32}$/.test(a[0])) a.shift();
      var m = a[0];
      var p = ask(function (cid) {
        if (window.__evxIsBg) B.bgbcast(ID, str(m), T, cid); else B.send(ID, str(m), location.href, T, cid);
      }).then(function (j) { if (j === "") lg("메시지 응답 없음", WHERE + " → " + msgName(m)); return parseJ(j); });
      return withCb(done, p);
    },
    connect: function () {
      var a = [].slice.call(arguments), info = {};
      if (typeof a[0] === "string") a.shift(); // 확장 프로그램 id
      if (a[0] && typeof a[0] === "object") info = a[0];
      var pid = rid(), out = window.__evxIsBg ? toPages : toBg;
      var p = mkPort(pid, info.name, undefined, out);
      out(envOf("open", pid, { name: p.name }));
      return p;
    },
    openOptionsPage: function () {
      var o = (M.options_ui && M.options_ui.page) || M.options_page;
      if (o) openTab(o);
      return cb(arguments, function () {});
    },
    reload: function () {},
    onMessage: shared("om"), onConnect: shared("oc"), onInstalled: ev(), onStartup: ev(), onSuspend: ev(), onUpdateAvailable: ev(),
    onSuspendCanceled: ev(), onConnectExternal: ev(), onMessageExternal: ev(), onRestartRequired: ev(), onBrowserUpdateAvailable: ev(),
    setUninstallURL: function () { return cb(arguments, function () { }); },
    requestUpdateCheck: function () { return cb(arguments, function () { return { status: "no_update" }; }); },
    restart: function () { }, restartAfterDelay: function () { return cb(arguments, function () { }); },
    getBackgroundPage: function () { return cb(arguments, function () { return null; }); },
    PlatformOs: { MAC: "mac", WIN: "win", ANDROID: "android", CROS: "cros", LINUX: "linux", OPENBSD: "openbsd" },
    PlatformArch: { ARM: "arm", ARM64: "arm64", X86_32: "x86-32", X86_64: "x86-64" },
    OnInstalledReason: { INSTALL: "install", UPDATE: "update", CHROME_UPDATE: "chrome_update", SHARED_MODULE_UPDATE: "shared_module_update" },
    ContextType: { TAB: "TAB", POPUP: "POPUP", BACKGROUND: "BACKGROUND", OFFSCREEN_DOCUMENT: "OFFSCREEN_DOCUMENT", SIDE_PANEL: "SIDE_PANEL" }
  });

  // ── webRequest (백그라운드 전용): 앱이 요청마다 __evxWr 로 불러 준다 ──
  var WRL = {};
  function wrEv(name) {
    var L = WRL[name] || (WRL[name] = []);
    return {
      addListener: function (f, filter, extra) {
        if (typeof f !== "function") return;
        extra = Array.isArray(extra) ? extra : [];
        var e = { f: f, lid: rid(), blocking: extra.indexOf("blocking") >= 0 || extra.indexOf("asyncBlocking") >= 0, async: extra.indexOf("asyncBlocking") >= 0 };
        L.push(e);
        try { B.wrreg(ID, name, JSON.stringify(filter || {}), e.lid, e.blocking, T); } catch (x) { }
      },
      removeListener: function (f) {
        for (var i = 0; i < L.length; i++) if (L[i].f === f) { try { B.wrunreg(ID, L[i].lid, T); } catch (x) { } L.splice(i, 1); return; }
      },
      hasListener: function (f) { return L.some(function (e) { return e.f === f; }); },
      hasListeners: function () { return L.length > 0; }
    };
  }
  var webRequest = null;
  if (window.__evxIsBg) {
    webRequest = ns({
      onBeforeRequest: wrEv("onBeforeRequest"), onBeforeSendHeaders: wrEv("onBeforeSendHeaders"), onSendHeaders: wrEv("onSendHeaders"),
      onHeadersReceived: wrEv("onHeadersReceived"), onBeforeRedirect: wrEv("onBeforeRedirect"), onResponseStarted: wrEv("onResponseStarted"),
      onCompleted: wrEv("onCompleted"), onErrorOccurred: wrEv("onErrorOccurred"), onAuthRequired: wrEv("onAuthRequired"),
      handlerBehaviorChanged: function () { return cb(arguments, function () { }); },
      MAX_HANDLER_BEHAVIOR_CHANGED_CALLS_PER_10_MINUTES: 20
    });
    window.__evxWr = function (name, dj, id, lids, wait) {
      var d = parseJ(dj) || {}, out = {}, p = Promise.resolve();
      (WRL[name] || []).filter(function (e) { return lids.indexOf(e.lid) >= 0; }).forEach(function (e) {
        p = p.then(function () {
          var r;
          try {
            if (e.async) r = new Promise(function (res) { var x = e.f(clone(d), res); if (x && typeof x === "object" && typeof x.then !== "function") res(x); });
            else r = e.f(clone(d));
          } catch (x) { console.error(x); return; }
          if (!e.blocking) return;
          return Promise.resolve(r).then(function (v) {
            if (!v || typeof v !== "object") return;
            if (v.cancel) out.cancel = true;
            if (v.redirectUrl) out.redirectUrl = v.redirectUrl;
            if (v.authCredentials) out.authCredentials = v.authCredentials;
            if (v.requestHeaders) { out.requestHeaders = v.requestHeaders; d.requestHeaders = v.requestHeaders; }
            if (v.responseHeaders) { out.responseHeaders = v.responseHeaders; d.responseHeaders = v.responseHeaders; }
          }, function () { });
        });
      });
      p.then(function () { if (wait) { try { B.wrres(ID, id, JSON.stringify(out), T); } catch (x) { } } });
    };
  }

  // ── contextMenus: 항목은 앱이 저장해 두고, 링크 · 이미지 길게 누르기 메뉴에 보여 준다 ──
  var CM = null, cmHandlers = {}, cmClick = ev();
  function cmList() { if (!CM) { CM = parseJ(B.cmget(ID, T)); if (!Array.isArray(CM)) CM = []; } return CM; }
  function cmSave() { try { B.cmset(ID, JSON.stringify(CM || []), T); } catch (x) { } }
  function cmIndex(id) { var l = cmList(); for (var i = 0; i < l.length; i++) if (String(l[i].id) === String(id)) return i; return -1; }
  var contextMenus = ns({
    create: function (p, done) {
      p = p || {};
      var id = p.id != null ? p.id : "evx_" + rid(), o = {};
      Object.keys(p).forEach(function (k) { if (typeof p[k] !== "function") o[k] = p[k]; });
      o.id = id;
      if (typeof p.onclick === "function") cmHandlers[String(id)] = p.onclick;
      var i = cmIndex(id);
      if (i >= 0) cmList()[i] = o; else cmList().push(o);
      cmSave();
      if (typeof done === "function") setTimeout(function () { try { done(); } catch (x) { } }, 0);
      return id;
    },
    update: function (id, p) {
      var a = arguments;
      return cb(a, function () {
        var i = cmIndex(id);
        if (i < 0) throw new Error("Cannot find menu item with id " + id);
        Object.keys(p || {}).forEach(function (k) { if (typeof p[k] !== "function") cmList()[i][k] = p[k]; else if (k === "onclick") cmHandlers[String(id)] = p[k]; });
        cmSave();
      });
    },
    remove: function (id) {
      var a = arguments;
      return cb(a, function () {
        var i = cmIndex(id);
        if (i < 0) throw new Error("Cannot find menu item with id " + id);
        cmList().splice(i, 1); delete cmHandlers[String(id)]; cmSave();
      });
    },
    removeAll: function () { return cb(arguments, function () { CM = []; cmHandlers = {}; cmSave(); }); },
    onClicked: cmClick, ACTION_MENU_TOP_LEVEL_LIMIT: 6,
    ContextType: { ALL: "all", PAGE: "page", FRAME: "frame", SELECTION: "selection", LINK: "link", EDITABLE: "editable", IMAGE: "image", VIDEO: "video", AUDIO: "audio", LAUNCHER: "launcher", BROWSER_ACTION: "browser_action", PAGE_ACTION: "page_action", ACTION: "action" },
    ItemType: { NORMAL: "normal", CHECKBOX: "checkbox", RADIO: "radio", SEPARATOR: "separator" }
  });
  if (window.__evxIsBg) {
    window.__evxActClick = function (tj) { lg("툴바 실행", "onClicked 리스너 " + actClick._a().length + "개 호출"); actClick._d([parseJ(tj)]); };
    window.__evxCmClick = function (ij, tj) {
      var i = parseJ(ij), t = parseJ(tj), h = cmHandlers[String(i && i.menuItemId)];
      if (h) { try { h(i, t); } catch (x) { console.error(x); } }
      cmClick._d([i, t]);
    };
  }

  // 툴바 버튼(action · browserAction · pageAction): 팝업이 없으면 버튼을 눌렀을 때 onClicked 가 불린다
  var actClick = ev(), actPopup = null;
  (function () {
    var add = actClick.addListener;
    actClick.addListener = function (f) { add(f); if (window.__evxIsBg) { try { B.actlisten(ID, T); } catch (e) { } } };
  })();
  var A0 = M.action || M.browser_action || M.page_action || {};
  var action = ns({
    onClicked: actClick,
    setPopup: function (d) { return cb(arguments, function () { if (d && typeof d.popup === "string") { actPopup = d.popup; try { B.actpopup(ID, d.popup, T); } catch (e) { } } }); },
    getPopup: function () { return cb(arguments, function () { return actPopup != null ? actPopup : (A0.default_popup || ""); }); },
    getTitle: function () { return cb(arguments, function () { return A0.default_title || M.name || ""; }); },
    getBadgeText: function () { return cb(arguments, function () { return ""; }); },
    isEnabled: function () { return cb(arguments, function () { return true; }); },
    openPopup: function () { return cb(arguments, function () { }); }
  });
  var C = {
    action: action, browserAction: action, pageAction: action,
    runtime: runtime,
    extension: ns({
      getURL: runtime.getURL, inIncognitoContext: false, lastError: undefined,
      getBackgroundPage: function () { return null; }, getViews: function () { return []; },
      isAllowedIncognitoAccess: function () { return cb(arguments, function () { return false; }); }
    }),
    storage: ns({
      local: area("local"), sync: area("sync"), session: area("session"), managed: area("managed"),
      onChanged: shared("ch")
    }),
    i18n: ns({
      getMessage: function (n, s) {
        var m = MSG[String(n).toLowerCase()];
        if (m == null) return "";
        if (s == null) s = []; else if (!Array.isArray(s)) s = [s];
        return m.replace(/\$(\d)/g, function (_, i) { var v = s[+i - 1]; return v == null ? "" : v; }).replace(/\$\$/g, "$");
      },
      getUILanguage: function () { return navigator.language; },
      getAcceptLanguages: function () { return cb(arguments, function () { return (navigator.languages || [navigator.language]).slice(); }); }
    }),
    tabs: ns({
      create: function (o) { openTab(o && o.url); return cb(arguments, function () { return { id: 2, url: o && o.url, active: true }; }); },
      query: function () {
        return cb(arguments, function () { try { return JSON.parse(B.tabinfo(ID, T)); } catch (e) { return []; } });
      },
      get: function () { return cb(arguments, function () { try { return JSON.parse(B.tabinfo(ID, T))[0]; } catch (e) { return undefined; } }); },
      getCurrent: function () { return cb(arguments, function () { return undefined; }); },
      update: function () {
        var x = tabArgs(arguments), u = x.d && x.d.url;
        if (u) tabCmd("nav", String(u));
        return cb(arguments, function () { return { id: 1, active: true, url: u || "" }; });
      },
      reload: function () { tabCmd("reload"); return cb(arguments, function () { }); },
      goBack: function () { tabCmd("back"); return cb(arguments, function () { }); },
      goForward: function () { tabCmd("forward"); return cb(arguments, function () { }); },
      connect: function (tabId, info) {
        info = info && typeof info === "object" ? info : {};
        var pid = rid(), p = mkPort(pid, info.name, undefined, toTab);
        toTab(envOf("open", pid, { name: p.name }));
        return p;
      },
      executeScript: function () {
        var x = tabArgs(arguments), d = x.d;
        var p = tabExec({ kind: "js", code: d.code || null, files: d.file ? [d.file] : null });
        return withCb(x.done, p);
      },
      insertCSS: function () {
        var x = tabArgs(arguments), d = x.d;
        var p = tabExec({ kind: "css", css: d.code || null, files: d.file ? [d.file] : null }).then(function () { });
        return withCb(x.done, p);
      },
      removeCSS: function () {
        var x = tabArgs(arguments), d = x.d;
        var p = tabExec({ kind: "rmcss", css: d.code || null, files: d.file ? [d.file] : null }).then(function () { });
        return withCb(x.done, p);
      },
      sendMessage: function () {
        var a = [].slice.call(arguments), done = null;
        if (typeof a[a.length - 1] === "function") done = a.pop();
        var m = a[1];
        var p = ask(function (cid) { B.tabsend(ID, str(m), T, cid); }).then(function (j) { if (j === "") lg("탭 메시지 응답 없음", "tabs.sendMessage → " + msgName(m)); return parseJ(j); });
        return withCb(done, p);
      }
    }),
    alarms: alarms,
    offscreen: ns({
      createDocument: function (o) {
        var a = arguments, u = "";
        try { u = new URL(String((o && o.url) || ""), BASE).href; } catch (e) { }
        if (offUrl) return Promise.reject(new Error("Only a single offscreen document may be created."));
        offUrl = u;
        var p = ask(function (cid) { B.offcreate(ID, u, T, cid); }, 15000).then(function () { });
        return withCb(typeof a[a.length - 1] === "function" ? a[a.length - 1] : null, p);
      },
      closeDocument: function () { offUrl = null; try { B.offclose(ID, T); } catch (e) { } return cb(arguments, function () { }); },
      hasDocument: function () { return cb(arguments, function () { return !!offUrl; }); },
      Reason: {}
    }),
    webNavigation: ns({
      getAllFrames: function () {
        return cb(arguments, function () {
          var t = null; try { t = JSON.parse(B.tabinfo(ID, T))[0]; } catch (e) { }
          return t ? [{ frameId: 0, parentFrameId: -1, url: t.url || "", errorOccurred: false, documentId: "0", documentLifecycle: "active", frameType: "outermost_frame" }] : [];
        });
      },
      getFrame: function () {
        return cb(arguments, function () {
          var t = null; try { t = JSON.parse(B.tabinfo(ID, T))[0]; } catch (e) { }
          return t ? { parentFrameId: -1, url: t.url || "", errorOccurred: false, documentId: "0", documentLifecycle: "active", frameType: "outermost_frame" } : null;
        });
      },
      onBeforeNavigate: ev(), onCommitted: ev(), onDOMContentLoaded: ev(), onCompleted: ev(), onErrorOccurred: ev(),
      onHistoryStateUpdated: ev(), onReferenceFragmentUpdated: ev(), onCreateNavigationTarget: ev(), onTabReplaced: ev()
    }),
    scripting: ns({
      executeScript: function (inj) {
        inj = inj || {};
        var last = arguments[arguments.length - 1];
        var p = tabExec({
          kind: "js", files: inj.files || null, args: inj.args || [],
          func: typeof inj.func === "function" ? String(inj.func) : null
        }).then(function (arr) { return arr.map(function (v) { return { frameId: 0, documentId: "0", result: v }; }); });
        return withCb(last, p);
      },
      insertCSS: function (inj) {
        inj = inj || {};
        var p = tabExec({ kind: "css", css: inj.css || null, files: inj.files || null }).then(function () { });
        return withCb(arguments[arguments.length - 1], p);
      },
      removeCSS: function (inj) {
        inj = inj || {};
        var p = tabExec({ kind: "rmcss", css: inj.css || null, files: inj.files || null }).then(function () { });
        return withCb(arguments[arguments.length - 1], p);
      }
    }),
    windows: ns({
      getCurrent: function () { var a = arguments; return cb(a, function () { return winOf(a); }); },
      getLastFocused: function () { var a = arguments; return cb(a, function () { return winOf(a); }); },
      getAll: function () { var a = arguments; return cb(a, function () { return [winOf(a)]; }); },
      create: function (o) {
        var u = o && o.url;
        var us = Array.isArray(u) ? u : (u ? [u] : []);
        us.forEach(openTab);
        // 확장이 w.tabs[0].id 처럼 바로 읽으므로 열린 탭 목록을 같이 돌려준다
        return cb(arguments, function () {
          var tabs = us.map(function (x, i) { return { id: 2 + i, index: i, windowId: 2, active: i === 0, highlighted: i === 0, incognito: false, url: x, pendingUrl: x, status: "complete", title: "" }; });
          if (!tabs.length) tabs.push({ id: 2, index: 0, windowId: 2, active: true, highlighted: true, incognito: false, url: "about:blank", status: "complete", title: "" });
          return { id: 2, focused: true, type: (o && o.type) || "normal", state: "normal", incognito: false, alwaysOnTop: false, tabs: tabs };
        });
      },
      WINDOW_ID_NONE: -1, WINDOW_ID_CURRENT: -2
    }),
    cookies: ns({
      get: function (d) { var a = arguments; return cb(a, function () { return cookieList(d)[0] || null; }); },
      getAll: function (d) { var a = arguments; return cb(a, function () { return cookieList(d || {}); }); },
      set: function (d) { var a = arguments; return cb(a, function () { return cookieWrite(d, false); }); },
      remove: function (d) { var a = arguments; return cb(a, function () { cookieWrite(d, true); return { url: d && d.url, name: d && d.name, storeId: "0" }; }); },
      getAllCookieStores: function () { return cb(arguments, function () { return [{ id: "0", tabIds: [1] }]; }); },
      onChanged: ev()
    }),
    declarativeNetRequest: ns({
      updateDynamicRules: function (o) { return dnrUpd("dynamic", o, arguments); },
      updateSessionRules: function (o) { return dnrUpd("session", o, arguments); },
      updateEnabledRulesets: function (o) { return dnrUpd("rulesets", o, arguments); },
      getDynamicRules: function () { return cb(arguments, function () { return dnrGet("dynamic"); }); },
      getSessionRules: function () { return cb(arguments, function () { return dnrGet("session"); }); },
      getEnabledRulesets: function () { return cb(arguments, function () { return dnrGet("rulesets"); }); },
      getAvailableStaticRuleCount: function () { return cb(arguments, function () { return 30000; }); },
      isRegexSupported: function () { return cb(arguments, function () { return { isSupported: true }; }); },
      getMatchedRules: function () { return cb(arguments, function () { return { rulesMatchedInfo: [] }; }); },
      MAX_NUMBER_OF_DYNAMIC_RULES: 30000, MAX_NUMBER_OF_SESSION_RULES: 5000, MAX_NUMBER_OF_ENABLED_STATIC_RULESETS: 50,
      RuleActionType: { BLOCK: "block", REDIRECT: "redirect", ALLOW: "allow", UPGRADE_SCHEME: "upgradeScheme", MODIFY_HEADERS: "modifyHeaders", ALLOW_ALL_REQUESTS: "allowAllRequests" },
      ResourceType: {
        MAIN_FRAME: "main_frame", SUB_FRAME: "sub_frame", STYLESHEET: "stylesheet", SCRIPT: "script", IMAGE: "image", FONT: "font",
        OBJECT: "object", XMLHTTPREQUEST: "xmlhttprequest", PING: "ping", CSP_REPORT: "csp_report", MEDIA: "media", WEBSOCKET: "websocket", OTHER: "other"
      },
      DomainType: { FIRST_PARTY: "firstParty", THIRD_PARTY: "thirdParty" }
    }),
    webRequest: webRequest || ns({}),
    contextMenus: contextMenus, menus: contextMenus,
    permissions: ns({
      contains: function () { return cb(arguments, function () { return true; }); },
      request: function () { return cb(arguments, function () { return true; }); },
      getAll: function () { return cb(arguments, function () { return { permissions: M.permissions || [], origins: [] }; }); }
    })
  };
  // ── 앱이 지원하는 만큼 채운 API ──
  // 호출해도 아무 일도 없는 '빈 stub' 은 undefined 를 돌려줘서, 결과를 .map / .length / .value 로 쓰는 확장 프로그램이 죽는다.
  // 그래서 크롬과 같은 모양(빈 목록 · 기본값)의 값을 돌려주고, 앱에 같은 기능이 있으면(기록 · 북마크 · 다운로드 · 알림) 실제로 이어 준다.
  function appData(kind, arg) { try { return JSON.parse(B.appdata(ID, kind, arg || "", T) || "[]"); } catch (e) { return []; } }
  function appCmd(kind, arg) { try { B.appcmd(ID, kind, typeof arg === "string" ? arg : JSON.stringify(arg), T); } catch (e) { } }
  function nop() { return cb(arguments, function () { }); }
  function ret(v) { return function () { var c = typeof v === "function" ? v : function () { return clone(v); }; return cb(arguments, c); }; }
  // 크롬 설정(chrome.privacy · chrome.proxy): 값은 바꿀 수 없고 기본값만 알려 준다
  function setting(def) {
    return { get: ret(function () { return { value: def, levelOfControl: "not_controllable" }; }), set: nop, clear: nop, onChange: ev() };
  }
  function settingsNs(def) {
    return new Proxy({}, { get: function (t, k) { return typeof k === "symbol" || k === "then" ? undefined : setting(def); } });
  }

  // 탭 · 이동 이벤트 (보고 있는 탭 하나만, id 는 항상 1). 앱이 페이지를 불러오기 시작 · 끝낼 때 알려 준다
  var TEV = {
    onUpdated: ev(), onActivated: ev(), onCreated: ev(), onRemoved: ev(), onReplaced: ev(), onMoved: ev(),
    onHighlighted: ev(), onAttached: ev(), onDetached: ev(), onZoomChange: ev(), onActiveChanged: ev(), onSelectionChanged: ev()
  };
  Object.keys(TEV).forEach(function (k) { C.tabs[k] = TEV[k]; });
  var TABX = {
    TAB_ID_NONE: -1, TabStatus: { LOADING: "loading", COMPLETE: "complete", UNLOADED: "unloaded" },
    WindowType: { NORMAL: "normal", POPUP: "popup", PANEL: "panel", APP: "app", DEVTOOLS: "devtools" },
    MutedInfoReason: { USER: "user", CAPTURE: "capture", EXTENSION: "extension" },
    detectLanguage: ret(function () { return (navigator.language || "en").split("-")[0]; }),
    getZoom: ret(1), setZoom: nop, getZoomSettings: ret({ mode: "automatic", scope: "per-origin", defaultZoomFactor: 1 }), setZoomSettings: nop,
    duplicate: function (id) { var u = ""; try { u = JSON.parse(B.tabinfo(ID, T))[0].url; } catch (e) { } if (u) openTab(u); return cb(arguments, function () { return { id: 2, url: u, active: true }; }); },
    remove: nop, move: ret([]), highlight: ret({ id: 1, focused: true, type: "normal", incognito: false }), discard: nop, group: ret(1), ungroup: nop,
    captureVisibleTab: function () { return Promise.reject(new Error("이 앱에서는 화면 캡처를 지원하지 않아요")); },
    getSelected: function () { return cb(arguments, function () { try { return JSON.parse(B.tabinfo(ID, T))[0]; } catch (e) { return undefined; } }); }
  };
  Object.keys(TABX).forEach(function (k) { C.tabs[k] = TABX[k]; });
  C.windows.get = ret({ id: 1, focused: true, type: "normal", state: "maximized", incognito: false });
  C.windows.update = ret({ id: 1, focused: true, type: "normal", state: "maximized", incognito: false });
  C.windows.remove = nop;
  C.windows.onCreated = ev(); C.windows.onRemoved = ev(); C.windows.onFocusChanged = ev(); C.windows.onBoundsChanged = ev();
  C.windows.WindowType = TABX.WindowType;
  C.permissions.remove = ret(true);
  C.permissions.onAdded = ev(); C.permissions.onRemoved = ev();
  C.permissions.contains = function () { return cb(arguments, function () { return true; }); };

  // ── 호환성 보강: 빈 stub 은 undefined 를 돌려줘서 결과를 .map / .length / .forEach 로 쓰는 확장 프로그램이 죽는다 → 크롬과 같은 모양의 값을 돌려준다 ──
  // scripting 의 동적 콘텐츠 스크립트: 등록 목록만 기억한다 (페이지에 실제로 넣지는 못하지만 manifest 의 content_scripts 는 그대로 동작한다)
  var RCS = [];
  C.scripting.registerContentScripts = function (list) {
    var a = arguments;
    return cb(a, function () {
      (Array.isArray(list) ? list : []).forEach(function (x) {
        if (!x || x.id == null) return;
        if (RCS.some(function (r) { return r.id === x.id; })) throw new Error("Duplicate script ID '" + x.id + "'");
        RCS.push(clone(x));
      });
    });
  };
  C.scripting.updateContentScripts = function (list) {
    var a = arguments;
    return cb(a, function () {
      (Array.isArray(list) ? list : []).forEach(function (x) {
        for (var i = 0; i < RCS.length; i++) if (x && RCS[i].id === x.id) RCS[i] = Object.assign(RCS[i], clone(x));
      });
    });
  };
  C.scripting.unregisterContentScripts = function (f) {
    var a = arguments;
    return cb(a, function () {
      var ids = f && Array.isArray(f.ids) ? f.ids : null;
      RCS = ids ? RCS.filter(function (r) { return ids.indexOf(r.id) < 0; }) : [];
    });
  };
  C.scripting.getRegisteredContentScripts = function (f) {
    var a = arguments;
    return cb(a, function () {
      var ids = f && Array.isArray(f.ids) ? f.ids : null;
      return clone(RCS.filter(function (r) { return !ids || ids.indexOf(r.id) >= 0; })) || [];
    });
  };
  C.scripting.ExecutionWorld = { ISOLATED: "ISOLATED", MAIN: "MAIN" };
  C.scripting.StyleOrigin = { AUTHOR: "AUTHOR", USER: "USER" };

  C.tabGroups = ns({
    get: ret(undefined), query: ret([]), update: ret(undefined), move: ret(undefined),
    onCreated: ev(), onUpdated: ev(), onMoved: ev(), onRemoved: ev(),
    TAB_GROUP_ID_NONE: -1,
    Color: { GREY: "grey", BLUE: "blue", RED: "red", YELLOW: "yellow", GREEN: "green", PINK: "pink", PURPLE: "purple", CYAN: "cyan", ORANGE: "orange" }
  });
  C.declarativeContent = ns({
    onPageChanged: { addRules: ret([]), removeRules: nop, getRules: ret([]), addListener: function () { }, removeListener: function () { }, hasListener: function () { return false; }, hasListeners: function () { return false; } },
    PageStateMatcher: function (o) { this.options = o; },
    ShowAction: function () { }, ShowPageAction: function () { }, SetIcon: function (o) { this.options = o; }, RequestContentScript: function (o) { this.options = o; }
  });
  C.readingList = ns({ query: ret([]), addEntry: nop, removeEntry: nop, updateEntry: nop, onEntryAdded: ev(), onEntryRemoved: ev(), onEntryUpdated: ev() });
  C.userScripts = ns({
    register: nop, unregister: nop, update: nop, getScripts: ret([]), configureWorld: nop, resetWorldConfiguration: nop, getWorldConfigurations: ret([])
  });
  C.contentSettings = ns({});
  ["cookies", "images", "javascript", "location", "microphone", "camera", "notifications", "popups", "plugins", "automaticDownloads", "fullscreen", "mouselock", "unsandboxedPlugins"].forEach(function (k) {
    C.contentSettings[k] = { get: ret({ setting: "allow" }), set: nop, clear: nop, getResourceIdentifiers: ret([]) };
  });
  C.dns = ns({ resolve: ret({ resultCode: 1 }) });
  C.wallpaper = ns({}); C.vpnProvider = ns({}); C.printerProvider = ns({});

  // 네이티브 메시징 호스트는 앱에 없다: 크롬이 '호스트 없음' 일 때와 같은 오류를 돌려준다
  C.runtime.sendNativeMessage = function () {
    var a = arguments, e = new Error("Specified native messaging host not found.");
    return cb(a, function () { throw e; });
  };
  C.runtime.connectNative = function () {
    var p = mkPort(rid(), "native", undefined, function () { });
    setTimeout(function () { try { p._in("close"); } catch (x) { } }, 0);
    return p;
  };

  // 웹뷰에는 개발자 도구 · 크롬 디버거 · 화면 녹화가 없다: 확장 프로그램이 멈추지 않도록 크롬이 '할 수 없음' 일 때처럼 오류로 알려 준다
  function unavail(msg) { return function () { var a = arguments; return cb(a, function () { throw new Error(msg); }); }; }
  C.debugger = ns({
    attach: unavail("Cannot attach to this target: 이 앱에서는 디버거를 지원하지 않아요"),
    detach: nop,
    sendCommand: unavail("Debugger is not attached to the tab: 이 앱에서는 디버거를 지원하지 않아요"),
    getTargets: ret([]),
    onEvent: ev(), onDetach: ev()
  });
  C.devtools = ns({
    inspectedWindow: ns({
      tabId: 1,
      eval: function () { var a = arguments; return cb(a, function () { return [undefined, { isError: true, code: "E_NOTSUPPORTED", description: "이 앱에서는 개발자 도구를 지원하지 않아요" }]; }); },
      reload: nop, getResources: ret([]), onResourceAdded: ev(), onResourceContentCommitted: ev()
    }),
    network: ns({ getHAR: ret({ entries: [] }), onNavigated: ev(), onRequestFinished: ev() }),
    panels: ns({ create: unavail("이 앱에서는 개발자 도구 패널을 지원하지 않아요"), themeName: "default", onThemeChanged: ev() })
  });
  C.tabCapture = ns({
    capture: unavail("Cannot capture tab: 이 앱에서는 탭 녹화를 지원하지 않아요"),
    captureOffscreenTab: unavail("이 앱에서는 탭 녹화를 지원하지 않아요"),
    getMediaStreamId: unavail("Cannot capture tab: 이 앱에서는 탭 녹화를 지원하지 않아요"),
    getCapturedTabs: ret([]),
    onStatusChanged: ev()
  });
  C.desktopCapture = ns({
    // 크롬에서 사용자가 선택 창을 닫은 것과 같게: 빈 스트림 ID 를 돌려준다
    chooseDesktopMedia: function () {
      var a = [].slice.call(arguments), done = typeof a[a.length - 1] === "function" ? a[a.length - 1] : null;
      if (done) setTimeout(function () { try { done("", {}); } catch (e) { console.error(e); } }, 0);
      return 1;
    },
    cancelChooseDesktopMedia: nop
  });

  C.history = ns({
    search: function (q) {
      var a = arguments;
      return cb(a, function () {
        q = q && typeof q === "object" ? q : {};
        var s = q.startTime == null ? 0 : +q.startTime, e = q.endTime == null ? Infinity : +q.endTime, m = q.maxResults == null ? 100 : +q.maxResults;
        return appData("history", q.text || "").filter(function (h) { return h.lastVisitTime >= s && h.lastVisitTime <= e; }).slice(0, m);
      });
    },
    getVisits: function (d) {
      return cb(arguments, function () {
        var u = d && d.url;
        return appData("history", u || "").filter(function (h) { return h.url === u; })
          .map(function (h) { return { id: h.id, visitId: h.id, visitTime: h.lastVisitTime, referringVisitId: "0", transition: "link" }; });
      });
    },
    addUrl: nop, deleteUrl: nop, deleteRange: nop, deleteAll: nop,
    onVisited: ev(), onVisitRemoved: ev()
  });

  function bmNode(b) { return { id: b.id, parentId: "1", index: 0, title: b.title || "", url: b.url, dateAdded: 0 }; }
  C.bookmarks = ns({
    getTree: ret(function () { return [{ id: "0", title: "", children: [{ id: "1", parentId: "0", title: "북마크", dateAdded: 0, children: appData("bookmarks").map(bmNode) }, { id: "2", parentId: "0", title: "기타 북마크", dateAdded: 0, children: [] }] }]; }),
    getSubTree: ret(function () { return [{ id: "1", parentId: "0", title: "북마크", dateAdded: 0, children: appData("bookmarks").map(bmNode) }]; }),
    getChildren: function (id) { return cb(arguments, function () { return String(id) === "1" ? appData("bookmarks").map(bmNode) : []; }); },
    getRecent: function (n) { return cb(arguments, function () { return appData("bookmarks").map(bmNode).slice(0, +n || 10); }); },
    get: function (ids) {
      return cb(arguments, function () {
        var want = (Array.isArray(ids) ? ids : [ids]).map(String);
        return appData("bookmarks").map(bmNode).filter(function (b) { return want.indexOf(String(b.id)) >= 0; });
      });
    },
    search: function (q) {
      return cb(arguments, function () {
        var o = typeof q === "string" ? { query: q } : (q || {}), t = String(o.query || "").toLowerCase();
        return appData("bookmarks").map(bmNode).filter(function (b) {
          return (!t || (b.title + " " + b.url).toLowerCase().indexOf(t) >= 0) && (!o.url || b.url === o.url) && (!o.title || b.title === o.title);
        });
      });
    },
    // 앱 북마크는 확장 프로그램이 바꿀 수 없다: 오류 없이 돌려주기만 한다
    create: function (o) { return cb(arguments, function () { o = o || {}; return { id: "evx_" + rid(), parentId: "1", index: 0, title: o.title || "", url: o.url, dateAdded: Date.now() }; }); },
    update: function (id, ch) { return cb(arguments, function () { return { id: String(id), title: (ch && ch.title) || "", url: ch && ch.url }; }); },
    remove: nop, removeTree: nop, move: ret({}),
    onCreated: ev(), onRemoved: ev(), onChanged: ev(), onMoved: ev(), onChildrenReordered: ev(), onImportBegan: ev(), onImportEnded: ev()
  });

  C.topSites = ns({
    get: ret(function () {
      var seen = {}, out = [];
      appData("history", "").forEach(function (h) {
        var o = ""; try { o = new URL(h.url).origin; } catch (e) { }
        if (o && !seen[o] && out.length < 10) { seen[o] = 1; out.push({ url: h.url, title: h.title || o }); }
      });
      return out;
    })
  });

  C.downloads = ns({
    // http(s) 주소만 앱 다운로드로 이어진다 (파일 이름 · 폴더 지정은 무시)
    download: function (o) {
      var u = o && o.url;
      if (u) appCmd("download", String(u));
      return cb(arguments, function () { return Math.floor(Date.now() % 100000000); });
    },
    search: ret([]), erase: ret([]), getFileIcon: ret(""),
    pause: nop, resume: nop, cancel: nop, open: nop, show: nop, showDefaultFolder: nop, removeFile: nop, acceptDanger: nop, setShelfEnabled: nop, setUiOptions: nop,
    onCreated: ev(), onChanged: ev(), onErased: ev(), onDeterminingFilename: ev()
  });

  C.notifications = ns({
    create: function () {
      var a = [].slice.call(arguments), id = null;
      if (typeof a[0] === "string") id = a.shift();
      var o = a[0] && typeof a[0] === "object" ? a[0] : {};
      if (id == null) id = "evx_" + rid();
      appCmd("notify", { title: String(o.title || ""), message: String(o.message || "") });
      return cb(arguments, function () { return id; });
    },
    update: ret(true), clear: ret(true), getAll: ret({}), getPermissionLevel: ret("granted"),
    onClicked: ev(), onClosed: ev(), onButtonClicked: ev(), onPermissionLevelChanged: ev(), onShowSettings: ev()
  });

  C.idle = ns({
    queryState: ret("active"), setDetectionInterval: nop, onStateChanged: ev()
  });

  function selfInfo() {
    return {
      id: ID, name: localize(M.name) || ID, shortName: localize(M.short_name || M.name) || ID, description: localize(M.description) || "",
      version: M.version || "1.0", mayDisable: true, enabled: true, isApp: false, type: "extension", installType: "normal",
      homepageUrl: M.homepage_url || "", offlineEnabled: false,
      optionsUrl: (M.options_ui && M.options_ui.page) || M.options_page ? BASE + String((M.options_ui && M.options_ui.page) || M.options_page).replace(/^\//, "") : "",
      permissions: (M.permissions || []).slice(), hostPermissions: (M.host_permissions || []).slice(), icons: []
    };
  }
  C.management = ns({
    getSelf: ret(function () { return selfInfo(); }),
    getAll: ret(function () { return [selfInfo()]; }),
    get: function (id) { return cb(arguments, function () { if (id !== ID) throw new Error("Failed to find extension with id " + id); return selfInfo(); }); },
    getPermissionWarningsById: ret([]), getPermissionWarningsByManifest: ret([]),
    setEnabled: nop, uninstall: nop, uninstallSelf: nop, launchApp: nop, createAppShortcut: nop, setLaunchType: nop, generateAppForLink: ret({}),
    onInstalled: ev(), onUninstalled: ev(), onEnabled: ev(), onDisabled: ev()
  });

  C.commands = ns({
    // 단축키는 터치 화면에서 쓸 수 없어서 목록만 알려 준다 (툴바 버튼으로 실행)
    getAll: ret(function () {
      var c = M.commands || {}, out = [];
      Object.keys(c).forEach(function (n) {
        var k = c[n] && c[n].suggested_key;
        out.push({ name: n, description: localize((c[n] && c[n].description) || ""), shortcut: (k && (k.android || k.default)) || "" });
      });
      return out;
    }),
    onCommand: ev(), onChanged: ev()
  });

  C.sessions = ns({
    getRecentlyClosed: ret([]), getDevices: ret([]), restore: ret({}),
    MAX_SESSION_RESULTS: 25, onChanged: ev()
  });

  C.system = ns({
    cpu: ns({ getInfo: ret(function () { return { numOfProcessors: navigator.hardwareConcurrency || 4, archName: "arm64", modelName: "", features: [], processors: [], temperatures: [] }; }) }),
    memory: ns({ getInfo: ret(function () { var g = (navigator.deviceMemory || 4) * 1073741824; return { capacity: g, availableCapacity: Math.floor(g / 2) }; }) }),
    display: ns({
      getInfo: ret(function () {
        var b = { left: 0, top: 0, width: screen.width || 0, height: screen.height || 0 };
        return [{ id: "0", name: "", isPrimary: true, isInternal: true, isEnabled: true, dpiX: 96, dpiY: 96, bounds: b, workArea: b, rotation: 0 }];
      }),
      onDisplayChanged: ev()
    }),
    storage: ns({ getInfo: ret([]), onAttached: ev(), onDetached: ev() })
  });

  C.tts = ns({
    speak: function (text) {
      try { if (window.speechSynthesis && text) window.speechSynthesis.speak(new SpeechSynthesisUtterance(String(text))); } catch (e) { }
      return cb(arguments, function () { });
    },
    stop: function () { try { window.speechSynthesis.cancel(); } catch (e) { } return cb(arguments, function () { }); },
    isSpeaking: ret(function () { try { return !!window.speechSynthesis.speaking; } catch (e) { return false; } }),
    getVoices: ret([]), pause: nop, resume: nop, onEvent: ev()
  });

  var authTokens = {};
  function redirectURL(p) { return "https://" + ID + ".chromiumapp.org/" + String(p || "").replace(/^\//, ""); }
  // 로그인 창(웹뷰)을 띄워 리디렉션 주소를 받는다 (최대 10분 기다림)
  function webAuth(url, interactive) {
    if (!url) return Promise.reject(new Error("Invalid URL."));
    return ask(function (cid) { B.authflow(ID, String(url), !!interactive, T, cid); }, 600000).then(function (j) {
      var r = parseJ(j);
      if (!r) throw new Error("The user did not approve access.");
      if (r.error) throw new Error(r.error);
      return r.url;
    });
  }
  function cbPromise(args, p) {
    var last = args[args.length - 1];
    if (typeof last !== "function") return p;
    p.then(function (v) { try { last(v); } catch (e) { console.error(e); } },
      function (e) { try { C.runtime.lastError = { message: e.message }; last(undefined); } catch (x) { console.error(x); } finally { C.runtime.lastError = undefined; } });
    return undefined;
  }

  C.identity = ns({
    getRedirectURL: function (p) { return redirectURL(p); },
    getProfileUserInfo: ret({ email: "", id: "" }),
    launchWebAuthFlow: function (d) {
      var args = arguments;
      var p = webAuth(d && d.url, !!(d && d.interactive));
      return cbPromise(args, p);
    },
    getAuthToken: function (d) {
      var args = arguments, o = M.oauth2 || {};
      var last = args[args.length - 1];
      var scopes = (d && d.scopes) || o.scopes || [];
      var p;
      if (!o.client_id) p = Promise.reject(new Error("OAuth2 request failed: Invalid OAuth2 Client ID."));
      else if (authTokens[o.client_id + scopes.join(" ")]) p = Promise.resolve(authTokens[o.client_id + scopes.join(" ")]);
      else {
        var url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + encodeURIComponent(o.client_id) +
          "&response_type=token&redirect_uri=" + encodeURIComponent(redirectURL("")) +
          "&scope=" + encodeURIComponent(scopes.join(" "));
        p = webAuth(url, !!(d && d.interactive)).then(function (u) {
          var h = String(u).split("#")[1] || "", m = /(?:^|&)access_token=([^&]+)/.exec(h);
          if (!m) throw new Error("OAuth2 request failed: Authorization page could not be loaded.");
          var g = /(?:^|&)scope=([^&]+)/.exec(h);
          var r = { token: decodeURIComponent(m[1]), grantedScopes: g ? decodeURIComponent(g[1]).split(" ") : scopes };
          authTokens[o.client_id + scopes.join(" ")] = r;
          return r;
        });
      }
      if (typeof last !== "function") return p;
      p.then(function (r) { try { last(r.token, r.grantedScopes); } catch (e) { console.error(e); } },
        function (e) { try { C.runtime.lastError = { message: e.message }; last(undefined); } catch (x) { console.error(x); } finally { C.runtime.lastError = undefined; } });
      return undefined;
    },
    removeCachedAuthToken: nop, clearAllCachedAuthTokens: nop,
    onSignInChanged: ev()
  });

  // 사이드 패널: 앱이 하단 시트(폰) · 옆 패널(태블릿)로 띄워 준다
  var spPath = (M.side_panel && M.side_panel.default_path) || "", spEnabled = true, spOnAction = false;
  C.pageCapture = ns({
    saveAsMHTML: function () { return pageCap(arguments); }
  });

  C.sidePanel = ns({
    setOptions: function (o) {
      return cb(arguments, function () {
        if (!o) return;
        if (typeof o.path === "string") spPath = o.path;
        if (typeof o.enabled === "boolean") spEnabled = o.enabled;
        try { B.sppath(ID, spEnabled ? spPath : "", T); } catch (e) { }
      });
    },
    getOptions: function () { return cb(arguments, function () { return { enabled: spEnabled, path: spPath }; }); },
    setPanelBehavior: function (o) {
      return cb(arguments, function () {
        if (o && typeof o.openPanelOnActionClick === "boolean") {
          spOnAction = o.openPanelOnActionClick;
          try { B.spbehavior(ID, spOnAction ? "1" : "0", T); } catch (e) { }
        }
      });
    },
    getPanelBehavior: function () { return cb(arguments, function () { return { openPanelOnActionClick: spOnAction }; }); },
    open: function () { return cb(arguments, function () { try { B.spopen(ID, T); } catch (e) { } }); }
  });
  C.omnibox = ns({
    setDefaultSuggestion: nop, sendSuggestions: function () { },
    onInputStarted: ev(), onInputChanged: ev(), onInputEntered: ev(), onInputCancelled: ev(), onDeleteSuggestion: ev()
  });
  C.search = ns({
    query: function (o) {
      var t = o && o.text;
      if (t) openTab("https://www.google.com/search?q=" + encodeURIComponent(t));
      return cb(arguments, function () { });
    }
  });
  C.browsingData = ns({
    settings: ret({ options: {}, dataToRemove: {}, dataRemovalPermitted: {} }),
    remove: nop, removeCache: nop, removeCookies: nop, removeHistory: nop, removeLocalStorage: nop, removeDownloads: nop, removeFormData: nop, removePasswords: nop
  });
  // chrome.proxy: 서버를 정하는 방식(fixed_servers · direct · 단순 PAC)은 앱의 웹뷰 프록시로 이어진다. 앱 전체에 하나만 적용된다
  var proxyChange = ev(), proxyErr = ev();
  function proxyInfo() { try { return JSON.parse(B.proxyget(ID, T) || "{}"); } catch (e) { return {}; } }
  function proxyCur() { var s = proxyInfo(); return { value: s.value || { mode: "system" }, levelOfControl: s.level || "controllable_by_this_extension" }; }
  function proxyNote() { var c = proxyCur(); c.incognitoSpecific = false; proxyChange._d([c]); }
  C.proxy = ns({
    settings: {
      get: function () { return cb(arguments, function () { return proxyCur(); }); },
      set: function (d) {
        var a = arguments;
        return cb(a, function () {
          var r = {};
          try { r = JSON.parse(B.proxyset(ID, JSON.stringify((d && d.value) || {}), T) || "{}"); } catch (e) { r = { error: String(e) }; }
          if (r.error) {
            setTimeout(function () { proxyErr._d([{ fatal: false, error: "net::ERR_NOT_IMPLEMENTED", details: String(r.error) }]); }, 0);
          } else {
            setTimeout(proxyNote, 0);
          }
          return undefined;
        });
      },
      clear: function () {
        return cb(arguments, function () { try { B.proxyclear(ID, T); } catch (e) { } setTimeout(proxyNote, 0); return undefined; });
      },
      onChange: proxyChange
    },
    onProxyError: proxyErr
  });
  C.privacy = ns({
    network: settingsNs("default"), services: settingsNs(false), websites: settingsNs(false)
  });
  C.power = ns({ requestKeepAwake: nop, releaseKeepAwake: nop });
  C.fontSettings = ns({
    getFontList: ret([]), getFont: ret({ fontId: "", levelOfControl: "not_controllable" }), setFont: nop, getDefaultFontSize: ret({ pixelSize: 16, levelOfControl: "not_controllable" })
  });
  C.i18n.detectLanguage = function (t) {
    return cb(arguments, function () { return { isReliable: false, languages: [{ language: (navigator.language || "en").split("-")[0], percentage: 100 }] }; });
  };

  if (window.__evxIsBg) {
    // 앱 → 백그라운드: 보고 있는 탭의 이동 · 로드 · 전환을 chrome.tabs / chrome.webNavigation 이벤트로 바꿔 준다
    window.__evxEvt = function (n, aj) {
      var d = parseJ(aj); if (!d) return;
      var now = Date.now(), url = String(d.url || "");
      var tab = { id: 1, index: 0, windowId: 1, active: true, highlighted: true, incognito: false, pinned: false, audible: false, discarded: false, autoDiscardable: true, groupId: -1,
        url: url, title: d.title || "", status: d.phase === "started" ? "loading" : "complete" };
      var nav = { tabId: 1, url: url, frameId: 0, parentFrameId: -1, processId: -1, timeStamp: now, documentId: "0", documentLifecycle: "active", frameType: "outermost_frame" };
      var wn = C.webNavigation;
      if (n === "activated") { TEV.onActivated._d([{ tabId: 1, windowId: 1 }]); TEV.onHighlighted._d([{ tabIds: [1], windowId: 1 }]); return; }
      if (d.phase === "started") {
        wn.onBeforeNavigate._d([nav]);
        wn.onCommitted._d([Object.assign({ transitionType: "link", transitionQualifiers: [] }, nav)]);
        TEV.onUpdated._d([1, { status: "loading", url: url }, tab]);
      } else if (d.phase === "finished") {
        wn.onDOMContentLoaded._d([nav]);
        wn.onCompleted._d([nav]);
        if (d.title) TEV.onUpdated._d([1, { title: d.title }, tab]);
        TEV.onUpdated._d([1, { status: "complete" }, tab]);
      }
    };
  }

  // 백그라운드 → 확장 프로그램 페이지(콘텐츠 스크립트 · 팝업) 메시지 받기 / 백그라운드가 받는 메시지 처리
  if (window.__evxIsBg) {
    window.__evxBgIn = function (cid, mj, sj) {
      var m = parseJ(mj);
      if (m && m.__evxPort === 1) { handlePort(m, parseJ(sj), toPages); B.bgresp(ID, cid, "", T); return; }
      var tries = 0, sd = parseJ(sj);
      // 백그라운드가 막 시작해서 아직 리스너를 달기 전이면 잠시 기다린다 (크롬은 서비스 워커가 깨어날 때까지 메시지를 붙잡아 둔다)
      (function go() {
        if (!runtime.onMessage.hasListeners() && tries++ < 80) { setTimeout(go, 100); return; }
        dispatch(runtime.onMessage, m, sd, function (v) { B.bgresp(ID, cid, v === undefined ? "" : JSON.stringify(v), T); });
      })();
    };
  } else {
    var LS = window.__evxLs;
    if (!LS) { LS = {}; try { Object.defineProperty(window, "__evxLs", { value: LS }); } catch (e) { } }
    LS[ID] = function (cid, mj, sj) {
      var m = parseJ(mj);
      if (m && m.__evxPort === 1) { handlePort(m, parseJ(sj), toBg); B.pageresp(ID, cid, "", T); return; }
      dispatch(runtime.onMessage, m, parseJ(sj), function (v) { B.pageresp(ID, cid, v === undefined ? "" : JSON.stringify(v), T); });
    };
    if (!window.__evxTabIn) {
      try {
        Object.defineProperty(window, "__evxTabIn", {
          value: function (ext, cid, mj, sj) {
            var f = window.__evxLs && window.__evxLs[ext];
            if (f) f(cid, mj, sj); else B.pageresp(ext, cid, "", T);
          }
        });
      } catch (e) { }
    }
  }

  // 백그라운드 페이지 전용: 서비스 워커 흉내 · CORS 없이 fetch · 시작 이벤트
  if (window.__evxIsBg && !window.__evxStarted) {
    window.__evxStarted = true;
    // 서비스 워커(MV3) 확장 프로그램의 백그라운드: 스크립트가 실행되기 전에 "여기는 서비스 워커"라는 환경을 먼저 갖춘다.
    // (Firebase 메시징처럼 ServiceWorkerGlobalScope · PushManager · Notification 이 있는지 보고, 없으면 오류를 던져
    // 백그라운드 전체가 시작도 못 하던 문제 — 사이드 패널이 비어 보이던 원인)
    if (window.__evxSw) {
      try { if (!("ServiceWorkerGlobalScope" in self)) self.ServiceWorkerGlobalScope = function ServiceWorkerGlobalScope() { }; } catch (e) { }
      try { if (typeof PushManager === "undefined") self.PushManager = function PushManager() { }; } catch (e) { }
      try {
        if (typeof Notification === "undefined") {
          self.Notification = function Notification() { };
          self.Notification.permission = "denied";
          self.Notification.requestPermission = function () { return Promise.resolve("denied"); };
        }
      } catch (e) { }
      try { if (typeof PushSubscription === "undefined") self.PushSubscription = function PushSubscription() { }; } catch (e) { }
      try { if (!Object.prototype.hasOwnProperty.call(PushSubscription.prototype, "getKey")) PushSubscription.prototype.getKey = function () { return null; }; } catch (e) { }
      try { if (typeof ServiceWorkerRegistration === "undefined") self.ServiceWorkerRegistration = function ServiceWorkerRegistration() { }; } catch (e) { }
      try { if (!Object.prototype.hasOwnProperty.call(ServiceWorkerRegistration.prototype, "showNotification")) ServiceWorkerRegistration.prototype.showNotification = function () { return Promise.resolve(); }; } catch (e) { }
      try {
        if (!self.registration) self.registration = {
          scope: BASE, active: null, installing: null, waiting: null,
          showNotification: function () { return Promise.resolve(); },
          getNotifications: function () { return Promise.resolve([]); },
          pushManager: {
            getSubscription: function () { return Promise.resolve(null); },
            permissionState: function () { return Promise.resolve("denied"); },
            subscribe: function () { return Promise.reject(new Error("push 를 지원하지 않아요")); }
          },
          unregister: function () { return Promise.resolve(false); },
          update: function () { return Promise.resolve(); }
        };
      } catch (e) { }
    }
    try { self.skipWaiting = function () { return Promise.resolve(); }; } catch (e) { }
    try { self.clients = { claim: function () { return Promise.resolve(); }, matchAll: function () { return Promise.resolve([]); } }; } catch (e) { }
    window.importScripts = function () {
      for (var i = 0; i < arguments.length; i++) {
        var u = new URL(arguments[i], BASE).href, x = new XMLHttpRequest();
        x.open("GET", u, false); x.send();
        if (x.status >= 200 && x.status < 300) (0, eval)(x.responseText + "\n//# sourceURL=" + u);
        else throw new Error("importScripts 실패: " + u);
      }
    };
    window.addEventListener("load", function () {
      setTimeout(function () {
        ["install", "activate"].forEach(function (n) {
          try { var e = new Event(n); e.waitUntil = function () { }; window.dispatchEvent(e); } catch (x) { }
        });
        runtime.onStartup._d([]);
        if (window.__evxInstalled) runtime.onInstalled._d([{ reason: "install" }]);
      }, 0);
    });
  }

  // 확장 프로그램 페이지(팝업 · 옵션)와 백그라운드: CORS 없이 fetch (host 권한이 있는 주소만)
  if ((window.__evxIsBg || location.href.indexOf(BASE) === 0) && !window.__evxFetchSet) {
    window.__evxFetchSet = true;
    var _fetch = window.fetch.bind(window);
    var b64 = function (buf) {
      var u = new Uint8Array(buf), s = "";
      for (var i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
      return btoa(s);
    };
    var unb64 = function (s) { var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
    window.fetch = function (input, init) {
      var req;
      try { req = new Request(input, init); } catch (e) { return _fetch(input, init); }
      var url = req.url;
      if (!/^https?:\/\//i.test(url) || url.indexOf(ROOT) === 0) return _fetch(req);
      return req.arrayBuffer().then(function (buf) {
        var h = {};
        req.headers.forEach(function (v, k) { h[k] = v; });
        if (req.credentials === "include") h["__evx_cred"] = "include";
        return ask(function (cid) { var hj = JSON.stringify(h), bd = buf.byteLength ? b64(buf) : ""; if (window.__evxIsBg) B.xfetch(ID, url, req.method, hj, bd, T, cid); else B.pfetch(ID, url, req.method, hj, bd, T, cid); }, 60000);
      }).then(function (j) {
        var r = parseJ(j);
        if (!r || r.error || r.status < 200 || r.status > 599) throw new TypeError("Failed to fetch");
        var nb = r.status === 204 || r.status === 205 || r.status === 304;
        var resp = new Response(nb ? null : unb64(r.body || ""), { status: r.status, statusText: r.statusText || "", headers: r.headers || {} });
        // new Response() 의 url 은 빈 문자열이라 new URL(response.url) 하는 코드가 'Invalid URL' 로 죽는다 → 요청 주소를 넣어 준다
        try { Object.defineProperty(resp, "url", { value: r.url || url }); } catch (e) { }
        return resp;
      });
    };
  }
  // 확장 프로그램 페이지(측면 패널 · 팝업 · 옵션) · 백그라운드 · 콘텐츠 스크립트(웹 페이지 위에 뜨는 "AI 요약" 버튼 등):
  // 크롬 내장 AI 요약(Summarizer)을 앱의 Gemini 로 대신 해 준다.
  // 크롬 138 이상에만 있는 기능이라 확장 프로그램이 "이 브라우저에서는 AI 요약을 쓸 수 없어요" 로 막는다. 설정에 Gemini 키가 있을 때만 켜진다.
  // (예전에는 확장 페이지·백그라운드에서만 켜서, 웹 페이지 위 버튼은 계속 막혔다. 호출 횟수는 앱 쪽에서 제한한다)
  if (!window.__evxAiSet) {
    window.__evxAiSet = true;
    try {
      if (typeof window.Summarizer === "undefined") {
        var aiOk = function () { try { return B.aistate(T) === "ok"; } catch (e) { return false; } };
        var TYPE = {
          "key-points": "핵심 내용을 글머리 기호 목록으로 정리하세요.",
          "tldr": "바쁜 독자를 위해 아주 짧게(한두 문장) 요약하세요.",
          "teaser": "읽고 싶어지도록 가장 흥미로운 부분을 살려 짧게 소개하세요.",
          "headline": "내용을 한 줄 제목(헤드라인)으로 쓰세요."
        };
        var LENGTH = {
          "key-points": { short: "3개", medium: "5개", long: "7개" },
          "other": { short: "한두 문장", medium: "한 문단", long: "여러 문단" }
        };
        var mkSystem = function (o, ctxt, reqCtx) {
          var t = o.type || "key-points", l = o.length || "medium";
          var amount = t === "key-points" ? "항목 수는 " + LENGTH["key-points"][l] + "로 하세요." : t === "headline" ? "" : "길이는 " + LENGTH.other[l] + "로 하세요.";
          var lang = o.outputLanguage ? "반드시 '" + o.outputLanguage + "' 언어로 쓰세요." : "원문과 같은 언어로 쓰세요.";
          var fmt = o.format === "plain-text" ? "마크다운 기호 없이 일반 글자로만 쓰세요(목록은 줄 앞에 '- ' 만)." : "마크다운으로 쓰세요.";
          var sys = "당신은 글을 요약하는 도구입니다. 주어진 글만 근거로 요약하고, 없는 내용을 지어내지 마세요. " + (TYPE[t] || TYPE["key-points"]) + " " + amount + " " + lang + " " + fmt + " 인사말이나 설명 없이 요약 결과만 출력하세요.";
          if (o.sharedContext) sys += " 배경 정보: " + o.sharedContext;
          if (reqCtx) sys += " 이 글의 맥락: " + reqCtx;
          return sys;
        };
        var SumObj = function (o) {
          this.sharedContext = o.sharedContext || "";
          this.type = o.type || "key-points";
          this.format = o.format || "markdown";
          this.length = o.length || "medium";
          this.expectedInputLanguages = o.expectedInputLanguages || null;
          this.expectedContextLanguages = o.expectedContextLanguages || null;
          this.outputLanguage = o.outputLanguage || null;
          this.inputQuota = 1000000;
          this._o = o; this._gone = false;
        };
        SumObj.prototype.summarize = function (text, opts) {
          var self = this;
          if (self._gone) return Promise.reject(new DOMException("The summarizer was destroyed.", "InvalidStateError"));
          if (opts && opts.signal && opts.signal.aborted) return Promise.reject(opts.signal.reason || new DOMException("Aborted", "AbortError"));
          var sys = mkSystem(self, null, opts && opts.context);
          return ask(function (cid) { B.ai(ID, String(text == null ? "" : text), sys, T, cid); }, 180000).then(function (j) {
            var r = parseJ(j);
            if (!r) throw new DOMException("요약 요청이 시간 안에 끝나지 않았어요", "NetworkError");
            if (!r.ok) throw new DOMException(r.error || "요약하지 못했어요", "NotSupportedError");
            return r.text;
          });
        };
        SumObj.prototype.summarizeStreaming = function (text, opts) {
          var self = this;
          return new ReadableStream({
            start: function (c) { self.summarize(text, opts).then(function (t) { c.enqueue(t); c.close(); }, function (e) { c.error(e); }); }
          });
        };
        SumObj.prototype.measureInputUsage = function (text) { return Promise.resolve(Math.ceil(String(text || "").length / 3)); };
        SumObj.prototype.destroy = function () { this._gone = true; };
        var SumApi = {
          availability: function () { return Promise.resolve(aiOk() ? "available" : "unavailable"); },
          create: function (o) {
            o = o || {};
            if (!aiOk()) return Promise.reject(new DOMException("설정에서 Gemini API 키를 저장하면 AI 요약을 쓸 수 있어요", "NotSupportedError"));
            if (typeof o.monitor === "function") { try { o.monitor({ addEventListener: function () { } }); } catch (e) { } }
            return Promise.resolve(new SumObj(o));
          }
        };
        Object.defineProperty(window, "Summarizer", { value: SumApi, configurable: true, writable: true });
      }
    } catch (e) { try { lg("AI 요약 준비 실패", (e && e.message) || e); } catch (x) { } }
  }
  // 팝업 안에서 window.close() 를 부르면 팝업 카드를 닫는다
  if (!window.__evxIsBg && location.href.indexOf(BASE) === 0) {
    try { window.close = function () { try { B.popclose(ID, T); } catch (e) { } }; } catch (e) { }
  }

  // 확장 프로그램 페이지(옵션 · 팝업 · 백그라운드): new Proxy(undefined, …) 처럼 대상이 객체가 아니어도 페이지 전체가 죽지 않게 한다.
  // (확장이 백그라운드에서 받은 값을 곧바로 Proxy 로 감싸는데, 이 앱에서 그 값이 비어 오면 "Cannot create proxy with a non-object"
  //  로 옵션 화면이 통째로 비어 보였다. 빈 객체로 대신해 나머지 화면은 그려지게 한다)
  if (location.href.indexOf(BASE) === 0 && !window.__evxProxySet) {
    window.__evxProxySet = true;
    try {
      var RawProxy = window.Proxy;
      var SafeProxy = function Proxy(target, handler) {
        var tt = typeof target;
        if (target === null || (tt !== "object" && tt !== "function")) { target = {}; try { lg("Proxy 대상 보정", "객체가 아닌 값(" + tt + ")으로 Proxy 를 만들려 해서 빈 객체로 바꿨어요"); } catch (e) { } }
        var ht = typeof handler;
        if (handler === null || (ht !== "object" && ht !== "function")) handler = {};
        return new RawProxy(target, handler);
      };
      SafeProxy.revocable = function (target, handler) {
        var tt = typeof target;
        if (target === null || (tt !== "object" && tt !== "function")) target = {};
        var ht = typeof handler;
        if (handler === null || (ht !== "object" && ht !== "function")) handler = {};
        return RawProxy.revocable(target, handler);
      };
      window.Proxy = SafeProxy;
    } catch (e) { }
  }

  // 백그라운드 · 팝업 · 옵션 페이지의 오류를 '진단'에 남긴다
  if (DIAG && !window.__evxDiagSet) {
    window.__evxDiagSet = true;
    try {
      window.addEventListener("error", function (v) {
        var t = v.target;
        if (t && t !== window) lg(WHERE + " 파일 실패", String(t.src || t.href || ""));
        else {
          var stk = ""; try { stk = v.error && v.error.stack ? "\n" + String(v.error.stack).split("\n").slice(1, 5).map(function (x) { return x.trim().replace(/https:\/\/ext\.evergreen\.invalid\/[a-p]{32}\//, ""); }).join("\n") : ""; } catch (x) { }
          lg(WHERE + " 오류", v.message + " @" + String(v.filename || "").split("/").pop() + ":" + v.lineno + stk);
        }
      }, true);
      window.addEventListener("unhandledrejection", function (v) { var r = v.reason; lg(WHERE + " 처리 안 된 오류", (r && (r.stack || r.message)) || r); }, true);
      window.addEventListener("securitypolicyviolation", function (v) { lg("CSP 차단", v.violatedDirective + " " + v.blockedURI); }, true);
      if (window.__evxIsBg) window.addEventListener("load", function () { setTimeout(function () { lg("백그라운드 상태", "onMessage 리스너 " + runtime.onMessage._a().length + "개 · 툴바 클릭 리스너 " + actClick._a().length + "개"); }, 1500); });
    } catch (e) { }
  }

  return new Proxy(C, {
    get: function (t, k) {
      if (k in t) return t[k];
      if (typeof k === "symbol" || k === "then") return undefined;
      return ns({});
    }
  });
}


// 콘텐츠 스크립트용: 확장 안의 모듈(import)과 파일(fetch)을 페이지 보안 정책(CSP)과 상관없이 앱에서 직접 읽어 와서 돌린다
function __evxModules(ID, B, T, chrome, browser, G) {
  var BASE = "https://ext.evergreen.invalid/" + ID + "/";
  var cache = {}, seq = 0;
  var AF = Object.getPrototypeOf(async function () { }).constructor;
  // 페이지가 보안 정책(require-trusted-types-for 'script')으로 문자열 실행을 막으면 new Function 이 실패한다.
  // 그럴 때는 Trusted Types 정책을 만들어 그 값으로 함수를 만든다 (정책 이름 제한이 있는 페이지에서는 만들 수 없어 그대로 둔다)
  var TTP = null;
  try {
    if (window.trustedTypes && window.trustedTypes.createPolicy)
      TTP = window.trustedTypes.createPolicy("evg-ext-" + Math.random().toString(36).slice(2, 8), { createScript: function (x) { return x; } });
  } catch (e) { TTP = null; }
  function ts(x) { return TTP ? TTP.createScript(x) : x; }
  function mkFn(Ctor, names, body) { return Ctor.apply(null, names.map(ts).concat([ts(body)])); }
  var _fetch = window.fetch.bind(window);
  function q(x) { return JSON.stringify(String(x)); }
  function rd(u) {
    u = String(u);
    if (u.indexOf(BASE) !== 0) return null;
    var p = u.slice(BASE.length).split("#")[0].split("?")[0];
    try { p = decodeURIComponent(p); } catch (e) { }
    try { var s = B.extText(ID, p, T); return s == null ? null : String(s); } catch (e) { return null; }
  }
  function impStmt(clause, spec) {
    if (!clause) return "await __imp(" + q(spec) + ");";
    var m = "__m" + (seq++), out = "const " + m + "=await __imp(" + q(spec) + ");";
    var cl = clause.trim(), rest = cl, d = /^([\w$]+)\s*(?:,\s*|$)/.exec(cl);
    if (d) { out += "const " + d[1] + "=" + m + ".default;"; rest = cl.slice(d[0].length).trim(); }
    if (rest) {
      var a = /^\*\s*as\s+([\w$]+)$/.exec(rest);
      if (a) out += "const " + a[1] + "=" + m + ";";
      else {
        var nm = /^\{([^}]*)\}$/.exec(rest);
        if (nm) out += "const {" + nm[1].split(",").map(function (x) { return x.trim(); }).filter(Boolean).map(function (x) { return x.replace(/\s+as\s+/, ":"); }).join(",") + "}=" + m + ";";
      }
    }
    return out;
  }
  // ES 모듈 글자를 '비동기 함수 본문'으로 바꾼다 (import → await __imp, export → __x 에 담기)
  function compile(src) {
    var exps = [];
    src = src.replace(/\bimport\.meta\b/g, "__meta");
    src = src.replace(/(^|[^\w$.])import\s*\(/g, "$1__imp(");
    src = src.replace(/(^|[;}\n])(\s*)import\s*(?:([\w$*{][^;"'`]*?)\s*from\s*)?(["'])([^"'\n]+)\4/g, function (all, pre, sp, clause, qt, spec) { return pre + sp + impStmt(clause, spec); });
    src = src.replace(/(^|[;}\n])(\s*)export\s*\{([^}]*)\}\s*(?:from\s*(["'])([^"'\n]+)\4)?/g, function (all, pre, sp, list, qt, spec) {
      var out = "", m = "";
      if (spec) { m = "__r" + (seq++); out = "const " + m + "=await __imp(" + q(spec) + ");"; }
      list.split(",").forEach(function (it) {
        it = it.trim(); if (!it) return;
        var p = it.split(/\s+as\s+/), loc = p[0], ex = p[1] || p[0];
        exps.push([ex, spec ? m + "[" + q(loc) + "]" : loc, !!spec]);
      });
      return pre + sp + out;
    });
    src = src.replace(/(^|[;}\n])(\s*)export\s+default\s+/g, "$1$2__x.default=");
    src = src.replace(/(^|[;}\n])(\s*)export\s+((?:async\s+)?function\s*\*?|class|const|let|var)\s*([\w$]+)/g, function (all, pre, sp, kw, name) { exps.push([name, name, false]); return pre + sp + kw + " " + name; });
    var tail = exps.map(function (e) { return ";Object.defineProperty(__x," + q(e[0]) + ",{enumerable:true,get:function(){return " + e[1] + "}});"; }).join("");
    return '"use strict";\n' + src + "\n" + tail + "\nreturn __x;";
  }
  function imp(spec, from) {
    var url;
    try { url = new URL(String(spec), from || BASE).href; } catch (e) { return Promise.reject(new TypeError("Failed to resolve module specifier " + spec)); }
    var key = url.split("#")[0];
    if (cache[key]) return cache[key];
    if (key.indexOf(BASE) !== 0) return (mkFn(Function, ["u"], "return import(u)"))(url);
    var src = rd(key);
    if (src == null) return Promise.reject(new TypeError("Failed to fetch dynamically imported module: " + url));
    var x = {};
    try { Object.defineProperty(x, Symbol.toStringTag, { value: "Module" }); } catch (e) { }
    cache[key] = Promise.resolve().then(function () {
      var fn = mkFn(AF, ["chrome", "browser", "globalThis", "fetch", "__imp", "__meta", "__x"], compile(src));
      return fn(chrome, browser, G, xfetch, function (s) { return imp(s, key); }, { url: key }, x);
    });
    return cache[key];
  }
  function xfetch(input, init) {
    try {
      var u = typeof input === "string" ? input : (input && input.url) || String(input);
      var mth = (init && init.method) || (input && input.method) || "GET";
      if (u.indexOf(BASE) === 0 && /^get$/i.test(mth)) {
        var t = rd(u);
        if (t != null) {
          var ext = u.split("#")[0].split("?")[0].split(".").pop().toLowerCase();
          var ct = { json: "application/json", js: "text/javascript", mjs: "text/javascript", css: "text/css", html: "text/html", svg: "image/svg+xml" }[ext] || "text/plain";
          var r = new Response(t, { status: 200, headers: { "content-type": ct + "; charset=utf-8" } });
          try { Object.defineProperty(r, "url", { value: u }); } catch (e) { }
          return Promise.resolve(r);
        }
      }
    } catch (e) { }
    return _fetch(input, init);
  }
  return { imp: imp, fetch: xfetch };
}
