package com.example.evergreen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 방문 기록.
 * - 맨 위 '최근 1시간' 과 날짜별(오늘 / 어제 / 11월 3일 (화) …)로 묶여 있고, 줄을 누르면 기록이 펼쳐지고 접힌다.
 *   처음 열면 '최근 1시간' 과 '오늘' 이 함께 펼쳐져 있다.
 * - 항목을 누르면 현재 탭, ⋮ 메뉴(또는 길게 누르기)로 새 탭 열기 / 주소 복사 / 삭제
 * - 고른 주소는 북마크 화면과 같은 방식(EXTRA_URL)으로 MainActivity 에 돌려준다.
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private val adapter = RowAdapter()
    private lateinit var select: ListSelect<String>

    /** 목록에 그려지는 줄: 날짜 줄 또는 기록 한 개 */
    private sealed class Row {
        class Header(val day: Long, val label: String, val count: Int, val open: Boolean) : Row()
        class Entry(val item: HistoryItem, val day: Long) : Row()
    }

    private companion object {
        /** 맨 위 '최근 1시간' 줄의 day 값 (실제 날짜 0시 시각이나 0(날짜 없음)과 겹치지 않는 값) */
        const val RECENT_DAY = -2L
        const val RECENT_MS = 60L * 60L * 1000L
    }

    private val rows = ArrayList<Row>()
    /** 선택 · 전체 선택의 대상: 접혀 있는 날의 기록까지 모두 */
    private val allItems = ArrayList<HistoryItem>()
    /** 펼쳐 둔 날 (그 날 0시의 시각). 처음엔 '최근 1시간'과 오늘이 펼쳐져 있다 */
    private val openDays = HashSet<Long>()
    /** 접는 애니메이션이 도는 중인지 */
    private var collapsing = false
    private var firstShow = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        ThemeColors.skin(findViewById(android.R.id.content))   // XML 의 ?attr 색에도 테마 색 입히기 (목록 줄은 만들어질 때마다 자동)
        ListUi.fitSystemBars(this)
        ListUi.applyTabletPopup(this)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "방문 기록"
        findViewById<View>(R.id.btnListBack).setOnClickListener { ListUi.closeSheet(this, backToMenu = true) }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        // 날짜별 목록이라 칩 줄은 쓰지 않는다
        (findViewById<View>(R.id.chipRow).parent as? View)?.visibility = View.GONE
        listView.adapter = adapter
        select = ListSelect(
            this, listView, findViewById(R.id.btnListAction), findViewById(R.id.listTitle),
            visibleKeys = { allItems.map { it.url } },
            onChanged = { adapter.notifyDataSetChanged() },
            onDelete = { urls -> deleteMany(urls) }
        )

        // 방문 기록을 열면 '최근 1시간'과 '오늘'이 함께 미리 펼쳐져 있다 (나머지 날짜는 접힌 채)
        openDays.add(RECENT_DAY)
        openDays.add(startOfToday())
        refreshView()
    }

    private fun startOfDay(t: Long): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun startOfToday(): Long = startOfDay(System.currentTimeMillis())

    /** 오늘 / 어제 / 11월 3일 (화) — 올해가 아니면 연도도 붙인다 */
    private fun dayLabel(day: Long): String {
        val today = startOfToday()
        if (day == today) return "오늘"
        if (day == startOfDay(today - 1)) return "어제"
        val sameYear = Calendar.getInstance().apply { timeInMillis = day }.get(Calendar.YEAR) ==
            Calendar.getInstance().apply { timeInMillis = today }.get(Calendar.YEAR)
        val fmt = if (sameYear) "M월 d일 (E)" else "yyyy년 M월 d일 (E)"
        return SimpleDateFormat(fmt, Locale.KOREA).format(Date(day))
    }

    private fun refreshView() {
        val all = prefs.historyItems().sortedByDescending { it.time }
        allItems.clear()
        allItems.addAll(all)

        // 날짜별로 묶는다 (시간이 없는 오래된 기록은 맨 아래 '날짜 없음' 으로)
        val byDay = LinkedHashMap<Long, MutableList<HistoryItem>>()
        all.forEach { byDay.getOrPut(if (it.time > 0L) startOfDay(it.time) else 0L) { ArrayList() }.add(it) }

        rows.clear()
        // 맨 위: 최근 1시간 줄 (날짜 줄과 같은 방식으로 펼치고 접는다. 1시간 안의 기록이 없으면 보이지 않는다)
        val cutoff = System.currentTimeMillis() - RECENT_MS
        val recent = all.filter { it.time > 0L && it.time >= cutoff }
        if (recent.isNotEmpty()) {
            val open = RECENT_DAY in openDays
            rows.add(Row.Header(RECENT_DAY, "최근 1시간", recent.size, open))
            if (open) recent.forEach { rows.add(Row.Entry(it, RECENT_DAY)) }
        }
        byDay.forEach { (day, list) ->
            val open = day in openDays
            rows.add(Row.Header(day, if (day == 0L) "날짜 없음" else dayLabel(day), list.size, open))
            if (open) list.forEach { rows.add(Row.Entry(it, day)) }
        }
        select.retain()
        adapter.notifyDataSetChanged()
        if (firstShow) listView.postDelayed({ firstShow = false }, 700)

        if (rows.isEmpty()) {
            emptyView.text = "방문 기록이 없습니다"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    /** 날짜 줄 안의 기록은 시각만 보여 준다 (날짜는 위 줄에 있다) */
    private fun timeLabel(t: Long): String =
        if (t <= 0L) "" else SimpleDateFormat("a h:mm", Locale.KOREA).format(Date(t))

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getViewTypeCount(): Int = 2
        override fun getItemViewType(position: Int): Int = if (rows[position] is Row.Header) 0 else 1

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
            when (val r = rows[position]) {
                is Row.Header -> headerView(r, convertView, parent, position)
                is Row.Entry -> entryView(r, convertView, parent)
            }

        private fun headerView(r: Row.Header, convertView: View?, parent: ViewGroup, position: Int): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_history_date, parent, false)
            resetAnim(v)
            val chevron = v.findViewById<ImageView>(R.id.dateChevron)
            v.findViewById<TextView>(R.id.dateLabel).text = r.label
            // 눌러서 돌고 있는 화살표는 건드리지 않는다 (상태가 다를 때만 곧바로 맞춘다)
            if (chevron.tag != r.open) {
                chevron.animate().cancel()
                chevron.rotation = if (r.open) 180f else 0f
                chevron.tag = r.open
            }
            v.contentDescription = "${r.label}, 기록 ${r.count}개, " + if (r.open) "접기" else "펼치기"
            v.setOnClickListener { toggleDay(r, chevron) }
            // 화면을 처음 열 때 날짜 줄이 차례로 떠오른다
            if (firstShow && position < 10) Motion.enter(v, position * 34L, 14f)
            return v
        }

        private fun entryView(r: Row.Entry, convertView: View?, parent: ViewGroup): View {
            val h = r.item
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)
            resetAnim(v)

            select.bindRow(v, h.url, R.drawable.ic_globe)
            if (!select.isSelected(h.url) || !select.active) Favicons.apply(v.findViewById(R.id.rowIcon), h.url)
            v.findViewById<ProgressBar>(R.id.rowProgress).visibility = View.GONE
            v.findViewById<TextView>(R.id.rowTitle).text = ListUi.displayTitle(h.title, h.url)
            val label = timeLabel(h.time)
            v.findViewById<TextView>(R.id.rowSub).text = if (label.isEmpty()) h.url else "$label · ${h.url}"

            v.setOnClickListener { if (select.active) select.toggle(h.url) else openUrl(h.url, newTab = false) }
            v.setOnLongClickListener {
                if (select.active) select.toggle(h.url) else select.enter(h.url)
                true
            }
            v.findViewById<ImageButton>(R.id.rowMore).setOnClickListener { showMenu(h) }
            return v
        }
    }

    /** 재활용되는 행에 남은 애니메이션 흔적을 지운다 */
    private fun resetAnim(v: View) {
        Motion.cancel(v)
        v.animate().cancel()
        v.alpha = 1f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f
    }

    /** 줄을 알아보는 열쇠 (목록이 다시 그려져도 같은 줄인지 알아보려고) */
    private fun rowKey(r: Row): String = when (r) {
        is Row.Header -> "h${r.day}"
        is Row.Entry -> "e${r.day}|${r.item.url}"
    }

    /** 지금 화면에 보이는 줄들의 위치 (움직이는 중이면 눈에 보이는 위치) */
    private fun snapshotTops(): HashMap<String, Int> {
        val m = HashMap<String, Int>()
        for (i in 0 until listView.childCount) {
            val r = rows.getOrNull(listView.firstVisiblePosition + i) ?: continue
            val v = listView.getChildAt(i)
            m[rowKey(r)] = (v.top + v.translationY).toInt()
        }
        return m
    }

    /**
     * 날짜를 펼치거나 접어 목록이 바뀔 때, 줄들이 순간이동하지 않고 새 자리로 미끄러지게 한다.
     * - 남아 있는 줄: 예전 자리에서 새 자리로 부드럽게 이동 (펼치면 아래 줄이 밀려 내려가고, 접으면 올라온다)
     * - 새로 생긴 그 날의 기록: 날짜 줄 밑에서 차례로 펼쳐져 나온다
     * - 펼친 기록이 화면 아래로 넘치면, 날짜 줄이 가려지지 않는 선까지 스르르 스크롤해서 보여 준다
     */
    private fun morph(day: Long, opening: Boolean, change: () -> Unit) {
        if (!Motion.enabled(this)) {
            change()
            return
        }
        val before = snapshotTops()
        change()
        listView.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                listView.viewTreeObserver.removeOnPreDrawListener(this)
                val first = listView.firstVisiblePosition
                var header: View? = null
                var sampleEntry: View? = null
                for (i in 0 until listView.childCount) {
                    val r = rows.getOrNull(first + i) ?: continue
                    if (r is Row.Header && r.day == day) header = listView.getChildAt(i)
                    if (r is Row.Entry && r.day == day && sampleEntry == null) sampleEntry = listView.getChildAt(i)
                }
                val anchorBottom = header?.bottom ?: 0
                val d = resources.displayMetrics.density
                val slide = android.view.animation.DecelerateInterpolator(2f)
                var k = 0
                for (i in 0 until listView.childCount) {
                    val r = rows.getOrNull(first + i) ?: continue
                    val v = listView.getChildAt(i)
                    v.animate().cancel()
                    val old = before[rowKey(r)]
                    if (old != null) {
                        val dy = (old - v.top).toFloat()
                        if (dy != 0f) {
                            v.translationY = dy
                            v.animate().translationY(0f).setDuration(280).setInterpolator(slide).start()
                        }
                    } else if (opening && r is Row.Entry && r.day == day && header != null) {
                        // 날짜 줄 밑에서 펼쳐져 나온다 (위에서부터 차례로)
                        v.alpha = 0f
                        v.translationY = (anchorBottom - v.top).toFloat() * 0.6f - 6f * d
                        v.scaleY = 0.94f
                        v.animate().alpha(1f).translationY(0f).scaleY(1f)
                            .setStartDelay(minOf(k * 26L, 200L)).setDuration(300).setInterpolator(slide).start()
                        k++
                    } else {
                        // 그 밖에 새로 보이게 된 줄 (화면 밖에 있던 줄): 살며시 나타난다
                        v.alpha = 0f
                        v.animate().alpha(1f).setDuration(200).start()
                    }
                }
                // 펼친 기록이 화면 아래로 넘치면 스크롤해서 보여 준다
                if (opening && header != null && sampleEntry != null) {
                    val count = rows.count { it is Row.Entry && it.day == day }
                    val bottom = header.bottom + count * sampleEntry.height
                    val limit = listView.height - listView.paddingBottom
                    val need = bottom - limit
                    val room = header.top - listView.paddingTop   // 날짜 줄이 위로 밀려 나가지 않는 만큼만
                    val dy = minOf(need, room)
                    if (dy > dp(8)) listView.postDelayed({
                        if (!isFinishing && !isDestroyed) listView.smoothScrollBy(dy, 340)
                    }, 80)
                }
                return true
            }
        })
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** 날짜 줄을 눌렀을 때: 화살표가 돌고, 기록이 펼쳐져 나오거나 날짜 줄 속으로 접혀 들어가며 아래 줄이 함께 미끄러진다 */
    private fun toggleDay(h: Row.Header, chevron: ImageView) {
        if (collapsing) return
        val opening = h.day !in openDays
        val anim = Motion.enabled(this)
        firstShow = false
        chevron.tag = opening
        if (anim) chevron.animate().rotation(if (opening) 180f else 0f).setDuration(240)
            .setInterpolator(android.view.animation.DecelerateInterpolator(2f)).start()
        else chevron.rotation = if (opening) 180f else 0f

        if (opening) {
            morph(h.day, true) { openDays.add(h.day); refreshView() }
            return
        }
        // 접기: 지금 보이는 그 날의 기록이 날짜 줄 쪽으로 말려 올라가며 사라진 뒤, 아래 줄이 올라와 빈자리를 메운다
        val visible = ArrayList<View>()
        var headerBottom: Int? = null
        for (i in 0 until listView.childCount) {
            val pos = listView.firstVisiblePosition + i
            val r = rows.getOrNull(pos)
            if (r is Row.Entry && r.day == h.day) visible.add(listView.getChildAt(i))
            if (r is Row.Header && r.day == h.day) headerBottom = listView.getChildAt(i).bottom
        }
        if (!anim || visible.isEmpty()) {
            morph(h.day, false) { openDays.remove(h.day); refreshView() }
            return
        }
        collapsing = true
        val d = resources.displayMetrics.density
        val n = visible.size
        visible.forEachIndexed { i, v ->
            // 날짜 줄이 보이면 그쪽으로, 안 보이면 살짝 위로. 아래쪽 기록이 먼저 말려 올라간다.
            val to = headerBottom?.let { (it - v.top).toFloat() * 0.6f } ?: (-10f * d)
            v.animate().alpha(0f).translationY(to).scaleY(0.94f)
                .setStartDelay(minOf((n - 1 - i) * 16L, 80L)).setDuration(150)
                .setInterpolator(android.view.animation.AccelerateInterpolator(1.3f)).start()
        }
        listView.postDelayed({
            collapsing = false
            if (isFinishing || isDestroyed) return@postDelayed
            morph(h.day, false) { openDays.remove(h.day); refreshView() }
        }, 150L + minOf(n * 16L, 80L))
    }

    private fun openUrl(url: String, newTab: Boolean) {
        setResult(
            RESULT_OK,
            Intent().putExtra(BookmarksActivity.EXTRA_URL, url)
                .putExtra(BookmarksActivity.EXTRA_NEW_TAB, newTab)
        )
        ListUi.closeSheet(this)
    }

    private fun showMenu(h: HistoryItem) {
        Popup.menu(
            this,
            title = ListUi.displayTitle(h.title, h.url),
            subtitle = h.url,
            headerIcon = R.drawable.ic_globe,
            items = listOf(
                Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { openUrl(h.url, newTab = true) },
                Popup.Item(R.drawable.ic_copy, "주소 복사") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("url", h.url))
                    ListUi.toast(this, "복사했습니다")
                },
                Popup.Item(R.drawable.ic_delete, "기록에서 삭제", danger = true) {
                    prefs.removeHistory(h.url)
                    refreshView()
                }
            )
        )
    }

    /** 묻지 않고 바로 지우고, 알림의 '실행 취소' 로 되돌릴 수 있게 한다 */
    private fun deleteMany(urls: Set<String>) {
        val n = urls.size
        val before = prefs.historyItems()
        if (n >= before.size) prefs.clearHistory() else prefs.removeHistories(urls)
        select.finishDelete()
        refreshView()
        ListUi.undoToast(this, "방문 기록 ${n}개를 삭제했습니다") {
            prefs.setHistoryItems(before)
            refreshView()
        }
    }

}
