package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import android.widget.ProgressBar
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * 웹사이트 로딩 바.
 *
 * 웹뷰가 알려 주는 진행률은 10 → 70 → 100 처럼 뚝뚝 끊겨 온다. 예전에는 소식이 올 때마다 새 애니메이터를 시작해서
 * 그때마다 속도가 0 부터 다시 붙었다(바가 멈칫하며 출발). 여기서는 바 안에 스프링 하나를 두고,
 * 목표가 바뀌어도 지금의 위치와 속도를 그대로 이어서 새 목표로 향한다. 감쇠를 임계값으로 잡아 목표를 넘어서지 않는다.
 *
 * 빛 효과(쉬머 · 맨 앞 번짐)는 없다. 시스템의 "애니메이션 끄기"를 따른다 (끄면 바로 그 위치로 간다).
 *
 * progress / max 는 기존 ProgressBar 그대로라서 [ProgressBar] 로 다루는 코드는 바꿀 필요가 없다.
 */
class LoadBarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.progressBarStyleHorizontal
) : ProgressBar(context, attrs, defStyleAttr) {

    private var pos = 0f
    private var vel = 0f
    private var goalValue = 0f
    private var stiffness = 90f
    private var driving = false
    private var lastNanos = 0L
    private var animOn = true
    private var internalSet = false

    /**
     * 삼성 테마처럼 로딩 바를 다른 자리(탭 카드 바로 아래)에 그릴 때 쓴다.
     * 값이 있으면 이 바는 그리지 않고(진행 계산·보이기/숨기기·투명도는 그대로 이 바가 맡는다), 같은 진행률·보임·투명도를 [mirror] 가 대신 그린다.
     */
    var mirror: LoadBarView? = null
        private set

    fun attachMirror(m: LoadBarView?) {
        if (mirror === m) return
        mirror = m
        if (m != null) {
            m.pushProgress(progress)
            m.alpha = alpha
            m.visibility = visibility
        }
        invalidate()
    }

    private fun pushProgress(p: Int) {
        internalSet = true
        try { super.setProgress(p) } finally { internalSet = false }
    }

    override fun onDraw(canvas: Canvas) {
        val m = mirror
        if (m != null) {
            // 투명도 애니메이션(ViewPropertyAnimator)은 setAlpha 를 거치지 않으므로 그릴 때마다 맞춘다
            if (m.alpha != alpha) m.alpha = alpha
            return
        }
        super.onDraw(canvas)
    }

    /** 지금 향하고 있는 목표 위치 (0..max) */
    val goal: Int get() = goalValue.roundToInt()

    /** 바깥에서 progress 를 직접 넣으면(0 으로 되돌리기 등) 스프링도 그 값에서 새로 시작한다 */
    override fun setProgress(progress: Int) {
        if (!internalSet) {
            pos = progress.toFloat()
            vel = 0f
            goalValue = pos
            halt()
        }
        super.setProgress(progress)
        mirror?.pushProgress(progress)
    }

    /** 현재 위치에서 [to] 로 부드럽게 달린다. 이미 달리는 중이면 속도를 이어받는다. stiffness 가 클수록 빠르다. */
    fun glideTo(to: Int, stiffness: Float = 90f) {
        val t = to.coerceIn(0, max).toFloat()
        goalValue = t
        this.stiffness = stiffness
        if (!animOn) {
            pos = t
            vel = 0f
            halt()
            applyPos()
            return
        }
        if (abs(t - pos) < 0.5f && abs(vel) < 1f) return
        if (!driving) {
            driving = true
            lastNanos = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    /** 달리던 스프링을 멈춘다 (위치는 그대로 둔다). */
    fun halt() {
        if (!driving) return
        driving = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!driving) return
            // 프레임이 길게 밀려도 건너뛰지 않는다 (SmoothAnim 과 같은 규칙)
            var left = SmoothAnim.step(lastNanos, frameTimeNanos) / 1000f
            lastNanos = frameTimeNanos
            val damp = 2f * sqrt(stiffness)
            while (left > 0f) {
                val h = minOf(left, 0.004f)
                vel += (stiffness * (goalValue - pos) - damp * vel) * h
                pos += vel * h
                left -= h
            }
            if (pos < 0f) { pos = 0f; if (vel < 0f) vel = 0f }
            if (pos > max) { pos = max.toFloat(); if (vel > 0f) vel = 0f }
            if (abs(goalValue - pos) < 0.4f && abs(vel) < 2f) {
                pos = goalValue
                vel = 0f
                driving = false
                applyPos()
                return
            }
            applyPos()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun applyPos() {
        internalSet = true
        try { super.setProgress(pos.roundToInt()) } finally { internalSet = false }
        mirror?.pushProgress(pos.roundToInt())
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animOn = Motion.enabled(context)
    }

    override fun onDetachedFromWindow() {
        halt()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (changedView === this) mirror?.visibility = visibility
        if (visibility == View.VISIBLE) animOn = Motion.enabled(context)
    }
}
