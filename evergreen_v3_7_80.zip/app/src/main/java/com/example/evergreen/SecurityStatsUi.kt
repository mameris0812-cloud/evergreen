package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.color.MaterialColors
import java.util.Calendar
import java.util.Locale

/**
 * 설정 > 보안 현황.
 * 보호 수준(약하게/보통/최대) 막대, 오늘 차단 건수, 최근 7일 막대 그래프, 종류별 오늘 건수를 한 화면에 보여 준다.
 */
object SecurityStatsUi {

    /** 지금 켜져 있는 보호 기능들 */
    class Toggles(
        val adBlock: Boolean,
        val malware: Boolean,
        val https: Boolean,
        val autoDownload: Boolean,
        val backRedirect: Boolean,
        val hijack: Boolean,
        val strictTrackers: Boolean,
        val skipCaptcha: Boolean
    ) {
        private val core get() = listOf(adBlock, malware, https, autoDownload, backRedirect, hijack)
        val score: Int get() = core.count { it } + listOf(strictTrackers, skipCaptcha).count { it }

        /** 0 약하게 / 1 보통 / 2 최대 */
        val level: Int get() = when {
            score == MAX_SCORE -> 2
            core.count { it } >= 5 -> 1
            else -> 0
        }

        /** 꺼져 있는 보호 기능 이름 */
        fun off(): List<String> = buildList {
            if (!adBlock) add("광고 차단")
            if (!malware) add("악성 사이트 알림")
            if (!https) add("HTTPS 우선 연결")
            if (!autoDownload) add("자동 다운로드 차단")
            if (!backRedirect) add("뒤로가기 중 자동 이동 차단")
            if (!hijack) add("클릭 가로채기 이동 차단")
            if (!strictTrackers) add("트래커 차단(엄격)")
            if (!skipCaptcha) add("캡차 건너뛰기(서드파티 쿠키 차단)")
        }
    }

    private const val MAX_SCORE = 8

    private val LEVELS = arrayOf("약하게", "보통", "최대")

    /** 설정 목록 줄에 보여 줄 한 줄 요약 */
    fun summary(t: Toggles): String {
        val today = SecurityStats.todayTotal()
        return "보호 수준 ${LEVELS[t.level]} · " + if (today == 0) "오늘 차단 없음" else "오늘 ${n(today)}번 차단"
    }

    private fun n(v: Int) = String.format(Locale.getDefault(), "%,d", v)

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private val KIND_LABELS = arrayOf(
        "광고·추적 요청", "광고 팝업·페이지 이동", "트래커 (엄격 모드)", "클릭 가로채기 이동",
        "자동 다운로드", "뒤로가기 중 자동 이동", "악성 사이트", "보안 연결(HTTPS)로 올림"
    )
    private val KIND_COLORS = intArrayOf(
        0xFF7E57C2.toInt(), 0xFFEF5350.toInt(), 0xFF5C6BC0.toInt(), 0xFFFF9800.toInt(),
        0xFF26A69A.toInt(), 0xFF42A5F5.toInt(), 0xFFD81B60.toInt(), 0xFF66BB6A.toInt()
    )

    /** @param origin 새 탭 화면 위젯에서 열 때 그 카드: 카드가 펼쳐져 이 창이 되고, 닫으면 다시 카드로 접힌다 */
    fun show(ctx: Context, toggles: Toggles, origin: View? = null): Dialog {
        SecurityStats.flush()
        val onSurface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = ThemeColors.get(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val track = ThemeColors.get(ctx, com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFFE6E6E6.toInt())
        val outline = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt())
        val surface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val week = SecurityStats.week()
        val today = week.last()

        return Popup.panel(
            ctx,
            title = "보안 현황",
            subtitle = "최근 7일 · 이 기기에만 저장돼요",
            headerIcon = R.drawable.ic_shield,
            widthDp = 380,
            origin = origin,
            secondaryLabel = "기록 지우기",
            onSecondary = { d ->
                Popup.confirm(
                    ctx, "기록을 지울까요?",
                    "최근 7일 차단 기록이 0으로 돌아갑니다. 설정은 그대로예요.",
                    "지우기", danger = true
                ) {
                    SecurityStats.reset()
                    Popup.dismissNow(d)
                    show(ctx, toggles, origin)
                }
            }
        ) { list, dialog ->
            var todayTv: TextView? = null
            var bars: View? = null
            val kindTvs = arrayOfNulls<TextView>(SecurityStats.KINDS)
            // 보호 수준 막대
            list.addView(
                LevelBar(ctx, toggles.score.toFloat() / MAX_SCORE, primary, track),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 18)).apply {
                    setMargins(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), 0)
                }
            )
            list.addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), 0)
                val gravities = intArrayOf(Gravity.START, Gravity.CENTER_HORIZONTAL, Gravity.END)
                for (i in 0..2) {
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = gravities[i]
                        val active = i == toggles.level
                        addView(TextView(ctx).apply {
                            text = LEVELS[i]
                            textSize = 14f
                            if (active) setTypeface(typeface, Typeface.BOLD)
                            setTextColor(if (active) primary else onVar)
                            gravity = Gravity.CENTER
                        })
                        addView(TextView(ctx).apply {
                            text = if (i == 1) "권장" else " "
                            textSize = 12f
                            setTextColor(primary)
                            gravity = Gravity.CENTER
                        })
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
            })
            val off = toggles.off()
            if (off.isNotEmpty()) {
                list.addView(TextView(ctx).apply {
                    text = "꺼져 있어요: " + off.joinToString(" · ")
                    textSize = 12f
                    setTextColor(onVar)
                    setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), 0)
                })
            }

            // 오늘 차단 건수
            list.addView(TextView(ctx).apply {
                todayTv = this
                text = if (today == 0) "오늘은 아직 차단한 게 없어요" else "오늘 ${n(today)}번 차단함"
                textSize = 22f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(onSurface)
                setPadding(dp(ctx, 12), dp(ctx, 20), dp(ctx, 12), dp(ctx, 4))
            })

            // 최근 7일 막대 그래프
            val cal = Calendar.getInstance()
            val dow = "일월화수목금토"
            val labels = Array(7) { i ->
                val c = cal.clone() as Calendar
                c.add(Calendar.DAY_OF_YEAR, -(6 - i))
                dow[c.get(Calendar.DAY_OF_WEEK) - 1].toString()
            }
            val weekBars = WeekBars(ctx, week, labels, primary, onVar, outline, onSurface, surface)
            bars = weekBars
            list.addView(
                weekBars,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 200)).apply {
                    setMargins(dp(ctx, 8), dp(ctx, 4), dp(ctx, 8), 0)
                }
            )

            // 종류별 (오늘 / 7일)
            list.addView(TextView(ctx).apply {
                text = "종류별 (오늘 · 7일)"
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(primary)
                setPadding(dp(ctx, 12), dp(ctx, 14), dp(ctx, 12), dp(ctx, 4))
            })
            for (k in SecurityStats.FIRST_SECURITY until SecurityStats.KINDS) {
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
                    addView(View(ctx).apply {
                        background = GradientDrawable().apply {
                            cornerRadius = dp(ctx, 5).toFloat()
                            setColor(KIND_COLORS[k])
                        }
                    }, LinearLayout.LayoutParams(dp(ctx, 22), dp(ctx, 9)).apply { marginEnd = dp(ctx, 12) })
                    addView(TextView(ctx).apply {
                        text = KIND_LABELS[k]
                        textSize = 14f
                        setTextColor(onSurface)
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    addView(TextView(ctx).apply {
                        kindTvs[k] = this
                        text = "${n(SecurityStats.today(k))} · ${n(SecurityStats.weekTotal(k))}"
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(onVar)
                        setPadding(dp(ctx, 12), 0, 0, 0)
                    })
                })
            }

            // 창이 떠 있는 동안 차단 기록이 바뀌면 숫자·그래프도 바로 따라 바뀐다 (0.3초에 한 번만 갱신)
            val queued = java.util.concurrent.atomic.AtomicBoolean(false)
            var shownOnce = false
            val live = object : Runnable {
                override fun run() {
                    if (dialog.isShowing) shownOnce = true
                    else if (shownOnce) { SecurityStats.removeListener(this); return }
                    if (!queued.compareAndSet(false, true)) return
                    val anchor = todayTv ?: return
                    anchor.postDelayed({
                        queued.set(false)
                        if (!dialog.isShowing) return@postDelayed
                        val w = SecurityStats.week()
                        System.arraycopy(w, 0, week, 0, week.size)
                        bars?.invalidate()
                        val t = w.last()
                        todayTv?.text = if (t == 0) "오늘은 아직 차단한 게 없어요" else "오늘 ${n(t)}번 차단함"
                        for (k in SecurityStats.FIRST_SECURITY until SecurityStats.KINDS) {
                            kindTvs[k]?.text = "${n(SecurityStats.today(k))} · ${n(SecurityStats.weekTotal(k))}"
                        }
                    }, 300L)
                }
            }
            SecurityStats.addListener(live)
        }
    }

    /** 보호 수준 막대: 켜 둔 보호 기능 비율만큼 채운다 */
    private class LevelBar(ctx: Context, val fraction: Float, val color: Int, val trackColor: Int) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val r = height / 2f
            val rect = RectF(0f, 0f, width.toFloat(), height.toFloat())
            p.shader = null
            p.color = trackColor
            c.drawRoundRect(rect, r, r, p)
            val fw = (width * fraction.coerceIn(0.08f, 1f))
            val light = (color and 0x00FFFFFF) or 0x99000000.toInt()
            p.shader = LinearGradient(0f, 0f, fw, 0f, light, color, Shader.TileMode.CLAMP)
            c.drawRoundRect(RectF(0f, 0f, fw, height.toFloat()), r, r, p)
            p.shader = null
        }
    }

    /** 최근 7일 막대 그래프 (맨 오른쪽이 오늘) */
    private class WeekBars(
        ctx: Context, val data: IntArray, val labels: Array<String>,
        val barColor: Int, val textColor: Int, val lineColor: Int, val todayBg: Int, val todayText: Int
    ) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val d = ctx.resources.displayMetrics.density
        private fun px(v: Int) = v * d
        private fun px(v: Float) = v * d

        private fun niceTop(max: Int): Int {
            val steps = intArrayOf(4, 8, 10, 20, 40, 60, 80, 100, 200, 400, 600, 800, 1000, 2000, 4000, 6000, 8000, 10000, 20000, 40000, 100000, 1000000)
            return steps.firstOrNull { it >= max } ?: (((max + 1) / 2) * 2)
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val chartL = px(4)
            val chartR = w - px(40)
            val top = px(26)
            val bottom = height - px(40)
            val today = SecurityStats.dayKey()
            val totals = IntArray(7) { i -> SecurityStats.dayTotal(today - (6 - i)) }
            val topV = niceTop(totals.maxOrNull() ?: 0)

            p.textSize = px(12)
            p.strokeWidth = px(1)
            p.style = Paint.Style.FILL
            // 눈금선 + 오른쪽 숫자
            for (v in intArrayOf(topV, topV / 2)) {
                val y = bottom - (bottom - top) * v / topV
                p.color = lineColor
                c.drawLine(chartL, y, chartR, y, p)
                p.color = textColor
                p.textAlign = Paint.Align.LEFT
                c.drawText(v.toString(), chartR + px(8), y + px(4), p)
            }
            p.color = lineColor
            c.drawLine(chartL, bottom, chartR, bottom, p)

            val slot = (chartR - chartL) / 7f
            val barW = slot * 0.42f
            val path = android.graphics.Path()
            for (i in 0 until 7) {
                val cx = chartL + slot * (i + 0.5f)
                val v = totals[i]
                if (v > 0) {
                    var h = (bottom - top) * v / topV
                    if (h < barW) h = barW
                    // 아래 목록의 종류별 색 그대로 쌓아 올린다. 막대 전체는 위쪽 모서리만 둥글게 잘라 그린다
                    val r = barW / 2
                    path.reset()
                    path.addRoundRect(
                        RectF(cx - barW / 2, bottom - h, cx + barW / 2, bottom),
                        floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f), android.graphics.Path.Direction.CW
                    )
                    c.save()
                    c.clipPath(path)
                    var y = bottom
                    p.shader = null
                    for (k in SecurityStats.FIRST_SECURITY until SecurityStats.KINDS) {
                        val cnt = SecurityStats.count(today - (6 - i), k)
                        if (cnt <= 0) continue
                        val segH = h * cnt / v
                        // 각 종류 색마다 위는 연하게 → 아래는 원래 색으로 이어지는 그라데이션
                        val base = KIND_COLORS[k]
                        val light = androidx.core.graphics.ColorUtils.blendARGB(base, 0xFFFFFFFF.toInt(), 0.4f)
                        p.shader = LinearGradient(0f, y - segH, 0f, y, light, base, Shader.TileMode.CLAMP)
                        c.drawRect(cx - barW / 2, y - segH, cx + barW / 2, y, p)
                        p.shader = null
                        y -= segH
                    }
                    c.restore()
                    // 막대 위에 정확한 건수
                    p.color = textColor
                    p.textAlign = Paint.Align.CENTER
                    p.typeface = Typeface.DEFAULT_BOLD
                    c.drawText(v.toString(), cx, bottom - h - px(6), p)
                    p.typeface = Typeface.DEFAULT
                } else {
                    // 0건인 날도 비어 보이지 않게 바닥에 작은 막대
                    p.color = lineColor
                    c.drawRoundRect(RectF(cx - barW / 2, bottom - px(3), cx + barW / 2, bottom), px(1.5f), px(1.5f), p)
                }
                val ly = bottom + px(24)
                p.textAlign = Paint.Align.CENTER
                if (i == 6) {
                    p.color = todayBg
                    c.drawCircle(cx, ly - px(4), px(12), p)
                    p.color = todayText
                    p.typeface = Typeface.DEFAULT_BOLD
                } else {
                    p.color = textColor
                    p.typeface = Typeface.DEFAULT
                }
                c.drawText(labels[i], cx, ly, p)
                p.typeface = Typeface.DEFAULT
            }
        }
    }
}
