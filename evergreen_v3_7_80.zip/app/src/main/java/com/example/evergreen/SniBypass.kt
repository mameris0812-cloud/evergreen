package com.example.evergreen

import android.annotation.SuppressLint
import android.content.Context
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 접속 차단(SNI 검열) 우회. 유니콘 HTTPS 와 같은 방식을 앱 안에 직접 넣은 것.
 *
 * 웹뷰의 https 연결을 앱 안의 로컬 프록시(127.0.0.1)로 보내고, 프록시가 사이트에 연결하면서
 *  1) DNS 는 DoH(암호화 DNS)로 직접 조회하고 (통신사 DNS 차단 회피)
 *  2) TLS 첫 패킷(ClientHello)을 사이트 이름(SNI) 한가운데에서 둘로 쪼개 보낸다 (이름을 한 번에 읽는 차단 장비 회피).
 * 쪼갠 연결을 사이트가 받아 주지 않으면 더 약한 방식 → 원본 순서로 자동으로 되돌린다 (사이트별로 기억).
 *
 * 내용은 건드리지 않고 그대로 중계만 하므로 속도 저하는 거의 없다. 웹뷰에만 적용된다 (다운로드·플레이어 연결은 해당 없음).
 */
object SniBypass {
    private const val MODE_RECORD = 0 // TLS 기록을 둘로 나누고, 패킷도 따로 보낸다
    private const val MODE_TCP = 1    // 기록은 그대로, 패킷만 둘로 나눠 보낸다
    private const val MODE_RAW = 2    // 손대지 않고 그대로

    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "sni-bypass").apply { isDaemon = true } }
    @Volatile private var server: ServerSocket? = null

    /** 사이트별로 통했던 방식 (처음에는 RECORD 부터 시도) */
    private val hostMode = ConcurrentHashMap<String, Int>()

    /** 기본(RECORD)이 아닌 방식으로만 통한 사이트는 앱을 껐다 켜도 기억해, 매번 안 되는 방식을 먼저 시도하느라 기다리지 않게 한다 */
    @Volatile private var modePrefs: android.content.SharedPreferences? = null
    private const val MODE_KEEP_MS = 14L * 24 * 3600 * 1000

    private fun loadModes(c: Context) {
        if (modePrefs != null) return
        val sp = c.applicationContext.getSharedPreferences("sni_modes", Context.MODE_PRIVATE)
        modePrefs = sp
        val now = System.currentTimeMillis()
        val old = ArrayList<String>()
        for ((k, v) in sp.all) {
            val t = (v as? String)?.split(':') ?: continue
            val m = t.getOrNull(0)?.toIntOrNull(); val at = t.getOrNull(1)?.toLongOrNull()
            if (m == null || at == null || now - at > MODE_KEEP_MS) { old.add(k); continue }
            hostMode.putIfAbsent(k, m)
        }
        if (old.isNotEmpty()) sp.edit().apply { old.forEach { remove(it) } }.apply()
    }

    private fun remember(host: String, mode: Int) {
        val prev = hostMode.put(host, mode)
        val sp = modePrefs ?: return
        if (mode == MODE_RECORD) { if (prev != null && prev != MODE_RECORD) sp.edit().remove(host).apply() }
        else if (prev != mode) sp.edit().putString(host, "$mode:${System.currentTimeMillis()}").apply()
    }

    private data class Dns(val addrs: List<InetAddress>, val expires: Long)
    private val dnsCache = ConcurrentHashMap<String, Dns>()

    private val http = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    // ───────────────────────── 켜고 끄기 ─────────────────────────

    /** 확장 프로그램(chrome.proxy)이 정한 프록시. 켜져 있으면 접속 차단 우회보다 우선한다 */
    class ExtProxy(
        val rules: List<Pair<String, String>>, // (프록시 주소, 적용할 주소 종류: ProxyConfig.MATCH_*)
        val bypass: List<String>,
        val direct: Boolean,                   // 프록시 없이 직접 연결 (mode: direct)
        val bypassLocal: Boolean               // <local> (점 없는 주소는 프록시를 거치지 않음)
    )

    @Volatile private var extProxy: ExtProxy? = null
    @Volatile private var wantSni = false

    /** 확장 프로그램 프록시를 웹뷰 설정으로 바꾼다. 잘못된 값이면 IllegalArgumentException */
    fun buildExt(ext: ExtProxy): ProxyConfig {
        val b = ProxyConfig.Builder()
        if (ext.direct) {
            b.addDirect()
        } else {
            for ((url, scheme) in ext.rules) b.addProxyRule(url, scheme)
            for (r in ext.bypass) b.addBypassRule(r)
            if (ext.bypassLocal) b.bypassSimpleHostnames()
        }
        return b.build()
    }

    /** 확장 프로그램 프록시를 켜거나(null 이면 끄고 원래 설정으로) 한다. 웹뷰가 지원하지 않으면 false */
    fun setExtProxy(ext: ExtProxy?): Boolean {
        extProxy = ext
        return reapply()
    }

    /** 설정에 맞춰 프록시를 켜거나 끈다. 웹뷰가 프록시 설정을 지원하지 않으면 false */
    fun apply(context: Context, enabled: Boolean): Boolean {
        if (enabled) loadModes(context)
        wantSni = enabled
        return reapply()
    }

    @Synchronized
    @SuppressLint("RequiresFeature")
    private fun reapply(): Boolean {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return false
        val exec = Runnable::run
        return try {
            val ext = extProxy
            if (ext != null) {
                ProxyController.getInstance().setProxyOverride(buildExt(ext), exec) {}
            } else if (wantSni) {
                val port = ensureServer()
                val cfg = ProxyConfig.Builder()
                    .addProxyRule("127.0.0.1:$port", ProxyConfig.MATCH_HTTPS) // https 만 프록시로, http 는 그대로
                    .addBypassRule("127.0.0.1")
                    .addBypassRule("localhost")
                    .bypassSimpleHostnames()
                    .build()
                ProxyController.getInstance().setProxyOverride(cfg, exec) {}
            } else {
                ProxyController.getInstance().clearProxyOverride(exec) {}
            }
            true
        } catch (e: Throwable) {
            false
        }
    }

    @Synchronized
    private fun ensureServer(): Int {
        server?.let { if (!it.isClosed) return it.localPort }
        val ss = ServerSocket(0, 64, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)))
        server = ss
        pool.execute {
            while (!ss.isClosed) {
                val c = try { ss.accept() } catch (e: IOException) { break }
                pool.execute { runCatching { handle(c) }.also { runCatching { c.close() } } }
            }
        }
        return ss.localPort
    }

    // ───────────────────────── 연결 처리 ─────────────────────────

    private fun handle(client: Socket) {
        client.tcpNoDelay = true
        client.soTimeout = 15_000
        val cin = client.getInputStream()
        val cout = client.getOutputStream()

        // CONNECT host:port HTTP/1.1 + 헤더
        val head = readHead(cin) ?: return
        val first = head.substringBefore("\r\n")
        val parts = first.split(' ')
        if (parts.size < 2 || !parts[0].equals("CONNECT", true)) {
            cout.write("HTTP/1.1 405 Method Not Allowed\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
            return
        }
        val target = parts[1]
        val host = target.substringBeforeLast(':').trim('[', ']')
        val port = target.substringAfterLast(':', "443").toIntOrNull() ?: 443

        var addrs = resolve(host)
        if (addrs.isEmpty()) {
            cout.write("HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
            return
        }
        cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
        cout.flush()

        // 브라우저가 보내는 첫 TLS 기록(ClientHello)을 통째로 읽는다
        val hello = readTlsRecord(cin) ?: return
        val sni = findSni(hello)

        var retriedFresh = false
        while (true) {
            var mode = if (sni == null) MODE_RAW else hostMode[host] ?: MODE_RECORD
            var remote: Pair<Socket, ByteArray>? = null
            while (true) {
                remote = connectAndSend(addrs, port, hello, sni, mode)
                if (remote != null) { if (sni != null) remember(host, mode); break }
                if (mode >= MODE_RAW) break
                mode++
            }
            if (remote != null) {
                pipe(client, remote.first, remote.second)
                return
            }
            // 기억해 둔 (만료된) 주소로 안 붙으면 새로 조회해서 한 번 더 시도한다
            if (retriedFresh) return
            retriedFresh = true
            dnsCache.remove(host)
            val fresh = resolve(host)
            if (fresh.isEmpty() || fresh == addrs) return
            addrs = fresh
        }
    }

    /** 사이트에 연결해 첫 패킷을 보내고, 사이트가 답하면 (소켓, 첫 응답)을 돌려준다. 답이 없거나 끊기면 null */
    private fun connectAndSend(
        addrs: List<InetAddress>, port: Int, hello: ByteArray, sni: IntRange?, mode: Int
    ): Pair<Socket, ByteArray>? {
        val s = connectFirst(addrs, port) ?: return null
        return finishConnect(s, hello, sni, mode)
    }

    /** 주소가 여러 개면 0.25초 간격으로 차례로 동시에 시도해 가장 먼저 붙는 연결을 쓴다 (첫 주소가 죽어 있어도 몇 초씩 기다리지 않는다) */
    private fun connectFirst(addrs: List<InetAddress>, port: Int): Socket? {
        val list = addrs.take(4)
        if (list.isEmpty()) return null
        if (list.size == 1) {
            val s = Socket()
            return try { s.connect(InetSocketAddress(list[0], port), 3_500); s } catch (_: Exception) { runCatching { s.close() }; null }
        }
        // LinkedBlockingQueue 는 null 을 넣으면 NullPointerException 이라 (예전에 이 때문에 앱이 꺼졌다), 실패는 빈 Optional 로 표시한다
        val q = LinkedBlockingQueue<java.util.Optional<Socket>>()
        val done = AtomicBoolean(false)
        list.forEachIndexed { i, a ->
            pool.execute {
                var winner: Socket? = null
                var s: Socket? = null
                try {
                    if (i > 0) try { Thread.sleep(250L * i) } catch (_: InterruptedException) {}
                    if (!done.get()) {
                        s = Socket()
                        s.connect(InetSocketAddress(a, port), 3_500)
                        if (done.compareAndSet(false, true)) winner = s
                    }
                } catch (_: Throwable) {
                    // IOException 외에 포트 범위 오류 등이 나도 이 스레드에서 앱이 꺼지지 않게 한다
                } finally {
                    if (winner == null) s?.let { runCatching { it.close() } }
                    // 성공이든 실패든 결과를 정확히 하나 넣는다 (기다리는 쪽이 헛되이 시간 초과를 기다리지 않게)
                    q.add(java.util.Optional.ofNullable(winner))
                }
            }
        }
        repeat(list.size) {
            val r = q.poll(6, TimeUnit.SECONDS) ?: return null
            if (r.isPresent) return r.get()
        }
        return null
    }

    private fun finishConnect(s: Socket, hello: ByteArray, sni: IntRange?, mode: Int): Pair<Socket, ByteArray>? {
        try {
            s.tcpNoDelay = true
            // 쪼갠 방식이 안 통하는 사이트는 응답이 아예 없을 수 있어 짧게 기다리고 다음 방식으로 넘어간다 (손대지 않는 방식은 넉넉히)
            s.soTimeout = if (mode == MODE_RAW) 6_000 else 3_000
            val out = s.getOutputStream()
            val cut = if (sni != null) sni.first + (sni.last - sni.first + 1) / 2 else -1
            if (mode == MODE_RAW || cut <= 5 || cut >= hello.size) {
                out.write(hello); out.flush()
            } else if (mode == MODE_TCP) {
                out.write(hello, 0, cut); out.flush()
                pause()
                out.write(hello, cut, hello.size - cut); out.flush()
            } else {
                // 기록 둘로 나누기: [헤더 + 앞부분] [헤더 + 뒷부분]
                val v1 = hello[1]; val v2 = hello[2]
                val a = cut - 5
                val b = hello.size - cut
                val r1 = ByteArray(5 + a)
                r1[0] = 0x16; r1[1] = v1; r1[2] = v2; r1[3] = (a shr 8).toByte(); r1[4] = a.toByte()
                System.arraycopy(hello, 5, r1, 5, a)
                val r2 = ByteArray(5 + b)
                r2[0] = 0x16; r2[1] = v1; r2[2] = v2; r2[3] = (b shr 8).toByte(); r2[4] = b.toByte()
                System.arraycopy(hello, cut, r2, 5, b)
                out.write(r1); out.flush()
                pause()
                out.write(r2); out.flush()
            }
            val buf = ByteArray(16 * 1024)
            val n = s.getInputStream().read(buf)
            if (n <= 0) { s.close(); return null }
            s.soTimeout = 0
            return s to buf.copyOf(n)
        } catch (e: IOException) {
            runCatching { s.close() }
            return null
        }
    }

    private fun pause() { try { Thread.sleep(1) } catch (_: InterruptedException) {} }

    /** 양쪽으로 그대로 중계한다 */
    private fun pipe(client: Socket, remote: Socket, firstFromRemote: ByteArray) {
        client.soTimeout = 0
        val cout = client.getOutputStream()
        cout.write(firstFromRemote); cout.flush()
        val up = pool.submit {
            copy(client.getInputStream(), remote.getOutputStream())
            runCatching { remote.shutdownOutput() }
        }
        copy(remote.getInputStream(), cout)
        runCatching { client.shutdownOutput() }
        runCatching { up.get(30, TimeUnit.SECONDS) }
        runCatching { remote.close() }
    }

    private fun copy(i: InputStream, o: OutputStream) {
        val buf = ByteArray(64 * 1024)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n); o.flush()
            }
        } catch (_: IOException) {}
    }

    // ───────────────────────── 읽기 · 해석 ─────────────────────────

    private fun readHead(i: InputStream): String? {
        val sb = StringBuilder()
        var last4 = 0
        while (sb.length < 8192) {
            val b = i.read()
            if (b < 0) return null
            sb.append(b.toChar())
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) return sb.toString()
        }
        return null
    }

    @Throws(IOException::class)
    private fun readFully(i: InputStream, buf: ByteArray, off: Int, len: Int) {
        var p = 0
        while (p < len) {
            val n = i.read(buf, off + p, len - p)
            if (n < 0) throw EOFException()
            p += n
        }
    }

    /** TLS 기록 하나(헤더 5바이트 + 본문)를 통째로 읽는다. TLS 가 아니면 null */
    private fun readTlsRecord(i: InputStream): ByteArray? {
        return try {
            val h = ByteArray(5)
            readFully(i, h, 0, 5)
            if (h[0].toInt() != 0x16) return null
            val len = ((h[3].toInt() and 0xFF) shl 8) or (h[4].toInt() and 0xFF)
            if (len <= 0 || len > 16 * 1024 + 256) return null
            val r = ByteArray(5 + len)
            System.arraycopy(h, 0, r, 0, 5)
            readFully(i, r, 5, len)
            r
        } catch (e: IOException) { null }
    }

    /** ClientHello 안에서 사이트 이름(SNI) 글자가 있는 범위(전체 배열 기준 인덱스)를 찾는다 */
    private fun findSni(r: ByteArray): IntRange? {
        try {
            fun u8(p: Int) = r[p].toInt() and 0xFF
            fun u16(p: Int) = (u8(p) shl 8) or u8(p + 1)
            if (r.size < 45 || u8(0) != 0x16 || u8(5) != 0x01) return null
            var p = 5 + 4 + 2 + 32 // 기록 헤더 + 핸드셰이크 헤더 + 버전 + 랜덤
            p += 1 + u8(p)         // 세션 ID
            p += 2 + u16(p)        // 암호 목록
            p += 1 + u8(p)         // 압축 방식
            val extEnd = p + 2 + u16(p)
            p += 2
            while (p + 4 <= extEnd && p + 4 <= r.size) {
                val type = u16(p); val len = u16(p + 2)
                if (type == 0) { // server_name
                    // 목록 길이(2) + 종류(1) + 이름 길이(2) + 이름
                    val nameLen = u16(p + 4 + 3)
                    val start = p + 4 + 5
                    if (nameLen > 0 && start + nameLen <= r.size) return start until start + nameLen
                    return null
                }
                p += 4 + len
            }
        } catch (_: IndexOutOfBoundsException) {}
        return null
    }

    // ───────────────────────── DNS (DoH) ─────────────────────────

    private val DOH_SERVERS = listOf("https://1.1.1.1/dns-query", "https://8.8.8.8/resolve", "https://9.9.9.9:5053/dns-query")

    /** DoH 조회 전용 (조회 하나가 오래 걸려도 오래 붙잡지 않도록 짧게) */
    private val dohHttp = http.newBuilder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(2, TimeUnit.SECONDS)
        .callTimeout(3, TimeUnit.SECONDS)
        .build()

    /** 같은 사이트를 동시에 조회하는 연결이 여러 개여도 조회는 한 번만 한다 */
    private val inflight = ConcurrentHashMap<String, java.util.concurrent.FutureTask<List<InetAddress>>>()

    /** 켜져 있을 때만, 곧 열 사이트의 주소를 미리 조회해 캐시에 넣어 둔다 (처음 가는 사이트가 느리던 주된 이유) */
    fun prefetch(host: String?) {
        if (host.isNullOrEmpty() || !wantSni || extProxy != null) return
        pool.execute { runCatching { resolve(host) } }
    }

    private fun resolve(host: String): List<InetAddress> {
        if (host.isEmpty()) return emptyList()
        // IP 주소나 내부 이름은 그대로
        val ipLiteral = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host) || host.contains(':')
        if (ipLiteral || !host.contains('.')) return runCatching { InetAddress.getAllByName(host).toList() }.getOrDefault(emptyList())
        val now = System.currentTimeMillis()
        dnsCache[host]?.let { c ->
            if (c.expires > now) return c.addrs
            // 만료됐어도 1시간 안이면 일단 그 주소로 바로 연결하고, 새 주소는 뒤에서 받아 둔다 (재방문이 조회를 기다리지 않게).
            // 그 주소로 안 붙으면 연결 쪽에서 새로 조회해 다시 시도한다
            if (now - c.expires < STALE_MS) { pool.execute { runCatching { resolveFresh(host) } }; return c.addrs }
        }
        return resolveFresh(host)
    }

    private const val STALE_MS = 3_600_000L

    private fun resolveFresh(host: String): List<InetAddress> {
        val ft = java.util.concurrent.FutureTask { lookup(host) }
        val prev = inflight.putIfAbsent(host, ft)
        val task = prev ?: ft.also { it.run() }
        return try {
            task.get(10, TimeUnit.SECONDS)
        } catch (e: Exception) {
            emptyList()
        } finally {
            if (prev == null) inflight.remove(host)
        }
    }

    private fun lookup(host: String): List<InetAddress> {
        // DoH 서버 세 곳에 한꺼번에 물어 가장 먼저 답한 쪽을 쓴다 (전에는 한 곳씩 차례로 물어, 한 곳이 막히면 서버마다 몇 초씩 기다렸다)
        val doh = try {
            pool.invokeAny(
                DOH_SERVERS.map { base -> java.util.concurrent.Callable { doh(host, base) ?: throw IOException("no answer") } },
                4, TimeUnit.SECONDS
            )
        } catch (e: Exception) { null }
        val addrs = doh?.first ?: runCatching { InetAddress.getAllByName(host).toList() }.getOrDefault(emptyList())
        if (addrs.isNotEmpty()) {
            val ttl = (doh?.second ?: 60).coerceIn(120, 1800)
            dnsCache[host] = Dns(addrs, System.currentTimeMillis() + ttl * 1000L)
        }
        return addrs
    }

    private fun doh(host: String, base: String): Pair<List<InetAddress>, Int>? {
        return try {
            val req = Request.Builder()
                .url("$base?name=$host&type=A")
                .header("accept", "application/dns-json")
                .build()
            dohHttp.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val ans = JSONObject(resp.body?.string() ?: return null).optJSONArray("Answer") ?: return null
                val list = ArrayList<InetAddress>()
                var ttl = 300
                for (k in 0 until ans.length()) {
                    val a = ans.getJSONObject(k)
                    if (a.optInt("type") == 1) {
                        list.add(InetAddress.getByName(a.getString("data")))
                        ttl = minOf(ttl, a.optInt("TTL", 300))
                    }
                }
                if (list.isEmpty()) null else list to ttl
            }
        } catch (e: Exception) { null }
    }
}
