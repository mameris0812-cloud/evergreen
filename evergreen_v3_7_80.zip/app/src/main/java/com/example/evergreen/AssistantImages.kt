package com.example.evergreen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.util.Base64
import android.util.LruCache
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * AI 어시스턴트가 페이지의 사진을 읽을 수 있게, 페이지 안의 사진을 골라 내려받고 Gemini 가 받기 좋은 크기의 JPEG 로 만든다.
 *
 * - 사진 목록은 페이지 JS(`MainActivity.PAGE_TEXT_JS`)가 알려 준다. 지금 화면에 보이는 사진을 먼저 고른다.
 * - 웹툰처럼 세로로 아주 긴 사진은 통째로 줄이면 글자가 뭉개지므로, 화면에 보이는 부분만 잘라 보낸다.
 * - 아이콘·로고처럼 작은 사진은 JS 와 여기서 한 번씩 걸러낸다.
 * - 내려받을 때는 웹뷰와 같은 User-Agent·쿠키·Referer 를 써서, 로그인이 필요하거나 핫링크를 막는 사진도 받는다.
 * - 반드시 백그라운드 스레드에서 부른다.
 */
object AssistantImages {
    /** 한 번에 AI 에게 보내는 사진 수 */
    const val MAX_IMAGES = 6

    /** 사진의 긴 변을 이 크기(px)까지만 보낸다 */
    private const val MAX_SIDE = 1280

    /** 이보다 작은 사진(아이콘·추적 픽셀 등)은 읽을 가치가 없어 건너뛴다 */
    private const val MIN_SIDE = 100

    /** 사진 한 장을 이 크기(바이트)까지만 내려받는다 */
    private const val MAX_DOWNLOAD = 12 * 1024 * 1024

    /** 사진을 다 받아 오는 데 기다리는 최대 시간 */
    private const val TOTAL_TIMEOUT_SEC = 20L

    /** 페이지 JS 가 알려 준 사진 후보 한 장 */
    class Cand(
        val url: String,
        val alt: String,
        /** 지금 화면에 보이는 넓이(CSS px²). 0 이면 화면 밖 */
        val vis: Double,
        /** 사진이 차지하는 전체 넓이(CSS px²) */
        val area: Double,
        /** 화면에 보이는 세로 구간(사진 높이 대비 0~1). 화면 밖이면 -1 */
        val y0: Double,
        val y1: Double
    )

    private val pool = Executors.newFixedThreadPool(3) { r -> Thread(r).apply { isDaemon = true } }

    /** 방금 받은 사진 원본 (같은 사진을 또 묻거나 스크롤해서 다른 부분을 볼 때 다시 받지 않게) */
    private val bytesCache = object : LruCache<String, ByteArray>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray): Int = value.size
    }

    /** 페이지 JS 의 `imgs` 배열을 후보 목록으로 바꾼다 */
    fun parse(arr: JSONArray?): List<Cand> {
        if (arr == null) return emptyList()
        val out = ArrayList<Cand>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val u = o.optString("u")
            if (u.isEmpty()) continue
            out.add(
                Cand(
                    url = u,
                    alt = o.optString("alt"),
                    vis = o.optDouble("vis", 0.0),
                    area = o.optDouble("area", 0.0),
                    y0 = o.optDouble("y0", -1.0),
                    y1 = o.optDouble("y1", -1.0)
                )
            )
        }
        return out
    }

    /** 보내 줄 사진을 고른다: 화면에 많이 보이는 것부터, 모자라면 큰 사진부터 */
    fun pick(all: List<Cand>): List<Cand> {
        val visible = all.filter { it.vis > 0 }.sortedByDescending { it.vis }
        val rest = all.filter { it.vis <= 0 }.sortedByDescending { it.area }
        return (visible + rest).take(MAX_IMAGES)
    }

    /**
     * 고른 사진을 내려받아 JPEG(Base64)로 만든다. 못 받은 사진은 조용히 뺀다.
     * [cookies] 는 사진 주소별 쿠키(웹뷰의 쿠키 저장소에서 미리 꺼내 온 것).
     */
    fun load(picked: List<Cand>, userAgent: String, cookies: Map<String, String>, referer: String): List<PageImage> {
        val tasks = picked.map { c ->
            Callable<PageImage?> { loadOne(c, userAgent, cookies[c.url].orEmpty(), referer) }
        }
        val futures = try {
            pool.invokeAll(tasks, TOTAL_TIMEOUT_SEC, TimeUnit.SECONDS)
        } catch (e: InterruptedException) {
            return emptyList()
        }
        val out = ArrayList<PageImage>()
        for (f in futures) {
            if (f.isCancelled) continue
            try {
                f.get()?.let { out.add(it) }
            } catch (e: Exception) {
                // 이 사진만 건너뜀
            }
        }
        return out
    }

    /** 사용자가 꾹 눌러 고른 사진의 설명 맨 앞에 붙는 표시 (AI 안내문과 다시 생성에서 알아본다) */
    const val CHOSEN_TAG = "[사용자가 꾹 눌러 고른 사진]"

    /** 사용자가 꾹 눌러 고른 사진 한 장을 내려받아 JPEG(Base64)로 만든다. 못 받으면 null */
    fun loadChosen(c: Cand, userAgent: String, cookie: String, referer: String): PageImage? =
        loadOne(c, userAgent, cookie, referer, chosen = true)

    private fun loadOne(c: Cand, userAgent: String, cookie: String, referer: String, chosen: Boolean = false): PageImage? {
        return try {
            val bytes = fetchBytes(c.url, userAgent, cookie, referer) ?: return null
            val enc = encode(bytes, c) ?: return null
            val alt = c.alt.replace(Regex("\\s+"), " ").trim()
            val label = buildString {
                append(if (chosen) "$CHOSEN_TAG " else if (c.vis > 0) "[화면에 보임] " else "[화면 밖] ")
                append(if (alt.isNotEmpty()) alt else "(설명 없음)")
                if (enc.cropped) append(" (긴 사진 중 일부만)")
            }
            PageImage("image/jpeg", enc.base64, label)
        } catch (e: Throwable) {
            // 메모리 부족 등 — 이 사진만 건너뜀
            null
        }
    }

    // ───────────────────────── 내려받기 ─────────────────────────

    fun fetchBytes(url: String, userAgent: String, cookie: String, referer: String): ByteArray? {
        if (url.startsWith("data:")) return decodeDataUrl(url)
        if (!(url.startsWith("http://") || url.startsWith("https://"))) return null
        bytesCache.get(url)?.let { return it }
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 12000
            conn.instanceFollowRedirects = true
            if (userAgent.isNotEmpty()) conn.setRequestProperty("User-Agent", userAgent)
            if (referer.startsWith("http")) conn.setRequestProperty("Referer", referer)
            if (cookie.isNotEmpty()) conn.setRequestProperty("Cookie", cookie)
            conn.setRequestProperty("Accept", "image/webp,image/jpeg,image/png,image/*;q=0.8,*/*;q=0.5")
            if (conn.responseCode !in 200..299) return null
            if (conn.contentLengthLong > MAX_DOWNLOAD) return null
            val out = ByteArrayOutputStream()
            conn.inputStream.use { ins ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_DOWNLOAD) return null
                }
            }
            val bytes = out.toByteArray()
            bytesCache.put(url, bytes)
            return bytes
        } catch (e: Exception) {
            return null
        } finally {
            try {
                conn?.disconnect()
            } catch (e: Exception) {
                // 무시
            }
        }
    }

    /** `data:image/...;base64,....` 주소를 바이트로 푼다 (SVG 나 base64 가 아닌 것은 건너뜀) */
    private fun decodeDataUrl(u: String): ByteArray? {
        val comma = u.indexOf(',')
        if (comma < 0) return null
        val head = u.substring(0, comma).lowercase()
        if (!head.startsWith("data:image/") || head.contains("svg") || !head.contains(";base64")) return null
        return try {
            Base64.decode(u.substring(comma + 1), Base64.DEFAULT)
        } catch (e: Exception) {
            null
        }
    }

    // ───────────────────────── 자르고 줄이기 ─────────────────────────

    private class Enc(val base64: String, val cropped: Boolean)

    private fun encode(bytes: ByteArray, c: Cand): Enc? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w < MIN_SIDE || h < MIN_SIDE) return null

        // 세로로 아주 긴 사진(웹툰 등): 화면에 보이는 부분만 잘라 보낸다
        var top = 0
        var bottom = h
        if (h > w * 2) {
            if (c.y0 >= 0 && c.y1 > c.y0) {
                top = (c.y0 * h).toInt().coerceIn(0, h - 1)
                bottom = (c.y1 * h).toInt().coerceIn(top + 1, h)
            } else {
                // 화면 밖의 긴 사진은 맨 위 부분만
                bottom = minOf(h, w * 3 / 2)
            }
            // 너무 얇게 보이는 조각은 위아래로 넓힌다 (최소 가로의 3/4)
            val minH = minOf(h, w * 3 / 4)
            if (bottom - top < minH) {
                val mid = (top + bottom) / 2
                top = (mid - minH / 2).coerceIn(0, h - minH)
                bottom = top + minH
            }
            // 너무 길면 가로의 3배까지만
            if (bottom - top > w * 3) bottom = top + w * 3
        }
        val cropped = top > 0 || bottom < h

        // 긴 변이 MAX_SIDE 가까이 되도록 2의 거듭제곱으로 줄여 읽는다
        var sample = 1
        while (maxOf(w, bottom - top) / (sample * 2) >= MAX_SIDE) sample *= 2

        var bmp: Bitmap? = null
        if (cropped) {
            var dec: BitmapRegionDecoder? = null
            try {
                dec = BitmapRegionDecoder.newInstance(bytes, 0, bytes.size, false)
                val o = BitmapFactory.Options().apply { inSampleSize = sample }
                bmp = dec?.decodeRegion(Rect(0, top, w, bottom), o)
            } catch (e: Exception) {
                bmp = null
            } finally {
                try {
                    dec?.recycle()
                } catch (e: Exception) {
                    // 무시
                }
            }
        }
        if (bmp == null) {
            // 일부만 읽는 방법이 안 되면 통째로 읽되, 메모리를 아끼려고 충분히 줄여서 읽는다
            var s2 = sample
            while ((w.toLong() / s2) * (h.toLong() / s2) > 12_000_000L) s2 *= 2
            val full = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s2 })
                ?: return null
            bmp = if (cropped) {
                val sy = full.height.toDouble() / h
                val y = (top * sy).toInt().coerceIn(0, full.height - 1)
                val hh = ((bottom - top) * sy).toInt().coerceIn(1, full.height - y)
                val part = Bitmap.createBitmap(full, 0, y, full.width, hh)
                if (part !== full) full.recycle()
                part
            } else {
                full
            }
        }

        var out: Bitmap = bmp ?: return null
        val longSide = maxOf(out.width, out.height)
        if (longSide > MAX_SIDE) {
            val k = MAX_SIDE.toFloat() / longSide
            val scaled = Bitmap.createScaledBitmap(
                out, maxOf(1, (out.width * k).toInt()), maxOf(1, (out.height * k).toInt()), true
            )
            if (scaled !== out) out.recycle()
            out = scaled
        }
        // 투명한 부분은 흰 바탕에 얹는다 (JPEG 는 투명을 못 담아 검게 나온다)
        if (out.hasAlpha()) {
            val flat = Bitmap.createBitmap(out.width, out.height, Bitmap.Config.ARGB_8888)
            val cv = Canvas(flat)
            cv.drawColor(Color.WHITE)
            cv.drawBitmap(out, 0f, 0f, null)
            out.recycle()
            out = flat
        }
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 82, bos)
        out.recycle()
        val jpeg = bos.toByteArray()
        if (jpeg.isEmpty()) return null
        return Enc(Base64.encodeToString(jpeg, Base64.NO_WRAP), cropped)
    }
}
