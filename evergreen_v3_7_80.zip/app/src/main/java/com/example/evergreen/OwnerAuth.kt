package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * '내 폰 모드' 비밀번호 확인.
 *  - 비밀번호는 PBKDF2 (폰마다 다른 무작위 salt · 20만 번 이상 반복)로 폰 안에만 저장한다.
 *  - 틀리면 3번째부터 기다리는 시간이 늘어난다 (30초 → 1분 → 2분 … 최대 1시간). 앱을 껐다 켜도 이어진다.
 *  - 값 비교는 시간 차이로 새지 않게 한다.
 *  - 처음에는 앱에 들어 있는 옛 해시로 확인하고, 맞으면 곧바로 폰 안의 PBKDF2 값으로 바꿔 저장한다 (그 뒤로는 옛 해시를 안 쓴다).
 */
object OwnerAuth {
    private const val LEGACY_HASH = "7d9fa4b930c2f0d8af1feb8239c5fb9cf4efab2735bd208ecafe40bbd7b794d8"
    private const val MIN_LEN = 8
    private const val MAX_LOCK_MS = 3_600_000L

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("owner_auth", Context.MODE_PRIVATE)

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    private fun legacy(pw: String): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(("evergreen-owner:" + pw).toByteArray(Charsets.UTF_8))

    private fun derive(pw: String, salt: ByteArray, iter: Int, alg: String): ByteArray {
        val spec = PBEKeySpec(pw.toCharArray(), salt, iter, 256)
        try { return SecretKeyFactory.getInstance(alg).generateSecret(spec).encoded } finally { spec.clearPassword() }
    }

    /** 폰에 맞는 PBKDF2 방식을 고른다 (안드로이드 8 미만은 SHA-256 판이 없어 SHA-1 로, 반복을 더 늘린다) */
    private fun pick(): Pair<String, Int> = try {
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); "PBKDF2WithHmacSHA256" to 210_000
    } catch (e: Exception) { "PBKDF2WithHmacSHA1" to 600_000 }

    private fun store(c: Context, pw: String) {
        val (alg, iter) = pick()
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp(c).edit().putString("alg", alg).putInt("iter", iter).putString("salt", hex(salt))
            .putString("hash", hex(derive(pw, salt, iter, alg))).apply()
    }

    private fun matches(c: Context, pw: String): Boolean {
        val s = sp(c)
        val h = s.getString("hash", null)
        val salt = s.getString("salt", null)
        if (h == null || salt == null) return MessageDigest.isEqual(legacy(pw), unhex(LEGACY_HASH))
        return try {
            MessageDigest.isEqual(derive(pw, unhex(salt), s.getInt("iter", 210_000), s.getString("alg", "PBKDF2WithHmacSHA256")!!), unhex(h))
        } catch (e: Exception) { false }
    }

    /** 지금 더 기다려야 하는 시간 (ms). 0 이면 시도할 수 있다 */
    fun waitMs(c: Context): Long {
        val left = sp(c).getLong("until", 0L) - System.currentTimeMillis()
        return left.coerceIn(0L, MAX_LOCK_MS)   // 시계를 뒤로 돌려도 1시간을 넘기지 않는다
    }

    /** 시간이 걸리므로 화면 스레드에서 부르지 않는다 */
    fun verify(c: Context, pw: String): Boolean {
        if (waitMs(c) > 0) return false
        val ok = matches(c, pw)
        val s = sp(c)
        if (ok) {
            val migrate = s.getString("hash", null) == null
            s.edit().remove("fails").remove("until").apply()
            if (migrate) store(c, pw)
        } else {
            val fails = s.getInt("fails", 0) + 1
            val delay = if (fails >= 3) minOf(30_000L shl (fails - 3).coerceAtMost(7), MAX_LOCK_MS) else 0L
            s.edit().putInt("fails", fails).putLong("until", System.currentTimeMillis() + delay).apply()
        }
        return ok
    }

    private fun fmt(ms: Long): String { val s = (ms + 999) / 1000; return if (s >= 60) "${(s + 59) / 60}분" else "${s}초" }

    private fun ask(act: Activity, title: String, hint: String, onOk: (String) -> Unit) {
        val dp = act.resources.displayMetrics.density
        val et = EditText(act).apply {
            this.hint = hint
            // setSingleLine() 이 글자 가림(비밀번호 변환)을 덮어써서 비밀번호가 그대로 보였다 → 한 줄 설정을 먼저 하고,
            // 그 뒤에 비밀번호 형식과 가림을 다시 지정한다. 자동완성·추천 단어에도 남지 않게 한다
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
            importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO
        }
        val box = LinearLayout(act).apply {
            setPadding((24 * dp).toInt(), (8 * dp).toInt(), (24 * dp).toInt(), 0)
            addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        ThemedDialogBuilder(act).setTitle(title).setView(box)
            .setNegativeButton("취소", null)
            .setPositiveButton("확인") { _, _ -> onOk(et.text.toString()) }
            .show()
    }

    /** 비밀번호를 묻고 맞으면 [onOk] 를 부른다 (화면 스레드에서) */
    fun prompt(act: Activity, title: String, onOk: () -> Unit) {
        val w = waitMs(act)
        if (w > 0) { AppToast.show(act, "여러 번 틀려서 ${fmt(w)} 뒤에 다시 할 수 있어요"); return }
        ask(act, title, "비밀번호") { pw ->
            Thread {
                val ok = verify(act, pw)
                act.runOnUiThread {
                    if (ok) onOk()
                    else {
                        val w2 = waitMs(act)
                        AppToast.show(act, if (w2 > 0) "비밀번호가 달라요 · ${fmt(w2)} 뒤에 다시 할 수 있어요" else "비밀번호가 달라요")
                    }
                }
            }.start()
        }
    }

    /** 현재 비밀번호를 확인한 뒤 새 비밀번호(8자 이상)로 바꾼다 */
    fun change(act: Activity) {
        prompt(act, "현재 비밀번호") {
            ask(act, "새 비밀번호 (${MIN_LEN}자 이상)", "새 비밀번호") { a ->
                if (a.length < MIN_LEN) { AppToast.show(act, "${MIN_LEN}자 이상으로 해 주세요"); return@ask }
                ask(act, "새 비밀번호 한 번 더", "새 비밀번호 확인") { b ->
                    if (a != b) { AppToast.show(act, "두 번 친 비밀번호가 달라요"); return@ask }
                    Thread {
                        store(act, a)
                        act.runOnUiThread { AppToast.show(act, "비밀번호를 바꿨어요") }
                    }.start()
                }
            }
        }
    }
}
