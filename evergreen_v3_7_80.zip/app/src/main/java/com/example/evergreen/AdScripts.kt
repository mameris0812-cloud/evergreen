package com.example.evergreen

/**
 * 페이지 안에서 도는 광고 관련 스크립트 두 가지.
 *
 * 1. [VIDEO_BANNER_JS] - 영상 배너(<video> 로 나오는 배너 광고) 감지·제거.
 *    주소만 보는 네트워크 차단은 같은 사이트가 직접 내려주는 mp4/webm 배너나 확장자 없는 영상 주소를 놓치기 쉬워서,
 *    실제로 화면에 올라온 <video> 의 크기·재생 방식·주변 이름·링크를 보고 한 번 더 걸러낸다.
 *    [AdBlocker.COSMETIC_START_JS] 안에 들어가 모든 프레임에서 돈다.
 *
 * 2. [PICKER_JS] - '광고 직접 선택'. 사용자가 페이지에서 광고를 눌러 고르면 선택자를 만들어 앱(EvMedia.adpick)에 저장한다.
 *    저장된 선택자는 다음 방문부터 [AdBlocker.topCss] 로 숨겨지고, 영상이면 소리가 계속 나지 않게 멈춘다.
 *
 * 두 스크립트 모두 `$` 를 쓰지 않는다 (코틀린 문자열 템플릿과 겹치지 않게).
 */
object AdScripts {

    /** AdBlocker.COSMETIC_START_JS 의 IIFE 안쪽에 붙는 조각. EvMedia.adblock() 이 true 일 때만 실행된다. */
    val VIDEO_BANNER_JS: String = """
 // ── 영상 배너 감지: 화면에 올라온 <video> 가 배너 광고로 보이면 멈추고 가린다 ──
 (function(){
  var host=location.hostname.toLowerCase();
  // 영상 사이트 본 플레이어는 건드리지 않는다 
  if(/(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|netflix\.com|twitch\.tv|tving\.com|wavve\.com|watcha\.com)${'$'}/.test(host)) return;
  var STRONG=/(^|[^a-z0-9])(ad|ads|adv|advert|adverts|advertise|advertising|advertisement|adsense|adfit|adslot|adunit|sponsor|sponsored|sponsors)([^a-z0-9]|${'$'})|광고|스폰서/i;
  var WEAK=/(^|[^a-z0-9])(banner|banners|bnr)([^a-z0-9]|${'$'})|배너/i;
  var IAB=[[728,90],[970,90],[970,250],[468,60],[320,50],[320,100],[300,250],[336,280],[300,600],[160,600],[120,600],[250,250],[200,200],[300,50],[234,60],[125,125],[300,100],[360,100],[360,200],[360,50],[375,100]];
  var seen=new WeakSet();
  var memo=new Map();
  var stat={n:0};
  var userSel=[];
  try{ userSel=JSON.parse(EvMedia.aduser(location.hostname)||'[]'); }catch(e){}

  function srcs(v){
   var out=[];
   try{ if(v.currentSrc) out.push(v.currentSrc); }catch(e){}
   try{ var a=v.getAttribute('src'); if(a) out.push(new URL(a,location.href).href); }catch(e){}
   try{ var ss=v.querySelectorAll('source[src]'); for(var i=0;i<ss.length;i++) out.push(new URL(ss[i].getAttribute('src'),location.href).href); }catch(e){}
   return out;
  }
  function attrText(e){
   var t='';
   try{
    t+=' '+(e.id||'');
    var c=e.className; t+=' '+(typeof c==='string'?c:(c&&c.baseVal)||'');
    var as=e.attributes;
    for(var i=0;i<as.length;i++){
     var n=as[i].name;
     if(n.indexOf('data-ad')===0||n.indexOf('data-banner')===0||n==='aria-label'||n==='title'||n==='name'||n==='alt'||n==='data-testid') t+=' '+n.replace('data-','')+' '+as[i].value;
    }
   }catch(x){}
   // 'ad-free' 'ads-block' 같은 말은 광고가 아니라 광고를 없앤다는 뜻
   return t.replace(/ads?[-_]?(free|block\w*)/gi,'');
  }
  function hostOf(h){ try{ return new URL(h,location.href).hostname.toLowerCase(); }catch(e){ return ''; } }
  function reg(h){ var p=h.split('.'); if(p.length<=2) return h; var l2=p.slice(-2).join('.'); return /^(co|or|go|ne|ac|com|org)\.[a-z]{2}${'$'}/.test(l2)?p.slice(-3).join('.'):l2; }
  function isIab(w,h){
   for(var i=0;i<IAB.length;i++){
    var bw=IAB[i][0], bh=IAB[i][1];
    if(Math.abs(w-bw)<=bw*0.06&&Math.abs(h-bh)<=bh*0.06) return true;
    // 가로로 꽉 채우는 모바일 배너: 높이가 표준이고 비율이 비슷
    if(Math.abs(h-bh)<=bh*0.06&&w>=bw*0.9&&w/h<=bw/bh*1.15&&w/h>=bw/bh*0.85) return true;
   }
   return false;
  }

  // 영상이 배너 광고인 이유가 있으면 그 이유를, 아니면 '' 를 돌려준다
  function why(v){
   var r=v.getBoundingClientRect();
   var w=r.width, h=r.height;
   var vw=window.innerWidth||document.documentElement.clientWidth||360, vh=window.innerHeight||600;
   var list=srcs(v), i;
   // (a) 영상 주소 자체가 광고 서버 / 광고 영상 주소 모양
   for(i=0;i<list.length;i++){
    if(list[i].indexOf('http')!==0) continue;
    var m=memo.get(list[i]);
    if(m===undefined){
     try{ m=!!EvMedia.advid(list[i],location.hostname); }catch(e){ m=false; }
     if(memo.size>300) memo.clear();
     memo.set(list[i],m);
    }
    if(m) return 'src';
   }
   var hasCtl=v.hasAttribute('controls');
   var dur=v.duration;
   if(isFinite(dur)&&dur>180) return '';           // 긴 영상은 본편
   if(hasCtl) return '';                           // 재생바가 있으면 사람이 보라고 둔 영상
   var inPlayer=false;
   try{ inPlayer=!!v.closest('[class*="player" i],[id*="player" i],[class*="video-js" i],[class*="jwplayer" i],[class*="plyr" i],[class*="vjs" i]'); }catch(e){}
   var silentLoop=(v.muted||v.hasAttribute('muted')||v.defaultMuted)&&(v.loop||v.hasAttribute('loop')||v.autoplay||v.hasAttribute('autoplay'));
   // (b) 바로 위 몇 단계 안에 '광고' 이름
   var e=v, d=0, strong=false, weak=false;
   while(e&&d<6&&e!==document.body&&e!==document.documentElement){
    var t=attrText(e);
    if(STRONG.test(t)) strong=true; else if(WEAK.test(t)) weak=true;
    e=e.parentElement; d++;
   }
   if(w<2||h<2) return '';
   var small=h<=450;
   if(strong&&!inPlayer&&h<=Math.max(450,vh*0.7)) return 'name';
   if(weak&&small&&silentLoop) return 'banner';
   // (c) 표준 광고 크기 + 소리 없는 반복/자동 재생
   if(silentLoop&&isIab(w,h)) return 'size';
   // (d) 다른 사이트로 가는 링크로 감싼, 재생바 없는 소리 없는 영상 = 눌러서 이동하는 영상 배너
   if(silentLoop&&small){
    var a=v.closest('a[href]');
    if(a){
     var ah=hostOf(a.getAttribute('href'));
     if(ah&&reg(ah)!==reg(host)) return 'link';
    }
   }
   return '';
  }

  // 숨길 요소: 영상을 감싼 같은 크기 링크/상자까지 올라가고, '광고' 이름이 붙은 가까운 상자가 있으면 그것까지
  function target(v){
   var vr=v.getBoundingClientRect();
   var el=v, p, k=0;
   while(k<4){
    p=el.parentElement;
    if(!p||p===document.body||p===document.documentElement) break;
    var pr=p.getBoundingClientRect();
    var onlyMe=(p.querySelectorAll('video,img,iframe,canvas').length<=1)&&!((p.innerText||'').trim().length>40);
    if(onlyMe&&pr.width<=vr.width+16&&pr.height<=vr.height+16){ el=p; k++; } else break;
   }
   var e=el, d=0, best=null, vh=window.innerHeight||600;
   while(e&&d<4&&e.parentElement&&e!==document.body){
    if(STRONG.test(attrText(e))){
     var r=e.getBoundingClientRect();
     if(r.height<=Math.max(450,vh*0.7)&&r.width>0) best=e;
    }
    e=e.parentElement; d++;
   }
   return best||el;
  }

  function kill(v,reason){
   if(seen.has(v)) return;
   seen.add(v);
   try{ v.pause(); }catch(e){}
   try{ v.muted=true; v.removeAttribute('autoplay'); v.removeAttribute('src'); var ss=v.querySelectorAll('source'); for(var i=0;i<ss.length;i++) ss[i].remove(); v.load(); }catch(e){}
   try{ var t=target(v); t.style.setProperty('display','none','important'); t.setAttribute('data-ev-adhid',reason); }catch(e){}
   try{ v.style.setProperty('display','none','important'); }catch(e){}
   stat.n++;
   try{ EvMedia.adhid(location.hostname); }catch(e){}
  }

  function stopHidden(){
   // 직접 고른 광고 안의 영상: 가려도 소리가 나지 않게 멈춘다
   for(var i=0;i<userSel.length;i++){
    var els; try{ els=document.querySelectorAll(userSel[i]); }catch(e){ continue; }
    for(var j=0;j<els.length;j++){
     var el=els[j];
     var vs=el.tagName==='VIDEO'?[el]:el.querySelectorAll('video');
     for(var k=0;k<vs.length;k++){
      var v=vs[k];
      try{ if(!v.paused||v.autoplay){ v.pause(); v.muted=true; v.removeAttribute('autoplay'); } }catch(e){}
     }
    }
   }
  }

  function scan(){
   try{
    var vs=document.getElementsByTagName('video');
    for(var i=0;i<vs.length;i++){
     var v=vs[i];
     if(seen.has(v)) continue;
     var r=''; try{ r=why(v); }catch(e){}
     if(r) kill(v,r);
    }
    if(userSel.length) stopHidden();
   }catch(e){}
  }

  var timer=0;
  function later(){ if(timer) return; timer=setTimeout(function(){ timer=0; scan(); },250); }
  document.addEventListener('DOMContentLoaded',scan);
  window.addEventListener('load',function(){ scan(); setTimeout(scan,1200); setTimeout(scan,4000); });
  // 영상이 재생을 시작하거나 크기를 알게 되는 순간 (play / loadedmetadata 는 거품이 올라오지 않아 capture 로 받는다)
  document.addEventListener('play',function(e){ if(e.target&&e.target.tagName==='VIDEO'&&!seen.has(e.target)){ var r=''; try{ r=why(e.target); }catch(x){} if(r) kill(e.target,r); } },true);
  document.addEventListener('loadedmetadata',function(e){ if(e.target&&e.target.tagName==='VIDEO'&&!seen.has(e.target)){ var r=''; try{ r=why(e.target); }catch(x){} if(r) kill(e.target,r); } },true);
  try{
   new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src','class','id','style','loop','muted','autoplay']});
  }catch(e){}
  scan();
 })();
"""

    /**
     * '광고 직접 선택' 화면. evaluateJavascript 로 주 프레임에 넣으면 바로 선택 모드가 시작된다 (이미 켜져 있으면 끈다).
     * 눌러서 요소를 고르고, 상위/하위 버튼으로 범위를 조절한 뒤 '차단' 을 누르면 EvMedia.adpick 으로 저장한다.
     */
    val PICKER_JS: String = """
(function(){
 if(window.__evPickStop){ window.__evPickStop(); return; }
 var host=location.hostname.replace(/^www\./,'');
 var cur=null, trail=[], lastX=0, lastY=0, blocked=0, selText='', selCount=0, selStr='', selSrc='', lastOrigin='';
 var EVENTS=['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend','contextmenu','dblclick','auxclick'];

 function esc(s){ try{ return CSS.escape(s); }catch(e){ return String(s).replace(/[^a-zA-Z0-9_-]/g,function(c){ return '\\'+c; }); } }
 function cnt(sel){ try{ return document.querySelectorAll(sel).length; }catch(e){ return -1; } }
  // 사이트가 광고마다 새로 만들어 붙이는 '아무 글자나 섞은' 이름인지 (다음에 열면 달라지므로 선택자에 쓰지 않는다)
  function segRandom(g){
   if(g.length<5) return false;
   if(/^\d+x\d+${'$'}/i.test(g)) return false;
   if(/^[0-9a-f]{8,}${'$'}/i.test(g)&&/\d/.test(g)) return true;
   var alt=0, tr=0, i;
   for(i=1;i<g.length;i++){
    var a=g.charAt(i-1), b=g.charAt(i);
    if((/\d/.test(a))!==(/\d/.test(b))) alt++;
    if(/[a-z]/.test(a)&&/[A-Z]/.test(b)) tr++;
   }
   if(g.length>=7&&alt>=3) return true;
   if(g.length<=16&&tr/g.length>=0.25) return true;
   if(/^[bcdfghjklmnpqrstvwxz]{6,}${'$'}/i.test(g)) return true;
   return false;
  }
  function looksRandom(s){
   var t=String(s||'');
   if(/__[A-Za-z0-9]{4,}${'$'}/.test(t)) return true;
   var gs=t.split(/[-_]/);
   for(var i=0;i<gs.length;i++){ if(segRandom(gs[i])) return true; }
   return false;
  }
  function sameSite(a,b){
   a=String(a||'').toLowerCase().replace(/^www\./,''); b=String(b||'').toLowerCase().replace(/^www\./,'');
   return a.split('.').slice(-2).join('.')===b.split('.').slice(-2).join('.');
  }
  // 다른 사이트에서 불러온 광고 프레임이면 그 사이트 주소(origin). 광고 서버는 그대로인데 주소 뒤쪽 값만 매번 바뀌는 경우를 막으려고 쓴다
  function frameOrigin(e){
   try{
    var t=e.tagName, s=(t==='OBJECT')?e.getAttribute('data'):((t==='IFRAME'||t==='EMBED')?e.getAttribute('src'):'');
    if(!s) return '';
    var u=new URL(s,location.href);
    if(u.protocol!=='http:'&&u.protocol!=='https:') return '';
    if(sameSite(u.hostname,location.hostname)) return '';
    return u.origin;
   }catch(x){ return ''; }
  }
  function okClass(c){
   if(!c||c.length>40) return false;
   if(/\d{3,}/.test(c)) return false;
   if(looksRandom(c)) return false;
  if(/^(css|sc|jsx|svelte|emotion|styled|ev)[-_]/i.test(c)) return false;
  if(/^(active|on|off|open|opened|show|shown|hide|hidden|visible|selected|current|focus|focused|hover|loading|loaded|fixed|sticky|is-|has-|js-|swiper|slick|owl)/i.test(c)) return false;
  return true;
 }
 function classes(e){
  var c=e.className; if(typeof c!=='string') return [];
  return c.split(/\s+/).filter(okClass);
 }
  function okId(id){ return id&&id.length<=40&&!/\d{4,}/.test(id)&&!looksRandom(id); }
 function mediaSrc(e){
  var t=e.tagName, s='';
  try{
   if(t==='VIDEO') s=e.currentSrc||e.getAttribute('src')||(e.querySelector('source[src]')||{getAttribute:function(){return ''}}).getAttribute('src');
   else if(t==='IMG') s=e.currentSrc||e.getAttribute('src');
   else if(t==='IFRAME'||t==='EMBED'||t==='SOURCE') s=e.getAttribute('src');
   else if(t==='OBJECT') s=e.getAttribute('data');
   if(!s) return '';
   var u=new URL(s,location.href);
   if(u.protocol!=='http:'&&u.protocol!=='https:') return '';
   return u.origin+u.pathname;
  }catch(x){ return ''; }
 }
 function pathSel(el){
  var parts=[], e=el, depth=0;
  while(e&&e.nodeType===1&&e!==document.documentElement&&depth<9){
   var part=e.tagName.toLowerCase();
   if(e.id&&okId(e.id)){ parts.unshift('#'+esc(e.id)); break; }
   var cl=classes(e).slice(0,2);
   if(cl.length) part+='.'+cl.map(esc).join('.');
   var p=e.parentElement;
   if(p){
    var same=[].filter.call(p.children,function(c){ return c.tagName===e.tagName; });
    if(same.length>1) part+=':nth-of-type('+(same.indexOf(e)+1)+')';
   }
   parts.unshift(part);
   if(cnt(parts.join('>'))===1) break;
   e=p; depth++;
  }
  return parts.join('>');
 }
 // 선택자 만들기: 사이트가 바뀌어도 오래 가는 모양(아이디, 영상·이미지 주소, 이름 있는 클래스)을 먼저, 안 되면 경로
 function makeSel(el){
  var tag=el.tagName.toLowerCase(), c, n, i;
   var MAX=12; lastOrigin='';
  if(el.id&&okId(el.id)){ c='#'+esc(el.id); if(cnt(c)===1) return c; }
  if(el.id&&/\d/.test(el.id)){
   var pre=el.id.replace(/[-_]?\d+.*${'$'}/,'');
   if(pre.length>=4){ c='[id^="'+pre.replace(/"/g,'')+'"]'; n=cnt(c); if(n>=1&&n<=MAX) return tag+c; }
  }
   // 광고 서비스가 붙이는 속성: 값은 매번 달라도 속성 이름은 그대로다
   var ADA=['data-ad-slot','data-ad-unit','data-adunit','data-ad-client','data-ad-format','data-ad-id','data-adfit-unit'];
   for(i=0;i<ADA.length;i++){
    if(el.hasAttribute&&el.hasAttribute(ADA[i])){ c=tag+'['+ADA[i]+']'; n=cnt(c); if(n>=1&&n<=MAX) return c; }
   }
   // 다른 사이트에서 온 광고 프레임: 주소 뒤쪽 값은 매번 달라도 광고 서버 이름은 같으니 서버 이름으로 고른다 (그 서버의 요청도 함께 막는다)
   var fo=frameOrigin(el);
   if(fo){
    var fk=fo.replace(/^https?:\/\//,'');
    if(fk.indexOf('"')<0){
     c=(tag==='object')?(tag+'[data*="'+fk+'"]'):(tag+'[src*="'+fk+'"]'); n=cnt(c);
     if(n>=1&&n<=MAX){ lastOrigin=fo; return c; }
    }
   }
   var ms=mediaSrc(el);
   if(ms){
   var key=ms.replace(/^https?:\/\//,'');
   if(key.indexOf('"')<0&&key.length>6){
    var attr=(tag==='object')?'data':'src';
    c=tag+'['+attr+'*="'+key+'"]'; n=cnt(c);
    if(n>=1&&n<=MAX) return c;
   }
  }
  var cl=classes(el);
  if(cl.length){
   c=tag+'.'+cl.slice(0,3).map(esc).join('.'); n=cnt(c);
   if(n>=1&&n<=MAX) return c;
   var bestC=null, bestN=1e9;
   for(i=0;i<cl.length;i++){ var cc='.'+esc(cl[i]); var nn=cnt(cc); if(nn>=1&&nn<bestN){ bestN=nn; bestC=cc; } }
   if(bestC&&bestN<=MAX) return tag+bestC;
  }
  return pathSel(el);
 }

 // ── 화면 ──
 var box=document.createElement('div');
 box.setAttribute('data-ev-pick','1');
 box.style.cssText='position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #ff3b30;background:rgba(255,59,48,.20);border-radius:3px;display:none;box-sizing:border-box;';
 var barHost=document.createElement('div');
 barHost.setAttribute('data-ev-pick','1');
 barHost.style.cssText='position:fixed;left:8px;right:8px;bottom:8px;z-index:2147483647;';
 var root=barHost.attachShadow({mode:'closed'});
 // 스타일은 CSSOM 으로 넣는다: 엄격한 CSP 가 있는 사이트에서도 <style> 요소는 막힐 수 있다
 var BAR_CSS=
  '*{box-sizing:border-box;font-family:-apple-system,Roboto,"Noto Sans KR",sans-serif}'+
  '.b{background:#1f2421;color:#fff;border-radius:16px;padding:10px 12px;box-shadow:0 4px 18px rgba(0,0,0,.4);font-size:13px;line-height:1.4}'+
  '.t{font-weight:700;font-size:14px;margin-bottom:2px}'+
  '.s{color:#c7d0c9;font-size:12px;word-break:break-all;max-height:3.9em;overflow:hidden;margin-bottom:8px}'+
  '.r{display:flex;gap:6px}'+
  'button{flex:1;border:0;border-radius:10px;padding:10px 4px;font-size:13px;font-weight:600;color:#fff;background:#3a423d}'+
  'button.ok{background:#e5392d}button.ok[disabled]{opacity:.35}button.x{background:#2b312d;flex:.8}';
 function sheet(css){ try{ var s=new CSSStyleSheet(); s.replaceSync(css); return s; }catch(e){ return null; } }
 var barSheet=sheet(BAR_CSS);
 if(barSheet){ try{ root.adoptedStyleSheets=[barSheet]; }catch(e){ barSheet=null; } }
 // 안내 막대는 innerHTML 이 아니라 DOM 으로 만든다: 유튜브처럼 Trusted Types 를 강제하는 사이트에서는 innerHTML 에 글자를 넣으면 오류가 나서 선택 화면이 통째로 안 뜬다
 function mk(tag,cls,id,txt){ var n=document.createElement(tag); if(cls) n.className=cls; if(id) n.id=id; if(txt) n.textContent=txt; return n; }
 if(!barSheet){ var stl=document.createElement('style'); stl.textContent=BAR_CSS; root.appendChild(stl); }
 var wrap=mk('div','b');
 wrap.appendChild(mk('div','t','t'));
 wrap.appendChild(mk('div','s','s'));
 var btnRow=mk('div','r');
 btnRow.appendChild(mk('button','','up','⬆ 상위'));
 btnRow.appendChild(mk('button','','dn','⬇ 하위'));
 btnRow.appendChild(mk('button','ok','ok','차단'));
 btnRow.appendChild(mk('button','x','x','닫기'));
 wrap.appendChild(btnRow);
 root.appendChild(wrap);
 var elT=root.getElementById('t'), elS=root.getElementById('s'), bUp=root.getElementById('up'), bDn=root.getElementById('dn'), bOk=root.getElementById('ok'), bX=root.getElementById('x');
 (document.body||document.documentElement).appendChild(box);
 (document.body||document.documentElement).appendChild(barHost);
 // 문서에 규칙을 더한다 (adoptedStyleSheets 우선, 안 되면 <style>)
 function addDocCss(css){
  var sh=sheet(css);
  if(sh){
   try{ document.adoptedStyleSheets=document.adoptedStyleSheets.concat([sh]); return function(){ try{ document.adoptedStyleSheets=document.adoptedStyleSheets.filter(function(x){ return x!==sh; }); }catch(e){} }; }catch(e){}
  }
  var st=document.createElement('style'); st.setAttribute('data-ev-pick','1'); st.textContent=css;
  (document.head||document.documentElement).appendChild(st);
  return function(){ try{ st.remove(); }catch(e){} };
 }
 // 선택하는 동안 광고 프레임이 터치를 먹지 않게 한다 (그래야 광고 프레임도 눌러서 고를 수 있다)
 var unshield=addDocCss('iframe,embed,object{pointer-events:none!important}');

 function isOurs(e){ return e===barHost||e===box||(e&&e.getAttribute&&e.getAttribute('data-ev-pick')); }
 function label(e){
  var t=e.tagName.toLowerCase();
  var c=classes(e)[0]; if(c) t+='.'+c; else if(e.id) t+='#'+e.id;
  var r=e.getBoundingClientRect();
  return t+' · '+Math.round(r.width)+'×'+Math.round(r.height);
 }
 function place(){
  if(!cur){ box.style.display='none'; return; }
  var r=cur.getBoundingClientRect();
  box.style.display='block';
  box.style.left=r.left+'px'; box.style.top=r.top+'px'; box.style.width=Math.max(r.width,4)+'px'; box.style.height=Math.max(r.height,4)+'px';
  // 선택한 요소가 아래쪽이면 안내 막대를 위로 옮겨 가리지 않게
  var mid=r.top+r.height/2;
  if(mid>innerHeight*0.55){ barHost.style.top='8px'; barHost.style.bottom='auto'; } else { barHost.style.top='auto'; barHost.style.bottom='8px'; }
 }
 function refresh(){
  if(!cur){
   elT.textContent=blocked?('광고 '+blocked+'건을 차단했어요'):'차단할 광고를 눌러 주세요';
   elS.textContent='눌러도 페이지는 이동하지 않아요. 스크롤은 그대로 됩니다.';
   bOk.disabled=true; bUp.disabled=true; bDn.disabled=true; place(); return;
  }
  selStr=makeSel(cur); selCount=cnt(selStr); selSrc=lastOrigin||mediaSrc(cur);
  elT.textContent=label(cur)+(selCount>1?'  ('+selCount+'개 일치)':'');
  elS.textContent=selStr;
  bOk.disabled=!(selCount>=1);
  bUp.disabled=!(cur.parentElement&&cur.parentElement!==document.body&&cur.parentElement!==document.documentElement);
  bDn.disabled=false;
  place();
 }
 function choose(e,keepTrail){
  if(!e||e===document.body||e===document.documentElement||isOurs(e)) return;
  if(!keepTrail) trail=[];
  cur=e; refresh();
 }
 function up(){
  if(!cur) return;
  var p=cur.parentElement;
  if(!p||p===document.body||p===document.documentElement) return;
  trail.push(cur); cur=p; refresh();
 }
 function down(){
  if(!cur) return;
  if(trail.length){ cur=trail.pop(); refresh(); return; }
  // 처음 누른 자리에서 더 안쪽 요소로
  try{
   var els=document.elementsFromPoint(lastX,lastY).filter(function(x){ return !isOurs(x); });
   var i=els.indexOf(cur);
   if(i>0&&cur.contains(els[i-1])){ cur=els[i-1]; refresh(); return; }
  }catch(e){}
  var ch=null; for(var k=0;k<cur.children.length;k++){ var c=cur.children[k]; var r=c.getBoundingClientRect(); if(r.width>4&&r.height>4){ ch=c; break; } }
  if(ch){ cur=ch; refresh(); }
 }
 function commit(){
  if(!cur||!(selCount>=1)) return;
  var ok=false;
  try{ ok=!!EvMedia.adpick(host,selStr,label(cur),selSrc); }catch(e){}
  if(!ok){ elT.textContent='저장하지 못했어요'; return; }
  // 바로 가리고, 영상이면 소리도 멈춘다
  addDocCss(selStr+'{display:none!important}');
  try{
   var els=document.querySelectorAll(selStr);
   for(var i=0;i<els.length;i++){
    var vs=els[i].tagName==='VIDEO'?[els[i]]:els[i].querySelectorAll('video');
    for(var j=0;j<vs.length;j++){ try{ vs[j].pause(); vs[j].muted=true; }catch(x){} }
   }
  }catch(e){}
  blocked++; cur=null; trail=[]; refresh();
 }

 // 누른 자리의 요소. 광고 프레임(iframe 등)은 위에서 막아 두었으니 크기로 직접 찾는다
 function hit(x,y){
  var t=document.elementFromPoint(x,y);
  var fr=document.querySelectorAll('iframe,embed,object'), best=null, ba=1e12;
  for(var i=0;i<fr.length;i++){
   var f=fr[i]; if(isOurs(f)) continue;
   var r=f.getBoundingClientRect();
   if(r.width<10||r.height<10||x<r.left||x>r.right||y<r.top||y>r.bottom) continue;
   var cs=getComputedStyle(f);
   if(cs.display==='none'||cs.visibility==='hidden') continue;
   if(r.width*r.height>innerWidth*innerHeight*0.85) continue;
   if(t&&t!==f&&!t.contains(f)) continue;
   var a=r.width*r.height; if(a<ba){ ba=a; best=f; }
  }
  return best||t;
 }
 var tx=0, ty=0;
 function onEvt(e){
  if(e.composedPath&&e.composedPath()[0]===barHost) return;
  if(isOurs(e.target)) return;
  e.stopImmediatePropagation();
  if(e.type==='touchstart'&&e.touches&&e.touches[0]){ tx=e.touches[0].clientX; ty=e.touches[0].clientY; }
 }
 function onClick(e){
  if(isOurs(e.target)) return;
  if(e.composedPath&&e.composedPath()[0]===barHost) return;
  e.preventDefault(); e.stopImmediatePropagation();
  lastX=e.clientX; lastY=e.clientY;
  choose(hit(lastX,lastY)||e.target,false);
 }
 EVENTS.forEach(function(n){ window.addEventListener(n,onEvt,true); });
 window.addEventListener('click',onClick,true);
 window.addEventListener('submit',function(e){ e.preventDefault(); },true);
 var onScroll=function(){ place(); };
 window.addEventListener('scroll',onScroll,true);
 window.addEventListener('resize',onScroll);
 var raf=setInterval(place,400);

 bUp.addEventListener('click',function(e){ e.stopPropagation(); up(); });
 bDn.addEventListener('click',function(e){ e.stopPropagation(); down(); });
 bOk.addEventListener('click',function(e){ e.stopPropagation(); commit(); });
 bX.addEventListener('click',function(e){ e.stopPropagation(); stop(); });

 function stop(){
  EVENTS.forEach(function(n){ window.removeEventListener(n,onEvt,true); });
  window.removeEventListener('click',onClick,true);
  window.removeEventListener('scroll',onScroll,true);
  window.removeEventListener('resize',onScroll);
  clearInterval(raf);
  try{ unshield(); }catch(e){}
  try{ box.remove(); barHost.remove(); }catch(e){}
  // 이번에 고른 숨김은 그대로 남겨 둔다
  window.__evPickStop=null;
  try{ EvMedia.adpickEnd(blocked); }catch(e){}
 }
 window.__evPickStop=stop;
 refresh();
})();
"""
}
