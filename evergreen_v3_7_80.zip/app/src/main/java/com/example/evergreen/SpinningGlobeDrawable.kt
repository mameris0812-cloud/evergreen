package com.example.evergreen

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 탭 아이콘용 로딩 표시: 평면(선 그림) 지구본이 세로축을 중심으로 입체적으로 돌아간다.
 * 겉 동그라미와 가로선(위도선)은 그대로 있고, 구의 앞면에 있는 세로선(경선)이 한쪽 가장자리에서 나타나
 * 가운데를 지나 반대쪽 가장자리로 사라진다. 뒷면으로 넘어간 선은 그리지 않고, 가장자리 가까이서는 흐려져 자연스럽게 나타났다 사라진다.
 * 평소 쓰는 지구본 아이콘(ic_globe)과 같은 선 그림 규격(24칸 격자 · 선 두께 1.8)이다.
 * [animator] 를 시작/취소해서 돌리고 멈춘다.
 */
class SpinningGlobeDrawable(color: Int) : Drawable() {

    private var angle = 0.0
    private var baseAlpha = 255

    /** 경선이 60° 간격이라 60° 만 돌면 처음 모양으로 돌아온다 */
    val animator: ValueAnimator = ValueAnimator.ofFloat(0f, (PI / 3).toFloat()).apply {
        duration = 600
        interpolator = LinearInterpolator()
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { angle = (it.animatedValue as Float).toDouble(); invalidateSelf() }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }
    private val path = Path()

    override fun draw(canvas: Canvas) {
        val b = bounds
        val size = min(b.width(), b.height()).toFloat()
        if (size <= 0f) return
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        val r = size * 9f / 24f
        paint.strokeWidth = size * 1.8f / 24f

        // 겉 동그라미
        paint.alpha = baseAlpha
        canvas.drawCircle(cx, cy, r, paint)

        // 가로선: 적도와 위·아래 위도선 (구 위의 같은 높이를 이은 선이라 폭은 동그라미 안쪽 현의 길이)
        for (k in floatArrayOf(-0.5f, 0f, 0.5f)) {
            val y = cy + r * k
            val half = r * sqrt(1f - k * k)
            canvas.drawLine(cx - half, y, cx + half, y, paint)
        }

        // 세로선: 60° 간격 경선 여섯 개 중 앞면(cos > 0)에 있는 셋.
        // 경선 위 한 점의 가로 위치는 r · sin(θ) · cos(위도) 라서, 가운데를 지날 때 곧은 선이 되고 가장자리에서는 동그라미에 겹친다
        for (i in 0 until 6) {
            val theta = angle + i * PI / 3.0
            val depth = cos(theta)
            if (depth <= 0.0) continue
            paint.alpha = (baseAlpha * (depth * 1.8).coerceAtMost(1.0)).toInt()
            val s = sin(theta)
            path.reset()
            var lat = -90
            while (lat <= 90) {
                val phi = lat * PI / 180.0
                val x = cx + (r * s * cos(phi)).toFloat()
                val y = cy - (r * sin(phi)).toFloat()
                if (lat == -90) path.moveTo(x, y) else path.lineTo(x, y)
                lat += 6
            }
            canvas.drawPath(path, paint)
        }
    }

    override fun setAlpha(alpha: Int) { baseAlpha = alpha; invalidateSelf() }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
