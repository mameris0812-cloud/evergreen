package com.example.evergreen

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.SuperscriptSpan
import android.widget.TextView

/** 아직 다듬는 중인 기능(확장 프로그램) 이름 옆에 붙이는 작은 BETA 딱지 */
object BetaBadge {
    const val EXTENSIONS = "확장 프로그램"

    fun text(title: String, color: Int): CharSequence {
        val sb = SpannableStringBuilder(title)
        val start = sb.length + 1
        sb.append("  BETA")
        sb.setSpan(RelativeSizeSpan(0.6f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    /** [title] 이 확장 프로그램이면 글자 옆에 BETA 를 붙여 넣고, 아니면 그대로 넣는다 */
    fun set(tv: TextView, title: String) {
        tv.text = if (title == EXTENSIONS) text(title, tv.context.getColor(R.color.ev_accent)) else title
    }
}
