package com.example.evergreen

import android.content.Context
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * MaterialAlertDialogBuilder 와 똑같이 쓰는 대화상자 빌더인데, 테마가 켜져 있으면 보여질 때
 * 카드 바탕·제목·내용·버튼·목록에 테마 색을 입힌다 ([ThemeColors.skinDialog]).
 */
class ThemedDialogBuilder : MaterialAlertDialogBuilder {
    constructor(context: Context) : super(context)
    constructor(context: Context, overrideThemeResId: Int) : super(context, overrideThemeResId)

    override fun create(): AlertDialog {
        val d = super.create()
        d.setOnShowListener { ThemeColors.skinDialog(d) }   // 테마가 꺼져 있어도 기억해 둔다 (나중에 테마를 켜면 떠 있는 창도 바뀐다)
        return d
    }
}
