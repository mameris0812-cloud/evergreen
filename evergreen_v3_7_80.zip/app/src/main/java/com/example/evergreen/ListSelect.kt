package com.example.evergreen

import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import com.google.android.material.color.MaterialColors

/**
 * 북마크 · 방문 기록 · 다운로드 목록이 함께 쓰는 '여러 개 선택해서 한 번에 지우기'.
 * - 제목줄의 '선택' 또는 항목을 길게 누르면 선택 모드. 항목을 누르면 체크가 켜지고 꺼진다.
 * - 선택 모드에서는 제목줄이 "n개 선택됨" 으로 바뀌고, 오른쪽 버튼은 '취소' 가 된다.
 * - 목록 아래에는 [○ 전체 선택 ········ 삭제 (n)] 막대가 떠오른다.
 * - 뒤로 가기는 먼저 선택 모드부터 끈다.
 * 선택은 항목의 키(북마크 id / 주소 / 다운로드 키)로 기억한다.
 */
class ListSelect<K : Any>(
    private val act: AppCompatActivity,
    private val listView: ListView,
    private val headerAction: TextView,
    /** 제목줄의 제목 (선택 모드에서는 선택한 개수를 보여 준다) */
    private val title: TextView,
    /** 지금 화면에 보이는 항목의 키 (전체 선택 · 사라진 항목 정리용) */
    private val visibleKeys: () -> List<K>,
    /** 선택 상태가 바뀌어 목록을 다시 그려야 할 때 */
    private val onChanged: () -> Unit,
    /** 삭제 막대의 '삭제' 를 눌렀을 때 (선택된 키들) */
    private val onDelete: (Set<K>) -> Unit
) {
    private val keys = LinkedHashSet<K>()
    var active = false
        private set

    private val bar: LinearLayout
    private val allBtn: LinearLayout
    private val allCheck: ImageView
    private val allText: TextView
    private val delText: TextView
    private val basePadBottom = listView.paddingBottom
    private val d = act.resources.displayMetrics.density
    private var baseTitle: CharSequence = title.text

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { exit() }
    }

    private fun color(attr: Int) = ThemeColors.get(listView, attr, 0)
    private fun px(v: Int) = (v * d).toInt()

    init {
        act.onBackPressedDispatcher.addCallback(act, backCb)

        headerAction.text = "선택"
        headerAction.visibility = View.VISIBLE
        headerAction.setOnClickListener { if (active) exit() else enter() }

        val host = listView.parent as FrameLayout
        bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(color(com.google.android.material.R.attr.colorSurfaceContainerHighest))
            }
            elevation = 8 * d
            setPadding(px(6), px(6), px(8), px(6))
            visibility = View.GONE
            // 막대 뒤로 목록이 비치거나 눌리지 않게
            isClickable = true
        }

        // 왼쪽: 동그라미 체크 + '전체 선택' (켜져 있으면 '선택 해제')
        allCheck = ImageView(act).apply {
            setPadding(px(3), px(3), px(3), px(3))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        allText = TextView(act).apply {
            setTextColor(color(com.google.android.material.R.attr.colorOnSurface))
            textSize = 14.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
        }
        allBtn = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(12), 0, px(16), 0)
            isClickable = true
            isFocusable = true
            background = androidx.appcompat.content.res.AppCompatResources.getDrawable(act, selectableBorderless())
            setOnClickListener { toggleAll() }
            addView(allCheck, LinearLayout.LayoutParams(px(24), px(24)))
            addView(allText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = px(10)
            })
        }
        bar.addView(allBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, px(44)))

        bar.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))

        // 오른쪽: 휴지통 + '삭제 (n)'
        delText = TextView(act).apply {
            gravity = Gravity.CENTER
            textSize = 14.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(px(18), 0, px(20), 0)
            compoundDrawablePadding = px(8)
            setCompoundDrawablesRelativeWithIntrinsicBounds(
                androidx.appcompat.content.res.AppCompatResources.getDrawable(act, R.drawable.ic_delete), null, null, null
            )
            isClickable = true
            isFocusable = true
            setOnClickListener { if (keys.isNotEmpty()) onDelete(LinkedHashSet(keys)) }
        }
        bar.addView(delText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, px(44)))

        host.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM
                val m = px(12)
                setMargins(m, 0, m, m)
            }
        )
        update()
    }

    private fun selectableBorderless(): Int {
        val tv = android.util.TypedValue()
        act.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        return tv.resourceId
    }

    /** '삭제' 알약: 고른 것이 있으면 빨갛게, 없으면 흐리게 */
    private fun applyDel(enabled: Boolean) {
        val bg = GradientDrawable().apply {
            cornerRadius = 22 * d
            setColor(ContextCompat.getColor(act, R.color.ev_danger))
        }
        delText.background = bg
        delText.setTextColor(ContextCompat.getColor(act, R.color.ev_on_danger))
        delText.compoundDrawableTintList = ColorStateList.valueOf(ContextCompat.getColor(act, R.color.ev_on_danger))
        delText.alpha = if (enabled) 1f else 0.4f
    }

    /** '전체 선택' 의 동그라미: 켜지면 색이 차고 체크가 보인다 */
    private fun applyAllCheck(on: Boolean) {
        allCheck.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (on) {
                setColor(color(com.google.android.material.R.attr.colorPrimary))
            } else {
                setColor(0)
                setStroke(px(2), color(com.google.android.material.R.attr.colorOutline))
            }
        }
        if (on) {
            allCheck.setImageResource(R.drawable.ic_check)
            allCheck.imageTintList = ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnPrimary))
        } else {
            allCheck.setImageDrawable(null)
        }
    }

    private fun tick() {
        listView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    fun isSelected(key: K) = key in keys

    fun enter(first: K? = null) {
        if (!active) {
            active = true
            backCb.isEnabled = true
            baseTitle = title.text
            headerAction.text = "취소"
            bar.visibility = View.VISIBLE
            if (Motion.enabled(act)) {
                bar.alpha = 0f
                bar.translationY = 40 * d
                Motion.spring(bar, DynamicAnimation.ALPHA, 1f, 400f, 1f)
                Motion.spring(bar, DynamicAnimation.TRANSLATION_Y, 0f, 380f, 0.72f)
            } else {
                bar.alpha = 1f; bar.translationY = 0f
            }
            // 막대에 마지막 항목이 가리지 않게 목록 아래에 여백
            listView.setPadding(listView.paddingLeft, listView.paddingTop, listView.paddingRight, basePadBottom + px(84))
            if (first != null) tick()
        }
        if (first != null) keys.add(first)
        update()
        onChanged()
    }

    fun exit() {
        if (!active) return
        active = false
        backCb.isEnabled = false
        keys.clear()
        headerAction.text = "선택"
        title.text = baseTitle
        listView.setPadding(listView.paddingLeft, listView.paddingTop, listView.paddingRight, basePadBottom)
        if (Motion.enabled(act)) {
            bar.animate().cancel()
            bar.animate().alpha(0f).translationY(30 * d).setDuration(140)
                .withEndAction { if (!active) bar.visibility = View.GONE }.start()
        } else {
            bar.visibility = View.GONE
        }
        onChanged()
    }

    fun toggle(key: K) {
        if (!keys.remove(key)) keys.add(key)
        tick()
        update()
        onChanged()
    }

    private fun toggleAll() {
        val all = visibleKeys()
        if (keys.containsAll(all) && all.isNotEmpty()) keys.removeAll(all.toSet()) else keys.addAll(all)
        tick()
        update()
        onChanged()
    }

    /** 목록이 다시 그려질 때: 사라진 항목을 선택에서 뺀다 */
    fun retain() {
        if (!active) return
        keys.retainAll(visibleKeys().toSet())
        update()
    }

    private fun update() {
        val all = visibleKeys()
        val allOn = all.isNotEmpty() && keys.containsAll(all)
        if (active) {
            title.text = if (keys.isEmpty()) "항목을 선택하세요" else "${keys.size}개 선택됨"
        }
        allText.text = if (allOn) "선택 해제" else "전체 선택"
        applyAllCheck(allOn)
        applyDel(keys.isNotEmpty())
        delText.text = if (keys.isEmpty()) "삭제" else "삭제 (${keys.size})"
    }

    /** 삭제를 마쳤을 때 */
    fun finishDelete() {
        keys.clear()
        exit()
    }

    /**
     * 행 모양을 선택 상태에 맞게 바꾼다 (재활용되는 행이라 항상 두 경우 모두 설정).
     * 선택 모드: 선택된 행은 아이콘 자리가 체크 칸이 되고 은은하게 칠해지며, ⋮ 는 숨긴다.
     */
    fun bindRow(row: View, key: K, normalIcon: Int, selectable: Boolean = true) {
        val icon = row.findViewById<ImageView>(R.id.rowIcon)
        val more = row.findViewById<View>(R.id.rowMore)
        if (!active || !selectable) {
            row.setBackgroundColor(0)
            icon.setImageResource(normalIcon)
            icon.setBackgroundResource(R.drawable.bg_row_icon)
            icon.imageTintList = ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnPrimaryContainer))
            more.visibility = View.VISIBLE
            row.alpha = if (active && !selectable) 0.45f else 1f
            return
        }
        row.alpha = 1f
        more.visibility = View.INVISIBLE
        val on = key in keys
        row.setBackgroundColor(if (on) color(com.google.android.material.R.attr.colorPrimaryContainer) and 0x00FFFFFF or 0x66000000 else 0)
        if (on) {
            icon.setImageResource(R.drawable.ic_check)
            icon.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color(com.google.android.material.R.attr.colorPrimary))
            }
            icon.imageTintList = ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnPrimary))
        } else {
            icon.setImageResource(normalIcon)
            icon.setBackgroundResource(R.drawable.bg_row_icon)
            icon.imageTintList = ColorStateList.valueOf(color(com.google.android.material.R.attr.colorOnPrimaryContainer))
        }
    }
}
