package com.example.evergreen

import android.content.Context
import android.animation.ValueAnimator
import android.util.AttributeSet
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * 동영상 전체화면 컨테이너: 화면 가운데에서 아래로 밀면 영상이 손가락을 따라 내려오며 작아지고,
 * 충분히 밀고 놓으면 전체화면을 빠져나간다. 모자라게 밀고 놓으면 탄성 있게 제자리로 돌아간다.
 *
 * 오작동을 줄이려고 아래 조건을 모두 만족할 때만 끼어든다 (그 전에는 페이지가 터치를 그대로 받는다):
 * - 손가락 하나, 시작 위치가 화면 대부분의 영역 (위쪽 제목 막대·아래쪽 컨트롤 막대, 시스템 제스처가 먹는 좌우 가장자리만 제외)
 * - 처음부터 분명하게 아래쪽으로 움직임 (가로로 먼저 움직이거나 위로 움직이면 이번 터치는 포기 → 탐색 막대 끌기 등과 겹치지 않음)
 * - 꾹 눌러 2배속 하던 터치(길게 누름 시간이 지난 터치)는 아래로 끌어도 나가지 않음
 * - 놓을 때 충분히 내려왔거나 빠르게 휙 내렸을 때만 나감. 끌고 있는 도중 다시 위로 올리면 취소됨
 *
 * 핀치 줌(내장 플레이어와 같은 방식): 두 손가락으로 영상을 확대 · 축소(최대 6배)하고, 확대한 뒤에는 한 손가락으로도 끌어 옮긴다.
 * 확대한 동안에는 아래로 밀어 나가기가 꺼진다. 크기가 바뀌거나(회전 · 작은 창) 전체화면이 닫히면 원래 크기로 돌아온다.
 */
class FullscreenSwipeLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    /** 지금 이 제스처를 쓸 수 있는지 (설정이 켜져 있고 전체화면 중일 때) */
    var enabledProvider: () -> Boolean = { false }

    /** 터치를 시작한 자리가 제스처를 써도 되는 곳인지 (진행 막대 위처럼 따로 끌어야 하는 자리를 빼는 데 쓴다) */
    var startFilter: (Float, Float) -> Boolean = { _, _ -> true }

    /** 이 레이아웃 좌표 (x, y) 가 [v] 안(사방으로 [pad] 만큼 넓혀서)에 있는지 */
    fun hits(v: View, x: Float, y: Float, pad: Float): Boolean {
        val a = IntArray(2)
        val b = IntArray(2)
        v.getLocationInWindow(a)
        getLocationInWindow(b)
        val l = a[0] - b[0] - pad
        val t = a[1] - b[1] - pad
        return x in l..(l + v.width + 2 * pad) && y in t..(t + v.height + 2 * pad)
    }

    /**
     * 콘텐츠(자식 뷰)와 함께 움직일 다른 뷰들. 미러링은 영상이 이 레이아웃 밖(뒤쪽 웹뷰)에 있고
     * 여기엔 컨트롤 UI 만 있어서, 웹뷰 쪽도 같이 내려가게 하려고 쓴다.
     */
    var companions: () -> List<View> = { emptyList() }

    /** 놓았을 때 나가기로 결정되고 나가는 애니메이션이 끝난 뒤 불린다 */
    var onDismiss: () -> Unit = {}

    /** 지금 핀치 줌을 쓸 수 있는지 (전체화면 · 미러링 중이고 작은 창(PiP)이 아닐 때) */
    var zoomEnabled: () -> Boolean = { false }

    /** 확대 · 축소할 뷰들. 기본은 콘텐츠(전체화면 영상). 미러링은 영상이 뒤쪽 웹뷰에 있어서 컨트롤은 두고 웹뷰 쪽만 확대한다 */
    var zoomTargets: () -> List<View> = { content()?.let { listOf(it) } ?: emptyList() }

    /** 핀치를 마쳤을 때 배율 안내 문구("250%", "원래 크기")를 알린다 */
    var onZoomLabel: (String) -> Unit = {}

    private val density = resources.displayMetrics.density
    private val slop = maxOf(ViewConfiguration.get(ctx).scaledTouchSlop * 1.5f, 14f * density)
    private val flingV = 1000f * density
    private val minFlingDist = 48f * density

    // ── 핀치 줌 상태: 화면 가운데를 기준으로 배율 zoomS, 이동 zoomTx/zoomTy ──
    private var zoomS = 1f
    private var zoomTx = 0f
    private var zoomTy = 0f
    private var pinching = false
    private var panning = false
    private var zoomSwallow = false      // 이번 터치는 확대 쪽이 가져가서 아래 뷰에는 취소로 알리고 더 보내지 않는다
    private var zoomCancelSent = false
    private var noPinch = false          // 꾹 눌러 2배속 중이던 터치에 손가락이 더해진 경우: 확대하지 않는다
    private var panResync = false
    private var lastFx = 0f
    private var lastFy = 0f
    private var panDownX = 0f
    private var panDownY = 0f
    private var panLastX = 0f
    private var panLastY = 0f
    private var zoomAnim: ValueAnimator? = null

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(d: ScaleGestureDetector): Boolean {
            if (noPinch || !zoomEnabled()) return false
            pinching = true
            zoomAnim?.cancel()
            lastFx = d.focusX; lastFy = d.focusY
            return true
        }

        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (zoomS * d.scaleFactor).coerceIn(0.85f, 6f)
            // 손가락 사이 한 점이 제자리에 머물도록 확대하고, 손가락이 같이 움직인 만큼 옮긴다
            val dx = d.focusX - width / 2f; val dy = d.focusY - height / 2f
            val r = ns / zoomS
            zoomTx = dx - r * (dx - zoomTx) + (d.focusX - lastFx)
            zoomTy = dy - r * (dy - zoomTy) + (d.focusY - lastFy)
            zoomS = ns
            lastFx = d.focusX; lastFy = d.focusY
            applyZoom(soft = true)
            return true
        }

        override fun onScaleEnd(d: ScaleGestureDetector) {
            pinching = false
            // 거의 원래 크기(또는 그보다 작게)로 줄였으면 딱 맞게 돌아온다
            val back = zoomS < 1.06f
            if (back) animateZoomTo(1f, 0f, 0f) else applyZoom(soft = false)
            onZoomLabel(if (back) "원래 크기" else "${(zoomS * 100).toInt()}%")
        }
    }).also { it.isQuickScaleEnabled = false }   // 더블탭 뒤 끌기로 확대되면 더블탭 이동과 겹친다

    /** 확대한 상태인가 (이때는 아래로 밀어 나가기를 쓰지 않는다) */
    fun isZoomed(): Boolean = zoomS > 1.01f || pinching

    /** 확대 · 이동을 뷰들에 적용한다. soft = true 면 핀치 도중이라 틀 밖으로 조금 벗어나도 둔다 (끝나면 제자리로 붙는다) */
    private fun applyZoom(soft: Boolean) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (!soft) {
            // 확대한 영상의 가장자리가 화면 안으로 들어오지 않게
            val mx = (zoomS - 1f).coerceAtLeast(0f) * w / 2f
            val my = (zoomS - 1f).coerceAtLeast(0f) * h / 2f
            zoomTx = zoomTx.coerceIn(-mx, mx)
            zoomTy = zoomTy.coerceIn(-my, my)
        }
        for (t in zoomTargets()) {
            t.scaleX = zoomS; t.scaleY = zoomS
            t.translationX = zoomTx; t.translationY = zoomTy
        }
    }

    private fun animateZoomTo(s: Float, tx: Float, ty: Float) {
        zoomAnim?.cancel()
        val s0 = zoomS; val x0 = zoomTx; val y0 = zoomTy
        zoomAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            interpolator = android.view.animation.DecelerateInterpolator(1.6f)
            addUpdateListener {
                val f = it.animatedValue as Float
                zoomS = s0 + (s - s0) * f; zoomTx = x0 + (tx - x0) * f; zoomTy = y0 + (ty - y0) * f
                applyZoom(soft = true)
            }
            start()
        }
    }

    /** 확대를 풀고 원래 크기 · 자리로 (애니메이션 없이) */
    fun resetZoom() {
        zoomAnim?.cancel()
        zoomAnim = null
        val was = zoomS != 1f || zoomTx != 0f || zoomTy != 0f
        zoomS = 1f; zoomTx = 0f; zoomTy = 0f
        pinching = false; panning = false; zoomSwallow = false; zoomCancelSent = false
        if (was) {
            for (t in zoomTargets()) {
                t.scaleX = 1f; t.scaleY = 1f; t.translationX = 0f; t.translationY = 0f
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // 회전 · 작은 창(PiP) 등으로 크기가 바뀌면 확대한 자리가 맞지 않으니 원래 크기로
        if (oldw > 0 && oldh > 0 && (w != oldw || h != oldh)) resetZoom()
    }

    /**
     * 핀치 줌 터치 처리. 두 손가락이거나, 확대한 상태에서 한 손가락으로 끌 때는 이번 터치를 여기서 끝낸다(true).
     * 그 전에 아래 뷰에는 취소로 한 번만 알려서 탭 · 길게 누름 · 끌기가 이어지지 않게 한다.
     */
    private fun handleZoomTouch(ev: MotionEvent): Boolean {
        val a = ev.actionMasked
        if (a == MotionEvent.ACTION_DOWN) {
            zoomSwallow = false; panning = false; noPinch = false; zoomCancelSent = false; panResync = false
            panDownX = ev.x; panDownY = ev.y; panLastX = ev.x; panLastY = ev.y
        }
        if (!zoomEnabled()) return false
        // 꾹 눌러 2배속 하던 터치에 손가락이 더해져도 확대하지 않는다 (길게 누름 시간 기준은 아래로 밀어 나가기와 같다)
        if (a == MotionEvent.ACTION_POINTER_DOWN && !zoomSwallow && !isZoomed() &&
            ev.eventTime - ev.downTime >= ViewConfiguration.getLongPressTimeout()
        ) noPinch = true
        if (noPinch) return false

        scaleDet.onTouchEvent(ev)
        val end = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL
        val multi = ev.pointerCount > 1 || pinching
        if (multi) {
            zoomSwallow = true
            panResync = true      // 손가락이 하나 남은 뒤 첫 움직임은 기준 위치만 새로 잡는다 (툭 튀지 않게)
        } else if (isZoomed() && !end) {
            if (zoomSwallow) {
                // 확대를 마치고 남은 한 손가락, 또는 이미 끌기를 시작한 손가락: 영상을 옮긴다
                if (a == MotionEvent.ACTION_MOVE) {
                    if (panResync) panResync = false
                    else {
                        zoomTx += ev.x - panLastX; zoomTy += ev.y - panLastY
                        applyZoom(soft = false)
                    }
                    panLastX = ev.x; panLastY = ev.y
                }
            } else if (a == MotionEvent.ACTION_MOVE) {
                // 확대한 상태에서 한 손가락으로 끌면 영상을 옮긴다 (짧게 눌러 시작한 터치만, 진행 막대 위에서 시작한 터치는 제외)
                val slop = ViewConfiguration.get(context).scaledTouchSlop
                if (ev.eventTime - ev.downTime < ViewConfiguration.getLongPressTimeout() &&
                    (abs(ev.x - panDownX) > slop || abs(ev.y - panDownY) > slop) &&
                    startFilter(panDownX, panDownY)
                ) {
                    panning = true
                    zoomSwallow = true
                    panLastX = ev.x; panLastY = ev.y
                }
            }
        }
        if (zoomSwallow) {
            if (!zoomCancelSent) {
                zoomCancelSent = true
                eligible = false; armed = false
                recycle()
                val c = MotionEvent.obtain(ev)
                c.action = MotionEvent.ACTION_CANCEL
                super.dispatchTouchEvent(c)
                c.recycle()
            }
            if (end) { zoomSwallow = false; panning = false; zoomCancelSent = false }
            return true
        }
        return false
    }

    private var eligible = false
    private var dragging = false
    private var animating = false
    private var downX = 0f
    private var downY = 0f
    private var armed = false          // 지금 놓으면 나가는 거리에 도달했는지 (햅틱 1회용)
    private var vt: VelocityTracker? = null

    private fun content(): View? = if (childCount > 0) getChildAt(childCount - 1) else null

    /** 영상 위치·크기·투명도를 원래대로 돌린다 (영상 뷰는 다음 전체화면에서 다시 쓰일 수 있다) */
    fun resetTransform() {
        animating = false          // 먼저 내려야 cancel() 이 끝 동작(onDismiss)을 다시 부르지 않는다
        resetZoom()
        content()?.let {
            it.animate().cancel()
            it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f; it.alpha = 1f
        }
        companions().forEach {
            it.animate().cancel()
            it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f; it.alpha = 1f
        }
        dragging = false
        eligible = false
        armed = false
        recycle()
    }

    private fun recycle() { vt?.recycle(); vt = null }

    /**
     * 터치를 아래 영상(웹뷰)보다 먼저 지켜본다. 예전엔 onInterceptTouchEvent 로 끼어들었는데,
     * 웹 영상 화면은 requestDisallowInterceptTouchEvent(true) 로 끼어들기를 막거나 아래에서 터치를 받지 않아서
     * 움직임이 여기까지 오지 않았다. dispatchTouchEvent 는 그런 것과 상관없이 모든 터치가 지나간다.
     */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (animating) return true
        if (!dragging && handleZoomTouch(ev)) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = false; armed = false
                val w = width.toFloat(); val h = height.toFloat()
                eligible = enabledProvider() && !isZoomed() && content() != null &&
                    ev.x in (w * 0.06f)..(w * 0.94f) && ev.y in (h * 0.08f)..(h * 0.82f) &&
                    startFilter(ev.x, ev.y)
                downX = ev.x; downY = ev.y
                recycle()
                if (eligible) { vt = VelocityTracker.obtain(); vt?.addMovement(ev) }
                // 아래에서 아무도 DOWN 을 받지 않아도 이후 움직임이 여기로 오게 true 로 돌려준다
                val r = super.dispatchTouchEvent(ev)
                return r || eligible || zoomEnabled()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!dragging) eligible = false          // 두 손가락(확대 등)이면 포기
            }
            MotionEvent.ACTION_MOVE -> {
                // 꾹 눌러 2배속 중(길게 누름 시간이 지난 터치)에는 아래로 끌어도 나가지 않는다.
                // 2배속을 켜는 길게 누름과 같은 시간 기준이라 모든 플레이어(내장 · 웹 전체화면 · 미러링)에 똑같이 적용된다
                if (!dragging && eligible && ev.eventTime - ev.downTime >= ViewConfiguration.getLongPressTimeout()) {
                    eligible = false
                }
                if (!dragging && eligible) {
                    vt?.addMovement(ev)
                    val dx = ev.x - downX; val dy = ev.y - downY
                    if (dy < -slop * 0.5f || (abs(dx) > slop && abs(dx) > dy)) {
                        eligible = false
                    } else if (dy > slop && dy > abs(dx) * 1.3f) {   // 비스듬히 내려도(약 40° 이상) 인식
                        dragging = true
                        parent?.requestDisallowInterceptTouchEvent(true)
                        // 아래 영상에는 터치가 취소됐다고 알려서, 끌던 동작이 이어지지 않게 한다
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(c)
                        c.recycle()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) { eligible = false; recycle() }
            }
        }
        if (dragging) {
            handleDrag(ev)
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun handleDrag(ev: MotionEvent) {
        vt?.addMovement(ev)
        val v = content() ?: return
        val h = height.toFloat().coerceAtLeast(1f)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val dy = (ev.y - downY - slop).coerceAtLeast(0f)       // 끼어든 순간부터 따라가서 툭 튀지 않게
                val p = (dy / (h * 0.45f)).coerceIn(0f, 1f)
                val s = 1f - 0.12f * p
                for (t in targets(v)) {
                    t.translationY = dy * 0.85f
                    t.scaleX = s; t.scaleY = s
                    t.alpha = 1f - 0.45f * p
                }
                val ready = dy > h * 0.22f
                if (ready != armed) {
                    armed = ready
                    // 놓으면 나가는 거리에 닿거나, 다시 돌아가면 살짝 진동
                    performHapticFeedback(
                        if (ready) {
                            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.KEYBOARD_TAP
                        } else HapticFeedbackConstants.CLOCK_TICK
                    )
                }
            }
            MotionEvent.ACTION_UP -> {
                vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                val dy = (ev.y - downY - slop).coerceAtLeast(0f)
                dragging = false; eligible = false; recycle()
                if (dy > h * 0.22f || (vy > flingV && dy > minFlingDist)) dismiss(v, h) else springBack(v)
            }
            MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> {
                dragging = false; eligible = false; recycle()
                springBack(v)
            }
        }
    }

    /** 같이 움직일 뷰들: 콘텐츠 + [companions] (중복 없이) */
    private fun targets(v: View): List<View> {
        val extra = companions().filter { it !== v }
        return if (extra.isEmpty()) listOf(v) else listOf(v) + extra
    }

    private fun dismiss(v: View, h: Float) {
        animating = true
        val ts = targets(v)
        ts.forEachIndexed { i, t ->
            t.animate().cancel()
            val a = t.animate()
                .translationY(h * 0.55f).scaleX(0.82f).scaleY(0.82f).alpha(0f)
                .setDuration(190).setInterpolator(AccelerateInterpolator(1.4f))
            // 끝 동작은 한 번만 (첫 뷰에서)
            if (i == 0) a.withEndAction {
                if (!animating) return@withEndAction      // 그 사이 다른 경로(뒤로 가기 등)로 이미 닫힌 경우
                animating = false
                onDismiss()
            }
            a.start()
        }
    }

    private fun springBack(v: View) {
        armed = false
        for (t in targets(v)) {
            t.animate().cancel()
            t.animate()
                .translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(260).setInterpolator(OvershootInterpolator(1.1f))
                .start()
        }
    }
}
