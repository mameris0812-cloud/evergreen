package com.example.evergreen

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.shape.MaterialShapeDrawable
import com.google.android.material.R as MR

/**
 * 크롬 테마를 앱 전체(메뉴 · 팝업 · 탭 화면 · 목록 화면 · 대화상자)에 입히는 색 표.
 * 테마가 켜져 있으면 머티리얼 색 속성(colorSurface · colorOnSurface · colorPrimary …)을 테마에서 뽑은 색으로 바꿔 돌려주고,
 * 꺼져 있으면 원래 머티리얼 색을 그대로 돌려준다. 앱 곳곳의 MaterialColors.getColor 대신 [get] 을 쓴다.
 */
/** 직접 그리는 드로어블이 자기 색(바탕·채움 등)을 테마 바꿈표대로 스스로 바꾸게 한다. [map] 은 색을 받아 바뀐 색을 돌려준다 */
interface ThemeRecolorable {
    fun recolorTheme(map: (Int) -> Int)
}

object ThemeColors {
    @Volatile private var map: Map<Int, Int>? = null

    val active: Boolean get() = map != null
    val isDark: Boolean get() = dark
    @Volatile private var dark = false

    fun get(ctx: Context, attr: Int, def: Int): Int = map?.get(attr) ?: MaterialColors.getColor(ctx, attr, def)
    fun get(v: View, attr: Int): Int = map?.get(attr) ?: MaterialColors.getColor(v, attr)
    fun get(v: View, attr: Int, def: Int): Int = map?.get(attr) ?: MaterialColors.getColor(v, attr, def)

    /** [bg] 위에서 잘 읽히는 색: [want] 의 대비가 모자라면 흰색/검정 계열 */
    fun readableOn(bgIn: Int, want: Int?): Int {
        val bg = bgIn or 0xFF000000.toInt()   // calculateContrast 는 반투명 배경이면 예외를 낸다
        if (want != null) {
            val w = ColorUtils.setAlphaComponent(want, 255)
            if (ColorUtils.calculateContrast(w, bg) >= 3.0) return w
        }
        return if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF1F1F1F.toInt() else 0xFFF1F3F4.toInt()
    }

    /** 켜진 테마에서 색 표를 만든다. null 이면 테마 끔(원래 색) */
    fun set(th: ExtensionManager.ThemeSpec?) {
        val prev = map
        if (th == null) { map = null; dark = false; if (prev != null) reskinLive(prev, null); return }
        val surface = ColorUtils.setAlphaComponent(th.toolbar, 255)
        val isDk = ColorUtils.calculateLuminance(surface) < 0.5
        // 삼성 테마: 아이콘색(#545454)을 쓰면 메뉴·팝업의 버튼과 글자가 흐린 회색으로 보여서, 탭 글자색(진한 색)을 쓴다
        val on = readableOn(surface, if (th.samsungTabs) (th.tabText ?: th.icon ?: th.ntpText) else (th.icon ?: th.tabText ?: th.ntpText))
        fun mix(w: Float) = ColorUtils.blendARGB(surface, on, w)
        // 강조색: 테마의 링크색 → 탭바(frame) 색 → 글자색 순으로, 바탕과 대비가 3 이상인 첫 색
        // 그래도 없으면(연한 파랑 탭바처럼 바탕과 비슷한 밝기) 같은 색상(hue)을 바탕과 대비 3이 되도록 어둡게/밝게 조정해서 쓴다.
        // 예전엔 이때 글자색을 흐리게 섞은 무채색이 되어, 파란 테마인데 메뉴만 회색·검정으로 보였다
        val cands = listOfNotNull(th.ntpLink, th.frame, th.omnibox).map { ColorUtils.setAlphaComponent(it, 255) }
        fun deriveAccent(c: Int): Int? {
            val hsl = FloatArray(3)
            ColorUtils.colorToHSL(c, hsl)
            if (hsl[1] < 0.12f) return null   // 거의 무채색이면 색상이 의미 없다
            hsl[1] = hsl[1].coerceIn(0.45f, 0.85f)
            repeat(40) {
                val col = ColorUtils.HSLToColor(hsl)
                if (ColorUtils.calculateContrast(col, surface) >= 3.0) return col
                hsl[2] = (hsl[2] + if (isDk) 0.02f else -0.02f).coerceIn(0f, 1f)
            }
            return null
        }
        val accent = cands.firstOrNull { ColorUtils.calculateContrast(it, surface) >= 3.0 }
            ?: cands.firstNotNullOfOrNull { deriveAccent(it) }
            ?: ColorUtils.blendARGB(on, surface, 0.15f)
        // 메뉴 배경·카드 바탕 단계는 글자색이 아니라 강조색(테마 색상)을 살짝 섞어서, 회색 대신 테마 색조가 돌게 한다
        fun tint(w: Float) = ColorUtils.blendARGB(surface, accent, w)
        val primaryContainer = ColorUtils.blendARGB(surface, accent, if (isDk) 0.30f else 0.18f)
        val onPrimaryContainer = readableOn(primaryContainer, accent)
        val m = HashMap<Int, Int>()
        // 속성 id 는 이름으로 찾지 않고 직접 참조한다 (릴리스 빌드에서 R8 이 안 쓰이는 R 필드를 지우면 이름 찾기가 실패해 테마 색이 하나도 안 입혀졌다)
        // blendARGB 는 부동소수점 때문에 알파를 254 로 돌려줄 때가 있어(예: #feeff4fd) 대비 계산(calculateContrast)이 "반투명 배경" 예외를 냈다 → 표의 색은 모두 불투명으로 고정한다
        fun put(a: Int, c: Int) { m[a] = c or 0xFF000000.toInt() }
        put(MR.attr.colorSurface, surface)
        put(MR.attr.colorSurfaceBright, surface)
        put(MR.attr.colorSurfaceContainerLowest, ColorUtils.blendARGB(surface, if (isDk) 0xFF000000.toInt() else 0xFFFFFFFF.toInt(), 0.35f))
        put(MR.attr.colorSurfaceContainerLow, tint(0.04f))
        put(MR.attr.colorSurfaceContainer, tint(0.09f))
        put(MR.attr.colorSurfaceContainerHigh, tint(0.13f))
        // 삼성 테마(라이트): 메뉴창 등 시트 바탕은 연한 회색 #F1F1F1
        // 삼성 테마(다크): 시트 바탕은 거의 검정, 그 위 카드는 한 단계 밝은 회색이라 카드가 또렷이 구분된다
        if (th.samsungTabs) put(MR.attr.colorSurfaceContainer, if (isDk) 0xFF0F0F10.toInt() else 0xFFF1F1F1.toInt())
        if (th.samsungTabs && isDk) { put(MR.attr.colorSurfaceContainerHigh, 0xFF2C2C2E.toInt()); put(MR.attr.colorSurfaceContainerHighest, 0xFF3A3A3C.toInt()) }
        put(MR.attr.colorSurfaceContainerHighest, tint(0.18f))
        put(MR.attr.colorSurfaceVariant, tint(0.13f))
        put(MR.attr.colorOnSurface, on)
        put(MR.attr.colorOnSurfaceVariant, ColorUtils.blendARGB(on, surface, 0.32f))
        put(MR.attr.colorPrimary, accent)
        put(MR.attr.colorOnPrimary, readableOn(accent, null))
        put(MR.attr.colorPrimaryContainer, primaryContainer)
        put(MR.attr.colorOnPrimaryContainer, onPrimaryContainer)
        put(MR.attr.colorSecondaryContainer, primaryContainer)
        put(MR.attr.colorOnSecondaryContainer, onPrimaryContainer)
        put(MR.attr.colorOutline, ColorUtils.blendARGB(surface, on, 0.45f))
        put(MR.attr.colorOutlineVariant, mix(0.18f))
        m[android.R.attr.colorBackground] = surface or 0xFF000000.toInt()
        // 코드로 만든 TextView 는 글자색을 따로 안 주면 시스템 기본 글자색(textColorPrimary/Secondary/Tertiary)을 쓴다 → 테마 글자색으로 바꿔 줄 수 있게 한다
        m[android.R.attr.textColorPrimary] = on or 0xFF000000.toInt()
        m[android.R.attr.textColorSecondary] = ColorUtils.blendARGB(on, surface, 0.32f) or 0xFF000000.toInt()
        m[android.R.attr.textColorTertiary] = ColorUtils.blendARGB(on, surface, 0.50f) or 0xFF000000.toInt()
        dark = isDk
        map = m
        // 이미 떠 있는 창(메뉴 · 팝업 · 대화상자)도 새 테마 색으로 바로 바꾼다
        if (prev != m) reskinLive(prev, m)
    }

    /**
     * 스위치(MaterialSwitch)는 색을 액티비티 기본 테마에서 직접 가져와서 위 [map] 도, XML 색 바꿔치기도 안 거친다 → 켜도 기본 초록이 그대로였다.
     * 테마가 켜져 있으면 켜짐/꺼짐/비활성 색을 테마 색으로 다시 칠한다.
     */
    private val switchOrig = java.util.WeakHashMap<MaterialSwitch, Array<ColorStateList?>>()

    private fun restoreSwitch(sw: MaterialSwitch) {
        val o = switchOrig.remove(sw) ?: return
        try {
            sw.trackTintList = o[0]; sw.thumbTintList = o[1]
            sw.trackDecorationTintList = o[2]; sw.thumbIconTintList = o[3]
        } catch (_: Throwable) { }
    }

    fun applySwitch(sw: MaterialSwitch) {
        val m = map ?: return
        val primary = m[MR.attr.colorPrimary] ?: return
        val onPrimary = m[MR.attr.colorOnPrimary] ?: return
        val trackOff = m[MR.attr.colorSurfaceContainerHighest] ?: return
        val outline = m[MR.attr.colorOutline] ?: return
        val onSurface = m[MR.attr.colorOnSurface] ?: return
        val iconOn = m[MR.attr.colorOnPrimaryContainer] ?: onPrimary
        // 테마를 끄면 되돌릴 수 있게 처음 색을 한 번 적어 둔다
        if (!switchOrig.containsKey(sw)) switchOrig[sw] = arrayOf(sw.trackTintList, sw.thumbTintList, sw.trackDecorationTintList, sw.thumbIconTintList)
        val dis = intArrayOf(-android.R.attr.state_enabled)
        val chk = intArrayOf(android.R.attr.state_checked)
        val none = intArrayOf()
        fun csl(disabled: Int, checked: Int, unchecked: Int) =
            ColorStateList(arrayOf(dis, chk, none), intArrayOf(disabled, checked, unchecked))
        val offDis = ColorUtils.setAlphaComponent(onSurface, 31)    // 비활성 바탕 12%
        val thumbDis = ColorUtils.setAlphaComponent(onSurface, 97)  // 비활성 손잡이 38%
        try {
            sw.trackTintList = csl(offDis, primary, trackOff)
            sw.thumbTintList = csl(thumbDis, onPrimary, outline)
            sw.trackDecorationTintList = csl(thumbDis, 0x00000000, outline)
            sw.thumbIconTintList = csl(offDis, iconOn, trackOff)
        } catch (_: Throwable) { }
    }

    // ───────── XML 의 ?attr/색 으로 칠해진 화면에 테마 색 입히기 ─────────
    // XML 레이아웃·드로어블의 ?attr/colorXxx 는 액티비티의 기본 테마에서 풀려 나와서 위 [map] 을 거치지 않는다.
    // 그래서 목록 화면·대화상자처럼 XML 로 만든 화면은 [skin] 으로 "기본 테마 색이던 곳"을 찾아 테마 색으로 바꿔 준다.
    // 테마가 꺼져 있으면 아무것도 하지 않는다. 이미 코드에서 테마 색을 입힌 곳은 기본 색과 달라서 건드리지 않는다.

    /** 바탕(배경·틴트 바탕)으로 쓰이는 색 속성 — 앞선 것이 우선 (기본 테마에서 같은 색이 여럿이면 앞 속성의 테마 색을 쓴다) */
    private val FILL_ORDER = intArrayOf(
        MR.attr.colorSurface, MR.attr.colorSurfaceContainer, MR.attr.colorSurfaceContainerHigh,
        MR.attr.colorSurfaceContainerHighest, MR.attr.colorPrimary, MR.attr.colorPrimaryContainer,
        MR.attr.colorSecondaryContainer, MR.attr.colorSurfaceContainerLow, MR.attr.colorSurfaceContainerLowest,
        MR.attr.colorSurfaceVariant, MR.attr.colorOutlineVariant, MR.attr.colorOutline, MR.attr.colorOnSurface
    )

    /** 글자·아이콘으로 쓰이는 색 속성 (흰 글씨가 '바탕 흰색'이 아니라 '채움 위 글자색'으로 바뀌도록 따로 둔다) */
    private val FG_ORDER = intArrayOf(
        MR.attr.colorOnSurface, MR.attr.colorOnSurfaceVariant, MR.attr.colorOnPrimary, MR.attr.colorPrimary,
        MR.attr.colorOnPrimaryContainer, MR.attr.colorOnSecondaryContainer, MR.attr.colorOutline,
        MR.attr.colorOutlineVariant, MR.attr.colorSurface,
        android.R.attr.textColorPrimary, android.R.attr.textColorSecondary, android.R.attr.textColorTertiary
    )

    private const val OPAQUE = 0xFF000000.toInt()
    private var cacheMap: Map<Int, Int>? = null
    private var cacheUi = -1
    private var cacheFill: Map<Int, Int> = emptyMap()
    private var cacheFg: Map<Int, Int> = emptyMap()

    private fun buildTable(ctx: Context, m: Map<Int, Int>, order: IntArray): Map<Int, Int> {
        val out = HashMap<Int, Int>()
        for (attr in order) {
            val themed = m[attr] ?: continue
            val base = MaterialColors.getColor(ctx, attr, 0)
            if (base == 0) continue
            val key = base or OPAQUE
            val to = themed or OPAQUE
            if (key != to && !out.containsKey(key)) out[key] = to
        }
        return out
    }

    private fun tables(ctx: Context, m: Map<Int, Int>) {
        val ui = ctx.resources.configuration.uiMode
        if (cacheMap === m && cacheUi == ui) return
        cacheFill = buildTable(ctx, m, FILL_ORDER)
        cacheFg = buildTable(ctx, m, FG_ORDER)
        cacheMap = m
        cacheUi = ui
    }

    private fun re(c: Int, t: Map<Int, Int>): Int {
        val a = c ushr 24
        if (a == 0) return c
        val n = t[c or OPAQUE] ?: return c
        return if (a == 255) n else ColorUtils.setAlphaComponent(n, a)
    }

    /** 색 목록의 색(기본·비활성)을 바꾼 새 목록. 바뀐 게 없으면 null */
    private fun reCsl(cs: ColorStateList?, t: Map<Int, Int>): ColorStateList? {
        if (cs == null) return null
        val def = cs.defaultColor
        val nd = re(def, t)
        if (!cs.isStateful) return if (nd != def) ColorStateList.valueOf(nd) else null
        val off = intArrayOf(-android.R.attr.state_enabled)
        val dis = cs.getColorForState(off, def)
        val ndis = re(dis, t)
        if (nd == def && ndis == dis) return null
        return ColorStateList(arrayOf(off, intArrayOf()), intArrayOf(ndis, nd))
    }

    /** 드로어블 안의 단색 칠을 바꾼다 (이미 mutate 한 것만 넘긴다). 눌림 물결(Ripple)은 마스크를 뺀 안쪽만 바꾼다 */
    private fun recolor(d: Drawable?, t: Map<Int, Int>) {
        when (d) {
            null -> {}
            // 눌림 물결: 모양(마스크)과 물결 색은 그대로 두고 안쪽 바탕만 바꾼다
            is RippleDrawable -> for (i in 0 until d.numberOfLayers) if (d.getId(i) != android.R.id.mask) recolor(d.getDrawable(i), t)
            is ColorDrawable -> { val n = re(d.color, t); if (n != d.color) d.color = n }
            is GradientDrawable -> reCsl(d.getColor(), t)?.let { d.setColor(it) }
            is MaterialShapeDrawable -> reCsl(d.fillColor, t)?.let { d.fillColor = it }
            is LayerDrawable -> for (i in 0 until d.numberOfLayers) recolor(d.getDrawable(i), t)
            is InsetDrawable -> recolor(d.drawable, t)
            is ThemeRecolorable -> d.recolorTheme { c -> re(c, t) }
            else -> {}
        }
    }

    private fun skinDrawable(d: Drawable?, t: Map<Int, Int>, seen: MutableSet<Any>? = null): Drawable? {
        if (d == null || t.isEmpty()) return d
        // 같은 드로어블을 여러 뷰가 나눠 쓰면 색이 두 번 바뀌지 않게 한 번만 칠한다
        if (seen != null && !seen.add(d)) return d
        return try { d.mutate().also { recolor(it, t) } } catch (_: Throwable) { d }
    }

    /**
     * [root] 아래 모든 뷰의 배경 · 글자색 · 아이콘 틴트 · 진행바 · 버튼 색 가운데 "기본 테마 색"인 것을 지금 테마 색으로 바꾼다.
     * 목록(ListView)은 나중에 만들어지는 줄에도 같이 입힌다.
     */
    fun skin(root: View?) {
        if (root == null) return
        track(root)   // 테마가 꺼져 있어도 기억해 둔다 (나중에 테마를 켜면 이미 떠 있는 창도 바뀌게)
        val m = map ?: return
        try {
            tables(root.context, m)
            walk(root, cacheFill, cacheFg)
        } catch (_: Throwable) { }
    }

    // ───────── 테마를 바꿀 때 이미 떠 있는 창도 바로 바꾸기 ─────────
    // 창은 만들어질 때의 테마 색으로 칠해져 있어서, 테마를 바꿔도 다시 열기 전에는 옛 색이 남았다.
    // 테마를 입힌(skin) 창의 뿌리 뷰를 약하게 기억해 두었다가, 테마가 바뀌는 순간 "옛 테마 색 → 새 테마 색" 표로 한 번 더 칠한다.
    private val live = ArrayList<java.lang.ref.WeakReference<View>>()

    private fun track(root: View) {
        live.removeAll { it.get() == null }
        if (live.none { it.get() === root }) live.add(java.lang.ref.WeakReference(root))
    }

    /** [old] 테마 색(없으면 기본 색)에서 [now] 테마 색(없으면 기본 색)으로 가는 색 바꿈표 */
    private fun transition(ctx: Context, old: Map<Int, Int>?, now: Map<Int, Int>?, order: IntArray): Map<Int, Int> {
        val out = HashMap<Int, Int>()
        for (attr in order) {
            val base = MaterialColors.getColor(ctx, attr, 0)
            val from = old?.get(attr) ?: base
            val to = now?.get(attr) ?: base
            if (from == 0 || to == 0) continue
            val key = from or OPAQUE
            val v = to or OPAQUE
            if (key != v && !out.containsKey(key)) out[key] = v
        }
        return out
    }

    private fun reskinLive(old: Map<Int, Int>?, now: Map<Int, Int>?) {
        try {
            val attached = live.mapNotNull { it.get() }.filter { it.isAttachedToWindow }
            live.removeAll { r -> val v = r.get(); v == null || !v.isAttachedToWindow }
            if (attached.isEmpty()) return
            val set = java.util.IdentityHashMap<View, Boolean>()
            attached.forEach { set[it] = true }
            // 안쪽 뷰가 따로 기억돼 있어도 바깥 뿌리에서 한 번만 칠한다 (두 번 칠하면 색이 한 번 더 바뀐다)
            val roots = attached.filter { r ->
                var p = r.parent as? View
                var nested = false
                while (p != null) { if (set.containsKey(p)) { nested = true; break }; p = p.parent as? View }
                !nested
            }
            for (r in roots) {
                try {
                    val ctx = r.context
                    val fill = transition(ctx, old, now, FILL_ORDER)
                    val fg = transition(ctx, old, now, FG_ORDER)
                    if (fill.isEmpty() && fg.isEmpty() && now != null) continue
                    walk(r, fill, fg, java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Any, Boolean>()))
                    r.invalidate()
                } catch (_: Throwable) { }
            }
        } catch (_: Throwable) { }
    }

    /**
     * 팝업 아래 두 버튼(왼쪽 연한 버튼 · 오른쪽 진한 버튼)을 테마 색으로 직접 칠한다.
     * 삼성 테마처럼 강조색이 회색에 가까운 테마에서는 기본 색 변환을 거치면 두 버튼이 눌러도 안 될 듯한 흐린 회색으로 보였다.
     * 비활성 상태에서도 같은 색을 쓰고, 테마가 꺼져 있으면 아무것도 하지 않는다.
     */
    fun paintPopupFooter(root: View) {
        if (map == null) return
        val ctx = root.context
        val primary = get(ctx, MR.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val onPrimary = get(ctx, MR.attr.colorOnPrimary, 0xFFFFFFFF.toInt())
        val pc = get(ctx, MR.attr.colorPrimaryContainer, 0xFFE8F5EC.toInt())
        val onPc = get(ctx, MR.attr.colorOnPrimaryContainer, 0xFF14532D.toInt())
        // 오른쪽 버튼이 진한 회색 채움이면(강조색이 무채색) 삼성 파랑으로 또렷하게 보이게 한다
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(primary, hsl)
        val gray = hsl[1] < 0.12f
        val okFill = if (gray) 0xFF2F7DF0.toInt() else primary
        val okText = if (gray) 0xFFFFFFFF.toInt() else onPrimary
        root.findViewById<android.widget.Button>(R.id.popupCancel)?.let { b ->
            b.isEnabled = true
            androidx.core.view.ViewCompat.setBackgroundTintList(b, ColorStateList.valueOf(pc))
            b.setTextColor(onPc)
            b.tag = SKIP_SKIN
        }
        root.findViewById<android.widget.Button>(R.id.popupOk)?.let { b ->
            b.isEnabled = true
            androidx.core.view.ViewCompat.setBackgroundTintList(b, ColorStateList.valueOf(okFill))
            b.setTextColor(okText)
            b.tag = SKIP_SKIN
        }
    }

    /** 대화상자: 카드 바탕과 안의 글자·버튼에 테마 색을 입힌다 (보여질 때 불러야 안쪽 뷰가 만들어져 있다) */
    fun skinDialog(d: android.app.Dialog?) {
        skin(d?.window?.decorView)
    }

    /** 코드에서 이미 테마 색으로 칠한 뷰(태그가 이 값)는 "기본 색 → 테마 색" 변환을 다시 거치지 않는다.
     *  거치면 테마 글자색(예: 흰색)이 기본 테마의 다른 색(예: 바탕 흰색)과 같다는 이유로 바탕색으로 한 번 더 바뀌어, 어두운 카드 위에 어두운 글자가 됐다 */
    const val SKIP_SKIN = "ev_skip_skin"

    private fun walk(v: View, fill: Map<Int, Int>, fg: Map<Int, Int>, seen: MutableSet<Any>? = null) {
        if (v.tag == SKIP_SKIN) return
        v.background?.let { skinDrawable(it, fill, seen) }   // mutate() 는 같은 객체를 돌려주므로 다시 대입하지 않는다 (대입하면 패딩이 초기화된다)
        v.backgroundTintList?.let { cs -> reCsl(cs, fill)?.let { v.backgroundTintList = it } }
        when (v) {
            is MaterialSwitch -> if (map != null) applySwitch(v) else restoreSwitch(v)
            is MaterialButton -> {
                reCsl(v.iconTint, fg)?.let { v.iconTint = it }
                reCsl(v.strokeColor, fg)?.let { v.strokeColor = it }
                reCsl(v.textColors, fg)?.let { v.setTextColor(it) }
            }
            is TextView -> {
                // 탭 개수 버튼의 글자는 투명으로 둔다 (숫자는 MorphIconDrawable 이 그린다)
                if (v.background !is MorphIconDrawable) reCsl(v.textColors, fg)?.let { v.setTextColor(it) }
                reCsl(v.hintTextColors, fg)?.let { v.setHintTextColor(it) }
            }
            is ImageView -> reCsl(v.imageTintList, fg)?.let { v.imageTintList = it }
            is ProgressBar -> {
                reCsl(v.progressTintList, fg)?.let { v.progressTintList = it }
                reCsl(v.progressBackgroundTintList, fill)?.let { v.progressBackgroundTintList = it }
                reCsl(v.indeterminateTintList, fg)?.let { v.indeterminateTintList = it }
            }
            is AbsListView -> {
                v.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                    override fun onChildViewAdded(parent: View, child: View) { skin(child) }
                    override fun onChildViewRemoved(parent: View, child: View) {}
                })
                if (v is android.widget.ListView) v.divider?.let { skinDrawable(it, fill, seen) }
            }
        }
        // 재생 위치 막대(SeekBar): 막대 트랙과 손잡이 드로어블에도 색을 입힌다
        if (v is android.widget.SeekBar) {
            skinDrawable(v.progressDrawable, fill, seen)
            skinDrawable(v.thumb, fill, seen)
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i), fill, fg, seen)
    }
}
