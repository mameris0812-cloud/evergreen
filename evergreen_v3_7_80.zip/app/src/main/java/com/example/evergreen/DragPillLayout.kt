package com.example.evergreen

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.widget.LinearLayout
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 알약 모양 막대: 자동 스크롤 조작 막대가 쓴다. 블러 없이 불투명한 면 + 가는 테두리선이다
 * (앱 알림·진행 카드처럼 높이(Z)를 크게 올려 그리므로 시스템 그림자는 쓰지 않고, 테두리선으로 웹 페이지와 구분한다).
 *
 * 세로로 끄는 동작도 받는다: [onDrag] / [onDragEnd] 를 정하면, 자식 버튼 위에서 시작한 세로 끌기도 이 막대가 가져와
 * 막대를 따라 움직이게 한다 (버튼을 그냥 누르는 것은 그대로 버튼이 받는다).
 */
class DragPillLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : LinearLayout(ctx, attrs) {

    /** 세로로 끄는 중: 처음 닿은 곳에서 지금까지 내려온 거리(px, 아래가 +) */
    var onDrag: ((Float) -> Unit)? = null

    /** 끌기가 끝났을 때: 내려온 거리(px)와 손가락을 뗄 때의 세로 속도(px/초, 아래가 +) */
    var onDragEnd: ((Float, Float) -> Unit)? = null

    // 끌기 상태
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var vt: VelocityTracker? = null

    init {
        val fill = ThemeColors.get(this, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFFEEEEEE.toInt())
        val edge = ColorUtils.setAlphaComponent(
            ThemeColors.get(this, com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt()), 0xB0
        )
        // 반지름을 아주 크게 주면 GradientDrawable 이 짧은 변의 절반으로 줄여 알약 모양이 된다
        background = GradientDrawable().apply {
            cornerRadius = 1000f
            setColor(fill)
            setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), edge)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        vt?.recycle(); vt = null
        dragging = false
    }

    // ───────────────────────── 세로 끌기 ─────────────────────────

    private fun beginTrack(ev: MotionEvent) {
        downX = ev.rawX
        downY = ev.rawY
        dragging = false
        vt?.recycle()
        vt = VelocityTracker.obtain()
        vt?.addMovement(ev)
    }

    private fun endTrack() {
        vt?.recycle()
        vt = null
        dragging = false
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (onDrag == null) return super.onInterceptTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> beginTrack(ev)
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                val dy = ev.rawY - downY
                val dx = ev.rawX - downX
                if (!dragging && Math.abs(dy) > slop && Math.abs(dy) > Math.abs(dx)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTrack()
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val drag = onDrag ?: return super.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (vt == null) beginTrack(ev)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                val dy = ev.rawY - downY
                val dx = ev.rawX - downX
                if (!dragging && Math.abs(dy) > slop && Math.abs(dy) > Math.abs(dx)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) drag(dy)
                return true
            }
            MotionEvent.ACTION_UP -> {
                val was = dragging
                val dy = ev.rawY - downY
                var vy = 0f
                vt?.let { it.addMovement(ev); it.computeCurrentVelocity(1000); vy = it.yVelocity }
                endTrack()
                if (was) onDragEnd?.invoke(dy, vy) else performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                val dy = ev.rawY - downY
                endTrack()
                if (was) onDragEnd?.invoke(dy, 0f)
                return true
            }
        }
        return super.onTouchEvent(ev)
    }
}
