package com.example.evergreen

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.widget.ScrollView
import android.widget.TextView

/**
 * PiP 로 들어간 창이 사라지는 문제를 찾기 위한 진단 기록 (v2.6.10).
 * PiP 를 시작할 때부터 창의 수명 주기(pause/stop/destroy)와 finish 를 부른 곳(호출 스택)을 적어 두고,
 * 창이 PiP 도중 닫혔다면 다음에 앱 화면이 보일 때 그 기록을 한 번 보여 준다 (복사해서 보낼 수 있다).
 */
object PipDiag {
    private const val SP = "pip_diag"
    private const val KEY = "log"
    private const val MAX = 6000
    private var t0 = 0L

    private fun sp(c: Context) = c.getSharedPreferences(SP, Context.MODE_PRIVATE)

    /** 새 PiP 시도를 시작한다: 이전 기록은 지운다 */
    fun begin(c: Context, what: String) {
        t0 = SystemClock.uptimeMillis()
        sp(c).edit().putString(KEY, "").commit()
        log(c, "BEGIN $what | sdk=${Build.VERSION.SDK_INT} ${Build.MANUFACTURER} ${Build.MODEL}")
    }

    fun log(c: Context, msg: String) {
        try {
            val p = sp(c)
            var s = p.getString(KEY, "").orEmpty()
            // 시작 기록이 없으면(=PiP 시도와 무관한 때) 아무것도 적지 않는다
            if (!s.startsWith("BEGIN") && !msg.startsWith("BEGIN")) return
            val line = "+${SystemClock.uptimeMillis() - t0}ms $msg\n"
            s += line
            if (s.length > MAX) s = s.substring(s.length - MAX)
            p.edit().putString(KEY, s).commit()
        } catch (_: Throwable) {}
    }

    /** 호출한 곳(앱 코드 쪽 스택 몇 줄) */
    fun caller(): String =
        Throwable().stackTrace.filter { it.className.startsWith("com.example.evergreen") && !it.className.contains("PipDiag") }
            .take(5).joinToString(" < ") { "${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}" }

    /** PiP 도중 창이 파괴된 기록이 남아 있으면 한 번 보여 준다 */
    fun showIfAny(a: Activity) {
        try {
            if (!Prefs(a).ownerMode) return   // 문제 확인용 창이라 내 폰 모드에서만
            val p = sp(a)
            val s = p.getString(KEY, "").orEmpty()
            if (!s.contains("DESTROY")) return
            p.edit().putString(KEY, "").commit()
            val tv = TextView(a).apply {
                text = s
                textSize = 11f
                setTextIsSelectable(true)
                setPadding(40, 20, 40, 20)
            }
            val sv = ScrollView(a).apply { addView(tv) }
            AlertDialog.Builder(a)
                .setTitle("PiP 진단 기록")
                .setView(sv)
                .setPositiveButton("복사") { _, _ ->
                    (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("pip_diag", s))
                }
                .setNegativeButton("닫기", null)
                .show()
        } catch (_: Throwable) {}
    }
}
