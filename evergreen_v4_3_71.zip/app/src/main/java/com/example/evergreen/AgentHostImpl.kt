package com.example.evergreen

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * [AgentHost] 의 구현: AI 도구와 2만 줄짜리 MainActivity 사이의 얇은 연결 층.
 * MainActivity 안쪽을 직접 만지지 않고, MainActivity 가 열어 둔 `agentXxx()` 함수만 부른다.
 * 도구는 백그라운드 스레드에서 도니, 화면·탭을 만지는 일은 여기서 메인 스레드로 넘기고 결과를 기다린다.
 */
class MainAgentHost(private val activity: MainActivity) : AgentHost {
    private val handler = Handler(Looper.getMainLooper())

    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val task = FutureTask<T>(Callable<T> { block() })
        handler.post(task)
        try {
            return task.get(8, TimeUnit.SECONDS)
        } catch (e: TimeoutException) {
            task.cancel(false)
            throw IllegalStateException("앱이 응답하지 않아요")
        } catch (e: ExecutionException) {
            throw (e.cause ?: e)
        }
    }

    /** 중지할 때마다 올라가는 번호. 기다리는 동안 이 번호가 바뀌면 시간 초과를 기다리지 않고 바로 포기한다 */
    @Volatile
    private var abortGen = 0

    override fun abortPending() {
        abortGen++
    }

    /** [latch] 가 풀리기를 최대 [sec] 초 기다린다. 풀리면 true, 시간이 다 되었거나 중지됐으면 false */
    private fun awaitLatch(latch: java.util.concurrent.CountDownLatch, sec: Long): Boolean {
        val gen = abortGen
        val end = System.nanoTime() + TimeUnit.SECONDS.toNanos(sec)
        while (true) {
            if (latch.await(200, TimeUnit.MILLISECONDS)) return true
            if (abortGen != gen || System.nanoTime() >= end) return false
        }
    }

    private fun alive(): Boolean = !activity.isFinishing && !activity.isDestroyed

    private fun gone() = AgentOutcome.fail("앱 화면이 닫혀서 실행할 수 없어요")

    override fun tabs(): List<AgentTab> = onMain { if (alive()) activity.agentTabs() else emptyList() }

    override fun history(query: String, limit: Int): List<AgentPage> =
        onMain { if (alive()) activity.agentHistory(query, limit) else emptyList() }

    override fun bookmarks(query: String, limit: Int): List<AgentBookmark> =
        onMain { if (alive()) activity.agentBookmarks(query, limit) else emptyList() }

    override fun settings(): JSONObject = onMain { if (alive()) activity.agentSettings() else JSONObject() }

    override fun extensions(): List<AgentExt> = onMain { if (alive()) activity.agentExtensions() else emptyList() }

    override fun openTab(target: String, incognito: Boolean, background: Boolean): AgentOutcome =
        onMain { if (alive()) activity.agentOpenTab(target, incognito, background) else gone() }

    override fun closeTab(number: Int): AgentOutcome = onMain { if (alive()) activity.agentCloseTab(number) else gone() }

    override fun switchTab(number: Int): AgentOutcome = onMain { if (alive()) activity.agentSwitchTab(number) else gone() }

    override fun navigate(target: String, number: Int): AgentOutcome =
        onMain { if (alive()) activity.agentNavigate(target, number) else gone() }

    override fun pageNav(action: String): AgentOutcome = onMain { if (alive()) activity.agentPageNav(action) else gone() }

    override fun addBookmark(number: Int, folder: String): AgentOutcome =
        onMain { if (alive()) activity.agentAddBookmark(number, folder) else gone() }

    override fun removeBookmark(url: String): AgentOutcome =
        onMain { if (alive()) activity.agentRemoveBookmark(url) else gone() }

    override fun activeDownloads(): List<AgentActiveDownload> =
        DownloadService.snapshot().map { AgentActiveDownload(it.id, it.name, it.downloaded, it.total, it.speedBps, it.paused) }

    override fun controlDownload(id: Int, action: String): AgentOutcome {
        if (DownloadService.snapshot().none { it.id == id }) return AgentOutcome.fail("그 다운로드는 이미 끝났거나 없어요")
        return when (action) {
            "pause" -> { DownloadService.setPaused(id, true); AgentOutcome.ok("일시정지했어요", 1) }
            "resume" -> { DownloadService.setPaused(id, false); AgentOutcome.ok("이어 받기 시작했어요", 1) }
            "cancel" -> { DownloadService.cancelJob(id); AgentOutcome.ok("취소했어요", 1) }
            else -> AgentOutcome.fail("action 은 pause · resume · cancel 중 하나여야 해요")
        }
    }

    override fun renameBookmarkFolder(name: String, newName: String): AgentOutcome =
        onMain { if (alive()) activity.agentRenameBookmarkFolder(name, newName) else gone() }

    override fun deleteBookmarkFolder(name: String): AgentOutcome =
        onMain { if (alive()) activity.agentDeleteBookmarkFolder(name) else gone() }

    override fun bookmarkFolderSnapshot(name: String): Any? =
        onMain { if (alive()) activity.agentBookmarkFolderSnapshot(name) else null }

    override fun restoreBookmarkFolder(snapshot: Any): AgentOutcome =
        onMain { if (alive()) activity.agentRestoreBookmarkFolder(snapshot) else gone() }

    override fun moveTab(number: Int, to: Int): AgentOutcome =
        onMain { if (alive()) activity.agentMoveTab(number, to) else gone() }

    override fun duplicateTab(number: Int, background: Boolean): AgentOutcome =
        onMain { if (alive()) activity.agentDuplicateTab(number, background) else gone() }

    override fun reopenClosedTab(): AgentOutcome = onMain { if (alive()) activity.agentReopenClosedTab() else gone() }

    override fun openScreen(screen: String): AgentOutcome =
        onMain { if (alive()) activity.agentOpenScreen(screen) else gone() }

    override fun exportBookmarks(): AgentOutcome {
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        if (!alive()) return gone()
        val (marks, folders) = onMain { activity.agentBookmarkExportData() }
        if (marks.isEmpty()) return AgentOutcome.fail("내보낼 북마크가 없어요")
        val (name, why) = BookmarkPorter.saveToDownloads(activity, BookmarkPorter.toHtml(marks, folders))
        return if (name == null) AgentOutcome.fail(why)
        else AgentOutcome.ok("북마크 ${marks.size}개를 다운로드 폴더에 「$name」 파일로 내보냈어요", marks.size)
    }

    override fun importBookmarks(key: String): AgentOutcome {
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        if (!alive()) return gone()
        val loaded = BookmarkPorter.load(activity, key)
        if (loaded.error != null) return AgentOutcome.fail(loaded.error)
        return onMain { if (alive()) activity.agentImportBookmarks(loaded.items, loaded.truncated) else gone() }
    }

    override fun setSetting(name: String, value: String): AgentOutcome =
        onMain { if (alive()) activity.agentSetSetting(name, value) else gone() }

    override fun setExtension(id: String, on: Boolean): AgentOutcome =
        onMain { if (alive()) activity.agentSetExtension(id, on) else gone() }

    override fun openExtension(id: String, target: String): AgentOutcome =
        onMain { if (alive()) activity.agentOpenExtension(id, target) else gone() }

    override fun installExtension(store: String): AgentOutcome {
        // 인터넷에서 내려받는 동안 기다리는 함수라 화면 스레드에서 부르면 멈춰 버린다 (화면에 닿는 일은 activity 쪽이 스레드를 넘긴다)
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        return if (alive()) activity.agentInstallExtension(store) else gone()
    }

    override fun createExtension(request: String, scope: String, sites: String): AgentOutcome {
        // 만드는 동안 · 사용자가 카드를 고르는 동안 기다리는 함수라 화면 스레드에서 부르면 멈춰 버린다
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        return if (alive()) activity.agentCreateExtension(request, scope, sites) else gone()
    }

    override fun createFeature(request: String): AgentOutcome {
        // 만드는 동안 · 사용자가 카드를 고르는 동안 기다리는 함수라 화면 스레드에서 부르면 멈춰 버린다
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        return if (alive()) activity.agentCreateFeature(request) else gone()
    }

    override fun editExtension(id: String, change: String): AgentOutcome {
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        return if (alive()) activity.agentEditExtension(id, change) else gone()
    }

    override fun lastAiExtensionId(): String = onMain { if (alive()) activity.agentLastAiExtensionId() else "" }

    override fun editFeature(feature: String, change: String): AgentOutcome {
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        return if (alive()) activity.agentEditFeature(feature, change) else gone()
    }

    override fun editWebsite(change: String, tabNumber: Int): AgentOutcome {
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        return if (alive()) activity.agentEditWebsite(change, tabNumber) else gone()
    }

    override fun removeExtension(id: String): AgentOutcome =
        onMain { if (alive()) activity.agentRemoveExtension(id) else gone() }

    override fun themes(): List<AgentTheme> = onMain { if (alive()) activity.agentThemes() else emptyList() }

    override fun setTheme(id: String): AgentOutcome = onMain { if (alive()) activity.agentSetTheme(id) else gone() }

    override fun customizeTheme(colors: org.json.JSONObject): AgentOutcome = onMain { if (alive()) activity.agentCustomizeTheme(colors) else gone() }

    override fun openWebsite(title: String, html: String): AgentOutcome =
        onMain { if (alive()) activity.agentOpenWebsite(title, html) else gone() }

    override fun customThemeColors(): org.json.JSONObject? = onMain { if (alive()) activity.agentCustomThemeColors() else null }

    override fun restoreCustomTheme(colors: org.json.JSONObject?): AgentOutcome = onMain { if (alive()) activity.agentRestoreCustomTheme(colors) else gone() }

    override fun download(url: String): AgentOutcome = onMain { if (alive()) activity.agentDownload(url) else gone() }

    override fun windows(): List<AgentWindow> = onMain { if (alive()) activity.agentWindows() else emptyList() }

    override fun moveTabsToWindow(numbers: List<Int>, window: String, mode: String): AgentOutcome =
        onMain { if (alive()) activity.agentMoveTabsToWindow(numbers, window, mode) else gone() }

    override fun tabGroups(): List<AgentTabGroup> = onMain { if (alive()) activity.agentTabGroups() else emptyList() }

    override fun groupTabs(numbers: List<Int>, name: String, color: String, existing: String): AgentOutcome =
        onMain { if (alive()) activity.agentGroupTabs(numbers, name, color, existing) else gone() }

    override fun ungroupTabs(numbers: List<Int>, group: String): AgentOutcome =
        onMain { if (alive()) activity.agentUngroupTabs(numbers, group) else gone() }

    override fun editTabGroup(group: String, newName: String, color: String, collapsed: String): AgentOutcome =
        onMain { if (alive()) activity.agentEditTabGroup(group, newName, color, collapsed) else gone() }

    override fun hiddenTabCount(): Int = onMain { if (alive()) activity.agentHiddenTabCount() else 0 }

    override fun hideTabs(numbers: List<Int>): AgentOutcome =
        onMain { if (alive()) activity.agentHideTabs(numbers) else gone() }

    override fun unhideTabs(query: String): AgentOutcome {
        // 사용자가 지문·얼굴 인식을 마칠 때까지 기다리는 함수라 화면 스레드에서 부르면 멈춰 버린다
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        val latch = java.util.concurrent.CountDownLatch(1)
        val box = arrayOfNulls<AgentOutcome>(1)
        onMain {
            if (alive()) {
                activity.agentUnhideTabs(query) { out -> box[0] = out; latch.countDown() }
            } else {
                box[0] = gone()
                latch.countDown()
            }
        }
        if (!awaitLatch(latch, 60)) return AgentOutcome.fail("본인 확인이 시간 안에 끝나지 않아서 숨긴 탭을 꺼내지 않았어요")
        return box[0] ?: AgentOutcome.fail("본인 확인 결과를 받지 못했어요")
    }

    override fun groupSnapshot(): Any? = onMain { if (alive()) activity.agentGroupSnapshot() else null }

    override fun restoreGroups(snapshot: Any): AgentOutcome =
        onMain { if (alive()) activity.agentRestoreGroups(snapshot) else gone() }

    override fun deleteBookmarks(urls: List<String>): AgentOutcome =
        onMain { if (alive()) activity.agentDeleteBookmarks(urls) else gone() }

    override fun bookmarkFolders(): List<AgentBookmarkFolder> =
        onMain { if (alive()) activity.agentBookmarkFolders() else emptyList() }

    override fun renameBookmark(url: String, title: String): AgentOutcome =
        onMain { if (alive()) activity.agentRenameBookmark(url, title) else gone() }

    override fun moveBookmarks(urls: List<String>, folder: String): AgentOutcome =
        onMain { if (alive()) activity.agentMoveBookmarks(urls, folder) else gone() }

    override fun restoreBookmarkEdits(snapshot: Any, urls: List<String>): AgentOutcome =
        onMain { if (alive()) activity.agentRestoreBookmarkEdits(snapshot, urls) else gone() }

    override fun bookmarkSnapshot(): Any? = onMain { if (alive()) activity.agentBookmarkSnapshot() else null }

    override fun restoreBookmarkSnapshot(snapshot: Any): AgentOutcome =
        onMain { if (alive()) activity.agentRestoreBookmarks(snapshot) else gone() }

    override fun deleteHistory(urls: List<String>, all: Boolean): AgentOutcome =
        onMain { if (alive()) activity.agentDeleteHistory(urls, all) else gone() }

    override fun historySnapshot(): Any? = onMain { if (alive()) activity.agentHistorySnapshot() else null }

    override fun restoreHistorySnapshot(snapshot: Any): AgentOutcome =
        onMain { if (alive()) activity.agentRestoreHistory(snapshot) else gone() }

    override fun downloads(query: String, limit: Int): List<AgentDownload> =
        onMain { if (alive()) activity.agentDownloads(query, limit) else emptyList() }

    override fun loadImage(fileId: String, url: String): AgentImageLoad {
        // 파일 · 인터넷을 읽는 동안 기다리는 함수라 화면 스레드에서 부르면 멈춰 버린다
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentImageLoad(null, "화면 스레드에서는 쓸 수 없어요")
        if (!alive()) return AgentImageLoad(null, "앱 화면이 닫혀서 실행할 수 없어요")
        val referer = try { tabs().firstOrNull { it.current }?.url.orEmpty() } catch (e: Exception) { "" }
        return AgentImageLoader.load(activity, fileId, url, referer)
    }

    override fun deleteDownloads(keys: List<String>): AgentOutcome =
        onMain { if (alive()) activity.agentDeleteDownloads(keys) else gone() }

    override fun media(): List<AgentMedia> = onMain { if (alive()) activity.agentMedia() else emptyList() }

    override fun controlMedia(number: Int, action: String, value: Double): AgentOutcome =
        onMain { if (alive()) activity.agentControlMedia(number, action, value) else gone() }

    override fun openWindow(mode: String, target: String, window: String): AgentOutcome =
        onMain { if (alive()) activity.agentOpenWindow(mode, target, window) else gone() }

    override fun closeWindow(window: String): AgentOutcome =
        onMain { if (alive()) activity.agentCloseWindow(window) else gone() }

    override fun renameWindow(window: String, name: String): AgentOutcome =
        onMain { if (alive()) activity.agentRenameWindow(window, name) else gone() }

    override fun enterPip(): AgentOutcome = onMain { if (alive()) activity.agentEnterPip() else gone() }

    override fun setMirroring(on: Boolean): AgentOutcome = awaitOnMain(10, "페이지가 응답하지 않아요 (불러오는 중이거나 막혀 있을 수 있어요)") { done ->
        activity.agentSetMirroring(on, done)
    }

    override fun openInPlayer(): AgentOutcome = awaitOnMain(12, "페이지가 응답하지 않아요 (불러오는 중이거나 막혀 있을 수 있어요)") { done ->
        activity.agentOpenInPlayer(done)
    }

    /** 화면 스레드에서 [start] 를 시작하고, 그 쪽이 [done] 으로 결과를 줄 때까지 (최대 [sec] 초) 기다린다. 화면 스레드에서는 부를 수 없다 */
    private fun awaitOnMain(sec: Long, timeoutMsg: String, start: (done: (AgentOutcome) -> Unit) -> Unit): AgentOutcome {
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        val latch = java.util.concurrent.CountDownLatch(1)
        val box = arrayOfNulls<AgentOutcome>(1)
        onMain {
            if (alive()) {
                start { out -> box[0] = out; latch.countDown() }
            } else {
                box[0] = gone()
                latch.countDown()
            }
        }
        if (!awaitLatch(latch, sec)) return AgentOutcome.fail(timeoutMsg)
        return box[0] ?: AgentOutcome.fail("결과를 받지 못했어요")
    }

    // 설정 값 읽기뿐이라 화면 스레드로 넘기지 않는다 (SharedPreferences 는 스레드 안전)
    override fun showActions(): Boolean = alive() && activity.agentShowFx()

    override fun frames(): List<AgentFrame> = onMain { if (alive()) activity.agentFrames() else emptyList() }

    override fun frameScript(frame: Int, op: String, params: String): AgentOutcome {
        // 결과가 올 때까지 기다리는 함수라 화면 스레드에서 부르면 멈춰 버린다
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        val latch = java.util.concurrent.CountDownLatch(1)
        val box = arrayOfNulls<AgentOutcome>(1)
        onMain {
            if (alive()) {
                activity.agentRunFrameScript(frame, op, params) { ok, text ->
                    box[0] = if (ok) AgentOutcome.ok(text) else AgentOutcome.fail(text)
                    latch.countDown()
                }
            } else {
                box[0] = gone()
                latch.countDown()
            }
        }
        if (!awaitLatch(latch, 8)) return AgentOutcome.fail("iframe 이 응답하지 않아요 (불러오는 중이거나 막혀 있을 수 있어요)")
        return box[0] ?: AgentOutcome.fail("iframe 에서 결과를 받지 못했어요")
    }

    override fun pageScript(js: String): AgentOutcome {
        // 결과가 올 때까지 기다리는 함수라 화면 스레드에서 부르면 멈춰 버린다
        if (Looper.myLooper() == Looper.getMainLooper()) return AgentOutcome.fail("화면 스레드에서는 쓸 수 없어요")
        val latch = java.util.concurrent.CountDownLatch(1)
        val box = arrayOfNulls<AgentOutcome>(1)
        onMain {
            if (alive()) {
                activity.agentRunPageScript(js) { ok, text ->
                    box[0] = if (ok) AgentOutcome.ok(text) else AgentOutcome.fail(text)
                    latch.countDown()
                }
            } else {
                box[0] = gone()
                latch.countDown()
            }
        }
        if (!awaitLatch(latch, 10)) return AgentOutcome.fail("페이지가 응답하지 않아요 (불러오는 중이거나 막혀 있을 수 있어요)")
        return box[0] ?: AgentOutcome.fail("페이지에서 결과를 받지 못했어요")
    }
}
