package com.example.evergreen

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * 광고/트래커 차단기.
 * - 내장 목록 + 내려받은 오픈소스 목록(EasyList, EasyPrivacy, uBlock Origin, AdGuard, List-KR, StevenBlack, Hagezi ...)
 * - 도메인 목록: 서브도메인도 함께 차단 (예: x.doubleclick.net -> doubleclick.net)
 * - 주소 규칙(||host/path^, 와일드카드, $third-party, $domain=, @@ 예외 ...): [NetFilter] 엔진이 처리
 * - 화면 광고 영역 숨김(CSS) 규칙
 */
class AdBlocker(private val context: Context) {

    /** 내려받은 차단 도메인 (내장 목록은 BUILTIN 에 따로 있다) */
    @Volatile
    private var hosts: Set<String> = emptySet()

    /** 내려받은 일반 광고 영역 숨김 선택자 (EasyList 의 전체 적용 규칙) */
    @Volatile
    private var cssRules: String = ""

    /** 사이트별 광고 영역 숨김 선택자: 도메인 -> 선택자 목록 (예: 어떤 커뮤니티 사이트의 배너 영역) */
    @Volatile
    private var siteRules: Map<String, List<String>> = emptyMap()

    /** 주소 규칙 엔진 (EasyList 문법의 네트워크 필터 전부) */
    private val net = NetFilter()

    // 차단 목록 현황 (설정의 '광고 차단 현황'에서 보여 준다)
    /** 주소 규칙 엔진에 올라간 규칙 수 (차단 + 예외) */
    val pathRuleCount: Int get() = net.size
    @Volatile var genericCssCount: Int = 0
        private set
    @Volatile var siteCssCount: Int = 0
        private set
    val hostRuleCount: Int get() = hosts.size + BUILTIN.size

    /** 이번에 앱을 켠 뒤 막은 전체 건수 */
    val blockedCount = AtomicInteger(0)

    // ───────────── 차단 통계 ─────────────
    private val statsPrefs = context.getSharedPreferences("adblock_stats", Context.MODE_PRIVATE)
    private val lifetime = AtomicLong(statsPrefs.getLong("total", 0L))
    private val todayCount = AtomicInteger(0)
    @Volatile private var todayKey: Long = -1L
    private val sinceFlush = AtomicInteger(0)

    /** 이번 실행 중 종류별 건수 */
    val requestCount = AtomicInteger(0)
    val popupCount = AtomicInteger(0)

    /** 통계를 모으기 시작한 시각 */
    @Volatile var statsSince: Long = statsPrefs.getLong("since", 0L).takeIf { it > 0 } ?: System.currentTimeMillis()
        private set

    /** 이번 실행 중 많이 막은 사이트 (키: 사이트 단위 도메인) */
    private val hostStats = java.util.concurrent.ConcurrentHashMap<String, AtomicInteger>()

    init {
        val key = dayKey()
        todayKey = key
        if (statsPrefs.getLong("day", -1L) == key) todayCount.set(statsPrefs.getInt("today", 0))
        if (!statsPrefs.contains("since")) statsPrefs.edit().putLong("since", statsSince).apply()
    }

    class Stats(
        val total: Long,
        val today: Int,
        val session: Int,
        val requests: Int,
        val popups: Int,
        val since: Long,
        val top: List<Pair<String, Int>>
    )

    private fun dayKey(): Long {
        val now = System.currentTimeMillis()
        return (now + java.util.TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    /**
     * 광고를 한 건 막았을 때 부른다 (백그라운드 스레드에서도 불림).
     * @param host 막은 요청의 호스트 (사이트별 통계용)
     * @param kind [KIND_REQUEST] 광고·추적 요청 / [KIND_POPUP] 팝업·광고 페이지 이동
     */
    fun record(host: String?, kind: Int = KIND_REQUEST) {
        SecurityStats.add(if (kind == KIND_POPUP) SecurityStats.POPUP else SecurityStats.AD)
        blockedCount.incrementAndGet()
        if (kind == KIND_POPUP) popupCount.incrementAndGet() else requestCount.incrementAndGet()
        lifetime.incrementAndGet()
        val key = dayKey()
        if (key != todayKey) {
            synchronized(this) {
                if (key != todayKey) {
                    todayKey = key
                    todayCount.set(0)
                }
            }
        }
        todayCount.incrementAndGet()
        if (!host.isNullOrEmpty()) {
            val site = registrable(host.lowercase())
            var c = hostStats[site]
            if (c == null) {
                val n = AtomicInteger()
                c = hostStats.putIfAbsent(site, n) ?: n
            }
            c.incrementAndGet()
            if (hostStats.size > 600) hostStats.entries.removeAll { it.value.get() <= 1 }
        }
        // 요청마다 저장하면 느리니, 일정 건수마다 / 앱을 나갈 때 저장한다
        if (sinceFlush.incrementAndGet() >= 40) flush()
    }

    /** 누적 통계를 저장한다 (앱을 나갈 때도 부른다) */
    fun flush() {
        sinceFlush.set(0)
        statsPrefs.edit()
            .putLong("total", lifetime.get())
            .putLong("day", todayKey)
            .putInt("today", todayCount.get())
            .apply()
    }

    fun stats(top: Int = 8): Stats = Stats(
        total = lifetime.get(),
        today = if (dayKey() == todayKey) todayCount.get() else 0,
        session = blockedCount.get(),
        requests = requestCount.get(),
        popups = popupCount.get(),
        since = statsSince,
        top = hostStats.entries.map { it.key to it.value.get() }.sortedByDescending { it.second }.take(top)
    )

    fun resetStats() {
        lifetime.set(0)
        todayCount.set(0)
        blockedCount.set(0)
        requestCount.set(0)
        popupCount.set(0)
        hostStats.clear()
        statsSince = System.currentTimeMillis()
        statsPrefs.edit().putLong("since", statsSince).apply()
        flush()
    }

    private val listFile: File get() = File(context.filesDir, "adblock_hosts.txt")
    private val cssFile: File get() = File(context.filesDir, "adblock_css.txt")
    private val siteFile: File get() = File(context.filesDir, "adblock_site_css.txt")
    private val rulesFile: File get() = File(context.filesDir, "adblock_rules.txt")
    private val userFile: File get() = File(context.filesDir, "adblock_user_rules.json")

    // ───────────── 사용자가 직접 고른 광고 ('광고 직접 선택') ─────────────

    /**
     * 직접 고른 광고 한 건.
     * @param host 적용할 사이트 (www 없는 주소; 하위 도메인에도 적용)
     * @param selector 화면에서 숨길 CSS 선택자
     * @param label 목록에서 알아보기 위한 짧은 이름 (예: "video · 광고 배너")
     * @param src 이미지/영상/프레임이면 그 주소(쿼리 제외): 이 주소의 요청도 함께 막는다. 없으면 빈 글자
     */
    class UserRule(val host: String, val selector: String, val label: String, val src: String, val time: Long)

    private val userLock = Any()
    @Volatile private var userList: List<UserRule> = emptyList()
    @Volatile private var userMap: Map<String, List<String>> = emptyMap()
    @Volatile private var userUrls: Set<String> = emptySet()

    val userRuleCount: Int get() = userList.size

    fun userRules(): List<UserRule> = userList

    private fun loadUserRules() {
        try {
            if (!userFile.exists()) return
            val arr = org.json.JSONArray(userFile.readText())
            val list = ArrayList<UserRule>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val sel = o.optString("sel")
                val host = o.optString("host")
                if (sel.isEmpty() || host.isEmpty()) continue
                list.add(UserRule(host, sel, o.optString("label"), o.optString("src"), o.optLong("time")))
            }
            applyUserRules(list)
        } catch (e: Exception) {
            // 읽지 못하면 직접 고른 규칙 없이 시작
        }
    }

    private fun applyUserRules(list: List<UserRule>) {
        userList = list
        val map = HashMap<String, MutableList<String>>()
        val urls = HashSet<String>()
        for (r in list) {
            map.getOrPut(r.host) { ArrayList(2) }.add(r.selector)
            if (r.src.isNotEmpty()) urls.add(r.src)
        }
        userMap = map
        userUrls = urls
        verdicts.clear()
    }

    private fun saveUserRules(list: List<UserRule>) {
        try {
            val arr = org.json.JSONArray()
            for (r in list) {
                arr.put(
                    org.json.JSONObject()
                        .put("host", r.host).put("sel", r.selector).put("label", r.label)
                        .put("src", r.src).put("time", r.time)
                )
            }
            userFile.writeText(arr.toString())
        } catch (e: Exception) {
            // 저장에 실패해도 이번 실행 중에는 계속 적용된다
        }
    }

    /**
     * 직접 고른 광고를 추가한다. 이미 같은 사이트·선택자가 있으면 그대로 둔다. (어느 스레드에서든 부를 수 있음)
     * @return 저장됐으면 true, 선택자가 이상해서 거절했으면 false
     */
    fun addUserRule(host: String?, selector: String?, label: String?, src: String?): Boolean {
        val h = host?.lowercase()?.trim()?.removePrefix("www.").orEmpty()
        val sel = selector?.trim().orEmpty()
        if (h.isEmpty() || sel.isEmpty() || sel.length > 400) return false
        // CSS 규칙 밖으로 빠져나가는 글자는 받지 않는다 (선택자 하나가 다른 규칙을 깨뜨리지 않게)
        if (sel.any { it == '{' || it == '}' || it == '\n' || it == '\r' }) return false
        if (sel == "html" || sel == "body" || sel == "*" || sel == "head") return false
        val cleanSrc = (src ?: "").let { if (it.startsWith("http://") || it.startsWith("https://")) stripQuery(it) else "" }
        synchronized(userLock) {
            if (userList.any { it.host == h && it.selector == sel }) return true
            val next = userList + UserRule(
                h, sel, (label ?: "").take(60).replace('\n', ' '), cleanSrc.take(500), System.currentTimeMillis()
            )
            applyUserRules(next)
            saveUserRules(next)
        }
        return true
    }

    fun removeUserRule(rule: UserRule) {
        synchronized(userLock) {
            val next = userList.filter { it !== rule && !(it.host == rule.host && it.selector == rule.selector) }
            applyUserRules(next)
            saveUserRules(next)
        }
    }

    fun clearUserRules() {
        synchronized(userLock) {
            applyUserRules(emptyList())
            saveUserRules(emptyList())
        }
    }

    /** 지금 사이트(와 그 상위 도메인)에 직접 고른 숨김 선택자 */
    fun userSelectors(host: String?): List<String> {
        val map = userMap
        if (host.isNullOrEmpty() || map.isEmpty()) return emptyList()
        var h = host.lowercase().removePrefix("www.")
        val out = ArrayList<String>()
        while (true) {
            map[h]?.let { out.addAll(it) }
            val dot = h.indexOf('.')
            if (dot < 0) break
            h = h.substring(dot + 1)
            if (!h.contains('.')) break
        }
        return out
    }

    private fun userCss(host: String?): String = buildCss(userSelectors(host))

    /**
     * 마지막으로 목록을 성공적으로 받은 시각 (파일 수정 시각).
     * 주소 경로 규칙 파일이 아직 없는 예전 설치는 0 으로 보아서, 다음 실행 때 새 목록을 한 번 받게 한다.
     */
    val lastUpdated: Long
        get() = if (listFile.exists() && siteFile.exists() && rulesFile.exists()) listFile.lastModified() else 0L

    /** load() 와 update() 가 동시에 목록을 바꾸지 못하게 한다 */
    private val listLock = Any()

    fun load() = synchronized(listLock) {
        try {
            // 파일을 줄 단위로 흘려 읽는다 (readLines().map().filter() 는 수십 만 줄짜리 목록을 세 벌씩 메모리에 올려 GC 가 잦았다)
            if (listFile.exists()) hosts = readHostSet(listFile)
            if (cssFile.exists()) {
                val lines = cssFile.readLines()
                cssRules = buildCss(lines)
                genericCssCount = lines.count { it.isNotBlank() }
            }
            if (siteFile.exists()) siteRules = siteFile.useLines(Charsets.UTF_8) { parseSiteLines(it.asIterable()) }
            if (rulesFile.exists()) rulesFile.useLines(Charsets.UTF_8) { net.load(it.asIterable()) }
        } catch (e: Exception) {
            // 내장 목록만 사용
        }
        loadUserRules()
        verdicts.clear()
    }

    private fun readHostSet(f: File): Set<String> {
        // 한 줄이 평균 18바이트쯤이라고 보고 처음부터 넉넉히 잡아 해시 표를 여러 번 키우지 않게 한다
        val cap = (f.length() / 18 * 4 / 3 + 16).toInt().coerceIn(16, 1_000_000)
        val set = HashSet<String>(cap)
        f.useLines(Charsets.UTF_8) { lines ->
            for (raw in lines) {
                val h = raw.trim().lowercase()
                if (h.isNotEmpty()) set.add(h)
            }
        }
        return set
    }

    /** 임시 파일에 줄 단위로 쓴 뒤 바꿔 끼운다 (거대한 문자열을 만들지 않고, 쓰다 꺼져도 반쪽짜리 목록이 남지 않는다) */
    private fun writeLines(dest: File, lines: Iterable<String>) {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.bufferedWriter(Charsets.UTF_8).use { w ->
            var first = true
            for (l in lines) {
                if (!first) w.write("\n")
                w.write(l)
                first = false
            }
        }
        if (!tmp.renameTo(dest)) {
            tmp.copyTo(dest, overwrite = true)
            tmp.delete()
        }
    }

    /** 가장 단순한 형태: 호스트만 보고 차단할지 */
    fun isBlocked(host: String?): Boolean = shouldBlock(host, null, null)

    /**
     * 하위 요청 한 건을 막아야 하는지.
     * 1) 내장 목록 / 내려받은 목록의 도메인 (서브도메인 포함)
     * 2) 다른 사이트에서 오는 요청 중 ads.xxx / adserver.xxx 같은 광고용 호스트 이름
     * 3) 광고 스크립트로 잘 알려진 주소 패턴
     */
    /**
     * 이미 "허용" 으로 판정해 둔 호스트인지 (목록을 뒤지지 않고 기억해 둔 결과만 본다).
     * 영상 조각처럼 같은 호스트로 쉴 새 없이 오는 요청이 주소 분석(요청 종류 추정)을 거치지 않고 바로 지나가게 하려는 용도.
     * 아직 판정한 적이 없거나 직접 고른 차단 주소가 있으면 false 라서, 평소 검사 경로를 그대로 탄다.
     */
    fun quickAllow(host: String?, pageHost: String?): Boolean {
        if (host.isNullOrEmpty() || userUrls.isNotEmpty()) return false
        val key = if (pageHost == null) host else "$host|$pageHost"
        return verdicts[key] == V_ALLOW
    }

    fun shouldBlock(host: String?, pageHost: String?, url: String?, type: Int = NetFilter.T_ANY): Boolean {
        if (host.isNullOrEmpty()) return false
        // 사용자가 '광고 직접 선택' 으로 고른 이미지·영상·프레임 주소는 목록과 상관없이 막는다
        val ub = userUrls
        if (ub.isNotEmpty() && url != null && ub.contains(stripQuery(url))) return true
        // 같은 (요청 호스트, 페이지 호스트) 조합은 매번 목록을 뒤지지 않고 기억해 둔 결과를 쓴다.
        // 페이지 하나가 하위 요청을 수십~수백 건 보내므로 로딩 속도에 직접 영향이 있다.
        val key = if (pageHost == null) host else "$host|$pageHost"
        var v = verdicts[key]
        if (v == null) {
            v = hostVerdict(host.lowercase(), pageHost)
            if (verdicts.size > 6000) verdicts.clear()
            verdicts[key] = v
        }
        if (v == V_ALLOW) return false
        val h = host.lowercase()
        val ph = pageHost?.lowercase()
        if (v == 0) {
            // 같은 사이트에서 직접 내려주는 배너 이미지/플래시: 예전에는 통째로 통과시켰지만,
            // 광고 배너는 사이트 자체 주소(/banners/ 등)로도 흔히 나오므로 이미지·플래시 요청만 따로 검사한다.
            if (url == null) return false
            if (!(url.startsWith("http://") || url.startsWith("https://"))) return false
            return firstPartyAsset(url, h, ph, type)
        }
        if (v and V_FORCE != 0) return true
        val listed = v and V_BLOCK != 0
        if (url == null) return listed
        val third = v and V_THIRD != 0
        val web = url.startsWith("http://") || url.startsWith("https://")
        if (listed) {
            // 목록에 오른 도메인이라도 uBlock 'unbreak' 같은 예외 규칙이 풀어 주면 통과시킨다
            return !(web && net.isException(url, h, ph, third, type))
        }
        if (third) {
            for (p in AD_PATHS) if (url.contains(p, ignoreCase = true)) return true
        }
        if (web && isFlashUrl(url)) return true
        if (web && isBannerAsset(url, type)) return true
        return web && net.shouldBlock(url, h, ph, third, type)
    }

    /** 주소 모양이 배너 광고(이미지·플래시·영상)인지. 영상 배너(mp4/webm 등)도 여기서 잡는다 */
    private fun isBannerAsset(url: String, type: Int): Boolean {
        val path = pathOf(url)
        if ((type and (NetFilter.T_IMAGE or NetFilter.T_OBJECT)) != 0 && BANNER_PATH.containsMatchIn(path)) return true
        if ((type and NetFilter.T_MEDIA) != 0 && BANNER_VIDEO_PATH.containsMatchIn(path)) return true
        return false
    }

    private fun stripQuery(url: String): String {
        val q = url.indexOfAny(charArrayOf('?', '#'))
        return if (q >= 0) url.substring(0, q) else url
    }

    /** 이 주소가 광고 영상 배너인지 (페이지 스크립트가 <video> 를 검사할 때). 호스트 규칙과 영상 배너 주소 모양을 모두 본다 */
    fun isAdVideoUrl(url: String?, pageHost: String?): Boolean {
        if (url.isNullOrEmpty() || !(url.startsWith("http://") || url.startsWith("https://"))) return false
        val host = runCatching { android.net.Uri.parse(url).host }.getOrNull() ?: return false
        return shouldBlock(host, pageHost, url, NetFilter.T_MEDIA)
    }

    /** 요청 주소에서 ?·# 앞의 경로만 소문자로 */
    private fun pathOf(url: String): String {
        val q = url.indexOfAny(charArrayOf('?', '#'))
        return (if (q >= 0) url.substring(0, q) else url).lowercase()
    }

    /** 플래시(.swf) 파일인지: 플래시는 더 이상 쓰이지 않고 광고 배너에만 남아 있다 */
    private fun isFlashUrl(url: String): Boolean = pathOf(url).endsWith(".swf")

    /** 호스트가 같은 사이트의 요청 중 배너 광고로 보이는 이미지·플래시 */
    private fun firstPartyAsset(url: String, h: String, ph: String?, type: Int): Boolean {
        if (isFlashUrl(url)) return true
        if ((type and (NetFilter.T_IMAGE or NetFilter.T_OBJECT or NetFilter.T_MEDIA)) == 0) return false
        if (isBannerAsset(url, type)) return true
        return net.shouldBlock(url, h, ph, false, type)
    }

    /**
     * 호스트만 보고 내린 판단 캐시.
     * [V_FORCE] = 내장 목록: 예외 없이 차단, [V_BLOCK] = 내려받은 도메인 목록에 있음(예외 규칙이 풀어 줄 수 있음),
     * 0 = 통과, [V_THIRD] = 페이지와 다른 사이트의 요청
     */
    private val verdicts = java.util.concurrent.ConcurrentHashMap<String, Int>()

    private fun hostVerdict(h: String, pageHost: String?): Int {
        if (matches(h, BUILTIN)) return V_FORCE
        if (matches(h, ALLOW)) return V_ALLOW
        val thirdParty = pageHost == null || registrable(h) != registrable(pageHost.lowercase())
        val third = if (thirdParty) V_THIRD else 0
        if (matches(h, hosts)) return V_BLOCK or third
        if (thirdParty) {
            val first = h.substringBefore('.')
            if (first in AD_LABELS && h.count { it == '.' } >= 2) return V_BLOCK or third
        }
        return third
    }

    /** 목록에 올라 있는 광고 서버인지 (이름 모양만 보고 짐작하는 규칙은 제외: 페이지 이동을 막을 때 쓰므로 엄격하게) */
    fun isAdHost(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        val h = host.lowercase()
        if (matches(h, BUILTIN)) return true
        if (matches(h, ALLOW)) return false
        return matches(h, hosts)
    }

    /** 이 주소가 광고인지 (페이지 안 스크립트가 팝업/링크를 열려 할 때 확인용) */
    fun isAdUrl(url: String?): Boolean {
        if (url.isNullOrEmpty()) return false
        val host = runCatching { android.net.Uri.parse(url).host }.getOrNull() ?: return false
        return isAdHost(host) || shouldBlock(host, null, url)
    }

    private fun matches(host: String, set: Set<String>): Boolean {
        if (set.isEmpty()) return false
        var h = host
        while (true) {
            if (set.contains(h)) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
            if (!h.contains('.')) return false // TLD 단독은 검사하지 않음
        }
    }

    private fun registrable(host: String): String {
        val parts = host.split('.')
        if (parts.size <= 2) return host
        val last2 = parts.takeLast(2).joinToString(".")
        return if (last2 in SECOND_LEVEL) parts.takeLast(3).joinToString(".") else last2
    }

    /** 첫 화면 프레임에서 쓰는 추가 숨김 CSS (규칙마다 따로: 잘못된 선택자 하나가 전체를 무효로 만들지 않게) */
    fun topCss(host: String? = null): String = cssRules + siteCss(host) + userCss(host)

    /** 지금 보는 사이트(와 그 상위 도메인)에만 해당하는 광고 영역 숨김 CSS */
    private fun siteCss(host: String?): String {
        val rules = siteRules
        if (host.isNullOrEmpty() || rules.isEmpty()) return ""
        var h = host.lowercase().removePrefix("www.")
        val sb = StringBuilder()
        while (true) {
            rules[h]?.let { sb.append(buildCss(it)) }
            val dot = h.indexOf('.')
            if (dot < 0) break
            h = h.substring(dot + 1)
            if (!h.contains('.')) break
        }
        return sb.toString()
    }

    /** 저장 파일 한 줄 = "도메인,도메인<TAB>선택자" */
    private fun parseSiteLines(lines: Iterable<String>): Map<String, List<String>> {
        val map = HashMap<String, MutableList<String>>()
        for (line in lines) {
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            val sel = line.substring(tab + 1)
            for (d in line.substring(0, tab).split(',')) map.getOrPut(d) { ArrayList(2) }.add(sel)
        }
        siteCssCount = map.values.sumOf { it.size }
        return map
    }

    private fun buildCss(selectors: List<String>): String =
        selectors.asSequence().map { it.trim() }.filter { it.isNotEmpty() }
            .joinToString("") { "$it{display:none!important}" }

    /**
     * 네트워크 작업이므로 반드시 백그라운드 스레드에서 호출. 적용된 도메인 수를 반환.
     * 같은 목록은 한 번만, 여러 개를 동시에 내려받아 임시 파일에 두고 한 줄씩 읽어 처리한다
     * (한꺼번에 메모리에 올리지 않는다). 일부만 실패해도 받은 것은 적용하고, 도메인 목록을 전부 못 받으면 예외를 던진다.
     */
    fun update(): Int {
        val urls = LinkedHashSet<String>().apply {
            addAll(HOST_SOURCES)
            addAll(COSMETIC_SOURCES)
            addAll(NET_SOURCES)
        }.toList()
        val files = HashMap<String, File>()
        var lastError: Exception? = null
        val pool = java.util.concurrent.Executors.newFixedThreadPool(minOf(4, urls.size))
        try {
            val futures = urls.mapIndexed { i, u ->
                u to pool.submit(java.util.concurrent.Callable<File?> {
                    val f = File(context.cacheDir, "adlist_$i.tmp")
                    try {
                        downloadTo(u, f)
                        f
                    } catch (e: Exception) {
                        f.delete()
                        throw e
                    }
                })
            }
            for ((u, fut) in futures) {
                try {
                    fut.get()?.let { files[u] = it }
                } catch (e: Exception) {
                    lastError = (e.cause as? Exception) ?: e
                }
            }
        } finally {
            pool.shutdown()
        }

        try {
          synchronized(listLock) {
            val merged = HashSet<String>()
            var ok = 0
            for (src in HOST_SOURCES) {
                val f = files[src] ?: continue
                var n = 0
                f.useLines(Charsets.UTF_8) { lines ->
                    for (raw in lines) {
                        val h = parseHostLine(raw) ?: continue
                        merged.add(h)
                        if (++n >= 250_000) break
                    }
                }
                ok++
            }
            // EasyList 류의 "||도메인^" 규칙도 도메인 목록에 합친다
            for (src in NET_SOURCES) {
                if (src in HOST_SOURCES) continue
                val f = files[src] ?: continue
                try {
                    f.useLines(Charsets.UTF_8) { lines ->
                        for (raw in lines) {
                            val r = NetFilter.parse(raw) ?: continue
                            if (!r.exception && r.isPureHost && HOST_REGEX.matches(r.host)) merged.add(r.host)
                        }
                    }
                } catch (e: Exception) {
                    // 이 목록만 건너뜀
                }
            }
            if (ok == 0 || merged.isEmpty()) throw (lastError ?: IOException("빈 목록"))
            writeLines(listFile, merged)
            hosts = merged
            verdicts.clear()

            // 광고 영역 숨김 규칙 (실패해도 도메인 차단에는 영향 없음)
            val generic = LinkedHashSet<String>()
            val site = LinkedHashSet<String>()
            var cosmeticOk = 0
            for (src in COSMETIC_SOURCES) {
                val f = files[src] ?: continue
                try {
                    f.useLines(Charsets.UTF_8) { lines ->
                        for (raw in lines) {
                            val rule = parseCosmetic(raw) ?: continue
                            if (rule.first == null) {
                                if (generic.size < 8000) generic.add(rule.second)
                            } else if (site.size < 80_000) {
                                site.add(rule.first!!.joinToString(",") + "\t" + rule.second)
                            }
                        }
                    }
                    cosmeticOk++
                } catch (e: Exception) {
                    // 이 목록만 건너뜀
                }
            }
            if (generic.isNotEmpty()) {
                writeLines(cssFile, generic)
                cssRules = buildCss(generic.toList())
                genericCssCount = generic.size
            }
            // 하나도 못 받았으면 예전 규칙을 지우지 않는다. 비어 있어도 파일은 남겨서(목록을 받아 본 표시) 매번 다시 받지 않게 한다
            if (cosmeticOk > 0 || !siteFile.exists()) {
                writeLines(siteFile, site)
                siteRules = parseSiteLines(site)
            }

            // 주소 규칙: 오픈소스 목록의 네트워크 필터를 걸러서 저장하고 엔진에 올린다
            val rules = LinkedHashSet<String>()
            var netOk = 0
            for (src in NET_SOURCES) {
                val f = files[src] ?: continue
                try {
                    f.useLines(Charsets.UTF_8) { lines ->
                        for (raw in lines) {
                            if (rules.size >= MAX_NET_RULES) break
                            val r = NetFilter.parse(raw) ?: continue
                            // 도메인만 막는 단순 규칙은 위의 도메인 목록이 빠르게 처리한다 (예외 규칙은 엔진에 둔다)
                            if (!r.exception && r.isPureHost) continue
                            rules.add(raw.trim())
                        }
                    }
                    netOk++
                } catch (e: Exception) {
                    // 이 목록만 건너뜀
                }
            }
            if (netOk > 0 || !rulesFile.exists()) {
                writeLines(rulesFile, rules)
                net.load(rules)
            }
            verdicts.clear()
            return hosts.size + BUILTIN.size
          }
        } finally {
            for (f in files.values) f.delete()
        }
    }

    private fun downloadTo(url: String, dest: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 12_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", "evergreen/1.1")
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            conn.inputStream.use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
        } finally {
            conn.disconnect()
        }
    }

    /** hosts 형식("0.0.0.0 example.com") / 한 줄에 도메인 하나 / 광고 필터의 "||example.com^" 모두 받는다. */
    private fun parseHostLine(raw: String): String? {
        var line = raw.trim().lowercase()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("!") || line.startsWith("[")) return null
        if (line.startsWith("@@")) return null
        // 광고 영역 숨김 규칙(예: "example.com##.ad")을 사이트 전체 차단으로 오해하지 않게
        if (line.contains("##") || line.contains("#@#") || line.contains("#?#") ||
            line.contains("#$#") || line.contains("#%#")
        ) return null
        if (line.startsWith("||")) {
            line = line.removePrefix("||")
            val end = line.indexOfFirst { it == '^' || it == '/' || it == '$' || it == '*' }
            if (end < 0) return null
            // 도메인 전체를 막는 규칙(예: ||ads.example.com^)만 사용. 경로가 있거나 옵션이 붙으면 건너뜀
            val rest = line.substring(end)
            if (!(rest == "^" || rest == "^\$third-party" || rest == "^\$important")) return null
            line = line.substring(0, end)
        } else {
            line = line.substringBefore('#').trim().substringAfterLast(' ').substringAfterLast('\t')
        }
        return if (HOST_REGEX.matches(line) && line != "localhost" && !line.endsWith(".local")) line else null
    }

    /**
     * 광고 영역 숨김 규칙 한 줄을 읽는다. 결과: (적용할 사이트들 또는 null=모든 사이트, 선택자).
     * "##.ad-banner" 는 모든 사이트, "a.com,b.com##.ad" 는 그 사이트에서만. 제외(~) 조건이나 확장 문법은 버린다.
     */
    private fun parseCosmetic(raw: String): Pair<List<String>?, String>? {
        val idx = raw.indexOf("##")
        if (idx < 0) return null
        val sel = cleanSelector(raw.substring(idx + 2)) ?: return null
        val domPart = raw.substring(0, idx).trim()
        if (domPart.isEmpty()) return null to sel
        val doms = domPart.lowercase().split(',').map { it.trim().removePrefix("www.") }
        if (doms.any { it.startsWith("~") || !HOST_REGEX.matches(it) }) return null
        return doms to sel
    }

    private fun cleanSelector(raw: String): String? {
        val sel = raw.trim()
        if (sel.isEmpty() || sel.length > 160) return null
        // 확장 문법(:has-text, :-abp-*, :contains, :xpath, :matches-css, +js ...)은 브라우저 CSS 로 쓸 수 없다
        if (sel.contains(":-abp") || sel.contains(":has-text") || sel.contains(":contains") ||
            sel.contains(":xpath") || sel.contains(":matches") || sel.contains(":upward") ||
            sel.contains(":style") || sel.contains(":remove") || sel.contains("-ext-") ||
            sel.contains("+js(") || sel.contains(":nth-ancestor") || sel.contains(":watch-attr") ||
            sel.contains("'") || sel.contains("{") || sel.contains("}") || sel.contains("\\")
        ) return null
        return sel
    }

    companion object {
        /** [record] 의 종류 */
        const val KIND_REQUEST = 0
        const val KIND_POPUP = 1

        private const val V_BLOCK = 1
        private const val V_THIRD = 2
        private const val V_FORCE = 8
        private const val V_ALLOW = 16

        /**
         * 광고 배너 이미지 주소 모양 (경로만 본다): /banners/ 같은 폴더, adbanner 같은 파일 이름,
         * 468x60 · 728x90 · 300x250 같은 표준 광고 크기.
         */
        private val BANNER_PATH = Regex(
            "/(banners|adbanner|adbanners|ad-banner|ad_banner|banner-ad|banner_ad|bannerad|bannerads|ads|advert|adverts|advertising|advertisement|advertisements)/" +
                "|[-_./](adbanner|ad-banner|ad_banner|banner-ad|banner_ad|bannerad)[-_.0-9a-z]*\\.(gif|png|jpe?g|webp)$" +
                "|[-_/.](468x60|728x90|300x250|336x280|160x600|120x600|300x600|320x50|320x100|970x90|970x250|234x60|120x90|125x125)\\.(gif|png|jpe?g|webp|swf)$"
        )

        /**
         * 광고 영상 배너 주소 모양 (경로만 본다): /banners/ 같은 폴더, ad_01.mp4 · adbanner.webm 같은 파일 이름,
         * 728x90 · 300x250 같은 표준 광고 크기. 'adventure.mp4' 처럼 ad 로 시작하는 일반 이름은 걸리지 않게 단어 경계를 본다.
         * (그냥 'banner' 라는 이름은 사이트 자체 홍보 영상일 수 있어 여기서는 막지 않고, 화면 쪽 영상 배너 감지가 맥락을 보고 판단한다.)
         */
        private val BANNER_VIDEO_PATH = Regex(
            "/(banners|adbanners?|ad-banners?|ad_banners?|banner-ads?|banner_ads?|bannerads?|ads|adv|advert|adverts|advertising|advertisement|advertisements|sponsored)/.*" +
                "\\.(mp4|webm|m4v|mov|ogv|m3u8|mpd|flv|f4v|3gp)$" +
                "|[-_./](ads?|adv|adbanner|ad-banner|ad_banner|banner-ad|banner_ad|bannerad|sponsored)([-_.0-9][-_.0-9a-z]*)?\\.(mp4|webm|m4v|mov|ogv|m3u8|mpd|flv|f4v|3gp)$" +
                "|[-_/.](468x60|728x90|300x250|336x280|160x600|120x600|300x600|320x50|320x100|970x90|970x250|234x60|120x90|125x125)\\.(mp4|webm|m4v|mov|ogv|m3u8|flv)$"
        )

        /** 주소 규칙 엔진에 올리는 규칙 수 상한 (메모리) */
        private const val MAX_NET_RULES = 160_000

        /** 내려받는 차단 목록들 (모두 공개 목록) */
        private val HOST_SOURCES = listOf(
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext",
            "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
            "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/domains/light.txt",
            "https://cdn.jsdelivr.net/gh/List-KR/List-KR@latest/filter-AdGuard.txt",
            "https://filters.adtidy.org/extension/ublock/filters/11.txt"
        )
        /** 광고 영역 숨김 규칙을 뽑는 목록 (한국 사이트용 List-KR 포함). 받지 못한 목록은 건너뛴다. */
        private val COSMETIC_SOURCES = listOf(
            "https://easylist.to/easylist/easylist.txt",
            "https://cdn.jsdelivr.net/gh/List-KR/List-KR@latest/filter-AdGuard.txt",
            "https://cdn.jsdelivr.net/gh/List-KR/List-KR@latest/filter.txt",
            "https://filters.adtidy.org/extension/ublock/filters/11.txt",
            "https://filters.adtidy.org/extension/ublock/filters/2.txt",
            "https://ublockorigin.github.io/uAssets/filters/filters.min.txt"
        )

        /**
         * 주소 규칙(NetFilter 엔진)으로 읽는 오픈소스 목록.
         * EasyList(광고) · EasyPrivacy(추적) · uBlock Origin(광고/개인정보/악성/오작동 예외) ·
         * AdGuard 기본/모바일 · List-KR(한국 사이트). 받지 못한 목록은 건너뛴다.
         */
        private val NET_SOURCES = listOf(
            // 규칙 수 상한에 걸려도 예외(오작동 방지)와 한국 사이트 규칙이 먼저 들어가도록 앞에 둔다
            "https://ublockorigin.github.io/uAssets/filters/unbreak.min.txt",
            "https://cdn.jsdelivr.net/gh/List-KR/List-KR@latest/filter-AdGuard.txt",
            "https://cdn.jsdelivr.net/gh/List-KR/List-KR@latest/filter.txt",
            "https://easylist.to/easylist/easylist.txt",
            "https://ublockorigin.github.io/uAssets/filters/filters.min.txt",
            "https://filters.adtidy.org/extension/ublock/filters/11.txt",
            "https://easylist.to/easylist/easyprivacy.txt",
            "https://ublockorigin.github.io/uAssets/filters/badware.min.txt",
            "https://ublockorigin.github.io/uAssets/filters/privacy.min.txt",
            "https://filters.adtidy.org/extension/ublock/filters/2.txt"
        )

        private val SECOND_LEVEL = setOf(
            "co.kr", "or.kr", "go.kr", "ne.kr", "ac.kr", "co.uk", "org.uk", "co.jp", "com.au", "com.cn", "com.br",
            "com.tw", "org.tw", "com.hk", "com.sg", "com.my", "com.ph", "com.vn", "co.id", "co.th", "co.in",
            "co.nz", "co.za", "com.tr", "com.mx", "com.ar", "com.ua"
        )

        /** 내려받은 목록이 잘못 막을 수 있는, 사이트가 동작하는 데 꼭 필요한 도메인 (내장 목록은 우선 적용) */
        private val ALLOW: Set<String> = setOf(
            "googlevideo.com", "youtube.com", "ytimg.com", "ggpht.com", "gstatic.com", "googleusercontent.com",
            "google.com", "googleapis.com", "apple.com", "icloud.com", "microsoft.com", "live.com",
            "microsoftonline.com", "kakao.com", "daum.net", "naver.com", "pstatic.net", "naver.net",
            "coupang.com", "github.com", "githubusercontent.com", "cloudflare.com", "recaptcha.net",
            "hcaptcha.com", "stripe.com", "paypal.com", "tosspayments.com"
        )

        /** 첫 번째 라벨이 이렇게 시작하는 다른 사이트 호스트는 광고용으로 본다 (예: ads.example.net) */
        private val AD_LABELS = setOf(
            "ads", "ad", "adserver", "adservice", "adsystem", "adtech", "adx", "banners", "pagead",
            "advert", "adverts", "advertising", "adsrv", "adimg", "adclick", "adview"
        )

        /** 광고 스크립트에서 흔한 주소 조각 (다른 사이트에서 오는 요청에만 적용) */
        private val AD_PATHS = listOf(
            "/pagead/", "/gampad/ads", "/adsbygoogle", "/adserver/", "/adserving/", "/ad-server/",
            "/adframe.", "/popunder", "/pop-under", "/clickunder", "/ads/ad.", "/banner_ad", "/ad_banner",
            "/show_ads", "/pagead2", "/prebid", "/tveta/", "/adfit/", "/adsbygoogle.js", "/ads/show.",
            "/popads", "/pop.js", "/clickunder.", "/adsbox.", "/banners/ad"
        )

        private val HOST_REGEX =
            Regex("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")

        /** 화면에서 광고 영역을 숨기는 CSS 선택자 (네트워크 차단을 빠져나간 요소용) */
        private val COSMETIC_SELECTORS = listOf(
            "ins.adsbygoogle",
            ".adsbygoogle",
            ".google-auto-placed",
            "iframe[src*=\"doubleclick.net\"]",
            "iframe[src*=\"googlesyndication.com\"]",
            "iframe[src*=\"adnxs.com\"]",
            "iframe[id^=\"google_ads_iframe\"]",
            "div[id^=\"div-gpt-ad\"]",
            "div[id^=\"google_ads\"]",
            "[data-ad-slot]",
            "[data-google-query-id]",
            "div[class*=\"adsbox\"]",
            "div[id*=\"taboola\"]",
            "div[class*=\"taboola\"]",
            "div[id*=\"outbrain\"]",
            ".OUTBRAIN",
            "[id^=\"aswift_\"]",
            "[id^=\"google_image_div\"]",
            "iframe[src*=\"googleadservices.com\"]",
            "iframe[src*=\"adservice\"]",
            "iframe[src*=\"/pagead/\"]",
            "a[href*=\"doubleclick.net/\"]",
            "a[href*=\"googleadservices.com\"]",
            ".ad-banner", ".ad_banner", ".banner-ad", ".banner_ad", ".adbox", ".ad-box",
            ".ad-container", ".ad-wrapper", ".ad-slot", ".ad-unit", ".adunit",
            ".advertisement", ".advertisment", ".sponsored-ad",
            "#ad-banner", "#ad_banner", "#adBanner", "#banner-ad", "#ad-container",
            "#ad-wrapper", "#adContainer", "#google_ads_frame", "#top-ad", "#bottom-ad", "#sidebar-ad",
            "img[src*=\"/banners/\"]", "img[src*=\"/adbanner\"]", "img[src*=\"/ad-banner\"]", "img[src*=\"/ad_banner\"]",
            "img[src*=\"/banner-ad\"]", "img[src*=\"/banner_ad\"]", "img[src*=\"/ads/\"]", "img[src*=\"/advertisement\"]",
            "img[src*=\"468x60.\"]", "img[src*=\"728x90.\"]", "img[src*=\"300x250.\"]", "img[src*=\"336x280.\"]",
            "img[src*=\"160x600.\"]", "img[src*=\"320x50.\"]", "img[src*=\"970x90.\"]", "img[src*=\"970x250.\"]",
            "video[src*=\"/banners/\"]", "video[src*=\"/adbanner\"]", "video[src*=\"/ad-banner\"]", "video[src*=\"/ad_banner\"]",
            "video[src*=\"/banner-ad\"]", "video[src*=\"/banner_ad\"]", "video[src*=\"/ads/\"]", "video[src*=\"/advertisement\"]",
            "video[src*=\"728x90.\"]", "video[src*=\"300x250.\"]", "video[src*=\"320x50.\"]", "video[src*=\"320x100.\"]",
            "video[src*=\"970x250.\"]", "video[data-ad]", "video[data-ad-slot]", "video[id^=\"google_ads\"]",
            "[class*=\"video-banner-ad\"]", "[class*=\"ad-video\"]", "[class*=\"video-ad-\"]", "[class*=\"adv-video\"]",
            "object[type*=\"flash\"]", "embed[type*=\"flash\"]", "object[data*=\".swf\"]", "embed[src*=\".swf\"]",
            "ins.kakao_ad_area", ".kakao_ad_area", "iframe[src*=\"adfit\"]", ".dable-widget"
        ).joinToString(",")

        /**
         * 문서 시작 시점(모든 프레임)에 실행: 광고 영역을 숨기고, 유튜브 영상 광고는 건너뛴다.
         * 앱 쪽 EvMedia.adblock() 이 꺼져 있으면 아무것도 하지 않는다.
         */
        val COSMETIC_START_JS: String = """
(function(){
 if(window.__evAd) return; window.__evAd=1;
 try{ if(!EvMedia.adblock()) return; }catch(e){ return; }
 // ── 팝업/클릭 가로채기 광고 차단 ──
 try{
  var _open=window.open;
  window.open=function(u){
   try{
    var abs=u?new URL(String(u),location.href).href:'';
    var act=navigator.userActivation?navigator.userActivation.isActive:true;
    if(!act||(abs&&EvMedia.adurl(abs))) return null;
   }catch(e){}
   return _open.apply(window,arguments);
  };
  document.addEventListener('click',function(e){
   try{
    var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;
    if(a&&EvMedia.adurl(a.href)){e.preventDefault();e.stopImmediatePropagation();}
   }catch(x){}
  },true);
 }catch(e){}
 // ── fetch / XHR / sendBeacon 으로 나가는 광고 요청은 진짜 광고 차단기처럼 '네트워크 오류'로 실패시킨다 ──
 // (앱이 빈 응답을 돌려주면 페이지에서는 요청이 성공한 것으로 보여, 차단 테스트가 '뚫림'으로 나온다)
 try{
  var memo=new Map();
  var isBlocked=function(u){
   try{
    var s=String(u&&u.url?u.url:u);
    var abs=new URL(s,location.href).href;
    if(abs.indexOf('http')!==0) return false;
    var v=memo.get(abs);
    if(v===undefined){
     v=!!EvMedia.adreq(abs,location.hostname);
     if(memo.size>600) memo.clear();
     memo.set(abs,v);
    }
    return v;
   }catch(e){ return false; }
  };
  var _fetch=window.fetch;
  if(_fetch){
   window.fetch=function(input,init){
    if(isBlocked(input)) return Promise.reject(new TypeError('Failed to fetch'));
    return _fetch.apply(this,arguments);
   };
  }
  var _xo=XMLHttpRequest.prototype.open, _xs=XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open=function(m,u){ try{ this.__evu=u; }catch(e){} return _xo.apply(this,arguments); };
  XMLHttpRequest.prototype.send=function(){
   if(this.__evu!==undefined&&isBlocked(this.__evu)){
    var x=this;
    setTimeout(function(){ try{ x.dispatchEvent(new ProgressEvent('error')); x.dispatchEvent(new ProgressEvent('loadend')); }catch(e){} },0);
    return;
   }
   return _xs.apply(this,arguments);
  };
  if(navigator.sendBeacon){
   var _sb=navigator.sendBeacon.bind(navigator);
   navigator.sendBeacon=function(u,d){ return isBlocked(u)?false:_sb(u,d); };
  }
 }catch(e){}
 // 화면 전체를 덮은 투명 클릭 가로채기 막(터치하는 순간 팝업을 여는 광고)을 터치 직전에 치운다
 if(window===window.top){
  var isOverlay=function(el){
   try{
    if(!el||el===document.body||el===document.documentElement) return false;
    // 파일 올리기 칸(투명하게 화면을 덮는 <input type=file> 등)은 광고 막이 아니니 지우지 않는다
    // (파일 칸이 있는 페이지는 sweep 맨 앞에서 이미 걸러낸다)
    if(el.tagName==='INPUT'||el.tagName==='LABEL') return false;
    var cs=getComputedStyle(el), w=innerWidth, h=innerHeight;
    var fixed=cs.position==='fixed';
    var z=parseInt(cs.zIndex,10)||0;
    if(!fixed&&!(cs.position==='absolute'&&z>=1000&&(el.offsetParent===document.body||el.offsetParent===null))) return false;
    var r=el.getBoundingClientRect();
    if(r.width<w*0.6||r.height<h*0.6) return false;
    if(el.closest('video,[class*=player],[id*=player],[class*=modal],[class*=dialog],[role=dialog]')) return false;
    var bg=cs.backgroundColor;
    var transp=(bg==='rgba(0, 0, 0, 0)'||bg==='transparent')&&cs.backgroundImage==='none';
    var empty=!(el.innerText||'').trim()&&!el.querySelector('img,video,canvas,svg,input,button,audio');
    return parseFloat(cs.opacity)<0.05||(transp&&empty);
   }catch(e){return false}
  };
  // 터치할 때마다 도는 검사라, 칸마다 DOM 전체를 훑던 것을 한 번의 가벼운 검사로 바꿨다 (큰 페이지에서 터치당 ~6ms → ~0.3ms)
  var hasFileInput=function(){
   var l=document.getElementsByTagName('input');
   for(var i=0;i<l.length;i++){ if(l[i].type==='file') return true; }
   return false;
  };
  var sweep=function(x,y){
   try{
    // 파일 올리기 칸이 있는 페이지에서는 투명한 덮개(업로드 버튼·드롭 영역)를 광고 막으로 오해해 지우지 않는다
    if(hasFileInput()) return;
    var els=document.elementsFromPoint(x,y);
    for(var i=0;i<els.length;i++){ if(isOverlay(els[i])){ els[i].remove(); } }
   }catch(e){}
  };
  document.addEventListener('touchstart',function(e){
   var t=e.touches&&e.touches[0]; if(t) sweep(t.clientX,t.clientY);
  },{capture:true,passive:true});
  document.addEventListener('mousedown',function(e){ sweep(e.clientX,e.clientY); },true);
 }
 function addCss(t){var s=document.createElement('style');s.textContent=t;(document.head||document.documentElement).appendChild(s)}
 addCss(`__SEL__{display:none!important}`);
 if(window===window.top){ try{ var c=EvMedia.adcss(location.hostname); if(c) addCss(c); }catch(e){} }
 if(/(^|\.)youtube\.com${'$'}/.test(location.hostname)){
  addCss('ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-display-ad-renderer,ytd-promoted-video-renderer,ytd-banner-promo-renderer,ytd-companion-slot-renderer,ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,#masthead-ad,#player-ads,.ytd-ad-slot-renderer,.ytp-ad-overlay-container{display:none!important}');
  var byUs=false;
  setInterval(function(){
   var v=document.querySelector('video.html5-main-video')||document.querySelector('video');
   var shown=!!document.querySelector('.ad-showing,.ytp-ad-player-overlay,.ytp-ad-module .ytp-ad-text');
   var x=document.querySelector('.ytp-ad-overlay-close-button'); if(x) x.click();
   if(!v) return;
   if(shown&&isFinite(v.duration)&&v.duration>0){
    if(!byUs){byUs=true; v.__evMuted=v.muted;}
    v.muted=true; v.playbackRate=16;
    try{ v.currentTime=Math.max(0,v.duration-0.1); }catch(e){}
   }else if(byUs){
    byUs=false; v.playbackRate=1; v.muted=!!v.__evMuted;
   }
  },250);
 }
${AdScripts.VIDEO_BANNER_JS}
})();
""".replace("__SEL__", COSMETIC_SELECTORS)

        val COSMETIC_JS: String =
            "(function(){if(document.getElementById('__sb_adblock'))return;" +
                "var s=document.createElement('style');s.id='__sb_adblock';" +
                "s.textContent='" + COSMETIC_SELECTORS + "{display:none!important}';" +
                "(document.head||document.documentElement).appendChild(s);})();"

        val BUILTIN: Set<String> = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "google-analytics.com", "adservice.google.com", "2mdn.net", "admob.com",
            "adnxs.com", "adsrvr.org", "advertising.com", "amazon-adsystem.com",
            "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "rubiconproject.com", "pubmatic.com", "openx.net", "moatads.com",
            "scorecardresearch.com", "quantserve.com", "casalemedia.com", "adform.net",
            "smartadserver.com", "serving-sys.com", "yieldmo.com", "teads.tv",
            "popads.net", "propellerads.com", "exoclick.com", "juicyads.com",
            "trafficjunky.com", "popcash.net", "adsterra.com", "mgid.com",
            "revcontent.com", "zedo.com", "media.net", "bidswitch.net", "33across.com",
            "sharethrough.com", "indexww.com", "lijit.com", "sovrn.com",
            "contextweb.com", "yieldlab.net", "adcolony.com", "applovin.com",
            "mopub.com", "inmobi.com", "chartboost.com", "vungle.com", "hotjar.com",
            "adtechus.com", "adition.com", "richaudience.com", "triplelift.com",
            "gumgum.com", "smaato.net", "ads.yahoo.com",
            // 국내 광고 서버
            "adfit.kakao.com", "display.ad.daum.net", "veta.naver.com",
            "adcr.naver.com", "dable.io",
            // 추가 광고/팝업/트래커
            "adsafeprotected.com", "imrworldwide.com", "doubleverify.com", "flashtalking.com",
            "everesttech.net", "adroll.com", "adblade.com", "adbutler.com", "adcash.com",
            "admixer.net", "adskeeper.com", "lentainform.com", "a-ads.com", "admaven.com",
            "clickadu.com", "hilltopads.net", "onclickads.net", "tsyndicate.com", "trafficstars.com",
            "realsrv.com", "an.facebook.com", "static.ads-twitter.com", "ads.pinterest.com",
            "ads.tiktok.com", "ads.linkedin.com", "bidr.io", "cpmstar.com", "adskeeper.co.uk",
            "tpc.googlesyndication.com", "pagead2.googlesyndication.com", "ad.doubleclick.net",
            "securepubads.g.doubleclick.net", "partner.googleadservices.com", "adnxs-simple.com",
            "serverbid.com", "undertone.com", "spotxchange.com", "spotx.tv", "springserve.com",
            "stickyadstv.com", "tremorhub.com", "adotmob.com", "ayads.co", "popcash.net",
            "pushwoosh.com", "onesignal-ads.com", "adspyglass.com", "ad-maven.com", "mc.yandex.ru",
            "an.yandex.ru", "yandexadexchange.net", "adriver.ru", "begun.ru",
            // 팝업/푸시/리다이렉트 광고망
            "monetag.com", "clickadilla.com", "richpush.co", "evadav.com", "profitableratecpm.com",
            "effectivegatecpm.com", "highperformanceformat.com", "pemsrv.com", "onclickalgo.com",
            "onclkds.com", "popmyads.com", "bidvertiser.com", "exdynsrv.com", "magsrv.com",
            "mondiad.com", "dtscout.com", "ad-delivery.net", "go.oclasrv.com", "popunder.net",
            "adexchangeclear.com", "trafficfactory.biz", "tubecorporate.com", "adspyglass.com"
        )
    }
}
