package com.example.evergreen

import android.content.Context
import android.content.SharedPreferences
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * 보안 현황용 차단 기록: 종류별로 하루 단위 건수를 최근 7일치 모아 둔다.
 * 어느 스레드에서 불러도 안전하고, 일정 건수마다 / 앱을 나갈 때 저장한다.
 */
object SecurityStats {
    const val AD = 0          // 광고·추적 요청
    const val POPUP = 1       // 광고 팝업·광고 페이지 이동
    const val TRACKER = 2     // 트래커 (엄격 모드)
    const val HIJACK = 3      // 클릭 가로채기 이동
    const val AUTO_DL = 4     // 자동 다운로드
    const val BACK = 5        // 뒤로가기 중 자동 이동
    const val MALWARE = 6     // 악성 사이트
    const val HTTPS = 7       // http → https 로 올려 연결
    const val KINDS = 8

    private const val DAYS = 7

    private var sp: SharedPreferences? = null
    private val counts = ConcurrentHashMap<String, AtomicInteger>()
    private val pending = AtomicInteger(0)

    fun dayKey(): Long {
        val now = System.currentTimeMillis()
        return (now + java.util.TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    private fun key(day: Long, kind: Int) = "d${day}_$kind"

    @Synchronized
    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("security_stats", Context.MODE_PRIVATE)
        sp = p
        val oldest = dayKey() - (DAYS - 1)
        val ed = p.edit()
        for ((k, v) in p.all) {
            val day = k.removePrefix("d").substringBefore('_').toLongOrNull()
            if (day == null || day < oldest) { ed.remove(k); continue }
            (v as? Int)?.let { counts[k] = AtomicInteger(it) }
        }
        ed.apply()
    }

    fun add(kind: Int) {
        if (sp == null) return
        counts.getOrPut(key(dayKey(), kind)) { AtomicInteger(0) }.incrementAndGet()
        if (pending.incrementAndGet() >= 30) flush()
    }

    fun flush() {
        val p = sp ?: return
        pending.set(0)
        val oldest = dayKey() - (DAYS - 1)
        val ed = p.edit()
        for ((k, v) in counts) {
            val day = k.removePrefix("d").substringBefore('_').toLongOrNull() ?: continue
            if (day < oldest) { counts.remove(k); ed.remove(k) } else ed.putInt(k, v.get())
        }
        ed.apply()
    }

    fun count(day: Long, kind: Int): Int = counts[key(day, kind)]?.get() ?: 0

    fun dayTotal(day: Long): Int = (0 until KINDS).sumOf { count(day, it) }

    /** 오늘을 마지막으로 하는 최근 7일의 하루 합계 (오래된 날 → 오늘) */
    fun week(): IntArray {
        val today = dayKey()
        return IntArray(DAYS) { dayTotal(today - (DAYS - 1 - it)) }
    }

    fun today(kind: Int): Int = count(dayKey(), kind)

    fun todayTotal(): Int = dayTotal(dayKey())

    fun weekTotal(kind: Int): Int {
        val today = dayKey()
        return (0 until DAYS).sumOf { count(today - it, kind) }
    }

    fun reset() {
        counts.clear()
        pending.set(0)
        sp?.edit()?.clear()?.apply()
    }
}
