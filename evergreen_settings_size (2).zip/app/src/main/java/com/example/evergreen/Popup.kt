package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.annotation.DrawableRes

/**
 * 앱 전체가 함께 쓰는 팝업 (가운데에 뜨는 둥근 카드).
 * - menu(): 머리말 + 아이콘 달린 항목 목록
 * - confirm(): 제목 + 설명 + 취소/확인 버튼
 * 등장은 통통 튀는 확대, 항목은 위에서부터 차례로 떠오른다.
 */
object Popup {

    class Item(
        @DrawableRes val icon: Int,
        val label: String,
        val sub: String? = null,
        val danger: Boolean = false,
        /** 아이콘 대신 이 색의 동그라미를 보여준다 (탭 그룹 색 등) */
        val dotColor: Int? = null,
        val checked: Boolean = false,
        /** 설명(sub)을 한 줄로 줄여 보여준다 (주소처럼 긴 글자용) */
        val compactSub: Boolean = false,
        val action: () -> Unit
    )

    /**
     * AlertDialog 의 카드를 창 폭(테마의 고정 폭, 창이 더 좁으면 창 폭)에 꽉 차게 한다.
     * 기본 틀은 내용 폭만큼만 잡혀서, 분할 화면처럼 창 크기가 달라지면 내용이 카드 한쪽에 쏠려 보였다.
     * 폭을 픽셀로 정하지 않으므로 창 크기가 바뀌어도 어긋나지 않는다. show() 뒤에 부른다.
     */
    fun fillWidth(dialog: androidx.appcompat.app.AlertDialog) {
        val panel = dialog.findViewById<View>(androidx.appcompat.R.id.parentPanel) ?: return
        val lp = panel.layoutParams ?: return
        if (lp.width != ViewGroup.LayoutParams.MATCH_PARENT) {
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            panel.layoutParams = lp
        }
    }

    /** 위험(삭제 등) 색: 밝은/어두운 테마에 맞춰 resources 에서 가져온다 */
    private fun danger(ctx: Context) = androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_danger)

    /**
     * 대화상자 안의 글자 입력칸을 앱 공통 모양(연한 면 + 둥근 모서리)으로 만든다.
     * 기본 밑줄 입력칸 대신 쓰며, 포커스를 받으면 테두리가 강조색으로 바뀐다.
     */
    fun styleInput(et: android.widget.EditText) {
        val ctx = et.context
        val fill = com.google.android.material.color.MaterialColors.getColor(
            ctx, com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFFF0F2F5.toInt()
        )
        val accent = com.google.android.material.color.MaterialColors.getColor(
            ctx, androidx.appcompat.R.attr.colorPrimary, 0xFF1E8E3E.toInt()
        )
        fun shape(stroke: Int) = GradientDrawable().apply {
            cornerRadius = dp(ctx, 14).toFloat()
            setColor(fill)
            setStroke(if (stroke == 0) 0 else dp(ctx, 2), stroke)
        }
        et.background = android.graphics.drawable.StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(accent))
            addState(intArrayOf(), shape(0))
        }
        et.setPadding(dp(ctx, 16), dp(ctx, 13), dp(ctx, 16), dp(ctx, 13))
        et.textSize = 15f
    }


    /** 버튼 아래에 붙어 뜨는 카드 팝업의 공통 규격 (모서리 · 그림자) */
    const val ANCHORED_RADIUS_DP = 16
    const val ANCHORED_ELEVATION_DP = 10

    /**
     * 붙어 뜨는 팝업(PopupWindow)의 둥근 카드 배경을 만든다.
     * [content] 는 같은 모양으로 잘리고, 블러가 켜져 있으면 뒤가 비치는 반투명 색이 된다.
     */
    fun anchoredBackground(ctx: Context, content: View, radiusDp: Int = ANCHORED_RADIUS_DP): GradientDrawable {
        val radius = dp(ctx, radiusDp).toFloat()
        content.clipToOutline = true
        content.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, v.width, v.height, radius)
            }
        }
        return GradientDrawable().apply {
            cornerRadius = radius
            setColor(Blur.surface(ctx, com.google.android.material.R.attr.colorSurfaceContainer, Blur.supported(ctx)))
        }
    }

    /** 등장 시작 상태: 누른 버튼 가운데 아래에서 펼쳐질 준비. 팝업을 띄우기 전에 부른다. */
    fun prepareAnchoredEnter(content: View, pivotXPx: Float, widthPx: Int) {
        if (!Motion.enabled(content.context)) return
        content.pivotX = pivotXPx.coerceIn(0f, widthPx.toFloat())
        content.pivotY = 0f
        content.alpha = 0f
        content.scaleX = 0.92f
        content.scaleY = 0.86f
    }

    /** 등장 재생: 부드럽게 안착하는 스프링 + (목록이 있으면) 항목이 살짝 내려오며 차례로 나타난다. 팝업을 띄운 뒤에 부른다. */
    fun playAnchoredEnter(content: View, list: ViewGroup? = null) {
        val ctx = content.context
        if (!Motion.enabled(ctx)) return
        Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 480f, 1f)
        Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 420f, 1f)
        Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 800f, 1f)
        if (list == null) return
        for (i in 0 until list.childCount) {
            val row = list.getChildAt(i)
            row.alpha = 0f
            row.translationY = -dp(ctx, 4).toFloat()
            row.animate()
                .alpha(1f).translationY(0f)
                .setStartDelay(minOf(40L + i * 16L, 220L))
                .setDuration(180)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f))
                .start()
        }
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /**
     * 팝업이 기준으로 삼을 "보이는 창"의 크기. 분할 화면·작은 창에서는 기기 화면 전체가 아니라
     * 앱 창 크기를 써야 팝업이 창 밖으로 나가거나 어긋나지 않는다. 알 수 없으면 화면 크기.
     */
    private fun viewport(ctx: Context): Pair<Int, Int> {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) {
                val root = c.window?.decorView
                if (root != null && root.width > 0 && root.height > 0) return root.width to root.height
                break
            }
            c = c.baseContext
        }
        val dm = ctx.resources.displayMetrics
        return dm.widthPixels to dm.heightPixels
    }


    private fun create(
        ctx: Context,
        title: String,
        subtitle: String?,
        headerIcon: Int?,
        headerColor: Int?,
        widthDp: Int = 340,
        preview: Boolean = false
    ): Pair<Dialog, View> {
        val dialog = Dialog(ctx, R.style.Evergreen_Popup)
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null)

        view.findViewById<TextView>(R.id.popupTitle).text = title
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        val icon = view.findViewById<ImageView>(R.id.popupIcon)
        if (headerColor != null) {
            icon.setImageDrawable(null)
            icon.setPadding(0, 0, 0, 0)
            icon.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(headerColor)
            }
            icon.visibility = View.VISIBLE
        } else if (headerIcon != null) {
            icon.setImageResource(headerIcon)
            icon.visibility = View.VISIBLE
        }

        dialog.setContentView(view)
        // 팝업이 뜨면 화면 읽기가 제목을 먼저 읽어 준다
        androidx.core.view.ViewCompat.setAccessibilityPaneTitle(view, title)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.apply {
            val maxW = minOf(dp(ctx, widthDp), (viewport(ctx).first * 0.92f).toInt())
            setLayout(maxW, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }
        // 뒤 페이지를 흐리게 + 카드를 반투명 유리처럼 (Android 12+ 에서 지원될 때만)
        if (preview) {
            // 뒤 페이지가 실시간으로 바뀌는 걸 봐야 하는 팝업(확대/축소 등): 흐림 없이 살짝만 어둡게
            dialog.window?.setDimAmount(0.15f)
        } else if (Blur.behind(dialog.window, ctx)) {
            view.background = Blur.glass(ctx, com.google.android.material.R.attr.colorSurface, dp(ctx, 26).toFloat())
        }
        return dialog to view
    }

    fun menu(
        ctx: Context,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        headerColor: Int? = null,
        items: List<Item>
    ): Dialog {
        val (dialog, view) = create(ctx, title, subtitle, headerIcon, headerColor)
        val list = view.findViewById<LinearLayout>(R.id.popupList)

        fillRows(ctx, list, items) { dialog.dismiss() }
        capListHeight(ctx, view, list, 340)

        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        Motion.stagger(list, 70, 30, 260)
        return dialog
    }


    /** 내용이 화면보다 길면 스크롤 영역 높이를 제한해서 아래 버튼이 밀려나지 않게 한다 (가로 화면은 더 낮게) */
    private fun capListHeight(ctx: Context, view: View, list: LinearLayout, widthDp: Int) {
        val (vw, vh) = viewport(ctx)
        val landscape = vw > vh
        val cap = (vh * (if (landscape) 0.5f else 0.6f)).toInt()
        val widthPx = minOf(dp(ctx, widthDp), (vw * 0.92f).toInt()) - dp(ctx, 16)
        list.measure(
            View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        if (list.measuredHeight > cap) {
            val scroll = view.findViewById<View>(R.id.popupScroll)
            scroll.layoutParams = scroll.layoutParams.apply { height = cap }
        }
    }

    /** 항목 줄들을 목록에 채운다. 항목을 누르면 먼저 onPick(팝업 닫기)을 부르고 그 동작을 실행한다. */
    private fun fillRows(ctx: Context, list: LinearLayout, items: List<Item>, onPick: () -> Unit) {
        val inflater = LayoutInflater.from(ctx)
        items.forEach { it0 ->
            val row = inflater.inflate(R.layout.popup_item, list, false)
            val icon = row.findViewById<ImageView>(R.id.itemIcon)
            val label = row.findViewById<TextView>(R.id.itemTitle)
            if (it0.dotColor != null) {
                icon.imageTintList = null
                icon.setImageDrawable(GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(it0.dotColor)
                    setSize(dp(ctx, 16), dp(ctx, 16))
                })
            } else {
                icon.setImageResource(it0.icon)
            }
            label.text = it0.label
            if (it0.danger) {
                icon.imageTintList = android.content.res.ColorStateList.valueOf(danger(ctx))
                label.setTextColor(danger(ctx))
            }
            if (it0.sub != null) {
                row.findViewById<TextView>(R.id.itemSub).apply {
                    text = it0.sub
                    visibility = View.VISIBLE
                    if (it0.compactSub) {
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    }
                }
            }
            if (it0.checked) {
                row.findViewById<View>(R.id.itemCheck).visibility = View.VISIBLE
                // 화면 읽기(TalkBack)에서 "✓" 대신 "선택됨"으로 읽히게
                androidx.core.view.ViewCompat.setStateDescription(row, "선택됨")
                row.findViewById<View>(R.id.itemCheck).importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            row.setOnClickListener {
                onPick()
                it0.action()
            }
            list.addView(row)
        }
    }

    /**
     * 태블릿용: 누른 버튼 바로 아래에 붙어서 뜨는 목록 팝업 (뒤로/앞으로 기록 등).
     * 버튼의 왼쪽 끝에 맞추되 화면 밖으로는 나가지 않고, 남는 높이보다 길면 스크롤된다.
     */
    fun menuAnchored(
        ctx: Context,
        anchor: View,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        headerColor: Int? = null,
        items: List<Item>,
        /** 주면 버튼 아래가 아니라 이 점(창 안 좌표) 바로 아래에 뜬다. 아래 공간이 모자라면 점 위에 뜬다 */
        pointX: Int? = null,
        pointY: Int? = null
    ): PopupWindow {
        val view = LayoutInflater.from(ctx).inflate(R.layout.popup_menu, null)
        view.findViewById<TextView>(R.id.popupTitle).text = title
        if (!subtitle.isNullOrEmpty()) {
            view.findViewById<TextView>(R.id.popupSub).apply {
                text = subtitle
                visibility = View.VISIBLE
            }
        }
        if (headerColor != null) {
            view.findViewById<ImageView>(R.id.popupIcon).apply {
                setImageDrawable(null)
                setPadding(0, 0, 0, 0)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(headerColor)
                }
                visibility = View.VISIBLE
            }
        } else if (headerIcon != null) {
            view.findViewById<ImageView>(R.id.popupIcon).apply {
                setImageResource(headerIcon)
                visibility = View.VISIBLE
            }
        }
        val list = view.findViewById<LinearLayout>(R.id.popupList)

        val dm = ctx.resources.displayMetrics
        // 창 안 좌표와 창 크기로 계산 (프리폼·팝업 창에서 화면 좌표와 섞이면 위치가 어긋난다)
        val winW = anchor.rootView.width.takeIf { it > 0 } ?: dm.widthPixels
        val winH = anchor.rootView.height.takeIf { it > 0 } ?: dm.heightPixels
        val width = minOf(dp(ctx, 380), winW - dp(ctx, 16))
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val pt = pointX != null && pointY != null
        val gap = dp(ctx, 14) // 손가락이 가리지 않게 누른 곳에서 살짝 띄운다
        val below = if (pt) pointY!! + gap else loc[1] + anchor.height
        val maxH = (winH - below - dp(ctx, 12)).coerceAtLeast(if (pt) dp(ctx, 120) else dp(ctx, 240))

        var pw: PopupWindow? = null
        fillRows(ctx, list, items) { pw?.dismiss() }

        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        var height = minOf(view.measuredHeight, maxH)
        var above = false
        if (pt && winH - below - dp(ctx, 12) < minOf(view.measuredHeight, dp(ctx, 240))) {
            // 누른 곳 아래가 너무 좁으면 위로 띄운다
            above = true
            height = minOf(view.measuredHeight, (pointY!! - gap - dp(ctx, 12)).coerceAtLeast(dp(ctx, 120)))
        }

        // 둥근 카드 모양은 팝업 창 배경이 맡는다 (그림자도 이 모양을 따라간다)
        view.background = null
        val bg = anchoredBackground(ctx, view)
        val popup = PopupWindow(view, width, height, true).apply {
            setBackgroundDrawable(bg)
            isOutsideTouchable = true
            elevation = dp(ctx, 10).toFloat()
            animationStyle = R.style.Evergreen_MenuPopupAnim
        }
        pw = popup

        val leftWanted = if (pt) pointX!! - width / 2 else loc[0]
        val wantLeft = leftWanted.coerceIn(dp(ctx, 8), (winW - width - dp(ctx, 8)).coerceAtLeast(dp(ctx, 8)))
        prepareAnchoredEnter(view, if (pt) (pointX!! - wantLeft).toFloat() else loc[0] + anchor.width / 2f - wantLeft, width)
        if (pt) {
            val topY = if (above) pointY!! - gap - height else below
            popup.showAsDropDown(anchor, wantLeft - loc[0], topY - (loc[1] + anchor.height))
        } else {
            popup.showAsDropDown(anchor, wantLeft - loc[0], dp(ctx, 4))
        }
        Blur.behindPopup(popup, ctx)
        playAnchoredEnter(view, list)
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        return popup
    }

    /**
     * 목록 대신 직접 만든 내용을 담는 팝업 (현황 화면 등).
     * 내용이 길면 화면의 60% 높이까지만 보이고 그 안에서 스크롤된다.
     * @param secondaryLabel 왼쪽 버튼 글자 (없으면 버튼을 숨김)
     */
    fun panel(
        ctx: Context,
        title: String,
        subtitle: String? = null,
        @DrawableRes headerIcon: Int? = null,
        widthDp: Int = 360,
        secondaryLabel: String? = null,
        onSecondary: ((Dialog) -> Unit)? = null,
        closeLabel: String = "닫기",
        /** 오른쪽(진한) 버튼을 눌렀을 때 동작. 없으면 그냥 닫는다. 닫는 일은 직접 해야 한다 */
        onClose: ((Dialog) -> Unit)? = null,
        /** 뒤 페이지를 흐리지 않고 그대로 보여 준다 (실시간 미리보기가 있는 팝업용) */
        preview: Boolean = false,
        build: (list: LinearLayout, dialog: Dialog) -> Unit
    ): Dialog {
        val (dialog, view) = create(ctx, title, subtitle, headerIcon, null, widthDp, preview)
        val list = view.findViewById<LinearLayout>(R.id.popupList)
        build(list, dialog)

        capListHeight(ctx, view, list, widthDp)

        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).apply {
            if (secondaryLabel == null) {
                visibility = View.GONE
                // 취소 버튼이 없으면 확인 버튼이 꽉 차므로 사이 간격도 없앤다
                (view.findViewById<View>(R.id.popupOk).layoutParams as LinearLayout.LayoutParams).marginStart = 0
            } else {
                text = secondaryLabel
                setOnClickListener { onSecondary?.invoke(dialog) }
            }
        }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = closeLabel
            setOnClickListener { if (onClose != null) onClose(dialog) else dialog.dismiss() }
        }
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        return dialog
    }

    fun confirm(
        ctx: Context,
        title: String,
        message: String,
        positive: String = "확인",
        danger: Boolean = false,
        onOk: () -> Unit
    ): Dialog {
        val (dialog, view) = create(ctx, title, null, null, null)
        view.findViewById<TextView>(R.id.popupMessage).apply {
            text = message
            visibility = View.VISIBLE
        }
        view.findViewById<View>(R.id.popupScroll).visibility = View.GONE
        view.findViewById<View>(R.id.popupButtons).visibility = View.VISIBLE
        view.findViewById<Button>(R.id.popupCancel).setOnClickListener { dialog.dismiss() }
        view.findViewById<Button>(R.id.popupOk).apply {
            text = positive
            // 위험한 동작(삭제 등)은 빨간 채움 버튼으로 눈에 띄게
            if (danger) {
                backgroundTintList = android.content.res.ColorStateList.valueOf(danger(ctx))
                setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_on_danger))
            }
            setOnClickListener {
                dialog.dismiss()
                onOk()
            }
        }
        dialog.show()
        return dialog
    }
}
