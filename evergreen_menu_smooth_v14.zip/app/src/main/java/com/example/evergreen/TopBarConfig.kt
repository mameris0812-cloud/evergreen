package com.example.evergreen

/** 상단바에 올릴 수 있는 버튼 한 개. side = 놓이는 자리 */
data class TopBarItem(val id: String, val label: String, val icon: Int, val side: Int)

/**
 * 상단바(태블릿) / 하단바(폰) 버튼 편집 설정.
 * - 뒤로/앞으로는 주소창 왼쪽, 새로고침은 주소창 안쪽, 나머지는 주소창 오른쪽(메뉴 버튼 앞)에 놓인다.
 * - 메뉴(⋮) 버튼은 설정으로 들어가는 길이라 편집 대상이 아니다 (넓은 화면에서는 항상 보인다).
 */
object TopBarConfig {
    const val LEFT = 0
    const val INLINE = 1
    const val RIGHT = 2

    val items = listOf(
        TopBarItem("back", "뒤로", R.drawable.ic_back, LEFT),
        TopBarItem("forward", "앞으로", R.drawable.ic_forward, LEFT),
        TopBarItem("refresh", "새로고침 / 중지", R.drawable.ic_refresh, INLINE),
        TopBarItem("desktop", "데스크톱 / 모바일 사이트", R.drawable.ic_desktop, RIGHT),
        TopBarItem("home", "홈", R.drawable.ic_home, RIGHT),
        TopBarItem("ai", "AI 어시스턴트", R.drawable.ic_ai, RIGHT),
        TopBarItem("tabs", "탭 목록", R.drawable.ic_tab, RIGHT),
        TopBarItem("newtab", "새 탭", R.drawable.ic_add, RIGHT),
        TopBarItem("bookmark", "북마크 추가 / 수정", R.drawable.ic_bookmark_border, RIGHT),
        TopBarItem("bookmarks", "북마크 목록", R.drawable.ic_bookmark, RIGHT),
        TopBarItem("history", "방문 기록", R.drawable.ic_history, RIGHT),
        TopBarItem("downloads", "다운로드 목록", R.drawable.ic_download, RIGHT),
        TopBarItem("find", "페이지에서 찾기", R.drawable.ic_search, RIGHT),
        TopBarItem("player", "내장 플레이어로 재생", R.drawable.ic_play, RIGHT),
        TopBarItem("hidebars", "상/하단바 숨기기", R.drawable.ic_hide_bars, RIGHT),
        TopBarItem("settings", "설정", R.drawable.ic_settings, RIGHT)
    )

    fun byId(id: String): TopBarItem? = items.firstOrNull { it.id == id }

    /** 지금까지 쓰던 모양 그대로: 넓은 화면(상단바) = 뒤로·앞으로 + 새로고침 + 데스크톱·홈·탭 / 폰(하단바) = 뒤로·앞으로·홈·탭 */
    fun defaults(wide: Boolean): List<String> =
        if (wide) listOf("back", "forward", "refresh", "desktop", "home", "tabs") else listOf("back", "forward", "home", "tabs")

    /** 고를 수 있는 버튼: 폰 하단바에는 주소창 안쪽 새로고침이 없다 */
    fun pool(wide: Boolean): List<TopBarItem> = if (wide) items else items.filter { it.side != INLINE }

    /** 보이는 버튼 id (순서대로) */
    fun enabled(prefs: Prefs, wide: Boolean): List<String> {
        val saved = prefs.topBarIds(wide) ?: return defaults(wide)
        return saved.filter { id -> pool(wide).any { it.id == id } }.distinct()
    }
}
