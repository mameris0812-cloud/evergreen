package com.example.evergreen

import android.app.Activity
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * 설정 > 앱 정보 > '업데이트 로그': 버전별로 바뀐 내용을 보여 준다.
 * 새 버전을 낼 때마다 [ENTRIES] 맨 위에 한 항목씩 더한다 (최신이 위).
 */
object Changelog {

    class Entry(val version: String, val date: String, val notes: List<String>)

    val ENTRIES: List<Entry> = listOf(
        Entry(
            "2.9.33", "2026-11-10", listOf(
                "사이트 정보 창을 다듬었어요. 연결 상태는 초록(안전) · 빨강(안전하지 않음) 카드로 보이고, 카메라 · 마이크 · 위치는 허용 · 차단 · 미정에 따라 아이콘과 글자 색이 바뀌어요. '사이트 권한' · '저장된 데이터' 구분 제목이 생기고, 항목을 누르면 둥근 물결이 번져요\n'쿠키 및 사이트 데이터' 창은 개수를 큰 카드로, 쿠키 이름을 둥근 칩으로 보여 줘요"
            )
        ),
        Entry(
            "2.9.32", "2026-11-10", listOf(
                "사이트 정보 창에서 '쿠키 및 사이트 데이터'를 누르면 상세 창이 갑자기 화면 가운데에 뜨던 문제를 고쳤어요. 이제 사이트 정보 창과 같은 자리(태블릿은 주소창 바로 아래)에 떠요"
            )
        ),
        Entry(
            "2.9.31", "2026-11-10", listOf(
                "사이트 정보 창에서 '권한 재설정'을 누르면 한 번 더 물어봐요. 취소하면 사이트 정보 창에 그대로 남아요"
            )
        ),
        Entry(
            "2.9.30", "2026-11-10", listOf(
                "'쿠키 및 사이트 데이터' 화면에서 '지우기'를 누르면 한 번 더 물어봐요. 취소하면 그 화면에 그대로 남아요"
            )
        ),
        Entry(
            "2.9.29", "2026-11-10", listOf(
                "사이트 정보 창의 '쿠키 및 사이트 데이터'를 눌러도 바로 지워지지 않고, 저장된 쿠키 개수와 이름을 보여 주는 상세 화면이 열려요. 거기서 '지우기'를 누르면 지워지고, '뒤로'로 사이트 정보 창에 돌아가요"
            )
        ),
        Entry(
            "2.9.28", "2026-11-10", listOf(
                "주소창 왼쪽 자물쇠(https) · 지구본(http)을 누르면 '사이트 정보' 창이 떠요. 연결이 안전한지, 카메라 · 마이크 · 위치를 허용했는지(스위치로 켜고 끄기), 권한 재설정, 이 사이트의 쿠키 및 데이터 지우기를 한곳에서 할 수 있어요. 태블릿은 주소창 바로 아래에, 폰은 가운데 카드로 떠요\n(카메라 · 마이크 · 위치 허용 상태는 지금처럼 앱을 켜 둔 동안 기억돼요)",
                "같은 사이트가 주소 끝의 '/' 나 포트 표기만 달라도 카메라 · 마이크 · 위치 허용을 따로 물어보던 것을 같은 사이트로 보게 고쳤어요"
            )
        ),
        Entry(
            "2.9.27", "2026-11-10", listOf(
                "미러링 플레이어에서 화면 비율을 '화면 채우기' · '화면에 늘리기'로 바꿔도 카메라(노치) 자리는 검은 띠로 남던 것을 고쳤어요. 이제 영상이 카메라 자리까지 화면 가득 차요. 버튼 · 진행 막대 · 설정 카드는 카메라 자리를 피해서 그대로 놓여요 (내장 플레이어는 원래 카메라 자리까지 차 있었어요)"
            )
        ),
        Entry(
            "2.9.26", "2026-11-10", listOf(
                "미러링 플레이어에서 컨트롤을 켰을 때 위쪽 그림자(제목 · 버튼이 잘 보이게 영상을 어둡게 하는 막)가 카메라(노치) · 상태표시줄 자리에는 없어서 그 띠만 밝게 남던 것을 고쳤어요. 이제 그림자가 화면 맨 위까지 이어져요 (내장 플레이어는 원래 맨 위까지 덮고 있어요)"
            )
        ),
        Entry(
            "2.9.25", "2026-11-10", listOf(
                "모든 내장 플레이어(내장 플레이어 · 미러링)에서 가운데를 두 번 탭해 일시정지할 때 나오던 애니메이션을 없앴어요. 다시 재생할 때의 애니메이션은 그대로예요"
            )
        ),
        Entry(
            "2.9.24", "2026-11-10", listOf(
                "확장 프로그램이 더 많이 돌아가요. 가장 큰 문제였던 chrome.runtime.lastError 가 항상 '오류 있음' 으로 읽히던 것을 고쳤어요 (콜백에서 lastError 를 확인하는 확장 프로그램이 모두 실패 처리하던 원인이에요)",
                "탭 이벤트가 실제로 와요: chrome.tabs.onUpdated · onActivated, chrome.webNavigation(onBeforeNavigate · onCommitted · onDOMContentLoaded · onCompleted) 이 보고 있는 탭의 이동 · 로드 · 전환마다 백그라운드로 전달돼요",
                "앱의 기록 · 북마크를 읽을 수 있어요: chrome.history(search · getVisits) · chrome.bookmarks(getTree · search · getChildren · getRecent · get) · chrome.topSites. 매니페스트에 해당 권한이 있는 확장 프로그램만 볼 수 있고 읽기 전용이에요",
                "chrome.downloads.download 는 앱 다운로드로, chrome.notifications.create 는 앱 알림으로 이어져요",
                "그 밖에 chrome.idle · management · commands · sessions · system(cpu · memory · display) · tts · identity · sidePanel · omnibox · search · browsingData · proxy · privacy · power 와 tabs(getZoom · duplicate · detectLanguage …) · windows · permissions · runtime(requestUpdateCheck · setUninstallURL · 외부 메시지 이벤트) 를 크롬과 같은 모양의 값으로 채워서, 결과를 바로 쓰는 확장 프로그램이 undefined 로 죽지 않게 했어요",
                "'identity' 권한을 쓰는 확장 프로그램도 설치할 수 있어요 (구글 로그인만 빠지고 나머지는 동작해요)"
            )
        ),
        Entry(
            "2.9.23", "2026-11-10", listOf(
                "웹 영상 전체화면과 미러링에서도 핀치 줌이 돼요: 두 손가락으로 영상을 벌려 최대 6배까지 확대하고, 확대한 뒤에는 한 손가락으로 끌어 옮길 수 있어요. 거의 원래 크기로 줄이면 딱 맞게 돌아오고, 확대한 동안에는 아래로 밀어 나가기가 꺼져요. 이제 모든 내장 플레이어(내장 플레이어 · 웹 영상 전체화면 · 미러링)에서 똑같이 써요",
                "내장 플레이어에서 두 손가락으로 확대한 뒤 한 손가락만 남기고 끌 때 영상이 툭 튀던 것을 고쳤어요"
            )
        ),
        Entry(
            "2.9.22", "2026-11-10", listOf(
                "내장 플레이어에서 핀치 줌이 돼요: 두 손가락으로 영상을 벌려 최대 6배까지 확대하고, 손가락을 옮기면 확대한 자리를 따라가요. 확대한 뒤에는 한 손가락으로도 끌어 옮길 수 있고, 거의 원래 크기로 줄이면 딱 맞게 돌아와요. 확대한 동안에는 아래로 밀어 나가기가 꺼져요"
            )
        ),
        Entry(
            "2.9.21", "2026-11-10", listOf(
                "모든 내장 플레이어(내장 플레이어 · 웹 영상 전체화면 · 미러링)에서 꾹 눌러 2배속 하다가 아래로 내리면 플레이어가 닫히던 것을 막았어요. 길게 누른 터치는 아래로 끌어도 나가지 않아요 (짧게 아래로 밀어서 나가는 건 그대로예요)"
            )
        ),
        Entry(
            "2.9.20", "2026-11-10", listOf(
                "웹사이트의 영상을 조작하다가(컨트롤 · 탐색 막대 · 슬라이더 · 영상 위 끌기) 아래로 끌어내리면 당겨서 새로고침이 되던 것을 막았어요. 영상(또는 영상 바로 아래 컨트롤 막대)에서 시작한 터치는 끌어도 새로고침하지 않아요"
            )
        ),
        Entry(
            "2.9.19", "2026-11-10", listOf(
                "한 창에서 영상을 여러 개 틀면 시스템 미디어 플레이어(알림 · 잠금화면)의 제목 · 그림 · 재생 상태가 계속 번갈아 바뀌며 깜박이던 문제를 고쳤어요. 이제 먼저 붙든 영상이 재생 중인 동안은 그대로 두고, 새로 재생을 시작하거나 붙든 영상이 멈췄을 때만 다른 영상으로 넘어가요"
            )
        ),
        Entry(
            "2.9.18", "2026-11-10", listOf(
                "내장 플레이어를 가로로 볼 때 태블릿(갤럭시 탭 등)의 카메라 구멍 쪽이 검은 띠로 잘려 보이던 것을 고쳤어요. 이제 어느 쪽 카메라 구멍이든 영상이 그 자리까지 채우고, 버튼만 구멍을 피해 놓여요"
            )
        ),
        Entry(
            "2.9.17", "2026-11-10", listOf(
                "유튜브 HDR 이 화질 메뉴에 안 뜨던 문제를 다시 손봤어요. 화면이 HDR 을 낼 수 있으면 ① 창 색 모드를 코드로도 HDR 로 켜고 ② 웹뷰가 '(dynamic-range: high)' · HDR 디코딩을 '안 됨' 으로 잘못 답하는 것을 바로잡아요 (영상 디코더가 HDR 을 못 풀면 그대로 안 떠요)"
            )
        ),
        Entry(
            "2.9.16", "2026-11-10", listOf(
                "확장 프로그램 아이콘(퍼즐 조각)이 버튼 가운데에서 왼쪽 위로 치우쳐 보이던 것을 가운데로 맞췄어요"
            )
        ),
        Entry(
            "2.9.15", "2026-11-10", listOf(
                "크롬 웹스토어 확장 프로그램 페이지를 열 때 뜨던 「크롬 웹스토어 확장 프로그램이에요 · 설치」 알림을 없앴어요. 설치는 페이지의 「evergreen에 추가」 버튼으로 해요"
            )
        ),
        Entry(
            "2.9.14", "2026-11-10", listOf(
                "상/하단바의 확장 프로그램 버튼에 전용 애니메이션을 넣었어요: 누르는 동안 퍼즐 조각이 왼쪽 아래로 물러나 살짝 기울고 튀어나온 돌기가 움츠러들고, 떼면 오른쪽 위로 딸깍 끼워 맞춰지며 돌기가 튀어나왔다가 출렁이며 자리를 잡아요 (예전에는 버튼만 작아졌다 돌아왔어요)",
                "확장 프로그램 목록이 뜨는 동안에는 버튼이 눌린 채 기다렸다가, 목록이 뜬 뒤에 애니메이션을 시작해서 끊기지 않고 목록 위치도 흔들리지 않아요"
            )
        ),
        Entry(
            "2.9.13", "2026-11-10", listOf(
                "내장 플레이어(일반 · 미러링 둘 다)의 설정(톱니)에 「취침 타이머」를 넣었어요: 10분 · 15분 · 30분 · 45분 · 1시간 · 1시간 30분 · 2시간 뒤에 재생을 멈추고, 설정 줄에 남은 시간이 보여요. 「끔」을 누르면 취소돼요"
            )
        ),
        Entry(
            "2.9.12", "2026-11-10", listOf(
                "유튜브 화질 메뉴에 HDR 이 안 뜨던 문제를 고치려고, 브라우저 · 새 창 · 내장 플레이어 화면을 HDR 색 모드(colorMode=hdr)로 열도록 했어요. HDR 화면을 가진 기기에서만 효과가 있어요"
            )
        ),
        Entry(
            "2.9.11", "2026-11-10", listOf(
                "크롬 웹스토어에서 evergreen 이 지원하지 않는 확장 프로그램(테마 · 크롬 앱 · 사이드 패널 · 개발자 도구 · 새 탭 바꾸기, 또는 nativeMessaging · proxy · debugger 같은 권한이 꼭 필요한 것)은 「evergreen에 추가」 버튼이 파란색에서 회색으로 바뀌고 「evergreen과 호환되지 않아요」로 보여요. 누르면 설치되지 않고, 버튼을 길게 누르면 이유가 나와요"
            )
        ),
        Entry(
            "2.9.10", "2026-11-10", listOf(
                "확장 프로그램을 켜 두면 유튜브 영상이 480p 로 고정되고, 화질을 올리면 끊기며 오류가 나고, 영상을 바꾸면 '오프라인' 으로 뜨던 문제를 고쳤어요 (원인 추정: 영상 조각 요청마다 확장 프로그램의 webRequest 응답을 기다리거나 앱이 대신 받아서 느려졌어요). googlevideo · videoplayback · 미디어 · Range 요청은 이제 웹뷰가 직접 받아요"
            )
        ),
        Entry(
            "2.9.9", "2026-11-10", listOf(
                "영상을 길게 눌러 끌 때 영상 · 재생목록까지 덮는 반투명 틀이 손가락에 따라다니던 문제를 막았어요 (영상 안에서 시작한 끌기와, 영상이 들어 있거나 화면 큰 부분을 차지하는 글자 선택 끌기). 이미지 · 링크 끌기는 그대로예요"
            )
        ),
        Entry(
            "2.9.8", "2026-11-10", listOf(
                "이미 설치한 확장 프로그램의 웹스토어 페이지는 버튼이 「evergreen에서 삭제」로 보이고, 누르면 바로 지워져요 (지우면 다시 「evergreen에 추가」로 돌아와요)",
                "이미 설치된 확장 프로그램 페이지에서는 「설치」 알림을 띄우지 않아요"
            )
        ),
        Entry(
            "2.9.7", "2026-11-10", listOf(
                "크롬 웹스토어 왼쪽 위 이름과 탭 제목이 「Chrome 웹 스토어 for evergreen」으로 바뀌어요"
            )
        ),
        Entry(
            "2.9.6", "2026-11-10", listOf(
                "확장 프로그램의 fetch 응답에 주소(response.url)를 넣었어요: AdBlock 이 규칙을 내려받다 \"Invalid URL\" 로 멈춰서 팝업 · 옵션이 비던 문제",
                "chrome.offscreen 을 지원해요: 확장 프로그램이 만든 숨은 페이지(offscreen 문서)를 화면 밖에서 띄우고, 백그라운드와 메시지를 주고받아요 (동영상 화질 개선기의 GPU 확인 등)"
            )
        ),
        Entry(
            "2.9.5", "2026-11-10", listOf(
                "AdBlock 팝업이 \"Oops\"로 뜨던 문제를 고쳤어요: 팝업을 바로 열어도 백그라운드가 준비될 때까지 메시지를 붙잡아 두었다가 전달해요",
                "chrome.runtime.getManifest() 가 이름 등을 번역해서 돌려줘요 (AdBlock 의 \"Invalid extension name\" 오류 대응)",
                "메시지 발신자 정보(frameId · origin 등)와 chrome.webNavigation(getFrame · getAllFrames) 을 채웠어요",
                "chrome.runtime.getContexts · chrome.offscreen 을 넣어 동영상 화질 개선기의 백그라운드 오류를 없앴어요 (offscreen 문서 자체는 아직 미지원)",
                "탭으로 보낸 메시지에 응답이 없을 때도 진단에 남아요"
            )
        ),
        Entry(
            "2.9.4", "2026-11-10", listOf(
                "확장 프로그램 「진단」에 백그라운드 · 팝업 · 툴바 버튼의 오류가 남아요: 스크립트 오류, 못 불러온 파일, 응답 없는 메시지, 백그라운드가 꺼져 있는 경우, 툴바 버튼 실행 결과 (팝업이 안 뜨거나 툴바가 안 될 때 원인 확인용)"
            )
        ),
        Entry(
            "2.9.3", "2026-11-10", listOf(
                "크롬 웹스토어 확장 프로그램 상세 페이지의 「Chrome에 추가」 버튼이 「evergreen에 추가」로 바뀌고, 누르면 바로 evergreen에 설치돼요 (시크릿 탭 제외)",
                "웹스토어가 회색(비활성)으로 보여 주던 버튼도 눌러지게 했어요"
            )
        ),
        Entry(
            "2.9.2", "2026-11-10", listOf(
                "팝업이 없는 확장 프로그램(툴바 버튼을 누르면 백그라운드가 동작하는 종류, chrome.action.onClicked)을 쓸 수 있어요: 목록에서 아이콘 · 이름이나 「실행」 버튼을 누르면 그 동작이 불려요",
                "chrome.action.setPopup 으로 바뀌는 팝업도 따라가요",
                "확장 프로그램 「진단」에 팝업 유무와 툴바 버튼 동작이 함께 보여요"
            )
        ),
        Entry(
            "2.9.1", "2026-11-10", listOf(
                "태블릿에서 상단바·하단바의 확장 프로그램 버튼을 누르면, 목록 창이 화면 가운데가 아니라 그 버튼 바로 아래에 붙어서 떠요 (설정에서 열 때는 전과 같이 가운데)"
            )
        ),
        Entry(
            "2.9.0", "2026-11-10", listOf(
                "확장 프로그램 목록 창을 메뉴창처럼 바꿨어요: 바탕은 회색, 카드는 흰색 (꺼진 확장 프로그램 카드는 살짝 회색빛)"
            )
        ),
        Entry(
            "2.8.9", "2026-11-10", listOf(
                "확장 프로그램 목록의 색 조합을 메뉴창과 비슷하게 바꿨어요: 회색 바탕 카드, 연초록 아이콘 받침, 짙은 초록 글자 꼬리표·버튼, 연한 빨강 삭제 버튼"
            )
        ),
        Entry(
            "2.8.8", "2026-11-10", listOf(
                "빌드 오류 수정: 확장 프로그램의 요청 바꿈(리다이렉트) 코드에서 같은 이름의 변수가 겹쳐 앱이 만들어지지 않던 문제를 고쳤어요"
            )
        ),
        Entry(
            "2.8.7", "2026-11-10", listOf(
                "확장 프로그램 목록의 회색 카드 · 아이콘 · 꼬리표 · 버튼을 앱의 초록 계열 색으로 바꿨어요 (꺼진 확장 프로그램은 더 옅은 초록)"
            )
        ),
        Entry(
            "2.8.6", "2026-11-10", listOf(
                "확장 프로그램 목록 화면을 다듬었어요: 켜진 것이 위, 꺼진 것이 아래로 나뉘어 보이고(이름순), 카드마다 팝업 · 백그라운드 · 차단 규칙 수 같은 꼬리표가 붙어요",
                "팝업이 있는 확장 프로그램의 아이콘·이름 줄을 누르면 물결 효과와 함께 팝업이 열려요",
                "삭제 버튼을 작은 휴지통 아이콘으로 바꿔 실수로 누르기 어렵게 했어요 (누르면 한 번 더 물어봐요)",
                "설치된 게 없을 때 안내 문구를 짧게 줄였어요"
            )
        ),
        Entry(
            "2.8.5", "2026-11-10", listOf(
                "확장 프로그램 팝업 고침: 내용이 짧아지면 팝업도 같이 줄어들고(전에는 늘어나기만 했어요), 내용이 360dp 보다 넓으면 카드가 화면 폭 94% 까지 넓어져요",
                "팝업 안에서 window.close() 를 부르면 팝업이 닫혀요",
                "팝업 · 옵션 페이지에서 보낸 fetch 가 CORS 에 막히지 않고 (host 권한이 있는 주소는) 백그라운드처럼 앱이 대신 받아 와요. 그래서 서버에서 데이터를 불러오는 팝업이 비어 보이지 않아요",
                "글자를 입력하는 팝업에서 키보드가 입력칸을 가리지 않아요"
            )
        ),
        Entry(
            "2.8.4", "2026-11-10", listOf(
                "글자를 선택했을 때 뜨는 팝업에 확장 프로그램의 우클릭 메뉴(contexts 에 selection 이 든 항목)가 들어가요. 누르면 선택한 글(selectionText)과 함께 onClicked 가 불려요",
                "webRequest.onAuthRequired 지원: 사이트가 아이디·비밀번호를 물으면 확장 프로그램이 authCredentials 로 대신 답하거나 cancel 할 수 있어요 (blocking · asyncBlocking). 답이 없으면 기존 입력 창이 떠요",
                "POST 요청도 onBeforeRequest 등 리스너가 불리고 막기·다른 주소로 보내기가 돼요 (요청 본문과 헤더 고치기는 웹뷰가 본문을 앱에 주지 않아서 안 돼요)"
            )
        ),
        Entry(
            "2.8.3", "2026-11-10", listOf(
                "webRequest 지원: onBeforeRequest · onBeforeSendHeaders · onSendHeaders · onHeadersReceived · onResponseStarted · onCompleted · onErrorOccurred. 막는(blocking) 리스너는 cancel · redirectUrl · requestHeaders · responseHeaders 를 돌려줄 수 있어요 (결과를 최대 1.5초 기다려요)",
                "declarativeNetRequest 의 modifyHeaders 규칙(요청 · 응답 헤더 set · append · remove)을 적용해요. 헤더를 고쳐야 하는 요청은 앱이 대신 받아서 돌려줘요 (GET 요청만)",
                "contextMenus 지원: 확장 프로그램이 만든 메뉴가 링크 · 이미지를 길게 눌렀을 때 나오는 메뉴에 들어가요. 누르면 onClicked 가 불려요",
                "여전히 안 되는 것: POST 요청 본문 보기 · 헤더 고치기, 글자를 선택했을 때 메뉴(selection), 인증 창(onAuthRequired)"
            )
        ),
        Entry(
            "2.8.2", "2026-11-10", listOf(
                "요청 차단 규칙(declarativeNetRequest)의 redirect 규칙(url · extensionPath · regexSubstitution · transform)과 upgradeScheme 규칙을 적용해요. 최상위 문서는 새 주소로 이동하고, 이미지·스크립트 같은 하위 리소스는 새 주소의 내용으로 바꿔 줘요",
                "확장 프로그램 안내 문구를 지원 범위에 맞게 고쳤어요",
                "여전히 안 되는 것: webRequest(요청 가로채기), contextMenus, modifyHeaders 규칙"
            )
        ),
        Entry(
            "2.8.1", "2026-11-10", listOf(
                "AdBlock 같은 큰 확장 프로그램도 설치돼요: 압축을 푼 크기 한도를 150MB → 1GB, 파일 크기 한도를 80MB → 160MB 로 늘렸어요",
                "확장 프로그램 카드의 '백그라운드는 메시지 · 알람 · 외부 요청만 지원해서 …' 안내 문구를 없앴어요"
            )
        ),
        Entry(
            "2.8.0", "2026-11-10", listOf(
                "확장 프로그램 지원 한계 개선: 백그라운드 ↔ 콘텐츠 스크립트·팝업 사이 포트 연결(runtime.connect · onConnect, tabs.connect)을 지원해요",
                "저장소가 바뀌면(storage.onChanged) 백그라운드·팝업·탭 어느 쪽에서 바꿔도 서로 알림을 받아요. 영역별(storage.local.onChanged 등) 알림도 돼요",
                "보고 있는 탭에 스크립트·스타일 넣기: scripting.executeScript · insertCSS · removeCSS, tabs.executeScript · insertCSS · removeCSS · update · reload · goBack · goForward",
                "요청 차단 규칙(declarativeNetRequest): 정적 · 동적 · 세션 규칙의 차단/허용(block · allow)을 적용해요 (urlFilter · regexFilter · 리소스 종류 · 도메인 조건). 확장 '진단'에 적용 중인 규칙 수가 보여요",
                "chrome.cookies(get · getAll · set · remove), chrome.windows 기본 지원. 백그라운드 fetch 는 credentials: 'include' 일 때 쿠키를 보내고 받아요",
                "백그라운드에서 보낸 runtime.sendMessage 가 열려 있는 팝업·옵션 페이지에 전달돼요. 한 페이지의 콘텐츠 스크립트가 여러 묶음이어도 onMessage 리스너를 함께 써요",
                "content_scripts 의 include_globs · exclude_globs 를 지원해요",
                "보안: 확장 프로그램 메시지·답장은 그 확장 프로그램이 적용된 페이지에만 전달해서, 상관없는 사이트가 엿볼 수 없어요",
                "여전히 안 되는 것: webRequest(요청 가로채기), contextMenus, 요청 헤더 고치기 · 리다이렉트 규칙"
            )
        ),
        Entry(
            "2.7.9", "2026-11-10", listOf(
                "페이지를 나갈 때 뜨는 '탐색 확인' 창(변경사항이 저장되지 않을 수 있습니다)을 앱 팝업 모양으로 새로 꾸몄어요: 경고 아이콘, 사이트 주소, 한 줄 안내, 큼직한 '머무르기'(진한) · '나가기'(빨간 글자) 버튼",
                "뒤로가기나 바깥을 눌러 닫으면 '머무르기'로 처리돼서 실수로 작품을 잃지 않아요"
            )
        ),
        Entry(
            "2.7.8", "2026-11-10", listOf(
                "게임·플레이어처럼 화면을 직접 끌어서 조작하는 영역(touch-action 이 none 인 곳, tessvm 실행기)에서는 아래로 끌어도 페이지가 새로고침되지 않아요"
            )
        ),
        Entry(
            "2.7.7", "2026-11-10", listOf(
                "확장 프로그램 '진단'에 확장 파일 요청(제공/없음)과 페이지 안 오류(console.error · 처리 안 된 오류)를 함께 기록해요"
            )
        ),
        Entry(
            "2.7.6", "2026-11-10", listOf(
                "확장 프로그램 수정: 콘텐츠 스크립트가 globalThis.chrome / globalThis.browser 로 확장 API 를 찾아도 동작해요 ('Cannot read properties of undefined (reading storage)' 오류 해결, tessvm for Entry 등)"
            )
        ),
        Entry(
            "2.7.5", "2026-11-10", listOf(
                "확장 프로그램 카드에 '진단' 버튼 추가: 적용된 페이지, 확장 파일이 보안 정책(CSP)에 막혔는지, 스크립트 오류를 보여 주고 복사할 수 있어요"
            )
        ),
        Entry(
            "2.7.4", "2026-11-10", listOf(
                "확장 프로그램 수정: '문서 시작(document_start)'에 도는 콘텐츠 스크립트가 <html> 이 생기기 전에 실행돼 오류로 멈추던 문제를 고쳤어요 (페이지에 아무것도 적용되지 않던 원인)"
            )
        ),
        Entry(
            "2.7.3", "2026-11-10", listOf(
                "상/하단바에 '확장 프로그램' 버튼 추가: 설정 > 상/하단바 편집에서 고르면 바에서 바로 확장 프로그램 목록을 열 수 있어요",
                "확장 프로그램 툴바 팝업이 새 탭이 아니라 앱 안 팝업으로 떠요 (폭 360dp, 내용 높이에 맞춰 늘고 줄어요). 머리말의 버튼으로 탭에서도 열 수 있어요",
                "확장 프로그램 화면을 카드 모양으로 새로 꾸몄어요: 버전 표시, 켜짐/꺼짐 상태, 알약 모양 '팝업 열기 · 옵션 · 삭제' 버튼, 이름을 누르면 팝업 바로 열기, 비어 있을 때의 안내 화면"
            )
        ),
        Entry(
            "2.7.2", "2026-11-10", listOf(
                "확장 프로그램 백그라운드 지원: 눈에 안 보이는 웹뷰에서 background(service worker · scripts)를 돌려요",
                "콘텐츠 스크립트·팝업 ↔ 백그라운드 메시지(runtime.sendMessage / onMessage, 응답 포함), 백그라운드 → 보고 있는 탭 메시지(tabs.sendMessage), tabs.query · tabs.create, chrome.alarms, importScripts, onInstalled · onStartup 지원",
                "백그라운드의 fetch 는 host 권한이 있는 주소에 한해 앱이 대신 요청해서 CORS 에 막히지 않아요",
                "여전히 안 되는 것: 요청 차단(webRequest · declarativeNetRequest), contextMenus, runtime.connect(포트)"
            )
        ),
        Entry(
            "2.7.1", "2026-11-10", listOf(
                "크롬 웹스토어에서 확장 프로그램 바로 설치: 설정 > 확장 프로그램 > ＋ 추가 > '크롬 웹스토어에서 추가'에 웹스토어 주소(또는 영문 32자 ID)를 넣으면 내려받아 설치해요",
                "웹스토어 확장 프로그램 상세 페이지를 열면 아래에 '설치' 알림이 떠서 한 번에 설치할 수 있어요 (시크릿 탭 제외)",
                "'웹스토어 열기' 버튼으로 웹스토어를 새 탭에서 열어 둘러볼 수 있어요"
            )
        ),
        Entry(
            "2.7.0", "2026-11-10", listOf(
                "크롬 확장 프로그램 지원 (설정 > 브라우저 > 확장 프로그램): .zip · .crx 파일을 추가하면 조건(matches)에 맞는 페이지에 확장 프로그램의 스크립트·스타일이 적용돼요",
                "chrome.runtime · storage · i18n 등 자주 쓰는 API 지원, 켜기/끄기 · 옵션 열기 · 삭제 가능",
                "백그라운드(service worker) · webRequest · 팝업 메시지 같은 기능은 지원하지 않아요. 시크릿 탭에서는 쓰지 않아요"
            )
        ),
        Entry(
            "2.6.30", "2026-11-10", listOf(
                "웹사이트에서 펜 호버링 지원: 펜을 화면에 띄우고 움직이면 마우스를 올린 것처럼 호버 메뉴·툴팁·:hover 효과가 동작"
            )
        ),
        Entry(
            "2.6.29", "2026-11-10", listOf(
                "내장 플레이어: 추천 영상이 없을 때 '재생이 끝났어요'와 버튼이 가로 화면에서도 화면 가운데에 오도록 수정"
            )
        ),
        Entry(
            "2.6.28", "2026-11-10", listOf(
                "내장 플레이어 '다음 영상' 카드 UI 개선: 큰 카드·목록 썸네일을 키우고 길이 표시가 또렷하게 보이도록 개선",
                "가로 화면(태블릿)에서 오른쪽 '이어서 볼 영상' 목록이 왼쪽 카드와 같은 높이 중심에 오도록 정리",
                "목록 줄이 하나씩 차례로 나타나도록 애니메이션 개선"
            )
        ),
        Entry(
            "2.6.27", "2026-11-10", listOf(
                "메뉴창 미디어 플레이어: 일시정지 버튼과 10초 이동 버튼 사이 간격을 약 30dp로 맞춤"
            )
        ),
        Entry(
            "2.6.26", "2026-11-10", listOf(
                "메뉴창 미디어 플레이어: 재생/일시정지 버튼과 10초 이동 버튼 사이 여백을 살짝 줄임"
            )
        ),
        Entry(
            "2.6.25", "2026-11-10", listOf(
                "유튜브 광고가 시작될 때 로딩이 오래 걸리던 문제 개선",
                "광고를 끝으로 넘길 때 0.25초마다 계속 옮기던 것을 광고 하나당 한 번만 옮기도록 고침",
                "유튜브 광고 차단이 켜져 있으면 유튜브에서 구글 광고 서버 요청을 막지 않고 통과시킴 (막으면 광고가 안 불러와져 유튜브가 한참 기다림)"
            )
        ),
        Entry(
            "2.6.24", "2026-11-10", listOf(
                "설정 > 앱 정보에 '업데이트 로그' 추가"
            )
        ),
        Entry(
            "2.6.23", "2026-11-10", listOf(
                "유튜브 광고 차단 개선: 영상 정보에서 광고 목록을 미리 지워 광고가 시작되지 않게 함",
                "광고의 '건너뛰기' 버튼이 스크립트 클릭으로 안 눌리면 앱이 진짜 터치로 눌러 줌",
                "설정 > 광고 차단에 '유튜브 광고 미리 지우기' 켜고 끄기 추가"
            )
        )
    )

    fun show(act: Activity) {
        val dp = act.resources.displayMetrics.density
        val sb = SpannableStringBuilder()
        ENTRIES.forEachIndexed { i, e ->
            if (i > 0) sb.append("\n\n")
            val head = "v${e.version}"
            val s = sb.length
            sb.append(head)
            sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(RelativeSizeSpan(1.1f), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (e.version == BuildConfig.VERSION_NAME) sb.append("  · 현재 버전")
            sb.append("\n").append(e.date)
            e.notes.forEach { sb.append("\n• ").append(it) }
        }
        val tv = TextView(act).apply {
            text = sb
            textSize = 14f
            setLineSpacing(0f, 1.2f)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(act).apply {
            addView(
                LinearLayout(act).apply {
                    setPadding((24 * dp).toInt(), (8 * dp).toInt(), (24 * dp).toInt(), (8 * dp).toInt())
                    addView(tv)
                }
            )
        }
        MaterialAlertDialogBuilder(act)
            .setTitle("업데이트 로그")
            .setView(scroll)
            .setPositiveButton("닫기", null)
            .show()
    }
}
