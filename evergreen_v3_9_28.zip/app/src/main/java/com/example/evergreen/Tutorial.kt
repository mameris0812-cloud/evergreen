package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 처음 켰을 때의 '둘러보기'와, 업데이트 뒤의 '새 기능을 둘러볼까요?' 안내.
 *
 * - 화면 위에 어두운 막을 덮고 안내할 버튼만 밝게 뚫어 보여 준다 (스포트라이트). 밝은 곳을 누르면 다음 단계로 간다.
 * - 새로 설치한 앱은 [FIRST] 단계를 자동으로 보여 주고, 업데이트한 앱은 [TOUR] 중 아직 안 본 것(since > Prefs.tourLevel)만 묻는다.
 * - 안내할 버튼이 지금 화면에 없으면(예: 홈이 아님) 그 단계는 건너뛴다. 어느 단계에서든 '건너뛰기'로 끝낼 수 있다.
 *
 * 새 버전에서 소개할 기능이 생기면: [CURRENT_LEVEL] 을 1 올리고 [TOUR] 에 since = 올린 값으로 항목을 더한다. (README '작업 규칙')
 */
object Tutorial {

    /** 신기능 안내의 현재 차수. TOUR 에 새 항목을 더할 때 같이 올린다 */
    const val CURRENT_LEVEL = 1

    private const val TAG = "evergreen_tutorial"

    /** 안내 한 단계. ids 는 가리킬 뷰 후보(앞에서부터 지금 보이는 첫 번째를 쓴다), 폰/태블릿마다 다를 수 있다 */
    private class Spec(
        val since: Int,
        val title: String,
        val ids: (wide: Boolean) -> List<Int>,
        val body: (wide: Boolean) -> String
    ) {
        /** 정해 두면 ids 가 가리키는 뷰 안에서 contentDescription 이 이 글자인 보이는 뷰를 찾아 가리킨다 (폰 하단바의 동적 버튼용) */
        var desc: String? = null
    }

    private val FIRST: List<Spec> = listOf(
        Spec(0, "검색하거나 주소를 입력해요", { listOf(R.id.urlBar) }) { "여기에 입력하면 바로 검색하거나 사이트가 열려요." },
        Spec(0, "탭", { w -> if (w) listOf(R.id.tabStripBar, R.id.btnTabs) else listOf(R.id.btnBottomTabs, R.id.btnTabs) }) { w ->
            if (w) "탭 줄에서 탭을 길게 눌러 끌면 순서를 바꾸거나 다른 창으로 옮겨요."
            else "탭 버튼으로 열린 탭을 한눈에 보고, 카드를 옆으로 밀어 닫아요."
        },
        Spec(0, "메뉴", { w -> if (w) listOf(R.id.tbMenu) else listOf(R.id.btnMenu) }) { "설정, 북마크, 다운로드는 메뉴에 모여 있어요." },
        Spec(0, "즐겨찾기", { listOf(R.id.homeShortcuts) }) { "자주 가는 사이트를 홈에 두고, 길게 눌러 편집해요." },
        Spec(0, "광고 차단", { listOf(R.id.homeAdCard) }) { "이번 주에 막은 광고 수를 여기서 볼 수 있어요. 누르면 자세한 현황이 열려요." }
    )

    /** 업데이트로 새로 생긴 기능 안내. since = 그 기능이 들어온 차수 */
    private val TOUR: List<Spec> = listOf(
        Spec(1, "새 창 고르기", { w -> if (w) listOf(R.id.tbMenu) else listOf(R.id.btnMenu) }) {
            "메뉴의 「새 창」에서 전체 화면 · 분할 · 팝업 중에 골라 열 수 있어요."
        },
        Spec(1, "둘러보기 다시 보기", { w -> if (w) listOf(R.id.tbMenu) else listOf(R.id.btnMenu) }) {
            "처음 안내는 설정에서 언제든 다시 볼 수 있어요."
        }
    )

    /** 기능별 선택 안내. 설정 > 둘러보기 다시 보기 에서 골라 본다. 안내할 버튼이 하나도 안 보이면 고를 때 이유를 알려 준다 */
    private class Chapter(val name: String, val specs: List<Spec>, val hint: String? = null)

    private val MENU_IDS: (Boolean) -> List<Int> = { w -> if (w) listOf(R.id.tbMenu) else listOf(R.id.btnMenu) }

    private val CHAPTERS: List<Chapter> = listOf(
        Chapter("탭 다루기", listOf(
            Spec(0, "새 탭", { w -> if (w) listOf(R.id.btnStripNewTab) else emptyList() }) { "＋ 버튼으로 새 탭을 열어요." },
            Spec(0, "탭 줄", { w -> if (w) listOf(R.id.tabStripBar) else emptyList() }) { "탭을 길게 눌러 끌면 순서가 바뀌고, 그냥 누르면 탭 메뉴가 열려요." },
            Spec(0, "탭 목록", { w -> if (w) listOf(R.id.btnStripTabList, R.id.btnTabs) else listOf(R.id.btnBottomTabs, R.id.btnTabs) }) {
                "탭 화면에서 열린 탭을 한눈에 보고, 카드를 옆으로 밀어 닫거나 길게 눌러 끌어 순서를 바꿔요."
            }
        )),
        Chapter("메뉴 속 기능", listOf(
            Spec(0, "페이지 번역", MENU_IDS) { "메뉴의 「페이지 번역」으로 보고 있는 페이지를 번역해요." },
            Spec(0, "동영상 PiP", MENU_IDS) { "영상이 있는 페이지에서 메뉴의 「동영상 PiP」를 누르면 작은 창으로 띄워 볼 수 있어요." },
            Spec(0, "북마크 · 방문 기록", MENU_IDS) { "저장한 북마크와 지난 방문 기록은 메뉴에서 모아 볼 수 있어요." },
            Spec(0, "설정", MENU_IDS) { "광고 차단, 자동 스크롤, 글자 크기 같은 것은 설정에서 바꿔요." }
        )),
        Chapter("AI 어시스턴트", listOf(
            Spec(0, "AI 어시스턴트", { w -> if (w) listOf(R.id.tbAi) else emptyList() }) { "버튼을 누르면 AI 어시스턴트가 열리고, 다시 누르면 닫혀요." },
            Spec(0, "AI 어시스턴트", { w -> if (w) emptyList() else listOf(R.id.bottomBar) }) { "버튼을 누르면 AI 어시스턴트가 열리고, 다시 누르면 닫혀요." }
                .apply { desc = "AI 어시스턴트" }
        ), hint = "상/하단바 버튼 편집에서 AI 어시스턴트 버튼을 추가하면 안내해 드려요")
    )

    /** 지금 화면에서 이 단계가 가리킬 뷰. 후보 중 보이고 크기가 있는 첫 번째, 없으면 null */
    private fun resolve(act: Activity, wide: Boolean, s: Spec): View? {
        val d = s.desc
        if (d != null) {
            val root = s.ids(wide).asSequence().mapNotNull { act.findViewById<View>(it) }.firstOrNull() as? ViewGroup ?: return null
            return findByDesc(root, d)
        }
        return s.ids(wide).asSequence().mapNotNull { act.findViewById<View>(it) }
            .firstOrNull { it.isShown && it.width > 0 && it.height > 0 }
    }

    private fun findByDesc(v: View, d: String): View? {
        if (v.isShown && v.width > 0 && v.height > 0 && v.contentDescription?.toString() == d) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findByDesc(v.getChildAt(i), d)?.let { return it }
        return null
    }

    /** 설정 > '둘러보기 다시 보기': 처음 둘러보기와 기능별 안내 중에 고른다. [prepareHome] 은 처음 둘러보기 전에 홈 화면을 만들어 둔다 */
    fun chooser(act: Activity, wide: Boolean, prepareHome: () -> Unit) {
        if (act.isFinishing || act.isDestroyed) return
        val chapters = CHAPTERS
        val names = (listOf("처음 둘러보기") + chapters.map { it.name }).toTypedArray()
        ThemedDialogBuilder(act)
            .setTitle("둘러보기")
            .setItems(names) { _, which ->
                if (which == 0) {
                    prepareHome()
                    Handler(Looper.getMainLooper()).postDelayed({ replay(act, wide) }, 450)
                } else {
                    val ch = chapters[which - 1]
                    // 안내할 버튼이 지금 화면에 하나도 없으면 이유를 알려 준다
                    if (ch.specs.none { resolve(act, wide, it) != null }) AppToast.show(act, ch.hint ?: "지금 화면에서는 안내할 버튼이 없어요")
                    else show(act, wide, ch.specs, intro = false) { }
                }
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    /** 앱을 처음 설치한 것이면 true. 업데이트로 들어온 앱은 설치 시각과 마지막 업데이트 시각이 다르다 */
    private fun isFreshInstall(ctx: Context): Boolean = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        pi.lastUpdateTime - pi.firstInstallTime < 60_000L
    } catch (_: Throwable) { false }

    /** 앱을 켠 뒤 MainActivity 가 부른다. 새 설치면 둘러보기를, 업데이트면 새 기능 안내 여부를 묻는다 */
    fun maybeStart(act: Activity, wide: Boolean, isHome: Boolean) {
        if (act.isFinishing || act.isDestroyed) return
        val prefs = Prefs(act)
        if (!prefs.tutorialDone) {
            if (isFreshInstall(act)) {
                if (!isHome) return   // 홈이 아니면 이번엔 건너뛰고 다음에 켤 때 다시 시도
                show(act, wide, FIRST, intro = true) {
                    prefs.tutorialDone = true
                    prefs.tourLevel = CURRENT_LEVEL
                }
            } else {
                // 업데이트로 들어온 사용자: 처음 안내는 설정에서만, 새 기능은 물어본다
                prefs.tutorialDone = true
                askTour(act, wide, prefs)
            }
        } else if (prefs.tourLevel < CURRENT_LEVEL) {
            askTour(act, wide, prefs)
        }
    }

    /** 설정 > '둘러보기 다시 보기' */
    fun replay(act: Activity, wide: Boolean) {
        if (act.isFinishing || act.isDestroyed) return
        show(act, wide, FIRST, intro = true) { }
    }

    private fun askTour(act: Activity, wide: Boolean, prefs: Prefs) {
        val items = TOUR.filter { it.since > prefs.tourLevel }
        if (items.isEmpty()) { prefs.tourLevel = CURRENT_LEVEL; return }
        // 물어본 것으로 치고 차수를 먼저 저장한다 (어떤 답을 해도 다시 묻지 않는다)
        prefs.tourLevel = CURRENT_LEVEL
        ThemedDialogBuilder(act)
            .setTitle("새 기능을 둘러볼까요?")
            .setMessage("이번에 새로 생긴 기능을 30초 안에 알려드릴게요.")
            .setPositiveButton("둘러보기") { _, _ -> show(act, wide, items, intro = false) { } }
            .setNegativeButton("나중에", null)
            .show()
    }

    private fun show(act: Activity, wide: Boolean, specs: List<Spec>, intro: Boolean, onEnd: () -> Unit) {
        val root = act.findViewById<ViewGroup>(android.R.id.content) ?: return
        if (root.findViewWithTag<View>(TAG) != null) return   // 이미 떠 있다
        val overlay = Overlay(act, wide, specs, intro, onEnd)
        if (!overlay.hasSteps()) return
        root.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay.begin()
    }

    private enum class Kind { INTRO, STEP, OUTRO }

    private class Item(val kind: Kind, val title: String, val staticBody: String?, val spec: Spec?)

    private class Overlay(
        private val act: Activity,
        private val wide0: Boolean,
        specs: List<Spec>,
        intro: Boolean,
        private val onEnd: () -> Unit
    ) : FrameLayout(act) {

        /** 폰↔태블릿 모드는 창 크기에 따라 도중에 바뀐다. 시작할 때 값이 아니라 지금 값을 쓴다 */
        private val wide: Boolean get() = (act as? MainActivity)?.isWideLayout() ?: wide0

        private val items = ArrayList<Item>()
        private var index = 0
        private var hole: RectF? = null
        private var bubble: View? = null
        private var ended = false

        private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(0x99, 0, 0, 0) }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
        }
        private val path = Path()

        init {
            tag = TAG
            setWillNotDraw(false)
            isClickable = true
            isFocusable = false
            // 토스트(200dp)·진행 카드(190dp)보다는 아래, 그 밖의 화면보다는 위
            AppToast.raiseToTop(this, dp(150))
            ring.color = ThemeColors.get(this, com.google.android.material.R.attr.colorPrimary, 0xFF2FA35B.toInt())

            if (intro) items.add(Item(Kind.INTRO, "evergreen 둘러보기", "핵심만 1분 안에 알려드릴게요.", null))
            // 단계는 전부 담아 두고, 지금 화면에 그 버튼이 있는지는 보여 줄 때마다 다시 본다 (화면 모양이 바뀌면 보이는 단계도 바뀐다)
            for (s in specs) items.add(Item(Kind.STEP, s.title, null, s))
            if (intro) items.add(Item(Kind.OUTRO, "준비됐어요", "설정에서 언제든 다시 볼 수 있어요.", null))
        }

        fun hasSteps() = items.any { live(it) }

        /** 안내할 단계이고 그 버튼이 지금 화면에 있으면 true */
        private fun live(item: Item): Boolean = item.kind == Kind.STEP && item.spec?.let { anchorFor(it) } != null

        private val relayout = Runnable { if (!ended) show(index, 8) }

        override fun onDetachedFromWindow() {
            removeCallbacks(relayout)
            super.onDetachedFromWindow()
        }

        fun begin() {
            alpha = 0f
            animate().alpha(1f).setDuration(200).start()
            show(0)
        }

        private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

        private fun anchorFor(s: Spec): View? = resolve(act, wide, s)

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            if (ended || ow == 0) return
            // 창 크기·비율·회전이 바뀌면(분할 화면, 폰↔태블릿 전환 포함) 안내할 버튼의 자리도, 있는지 여부도 바뀐다.
            // 레이아웃이 자리 잡는 동안은 안내를 잠깐 감추고, 잠잠해지면(0.25초) 같은 단계를 새 모양에 맞춰 다시 그린다
            hole = null
            bubble?.visibility = INVISIBLE
            invalidate()
            removeCallbacks(relayout)
            postDelayed(relayout, 250)
        }

        override fun onDraw(c: Canvas) {
            val h = hole
            if (h == null) {
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
                return
            }
            path.reset()
            path.fillType = Path.FillType.EVEN_ODD
            path.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
            val r = minOf(dp(14).toFloat(), h.height() / 2f)
            path.addRoundRect(h, r, r, Path.Direction.CW)
            c.drawPath(path, dim)
            c.drawRoundRect(h, r, r, ring)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            // 밝게 뚫린 곳을 누르면 다음 단계. 그 밖은 막 뒤의 화면이 눌리지 않게 삼킨다
            if (e.actionMasked == MotionEvent.ACTION_UP && hole?.contains(e.x, e.y) == true) advance()
            return true
        }

        private fun advance() {
            if (index + 1 >= items.size) finish() else show(index + 1)
        }

        private fun finish() {
            if (ended) return
            ended = true
            onEnd()
            animate().alpha(0f).setDuration(180).withEndAction { (parent as? ViewGroup)?.removeView(this) }.start()
        }

        private fun show(i: Int, retries: Int = 0) {
            if (ended) return
            if (width == 0 || height == 0) { post { show(i, retries) }; return }
            index = i
            val item = items[i]
            // 안내할 버튼이 사라졌으면(모드 전환 등) 그 단계는 넘어간다
            val anchor = item.spec?.let { anchorFor(it) }
            if (item.kind == Kind.STEP && anchor == null) {
                // 화면 모양이 바뀌는 중이면 버튼이 아직 자리를 못 잡았을 수 있다 → 잠시 기다려 다시 보고, 그래도 없으면 넘어간다
                if (retries > 0) {
                    hole = null
                    bubble?.visibility = INVISIBLE
                    invalidate()
                    postDelayed({ if (!ended) show(i, retries - 1) }, 200)
                    return
                }
                advance(); return
            }

            hole = if (anchor != null) {
                val a = IntArray(2); val me = IntArray(2)
                anchor.getLocationInWindow(a); getLocationInWindow(me)
                val pad = dp(6)
                RectF(
                    (a[0] - me[0] - pad).toFloat(), (a[1] - me[1] - pad).toFloat(),
                    (a[0] - me[0] + anchor.width + pad).toFloat(), (a[1] - me[1] + anchor.height + pad).toFloat()
                )
            } else null
            invalidate()

            bubble?.let { removeView(it) }
            val b = buildBubble(item, i)
            val bw = minOf(dp(300), width - dp(32))
            b.measure(MeasureSpec.makeMeasureSpec(bw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            val bh = b.measuredHeight
            val h = hole
            val x: Int
            var y: Int
            if (h == null) {
                x = (width - bw) / 2
                y = (height - bh) / 2
            } else {
                x = (h.centerX() - bw / 2f).toInt().coerceIn(dp(16), maxOf(dp(16), width - bw - dp(16)))
                y = if (h.centerY() < height / 2f) (h.bottom + dp(12)).toInt() else (h.top - dp(12) - bh).toInt()
                y = y.coerceIn(dp(8), maxOf(dp(8), height - bh - dp(8)))
            }
            addView(b, LayoutParams(bw, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
                leftMargin = x; topMargin = y
            })
            bubble = b
            b.alpha = 0f
            b.translationY = dp(6).toFloat()
            b.animate().alpha(1f).translationY(0f).setDuration(180).start()
        }

        private fun pill(text: String, filled: Boolean, onClick: () -> Unit): TextView {
            val ctx = context
            val primary = ThemeColors.get(this, com.google.android.material.R.attr.colorPrimary, 0xFF2FA35B.toInt())
            val onPrimary = ThemeColors.get(this, com.google.android.material.R.attr.colorOnPrimary, Color.WHITE)
            val onVar = ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF73777F.toInt())
            return TextView(ctx).apply {
                this.text = text
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                minHeight = dp(36)
                if (filled) {
                    setTextColor(onPrimary)
                    background = GradientDrawable().apply { setColor(primary); cornerRadius = dp(18).toFloat() }
                } else {
                    setTextColor(onVar)
                }
                isClickable = true
                setOnClickListener { onClick() }
            }
        }

        private fun buildBubble(item: Item, i: Int): View {
            val ctx = context
            val surface = ThemeColors.get(this, com.google.android.material.R.attr.colorSurface, Color.WHITE)
            val onSurface = ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurface, 0xFF202124.toInt())
            val onVar = ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF73777F.toInt())
            val edge = ThemeColors.get(this, com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt())

            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(16), dp(14), dp(10))
                background = GradientDrawable().apply {
                    setColor(surface); cornerRadius = dp(20).toFloat(); setStroke(dp(1), edge)
                }
                isClickable = true   // 말풍선 위를 눌러도 뒤로 새지 않게
            }
            box.addView(TextView(ctx).apply {
                text = item.title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setTextColor(onSurface)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            })
            box.addView(TextView(ctx).apply {
                text = item.spec?.body?.invoke(wide) ?: item.staticBody ?: ""
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(onVar)
                setLineSpacing(0f, 1.2f)
                setPadding(0, dp(6), dp(4), dp(12))
            })

            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val stepNo = items.subList(0, i + 1).count { live(it) }
            val stepTotal = items.count { live(it) }
            row.addView(TextView(ctx).apply {
                text = if (item.kind == Kind.STEP) "$stepNo / $stepTotal" else ""
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(onVar)
            }, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))

            val last = i == items.size - 1
            if (!last) row.addView(pill("건너뛰기", false) { finish() })
            val nextLabel = when {
                item.kind == Kind.INTRO -> "시작"
                item.kind == Kind.OUTRO -> "시작하기"
                last -> "완료"
                else -> "다음"
            }
            row.addView(pill(nextLabel, true) { advance() })
            box.addView(row, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
            return box
        }
    }
}
