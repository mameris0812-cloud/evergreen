package com.example.evergreen

import android.net.Uri
import android.os.Bundle
import androidx.browser.customtabs.CustomTabsService
import androidx.browser.customtabs.CustomTabsSessionToken

/**
 * 다른 앱이 "이 기기에서 커스텀 탭을 지원하는 브라우저"를 찾을 때 evergreen 이 후보로 보이게 하는 서비스.
 * 미리 불러오기(warmup)·postMessage 같은 고급 기능은 쓰지 않아서 모두 "지원 안 함"으로 답한다.
 * 실제 화면은 [CustomTabActivity] 가 그린다.
 */
class EvergreenCustomTabsService : CustomTabsService() {
    override fun warmup(flags: Long): Boolean = true
    override fun newSession(sessionToken: CustomTabsSessionToken): Boolean = true
    override fun mayLaunchUrl(sessionToken: CustomTabsSessionToken, url: Uri?, extras: Bundle?, otherLikelyBundles: List<Bundle>?): Boolean = false
    override fun extraCommand(commandName: String, args: Bundle?): Bundle? = null
    override fun updateVisuals(sessionToken: CustomTabsSessionToken, bundle: Bundle?): Boolean = false
    override fun requestPostMessageChannel(sessionToken: CustomTabsSessionToken, postMessageOrigin: Uri): Boolean = false
    override fun postMessage(sessionToken: CustomTabsSessionToken, message: String, extras: Bundle?): Int = RESULT_FAILURE_DISALLOWED
    override fun validateRelationship(sessionToken: CustomTabsSessionToken, relation: Int, origin: Uri, extras: Bundle?): Boolean = false
    override fun receiveFile(sessionToken: CustomTabsSessionToken, uri: Uri, purpose: Int, extras: Bundle?): Boolean = false
}
