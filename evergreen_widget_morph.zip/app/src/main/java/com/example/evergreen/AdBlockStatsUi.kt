package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 설정 > 광고 차단 현황.
 * 이 페이지 / 오늘 / 전체 차단 건수, 종류별 건수, 가장 많이 막은 사이트, 차단 목록 상태를 한 화면에 보여 준다.
 */
object AdBlockStatsUi {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun n(v: Number) = String.format(Locale.getDefault(), "%,d", v.toLong())

    /** "방금 전 / 3시간 전 / 2일 전" 처럼 마지막 목록 업데이트를 짧게 */
    fun agoText(time: Long): String {
        if (time <= 0L) return "아직 내려받지 않음"
        val diff = System.currentTimeMillis() - time
        val min = diff / 60_000
        return when {
            diff < 0 || min < 1 -> "방금 전"
            min < 60 -> "${min}분 전"
            min < 60 * 24 -> "${min / 60}시간 전"
            else -> "${min / (60 * 24)}일 전"
        }
    }

    /**
     * @param enabled 광고 차단이 켜져 있는지
     * @param pageBlocked 지금 보는 페이지에서 막은 건수 (홈 화면이면 null)
     * @param trackerBlocked 트래커 차단(엄격 모드)이 이번 실행에서 막은 건수 (꺼져 있으면 null)
     * @param onUpdate '지금 목록 업데이트' 를 눌렀을 때
     * @param origin 눌린 카드 (없으면 일반 팝업)
     */
    fun show(
        ctx: Context,
        blocker: AdBlocker,
        enabled: Boolean,
        pageBlocked: Int?,
        trackerBlocked: Int?,
        onUpdate: () -> Unit,
        /** 새 탭 화면 위젯처럼 눌린 카드가 있으면, 그 카드가 펼쳐져 이 창이 된다 */
        origin: View? = null
    ): Dialog {
        blocker.flush()
        val st = blocker.stats(8)
        val onSurface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val tile = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFFEEEEEE.toInt())

        fun section(list: LinearLayout, text: String) {
            list.addView(TextView(ctx).apply {
                this.text = text
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(primary)
                setPadding(dp(ctx, 12), dp(ctx, 16), dp(ctx, 12), dp(ctx, 4))
            })
        }

        fun row(list: LinearLayout, label: String, value: String) {
            list.addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(ctx, 12), dp(ctx, 7), dp(ctx, 12), dp(ctx, 7))
                addView(TextView(ctx).apply {
                    text = label
                    textSize = 14f
                    setTextColor(onSurface)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(TextView(ctx).apply {
                    text = value
                    textSize = 14f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(onVar)
                    setPadding(dp(ctx, 12), 0, 0, 0)
                })
            })
        }

        fun tile(label: String, value: String): View = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 6), dp(ctx, 14), dp(ctx, 6), dp(ctx, 12))
            background = GradientDrawable().apply {
                cornerRadius = dp(ctx, 16).toFloat()
                setColor(tile)
            }
            addView(TextView(ctx).apply {
                text = value
                textSize = 22f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(primary)
                gravity = Gravity.CENTER
                maxLines = 1
            })
            addView(TextView(ctx).apply {
                text = label
                textSize = 12f
                setTextColor(onVar)
                gravity = Gravity.CENTER
                setPadding(0, dp(ctx, 3), 0, 0)
            })
        }

        val dateText = SimpleDateFormat("yyyy.MM.dd", Locale.getDefault()).format(Date(st.since))

        return Popup.panel(
            ctx,
            title = "광고 차단 현황",
            subtitle = if (enabled) "광고 차단 켜짐 · $dateText 부터 집계" else "광고 차단이 꺼져 있어요 · 켜면 다시 집계됩니다",
            headerIcon = R.drawable.ic_shield,
            widthDp = 380,
            origin = origin,
            secondaryLabel = "통계 초기화",
            // 확인을 받고 지운 뒤, 새 숫자로 현황을 다시 연다
            onSecondary = { d ->
                Popup.confirm(
                    ctx, "통계를 초기화할까요?",
                    "오늘·전체·종류별 차단 건수와 사이트별 기록이 0으로 돌아갑니다. 차단 목록과 설정은 그대로예요.",
                    "초기화", danger = true
                ) {
                    blocker.resetStats()
                    Popup.dismissNow(d)
                    show(ctx, blocker, enabled, pageBlocked, trackerBlocked, onUpdate, origin)
                }
            }
        ) { list, dialog ->
            // 한눈에 보는 숫자
            list.addView(
                LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(dp(ctx, 8), dp(ctx, 4), dp(ctx, 8), 0)
                    val items = listOf(
                        "이 페이지" to (pageBlocked?.let { n(it) } ?: "-"),
                        "오늘" to n(st.today),
                        "전체" to n(st.total)
                    )
                    items.forEachIndexed { i, (label, value) ->
                        addView(
                            tile(label, value),
                            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                                if (i > 0) marginStart = dp(ctx, 8)
                            }
                        )
                    }
                }
            )

            section(list, "종류별 (이번에 앱을 켠 뒤)")
            row(list, "광고·추적 요청", n(st.requests) + "건")
            row(list, "팝업·광고 페이지 이동", n(st.popups) + "건")
            if (trackerBlocked != null) row(list, "트래커 (엄격 모드)", n(trackerBlocked) + "건")

            section(list, "가장 많이 막은 곳")
            if (st.top.isEmpty()) {
                list.addView(TextView(ctx).apply {
                    text = "아직 막은 광고가 없어요. 사이트를 둘러보면 여기에 쌓여요."
                    textSize = 13f
                    setTextColor(onVar)
                    setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), dp(ctx, 6))
                })
            } else {
                st.top.forEach { (host, count) -> row(list, host, n(count) + "건") }
            }

            section(list, "차단 목록")
            row(list, "차단 도메인", n(blocker.hostRuleCount) + "개")
            row(list, "주소 필터 규칙 (EasyList 등)", n(blocker.pathRuleCount) + "개")
            row(list, "화면 광고 숨김 규칙", n(blocker.genericCssCount + blocker.siteCssCount) + "개")
            row(list, "마지막 업데이트", agoText(blocker.lastUpdated))

            list.addView(
                MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                    text = "지금 목록 업데이트"
                    setOnClickListener {
                        dialog.dismiss()
                        onUpdate()
                    }
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(dp(ctx, 12), dp(ctx, 14), dp(ctx, 12), dp(ctx, 8))
                }
            )
        }
    }
}
