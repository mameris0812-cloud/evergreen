package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.WebResourceRequest
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.Collections
import java.util.Locale
import java.util.UUID
import java.util.WeakHashMap
import java.util.zip.ZipInputStream

/**
 * 크롬 확장 프로그램 지원.
 *
 * 안드로이드 WebView 는 크롬 확장을 그대로 돌릴 수 없어서, 확장 프로그램의 '콘텐츠 스크립트'(웹페이지에 끼워 넣는
 * JS/CSS)를 매니페스트의 주소 조건(matches)에 맞는 페이지에 직접 넣어 주고, 자주 쓰는 chrome.* API
 * (runtime · storage · i18n · tabs 일부 · alarms)를 흉내 내어 제공한다.
 * 백그라운드(service worker / background scripts)는 눈에 안 보이는 웹뷰에서 일반 페이지로 돌린다:
 * runtime.sendMessage ↔ onMessage, tabs.sendMessage(보고 있는 탭), alarms, importScripts, onInstalled/onStartup,
 * 그리고 host 권한이 있는 주소로의 fetch(CORS 없이 앱이 대신 요청)를 지원한다.
 * webRequest · declarativeNetRequest · contextMenus · runtime.connect(포트) 같은 기능은 지원하지 않는다.
 */
class ExtensionManager(private val ctx: Context) {

    class Entry(
        val matches: List<String>,
        val excludes: List<String>,
        val js: List<String>,
        val css: List<String>,
        val runAt: String,
        val allFrames: Boolean
    )

    class Ext(
        val id: String,
        val name: String,
        val version: String,
        val description: String,
        val manifestVersion: Int,
        val dir: File,
        val manifest: JSONObject,
        val entries: List<Entry>,
        val hasBackground: Boolean,
        val options: String?,
        val popup: String?,
        val icon: String?,
        val messages: Map<String, String>,
        val hosts: List<Regex>,
        var enabled: Boolean
    )

    companion object {
        const val HOST = "ext.evergreen.invalid"
        private const val MAX_ZIP = 80L * 1024 * 1024
        private const val MAX_UNPACKED = 150L * 1024 * 1024
        private const val MAX_AREA_JSON = 5_000_000
        private const val STORE_CHROME_VERSION = "130.0.0.0"
        private const val MAX_MSG = 4_000_000
        private const val MAX_FETCH = 15L * 1024 * 1024
        private const val BG_PAGE = "__evx_bg.html"
        private val ID_RE = Regex("^[a-p]{32}$")
        private val STORE_RE = Regex("^https?://(chromewebstore\\.google\\.com|chrome\\.google\\.com/webstore)/detail/.*?([a-p]{32})(?:[/?#].*)?$", RegexOption.IGNORE_CASE)

        /** 웹스토어 상세 페이지 주소 또는 ID 만 적은 글에서 확장 프로그램 ID 를 뽑는다 (아니면 null) */
        fun parseStoreId(input: String): String? {
            val t = input.trim()
            if (ID_RE.matches(t)) return t
            return STORE_RE.matchEntire(t)?.groupValues?.get(2)?.lowercase(Locale.ROOT)
        }
    }

    private val root = File(ctx.filesDir, "extensions")
    private val dataDir = File(root, ".data")
    private val indexFile = File(root, "index.json")
    private val lock = Any()
    private var exts: List<Ext> = emptyList()
    private val scriptCache = HashMap<String, String>()
    private val shim: String by lazy {
        ctx.assets.open("ext_shim.js").use { String(it.readBytes(), Charsets.UTF_8) }
    }

    // 페이지가 마음대로 확장 저장소를 읽지 못하게, 매 실행마다 새로 만드는 이름과 열쇠
    private val bridgeName = "EvExt" + UUID.randomUUID().toString().replace("-", "").take(12)
    private val token = UUID.randomUUID().toString().replace("-", "")
    private val session = HashMap<String, String>()
    private val handlers = Collections.synchronizedMap(WeakHashMap<WebView, MutableList<ScriptHandler>>())

    private val ui = Handler(Looper.getMainLooper())
    private val pool = java.util.concurrent.Executors.newCachedThreadPool()
    private val bgViews = HashMap<String, WebView>() // 화면 스레드에서만 만진다
    private val pages: MutableSet<WebView> = Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap<WebView, Boolean>()))
    private val pendingInstalled: MutableSet<String> = Collections.synchronizedSet(HashSet())

    /** 지금 보고 있는 (시크릿 아닌) 탭의 웹뷰 — tabs.query / tabs.sendMessage 용. MainActivity 가 채워 준다 */
    var activeWebView: (() -> WebView?)? = null

    /** 확장 프로그램이 새 탭을 열 때 (tabs.create · openOptionsPage) */
    var openTab: ((String) -> Unit)? = null

    val supported: Boolean by lazy { WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) }

    init {
        root.mkdirs()
        reload()
    }

    // ───────────────────────── 목록 ─────────────────────────

    fun list(): List<Ext> = synchronized(lock) { exts }

    private fun disabledIds(): MutableSet<String> {
        val set = HashSet<String>()
        try {
            if (indexFile.exists()) {
                val a = JSONObject(indexFile.readText()).optJSONArray("disabled")
                if (a != null) for (i in 0 until a.length()) set.add(a.getString(i))
            }
        } catch (e: Exception) { /* 읽지 못하면 모두 켜짐 */ }
        return set
    }

    private fun saveIndex() {
        val dis = JSONArray()
        exts.filter { !it.enabled }.forEach { dis.put(it.id) }
        try { indexFile.writeText(JSONObject().put("disabled", dis).toString()) } catch (e: Exception) { }
    }

    fun reload() = synchronized(lock) {
        scriptCache.clear()
        val dis = disabledIds()
        val out = ArrayList<Ext>()
        root.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name }?.forEach { d ->
            try { parse(d, d.name)?.let { it.enabled = it.id !in dis; out.add(it) } } catch (e: Exception) { }
        }
        exts = out.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    fun setEnabled(id: String, on: Boolean) = synchronized(lock) {
        exts.find { it.id == id }?.enabled = on
        scriptCache.keys.removeAll { it.startsWith("$id:") }
        saveIndex()
    }

    fun remove(id: String) = synchronized(lock) {
        File(root, id).deleteRecursively()
        File(dataDir, id).deleteRecursively()
        exts = exts.filter { it.id != id }
        scriptCache.keys.removeAll { it.startsWith("$id:") }
        saveIndex()
    }

    // ───────────────────────── 설치 ─────────────────────────

    /** .zip 또는 .crx 를 풀어 설치한다. 성공하면 이름을, 실패하면 예외(메시지는 사용자에게 보여 줄 말)를 던진다. */
    fun install(uri: Uri): Ext {
        val raw = ByteArrayOutputStream()
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                raw.write(buf, 0, n)
                if (raw.size() > MAX_ZIP) throw IllegalStateException("파일이 너무 커요 (80MB 이하만 가능)")
            }
        } ?: throw IllegalStateException("파일을 열 수 없어요")
        return installBytes(raw.toByteArray())
    }

    /**
     * 크롬 웹스토어 주소(또는 32자리 확장 프로그램 ID)로 .crx 를 받아 설치한다.
     * 구글 업데이트 서버(clients2.google.com)에서 크롬과 같은 방식으로 내려받는다.
     */
    fun installFromStore(input: String): Ext {
        val id = parseStoreId(input) ?: throw IllegalStateException("웹스토어 주소나 확장 프로그램 ID(영문 32자)를 확인해 주세요")
        val url = "https://clients2.google.com/service/update2/crx?response=redirect&os=android&arch=arm64&os_arch=arm64" +
            "&nacl_arch=arm&prod=chromecrx&prodchannel=stable&prodversion=$STORE_CHROME_VERSION" +
            "&acceptformat=crx2,crx3&x=" + java.net.URLEncoder.encode("id=$id&uc", "UTF-8")
        var conn: java.net.HttpURLConnection? = null
        try {
            conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 30000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$STORE_CHROME_VERSION Mobile Safari/537.36")
            }
            val code = conn.responseCode
            if (code == 204 || code == 404) throw IllegalStateException("웹스토어에서 이 확장 프로그램을 찾지 못했어요 (없어졌거나 내려받을 수 없는 항목)")
            if (code !in 200..299) throw IllegalStateException("웹스토어 서버 응답 오류 ($code)")
            val raw = ByteArrayOutputStream()
            conn.inputStream.use { ins ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    raw.write(buf, 0, n)
                    if (raw.size() > MAX_ZIP) throw IllegalStateException("파일이 너무 커요 (80MB 이하만 가능)")
                }
            }
            return installBytes(raw.toByteArray())
        } catch (e: IllegalStateException) {
            throw e
        } catch (e: java.io.IOException) {
            throw IllegalStateException("웹스토어에 연결하지 못했어요. 인터넷 연결을 확인해 주세요")
        } finally {
            try { conn?.disconnect() } catch (e: Exception) { }
        }
    }

    /** .zip / .crx 바이트를 풀어 설치한다 */
    private fun installBytes(bytes: ByteArray): Ext {
        if (bytes.size < 4) throw IllegalStateException("올바른 확장 프로그램 파일이 아니에요")

        // crx 머리글 건너뛰기
        var start = 0
        if (bytes[0] == 'C'.code.toByte() && bytes[1] == 'r'.code.toByte() && bytes[2] == '2'.code.toByte() && bytes[3] == '4'.code.toByte()) {
            fun le(o: Int) = (bytes[o].toInt() and 0xFF) or ((bytes[o + 1].toInt() and 0xFF) shl 8) or
                ((bytes[o + 2].toInt() and 0xFF) shl 16) or ((bytes[o + 3].toInt() and 0xFF) shl 24)
            start = when (le(4)) {
                3 -> 12 + le(8)
                2 -> 16 + le(8) + le(12)
                else -> throw IllegalStateException("지원하지 않는 crx 형식이에요")
            }
            if (start <= 0 || start >= bytes.size) throw IllegalStateException("crx 파일이 손상됐어요")
        }

        val tmp = File(root, ".tmp_" + UUID.randomUUID().toString().take(8))
        tmp.mkdirs()
        try {
            var total = 0L
            val tmpCanon = tmp.canonicalPath
            ZipInputStream(ByteArrayInputStream(bytes, start, bytes.size - start)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val name = e.name.replace('\\', '/')
                    if (name.startsWith("__MACOSX/") || name.isEmpty()) continue
                    val f = File(tmp, name)
                    if (!f.canonicalPath.startsWith(tmpCanon + File.separator)) continue // 폴더 밖으로 나가는 경로 차단
                    if (e.isDirectory) { f.mkdirs(); continue }
                    f.parentFile?.mkdirs()
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_UNPACKED) throw IllegalStateException("압축을 풀면 너무 커요")
                            out.write(buf, 0, n)
                        }
                    }
                }
            }
            // manifest.json 이 있는 가장 얕은 폴더를 확장 프로그램 폴더로 본다
            val manifest = tmp.walkTopDown().filter { it.isFile && it.name == "manifest.json" }
                .minByOrNull { it.relativeTo(tmp).path.count { c -> c == File.separatorChar } }
                ?: throw IllegalStateException("manifest.json 이 없어요 (확장 프로그램 zip/crx 가 아니에요)")
            val base = manifest.parentFile!!
            val mj = readJson(manifest)
            val name0 = mj.optString("name")
            if (name0.isBlank() || mj.optString("version").isBlank()) throw IllegalStateException("manifest.json 에 name/version 이 없어요")
            val id = makeId(mj, name0)
            val dest = File(root, id)
            synchronized(lock) {
                dest.deleteRecursively()
                if (!base.renameTo(dest)) {
                    base.copyRecursively(dest, true)
                }
            }
            val ext = parse(dest, id) ?: throw IllegalStateException("manifest.json 을 읽지 못했어요")
            pendingInstalled.add(id)
            synchronized(lock) {
                ext.enabled = true
                exts = (exts.filter { it.id != id } + ext).sortedBy { it.name.lowercase(Locale.ROOT) }
                scriptCache.keys.removeAll { it.startsWith("$id:") }
                saveIndex()
            }
            return ext
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun readJson(f: File): JSONObject {
        var s = f.readText(Charsets.UTF_8)
        if (s.startsWith("\uFEFF")) s = s.substring(1)
        return JSONObject(s)
    }

    private fun makeId(mj: JSONObject, name: String): String {
        val seed = mj.optString("key").ifEmpty { "evergreen:$name" }
        val d = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        val sb = StringBuilder()
        for (i in 0 until 16) {
            val b = d[i].toInt() and 0xFF
            sb.append(('a' + (b shr 4))).append(('a' + (b and 0x0F)))
        }
        return sb.toString()
    }

    // ───────────────────────── 매니페스트 읽기 ─────────────────────────

    private fun loadMessages(dir: File, mj: JSONObject): Map<String, String> {
        val loc = File(dir, "_locales")
        if (!loc.isDirectory) return emptyMap()
        val names = loc.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: return emptyMap()
        val lang = Locale.getDefault().language
        val def = mj.optString("default_locale")
        val pick = listOf(Locale.getDefault().toString(), lang, def, "en", "en_US", "en_GB")
            .firstOrNull { it.isNotEmpty() && it in names } ?: names.firstOrNull() ?: return emptyMap()
        val f = File(loc, "$pick/messages.json")
        if (!f.exists()) return emptyMap()
        val out = HashMap<String, String>()
        try {
            val o = readJson(f)
            for (k in o.keys()) {
                val item = o.optJSONObject(k) ?: continue
                var msg = item.optString("message")
                item.optJSONObject("placeholders")?.let { ph ->
                    for (pk in ph.keys()) {
                        val c = ph.optJSONObject(pk)?.optString("content") ?: continue
                        msg = msg.replace("\$$pk\$", c, ignoreCase = true)
                    }
                }
                out[k.lowercase(Locale.ROOT)] = msg
            }
        } catch (e: Exception) { }
        return out
    }

    private fun parse(dir: File, id: String): Ext? {
        val mf = File(dir, "manifest.json")
        if (!mf.exists()) return null
        val mj = readJson(mf)
        val msgs = loadMessages(dir, mj)
        fun loc(s: String): String = Regex("__MSG_([A-Za-z0-9_@]+)__").replace(s) { m ->
            msgs[m.groupValues[1].lowercase(Locale.ROOT)] ?: m.value
        }
        val entries = ArrayList<Entry>()
        val cs = mj.optJSONArray("content_scripts")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.optJSONObject(i) ?: continue
            fun strs(k: String): List<String> {
                val a = c.optJSONArray(k) ?: return emptyList()
                return (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
            }
            val m = strs("matches")
            if (m.isEmpty()) continue
            entries.add(
                Entry(
                    m, strs("exclude_matches"), strs("js"), strs("css"),
                    c.optString("run_at", "document_idle"), c.optBoolean("all_frames", false)
                )
            )
        }
        val bg = mj.optJSONObject("background")
        val action = mj.optJSONObject("action") ?: mj.optJSONObject("browser_action") ?: mj.optJSONObject("page_action")
        val optUi = mj.optJSONObject("options_ui")?.optString("page")?.takeIf { it.isNotEmpty() }
        val options = optUi ?: mj.optString("options_page").takeIf { it.isNotEmpty() }
        val popup = action?.optString("default_popup")?.takeIf { it.isNotEmpty() }
        var icon: String? = null
        fun bestIcon(o: JSONObject?): String? {
            o ?: return null
            val best = o.keys().asSequence().mapNotNull { it.toIntOrNull() }.maxOrNull() ?: return null
            return o.optString(best.toString()).takeIf { it.isNotEmpty() }
        }
        icon = bestIcon(mj.optJSONObject("icons"))
        if (icon == null) {
            val di = action?.opt("default_icon")
            icon = when (di) {
                is String -> di
                is JSONObject -> bestIcon(di)
                else -> null
            }
        }
        val hostPats = ArrayList<String>()
        for (k in listOf("host_permissions", "optional_host_permissions", "permissions", "optional_permissions")) {
            val a = mj.optJSONArray(k) ?: continue
            for (i in 0 until a.length()) {
                val h = a.optString(i)
                if (h == "<all_urls>" || h.contains("://")) hostPats.add(h)
            }
        }
        val hosts = hostPats.mapNotNull { patternToRegex(it) }.mapNotNull { try { Regex(it) } catch (e: Exception) { null } }
        return Ext(
            id = id,
            name = loc(mj.optString("name")),
            version = mj.optString("version"),
            description = loc(mj.optString("description")),
            manifestVersion = mj.optInt("manifest_version", 2),
            dir = dir,
            manifest = mj,
            entries = entries,
            hasBackground = bg != null && (bg.has("service_worker") || bg.has("scripts") || bg.has("page")),
            options = options,
            popup = popup,
            icon = icon,
            messages = msgs,
            hosts = hosts,
            enabled = true
        )
    }

    fun iconBitmap(e: Ext): Bitmap? {
        val p = e.icon ?: return null
        return try {
            val f = File(e.dir, p.removePrefix("/"))
            if (f.canonicalPath.startsWith(e.dir.canonicalPath) && f.exists()) BitmapFactory.decodeFile(f.path) else null
        } catch (ex: Exception) { null }
    }

    /** 새 탭에서 열 수 있는 확장 프로그램 내부 페이지 주소 (옵션 · 팝업) */
    fun pageUrl(e: Ext, path: String): String = "https://$HOST/${e.id}/" + path.removePrefix("/")

    // ───────────────────────── 웹페이지에 넣기 ─────────────────────────

    private fun esc(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in ".+?^$()|[]{}\\") sb.append('\\')
            sb.append(c)
        }
        return sb.toString()
    }

    /** 크롬의 match pattern 을 JS 정규식 문자열로 바꾼다 (잘못된 패턴이면 null) */
    private fun patternToRegex(p: String): String? {
        if (p == "<all_urls>") return "^https?://.*$"
        val m = Regex("^(\\*|https?|file|ftp)://([^/]*)(/.*)$").matchEntire(p) ?: return null
        val scheme = m.groupValues[1]
        val host = m.groupValues[2]
        val path = m.groupValues[3]
        val s = if (scheme == "*") "https?" else scheme
        val h = when {
            scheme == "file" -> esc(host)
            host == "*" -> "[^/:]+"
            host.startsWith("*.") -> "([^/:]+\\.)?" + esc(host.substring(2))
            else -> esc(host)
        }
        val port = if (scheme == "file") "" else "(:\\d+)?"
        val pa = path.split("*").joinToString(".*") { esc(it) }
        return "^$s://$h$port$pa$"
    }

    private fun readText(e: Ext, rel: String): String? {
        return try {
            val f = File(e.dir, rel.removePrefix("/"))
            if (!f.canonicalPath.startsWith(e.dir.canonicalPath + File.separator) || !f.isFile) null
            else f.readText(Charsets.UTF_8)
        } catch (ex: Exception) { null }
    }

    private fun msgsJson(e: Ext): String {
        val o = JSONObject()
        e.messages.forEach { (k, v) -> o.put(k, v) }
        return o.toString()
    }

    private fun makeCall(e: Ext): String =
        "__evxMake(${JSONObject.quote(e.id)},${e.manifest},${msgsJson(e)},window[${JSONObject.quote(bridgeName)}],${JSONObject.quote(token)})"

    private fun buildScript(e: Ext, idx: Int): String? {
        val en = e.entries[idx]
        val key = "${e.id}:$idx"
        synchronized(lock) { scriptCache[key]?.let { return it } }
        val inc = en.matches.mapNotNull { patternToRegex(it) }
        if (inc.isEmpty()) return null
        val exc = en.excludes.mapNotNull { patternToRegex(it) }
        val js = StringBuilder()
        for (f in en.js) readText(e, f)?.let { js.append(it).append("\n;\n") }
        val css = StringBuilder()
        for (f in en.css) readText(e, f)?.let { css.append(it).append("\n") }
        if (js.isEmpty() && css.isEmpty()) return null
        val sb = StringBuilder()
        sb.append("(function(){\n")
        sb.append("if(location.hostname===${JSONObject.quote(HOST)})return;\n")
        sb.append("var __h=location.href.split('#')[0];\n")
        sb.append("var __i=").append(JSONArray(inc)).append(",__x=").append(JSONArray(exc)).append(";\n")
        sb.append("function __t(a){for(var i=0;i<a.length;i++){try{if(new RegExp(a[i]).test(__h))return true}catch(e){}}return false}\n")
        sb.append("if(!__t(__i)||__t(__x))return;\n")
        if (!en.allFrames) sb.append("if(window.top!==window)return;\n")
        sb.append("var __k=${JSONObject.quote("__evx_$key")};\n")
        sb.append("if(window[__k])return;try{Object.defineProperty(window,__k,{value:1})}catch(e){window[__k]=1}\n")
        // 진단: 적용됐는지 · 확장 주소의 파일이 보안 정책(CSP)에 막혔는지 · 오류가 났는지를 앱에 알린다 (확장 프로그램 화면의 '진단')
        sb.append("var __B=window[").append(q(bridgeName)).append("],__T=").append(q(token)).append(";\n")
        sb.append("function __lg(k,m){try{__B.log(").append(q(e.id)).append(",k,String(m).slice(0,300),__T)}catch(x){}}\n")
        sb.append("__lg('적용', location.href);\n")
        sb.append("try{document.addEventListener('securitypolicyviolation',function(v){__lg('CSP 차단',v.violatedDirective+' '+v.blockedURI)},true)}catch(x){}\n")
        sb.append("try{window.addEventListener('error',function(v){var t=v.target;var u=t&&t!==window?String(t.src||t.href||''):String(v.filename||'');")
            .append("if(u.indexOf(").append(q(HOST)).append(")>=0)__lg(t&&t!==window?'파일 불러오기 실패':'스크립트 오류',(t&&t!==window?u:(v.message+' @'+u+':'+v.lineno)))},true)}catch(x){}\n")
        sb.append(shim).append("\n")
        sb.append("var chrome=").append(makeCall(e)).append(",browser=chrome;\n")
        if (css.isNotEmpty()) {
            sb.append("function __css(){var s=document.createElement('style');s.textContent=")
                .append(JSONObject.quote(css.toString()))
                .append(";(document.head||document.documentElement).appendChild(s)}\n")
            sb.append("if(document.documentElement)__css();else{var __mo=new MutationObserver(function(){if(document.documentElement){__mo.disconnect();__css()}});__mo.observe(document,{childList:true})}\n")
        }
        if (js.isNotEmpty()) {
            // 확장 스크립트가 globalThis.chrome / globalThis.browser 로 API 를 찾는 경우를 위해, 그 스크립트가 보는 globalThis 에만 chrome 을 얹는다 (페이지의 window 는 건드리지 않는다)
            sb.append("var __G;try{__G=new Proxy(window,{get:function(t,k){if(k==='chrome')return chrome;if(k==='browser')return browser;var v=t[k];return typeof v==='function'&&!/^[A-Z]/.test(String(k))?v.bind(t):v},set:function(t,k,v){t[k]=v;return true},has:function(t,k){return k==='chrome'||k==='browser'||k in t}})}catch(x){__G=window}\n")
            sb.append("function __run(){try{(function(chrome,browser,globalThis){\n").append(js).append("\n})(chrome,browser,__G)}catch(e){console.error(${JSONObject.quote("[Evergreen 확장] " + e.name)},e);__lg('실행 오류',(e&&e.stack)||e)}}\n")
            when (en.runAt) {
                // 웹뷰의 문서 시작 스크립트는 <html> 이 생기기 전에 돌 수 있다 (크롬은 항상 있다) → 생길 때까지 기다렸다가 돌린다
                "document_start" -> sb.append("if(document.documentElement)__run();else{var __mr=new MutationObserver(function(){if(document.documentElement){__mr.disconnect();__run()}});__mr.observe(document,{childList:true})}\n")
                "document_end" -> sb.append("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',__run,{once:true});else __run();\n")
                else -> sb.append("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(__run,0)},{once:true});else setTimeout(__run,0);\n")
            }
        }
        sb.append("})();")
        val out = sb.toString()
        synchronized(lock) { scriptCache[key] = out }
        return out
    }

    private val diag = HashMap<String, java.util.ArrayDeque<String>>()

    private fun diagAdd(id: String, line: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
        synchronized(diag) {
            val q = diag.getOrPut(id) { java.util.ArrayDeque() }
            // 같은 줄이 연달아 오면 한 번만 남긴다
            if (q.peekLast()?.substring(10) == line) return
            q.addLast("$t  $line")
            while (q.size > 40) q.pollFirst()
        }
    }

    /** 확장 프로그램 화면의 '진단'에 보여 줄 기록 (오래된 것부터) */
    fun diagLines(id: String): List<String> = synchronized(diag) { diag[id]?.toList() ?: emptyList() }

    fun diagClear(id: String) { synchronized(diag) { diag.remove(id) } }

    inner class Bridge {
        @JavascriptInterface
        fun log(id: String, kind: String, msg: String, t: String) {
            if (t != token || id.length > 40 || kind.length > 24 || msg.length > 400) return
            diagAdd(id, "$kind: $msg")
        }

        @JavascriptInterface
        fun sget(id: String, area: String, t: String): String {
            if (t != token) return "{}"
            return readArea(id, area)
        }

        @JavascriptInterface
        fun sset(id: String, area: String, json: String, t: String) {
            if (t != token || json.length > MAX_AREA_JSON) return
            writeArea(id, area, json)
        }

        /** 콘텐츠 스크립트 · 팝업 → 백그라운드: runtime.sendMessage */
        @JavascriptInterface
        fun send(id: String, msg: String, url: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || msg.length > MAX_MSG) return
            ui.post {
                val bg = bgViews[id]
                if (bg == null) { respondPages(cid, ""); return@post }
                val sender = JSONObject().put("id", id).put("url", url)
                if (!url.startsWith("https://$HOST/")) {
                    sender.put("tab", JSONObject().put("id", 1).put("url", url).put("active", true).put("windowId", 1))
                }
                bg.evaluateJavascript(
                    "window.__evxBgIn&&window.__evxBgIn(${JSONObject.quote(cid)},${JSONObject.quote(msg)},${JSONObject.quote(sender.toString())})", null
                )
            }
        }

        /** 백그라운드의 답장 → 요청한 페이지 */
        @JavascriptInterface
        fun bgresp(id: String, cid: String, json: String, t: String) {
            if (t != token || cid.length > 80 || json.length > MAX_MSG) return
            respondPages(cid, json)
        }

        /** 백그라운드 → 보고 있는 탭의 콘텐츠 스크립트: tabs.sendMessage */
        @JavascriptInterface
        fun tabsend(id: String, msg: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || msg.length > MAX_MSG) return
            ui.post {
                val wv = try { activeWebView?.invoke() } catch (e: Exception) { null }
                if (wv == null) { respondBg(id, cid, ""); return@post }
                val sender = JSONObject().put("id", id).toString()
                wv.evaluateJavascript(
                    "(window.__evxTabIn?(window.__evxTabIn(${JSONObject.quote(id)},${JSONObject.quote(cid)},${JSONObject.quote(msg)},${JSONObject.quote(sender)}),1):0)"
                ) { r -> if (r == "0" || r == "null") respondBg(id, cid, "") }
            }
        }

        /** 콘텐츠 스크립트의 답장 → 백그라운드 */
        @JavascriptInterface
        fun pageresp(id: String, cid: String, json: String, t: String) {
            if (t != token || cid.length > 80 || json.length > MAX_MSG) return
            respondBg(id, cid, json)
        }

        /** tabs.query / tabs.get: 보고 있는 탭 하나 */
        @JavascriptInterface
        fun tabinfo(id: String, t: String): String {
            if (t != token) return "[]"
            val latch = java.util.concurrent.CountDownLatch(1)
            var out = "[]"
            ui.post {
                try {
                    val wv = activeWebView?.invoke()
                    if (wv != null) {
                        out = JSONArray().put(
                            JSONObject().put("id", 1).put("index", 0).put("windowId", 1).put("active", true)
                                .put("highlighted", true).put("url", wv.url ?: "").put("title", wv.title ?: "")
                        ).toString()
                    }
                } catch (e: Exception) { }
                latch.countDown()
            }
            latch.await(800, java.util.concurrent.TimeUnit.MILLISECONDS)
            return out
        }

        @JavascriptInterface
        fun opentab(id: String, url: String, t: String) {
            if (t != token || url.length > 4000) return
            val u = url.trim()
            if (!u.startsWith("https://") && !u.startsWith("http://")) return
            ui.post { openTab?.invoke(u) }
        }

        /** 백그라운드의 fetch: host 권한이 있는 주소만 앱이 대신 요청해 CORS 없이 돌려준다 */
        @JavascriptInterface
        fun xfetch(id: String, url: String, method: String, headers: String, body: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || body.length > MAX_MSG * 3) return
            pool.execute {
                val out = try { doFetch(id, url, method, headers, body) }
                catch (e: Exception) { JSONObject().put("error", e.message ?: "error").toString() }
                respondBg(id, cid, out)
            }
        }
    }

    private fun q(s: String) = JSONObject.quote(s)

    private fun respondPages(cid: String, json: String) {
        val js = "window.__evxResp&&window.__evxResp(${q(cid)},${q(json)})"
        ui.post {
            val all = synchronized(pages) { pages.toList() }
            all.forEach { try { it.evaluateJavascript(js, null) } catch (e: Exception) { } }
        }
    }

    private fun respondBg(id: String, cid: String, json: String) {
        val js = "window.__evxResp&&window.__evxResp(${q(cid)},${q(json)})"
        ui.post { try { bgViews[id]?.evaluateJavascript(js, null) } catch (e: Exception) { } }
    }

    private fun doFetch(id: String, url: String, method: String, headers: String, body: String): String {
        val e = list().find { it.id == id && it.enabled } ?: throw IllegalStateException("disabled")
        if (!url.startsWith("https://") && !url.startsWith("http://")) throw IllegalStateException("scheme")
        if (e.hosts.none { it.matches(url) }) throw IllegalStateException("no host permission")
        val m = method.uppercase(Locale.ROOT)
        if (m !in setOf("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS")) throw IllegalStateException("method")
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.instanceFollowRedirects = true
            conn.requestMethod = m
            var hasUa = false
            val hj = try { JSONObject(headers) } catch (ex: Exception) { JSONObject() }
            for (k in hj.keys()) {
                val lk = k.lowercase(Locale.ROOT)
                if (lk in setOf("host", "content-length", "connection", "cookie", "origin", "referer") || lk.startsWith("sec-") || lk.startsWith("proxy-")) continue
                if (lk == "user-agent") hasUa = true
                conn.setRequestProperty(k, hj.optString(k))
            }
            if (!hasUa) conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$STORE_CHROME_VERSION Mobile Safari/537.36")
            if (body.isNotEmpty() && m != "GET" && m != "HEAD") {
                conn.doOutput = true
                conn.outputStream.use { it.write(Base64.decode(body, Base64.DEFAULT)) }
            }
            val code = conn.responseCode
            val ins = try { conn.inputStream } catch (ex: java.io.IOException) { conn.errorStream }
            val bos = ByteArrayOutputStream()
            if (ins != null && m != "HEAD") ins.use {
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = it.read(buf)
                    if (n < 0) break
                    bos.write(buf, 0, n)
                    if (bos.size() > MAX_FETCH) throw IllegalStateException("too large")
                }
            }
            val hs = JSONObject()
            conn.headerFields?.forEach { (k, v) -> if (k != null && v != null) hs.put(k, v.joinToString(", ")) }
            return JSONObject().put("status", code).put("statusText", conn.responseMessage ?: "")
                .put("headers", hs).put("body", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)).toString()
        } finally {
            conn.disconnect()
        }
    }

    // ───────────────────────── 백그라운드 페이지 ─────────────────────────

    /** 켜진 확장 프로그램의 백그라운드를 (다시) 시작하고, 꺼지거나 지워진 것은 끈다. 화면 스레드에서 부른다 */
    fun syncBackground() {
        bgViews.keys.toList().forEach { stopBg(it) }
        if (!supported) return
        list().filter { it.enabled && it.hasBackground }.forEach { startBg(it) }
    }

    private fun stopBg(id: String) {
        val wv = bgViews.remove(id) ?: return
        try {
            wv.stopLoading()
            wv.loadUrl("about:blank")
            wv.removeJavascriptInterface(bridgeName)
            wv.destroy()
        } catch (e: Exception) { }
    }

    fun destroyBackground() { bgViews.keys.toList().forEach { stopBg(it) } }

    private fun startBg(e: Ext) {
        try {
            val wv = WebView(ctx)
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = true
            }
            wv.addJavascriptInterface(bridge, bridgeName)
            wv.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    if (request.url.host == HOST) serve(request.url) else null

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
            }
            bgViews[e.id] = wv
            val bg = e.manifest.optJSONObject("background")
            val page = if (bg != null && bg.optString("service_worker").isEmpty()) bg.optString("page").takeIf { it.isNotEmpty() } else null
            val target = if (page != null) page.removePrefix("/") else BG_PAGE
            wv.loadUrl("https://$HOST/${e.id}/$target?__evxbg=1")
        } catch (ex: Exception) {
            bgViews.remove(e.id)
        }
    }

    private fun bgHtml(e: Ext): String {
        val bg = e.manifest.optJSONObject("background")
        val sb = StringBuilder("<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body>")
        val sw = bg?.optString("service_worker").orEmpty()
        val module = bg?.optString("type") == "module"
        fun tag(src: String) = "<script" + (if (module) " type=\"module\"" else "") + " src=\"" +
            src.removePrefix("/").replace("\"", "&quot;") + "\"></script>"
        if (sw.isNotEmpty()) sb.append(tag(sw))
        else bg?.optJSONArray("scripts")?.let { a ->
            for (i in 0 until a.length()) a.optString(i).takeIf { it.isNotEmpty() }?.let { sb.append(tag(it)) }
        }
        sb.append("</body></html>")
        return injectHtml(e, sb.toString(), true)
    }

    private fun injectHtml(e: Ext, html: String, bg: Boolean): String {
        val flags = StringBuilder()
        if (bg) {
            flags.append("window.__evxIsBg=true;")
            if (pendingInstalled.remove(e.id)) flags.append("window.__evxInstalled=true;")
        }
        val inject = "<script>$flags$shim\nwindow.chrome=window.browser=${makeCall(e)};</script>"
        val at = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
        return if (at != null) html.substring(0, at.range.last + 1) + inject + html.substring(at.range.last + 1) else inject + html
    }

    private val bridge = Bridge()

    private fun areaFile(id: String, area: String): File? {
        if (id.isEmpty() || !id.all { it in 'a'..'z' }) return null
        if (area !in listOf("local", "sync", "managed")) return null
        return File(dataDir, "$id/$area.json")
    }

    private fun readArea(id: String, area: String): String {
        if (area == "session") return synchronized(session) { session["$id:$area"] ?: "{}" }
        val f = areaFile(id, area) ?: return "{}"
        return try { if (f.exists()) f.readText() else "{}" } catch (e: Exception) { "{}" }
    }

    private fun writeArea(id: String, area: String, json: String) {
        if (area == "session") { synchronized(session) { session["$id:$area"] = json }; return }
        val f = areaFile(id, area) ?: return
        try {
            f.parentFile?.mkdirs()
            f.writeText(json)
        } catch (e: Exception) { }
    }

    /** 웹뷰 하나에 확장 프로그램을 연결한다. 이미 연결돼 있으면 먼저 떼고 다시 붙인다. */
    fun attach(wv: WebView, incognito: Boolean) {
        detach(wv)
        try { wv.addJavascriptInterface(bridge, bridgeName) } catch (e: Exception) { }
        pages.add(wv)
        if (incognito || !supported) return // 크롬처럼 시크릿 탭에서는 확장 프로그램을 쓰지 않는다
        val hs = ArrayList<ScriptHandler>()
        for (e in list()) {
            if (!e.enabled) continue
            for (i in e.entries.indices) {
                val s = buildScript(e, i) ?: continue
                try { hs.add(WebViewCompat.addDocumentStartJavaScript(wv, s, setOf("*"))) } catch (ex: Exception) { }
            }
        }
        if (hs.isNotEmpty()) handlers[wv] = hs
    }

    fun detach(wv: WebView) {
        pages.remove(wv)
        handlers.remove(wv)?.forEach { try { it.remove() } catch (e: Exception) { } }
    }

    // ───────────────────────── 앱 안 팝업 웹뷰 ─────────────────────────

    /**
     * 확장 프로그램 팝업(action.default_popup)을 앱 안 카드로 띄울 때 쓰는 웹뷰.
     * 확장 프로그램 파일을 직접 받아 오고 chrome.* 연결을 붙인다. 링크는 [onLink] 로 넘겨 새 탭에서 열게 한다.
     */
    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    fun newPopupView(onLink: (String) -> Unit): WebView {
        val wv = WebView(ctx)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }
        wv.addJavascriptInterface(bridge, bridgeName)
        pages.add(wv)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.host == HOST) serve(request.url) else null

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                if (u.host == HOST) return false
                val s = u.toString()
                if (s.startsWith("http://") || s.startsWith("https://")) onLink(s)
                return true
            }
        }
        return wv
    }

    fun releasePopupView(wv: WebView) {
        pages.remove(wv)
        try { (wv.parent as? android.view.ViewGroup)?.removeView(wv); wv.stopLoading(); wv.destroy() } catch (e: Exception) { }
    }

    // ───────────────────────── 확장 프로그램 파일 제공 ─────────────────────────

    /** https://ext.evergreen.invalid/<id>/<경로> 요청에 확장 프로그램 안의 파일을 돌려준다 */
    fun serve(uri: Uri): WebResourceResponse? {
        val segs = uri.pathSegments
        if (segs.isEmpty()) return notFound()
        val e = list().find { it.id == segs[0] } ?: return notFound()
        val rel = segs.drop(1).joinToString("/")
        if (rel == BG_PAGE) {
            return WebResourceResponse(
                "text/html", "utf-8", 200, "OK",
                hashMapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache"),
                ByteArrayInputStream(bgHtml(e).toByteArray(Charsets.UTF_8))
            )
        }
        val f = File(e.dir, rel)
        try {
            if (!f.canonicalPath.startsWith(e.dir.canonicalPath + File.separator) || !f.isFile) return notFound()
        } catch (ex: Exception) { return notFound() }
        val ext = f.extension.lowercase(Locale.ROOT)
        val mime = when (ext) {
            "js", "mjs" -> "text/javascript"
            "json" -> "application/json"
            "css" -> "text/css"
            "html", "htm" -> "text/html"
            "svg" -> "image/svg+xml"
            "woff2" -> "font/woff2"
            "woff" -> "font/woff"
            "wasm" -> "application/wasm"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
        val headers = hashMapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache")
        val stream: InputStream = if (mime == "text/html") {
            // 옵션/팝업 페이지: 맨 앞에 chrome.* 를 넣어 준다
            val html = f.readText(Charsets.UTF_8)
            val merged = injectHtml(e, html, uri.getQueryParameter("__evxbg") == "1")
            ByteArrayInputStream(merged.toByteArray(Charsets.UTF_8))
        } else f.inputStream()
        return WebResourceResponse(mime, if (mime.startsWith("text/") || mime == "application/json") "utf-8" else null, 200, "OK", headers, stream)
    }

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", hashMapOf("Access-Control-Allow-Origin" to "*"),
        ByteArrayInputStream(ByteArray(0))
    )
}
