package com.example.evergreen

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import java.net.URLEncoder

/**
 * 성인 모드 > 「키워드 추천」: 지금 열려 있는 사이트의 페이지에서 영상 목록을 읽어, 내가 등록해 둔 키워드가 들어갔거나 비슷한 영상을 골라 준다.
 *  - 페이지를 읽는 것도 계산도 모두 폰 안에서만 한다. 키워드는 서버로 보내지 않고 이 앱의 설정(Prefs)에만 저장한다.
 *  - 영상 찾기 = 페이지의 링크 중 썸네일 · 영상 모양인 것을 [SCAN_JS] 로 모은다 (현재 탭 또는 열린 탭 전부).
 *  - 추천 = ① 제목/주소에 키워드가 들어간 영상(점수순) ② 키워드는 없지만 ①의 제목들에 자주 나온 낱말(= 비슷한 키워드)이 든 영상 ('비슷').
 */
object AdultReco {

    class PageItem(val url: String, val title: String, val site: String = "")
    /** similar=true 면 키워드가 직접 들어간 건 아니고 비슷한 낱말로 고른 것. matched 는 맞은 키워드(또는 비슷한 낱말) */
    class Hit(val url: String, val title: String, val site: String, val score: Int, val matched: List<String>, val similar: Boolean)
    class Result(val hits: List<Hit>, val related: List<String>, val scanned: Int)

    const val MAX_KEYWORDS = 30

    /** 페이지에서 영상 링크 후보를 JSON 문자열로 돌려준다: [{u:주소, t:제목}, ...] (최대 400개) */
    const val SCAN_JS = """(function(){try{var out=[],seen={},here=location.href.split('#')[0];
var as=document.querySelectorAll('a[href]');
for(var i=0;i<as.length&&out.length<400;i++){var a=as[i],h=a.href;
if(!/^https?:/.test(h)||seen[h]||h.split('#')[0]===here)continue;
var img=a.querySelector('img,video,picture');
var vid=!!a.querySelector('[class*=duration],[class*=thumb],[class*=video],[class*=preview]')||/video|watch|view|movie|embed|play|\/v\//i.test(h);
if(!img&&!vid)continue;
var t=(a.getAttribute('title')||(img&&(img.getAttribute('alt')||img.getAttribute('title')))||a.textContent||'').replace(/\s+/g,' ').trim();
if(t.length<2)continue;seen[h]=1;out.push({u:h,t:t.slice(0,160)});}
return JSON.stringify(out)}catch(e){return '[]'}})()"""

    private val STOP = setOf(
        "the", "and", "for", "with", "from", "video", "videos", "free", "full", "new", "best", "hd", "www", "com", "http", "https",
        "영상", "동영상", "무료", "다시보기", "보기", "최신", "모음", "시리즈", "채널", "min", "sec", "views"
    )

    fun norm(s: String): String = s.trim().lowercase().replace(Regex("\\s+"), " ")

    /** 쉼표 · 줄바꿈으로 여러 개를 한꺼번에 넣을 수 있다. 중복 · 빈 값 제거, 최대 [MAX_KEYWORDS] 개 */
    fun addKeywords(current: List<String>, input: String): List<String> {
        val out = LinkedHashSet<String>(current)
        for (p in input.split(',', '\n', '，', '、')) {
            val k = norm(p).take(40)
            if (k.length >= 2) out.add(k)
        }
        return out.take(MAX_KEYWORDS)
    }

    fun tokens(text: String): List<String> =
        text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 && it !in STOP && !it.all(Char::isDigit) }

    /** [SCAN_JS] 가 돌려준 글(evaluateJavascript 결과: 따옴표로 싼 JSON 문자열)을 항목 목록으로 바꾼다 */
    fun parseScan(raw: String?, site: String): List<PageItem> = runCatching {
        if (raw.isNullOrBlank() || raw == "null") return emptyList()
        val inner = org.json.JSONTokener(raw).nextValue() as? String ?: return emptyList()
        val arr = JSONArray(inner)
        List(arr.length()) { val o = arr.getJSONObject(it); PageItem(o.getString("u"), o.optString("t"), site) }
    }.getOrDefault(emptyList())

    /** 여러 탭에서 모은 영상 중 같은 주소는 하나로 합친다 */
    fun dedupe(items: List<PageItem>): List<PageItem> = items.distinctBy { it.url }

    fun recommend(keywords: List<String>, items: List<PageItem>, limit: Int = 40): Result {
        val kws = keywords.map(::norm).filter { it.isNotEmpty() }.distinct()
        val all = dedupe(items)
        if (kws.isEmpty() || all.isEmpty()) return Result(emptyList(), emptyList(), all.size)

        val direct = ArrayList<Hit>()
        val rest = ArrayList<PageItem>()
        for (it in all) {
            val t = it.title.lowercase(); val u = it.url.lowercase()
            var score = 0; val m = ArrayList<String>()
            for (k in kws) {
                val inT = t.contains(k)
                val inU = u.contains(k) || u.contains(k.replace(' ', '-')) || u.contains(k.replace(' ', '+')) || u.contains(k.replace(' ', '_'))
                if (inT || inU) { score += (if (inT) 3 else 0) + (if (inU) 1 else 0); m.add(k) }
            }
            if (m.isEmpty()) rest.add(it) else direct.add(Hit(it.url, it.title.ifBlank { it.url }, it.site, score + 2 * (m.size - 1), m, false))
        }
        direct.sortByDescending { it.score }

        // 비슷한 키워드: 맞은 제목에 같이 나온 낱말 (직접 맞은 영상이 3개 미만이면 한 번만 나와도 인정)
        val have = kws.flatMap { tokens(it) }.toSet() + kws
        val freq = HashMap<String, Int>()
        for (h in direct) for (w in tokens(h.title).toSet()) if (w !in have) freq[w] = (freq[w] ?: 0) + 1
        val need = if (direct.size >= 3) 2 else 1
        val related = freq.entries.filter { it.value >= need }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(8).map { it.key }

        // 비슷한 영상: 키워드는 없지만 비슷한 낱말이 든 것 (겹치는 낱말이 많을수록 앞)
        val similar = ArrayList<Hit>()
        if (related.isNotEmpty()) {
            val rel = related.toSet()
            for (it in rest) {
                val shared = tokens(it.title).filter { w -> w in rel }.distinct()
                if (shared.isNotEmpty()) similar.add(Hit(it.url, it.title.ifBlank { it.url }, it.site, shared.size, shared, true))
            }
            similar.sortByDescending { it.score }
        }
        return Result((direct + similar).take(limit), related, all.size)
    }

    // ───────── 저장 ─────────
    fun load(prefs: Prefs): List<String> = runCatching {
        val a = JSONArray(prefs.adultKeywords); List(a.length()) { a.getString(it) }
    }.getOrDefault(emptyList())

    fun save(prefs: Prefs, list: List<String>) { prefs.adultKeywords = JSONArray(list).toString() }

    // ───────── 화면 ─────────
    /**
     * [scan] 은 영상을 읽어 온다 (allTabs=false: 지금 탭, true: 열린 탭 전부). 다 읽으면 한 번 콜백한다.
     * [open] 은 주소를 새 탭으로 연다
     */
    fun show(act: Activity, prefs: Prefs, scan: (allTabs: Boolean, done: (List<PageItem>) -> Unit) -> Unit, open: (String) -> Unit) {
        val d = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val accent = act.getColor(R.color.ev_accent)
        val cOn = ThemeColors.get(act.window.decorView, com.google.android.material.R.attr.colorOnSurface, Color.BLACK)
        val cVar = ThemeColors.get(act.window.decorView, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)

        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val scroll = ScrollView(act).apply { addView(root) }
        val dlg = ThemedDialogBuilder(act).setTitle("키워드 추천").setView(scroll).setPositiveButton("닫기", null).create()

        fun label(t: String, size: Float = 12f, color: Int = cVar, bold: Boolean = false) = TextView(act).apply {
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, size); setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        fun chip(t: String, filled: Boolean, onClick: () -> Unit) = TextView(act).apply {
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(if (filled) Color.WHITE else cOn)
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                if (filled) setColor(accent) else { setColor(Color.TRANSPARENT); setStroke(dp(1), cVar) }
            }
            setOnClickListener { onClick() }
        }
        fun wrapRow(items: List<View>): View {
            val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            val maxW = act.resources.displayMetrics.widthPixels - dp(40 + 48)
            var line = LinearLayout(act); var used = 0
            box.addView(line)
            for (v in items) {
                v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
                val w = v.measuredWidth + dp(8)
                if (used + w > maxW && used > 0) { line = LinearLayout(act); box.addView(line); used = 0 }
                line.addView(v, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(4), dp(8), dp(4)) })
                used += w
            }
            return box
        }

        var items: List<PageItem> = emptyList()
        var scanning = false
        var scannedAll = false
        var everScanned = false

        fun doScan(all: Boolean, render: () -> Unit) {
            scanning = true; scannedAll = all; render()
            scan(all) { list -> act.runOnUiThread { items = list; scanning = false; everScanned = true; render() } }
        }

        fun render() {
            root.removeAllViews()
            val kws = load(prefs)

            root.addView(label("등록한 키워드 (${kws.size}/$MAX_KEYWORDS)", 13f, cOn, true))
            root.addView(label("누르면 지워요 · 쉼표로 여러 개를 한 번에 넣을 수 있어요 · 폰 안에만 저장돼요"))
            if (kws.isNotEmpty()) root.addView(wrapRow(kws.map { k -> chip("$k  ✕", true) { save(prefs, load(prefs) - k); render() } }))
            val input = EditText(act).apply {
                hint = "키워드 입력 (예: 키워드1, 키워드2)"; inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
                setTextColor(cOn); setHintTextColor(cVar)
            }
            root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            root.addView(chip("추가", true) {
                val before = load(prefs)
                val next = addKeywords(before, input.text.toString())
                if (next.size == before.size && input.text.isNotBlank()) AppToast.show(act, "이미 있거나 너무 짧아요 (2글자 이상)")
                save(prefs, next); render()
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4); gravity = Gravity.END })

            if (kws.isEmpty()) {
                root.addView(label("키워드를 등록하면, 열려 있는 사이트에서 그 키워드가 들어갔거나 비슷한 영상을 골라 줘요.", 13f).apply { setPadding(0, dp(18), 0, 0) })
                return
            }

            root.addView(label("영상 찾기", 13f, cOn, true).apply { setPadding(0, dp(16), 0, 0) })
            root.addView(wrapRow(listOf(
                chip(if (everScanned && !scannedAll) "↻ 이 페이지 다시 읽기" else "이 페이지에서 찾기", !scannedAll || !everScanned) { doScan(false, ::render) },
                chip("열린 탭 전부에서 찾기", scannedAll && everScanned) { doScan(true, ::render) }
            )))
            if (scanning) { root.addView(label("페이지를 읽는 중…", 13f)); return }
            if (!everScanned) { root.addView(label("사이트의 목록 페이지(검색 결과 · 추천 목록 등)를 연 채로 눌러 주세요.")); return }

            val res = recommend(kws, items)
            root.addView(label("읽은 영상 ${res.scanned}개 중 ${res.hits.size}개 추천", 12f))
            if (res.scanned == 0) { root.addView(label("영상 링크를 못 찾았어요. 영상이 여러 개 나열된 페이지에서 해 보세요.")); return }

            if (res.related.isNotEmpty()) {
                root.addView(label("비슷한 키워드 (눌러서 추가)", 13f, cOn, true).apply { setPadding(0, dp(12), 0, 0) })
                root.addView(wrapRow(res.related.map { w -> chip("+ $w", false) { save(prefs, addKeywords(load(prefs), w)); render() } }))
            }
            if (res.hits.isEmpty()) root.addView(label("키워드가 들어간 영상이 이 페이지에는 없어요. 다른 페이지에서 해 보세요.").apply { setPadding(0, dp(8), 0, 0) })
            for (h in res.hits) {
                val row = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
                row.addView(label(h.title.take(90), 14f, cOn).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
                val host = h.site.ifBlank { runCatching { java.net.URI(h.url).host }.getOrNull() ?: "" }
                row.addView(label((if (h.similar) "비슷 · " else "") + host + " · " + h.matched.joinToString(", "), 12f, if (h.similar) cVar else accent))
                row.setOnClickListener { dlg.dismiss(); open(h.url) }
                root.addView(row)
            }
        }
        render()
        dlg.show()
    }

    /** 처음 한 번, 성인 모드 기능을 쓰기 전에 만 19세 이상인지 확인한다 */
    fun ensureAdult(act: Activity, prefs: Prefs, then: () -> Unit) {
        if (prefs.adultConfirmed) { then(); return }
        ThemedDialogBuilder(act).setTitle("성인 확인")
            .setMessage("이 기능은 만 19세 이상 성인만 쓸 수 있어요. 만 19세 이상인가요?")
            .setPositiveButton("네, 성인이에요") { _, _ -> prefs.adultConfirmed = true; then() }
            .setNegativeButton("아니요", null).show()
    }
}
