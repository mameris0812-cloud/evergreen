package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * AI 커스텀 기능: 「AI로 만들기 > 새로운 기능」 으로 만드는, 확장 프로그램과는 별개의 '앱 기능'.
 *
 * 사용자가 말로 적은 일을 AI 가 앱 내장 도구(탭 · 주소 이동 · 북마크 · 설정 · 테마 · 탭 그룹 등, [AgentTools])를
 * 순서대로 엮은 단계 목록으로 바꿔 저장한다. 실행할 때는 AI 를 다시 부르지 않고 저장된 단계를 그대로 돌린다 (재빌드 · 설치 없음).
 * 위험한 도구(다운로드 · 확장 설치/삭제 등 [AgentRisk.DANGER])와 확장/웹사이트 만들기 도구는 쓰지 않는다.
 */
object CustomFeatures {
    class Step(val tool: String, val args: JSONObject)

    class Feature(
        val id: String,
        var name: String,
        var summary: String,
        val steps: List<Step>,
        var enabled: Boolean,
        val request: String,
        val created: Long,
        /** 오류로 자동으로 꺼졌을 때 그 이유 (비어 있으면 오류 없음). 사용자가 다시 켜면 지운다 */
        var lastError: String = "",
        /** AI 가 쓴 JavaScript 코드. 비어 있으면 예전 방식(저장된 [steps])으로 돈다 */
        val code: String = ""
    )

    private const val PREF = "evergreen_custom_features"
    private const val KEY = "list"
    const val MAX_STEPS = 12

    /** 단계로 쓰지 않는 도구: 확장 · 웹사이트 만들기와 고치기 · 지우기, 테마 직접 꾸미기 */
    private val BLOCKED = setOf(
        "create_extension", "create_website", "edit_extension", "remove_extension", "install_extension", "customize_theme"
    )

    /** 단계로 쓸 수 있는 도구: 앱을 바꾸는 도구(CHANGE) 와 화면 열기 */
    fun allowedTools(): List<AgentTool> =
        AgentTools.build(false).filter { (it.risk == AgentRisk.CHANGE && it.name !in BLOCKED) || it.name == "open_screen" }

    // ───────────────────────── 저장 ─────────────────────────

    fun list(ctx: Context): List<Feature> = try {
        val arr = JSONArray(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val sa = o.optJSONArray("steps") ?: JSONArray()
            val steps = (0 until sa.length()).mapNotNull { j ->
                val s = sa.optJSONObject(j) ?: return@mapNotNull null
                Step(s.optString("tool"), s.optJSONObject("args") ?: JSONObject())
            }
            Feature(
                o.optString("id"), o.optString("name"), o.optString("summary"), steps,
                o.optBoolean("enabled", true), o.optString("request"), o.optLong("created"), o.optString("error"), o.optString("code")
            )
        }
    } catch (e: Exception) { emptyList() }

    private fun write(ctx: Context, all: List<Feature>) {
        val arr = JSONArray()
        all.forEach { f ->
            val sa = JSONArray()
            f.steps.forEach { sa.put(JSONObject().put("tool", it.tool).put("args", it.args)) }
            arr.put(
                JSONObject().put("id", f.id).put("name", f.name).put("summary", f.summary).put("steps", sa)
                    .put("enabled", f.enabled).put("request", f.request).put("created", f.created).put("error", f.lastError).put("code", f.code)
            )
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    /** 같은 id 가 있으면 그 자리에 바꿔 넣고, 없으면 맨 뒤에 더한다 */
    fun save(ctx: Context, f: Feature) {
        val all = list(ctx).toMutableList()
        val at = all.indexOfFirst { it.id == f.id }
        if (at >= 0) all[at] = f else all.add(f)
        write(ctx, all)
    }

    fun remove(ctx: Context, id: String) = write(ctx, list(ctx).filter { it.id != id })

    // ───────────────────────── AI 로 만들기 ─────────────────────────

    private fun sig(t: AgentTool): String {
        val props = t.params?.optJSONObject("properties")
        val ps = StringBuilder()
        if (props != null) {
            val names = props.keys().asSequence().toList()
            names.forEach { n ->
                val d = props.optJSONObject(n)?.optString("description").orEmpty().take(60)
                if (ps.isNotEmpty()) ps.append(", ")
                ps.append(n).append(if (d.isNotEmpty()) " (" + d + ")" else "")
            }
        }
        return "- ${t.name}: ${t.description.take(140)} | 인자: ${if (ps.isEmpty()) "없음" else ps.toString()}"
    }

    private const val MAX_CODE = 8000

    /** 코드에 넣지 못하게 하는 것들: 네트워크 · 동적 실행 · 저장소 · 쿠키 (실행 환경도 막아 두지만 만들 때 한 번 더 거른다) */
    private val FORBIDDEN = listOf(
        "fetch(", "XMLHttpRequest", "WebSocket", "sendBeacon", "EventSource", "eval(", "new Function", "import(", "importScripts",
        "document.cookie", "localStorage", "sessionStorage", "indexedDB"
    )

    private fun systemPrompt(tools: List<AgentTool>): String = buildString {
        append("당신은 브라우저 앱의 '커스텀 기능'을 JavaScript 코드로 만듭니다. 사용자가 말로 적은 일을 코드로 짭니다.\n")
        append("코드는 async 함수의 본문으로 실행되고, 인자 app 을 받습니다. 쓸 수 있는 것은 아래뿐입니다.\n")
        append("- app.tool(이름, 인자객체): 앱 기능을 부릅니다 (아래 도구 목록). 결과는 {ok, message, data}. 실패하면 예외가 던져집니다.\n")
        append("- app.page(함수): 지금 보는 웹 페이지 안에서 그 함수를 동기로 실행하고, 돌려준 값(JSON 으로 바꿀 수 있는 값)을 받습니다. ")
        append("함수 안에서만 document 를 쓸 수 있고 바깥 변수는 쓸 수 없습니다. 값은 반환값으로만 가져옵니다. 예: const title = app.page(() => document.title)\n")
        append("- app.toast(글): 사용자에게 알림. await app.sleep(ms): 잠깐 기다림 (최대 10초).\n")
        append("규칙:\n")
        append("- 네트워크(fetch · XMLHttpRequest 등), eval, import, 쿠키, localStorage 는 막혀 있으니 쓰지 않습니다.\n")
        append("- 오류를 try/catch 로 삼키지 않습니다. 실패하면 그대로 던져서 기능이 스스로 꺼지게 합니다.\n")
        append("- 결과나 할 일을 마친 뒤에는 app.toast 로 한 줄 알려 줍니다.\n")
        append("- 코드는 $MAX_CODE 자 이하로, 짧고 읽기 쉽게 씁니다. 도구와 페이지 조작으로 할 수 없는 일이면 code 를 빈 글로 두고 notes 에 이유를 적습니다.\n")
        append("- 반드시 JSON 한 개만 답합니다: {\"name\":\"짧은 이름(12자 이내)\",\"summary\":\"한 줄 설명\",\"code\":\"JavaScript 코드\",\"notes\":\"\"}\n\n")
        append("app.tool 로 부를 수 있는 도구:\n")
        tools.forEach { append(sig(it)).append('\n') }
    }

    /** 요청 한 줄을 AI 가 코드로 짠다. 실패하면 이유를 예외로 던진다 (백그라운드 스레드에서 부른다) */
    fun generate(key: String, request: String, id: String): Feature {
        val tools = allowedTools()
        val sb = StringBuilder()
        var err: String? = null
        try {
            GeminiClient().stream(
                key, GeminiModels.HYDROGEN.id, systemPrompt(tools), listOf(ChatMsg("user", "만들 기능: " + request.trim())),
                onDelta = { sb.append(it) }, onDone = { }, onError = { err = it },
                json = true, thinking = GeminiThinking.LOW
            )
        } catch (e: Exception) {
            err = e.message ?: "AI 요청에 실패했어요"
        }
        err?.let { throw IllegalStateException(it) }
        var raw = sb.toString().trim()
        if (raw.startsWith("```")) raw = raw.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (raw.isEmpty()) throw IllegalStateException("AI가 빈 답을 보냈어요")
        val o = try { JSONObject(raw) } catch (e: Exception) { throw IllegalStateException("AI 답을 읽지 못했어요. 다시 만들어 보세요") }
        val code = o.optString("code").trim()
        if (code.isEmpty()) throw IllegalStateException(o.optString("notes").ifBlank { "앱 기능으로는 만들 수 없는 일이에요" })
        if (code.length > MAX_CODE) throw IllegalStateException("코드가 너무 길어요. 더 작은 일로 나눠서 만들어 보세요")
        FORBIDDEN.firstOrNull { code.contains(it) }?.let { throw IllegalStateException("허용하지 않는 동작이 들어 있어요 ($it). 다시 만들어 보세요") }
        val name = o.optString("name").trim().ifEmpty { request.trim().take(12) }.take(20)
        return Feature(id, name, o.optString("summary").trim(), emptyList(), true, request.trim(), System.currentTimeMillis(), "", code)
    }

    /** 단계 하나를 사람이 읽는 문장으로 */
    fun label(s: Step): String = try {
        allowedTools().firstOrNull { it.name == s.tool }?.doing?.invoke(s.args) ?: s.tool
    } catch (e: Exception) { s.tool }

    // ───────────────────────── 실행 ─────────────────────────

    /** 오류가 난 기능을 바로 끄고 이유를 남긴다 (메뉴에서 사라지고, 설정 > AI 커스텀 기능 관리에서 다시 켤 수 있다) */
    private fun disableOnError(ctx: Context, id: String, why: String) {
        val cur = list(ctx).firstOrNull { it.id == id } ?: return
        cur.enabled = false
        cur.lastError = why.take(120)
        save(ctx, cur)
    }

    /** 저장된 단계를 차례로 돌린다. 한 단계라도 실패하거나 위험해지거나 예외가 나면 거기서 멈추고, 그 기능을 자동으로 끈다 */
    fun run(act: MainActivity, f: Feature) {
        val host = MainAgentHost(act)
        val key = Prefs(act).geminiKey
        val tools = allowedTools().associateBy { it.name }
        AppToast.show(act, "「${f.name}」 실행 중…")
        if (f.code.isNotBlank()) {
            runCode(act, f, host, key, tools)
            return
        }
        Thread {
            var done = 0
            var fail: String? = null
            try {
                val ctx = AgentContext(key, host)
                for (s in f.steps) {
                    val t = tools[s.tool]
                    if (t == null) { fail = "「${s.tool}」 도구를 찾을 수 없어요"; break }
                    val risk = try { t.riskFor?.invoke(s.args, ctx) } catch (e: Exception) { null } ?: t.risk
                    if (risk == AgentRisk.DANGER) { fail = "위험한 동작이라 멈췄어요: ${label(s)}"; break }
                    val res = try { t.run(s.args, ctx) } catch (e: Exception) { AgentResult.fail(e.message ?: "실행에 실패했어요") }
                    if (!res.ok) { fail = res.summary.ifBlank { "실행에 실패했어요" }; break }
                    done++
                    try { Thread.sleep(500) } catch (e: InterruptedException) { break }
                }
            } catch (e: Throwable) {
                fail = e.message ?: "알 수 없는 오류가 났어요"
            }
            val why = fail?.let { "${done + 1}/${f.steps.size}단계 · $it" }
            if (why != null) disableOnError(act, f.id, why)
            act.runOnUiThread {
                if (act.isFinishing || act.isDestroyed) return@runOnUiThread
                val msg = if (why == null) "「${f.name}」 실행했어요" else "「${f.name}」 오류가 나서 자동으로 껐어요 · $why"
                AppToast.show(act, msg)
            }
        }.start()
    }
    private const val RUN_TIMEOUT_MS = 30_000L

    /** 코드 실행 결과를 알린다: 오류면 그 기능을 자동으로 끄고 이유를 남긴다 */
    private fun report(act: MainActivity, f: Feature, why: String?) {
        if (why != null) disableOnError(act, f.id, why)
        act.runOnUiThread {
            if (act.isFinishing || act.isDestroyed) return@runOnUiThread
            AppToast.show(act, if (why == null) "「${f.name}」 실행했어요" else "「${f.name}」 오류가 나서 자동으로 껐어요 · $why")
        }
    }

    /** 앱 도구와 페이지 조작을 코드에 열어 주는 문. 코드가 도는 곳에서는 `EG` 라는 이름으로만 보인다 */
    private class Bridge(
        val act: MainActivity,
        val host: AgentHost,
        val ctx: AgentContext,
        val tools: Map<String, AgentTool>,
        val finish: (String?) -> Unit
    ) {
        private fun err(m: String) = JSONObject().put("ok", false).put("error", m).toString()

        @JavascriptInterface
        fun call(name: String, argsJson: String): String {
            val t = tools[name] ?: return err("「$name」 도구를 쓸 수 없어요")
            val args = try { JSONObject(argsJson) } catch (e: Exception) { JSONObject() }
            val risk = try { t.riskFor?.invoke(args, ctx) } catch (e: Exception) { null } ?: t.risk
            if (risk == AgentRisk.DANGER) return err("위험한 동작이라 쓸 수 없어요: $name")
            val res = try { t.run(args, ctx) } catch (e: Exception) { AgentResult.fail(e.message ?: "실행에 실패했어요") }
            return if (res.ok) JSONObject().put("ok", true).put("message", res.summary).put("data", res.data).toString()
            else err(res.summary.ifBlank { "$name 실행에 실패했어요" })
        }

        @JavascriptInterface
        fun page(code: String): String {
            val wrapped = "(function(){try{var __r=(function(){" + code + "\n})();" +
                "return JSON.stringify({ok:true,value:(__r===undefined?null:__r)});}" +
                "catch(e){return JSON.stringify({ok:false,error:String((e&&e.message)||e)});}})()"
            val o = host.pageScript(wrapped)
            return if (o.ok) o.message else err(o.message)
        }

        @JavascriptInterface
        fun toast(msg: String) {
            act.runOnUiThread { if (!act.isFinishing && !act.isDestroyed) AppToast.show(act, msg.take(200)) }
        }

        @JavascriptInterface
        fun done(ok: Boolean, msg: String) = finish(if (ok) null else msg.ifBlank { "알 수 없는 오류가 났어요" })
    }

    private fun sandboxHtml(code: String): String {
        val safe = code.replace("</script", "<\\/script", ignoreCase = true)
        return """<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'"></head><body><script>
window.onerror=function(m,s,l){EG.done(false,'코드 오류: '+m+(l?' ('+l+'줄)':''));return true;};
window.onunhandledrejection=function(e){EG.done(false,'오류: '+((e.reason&&e.reason.message)||e.reason));};
</script><script>
var app={
tool:function(n,a){var r=JSON.parse(EG.call(String(n),JSON.stringify(a||{})));if(!r.ok)throw new Error(r.error);return r;},
page:function(f){var c=(typeof f==='function')?('return ('+f.toString()+')();'):String(f);var r=JSON.parse(EG.page(c));if(!r.ok)throw new Error(r.error);return r.value;},
toast:function(m){EG.toast(String(m));},
sleep:function(ms){return new Promise(function(r){setTimeout(r,Math.min(Number(ms)||0,10000));});}
};
(async function(){try{await (async function(app){
$safe
})(app);EG.done(true,'');}catch(e){EG.done(false,String((e&&e.message)||e));}})();
</script></body></html>"""
    }

    /**
     * AI 가 쓴 코드를 격리된 숨은 웹뷰에서 돌린다. 그 웹뷰는 네트워크 · 파일 · 저장소가 막혀 있고, 앱 도구와 지금 페이지는 [Bridge] 로만 만진다.
     * 문법 오류 · 던진 오류 · 막힌 동작 · 시간 초과(30초) 는 모두 오류로 보고 [report] 가 기능을 자동으로 끈다.
     */
    private fun runCode(act: MainActivity, f: Feature, host: AgentHost, key: String, tools: Map<String, AgentTool>) {
        val finished = AtomicBoolean(false)
        var view: WebView? = null
        val main = Handler(Looper.getMainLooper())
        fun finish(why: String?) {
            if (!finished.compareAndSet(false, true)) return
            main.post {
                view?.let { v -> try { v.stopLoading(); v.destroy() } catch (e: Exception) { } }
                view = null
            }
            report(act, f, why)
        }
        act.runOnUiThread {
            try {
                val wv = WebView(act)
                view = wv
                wv.settings.javaScriptEnabled = true
                wv.settings.blockNetworkLoads = true
                wv.settings.allowFileAccess = false
                wv.settings.allowContentAccess = false
                wv.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(v: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val scheme = request.url.scheme
                        return if (scheme == "http" || scheme == "https")
                            WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                        else null
                    }
                }
                wv.addJavascriptInterface(Bridge(act, host, AgentContext(key, host), tools) { why -> finish(why) }, "EG")
                wv.loadDataWithBaseURL("https://evergreen.invalid/", sandboxHtml(f.code), "text/html", "utf-8", null)
                main.postDelayed({ finish("시간이 너무 오래 걸려서 멈췄어요") }, RUN_TIMEOUT_MS)
            } catch (e: Throwable) {
                finish(e.message ?: "코드를 실행하지 못했어요")
            }
        }
    }
}

/** AI 커스텀 기능의 만들기 · 관리 화면 */
object CustomFeaturesUi {
    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    private fun field(a: Activity, hint: String, init: String, multi: Boolean): Pair<LinearLayout, EditText> {
        val et = EditText(a).apply {
            setText(init)
            this.hint = hint
            if (multi) {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = 3
                gravity = Gravity.TOP
            } else inputType = InputType.TYPE_CLASS_TEXT
        }
        Popup.styleInput(et)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 20), dp(a, 4), dp(a, 20), 0)
            addView(et)
        }
        return box to et
    }

    /** 만들기: 설명 입력 → AI 가 단계로 엮음 → 미리보기에서 저장. [replaceId] 가 있으면 그 기능을 새로 만든 것으로 바꾼다 */
    fun showMaker(act: MainActivity, prefill: String = "", replaceId: String? = null) {
        val key = Prefs(act).geminiKey
        if (key.isBlank()) {
            AppToast.show(act, "설정에서 Gemini API 키를 먼저 저장해 주세요")
            return
        }
        val (box, et) = field(act, "예: 새 탭 두 개로 뉴스와 날씨를 열어줘", prefill, true)
        ThemedDialogBuilder(act)
            .setTitle("새로운 기능 만들기")
            .setMessage("하고 싶은 일을 적어 주세요. AI가 코드를 짜서, 누르면 실행되는 나만의 기능을 만들어요. 앱 기능(탭 · 북마크 · 설정 등)과 지금 보는 페이지를 다룰 수 있고, 오류가 나면 자동으로 꺼져요.")
            .setView(box)
            .setPositiveButton("만들기") { _, _ ->
                val req = et.text?.toString().orEmpty().trim()
                if (req.isEmpty()) { AppToast.show(act, "하고 싶은 일을 적어 주세요"); return@setPositiveButton }
                AppToast.show(act, "AI가 기능을 만드는 중…")
                val id = replaceId ?: ("cf_" + System.currentTimeMillis())
                Thread {
                    val r = try { CustomFeatures.generate(key, req, id) to null } catch (e: Exception) { null to (e.message ?: "만들지 못했어요") }
                    act.runOnUiThread {
                        if (act.isFinishing || act.isDestroyed) return@runOnUiThread
                        val f = r.first
                        if (f != null) showPreview(act, f, replaceId != null)
                        else ThemedDialogBuilder(act).setTitle("만들지 못했어요").setMessage(r.second)
                            .setPositiveButton("다시 쓰기") { _, _ -> showMaker(act, req, replaceId) }
                            .setNegativeButton("닫기", null).show()
                    }
                }.start()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    /** 코드 기능이면 코드를, 예전 단계 기능이면 단계 목록을 */
    private fun bodyText(f: CustomFeatures.Feature): String = if (f.code.isNotBlank()) f.code else stepsText(f)

    private fun stepsText(f: CustomFeatures.Feature): String =
        f.steps.mapIndexed { i, s -> "${i + 1}. ${CustomFeatures.label(s)}" }.joinToString("\n")

    private fun showPreview(act: MainActivity, f: CustomFeatures.Feature, replacing: Boolean) {
        ThemedDialogBuilder(act)
            .setTitle("「${f.name}」")
            .setMessage((f.summary.takeIf { it.isNotBlank() }?.plus("\n\n") ?: "") + bodyText(f) + "\n\n코드를 읽어 보고 저장하세요. 저장하면 메뉴의 AI 커스텀 기능 칸에 나타나고, 오류가 나면 자동으로 꺼져요.")
            .setPositiveButton("저장") { _, _ ->
                if (replacing) CustomFeatures.list(act).firstOrNull { it.id == f.id }?.let { f.enabled = it.enabled }
                CustomFeatures.save(act, f)
                AppToast.show(act, "「${f.name}」 을 저장했어요")
            }
            .setNeutralButton("다시 만들기") { _, _ -> showMaker(act, f.request, if (replacing) f.id else null) }
            .setNegativeButton("취소", null)
            .show()
    }

    /** 설정 > AI 커스텀 기능 관리 */
    fun showManager(act: MainActivity) {
        val all = CustomFeatures.list(act)
        val items = ArrayList<Popup.Item>()
        all.forEach { f ->
            items.add(Popup.Item(
                R.drawable.ic_ai, f.name,
                stateText(f)
            ) { showActions(act, f) })
        }
        items.add(Popup.Item(R.drawable.ic_add, "새 기능 만들기", "말로 적으면 AI가 코드로 만들어요") { showMaker(act) })
        Popup.menu(act, "AI 커스텀 기능", if (all.isEmpty()) "아직 만든 기능이 없어요" else "${all.size}개", R.drawable.ic_ai, null, items)
    }

    private fun stateText(f: CustomFeatures.Feature): String = when {
        f.enabled -> "사용 중 · ${if (f.code.isNotBlank()) "코드" else "${f.steps.size}단계"}"
        f.lastError.isNotBlank() -> "오류로 꺼짐 · ${f.lastError.take(40)}"
        else -> "꺼져 있어요 · ${if (f.code.isNotBlank()) "코드" else "${f.steps.size}단계"}"
    }

    private fun showActions(act: MainActivity, f: CustomFeatures.Feature) {
        val items = listOf(
            Popup.Item(R.drawable.ic_play, "지금 실행") { CustomFeatures.run(act, f) },
            Popup.Item(R.drawable.ic_check, if (f.enabled) "끄기" else "켜기", if (f.enabled) "메뉴에서 숨겨요" else "메뉴에 다시 보여요") {
                f.enabled = !f.enabled
                if (f.enabled) f.lastError = ""
                CustomFeatures.save(act, f)
                showManager(act)
            },
            Popup.Item(R.drawable.ic_edit, "이름 바꾸기") { rename(act, f) },
            Popup.Item(R.drawable.ic_search, if (f.code.isNotBlank()) "코드 보기" else "단계 보기") {
                ThemedDialogBuilder(act).setTitle(if (f.code.isNotBlank()) "「${f.name}」 의 코드" else "「${f.name}」 의 단계").setMessage(bodyText(f))
                    .setPositiveButton("닫기") { _, _ -> showManager(act) }.show()
            },
            Popup.Item(R.drawable.ic_ai, "AI로 다시 만들기", "설명을 고쳐서 단계를 새로 짜요") { showMaker(act, f.request, f.id) },
            Popup.Item(R.drawable.ic_delete, "삭제", danger = true) {
                ThemedDialogBuilder(act)
                    .setTitle("「${f.name}」 을 삭제할까요?")
                    .setMessage("삭제하면 메뉴의 AI 커스텀 기능 칸에서도 사라져요.")
                    .setPositiveButton("삭제") { _, _ -> CustomFeatures.remove(act, f.id); showManager(act) }
                    .setNegativeButton("취소") { _, _ -> showManager(act) }
                    .show()
            }
        )
        Popup.menu(act, f.name, stateText(f), R.drawable.ic_ai, null, items)
    }

    private fun rename(act: MainActivity, f: CustomFeatures.Feature) {
        val (box, et) = field(act, "기능 이름", f.name, false)
        ThemedDialogBuilder(act)
            .setTitle("이름 바꾸기")
            .setView(box)
            .setPositiveButton("저장") { _, _ ->
                val n = et.text?.toString().orEmpty().trim()
                if (n.isNotEmpty()) { f.name = n.take(20); CustomFeatures.save(act, f) }
                showManager(act)
            }
            .setNegativeButton("취소") { _, _ -> showManager(act) }
            .show()
    }
}
