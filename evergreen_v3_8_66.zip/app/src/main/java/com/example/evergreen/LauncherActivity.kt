package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 런처(작업 표시줄) 아이콘 진입점. 화면 없이 바로 끝나는 중계 창이다 (크롬·삼성 인터넷과 같은 방식).
 * 앱의 실제 화면(MainActivity)이 런처 진입점이면 시스템이 이미 떠 있는 앱으로 보고
 * 작업 표시줄에서 끌어다 놓을 때 "이미 실행 중입니다" 로 막기 때문에, 진입점은 금방 사라지는 이 창으로 둔다.
 * - 새 창 요청(MULTIPLE_TASK / 옆에 붙이기)이고 이미 떠 있는 창이 있으면: 새 창을 옆에 띄운다
 * - 그 밖에는: MainActivity 를 연다 (이미 떠 있는 앱을 아이콘으로 앞에 가져오는 건 시스템이 이 창을 만들지 않고 처리)
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val asked = Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
        val newWindow = (intent?.flags ?: 0) and asked != 0
        if (!(newWindow && MainActivity.openWindowFromLauncher())) {
            val go = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            intent?.extras?.let { go.putExtras(it) }
            startActivity(go)
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
