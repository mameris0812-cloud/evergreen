package com.example.evergreen

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** 다운로드 완료 알림 (빠른 다운로드 / blob·data 저장이 함께 쓴다) */
object DownloadNotifier {
    const val CH_DONE = "downloads_done"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CH_DONE, "다운로드 완료", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun listIntent(context: Context, id: Int): PendingIntent =
        PendingIntent.getActivity(
            context, id,
            Intent(context, DownloadsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** 받은 파일을 여는 PendingIntent. HTML 은 이 브라우저 새 탭, APK 는 설치 화면, 나머지는 맞는 앱으로 연다. */
    fun openFileIntent(context: Context, id: Int, name: String, mime: String, uri: Uri?): PendingIntent {
        uri ?: return listIntent(context, id)
        val lower = name.lowercase()
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val isHtml = lower.endsWith(".html") || lower.endsWith(".htm") || lower.endsWith(".xhtml") ||
            mime == "text/html" || mime == "application/xhtml+xml"
        val isApk = lower.endsWith(".apk") || mime == "application/vnd.android.package-archive"
        val intent = when {
            isHtml -> Intent(context, MainActivity::class.java)
                .setAction(Intent.ACTION_VIEW)
                .setDataAndType(uri, "text/html")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            isApk -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                    !context.packageManager.canRequestPackageInstalls()
                ) return listIntent(context, id)
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            else -> Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime.takeIf { !FileNames.isGeneric(it) } ?: "*/*")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return PendingIntent.getActivity(context, id, intent, flags)
    }

    fun done(context: Context, id: Int, name: String, size: Long, mime: String, uri: Uri?) {
        ensureChannel(context)
        val open = openFileIntent(context, id, name, mime, uri)
        try {
            context.getSystemService(NotificationManager::class.java).notify(
                id,
                NotificationCompat.Builder(context, CH_DONE)
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(name)
                    .setContentText("다운로드 완료 · ${formatBytes(size)} · 눌러서 열기")
                    .setContentIntent(open)
                    .addAction(0, "열기", open)
                    .addAction(0, "다운로드 목록", listIntent(context, id))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_STATUS)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (e: Exception) {
            // 알림 권한이 없으면 건너뜀
        }
    }

    fun formatBytes(n: Long): String = when {
        n >= 1L shl 30 -> String.format("%.2f GB", n / (1024.0 * 1024 * 1024))
        n >= 1L shl 20 -> String.format("%.1f MB", n / (1024.0 * 1024))
        n >= 1L shl 10 -> String.format("%.0f KB", n / 1024.0)
        else -> "$n B"
    }
}

/**
 * blob: / data: 주소로 만들어진 파일 저장.
 * 이런 주소는 서버에서 받을 수 없고 페이지 안에만 있어서, blob 은 페이지에서 읽어 조각으로 넘겨받는다.
 */
class LocalDownload(
    private val context: Context,
    private val onMessage: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())

    private class Pending(val contentDisposition: String?, val mime: String?)

    private class Writer(
        val name: String,
        val mime: String,
        val uri: Uri?,
        val file: File?,
        val out: OutputStream
    ) {
        var written = 0L
    }

    private val pending = ConcurrentHashMap<String, Pending>()
    private val writers = ConcurrentHashMap<String, Writer>()

    /** 사용자가 누른 다운로드의 주소가 blob:/data: 이면 여기로 보낸다 (UI 스레드에서 호출) */
    fun handle(wv: WebView, url: String, contentDisposition: String?, mimeType: String?) {
        if (url.startsWith("data:")) {
            Thread { saveDataUrl(url, contentDisposition, mimeType) }.start()
            return
        }
        val token = UUID.randomUUID().toString()
        pending[token] = Pending(contentDisposition, mimeType)
        val js = """
            (function(u,t){
              function fail(){try{EvBlob.fail(t)}catch(e){}}
              try{
                var x=new XMLHttpRequest();x.open('GET',u,true);x.responseType='blob';
                x.onerror=fail;
                x.onload=function(){
                  var b=x.response; if(!b){fail();return}
                  var size=b.size,CH=1048576,off=0;
                  EvBlob.begin(t,b.type||'');
                  (function next(){
                    if(off>=size){EvBlob.end(t);return}
                    var r=new FileReader();
                    r.onload=function(){var s=r.result;EvBlob.chunk(t,s.substring(s.indexOf(',')+1));off+=CH;next()};
                    r.onerror=fail;
                    r.readAsDataURL(b.slice(off,off+CH));
                  })();
                };
                x.send();
              }catch(e){fail()}
            })(${JSONObject.quote(url)},${JSONObject.quote(token)});
        """.trimIndent()
        wv.evaluateJavascript(js, null)
    }

    // ── 페이지 스크립트가 부르는 부분 (우리가 만든 토큰이 있어야만 동작) ──

    @JavascriptInterface
    fun begin(token: String, blobMime: String) {
        val p = pending[token] ?: return
        try {
            val mime = blobMime.takeIf { it.isNotBlank() }
                ?: p.mime?.takeIf { it.isNotBlank() } ?: "application/octet-stream"
            writers[token] = openWriter(nameFor(p.contentDisposition, mime), mime)
        } catch (e: Exception) {
            pending.remove(token)
            message("파일을 저장할 수 없습니다")
        }
    }

    @JavascriptInterface
    fun chunk(token: String, base64: String) {
        val w = writers[token] ?: return
        try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            w.out.write(bytes)
            w.written += bytes.size
        } catch (e: Exception) {
            abort(token)
            message("파일 저장 중 오류가 났습니다")
        }
    }

    @JavascriptInterface
    fun end(token: String) {
        pending.remove(token)
        val w = writers.remove(token) ?: return
        finish(w)
    }

    @JavascriptInterface
    fun fail(token: String) {
        if (pending.remove(token) == null) return
        abort(token)
        message("이 파일은 저장할 수 없습니다")
    }

    // ── 저장 ──

    private fun saveDataUrl(url: String, cd: String?, mimeType: String?) {
        try {
            val comma = url.indexOf(',')
            if (comma < 0) throw IllegalArgumentException()
            val header = url.substring(5, comma)
            val payload = url.substring(comma + 1)
            val isB64 = header.endsWith(";base64", ignoreCase = true)
            val headMime = header.substringBefore(';').takeIf { it.isNotBlank() }
            val mime = mimeType?.takeIf { it.isNotBlank() } ?: headMime ?: "text/plain"
            val bytes = if (isB64) Base64.decode(payload, Base64.DEFAULT)
            else Uri.decode(payload).toByteArray(Charsets.UTF_8)
            val w = openWriter(nameFor(cd, mime), mime)
            try {
                w.out.write(bytes)
                w.written = bytes.size.toLong()
            } catch (e: Exception) {
                abortWriter(w)
                throw e
            }
            finish(w)
        } catch (e: Exception) {
            message("파일을 저장할 수 없습니다")
        }
    }

    private fun nameFor(cd: String?, mime: String): String {
        val raw = FileNames.guess(null, cd, mime).replaceFirst("downloadfile", "download")
        return raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").ifBlank { "download" }
    }

    private fun openWriter(name: String, mime: String): Writer {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, FileNames.mimeFor(name, mime) ?: mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw java.io.IOException("insert")
            val out = context.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("open")
            return Writer(name, mime, uri, null, out)
        }
        // Android 9 이하: 다운로드 폴더에 직접 쓴다 (같은 이름이 있으면 번호를 붙임)
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        var f = File(dir, name)
        var i = 1
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        while (f.exists()) f = File(dir, "$base ($i)$ext").also { i++ }
        return Writer(f.name, mime, null, f, FileOutputStream(f))
    }

    private fun finish(w: Writer) {
        try {
            w.out.close()
            val uri = w.uri
            if (uri != null) {
                context.contentResolver.update(
                    uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null
                )
            } else if (w.file != null) {
                // Android 9 이하: 갤러리/다운로드 목록에 보이도록 알리고, 알림은 다운로드 목록으로 연결한다
                android.media.MediaScannerConnection.scanFile(context, arrayOf(w.file.absolutePath), null, null)
            }
            val id = NEXT_ID.getAndIncrement()
            DownloadNotifier.done(context, id, w.name, w.written, FileNames.mimeFor(w.name, w.mime) ?: w.mime, uri)
            message("다운로드 완료: ${w.name}")
        } catch (e: Exception) {
            abortWriter(w)
            message("파일을 저장할 수 없습니다")
        }
    }

    private fun abort(token: String) {
        writers.remove(token)?.let { abortWriter(it) }
        pending.remove(token)
    }

    private fun abortWriter(w: Writer) {
        try { w.out.close() } catch (e: Exception) { /* 무시 */ }
        try {
            w.uri?.let { context.contentResolver.delete(it, null, null) }
            w.file?.delete()
        } catch (e: Exception) { /* 무시 */ }
    }

    private fun message(msg: String) = main.post { onMessage(msg) }

    companion object {
        private val NEXT_ID = java.util.concurrent.atomic.AtomicInteger(5000)
    }
}
