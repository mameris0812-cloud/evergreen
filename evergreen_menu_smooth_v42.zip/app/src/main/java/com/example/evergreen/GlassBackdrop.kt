package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.PixelCopy
import android.view.View
import androidx.annotation.RequiresApi
import androidx.core.graphics.ColorUtils

/**
 * 유리(블러) 배경 공통 도우미 (Android 12 이상에서만 쓴다).
 *
 * 웹 페이지(WebView)를 우리가 직접 한 번 더 그리면 같은 프레임에 두 번 그려져 화면이 깜빡이므로,
 * 화면에 이미 그려진 픽셀을 PixelCopy 로 작게(1/8) 복사해 와서 그 그림을 흐리게 깐다.
 * 복사는 약 80ms 에 한 번 이하로만 하고, 그림이 실제로 바뀐 경우에만 다시 그린다 (바뀌지 않으면 멈춘다).
 *
 * [rectProvider]: 복사할 곳(창 좌표).
 *
 * [edgeDp] 가 0 이면: 이 뷰 자신이 겹치지 않는 곳을 가리켜야 한다 (자기 자신이 찍히면 번져 보인다).
 * [edgeDp] 가 0 보다 크면 '가운데 구멍' 방식: [rectProvider] 는 뷰 사각형을 사방으로 [edgeDp] 만큼 넓힌 곳이어야 하고,
 * 복사한 그림에서 뷰와 겹치는 가운데는 버리고 둘레 띠 색으로 매끄럽게 채운다.
 * 그래서 뷰 바로 뒤(둘레)의 페이지 색을 따라가면서도 뷰 자신이 찍혀 번지는 일이 없다.
 */
@RequiresApi(Build.VERSION_CODES.S)
internal class GlassBackdrop(
    private val view: View,
    /** 흐림 반경 (dp). 클수록 비침이 뭉개져 은은해진다 */
    private val blurDp: Float = 10f,
    /** 0 보다 크면 '가운데 구멍' 방식 (위 설명 참고). 뷰 둘레로 넓힌 폭 (dp) */
    private val edgeDp: Float = 0f,
    private val rectProvider: () -> Rect?
) {

    private val handler = Handler(Looper.getMainLooper())
    private var front: Bitmap? = null
    private var back: Bitmap? = null
    private var busy = false
    private var lastAt = 0L
    private var lastSig = 0L
    private var retryQueued = false
    private var node: RenderNode? = null
    private val retry = Runnable { retryQueued = false; refresh() }

    private companion object {
        /** 복사 최소 간격. 거의 매 프레임 따라가되 한 프레임에 두 번은 하지 않는다 */
        const val MIN_INTERVAL_MS = 12L
    }

    /** 그림이 바뀌었을 때 (이 그림을 나눠 쓰는 다른 뷰도 다시 그리게 할 때 쓴다) */
    var onUpdated: (() -> Unit)? = null

    private fun activity(c: Context): Activity? {
        var x: Context? = c
        while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }
        return null
    }

    /** 화면이 그려지기 직전에 부른다. 필요하면 복사를 요청한다 */
    fun refresh() {
        if (busy || !view.isShown || view.width <= 0) return
        val now = SystemClock.uptimeMillis()
        if (now - lastAt < MIN_INTERVAL_MS) {
            if (!retryQueued) { retryQueued = true; handler.postDelayed(retry, MIN_INTERVAL_MS) }
            return
        }
        val win = activity(view.context)?.window ?: return
        val r = rectProvider() ?: return
        val dm = view.resources.displayMetrics
        val bounds = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        if (r.isEmpty || !bounds.contains(r)) return
        val bw = (r.width() / 8).coerceIn(8, 400)
        val bh = (r.height() / 8).coerceIn(4, 400)
        var dst = back
        if (dst == null || dst.width != bw || dst.height != bh) {
            dst = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            back = dst
        }
        busy = true
        lastAt = now
        try {
            PixelCopy.request(win, r, dst, { result ->
                busy = false
                if (result == PixelCopy.SUCCESS) {
                    if (edgeDp > 0f) fillHole(dst, r.width(), r.height())
                    // 몇 군데 픽셀만 보고 그림이 바뀌었는지 확인한다
                    var sig = 17L
                    for (iy in 0 until 6) for (ix in 0 until 12) {
                        sig = sig * 31 + dst.getPixel((ix * (dst.width - 1)) / 11, (iy * (dst.height - 1)) / 5)
                    }
                    val t = front; front = dst; back = t
                    if (sig != lastSig) { lastSig = sig; view.invalidate(); onUpdated?.invoke() }
                }
            }, handler)
        } catch (e: Throwable) {
            busy = false
        }
    }

    /** [px] 의 start 부터 step 간격으로 count 개 픽셀의 평균 색 */
    private fun mean(px: IntArray, start: Int, step: Int, count: Int): Int {
        if (count <= 0) return px[start.coerceIn(0, px.size - 1)]
        var r = 0; var g = 0; var b = 0
        for (i in 0 until count) {
            val c = px[start + i * step]
            r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF
        }
        return (0xFF shl 24) or ((r / count) shl 16) or ((g / count) shl 8) or (b / count)
    }

    /**
     * '가운데 구멍' 방식: 복사한 그림([regionW]x[regionH] 영역)에서 뷰가 차지한 가운데를 지우고,
     * 왼/오른 띠는 가로로, 위/아래 띠는 세로로 이어 평균내어 채운다. 바로 위에 뷰가 그려져 있어도 그 색이 섞이지 않는다.
     */
    private fun fillHole(bmp: Bitmap, regionW: Int, regionH: Int) {
        if (regionW <= 0 || regionH <= 0) return
        val d = view.resources.displayMetrics.density
        val edge = (edgeDp * d).toInt()
        val inner = (edge - (2 * d).toInt()).coerceAtLeast(0)   // 가장자리 번짐·테두리 몫으로 구멍을 2dp 키운다
        val bw = bmp.width; val bh = bmp.height
        val sx = bw.toFloat() / regionW; val sy = bh.toFloat() / regionH
        val hx0 = Math.floor((inner * sx).toDouble()).toInt()
        val hx1 = Math.ceil(((regionW - inner) * sx).toDouble()).toInt()
        val hy0 = Math.floor((inner * sy).toDouble()).toInt()
        val hy1 = Math.ceil(((regionH - inner) * sy).toDouble()).toInt()
        if (hx0 < 1 || hy0 < 1 || hx1 > bw - 1 || hy1 > bh - 1 || hx1 - hx0 < 1 || hy1 - hy0 < 1) return
        val px = IntArray(bw * bh)
        bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
        val left = IntArray(bh); val right = IntArray(bh)
        for (y in hy0 until hy1) {
            left[y] = mean(px, y * bw, 1, hx0)
            right[y] = mean(px, y * bw + hx1, 1, bw - hx1)
        }
        val top = IntArray(bw); val bottom = IntArray(bw)
        for (x in hx0 until hx1) {
            top[x] = mean(px, x, bw, hy0)
            bottom[x] = mean(px, hy1 * bw + x, bw, bh - hy1)
        }
        for (y in hy0 until hy1) {
            val ty = (y - hy0 + 0.5f) / (hy1 - hy0)
            for (x in hx0 until hx1) {
                val tx = (x - hx0 + 0.5f) / (hx1 - hx0)
                val h = ColorUtils.blendARGB(left[y], right[y], tx)
                val v = ColorUtils.blendARGB(top[x], bottom[x], ty)
                px[y * bw + x] = ColorUtils.blendARGB(h, v, 0.5f)
            }
        }
        bmp.setPixels(px, 0, bw, 0, 0, bw, bh)
    }

    /** 뷰의 (0,0)~(w,h) 자리에 흐린 그림을 그린다. 뒤 배경보다 먼저 불러야 한다 */
    fun draw(canvas: Canvas, w: Int, h: Int) = drawSlice(canvas, w, h, 0, h, false)

    /**
     * 복사해 온 그림 전체(높이 [totalH])에서 위로부터 [offsetY] 만큼 아래 구간을 이 뷰의 (0,0)~(w,h) 에 그린다.
     * 상태표시줄·탭 줄·주소창이 한 장의 그림을 나눠 그리므로 경계에서 끊기지 않고 이어진다.
     * [flip] 이면 그림을 위아래로 뒤집어, 페이지와 맞닿는 바의 가장자리가 페이지의 그 가장자리 줄과 같게(거울처럼) 이어 보이게 한다.
     */
    fun drawSlice(canvas: Canvas, w: Int, h: Int, offsetY: Int, totalH: Int, flip: Boolean = true) {
        val bmp = front ?: return
        if (!canvas.isHardwareAccelerated) return
        val d = view.resources.displayMetrics.density
        // 구멍 방식은 복사한 그림이 (뷰 + 둘레) 크기 그대로이므로 둘레 폭만큼만 여백을 둔다 (위치가 1:1 로 맞는다)
        val pad = if (edgeDp > 0f) (edgeDp * d).toInt() else (16 * d).toInt()
        val rn = node ?: RenderNode("glassBlur").also {
            val r = blurDp * d
            it.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
            node = it
        }
        val th = maxOf(totalH, h + offsetY)
        rn.setPosition(0, 0, w + pad * 2, th + pad * 2)
        val rc = rn.beginRecording(w + pad * 2, th + pad * 2)
        try {
            if (flip) { rc.translate(0f, (th + pad * 2).toFloat()); rc.scale(1f, -1f) }
            rc.drawBitmap(bmp, null, RectF(0f, 0f, (w + pad * 2).toFloat(), (th + pad * 2).toFloat()), null)
        } finally {
            rn.endRecording()
        }
        canvas.save()
        canvas.clipRect(0, 0, w, h)
        canvas.translate(-pad.toFloat(), -pad.toFloat() - offsetY)
        canvas.drawRenderNode(rn)
        canvas.restore()
    }

    fun release() {
        handler.removeCallbacks(retry)
        retryQueued = false
    }
}
