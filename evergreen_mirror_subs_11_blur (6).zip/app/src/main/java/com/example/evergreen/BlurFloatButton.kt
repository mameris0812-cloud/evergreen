package com.example.evergreen

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 상/하단바 숨기기를 켰을 때 뜨는 작은 '더보기' 버튼.
 * Android 12(API 31) 이상에서는 버튼 바로 옆의 웹 페이지를 흐리게 깐 유리 모양이 된다.
 * 그 아래 버전에서는 원래의 불투명 배경(bg_float_menu) 그대로다.
 * 웹뷰를 직접 다시 그리지 않고 화면에 그려진 픽셀을 복사해 쓴다 (GlassBackdrop 참고).
 */
class BlurFloatButton @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null, defStyle: Int = androidx.appcompat.R.attr.imageButtonStyle
) : AppCompatImageButton(ctx, attrs, defStyle) {

    /** 웹 페이지가 붙는 영역 (이 안에서만 가져온다) */
    var source: View? = null
        set(v) { field = v; invalidate() }

    // 버튼 전체 투명도(alpha)는 1 로 둔다. 1 보다 작으면 뒤 페이지가 비쳐 흐린 그림과 겹쳐 보인다.
    private val blurOn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    private var glass: Any? = null
    private val clip = Path()
    private val a = IntArray(2)
    private val pre = ViewTreeObserver.OnPreDrawListener {
        if (source != null && alpha > 0.01f) (glass as? GlassBackdrop)?.refresh()
        true
    }

    /** 버튼에 겹치지 않도록 버튼 바로 왼쪽(왼쪽이 모자라면 오른쪽)의 페이지를 가져온다 */
    private fun region(): Rect? {
        val src = source ?: return null
        if (width <= 0) return null
        getLocationInWindow(a)
        val gap = (6 * resources.displayMetrics.density).toInt()
        var x = a[0] - width - gap
        if (x < 0) x = a[0] + width + gap
        return Rect(x, a[1], x + width, a[1] + height)
    }

    init {
        if (blurOn) {
            val fill = ColorUtils.setAlphaComponent(
                MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurfaceContainerHighest), 0x8C
            )
            val edge = ColorUtils.setAlphaComponent(
                MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutlineVariant), 0xA0
            )
            val shape = GradientDrawable().apply {
                this.shape = GradientDrawable.OVAL
                setColor(fill)
                setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), edge)
            }
            val ripple = MaterialColors.getColor(this, android.R.attr.colorControlHighlight, 0x22000000)
            background = RippleDrawable(ColorStateList.valueOf(ripple), shape, null)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (blurOn) {
            if (glass == null) glass = GlassBackdrop(this) { region() }
            viewTreeObserver.addOnPreDrawListener(pre)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (blurOn) {
            if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(pre)
            (glass as? GlassBackdrop)?.release()
        }
    }

    // 배경(반투명 유리)보다 먼저 흐린 그림을 그려야 하므로 onDraw 가 아니라 draw 에서 한다
    override fun draw(canvas: Canvas) {
        val g = glass as? GlassBackdrop
        if (blurOn && g != null && source != null && width > 0 && height > 0) {
            val n = canvas.save()
            try {
                clip.reset()
                clip.addOval(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
                canvas.clipPath(clip)
                g.draw(canvas, width, height)
            } catch (e: Throwable) { /* 못 그리면 유리 배경만 */ } finally {
                canvas.restoreToCount(n)
            }
        }
        super.draw(canvas)
    }
}
