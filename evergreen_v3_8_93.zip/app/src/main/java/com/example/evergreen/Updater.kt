package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * 앱 안에서 하는 업데이트.
 * GitHub 의 '최신 릴리스'(워크플로가 빌드마다 올린다)를 확인해서 지금 설치된 것보다 새 버전이면 APK 를 받아 설치 화면을 띄운다.
 * 저장소 이름은 빌드할 때 GitHub Actions 가 넣어 준다(BuildConfig.UPDATE_REPO). 직접 빌드해서 비어 있으면 동작하지 않는다.
 * 설치는 같은 키로 서명한 APK 만 덮어쓰기가 되고, 설치 확인 버튼은 매번 눌러야 한다(안드로이드 정책).
 */
object Updater {
    class Release(val versionName: String, val versionCode: Long, val apkUrl: String, val sha256: String, val assetApiUrl: String = "")

    sealed class Result {
        object UpToDate : Result()
        class Available(val release: Release) : Result()
        class Failed(val msg: String) : Result()
    }

    private const val PREFS = "evergreen_updater"
    private const val KEY_LAST_CHECK = "last_check"
    private const val AUTO_INTERVAL_MS = 30L * 60 * 1000
    /** 확인이 실패했을 때(오프라인 · GitHub 한도 등)는 다음 확인까지 이만큼만 기다린다 */
    private const val RETRY_MS = 5L * 60 * 1000
    private const val KEY_PERM_ASKED = "perm_asked_code"

    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followSslRedirects(false) // https → http 로 내려가는 리다이렉트는 따라가지 않는다
        .build()

    /** 이 프로세스에서 '업데이트 준비됨' 창을 이미 띄웠는지 (창이 계속 반복해서 뜨지 않게) */
    @Volatile private var readyPrompted = false
    private val quietBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var lastCommitAt = 0L

    fun enabled(): Boolean = BuildConfig.UPDATE_REPO.contains('/')

    private fun currentCode(ctx: Context): Long =
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))

    private fun updateDir(ctx: Context) = File(ctx.cacheDir, "updates")

    /** https 이고 GitHub 호스트인 주소만 믿는다 */
    private fun isTrustedUrl(url: String): Boolean {
        val u = url.toHttpUrlOrNull() ?: return false
        if (!u.isHttps) return false
        val h = u.host
        return h == "github.com" || h.endsWith(".github.com") || h.endsWith(".githubusercontent.com")
    }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    /** 받은 APK 의 서명 인증서가 지금 설치된 앱과 같은지 */
    private fun sameSigner(ctx: Context, apk: File): Boolean {
        val pm = ctx.packageManager
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                val flag = android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
                val new = pm.getPackageArchiveInfo(apk.path, flag)?.signingInfo ?: return false
                val cur = pm.getPackageInfo(ctx.packageName, flag).signingInfo ?: return false
                if (new.hasMultipleSigners() || cur.hasMultipleSigners()) {
                    val a = new.apkContentsSigners.map { hex(it.toByteArray()) }.toSet()
                    val b = cur.apkContentsSigners.map { hex(it.toByteArray()) }.toSet()
                    a.isNotEmpty() && a == b
                } else {
                    val a = new.signingCertificateHistory.map { hex(it.toByteArray()) }.toSet()
                    val b = cur.signingCertificateHistory.map { hex(it.toByteArray()) }.toSet()
                    a.isNotEmpty() && a.intersect(b).isNotEmpty()
                }
            } else {
                @Suppress("DEPRECATION")
                val flag = android.content.pm.PackageManager.GET_SIGNATURES
                @Suppress("DEPRECATION")
                val a = pm.getPackageArchiveInfo(apk.path, flag)?.signatures?.map { hex(it.toByteArray()) }?.toSet()
                @Suppress("DEPRECATION")
                val b = pm.getPackageInfo(ctx.packageName, flag).signatures?.map { hex(it.toByteArray()) }?.toSet()
                !a.isNullOrEmpty() && a == b
            }
        } catch (e: Exception) { false }
    }

    // ───────── 확인 ─────────

    private fun check(ctx: Context, cb: (Result) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val res = try {
                fetch(app)
            } catch (e: Exception) {
                Result.Failed(e.message ?: "네트워크 오류")
            }
            main.post { cb(res) }
        }.start()
    }

    private fun fetch(ctx: Context): Result {
        if (!enabled()) return Result.Failed("업데이트 저장소가 설정되지 않았어요 (GitHub Actions 로 빌드한 앱에서만 동작해요)")
        // 로그인 없이 묻는 GitHub 요청은 시간당 60번(같은 와이파이를 쓰는 기기끼리 나눔)이라 금방 막힌다(403).
        // 파일 올리기에서 저장해 둔 토큰이 있으면 그걸로 물어 한도를 늘리고, 토큰이 거절되면(401) 토큰 없이 다시 묻는다.
        val token = runCatching { GitUpload.loadToken(ctx) }.getOrNull()
        fun request(withToken: Boolean): Request {
            val b = Request.Builder()
                .url("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/latest")
                .header("Accept", "application/vnd.github+json")
                .header("User-Agent", "evergreen-updater")
            if (withToken && token != null) b.header("Authorization", "Bearer $token")
            return b.build()
        }
        var resp0 = client.newCall(request(true)).execute()
        if (resp0.code == 401 && token != null) { resp0.close(); resp0 = client.newCall(request(false)).execute() }
        return resp0.use { resp ->
            if (resp.code == 403 || resp.code == 429) {
                val reset = resp.header("x-ratelimit-reset")?.toLongOrNull() ?: 0L
                val mins = if (reset > 0) ((reset * 1000 - System.currentTimeMillis()) / 60_000L + 1).coerceIn(1, 60) else 0
                return@use Result.Failed(
                    if (resp.header("x-ratelimit-remaining") == "0")
                        (if (mins > 0) "GitHub 요청 한도에 도달했어요. 약 ${mins}분 뒤에 다시 눌러 주세요" else "GitHub 요청 한도에 도달했어요. 잠시 뒤에 다시 눌러 주세요")
                    else "GitHub 가 요청을 막았어요 (${resp.code}). 잠시 뒤에 다시 눌러 주세요"
                )
            }
            if (resp.code == 404) return@use Result.Failed("공개된 릴리스를 찾지 못했어요 (저장소가 비공개이거나 릴리스가 아직 없어요)")
            if (!resp.isSuccessful) return@use Result.Failed("서버 응답 오류 (${resp.code})")
            val j = JSONObject(resp.body?.string() ?: return@use Result.Failed("빈 응답"))
            val body = j.optString("body")
            val code = Regex("versionCode:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toLongOrNull()
                ?: return@use Result.Failed("릴리스에 버전 정보가 없어요")
            if (code <= currentCode(ctx)) return@use Result.UpToDate
            val assets = j.optJSONArray("assets") ?: return@use Result.Failed("릴리스에 APK 가 없어요")
            var url: String? = null
            var apiUrl = ""
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    url = a.optString("browser_download_url")
                    apiUrl = a.optString("url")
                    break
                }
            }
            if (url.isNullOrEmpty()) return@use Result.Failed("릴리스에 APK 가 없어요")
            if (!isTrustedUrl(url)) return@use Result.Failed("받을 주소가 안전하지 않아 중단했어요")
            val sha = Regex("sha256:\\s*([0-9a-fA-F]{64})").find(body)?.groupValues?.get(1)?.lowercase()
                ?: return@use Result.Failed("릴리스에 체크섬(sha256)이 없어 중단했어요")
            val name = Regex("versionName:\\s*(\\S+)").find(body)?.groupValues?.get(1)
                ?: j.optString("tag_name").removePrefix("v").ifEmpty { code.toString() }
            Result.Available(Release(name, code, url, sha, apiUrl))
        }
    }

    /** 설정의 '업데이트 확인' 을 눌렀을 때: 결과를 항상 알려 준다 */
    fun manualCheck(act: Activity) {
        AppToast.show(act, "업데이트 확인 중…")
        check(act) { res ->
            if (act.isFinishing || act.isDestroyed) return@check
            when (res) {
                is Result.UpToDate -> AppToast.show(act, "최신 버전이에요 (${BuildConfig.VERSION_NAME})")
                is Result.Failed -> AppToast.show(act, res.msg)
                is Result.Available -> showAvailable(act, res.release)
            }
        }
    }

    // ───────── 자동 업데이트 ─────────
    // 켜져 있으면(기본): 앱을 켤 때 새 버전을 찾아 Wi-Fi 같은 무제한 네트워크에서 조용히 받아 두고,
    // 앱이 화면에서 사라질 때(홈 · 다른 앱으로 이동) 설치한다. 안드로이드 12 이상이면 확인 창 없이 덮어써지고,
    // 그보다 낮거나 시스템이 확인을 요구하면 다음에 앱을 켰을 때 "업데이트 준비됨" 창에서 한 번만 누르면 된다.

    private const val KEY_AUTO = "auto_install"
    private const val ACTION_RESULT = "com.example.evergreen.UPDATE_RESULT"

    fun autoEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO, true)

    fun setAutoEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO, on).apply()
    }

    private fun unmetered(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.isActiveNetworkMetered.not()
    } catch (e: Exception) { false }

    private fun readyApk(ctx: Context) = File(updateDir(ctx), "evergreen-update.apk")

    /** 받아 둔 APK 가 지금 앱보다 새 버전이면 그 파일, 아니면(이미 설치됐거나 낡았으면) 지우고 null */
    private fun readyIfNewer(ctx: Context): File? {
        val f = readyApk(ctx)
        if (!f.exists()) return null
        val info = ctx.packageManager.getPackageArchiveInfo(f.path, 0)
        val code = info?.let { PackageInfoCompat.getLongVersionCode(it) } ?: -1L
        if (code <= currentCode(ctx) || !sameSigner(ctx, f)) { updateDir(ctx).listFiles()?.forEach { it.delete() }; return null }
        return f
    }

    /**
     * 앱이 화면에 돌아올 때마다 알아서: 새 버전이 있을 때만 알리고, 실패는 조용히 넘긴다 (30분 간격).
     * 확인이 실패하면 30분을 기다리지 않고 5분 뒤에 다시 확인한다.
     */
    fun autoCheck(act: Activity) {
        if (!enabled()) return
        // 지난번에 받아 두었는데 설치가 안 끝났다면 바로 알려 준다 (프로세스당 한 번)
        readyIfNewer(act)?.let { f ->
            if (readyPrompted) return
            readyPrompted = true
            ThemedDialogBuilder(act)
                .setTitle("업데이트 준비됨")
                .setMessage("새 버전을 이미 받아 두었어요. 지금 설치할까요?")
                .setPositiveButton("설치") { _, _ -> install(act, f) }
                .setNegativeButton("나중에", null)
                .show()
            return
        }
        if (quietBusy.get()) return
        val sp = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - sp.getLong(KEY_LAST_CHECK, 0L) < AUTO_INTERVAL_MS) return
        sp.edit().putLong(KEY_LAST_CHECK, now).apply()
        check(act) { res ->
            if (res is Result.Failed) {
                // 실패한 확인이 30분을 막아 버리지 않게, 5분 뒤에 다시 확인하도록 시계를 돌려 둔다
                sp.edit().putLong(KEY_LAST_CHECK, now - AUTO_INTERVAL_MS + RETRY_MS).apply()
                return@check
            }
            if (res !is Result.Available) return@check
            val app = act.applicationContext
            val alive = !act.isFinishing && !act.isDestroyed
            if (autoEnabled(app) && unmetered(app)) {
                if (canInstall(app)) downloadQuietly(app, res.release)
                else if (alive) askInstallPermission(act, res.release)
            } else if (alive) showAvailable(act, res.release)
        }
    }

    private fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    /**
     * 이 앱이 APK 를 설치해도 된다고 허용돼 있지 않으면 자동 설치가 조용히 아무 일도 안 한다.
     * 새 버전마다 한 번만 이유를 알리고 허용 화면으로 안내한다.
     */
    private fun askInstallPermission(act: Activity, r: Release) {
        val store = sp(act)
        if (store.getLong(KEY_PERM_ASKED, 0L) == r.versionCode) return
        store.edit().putLong(KEY_PERM_ASKED, r.versionCode).apply()
        ThemedDialogBuilder(act)
            .setTitle("자동 업데이트 허용")
            .setMessage("새 버전(${r.versionName})이 있어요. 자동으로 설치하려면 '이 출처 허용'을 한 번 켜 주세요.")
            .setPositiveButton("허용하러 가기") { _, _ ->
                // 허용하고 돌아오면 바로 다시 확인하도록 시계를 되돌린다
                store.edit().putLong(KEY_LAST_CHECK, 0L).apply()
                if (Build.VERSION.SDK_INT >= 26) {
                    act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}")))
                }
            }
            .setNegativeButton("나중에", null)
            .show()
    }

    /** 화면 없이 받아 둔다. 실패하면 5분 뒤 다시 시도한다. 다 받았을 때 앱이 이미 화면에 없으면 바로 설치한다 */
    private fun downloadQuietly(app: Context, r: Release) {
        if (!quietBusy.compareAndSet(false, true)) return
        Thread {
            try {
                fetchApk(app, r, java.util.concurrent.atomic.AtomicBoolean(false)) {}
                // 받는 동안 앱을 떠났다면 '화면을 떠날 때 설치' 시점이 이미 지났으므로 지금 설치한다
                if (AppForeground.current() == null) installReadyInBackground(app)
            } catch (e: Exception) {
                sp(app).edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis() - AUTO_INTERVAL_MS + RETRY_MS).apply()
            } finally {
                quietBusy.set(false)
            }
        }.start()
    }

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 앱이 화면에서 사라질 때 불린다: 받아 둔 새 버전이 있으면 설치기에 맡긴다 */
    fun installReadyInBackground(ctx: Context) {
        if (!enabled() || !autoEnabled(ctx)) return
        val app = ctx.applicationContext
        val apk = readyIfNewer(app) ?: return
        if (!canInstall(app)) return
        // 앱을 나갔다 들어왔다 할 때마다 같은 설치를 또 걸지 않게 1분은 건너뛴다
        val now = System.currentTimeMillis()
        if (now - lastCommitAt < 60_000L) return
        lastCommitAt = now
        Thread {
            try { commitSession(app, apk) } catch (e: Exception) { /* 못 하면 다음 실행 때 '업데이트 준비됨' 창으로 */ }
        }.start()
    }

    /**
     * 설치기 세션으로 APK 를 넘긴다. 이 앱이 직접 설치한 앱이 되어서, 안드로이드 12 이상에서는 다음 업데이트부터
     * 확인 창 없이 덮어써진다(보기 화면으로 열어 설치하면 시스템 설치기가 설치한 것으로 남아 늘 확인을 묻는다).
     */
    private fun commitSession(app: Context, apk: File) {
        val pi = app.packageManager.packageInstaller
        val params = android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(android.content.pm.PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val id = pi.createSession(params)
        pi.openSession(id).use { session ->
            apk.inputStream().use { input ->
                session.openWrite("evergreen.apk", 0, apk.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
            val pending = android.app.PendingIntent.getBroadcast(
                app, id, Intent(app, ResultReceiver::class.java).setAction(ACTION_RESULT), flags
            )
            session.commit(pending.intentSender)
        }
    }

    /**
     * 설치기가 알려 주는 결과. 확인이 필요하다고 하면, 앱이 화면에 떠 있을 때는 바로 띄우고
     * 떠 있지 않을 때는(안드로이드 10 이상은 뒤에서 화면을 띄울 수 없다) 알림으로 알린다.
     * 그래도 못 하면 다음 실행 때 '업데이트 준비됨' 창으로 안내한다.
     */
    class ResultReceiver : android.content.BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -999)) {
                android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    @Suppress("DEPRECATION")
                    val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT) ?: return
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (AppForeground.current() != null) {
                        try { ctx.startActivity(confirm); return } catch (e: Exception) { }
                    }
                    notifyConfirm(ctx, confirm)
                }
                android.content.pm.PackageInstaller.STATUS_SUCCESS -> updateDir(ctx).listFiles()?.forEach { it.delete() }
            }
        }
    }

    private const val CH_UPDATE = "app_update"

    /** 설치 확인 창을 눌러서 열 수 있는 알림 */
    private fun notifyConfirm(ctx: Context, confirm: Intent) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(android.app.NotificationChannel(CH_UPDATE, "앱 업데이트", android.app.NotificationManager.IMPORTANCE_DEFAULT))
            }
            val pi = android.app.PendingIntent.getActivity(
                ctx, 7701, confirm, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val n = androidx.core.app.NotificationCompat.Builder(ctx, CH_UPDATE)
                .setSmallIcon(R.drawable.ic_notif_evergreen)
                .setContentTitle("업데이트 준비됨")
                .setContentText("눌러서 새 버전을 설치하세요")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(7701, n)
        } catch (e: Exception) { /* 알림이 막혀 있으면 다음 실행 때 창으로 */ }
    }

    // ───────── 안내 · 받기 · 설치 ─────────

    private fun showAvailable(act: Activity, r: Release) {
        ThemedDialogBuilder(act)
            .setTitle("새 버전이 있어요")
            .setMessage("${BuildConfig.VERSION_NAME} → ${r.versionName}\n지금 받아서 업데이트할까요?")
            .setPositiveButton("업데이트") { _, _ -> startDownload(act, r) }
            .setNegativeButton("나중에", null)
            .show()
    }

    /** APK 를 받아 체크섬·서명까지 확인한다. 취소되면 InterruptedException, 실패하면 IllegalStateException. 화면은 건드리지 않는다 */
    private fun fetchApk(app: Context, r: Release, canceled: java.util.concurrent.atomic.AtomicBoolean, onProgress: (Int) -> Unit): File {
        val dir = updateDir(app).apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val tmp = File(dir, "evergreen-update.apk.part")
        val md = MessageDigest.getInstance("SHA-256")
        val token = runCatching { GitUpload.loadToken(app) }.getOrNull()
        fun get(url: String, auth: Boolean): okhttp3.Response {
            val b = Request.Builder().url(url).header("User-Agent", "evergreen-updater")
            if (auth && token != null) {
                // 비공개 저장소의 릴리스 파일: API 주소 + 토큰 + octet-stream 으로 받는다 (다른 호스트로 넘어가면 OkHttp 가 토큰을 빼 준다)
                b.header("Accept", "application/octet-stream")
                b.header("Authorization", "Bearer $token")
            }
            return client.newCall(b.build()).execute()
        }
        var first = get(r.apkUrl, false)
        if (!first.isSuccessful && token != null && r.assetApiUrl.isNotEmpty() && isTrustedUrl(r.assetApiUrl)) {
            first.close()
            first = get(r.assetApiUrl, true)
        }
        first.use { resp ->
            if (!resp.isSuccessful) {
                val hint = when (resp.code) {
                    404 -> " · 파일을 찾지 못했어요 (비공개 저장소면 파일 올리기에서 GitHub 토큰을 저장해 주세요)"
                    403, 429 -> " · GitHub 요청이 막혔어요. 잠시 뒤에 다시 눌러 주세요"
                    in 500..599 -> " · GitHub 서버 문제예요. 잠시 뒤에 다시 눌러 주세요"
                    else -> ""
                }
                throw IllegalStateException("서버 응답 오류 (${resp.code})$hint")
            }
            if (!isTrustedUrl(resp.request.url.toString())) throw IllegalStateException("안전하지 않은 주소로 넘어가 중단했어요")
            val body = resp.body ?: throw IllegalStateException("빈 응답")
            val total = body.contentLength()
            var done = 0L
            var lastPct = -1
            body.byteStream().use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        if (canceled.get()) throw InterruptedException()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        md.update(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
            }
        }
        if (tmp.length() <= 0L) throw IllegalStateException("받은 파일이 비어 있어요")
        if (hex(md.digest()) != r.sha256) {
            tmp.delete()
            throw IllegalStateException("파일이 손상됐거나 바뀌었어요 (체크섬 불일치)")
        }
        val apk = File(dir, "evergreen-update.apk")
        if (!tmp.renameTo(apk)) throw IllegalStateException("파일을 저장하지 못했어요")
        if (!sameSigner(app, apk)) {
            apk.delete()
            throw IllegalStateException("서명이 현재 앱과 달라 설치하지 않았어요")
        }
        return apk
    }

    private fun startDownload(act: Activity, r: Release) {
        val dp = act.resources.displayMetrics.density
        val label = TextView(act).apply { text = "받는 중…" }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = true
        }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((24 * dp).toInt(), (12 * dp).toInt(), (24 * dp).toInt(), 0)
            addView(label)
            addView(bar)
        }
        val canceled = java.util.concurrent.atomic.AtomicBoolean(false)
        val dlg = ThemedDialogBuilder(act)
            .setTitle("업데이트 받는 중")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("취소") { _, _ -> canceled.set(true) }
            .show()

        val app = act.applicationContext
        Thread {
            var err: String? = null
            var file: File? = null
            try {
                file = fetchApk(app, r, canceled) { pct ->
                    main.post {
                        bar.isIndeterminate = false
                        bar.progress = pct
                        label.text = "받는 중… $pct%"
                    }
                }
            } catch (e: InterruptedException) {
                // 사용자가 취소함
            } catch (e: Exception) {
                err = e.message ?: "받지 못했어요"
            }
            val doneFile = file
            val doneErr = err
            main.post {
                runCatching { dlg.dismiss() }
                when {
                    canceled.get() -> {}
                    doneErr != null -> AppToast.show(act, "업데이트를 받지 못했어요: $doneErr")
                    doneFile != null && !act.isFinishing && !act.isDestroyed -> install(act, doneFile)
                }
            }
        }.start()
    }

    private fun install(act: Activity, apk: File) {
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            // 이 앱이 APK 를 설치하도록 한 번 허용해야 한다. 허용하고 돌아와서 다시 '업데이트' 를 누른다.
            AppToast.show(act, "'이 출처 허용'을 켠 뒤 다시 업데이트해 주세요")
            act.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}"))
            )
            return
        }
        // 설치기 세션으로 넘겨야 이 앱이 설치한 앱이 되어 다음부터 자동 업데이트가 조용히 된다. 안 되면 예전 방식으로
        val app = act.applicationContext
        Thread {
            try { commitSession(app, apk) }
            catch (e: Exception) { main.post { installViaView(act, apk) } }
        }.start()
    }

    private fun installViaView(act: Activity, apk: File) {
        val uri = FileProvider.getUriForFile(act, "${act.packageName}.updates", apk)
        act.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
