package com.example.evergreen

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.webkit.WebView

/**
 * 세로 스크롤을 부모(PullRefreshLayout)에게 먼저 나눠 주는 WebView.
 *
 * 손가락이 움직이면 부모가 그 만큼을 먼저 써서 메뉴바를 밀어내고, 남은 움직임만 웹페이지가 스크롤한다.
 * (크롬처럼 메뉴바가 손가락을 그대로 따라 움직이고, 그동안 페이지는 제자리에 있다.)
 */
class NestedWebView(context: Context) : WebView(context) {
    private var lastY = 0
    private var nestedOffsetY = 0
    private val scrollOffset = IntArray(2)
    private val scrollConsumed = IntArray(2)

    /**
     * 백그라운드 재생: true 를 돌려주는 동안에는 앱이 화면 밖으로 나가거나 화면이 꺼져도
     * 이 웹뷰를 '안 보임' 상태로 바꾸지 않는다. 안 보임으로 바뀌면 WebView 가 소리까지 멈춰 버리는 기기가 많다.
     */
    var keepPlaying: () -> Boolean = { false }

    init {
        isNestedScrollingEnabled = true
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.VISIBLE && keepPlaying()) {
            // 보이는 상태 그대로 유지 (안 보임/없어짐 알림을 웹뷰에 전달하지 않는다)
            super.onWindowVisibilityChanged(View.VISIBLE)
            return
        }
        super.onWindowVisibilityChanged(visibility)
    }

    /** 두 손가락 이상(핀치 확대/축소) 제스처가 진행 중인지 */
    private var multiTouch = false

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val action0 = ev.actionMasked
        // 핀치 줌: 손가락이 둘 이상이면 중첩 스크롤(메뉴바 밀기)과 좌표 보정을 모두 끄고
        // 원본 이벤트를 WebView 에 그대로 전달한다. 그래야 줌 제스처가 깨지지 않는다.
        if (action0 == MotionEvent.ACTION_POINTER_DOWN || ev.pointerCount > 1) {
            if (!multiTouch) {
                multiTouch = true
                stopNestedScroll()
            }
            // 보정했던 오프셋이 남아 있으면 되돌려서 좌표가 어긋나지 않게 한다
            val raw = MotionEvent.obtain(ev)
            raw.offsetLocation(0f, nestedOffsetY.toFloat())
            val h = super.onTouchEvent(raw)
            raw.recycle()
            return h
        }
        if (multiTouch) {
            // 손가락 하나만 남았거나 제스처가 끝남 — 기준점을 다시 잡고 이번 제스처는 중첩 스크롤 없이 끝까지 WebView 에 맡긴다
            if (action0 == MotionEvent.ACTION_UP || action0 == MotionEvent.ACTION_CANCEL) {
                multiTouch = false
                nestedOffsetY = 0
                stopNestedScroll()
            }
            val raw = MotionEvent.obtain(ev)
            raw.offsetLocation(0f, nestedOffsetY.toFloat())
            val h = super.onTouchEvent(raw)
            raw.recycle()
            return h
        }

        val event = MotionEvent.obtain(ev)
        val action = event.actionMasked
        if (action == MotionEvent.ACTION_DOWN) nestedOffsetY = 0
        val eventY = event.y.toInt()
        event.offsetLocation(0f, nestedOffsetY.toFloat())
        val handled: Boolean
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                handled = super.onTouchEvent(event)
                lastY = eventY
                startNestedScroll(View.SCROLL_AXIS_VERTICAL)
            }
            MotionEvent.ACTION_MOVE -> {
                val deltaY = lastY - eventY
                if (dispatchNestedPreScroll(0, deltaY, scrollConsumed, scrollOffset)) {
                    lastY = eventY - scrollOffset[1]
                    event.offsetLocation(0f, (-scrollOffset[1]).toFloat())
                    nestedOffsetY += scrollOffset[1]
                } else {
                    lastY = eventY
                }
                handled = super.onTouchEvent(event)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                stopNestedScroll()
                handled = super.onTouchEvent(event)
            }
            else -> handled = super.onTouchEvent(event)
        }
        event.recycle()
        return handled
    }
}
