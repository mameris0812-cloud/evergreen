package com.example.evergreen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 방문 기록.
 * - 위쪽 칩으로 전체 / 오늘 / 어제 / 이전 기록을 걸러 본다.
 * - 항목을 누르면 현재 탭, ⋮ 메뉴(또는 길게 누르기)로 새 탭 열기 / 주소 복사 / 삭제
 * - 고른 주소는 북마크 화면과 같은 방식(EXTRA_URL)으로 MainActivity 에 돌려준다.
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var chipRow: LinearLayout
    private val adapter = RowAdapter()

    private val shown = ArrayList<HistoryItem>()
    private var selected = ALL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "방문 기록"
        findViewById<View>(R.id.btnListBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.btnListAction).apply {
            text = "모두 삭제"
            visibility = View.VISIBLE
            setOnClickListener { confirmClear() }
        }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        chipRow = findViewById(R.id.chipRow)
        listView.adapter = adapter

        refreshView()
    }

    private fun startOfToday(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun refreshView() {
        val all = prefs.historyItems()
        val today = startOfToday()
        val yesterday = today - DAY_MS

        fun inRange(h: HistoryItem, id: Long) = when (id) {
            TODAY -> h.time >= today
            YESTERDAY -> h.time in yesterday until today
            OLDER -> h.time < yesterday
            else -> true
        }

        val entries = listOf(
            ListUi.ChipEntry(ALL, "전체 (${all.size})"),
            ListUi.ChipEntry(TODAY, "오늘 (${all.count { inRange(it, TODAY) }})"),
            ListUi.ChipEntry(YESTERDAY, "어제 (${all.count { inRange(it, YESTERDAY) }})"),
            ListUi.ChipEntry(OLDER, "이전 (${all.count { inRange(it, OLDER) }})")
        )
        ListUi.renderChips(
            chipRow, entries, selected,
            onSelect = {
                selected = it
                refreshView()
            },
            onLongPress = { }
        )

        shown.clear()
        shown.addAll(all.filter { inRange(it, selected) })
        adapter.notifyDataSetChanged()

        if (shown.isEmpty()) {
            emptyView.text = if (selected == ALL) "방문 기록이 없습니다" else "이 기간의 방문 기록이 없습니다"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    private fun timeLabel(t: Long): String {
        if (t <= 0L) return ""
        val today = startOfToday()
        return when {
            t >= today -> SimpleDateFormat("a h:mm", Locale.KOREA).format(Date(t))
            t >= today - DAY_MS -> "어제 " + SimpleDateFormat("a h:mm", Locale.KOREA).format(Date(t))
            else -> SimpleDateFormat("M월 d일", Locale.KOREA).format(Date(t))
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)
            val h = shown[position]

            v.findViewById<ImageView>(R.id.rowIcon).setImageResource(R.drawable.ic_globe)
            v.findViewById<ProgressBar>(R.id.rowProgress).visibility = View.GONE
            v.findViewById<TextView>(R.id.rowTitle).text = ListUi.displayTitle(h.title, h.url)
            val label = timeLabel(h.time)
            v.findViewById<TextView>(R.id.rowSub).text = if (label.isEmpty()) h.url else "$label · ${h.url}"

            v.setOnClickListener { openUrl(h.url, newTab = false) }
            v.setOnLongClickListener {
                showMenu(h)
                true
            }
            v.findViewById<ImageButton>(R.id.rowMore).setOnClickListener { showMenu(h) }
            return v
        }
    }

    private fun openUrl(url: String, newTab: Boolean) {
        setResult(
            RESULT_OK,
            Intent().putExtra(BookmarksActivity.EXTRA_URL, url)
                .putExtra(BookmarksActivity.EXTRA_NEW_TAB, newTab)
        )
        finish()
    }

    private fun showMenu(h: HistoryItem) {
        Popup.menu(
            this,
            title = ListUi.displayTitle(h.title, h.url),
            subtitle = h.url,
            headerIcon = R.drawable.ic_globe,
            items = listOf(
                Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { openUrl(h.url, newTab = true) },
                Popup.Item(R.drawable.ic_copy, "주소 복사") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("url", h.url))
                    ListUi.toast(this, "복사했습니다")
                },
                Popup.Item(R.drawable.ic_delete, "기록에서 삭제", danger = true) {
                    prefs.removeHistory(h.url)
                    refreshView()
                }
            )
        )
    }

    private fun confirmClear() {
        if (prefs.historyItems().isEmpty()) {
            ListUi.toast(this, "삭제할 기록이 없습니다")
            return
        }
        Popup.confirm(this, "방문 기록 삭제", "방문 기록을 모두 삭제할까요?", "모두 삭제", danger = true) {
            prefs.clearHistory()
            refreshView()
        }
    }

    companion object {
        private const val DAY_MS = 24L * 60 * 60 * 1000
        private const val ALL = 0L
        private const val TODAY = 1L
        private const val YESTERDAY = 2L
        private const val OLDER = 3L
    }
}
