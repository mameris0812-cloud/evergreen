package com.example.evergreen

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * 탭 아이콘용 로딩 표시: 입체적으로 돌아가는 지구본.
 * 경선(세로선)이 구의 앞면을 따라 옆에서 나타났다 반대쪽으로 사라지며 돌고, 위도선은 살짝 기울어진 곡선으로 보인다.
 * [animator] 를 시작/취소해서 돌리고 멈춘다.
 */
class SpinningGlobeDrawable(private val color: Int) : Drawable() {

    private var angle = 0.0
    private val tilt = Math.toRadians(20.0)

    val animator: ValueAnimator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 2600
        interpolator = LinearInterpolator()
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { angle = (it.animatedValue as Float).toDouble(); invalidateSelf() }
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = this@SpinningGlobeDrawable.color
    }
    private val lines = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        color = ColorUtils.setAlphaComponent(this@SpinningGlobeDrawable.color, 215)
    }
    private val path = Path()

    private var cx = 0f
    private var cy = 0f
    private var r = 0f

    override fun draw(canvas: Canvas) {
        val b = bounds
        val size = min(b.width(), b.height()).toFloat()
        if (size <= 0f) return
        cx = b.exactCenterX(); cy = b.exactCenterY()
        r = size * 0.375f
        outline.strokeWidth = size * 1.8f / 24f
        lines.strokeWidth = size * 1.35f / 24f

        // 구의 면: 왼쪽 위에서 빛을 받는 은은한 음영 (입체감)
        fill.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.4f, r * 1.5f,
            intArrayOf(ColorUtils.setAlphaComponent(color, 80), ColorUtils.setAlphaComponent(color, 14)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, fill)

        // 위도선 (-40°, 0°, 40°) — 경도를 따라 한 바퀴 훑으며 앞쪽(보이는 쪽)만 그린다
        for (latDeg in intArrayOf(-40, 0, 40)) {
            val lat = Math.toRadians(latDeg.toDouble())
            var lon = 0
            curve(canvas) { if (lon > 360) null else (Math.toRadians(lon.toDouble()) to lat).also { lon += 10 } }
        }
        // 경선 6개 — 돌아가는 각도(angle)를 더해 앞면을 지나가게 한다
        for (k in 0 until 6) {
            val lon = k * PI / 3.0
            var lat = -90
            curve(canvas) { if (lat > 90) null else (lon to Math.toRadians(lat.toDouble())).also { lat += 10 } }
        }
        canvas.drawCircle(cx, cy, r, outline)
    }

    /** 점들을 이어 그리되, 구의 뒷면으로 넘어간 구간은 건너뛴다. next() 는 (경도, 위도) 를 주고 끝나면 null */
    private fun curve(canvas: Canvas, next: () -> Pair<Double, Double>?) {
        path.reset()
        var drawing = false
        var any = false
        while (true) {
            val p = next() ?: break
            val (lon, lat) = p
            val pt = project(lon, lat)
            if (pt[2] > 0f) {
                if (!drawing) { path.moveTo(pt[0], pt[1]); drawing = true } else path.lineTo(pt[0], pt[1])
                any = true
            } else drawing = false
        }
        if (any) canvas.drawPath(path, lines)
    }

    /** (경도, 위도) → 화면 x, y 와 깊이 z (z > 0 이면 앞면) */
    private fun project(lon: Double, lat: Double): FloatArray {
        val l = lon + angle
        val x = cos(lat) * sin(l)
        val y0 = sin(lat)
        val z0 = cos(lat) * cos(l)
        val y = y0 * cos(tilt) - z0 * sin(tilt)
        val z = y0 * sin(tilt) + z0 * cos(tilt)
        return floatArrayOf(cx + (r * x).toFloat(), cy - (r * y).toFloat(), z.toFloat())
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha; outline.alpha = alpha; lines.alpha = alpha * 215 / 255 }
    override fun setColorFilter(colorFilter: ColorFilter?) {
        fill.colorFilter = colorFilter; outline.colorFilter = colorFilter; lines.colorFilter = colorFilter
    }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
