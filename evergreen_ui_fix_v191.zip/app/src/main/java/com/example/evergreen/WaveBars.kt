package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * 메뉴 미디어 플레이어의 소리 막대 (파형).
 * - 실제 소리 값이 들어오면 그 값을 따라 움직인다 (올라갈 땐 빠르게, 내려갈 땐 천천히 — 소리 미터처럼).
 * - 사이트가 소리를 읽게 해 주지 않으면 재생 중에만 출렁이는 대체 움직임을 쓴다.
 * - 일시정지하면 막대가 부드럽게 가라앉아 작은 점이 된다.
 * 화면에 붙어 있고 움직일 게 있을 때만 프레임을 돌린다.
 */
class WaveBars @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object { const val N = 28 }

    var color = 0xFF2E9E5B.toInt()
        set(v) { field = v; paint.color = v; invalidate() }

    /** 가장 최근에 들어온 소리 값을 돌려주는 곳 (프레임마다 읽는다) */
    var source: (() -> MediaWave?)? = null

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = this@WaveBars.color }
    private val rect = RectF()
    private val shown = FloatArray(N)
    private var playing = false
    private var attached = false
    private var looping = false
    private var lastFrame = 0L
    private val t0 = SystemClock.uptimeMillis()

    fun setPlaying(p: Boolean) {
        if (p == playing) return
        playing = p
        kick()
    }

    private fun kick() {
        if (!attached || looping) return
        looping = true
        lastFrame = SystemClock.uptimeMillis()
        postOnAnimation(frame)
    }

    private val frame = object : Runnable {
        override fun run() {
            if (!attached) { looping = false; return }
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastFrame).coerceIn(8L, 50L).toFloat()
            lastFrame = now
            val motion = Motion.enabled(context)
            val w = if (playing) source?.invoke() else null
            val bands = w?.bands
            val real = w != null && !w.unavailable && bands != null && now - w.at < 500L
            val kUp = 1f - exp(-dt / 45f)    // 올라갈 때: 빠르게
            val kDown = 1f - exp(-dt / 170f) // 내려갈 때: 천천히
            var moving = false
            for (i in 0 until N) {
                val target = when {
                    !playing -> 0f
                    real -> (bands!![i.coerceAtMost(bands.size - 1)] * 1.35f).coerceIn(0f, 1f)
                    motion -> fake(i, now)
                    else -> 0.25f
                }
                val cur = shown[i]
                val next = if (!motion) target else cur + (target - cur) * (if (target > cur) kUp else kDown)
                shown[i] = next
                if (kotlin.math.abs(next - target) > 0.004f) moving = true
            }
            invalidate()
            // 재생 중이거나 아직 가라앉는 중이면 계속, 다 가라앉았으면 멈춘다
            if (playing || moving) postOnAnimation(this) else looping = false
        }
    }

    /** 실제 값이 없을 때: 박자감 있는 출렁임 (저음 쪽이 더 크게, 막대마다 위상이 다르게) */
    private fun fake(i: Int, now: Long): Float {
        val t = (now - t0) / 1000f
        val a = sin(t * 3.1f + i * 0.8f) * 0.5f + 0.5f
        val b = sin(t * 5.3f + i * 1.7f + 1.3f) * 0.5f + 0.5f
        val c = sin(t * 1.3f + i * 0.35f) * 0.5f + 0.5f
        val beat = 0.72f + 0.28f * sin(t * 2f * PI.toFloat() * 1.7f)
        val tilt = 1f - 0.45f * (i / N.toFloat())
        return ((0.5f * a + 0.3f * b + 0.2f * c) * tilt * beat).coerceIn(0.06f, 1f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize(suggestedMinimumWidth, widthMeasureSpec),
            resolveSize((32 * d).toInt(), heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val gap = 3 * d
        val bw = ((w - gap * (N - 1)) / N).coerceAtLeast(2 * d)
        val used = bw * N + gap * (N - 1)
        val left0 = (w - used) / 2f
        val cy = h / 2f
        // 일시정지일 땐 살짝 흐리게
        paint.alpha = if (playing) 255 else 130
        for (i in 0 until N) {
            val bh = bw + shown[i] * (h - bw)
            val l = left0 + i * (bw + gap)
            rect.set(l, cy - bh / 2f, l + bw, cy + bh / 2f)
            canvas.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        kick()
    }

    override fun onDetachedFromWindow() {
        attached = false
        looping = false
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }
}
