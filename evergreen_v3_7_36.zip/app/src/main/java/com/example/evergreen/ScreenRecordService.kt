package com.example.evergreen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 미러링 화면 녹화 서비스. 화면 녹화 허가(MediaProjection)를 받은 뒤 포그라운드로 떠서 [ScreenRecorder] 를 돌린다.
 * 앱이 작은 창(PiP)이 되거나 화면 밖으로 나가도 시스템이 멈추지 못하게 붙들고, 끝나면 mp4 를 다운로드 폴더에 저장한다.
 */
class ScreenRecordService : Service() {

    interface Listener {
        /** 녹화가 시작됐다. [startedAt] 은 SystemClock.elapsedRealtime 기준 시작 시각, [audio] 는 소리도 담는지 */
        fun onStarted(startedAt: Long, audio: Boolean)

        /** 녹화가 끝났다. 저장했으면 [name] 에 파일 이름, 못 했으면 [error] 에 이유 */
        fun onFinished(name: String?, error: String?)
    }

    companion object {
        private const val CH = "screen_record"
        private const val ID = 4302
        private const val ACTION_START = "com.example.evergreen.REC_START"
        private const val ACTION_STOP = "com.example.evergreen.REC_STOP"

        private val main = Handler(Looper.getMainLooper())
        @Volatile private var instance: ScreenRecordService? = null

        /** 녹화를 시작했거나 시작하는 중이다 (끝나서 저장 중일 때도 true) */
        @Volatile var active = false
            private set

        @Volatile var startedAt = 0L
            private set

        @Volatile var listener: Listener? = null

        fun start(ctx: Context, resultCode: Int, data: Intent, w: Int, h: Int, dpi: Int, audio: Boolean, title: String?) {
            if (active) return
            active = true
            try {
                ContextCompat.startForegroundService(
                    ctx,
                    Intent(ctx, ScreenRecordService::class.java).setAction(ACTION_START)
                        .putExtra("code", resultCode)
                        .putExtra("data", data)
                        .putExtra("w", w).putExtra("h", h).putExtra("dpi", dpi)
                        .putExtra("audio", audio)
                        .putExtra("title", title)
                )
            } catch (e: Exception) {
                active = false
                main.post { listener?.onFinished(null, "화면 녹화를 시작하지 못했어요") }
            }
        }

        /** 녹화를 멈추고 저장한다 */
        fun stop() {
            instance?.requestStop()
        }
    }

    private var projection: MediaProjection? = null
    private var recorder: ScreenRecorder? = null
    private var title: String? = null
    private val finishing = AtomicBoolean(false)
    private var sink: Sink? = null

    /**
     * 녹화 결과가 쓰이는 곳. 안드로이드 10+ 는 다운로드(MediaStore)에 '저장 중' 항목을 먼저 만들어 녹화하는 동안 바로 거기에 쓰고,
     * 끝나면 '저장 중' 표시만 풀어 준다(파일을 옮겨 복사하는 시간이 없다). 안드로이드 9 이하는 다운로드 폴더에 직접 쓴다.
     * 둘 다 안 되면 캐시에 쓰고 끝난 뒤 옮긴다([copyNeeded]).
     */
    private class Sink(val name: String, val uri: Uri?, val pfd: ParcelFileDescriptor?, val file: File, val copyNeeded: Boolean)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.action == ACTION_STOP) {
            requestStop()
            return START_NOT_STICKY
        }
        if (intent == null || intent.action != ACTION_START || recorder != null) {
            if (recorder == null) {
                active = false
                stopSelf()
            }
            return START_NOT_STICKY
        }
        instance = this
        title = intent.getStringExtra("title")
        // 허가를 받은 뒤 5초 안에 포그라운드로 올라야 한다 (안드로이드 14 부터는 이 순서가 필수)
        val at = SystemClock.elapsedRealtime()
        try {
            ServiceCompat.startForeground(
                this, ID, buildNotification(at),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
            )
        } catch (e: Exception) {
            failStart("화면 녹화를 시작하지 못했어요")
            return START_NOT_STICKY
        }
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra("data")
        if (data == null) {
            failStart("화면 녹화 허가를 받지 못했어요")
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("projection")
            projection = p
            // 안드로이드 14 부터는 화면을 담기 전에 콜백을 등록해야 한다. 시스템 알림 칩에서 중지해도 여기로 온다
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    requestStop()
                }
            }, main)
            val sk = openSink()
            sink = sk
            val rec = ScreenRecorder(
                p, intent.getIntExtra("w", 1080), intent.getIntExtra("h", 1920), intent.getIntExtra("dpi", 320),
                intent.getBooleanExtra("audio", false), sk.file, sk.pfd
            )
            rec.start()
            recorder = rec
            startedAt = at
            listener?.onStarted(at, rec.hasAudio)
        } catch (e: Throwable) {
            failStart(e.message?.takeIf { it.contains(' ') } ?: "화면 녹화를 시작하지 못했어요")
        }
        return START_NOT_STICKY
    }

    private fun failStart(msg: String) {
        try { projection?.stop() } catch (e: Throwable) { }
        projection = null
        discardSink(applicationContext)
        recorder = null
        active = false
        instance = null
        listener?.onFinished(null, msg)
        stopForegroundCompat()
        stopSelf()
    }

    /** 녹화를 마치고 파일을 다운로드 폴더에 저장한다 (인코더 마무리가 오래 걸릴 수 있어 별도 스레드에서) */
    fun requestStop() {
        if (!finishing.compareAndSet(false, true)) return
        val rec = recorder
        val ctx = applicationContext
        Thread {
            var err: String? = null
            var name: String? = null
            if (rec == null) {
                err = "녹화를 시작하지 못했어요"
                discardSink(ctx)
            } else {
                err = rec.stop()
                if (err == null) {
                    try {
                        name = finalizeSink(ctx)
                    } catch (e: Throwable) {
                        err = "녹화 파일을 저장하지 못했어요"
                        discardSink(ctx)
                    }
                } else {
                    discardSink(ctx)
                }
            }
            try { projection?.stop() } catch (e: Throwable) { }
            main.post {
                projection = null
                recorder = null
                active = false
                instance = null
                listener?.onFinished(name, err)
                stopForegroundCompat()
                stopSelf()
            }
        }.apply { isDaemon = true }.start()
    }

    private fun stopForegroundCompat() {
        try {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        } catch (e: Throwable) { }
    }

    override fun onDestroy() {
        // 서비스가 시스템에 의해 내려갈 때 파일이 반쯤 남지 않게 마무리한다
        if (recorder != null && !finishing.get()) {
            val e = try { recorder?.stop() } catch (x: Throwable) { "stop" }
            try {
                if (e == null) finalizeSink(applicationContext) else discardSink(applicationContext)
            } catch (x: Throwable) {
                discardSink(applicationContext)
            }
            try { projection?.stop() } catch (x: Throwable) { }
            recorder = null
            active = false
        }
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun buildNotification(startedAtElapsed: Long): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "화면 녹화", NotificationManager.IMPORTANCE_LOW))
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val open = launch?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif_evergreen)
            .setContentTitle("화면을 녹화하는 중이에요")
            .setContentText("누르면 앱으로 돌아가요")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setUsesChronometer(true)
            .setWhen(System.currentTimeMillis() - (SystemClock.elapsedRealtime() - startedAtElapsed))
            .setContentIntent(open)
            .addAction(0, "녹화 중지", stop)
            .build()
    }

    private fun buildName(): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeTitle = title?.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_")?.trim()?.take(60)?.takeIf { it.isNotBlank() }
        return if (safeTitle != null) "${safeTitle}_녹화_$stamp.mp4" else "화면녹화_$stamp.mp4"
    }

    /** 녹화 결과를 쓸 곳을 만든다 (위 [Sink] 설명 참고). 가능한 한 바로 최종 위치에 쓰는 쪽을 고른다 */
    private fun openSink(): Sink {
        val name = buildName()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var u: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw java.io.IOException("insert")
                // muxer 는 앞뒤로 오가며 쓰므로 읽기·쓰기 모두 되는 모드로 연다
                val pfd = contentResolver.openFileDescriptor(u, "rw") ?: throw java.io.IOException("open")
                return Sink(name, u, pfd, File(cacheDir, "unused.mp4"), false)
            } catch (e: Throwable) {
                if (u != null) try { contentResolver.delete(u, null, null) } catch (x: Throwable) { }
            }
        } else {
            try {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var f = File(dir, name)
                var i = 1
                while (f.exists()) f = File(dir, name.removeSuffix(".mp4") + " ($i).mp4").also { i++ }
                if (f.createNewFile()) return Sink(f.name, null, null, f, false)
            } catch (e: Throwable) { }
        }
        // 최종 위치에 바로 쓸 수 없으면 캐시에 쓰고 끝난 뒤 옮긴다
        return Sink(name, null, null, File(cacheDir, "rec_${System.currentTimeMillis()}.mp4"), true)
    }

    /** 녹화가 정상으로 끝났을 때: 저장을 마무리하고 완료 알림을 띄운다. 저장한 파일 이름을 돌려준다 */
    private fun finalizeSink(ctx: Context): String {
        val sk = sink ?: throw java.io.IOException("sink")
        sink = null
        var uri: Uri? = sk.uri
        var finalName = sk.name
        var size = 0L
        if (sk.copyNeeded) {
            // 바로 쓰지 못한 경우: 큰 덩어리로 옮겨 복사 시간을 줄인다
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, sk.name)
                    put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw java.io.IOException("insert")
                try {
                    ctx.contentResolver.openOutputStream(u)?.use { out -> sk.file.inputStream().use { it.copyTo(out, 1 shl 20) } }
                        ?: throw java.io.IOException("open")
                    ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                } catch (e: Throwable) {
                    try { ctx.contentResolver.delete(u, null, null) } catch (x: Throwable) { }
                    throw e
                }
                uri = u
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var f = File(dir, sk.name)
                var i = 1
                while (f.exists()) f = File(dir, sk.name.removeSuffix(".mp4") + " ($i).mp4").also { i++ }
                FileOutputStream(f).use { out -> sk.file.inputStream().use { it.copyTo(out, 1 shl 20) } }
                android.media.MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
                finalName = f.name
                size = f.length()
            }
            if (size == 0L) size = sk.file.length()
            try { sk.file.delete() } catch (e: Throwable) { }
        } else if (sk.uri != null) {
            // 이미 다 써 둔 파일: '저장 중' 표시만 풀면 끝
            ctx.contentResolver.update(sk.uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            size = try { ctx.contentResolver.openAssetFileDescriptor(sk.uri, "r")?.use { it.length } ?: 0L } catch (e: Throwable) { 0L }
        } else {
            android.media.MediaScannerConnection.scanFile(ctx, arrayOf(sk.file.absolutePath), null, null)
            size = sk.file.length()
        }
        DownloadNotifier.ensureChannel(ctx)
        DownloadNotifier.done(ctx, ID + 1, finalName, size, "video/mp4", uri)
        return finalName
    }

    /** 녹화가 실패했거나 너무 짧을 때: 만들어 둔 빈 항목·파일을 지운다 */
    private fun discardSink(ctx: Context) {
        val sk = sink ?: return
        sink = null
        try { sk.pfd?.close() } catch (e: Throwable) { }
        if (sk.uri != null) {
            try { ctx.contentResolver.delete(sk.uri, null, null) } catch (e: Throwable) { }
        } else {
            try { sk.file.delete() } catch (e: Throwable) { }
        }
    }
}
