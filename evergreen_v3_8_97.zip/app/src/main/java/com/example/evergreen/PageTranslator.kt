package com.example.evergreen

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * 웹페이지 번역 (AI 어시스턴트 채팅과는 따로 동작한다).
 * 열려 있는 페이지의 글자를 한국어로 바꾸고, 원문으로 되돌린다.
 * 기본은 키 없는 Google 번역, 'Gemini 로 번역'을 켜 두면 Gemini 를 쓴다.
 * 메뉴의 '페이지 번역' 줄과 AI 어시스턴트의 번역 칩이 같은 인스턴스를 같이 쓴다.
 */
class PageTranslator(
    private val activity: AppCompatActivity,
    private val prefs: Prefs,
    /** 이미지를 내려받을 때 쓸 웹뷰 정보 (User-Agent · 주소 · 쿠키). 열린 페이지가 없으면 null */
    private val imageEnv: () -> ImageEnv?,
    /** 지금 보는 페이지에서 JS 를 실행한다 (페이지가 없으면 결과는 null) */
    private val runPageJs: (String, (String?) -> Unit) -> Unit
) {
    /** 이미지를 웹뷰와 같은 조건으로 내려받기 위한 정보. [cookieFor] 는 메인 스레드에서만 부른다 */
    class ImageEnv(val userAgent: String, val referer: String, val cookieFor: (String) -> String)

    private class ImgItem(val k: Int, val url: String, val cookie: String)
    private class ImgResult(val k: Int, val w: Int, val h: Int, val boxes: JSONArray)

    private val ui = Handler(Looper.getMainLooper())

    /** 번역·되돌리기를 시작하기 직전에 부른다 (채팅 창을 닫는 등) */
    var onStart: (() -> Unit)? = null

    private val tpool = Executors.newFixedThreadPool(TRANSLATE_WORKERS)
    private var translating = false
    @Volatile private var tCancelled = false
    @Volatile private var tError: String? = null
    private var tCancels: List<() -> Unit> = emptyList()
    private val tCard = TranslateCard(activity) { prefs.translateCard }
    private var tDone = 0
    private val tApplied = AtomicInteger(0)

    /** 이번 번역이 '항상 번역'으로 저절로 시작된 것인지 / 도중에 다른 페이지로 이동해 멈췄는지 */
    private var autoRun = false
    @Volatile private var navAborted = false

    /** 이미지 글자 번역 중 처음 난 번역 오류 (이미지는 하나가 실패해도 나머지를 계속한다) */
    @Volatile private var imgErr: String? = null

    /**
     * 지금 열려 있는 웹페이지의 글자를 한국어로 바꾼다.
     * 화면에 보이는 부분부터 먼저 번역해서 바로바로 바뀌고, 나머지는 이어서 채운다.
     */
    fun translatePage(auto: Boolean = false) {
        if (translating) return
        // 키 없이도 된다: 키가 없거나 'Gemini 로 번역'이 꺼져 있으면 Google 번역을 쓴다
        val key = prefs.geminiKey
        val model = prefs.geminiModel
        // 직접 누른 번역일 때만 채팅 창 등을 먼저 정리한다 ('항상 번역'은 하던 일을 방해하지 않는다)
        if (!auto) onStart?.invoke()
        autoRun = auto
        navAborted = false
        translating = true
        tCancelled = false
        tError = null
        imgErr = null
        tDone = 0
        tApplied.set(0)
        // '항상 번역'은 번역할 글이 있다고 확인된 뒤에야 카드를 띄운다 (번역할 게 없는 페이지에서 조용히 넘어가려고)
        if (!auto) tCard.showSearching { cancelTranslate() }

        runPageJs(COLLECT_JS) { raw ->
            var token = ""
            var items: JSONArray? = null
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    val o = JSONObject(inner)
                    token = o.optString("id")
                    items = o.optJSONArray("items")
                }
            } catch (e: Exception) {
                items = null
            }
            val list = items
            if (list == null) {
                if (auto) quietFinish() else finishTranslate("번역할 수 없어요\n번역할 수 있는 웹페이지가 열려 있지 않아요")
            } else if (list.length() == 0) {
                // 본문 글이 없어도 이미지 속 글자 번역이 켜져 있으면 이미지를 찾아본다
                if (prefs.translateImages) startImagePhase(token, key, model)
                else if (auto) quietFinish() else finishTranslate("번역할 글이 없어요\n이미 한국어이거나 글이 없는 페이지예요")
            } else {
                if (auto) tCard.showSearching { cancelTranslate() }
                runBatches(token, list, key, model)
            }
        }
    }

    /**
     * 이미지를 꾹 눌러 나온 메뉴의 「이미지 번역」: 그 이미지 한 장의 글자만 읽어 번역하고 이미지 위에 덮는다.
     * (본문 글은 건드리지 않고, 「이미지 속 글자도 번역」 설정이 꺼져 있어도 된다)
     */
    fun translateImage(imageUrl: String) {
        if (translating) {
            cancelTranslate()
            return
        }
        val env = imageEnv()
        val key = prefs.geminiKey
        val model = prefs.geminiModel
        onStart?.invoke()
        autoRun = false
        navAborted = false
        translating = true
        tCancelled = false
        tError = null
        imgErr = null
        tDone = 0
        tApplied.set(0)
        tCard.showSearching { cancelTranslate() }
        if (env == null) {
            finishTranslate("번역할 수 없어요\n번역할 수 있는 웹페이지가 열려 있지 않아요")
            return
        }
        // 이 페이지 번역 작업의 표식을 새로 만들고(덮어쓰기 함수가 확인한다), 페이지의 이미지를 모아 눌러 둔 이미지를 찾는다
        runPageJs("(function(){var id=String(Math.random()).slice(2);window.__evId=id;return id})()") { tokRaw ->
            val token = try {
                JSONTokener(tokRaw ?: "null").nextValue()?.toString() ?: ""
            } catch (e: Exception) {
                ""
            }
            if (token.isEmpty() || token == "null") {
                finishTranslate("번역할 수 없어요\n번역할 수 있는 웹페이지가 열려 있지 않아요")
                return@runPageJs
            }
            runPageJs(IMG_COLLECT_JS) { raw ->
                var found: ImgItem? = null
                var lang = ""
                try {
                    val inner = JSONTokener(raw ?: "null").nextValue() as? String
                    if (inner != null) {
                        val o = JSONObject(inner)
                        lang = o.optString("lang")
                        val arr = o.optJSONArray("items")
                        val want = sameImageKey(imageUrl)
                        if (arr != null) {
                            for (k in 0 until arr.length()) {
                                val io = arr.getJSONObject(k)
                                val u = io.optString("u")
                                if (u.isEmpty()) continue
                                if (u == imageUrl || sameImageKey(u) == want) {
                                    val ck = if (u.startsWith("http")) env.cookieFor(u) else ""
                                    found = ImgItem(io.optInt("k"), u, ck)
                                    break
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    found = null
                }
                val item = found
                if (tCancelled) {
                    finishTranslate("번역을 취소했어요")
                } else if (item == null) {
                    finishTranslate("이미지를 찾지 못했어요\n이미 번역한 이미지이거나, 화면에서 찾을 수 없는 이미지예요")
                } else {
                    runImages(token, env, listOf(item), lang, key, model)
                }
            }
        }
    }

    /** 꾹 누른 이미지에 번역 덮개가 이미 올라가 있는지 (메뉴에서 「이미지 번역」 대신 「번역 해제」를 보여 줄 때) */
    fun isImageTranslated(imageUrl: String, cb: (Boolean) -> Unit) {
        runPageJs(imgMatchJs(imageUrl, "if(m.__evHas)n++")) { res -> cb((res?.trim()?.toIntOrNull() ?: 0) > 0) }
    }

    /** 그 이미지 한 장의 번역 덮개만 걷어 낸다. 걷어 낸 이미지 수를 돌려준다 */
    fun untranslateImage(imageUrl: String, cb: (Int) -> Unit) {
        runPageJs(imgMatchJs(imageUrl, "if(m.__evHas&&window.__evImgClearOne){window.__evImgClearOne(m);n++}")) { res ->
            cb(res?.trim()?.toIntOrNull() ?: 0)
        }
    }

    /** 페이지에서 주소가 [imageUrl] 과 같은(# 뒤 제외, lazy 로딩 주소 포함) 이미지마다 [body] 를 돌리고 n 을 돌려주는 JS */
    private fun imgMatchJs(imageUrl: String, body: String): String =
        "(function(){try{" +
            "function k(u){try{return new URL(u,document.baseURI).href.split('#')[0]}catch(e){return ''}}" +
            "var w=k(" + JSONObject.quote(sameImageKey(imageUrl)) + "),ims=document.images,n=0;" +
            "for(var i=0;i<ims.length;i++){var m=ims[i];" +
            "var c=[m.currentSrc,m.src,m.getAttribute('data-src'),m.getAttribute('data-original'),m.getAttribute('data-lazy-src'),m.getAttribute('data-url')];" +
            "for(var j=0;j<c.length;j++){if(c[j]&&k(c[j])===w){" + body + ";break}}}" +
            "return n}catch(e){return -1}})()"

    /** 같은 이미지인지 비교할 때 쓰는 값: 주소에서 # 뒤를 뺀 것 */
    private fun sameImageKey(u: String): String = u.substringBefore('#')

    private fun runBatches(token: String, items: JSONArray, key: String, model: String) {
        // 너무 크지 않게 묶어서 보낸다 (글자 약 3천 자 / 50문장 단위)
        val batches = ArrayList<JSONArray>()
        var cur = JSONArray()
        var chars = 0
        for (k in 0 until items.length()) {
            val o = items.getJSONObject(k)
            val len = o.optString("t").length
            if (cur.length() > 0 && (chars + len > 3000 || cur.length() >= 50)) {
                batches.add(cur)
                cur = JSONArray()
                chars = 0
            }
            cur.put(o)
            chars += len
        }
        if (cur.length() > 0) batches.add(cur)

        val total = batches.size
        tCard.progress(0, total)
        val next = AtomicInteger(0)
        val workersLeft = AtomicInteger(TRANSLATE_WORKERS)
        val clients = List(TRANSLATE_WORKERS) { GeminiClient() }
        val frees = List(TRANSLATE_WORKERS) { FreeTranslator() }
        tCancels = clients.map { c -> { c.cancel() } } + frees.map { f -> { f.cancel() } }

        for (w in 0 until TRANSLATE_WORKERS) {
            val c = clients[w]
            val f = frees[w]
            tpool.execute {
                while (!tCancelled && tError == null) {
                    val k = next.getAndIncrement()
                    if (k >= total) break
                    val (pairs, err) = translateBatch(c, f, key, model, batches[k])
                    if (tCancelled) break
                    if (pairs == null) {
                        if (tError == null) tError = err ?: "번역에 실패했어요"
                        break
                    }
                    tApplied.addAndGet(pairs.length())
                    ui.post { applyPairs(token, pairs, total) }
                }
                if (workersLeft.decrementAndGet() == 0) {
                    ui.post { afterTextPhase(token, key, model) }
                }
            }
        }
    }

    /** 본문 글 번역이 끝났을 때: 이미지 글자 번역이 켜져 있고 문제가 없었다면 이어서 이미지를 번역한다 */
    private fun afterTextPhase(token: String, key: String, model: String) {
        // '항상 번역' 중에 다른 페이지로 넘어간 건 오류가 아니니 조용히 끝낸다
        if (autoRun && navAborted) {
            quietFinish()
            return
        }
        if (prefs.translateImages && tError == null && !tCancelled) {
            startImagePhase(token, key, model)
            return
        }
        finalizeRun(0)
    }

    /** 번역을 마무리하는 안내. [imgN] 은 글자를 번역해 덮어 보여 준 이미지 수 */
    private fun finalizeRun(imgN: Int) {
        // 멈췄거나 끝났을 때 아직 남은 이미지 효과를 걷어 낸다
        runPageJs("(function(){try{if(window.__evImgFxClear)window.__evImgFxClear()}catch(e){}return 0})()") { }
        if (autoRun && navAborted) {
            quietFinish()
            return
        }
        val n = tApplied.get()
        val err = tError ?: (if (n == 0 && imgN == 0) imgErr else null)
        val total = n + imgN
        if (total == 0 && err == null && !tCancelled) {
            // 본문에도 이미지에도 번역할 글이 없었다
            if (autoRun) quietFinish()
            else finishTranslate("번역할 글이 없어요\n이미 한국어이거나 글을 찾지 못한 페이지예요")
            return
        }
        val part = when {
            n > 0 && imgN > 0 -> "${n}개 문장과 이미지 ${imgN}장"
            n > 0 -> "${n}개 문장"
            else -> "이미지 ${imgN}장"
        }
        finishTranslate(
            when {
                tCancelled && err != null -> err
                tCancelled -> if (total > 0) "번역을 멈췄어요\n${part}은 번역됐어요" else "번역을 취소했어요"
                err != null && total > 0 -> "일부만 번역했어요\n$err"
                err != null -> err
                else -> "번역 완료\n${part}을 한국어로 바꿨어요"
            },
            ok = !tCancelled && err == null && total > 0,
            restorable = total > 0
        )
    }

    // ───────────────────────── 이미지 속 글자 ─────────────────────────

    /**
     * 페이지의 이미지를 찾아, 글자를 읽고(기기 안) 번역해서 이미지 위에 덮어 보여 준다.
     * 화면에 보이는 이미지부터 최대 [IMG_MAX]장.
     */
    private fun startImagePhase(token: String, key: String, model: String) {
        val env = imageEnv()
        if (env == null) {
            finalizeRun(0)
            return
        }
        runPageJs(IMG_COLLECT_JS) { raw ->
            val items = ArrayList<ImgItem>()
            var lang = ""
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    val o = JSONObject(inner)
                    lang = o.optString("lang")
                    val arr = o.optJSONArray("items")
                    if (arr != null) {
                        for (k in 0 until arr.length()) {
                            val io = arr.getJSONObject(k)
                            val u = io.optString("u")
                            if (u.isEmpty()) continue
                            // 쿠키는 웹뷰에서만 꺼낼 수 있어서 여기(메인 스레드)서 미리 받아 둔다
                            val ck = if (u.startsWith("http")) env.cookieFor(u) else ""
                            items.add(ImgItem(io.optInt("k"), u, ck))
                        }
                    }
                }
            } catch (e: Exception) {
                items.clear()
            }
            if (tCancelled) {
                finalizeRun(0)
            } else if (items.isEmpty()) {
                finalizeRun(0)
            } else {
                runImages(token, env, items, lang, key, model)
            }
        }
    }

    private fun runImages(token: String, env: ImageEnv, items: List<ImgItem>, lang: String, key: String, model: String) {
        val total = items.size
        // 본문 글이 없어 카드가 아직 안 떴을 때만 띄운다 (사용자가 숨긴 카드를 다시 띄우지 않으려고)
        if (autoRun && tApplied.get() == 0 && !tCard.isShowing) tCard.showSearching { cancelTranslate() }
        tCard.progress(0, total, IMG_TITLE)
        val next = AtomicInteger(0)
        val done = AtomicInteger(0)
        val applied = AtomicInteger(0)
        val workersLeft = AtomicInteger(IMG_WORKERS)
        val clients = List(IMG_WORKERS) { GeminiClient() }
        val frees = List(IMG_WORKERS) { FreeTranslator() }
        tCancels = clients.map { c -> { c.cancel() } } + frees.map { f -> { f.cancel() } }

        for (w in 0 until IMG_WORKERS) {
            val c = clients[w]
            val f = frees[w]
            tpool.execute {
                while (!tCancelled) {
                    val k = next.getAndIncrement()
                    if (k >= total) break
                    val pageK = items[k].k
                    // 처리하는 동안 해당 이미지에 효과를 띄운다
                    ui.post { imgFx(token, pageK, true) }
                    val res = try {
                        processImage(env, items[k], lang, c, f, key, model)
                    } catch (e: Throwable) {
                        null
                    }
                    if (tCancelled) break
                    val d = done.incrementAndGet()
                    if (res == null) {
                        ui.post {
                            imgFx(token, pageK, false)
                            tCard.progress(d, total, IMG_TITLE)
                        }
                        continue
                    }
                    if (res.boxes.length() > 0) applied.incrementAndGet()
                    ui.post { applyImage(token, res, d, total) }
                }
                if (workersLeft.decrementAndGet() == 0) {
                    ui.post { finalizeRun(applied.get()) }
                }
            }
        }
    }

    /** 이미지 한 장: 내려받기 → 글자 읽기 → 번역. 못 읽은 이미지는 null */
    private fun processImage(
        env: ImageEnv, item: ImgItem, lang: String,
        c: GeminiClient, f: FreeTranslator, key: String, model: String
    ): ImgResult? {
        val bytes = AssistantImages.fetchBytes(item.url, env.userAgent, item.cookie, env.referer) ?: return null
        if (tCancelled) return null
        val ocr = ImageOcr.recognize(bytes, lang) ?: return null
        if (tCancelled) return null
        val boxes = JSONArray()
        val blocks = ocr.blocks
        // 키 없는 번역의 원문 언어 자동 감지는 짧은 이름·크레딧 줄에서 틀린다(「Written by Huma Raza」→ 스페인어로 착각). 알 때는 지정한다
        val src = when (ocr.lang) {
            "ja" -> "ja"
            "zh-CN" -> "zh-CN"
            "latin" -> {
                val h = lang.lowercase()
                if (h.isEmpty() || h.startsWith("en") || h.startsWith("ko") || h.startsWith("ja") || h.startsWith("zh")) "en" else "auto"
            }
            else -> "auto"
        }
        // 말풍선을 읽는 순서(위→아래, 세로쓰기면 오른쪽→왼쪽)로 늘어놓아, 번역기가 앞뒤 대사를 보고 말투·맥락을 맞추게 한다
        val order = readingOrder(blocks)
        var s = 0
        while (s < order.size) {
            val e = minOf(order.size, s + IMG_BATCH)
            val batch = JSONArray()
            for (n in s until e) batch.put(JSONObject().put("i", order[n]).put("t", blocks[order[n]].text))
            val (pairs, err) = translateBatch(c, f, key, model, batch, IMG_SYSTEM, src)
            if (tCancelled) return null
            if (pairs == null) {
                if (imgErr == null) imgErr = err ?: "번역에 실패했어요"
                return null
            }
            for (p in 0 until pairs.length()) {
                val pr = pairs.getJSONArray(p)
                val i = pr.getInt(0)
                val t = tidyImgText(pr.getString(1).trim())
                val b = blocks.getOrNull(i) ?: continue
                if (t.isEmpty() || t == b.text.trim()) continue
                boxes.put(
                    JSONObject()
                        .put("x", b.left).put("y", b.top)
                        .put("w", b.right - b.left).put("h", b.bottom - b.top)
                        .put("t", t)
                        .put("bg", ImageOcr.hex(b.bg)).put("fg", ImageOcr.hex(b.fg)).put("fs", b.fs).put("bl", if (b.blur) 1 else 0)
                )
            }
            s = e
        }
        return ImgResult(item.k, ocr.width, ocr.height, boxes)
    }

    /** 글자 덩어리를 읽는 순서의 번호 목록으로: 줄(띠)별로 위→아래, 한 줄 안에서는 세로쓰기가 많으면 오른쪽→왼쪽, 아니면 왼쪽→오른쪽 */
    private fun readingOrder(blocks: List<ImageOcr.Block>): List<Int> {
        if (blocks.size < 2) return blocks.indices.toList()
        val vert = blocks.count { (it.bottom - it.top) > (it.right - it.left) } * 2 > blocks.size
        val hs = blocks.map { it.bottom - it.top }.sorted()
        val band = maxOf(hs[hs.size / 2], 40)
        return blocks.indices.sortedWith(
            compareBy<Int> { blocks[it].top / band }
                .thenBy { if (vert) -blocks[it].right else blocks[it].left }
                .thenBy { blocks[it].top }
        )
    }

    /** 번역 중인 이미지에 효과(초록빛 스캔)를 켜고 끈다. 번역문을 덮을 때는 페이지 쪽에서 알아서 꺼진다 */
    private fun imgFx(token: String, k: Int, on: Boolean) {
        if (!translating || tCancelled) return
        runPageJs(
            "(function(){try{return window.__evImgBusy?window.__evImgBusy(" +
                JSONObject.quote(token) + "," + k + "," + (if (on) 1 else 0) + "):-1}catch(e){return -1}})()"
        ) { }
    }

    /** 번역한 글을 이미지 위에 덮어 보여 준다. */
    private fun applyImage(token: String, r: ImgResult, done: Int, total: Int) {
        if (!translating || tCancelled) return
        val js = "(function(){try{return window.__evImgApply?window.__evImgApply(" +
            JSONObject.quote(token) + "," + r.k + "," + r.w + "," + r.h +
            ",JSON.parse(" + JSONObject.quote(r.boxes.toString()) + ")):-1}catch(e){return -1}})()"
        runPageJs(js) { res ->
            val n = res?.trim()?.toIntOrNull() ?: -1
            if (n < 0) {
                // 다른 페이지로 이동했거나 탭이 바뀌었다
                navAborted = true
                if (tError == null) tError = "다른 페이지로 이동해서 번역을 멈췄어요"
                tCancelled = true
                tCancels.forEach { it() }
            } else {
                tCard.progress(done, total, IMG_TITLE)
            }
        }
    }

    /**
     * 한 묶음을 번역한다. (번역 결과, 오류 메시지)
     * 기본은 키 없는 Google 번역. 'Gemini 로 번역'을 켜 둔 경우엔 Gemini 를 먼저 쓰고,
     * 키 없는 번역이 막히면 (키가 있을 때) Gemini 로 대신한다.
     */
    private fun translateBatch(
        c: GeminiClient, f: FreeTranslator, key: String, model: String, batch: JSONArray,
        system: String = TRANSLATE_SYSTEM, source: String = "auto"
    ): Pair<JSONArray?, String?> {
        val hasKey = key.isNotBlank()
        if (hasKey && prefs.translateWithGemini) return geminiBatch(c, key, model, batch, system)
        val (res, err) = freeBatch(f, batch, source)
        if (res != null || tCancelled) return Pair(res, err)
        return if (hasKey) geminiBatch(c, key, model, batch, system) else Pair(null, err ?: "번역에 실패했어요")
    }

    /** 키 없는 번역으로 한 묶음 번역 */
    private fun freeBatch(f: FreeTranslator, batch: JSONArray, source: String = "auto"): Pair<JSONArray?, String?> {
        val idx = IntArray(batch.length())
        val texts = ArrayList<String>(batch.length())
        for (k in 0 until batch.length()) {
            val o = batch.getJSONObject(k)
            idx[k] = o.optInt("i", -1)
            texts.add(o.optString("t"))
        }
        var lastErr: String? = null
        for (attempt in 0..1) {
            if (tCancelled) return Pair(null, null)
            val (tr, err) = f.translate(texts, "ko", source)
            if (tCancelled) return Pair(null, null)
            if (tr != null) {
                val out = JSONArray()
                for (k in tr.indices) {
                    if (idx[k] >= 0 && tr[k].isNotBlank()) out.put(JSONArray().put(idx[k]).put(tr[k]))
                }
                return if (out.length() == 0) Pair(null, "번역 결과를 읽지 못했어요") else Pair(out, null)
            }
            lastErr = err
            if (attempt == 0) {
                try {
                    Thread.sleep(1200)
                } catch (ie: InterruptedException) {
                    return Pair(null, null)
                }
            }
        }
        return Pair(null, lastErr)
    }

    /** Gemini 로 한 묶음을 번역한다. 실패하면 한 번 더 시도한다. */
    private fun geminiBatch(c: GeminiClient, key: String, model: String, batch: JSONArray, system: String = TRANSLATE_SYSTEM): Pair<JSONArray?, String?> {
        var lastErr: String? = null
        for (attempt in 0..1) {
            if (tCancelled) return Pair(null, null)
            val sb = StringBuilder()
            var err: String? = null
            c.stream(
                key, model, system, listOf(ChatMsg("user", batch.toString())),
                onDelta = { sb.append(it) },
                onDone = {},
                onError = { err = it },
                json = true
            )
            if (tCancelled) return Pair(null, null)
            val e = err
            if (e == null) {
                val parsed = parsePairs(sb.toString())
                if (parsed != null) return Pair(parsed, null)
                lastErr = "번역 결과를 읽지 못했어요"
            } else {
                lastErr = e
            }
            if (attempt == 0) {
                try {
                    Thread.sleep(1200)
                } catch (ie: InterruptedException) {
                    return Pair(null, null)
                }
            }
        }
        return Pair(null, lastErr)
    }

    private fun parsePairs(textIn: String): JSONArray? {
        var t = textIn.trim()
        if (t.startsWith("```")) t = t.substringAfter('\n').substringBeforeLast("```").trim()
        return try {
            val arr = JSONArray(t)
            val out = JSONArray()
            for (k in 0 until arr.length()) {
                val o = arr.optJSONObject(k) ?: continue
                val i = o.optInt("i", -1)
                val tr = o.optString("t", "")
                if (i >= 0 && tr.isNotBlank()) out.put(JSONArray().put(i).put(tr))
            }
            if (out.length() == 0) null else out
        } catch (e: Exception) {
            null
        }
    }

    /** 번역된 글을 웹페이지에 바로 끼워 넣는다. */
    private fun applyPairs(token: String, pairs: JSONArray, total: Int) {
        if (!translating || tCancelled) return
        val js = "(function(){try{return window.__evApply?window.__evApply(" +
            JSONObject.quote(token) + ",JSON.parse(" + JSONObject.quote(pairs.toString()) + ")):-1}catch(e){return -1}})()"
        runPageJs(js) { r ->
            val n = r?.trim()?.toIntOrNull() ?: -1
            if (n < 0) {
                // 다른 페이지로 이동했거나 탭이 바뀌었다
                navAborted = true
                if (tError == null) tError = "다른 페이지로 이동해서 번역을 멈췄어요"
                tCancelled = true
                tCancels.forEach { it() }
            } else {
                tDone++
                tCard.progress(tDone, total)
            }
        }
    }

    private fun cancelTranslate() {
        tCancelled = true
        tCancels.forEach { it() }
    }

    /** 카드나 안내 없이 번역을 끝낸다 ('항상 번역'에서 번역할 게 없거나 페이지를 떠났을 때) */
    private fun quietFinish() {
        translating = false
        tCard.dismiss()
    }

    private fun finishTranslate(msg: String, ok: Boolean = false, restorable: Boolean = false) {
        translating = false
        val lines = msg.split("\n", limit = 2)
        tCard.finish(
            lines[0], lines.getOrNull(1), ok,
            if (restorable) "원문 보기" else null,
            if (restorable) ({ restorePage() }) else null
        )
    }

    /**
     * 메뉴의 '페이지 번역' 한 줄에서 부른다 (채팅 창 없이, 키 없이).
     * 번역 중이면 멈추고, 이미 번역된 페이지면 원문으로 되돌리고, 아니면 번역한다.
     */
    fun togglePageTranslation() {
        if (translating) {
            cancelTranslate()
            return
        }
        runPageJs("(function(){return window.__evT===1?1:0})()") { r ->
            if (r?.trim() == "1") restorePage() else translatePage()
        }
    }

    /**
     * 페이지 로딩이 끝났을 때 부른다. '항상 번역'이 켜져 있으면 저절로 번역한다.
     * (글이 늦게 채워지는 페이지가 많아서 잠깐 기다렸다가 시작한다)
     */
    fun onPageLoaded(url: String) {
        if (!prefs.alwaysTranslate || !url.startsWith("http")) return
        ui.postDelayed({ autoTranslate(0) }, 700)
    }

    /** '항상 번역'을 막 켰을 때: 지금 보는 페이지도 바로 번역한다 */
    fun translateCurrentIfNeeded() {
        if (prefs.alwaysTranslate) autoTranslate(0)
    }

    private fun autoTranslate(attempt: Int) {
        if (!prefs.alwaysTranslate) return
        if (translating) {
            // 이전 페이지 번역이 아직 끝나지 않았으면 멈추고 잠깐 뒤에 다시 시도한다
            if (attempt < 6) {
                cancelTranslate()
                ui.postDelayed({ autoTranslate(attempt + 1) }, 400)
            }
            return
        }
        runPageJs("(function(){return window.__evT===1?1:0})()") { r ->
            // 이미 번역된 페이지(같은 페이지 안에서 다시 로딩이 끝난 경우)는 건드리지 않는다
            if (r?.trim() != "1" && !translating) translatePage(auto = true)
        }
    }

    // ───────────────────────── 번역 설정 ─────────────────────────

    private fun dp(n: Int) = (n * activity.resources.displayMetrics.density).toInt()

    /** 번역 설정 창: 항상 번역 · Gemini 사용 · 이미지 속 글자 · 진행 카드 */
    fun showSettings() {
        val hasKey = prefs.geminiKey.isNotBlank()
        val sub = ThemeColors.get(activity, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        fun note(text: String) = TextView(activity).apply {
            this.text = text
            textSize = 12f
            setTextColor(sub)
            setPadding(dp(4), 0, 0, dp(10))
        }
        val always = MaterialCheckBox(activity).apply {
            text = "항상 번역"
            textSize = 14f
            isChecked = prefs.alwaysTranslate
        }
        box.addView(always)
        box.addView(note("페이지를 열 때마다 저절로 한국어로 번역해요. 이미 한국어인 페이지는 그대로 둬요."))
        val gemTr = MaterialCheckBox(activity).apply {
            text = "번역에 Gemini 사용"
            textSize = 14f
            isChecked = prefs.translateWithGemini && hasKey
            isEnabled = hasKey
        }
        box.addView(gemTr)
        box.addView(note(
            if (hasKey) "끄면 키 없이 Google 번역으로 번역해요."
            else "Gemini API 키가 있어야 쓸 수 있어요 (AI 설정에서 입력). 키가 없어도 Google 번역으로 번역돼요."
        ))
        val imgTr = MaterialCheckBox(activity).apply {
            text = "이미지 속 글자도 번역"
            textSize = 14f
            isChecked = prefs.translateImages
        }
        box.addView(imgTr)
        box.addView(note("만화·웹툰·캡처 같은 이미지 안의 글자를 읽어서, 이미지 위에 한국어로 덮어 보여줘요. 글자 읽기는 기기 안에서 하고 번역만 인터넷을 써요. 이미지가 많으면 시간이 더 걸려요."))
        val card = MaterialCheckBox(activity).apply {
            text = "번역 진행 카드 표시"
            textSize = 14f
            isChecked = prefs.translateCard
        }
        box.addView(card)
        box.addView(note("끄면 카드 없이 번역하고, 끝났을 때 짧은 안내만 보여요. 카드는 아래로 밀거나 ⌄ 를 눌러 그때그때 숨길 수도 있어요."))

        ThemedDialogBuilder(activity)
            .setTitle("번역 설정")
            .setView(box)
            .setPositiveButton("저장") { _, _ ->
                val wasAlways = prefs.alwaysTranslate
                prefs.alwaysTranslate = always.isChecked
                prefs.translateWithGemini = gemTr.isChecked && prefs.geminiKey.isNotBlank()
                prefs.translateImages = imgTr.isChecked
                prefs.translateCard = card.isChecked
                if (always.isChecked && !wasAlways) translateCurrentIfNeeded()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    /** 번역한 글을 원래 글로 되돌린다. */
    fun restorePage() {
        onStart?.invoke()
        runPageJs("(function(){var a=window.__evRestore?window.__evRestore():0;var b=window.__evImgClear?window.__evImgClear():0;window.__evT=0;return a+b})()") { r ->
            val n = r?.trim()?.toIntOrNull() ?: 0
            if (n > 0) tCard.finish("원문으로 되돌렸어요", null, ok = true, actionLabel = "다시 번역", onActionClick = { translatePage() }, withBar = false)
            else tCard.finish("되돌릴 번역이 없어요", null, ok = false, withBar = false)
        }
    }

    companion object {
        private const val TRANSLATE_WORKERS = 3

        /** 이미지 글자 번역: 동시에 처리하는 이미지 수 / 한 번에 번역 요청하는 글 덩어리 수 / 한 번에 다루는 이미지 수 / 카드 제목 */
        private const val IMG_WORKERS = 2
        private const val IMG_BATCH = 40
        private const val IMG_TITLE = "이미지 속 글자 번역 중"

        /** 만화·웹툰 말풍선처럼 이미지에서 글자 인식으로 읽어 낸 글을 번역할 때의 지시문 */
/** 번역기가 원문을 괄호로 덧붙이는 것(「아르빌레(Arbhylle Artiaga)의 그림」)을 걷어 낸다. 한글이 있을 때만, 영문 두 글자 이상인 괄호만 */
        private val LATIN_PAREN = Regex("\\s*[(（][A-Za-z][A-Za-z0-9 .,'’&\\-]+[)）]")

        private fun tidyImgText(t: String): String {
            if (!t.any { it in '\uAC00'..'\uD7A3' }) return t
            return LATIN_PAREN.replace(t, "").trim()
        }

        private const val IMG_SYSTEM =
            "You translate text that OCR read from images (comic, manga and webtoon speech bubbles, captions, signs) into natural Korean. " +
                "Input is a JSON array of {\"i\": number, \"t\": string}, listed in reading order; neighbouring items are usually one conversation, " +
                "so keep speakers' tone and context consistent (casual talk between friends stays casual) and keep character names consistent (transliterate names into Korean). " +
                "The OCR text may contain mistakes: for example the Japanese long-vowel mark \"ー\" may appear as 1, l or |, and kanji or small kana may be misread. " +
                "Use context to fix obvious misreads before translating. " +
                "Keep each translation short and natural, as spoken in a speech bubble, so it fits the bubble. " +
                "Translate sound effects into Korean onomatopoeia. Do not add explanations or notes. " +
                "Translate EVERYTHING into Korean, including titles, credits, signs, logos and brand names: write personal names, place names, brand names and any other English words that have no Korean equivalent in Hangul (transliteration, e.g. \"Heedal Kim\" -> \"김희달\", \"Created by\" -> \"제작\", \"Copyright\" -> \"저작권\"). " +
                "Never leave Latin letters in the translation, never repeat the original in parentheses, and keep only universal abbreviations such as TV, OK or CD as they are. " +
                "If a text is already Korean or is not real text (a logo fragment, noise, random letters), return it unchanged. " +
                "Return ONLY a JSON array of the same length with the same \"i\" values: [{\"i\":0,\"t\":\"번역\"}]."

        private const val TRANSLATE_SYSTEM =
            "You are a translation engine for web page text. " +
                "Input is a JSON array of {\"i\": number, \"t\": string}. " +
                "Translate every \"t\" into natural Korean. " +
                "Keep brand names, product names, code, numbers, URLs and emoji as they are. " +
                "Keep short UI labels (buttons, menus) short. Do not add explanations or notes. " +
                "If a text is already Korean or cannot be translated, return it unchanged. " +
                "Return ONLY a JSON array of the same length with the same \"i\" values: [{\"i\":0,\"t\":\"번역\"}]."

        /**
         * 페이지의 글자(본문 글, 입력창 안내문, 버튼 글)를 모아서 돌려주고,
         * 번역 결과를 끼워 넣는 함수(__evApply)와 되돌리는 함수(__evRestore)를 페이지에 심는다.
         * 화면에 보이는 글이 앞에 오도록 정렬한다.
         */
        private const val COLLECT_JS = """(function(){
try{
var id=String(Math.random()).slice(2);
var T=[],R=window.__evR=window.__evR||[];
var vh=window.innerHeight||800;
function skipText(s){
  var l=(s.match(/[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF\u0590-\u06FF\u0900-\u0DFF\u0E00-\u0E7F\u3040-\u30FF\u3400-\u9FFF\uAC00-\uD7A3]/g)||[]).length;
  if(l===0)return true;
  var h=(s.match(/[\uAC00-\uD7A3]/g)||[]).length;
  return h/l>0.4;
}
function lead(s){return s.slice(0,s.length-s.replace(/^\s+/,'').length)}
function trail(s){return s.slice(s.trimEnd().length)}
var BAD='script,style,noscript,textarea,code,pre,svg,template,iframe,[contenteditable=""],[contenteditable="true"],[translate="no"],.notranslate';
var chars=0;
var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);
var n;
while((n=w.nextNode())){
  if(T.length>=2500||chars>90000)break;
  var p=n.parentElement;if(!p)continue;
  var s=n.nodeValue;if(!s)continue;
  var t=s.trim();if(!t||skipText(t))continue;
  if(p.closest(BAD))continue;
  if(!p.getClientRects().length)continue;
  if(n.__evo===undefined){n.__evo=s;(function(nn){R.push(function(){nn.nodeValue=nn.__evo})})(n);}
  (function(nn,pp,t0,a,b){T.push({y:pp.getBoundingClientRect().top,t:t0,el:pp,set:function(v){nn.nodeValue=a+v+b}})})(n,p,t,lead(s),trail(s));
  chars+=t.length;
}
var els=document.querySelectorAll('input[placeholder],textarea[placeholder],input[type=submit],input[type=button]');
for(var k=0;k<els.length&&T.length<2600;k++){
  var el=els[k];
  var at=el.hasAttribute('placeholder')?'placeholder':'value';
  var v=el.getAttribute(at)||'';var tv=v.trim();
  if(!tv||skipText(tv)||!el.getClientRects().length)continue;
  if(el['__evo_'+at]===undefined){el['__evo_'+at]=v;(function(e,a){R.push(function(){e.setAttribute(a,e['__evo_'+a])})})(el,at);}
  (function(e,a,t0){T.push({y:e.getBoundingClientRect().top,t:t0,el:e,set:function(x){e.setAttribute(a,x)}})})(el,at,tv);
}
var order=[];for(var i=0;i<T.length;i++)order.push(i);
function vis(i){var y=T[i].y;return y>-vh*0.5&&y<vh*1.5}
order=order.filter(vis).concat(order.filter(function(i){return !vis(i)}));
window.__evId=id;
function fl(e){try{
  if(!e||e===document.body||e===document.documentElement||!e.animate)return;
  var r=e.getBoundingClientRect();if(r.bottom<0||r.top>vh)return;
  e.animate([{textShadow:'0 0 12px rgba(47,163,91,0.95), 0 0 3px rgba(47,163,91,0.8)'},{textShadow:'0 0 0 rgba(47,163,91,0)'}],{duration:1100,easing:'ease-out'});
}catch(x){}}
window.__evApply=function(tok,pairs){
  if(tok!==window.__evId)return -1;
  var c=0;
  for(var k=0;k<pairs.length;k++){var it=T[pairs[k][0]];if(it){try{it.set(pairs[k][1]);c++;fl(it.el)}catch(e){}}}
  if(c>0)window.__evT=1;
  return c;
};
window.__evRestore=function(){
  var c=0;
  for(var k=0;k<R.length;k++){try{R[k]();c++}catch(e){}}
  window.__evT=0;
  return c;
};
return JSON.stringify({id:id,items:order.map(function(i){return {i:i,t:T[i].t}})});
}catch(e){return JSON.stringify({id:'',items:null})}
})()"""

        /**
         * 번역할 이미지를 모아서 돌려주고(화면에 보이는 것 먼저, 최대 40장),
         * 번역한 글을 이미지 위에 덮는 함수(__evImgApply)와 지우는 함수(__evImgClear)를 페이지에 심는다.
         * 덮는 글은 페이지 글 안에 끼워 넣지 않고 문서 맨 끝의 따로 둔 층에 올려서, 이미지 위치를 따라다니게 한다.
         */
        private const val IMG_COLLECT_JS = """(function(){
try{
if(!window.__evImgInit){
window.__evImgInit=1;
(function(){
var G=[],root=null,pend=0;
function ensureRoot(){
  if(root&&root.isConnected)return root;
  root=document.createElement('div');
  root.id='__ev_img_root';
  root.className='notranslate';
  root.setAttribute('translate','no');
  root.style.cssText='position:absolute;left:0;top:0;width:0;height:0;overflow:visible;z-index:2147483000;pointer-events:none;';
  document.documentElement.appendChild(root);
  return root;
}
function fit(b,s){
  var w=Math.max(4,b.w*s),h=Math.max(4,b.h*s),st=b.el.style;
  st.left=(b.x*s)+'px';st.top=(b.y*s)+'px';st.width=w+'px';st.height=h+'px';
  var cap=b.fs?Math.max(10,b.fs*s*1.5):56,sp=b.sp;
  function run(v){
    sp.style.writingMode=v?'vertical-rl':'horizontal-tb';
    sp.style.textOrientation=v?'upright':'mixed';
    sp.style.width=v?'auto':'100%';
    sp.style.height=v?'100%':'auto';
    var lo=5,hi=Math.max(6,Math.min((v?w:h)*0.9,56,cap)),m,i;
    for(i=0;i<7;i++){
      m=(lo+hi)/2;sp.style.fontSize=m+'px';
      if(sp.offsetHeight<=h-2&&sp.scrollWidth<=w+1)lo=m;else hi=m;
    }
    return lo;
  }
  var best=run(false),vert=false;
  // 한글은 가로로 쓰는 글이라, 긴 문장을 한 글자씩 세워 쓰면 어색하다 → 짧은 말(6글자 이하: '뭐', '가자.' 같은 것)만 세로로 쓴다
  if(h>w*1.5&&sp.textContent.replace(/\s/g,'').length<=6){var vs=run(true);if(vs>best*1.15){vert=true;best=vs}}
  if(!vert)run(false);
  sp.style.fontSize=best+'px';
}
function place(){
  pend=0;
  var sx=window.pageXOffset||0,sy=window.pageYOffset||0;
  for(var i=0;i<G.length;i++){
    var g=G[i],im=g.img,st=g.el.style;
    if(!im.isConnected){st.display='none';continue}
    var r=im.getBoundingClientRect();
    if(r.width<2||r.height<2){st.display='none';continue}
    st.display='block';
    st.left=(r.left+sx)+'px';st.top=(r.top+sy)+'px';st.width=r.width+'px';st.height=r.height+'px';
    if(Math.abs(r.width-g.lw)>1.5){
      g.lw=r.width;var s=r.width/g.nw;
      for(var j=0;j<g.boxes.length;j++)fit(g.boxes[j],s);
    }
  }
}
function sched(){if(!pend){pend=1;requestAnimationFrame(place)}}
window.addEventListener('scroll',sched,true);
window.addEventListener('resize',sched);
setInterval(function(){if(G.length)sched()},800);
function dropFx(img,fade){
  for(var i=0;i<G.length;i++){
    if(G[i].fx&&G[i].img===img){
      var el=G[i].el;G.splice(i,1);
      if(fade){
        try{var ss=el.querySelectorAll('.ev-star');for(var u=0;u<ss.length;u++)ss[u].animate([{opacity:1,transform:'scale(1) rotate(45deg)'},{opacity:0,transform:'scale(1.9) rotate(90deg)'}],{duration:420,easing:'ease-out',fill:'forwards'})}catch(e){}
        try{el.animate([{opacity:1},{opacity:0}],{duration:520,easing:'ease-out',fill:'forwards'}).onfinish=function(){try{el.remove()}catch(e){}};return}catch(e){}
      }
      try{el.remove()}catch(e){}
      return;
    }
  }
}
window.__evImgBusy=function(tok,k,on){
  if(tok!==window.__evId)return -1;
  return 1;
};
window.__evImgFxClear=function(){
  for(var i=G.length-1;i>=0;i--){
    if(G[i].fx){try{G[i].el.remove()}catch(e){}G.splice(i,1)}
  }
  return 1;
};
window.__evImgApply=function(tok,k,nw,nh,boxes){
  if(tok!==window.__evId)return -1;
  var img=window.__evImgs&&window.__evImgs[k];
  if(!img||!img.isConnected||!nw||!nh){if(img)dropFx(img,true);return 0}
  dropFx(img,true);
  if(!boxes.length)return 0;
  img.__evHas=1;
  var el=document.createElement('div');
  el.style.cssText='position:absolute;pointer-events:none;overflow:visible;';
  var g={img:img,el:el,nw:nw,nh:nh,lw:0,boxes:[]};
  for(var i=0;i<boxes.length;i++){
    var o=boxes[i],d=document.createElement('div'),sp=document.createElement('span');
    var bl=o.bl===1,hn=parseInt((o.bg||'#ffffff').slice(1),16)||0,rgb=(hn>>16&255)+','+(hn>>8&255)+','+(hn&255);
    d.style.cssText='position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;text-align:center;overflow:hidden;padding:1px 2px;border-radius:'+(bl?8:4)+'px;background:'+(bl?'rgba('+rgb+',0.78)':o.bg)+';color:'+o.fg+';'+(bl?'-webkit-backdrop-filter:blur(9px);backdrop-filter:blur(9px);':'');
    sp.style.cssText='display:block;width:100%;font-weight:700;line-height:1.18;letter-spacing:-0.01em;word-break:keep-all;overflow-wrap:anywhere;font-family:-apple-system,"Noto Sans KR","Apple SD Gothic Neo",sans-serif;';
    if(bl)sp.style.textShadow='0 0 2px rgb('+rgb+'),0 0 4px rgb('+rgb+'),0 0 7px rgb('+rgb+')';
    sp.textContent=o.t;
    d.appendChild(sp);el.appendChild(d);
    g.boxes.push({el:d,sp:sp,x:o.x,y:o.y,w:o.w,h:o.h,fs:o.fs||0});
  }
  ensureRoot().appendChild(el);
  G.push(g);
  place();
  try{
    for(var j=0;j<g.boxes.length;j++){
      g.boxes[j].el.animate(
        [{opacity:0,filter:'blur(8px)',transform:'scale(1.06)'},{opacity:1,filter:'blur(0px)',transform:'scale(1)'}],
        {duration:480,delay:Math.min(j*70,700),easing:'ease-out',fill:'backwards'}
      );
    }
  }catch(e){}
  window.__evT=1;
  return boxes.length;
};
window.__evImgClearOne=function(img){
  var n=0;
  for(var i=G.length-1;i>=0;i--){
    if(G[i].img===img){n+=G[i].boxes.length;try{G[i].el.remove()}catch(e){}G.splice(i,1)}
  }
  try{img.__evHas=0}catch(e){}
  return n;
};
window.__evImgClear=function(){
  var n=0;
  for(var i=0;i<G.length;i++){
    n+=G[i].boxes.length;
    try{G[i].el.remove()}catch(e){}
    try{G[i].img.__evHas=0}catch(e){}
  }
  G=[];
  return n;
};
})();
}
var vh=window.innerHeight||800,list=[],imgs=document.images,i;
window.__evImgs=[];
for(i=0;i<imgs.length;i++){
  var m=imgs[i];
  if(m.__evHas)continue;
  var r=m.getBoundingClientRect();
  if(r.width<80||r.height<40)continue;
  var cs=getComputedStyle(m);
  if(cs.visibility==='hidden'||cs.display==='none'||parseFloat(cs.opacity)===0)continue;
  var u=m.currentSrc||m.src||'';
  var lz=m.getAttribute('data-src')||m.getAttribute('data-original')||m.getAttribute('data-lazy-src')||m.getAttribute('data-url')||'';
  var ph=!u||(u.indexOf('data:')===0&&u.length<2000)||m.naturalWidth===0;
  if(ph&&lz)u=lz;
  if(!u)continue;
  try{u=new URL(u,document.baseURI).href}catch(e){continue}
  if(u.indexOf('http')!==0&&u.indexOf('data:image/')!==0)continue;
  if(u.indexOf('data:')===0&&u.length>400000)continue;
  if(/\.svg([?#]|${'$'})/i.test(u)||u.indexOf('data:image/svg')===0)continue;
  if(m.naturalWidth>0&&(m.naturalWidth<120||m.naturalHeight<60))continue;
  window.__evImgs.push(m);
  list.push({k:window.__evImgs.length-1,u:u,y:r.top});
}
function vis(o){return o.y>-vh*0.5&&o.y<vh*1.5}
list.sort(function(a,b){
  var va=vis(a),vb=vis(b);
  if(va!==vb)return va?-1:1;
  return va?a.y-b.y:Math.abs(a.y)-Math.abs(b.y);
});
list=list.slice(0,40);
return JSON.stringify({lang:(document.documentElement.lang||'').toLowerCase(),items:list.map(function(o){return {k:o.k,u:o.u}})});
}catch(e){return JSON.stringify({lang:'',items:[]})}
})()"""
    }
}
