package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 런처 아이콘(작업 표시줄·앱 목록·엣지 패널 포함)의 진입점. 보이지 않고 바로 닫힌다.
 *
 * 이미 떠 있는 에버그린을 앞으로 가져오기만 하면 삼성 One UI 가 "evergreen은(는) 이미 실행 중입니다."
 * 토스트로 막아 버린다. 그래서 '지금 화면에 보이는 창이 있는데 아이콘을 또 눌렀다'면
 * 창 모드(분할·자유 창)인지 전체 화면인지와 상관없이 새 창을 하나 더 띄운다.
 *
 * - 앱이 화면에 안 보이는 상태(홈 화면에서 눌렀을 때 등)면 예전처럼 떠 있는 앱을 앞으로 가져오거나 새로 시작한다.
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val running = MainActivity.runningWindows().filter { !it.isFinishing && !it.isDestroyed }

        // 새 창을 띄울 기준 창: 지금 보이는 창 > 창 모드로 떠 있는 창 > (이 진입점이 창 모드면) 아무 창
        // 전체 화면으로 떠 있어도 '보이는 중'이면 해당된다 (작업 표시줄에서 누르면 앱이 전체 화면이어도 isInMultiWindowMode 가 false 라서)
        val base = running.firstOrNull { it.visibleNow }
            ?: running.firstOrNull { it.isInMultiWindowMode }
            ?: if (isInMultiWindowMode) running.firstOrNull() else null

        var opened = false
        if (base != null) {
            opened = try {
                base.openNewWindow()
                true
            } catch (e: Throwable) {
                false
            }
        }
        if (!opened) {
            // 떠 있는 창이 있으면(화면에 안 보이는 상태) 그 작업을 앞으로 가져온다.
            // 없으면 '여러 창 가능한' 문서형 작업(BrowserWindowActivity)으로 첫 창을 연다.
            // 첫 창이 MainActivity(singleTop) 작업이면 삼성 앱 선택창·작업 표시줄이
            // "이미 실행 중"이라며 두 번째 창을 막기 때문이다.
            val front = try {
                val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
                am.appTasks.firstOrNull {
                    it.taskInfo.baseIntent?.component?.className != LauncherActivity::class.java.name
                }?.also { it.moveToFront() } != null
            } catch (e: Throwable) {
                false
            }
            if (!front) {
                startActivity(
                    Intent(this, BrowserWindowActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                )
            }
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
