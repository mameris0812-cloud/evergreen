package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.provider.Settings
import android.util.AttributeSet
import android.widget.TextView

/**
 * 한 줄 제목이 너비보다 길면 말줄임(…) 대신 처음부터 끝까지 계속 흘러가며 보여 주는 TextView.
 *
 * - 맨 앞에서 잠깐 멈췄다가 왼쪽으로 한 번 흘러가고, 끝나면 처음 모습으로 돌아와 멈춘다.
 * - 제목이 너비 안에 들어가면 평소 TextView 처럼 가만히 있는다.
 * - 포커스/선택 여부와 상관없이 스스로 그려서(시스템 marquee 미사용) 팝업·다이얼로그 안에서도 항상 동작한다.
 * - 시스템의 "애니메이션 끄기" 설정이면 움직이지 않고 말줄임으로 보여 준다.
 * - 같은 글자가 다시 들어오면(주기적 갱신) 흐름을 처음으로 되돌리지 않는다.
 */
class MarqueeTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle,
) : TextView(context, attrs, defStyleAttr) {

    private var lastText: String? = null
    private var startAt = 0L

    private val density get() = resources.displayMetrics.density
    /** 흐르는 속도 (dp/초) */
    private val speed get() = 38f * density
    /** 한 바퀴 돌고 다시 시작할 때 글자 사이 간격 */
    private val gap get() = 36f * density
    /** 맨 앞에서 멈춰 있는 시간 */
    private val pauseMs = 1600L

    init {
        maxLines = 1
        isSingleLine = true
    }

    private var animOn = true

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animOn = animationsOn() // 화면에 붙을 때마다 한 번만 확인 (프레임마다 읽지 않는다)
        startAt = 0L
    }

    private fun animationsOn(): Boolean = try {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) != 0f
    } catch (_: Throwable) { true }

    override fun onTextChanged(text: CharSequence?, start: Int, lengthBefore: Int, lengthAfter: Int) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter)
        val s = text?.toString()
        if (s != lastText) {
            lastText = s
            startAt = 0L // 새 제목이면 처음부터
        }
    }

    override fun onDraw(canvas: Canvas) {
        val str = lastText
        val availW = width - paddingLeft - paddingRight
        if (str.isNullOrEmpty() || availW <= 0 || !animOn) {
            super.onDraw(canvas); return
        }
        val p = paint
        p.color = currentTextColor
        val textW = p.measureText(str)
        if (textW <= availW) { super.onDraw(canvas); return }

        val now = SystemClock.uptimeMillis()
        if (startAt == 0L) startAt = now
        val period = textW + gap
        val scrollMs = (period / speed * 1000f).toLong().coerceAtLeast(1L)
        val t = now - startAt
        // 한 번만 흐르고 끝: 한 바퀴가 끝나면 처음 모습(말줄임)으로 돌아와 멈춘다
        if (t >= pauseMs + scrollMs) { super.onDraw(canvas); return }
        val offset = if (t < pauseMs) 0f else (t - pauseMs) / scrollMs.toFloat() * period

        val save = canvas.save()
        canvas.clipRect(paddingLeft, 0, width - paddingRight, height)
        val y = baseline.toFloat()
        var x = paddingLeft - offset
        canvas.drawText(str, x, y, p)
        x += period
        canvas.drawText(str, x, y, p) // 끝이 지나가면 앞부분이 이어서 들어온다
        canvas.restoreToCount(save)
        postInvalidateOnAnimation()
    }
}
