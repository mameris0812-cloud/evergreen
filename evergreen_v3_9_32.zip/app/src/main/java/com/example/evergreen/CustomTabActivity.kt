package com.example.evergreen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.lang.ref.WeakReference

/**
 * 다른 앱(카카오톡·유튜브 등)에서 링크를 누르면 뜨는 간이 브라우저(커스텀 탭).
 * 위쪽 막대: 닫기(X) · [자물쇠 + 사이트 주소 + 새로고침] 알약 · 공유 · 더보기(evergreen에서 열기 · 번역 · 링크 복사 · 접기).
 *
 * - 열기: [MainActivity] 가 "android.support.customtabs.extra.SESSION" 이 붙은 VIEW 인텐트를 받으면 여기로 넘긴다.
 * - 닫기: 부른 앱으로 돌아간다. 이미 켜져 있던 evergreen 창 위에 얹혔다면 그 창도 뒤로 보내서 부른 앱이 보이게 한다.
 * - 광고 차단은 앱 설정의 광고 차단 목록을 그대로 쓴다.
 */
class CustomTabActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var hostText: TextView
    private lateinit var lockIcon: android.widget.ImageView
    private lateinit var refreshBtn: ImageButton
    private var spinner: android.animation.ObjectAnimator? = null
    private lateinit var adBlocker: AdBlocker
    private var pageHost: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val startUrl = intent?.data?.toString()
        if (startUrl == null) { finish(); return }
        adBlocker = AdBlocker(this)
        Thread { adBlocker.load() }.apply { isDaemon = true; priority = Thread.MIN_PRIORITY }.start()

        // 앱의 테마 색을 그대로 쓴다 (호출한 앱이 정한 막대 색은 따르지 않는다 — 어느 앱에서 열어도 evergreen 답게)
        val C = com.google.android.material.R.attr.colorSurface
        val surface = ThemeColors.get(this, C, Color.WHITE)
        val textMain = ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurface, Color.BLACK)
        val textSub = ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)
        val accent = ThemeColors.get(this, com.google.android.material.R.attr.colorPrimary, Color.GREEN)
        val pillBg = ThemeColors.get(this, com.google.android.material.R.attr.colorPrimaryContainer, 0x1A000000)

        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
        fun icon(res: Int, desc: String, tint: Int = textMain, size: Int = 40, onClick: (View) -> Unit) = ImageButton(this).apply {
            setImageResource(res)
            contentDescription = desc
            imageTintList = android.content.res.ColorStateList.valueOf(tint)
            setPadding(dp(9), dp(9), dp(9), dp(9))
            background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(textMain, 0x22)), null,
                GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            )
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
            setOnClickListener(onClick)
        }

        // 가운데 알약: 자물쇠(보안) + 사이트 주소. 누르면 링크 복사, 오른쪽 새로고침
        lockIcon = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_lock)
            layoutParams = LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginStart = dp(12) }
        }
        hostText = TextView(this).apply {
            setTextColor(textMain); textSize = 15f; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8); marginEnd = dp(4) }
        }
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(ColorUtils.setAlphaComponent(pillBg, 0xCC)) }
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(6); marginEnd = dp(6) }
            addView(lockIcon); addView(hostText)
            refreshBtn = icon(R.drawable.ic_refresh, "새로고침", textSub, 36) { spinRefresh(); web.reload() }
            addView(refreshBtn)
            setOnClickListener { copyLink() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(surface)
            setPadding(dp(8), 0, dp(8), 0)
            addView(icon(R.drawable.ic_close, "닫기") { closeTab() })
            addView(pill)
            addView(icon(R.drawable.ic_share, "공유") { share() })
            addView(icon(R.drawable.ic_more, "더보기") { showMenu(it) })
        }
        // 막대 바로 아래 얇은 로딩 줄 (앱 강조색)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.TRANSPARENT)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)).apply { gravity = Gravity.TOP }
        }
        web = WebView(this)
        val body = FrameLayout(this).apply {
            addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(progress)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
            addView(View(this@CustomTabActivity).apply { setBackgroundColor(ColorUtils.setAlphaComponent(textMain, 0x1A)) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        // 가장자리까지 그려지는 화면: 상태 표시줄·내비게이션 막대 자리만큼 띄운다 (막대와 같은 색이 상태 표시줄 뒤에 깔린다)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(sb.left, sb.top, sb.right, maxOf(sb.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }
        androidx.core.view.WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars =
            ColorUtils.calculateLuminance(surface) > 0.5

        setupWeb()
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else closeTab() }
        })
        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(startUrl)
        showHost(startUrl)
    }

    private fun setupWeb() {
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true; displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false; allowContentAccess = false
            setSupportMultipleWindows(false)
        }
        web.setDownloadListener { url, _, _, _, _ -> openInEvergreen(url) }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val sc = u.scheme?.lowercase()
                if (sc == "http" || sc == "https") return false
                // tel: · market: · intent: 같은 주소는 그 앱으로 넘긴다
                runCatching {
                    val i = if (sc == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, u)
                    i.addCategory(Intent.CATEGORY_BROWSABLE); i.component = null; i.selector = null
                    startActivity(i)
                }
                return true
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                // 페이지 이동 자체는 막지 않는다: 광고를 눌러 열린 주소까지 막으면 빈 오류 페이지만 뜬다. 광고 등 하위 요청만 막는다
                if (request.isForMainFrame) return null
                val u = request.url
                val host = u.host
                if (host != null && adBlocker.shouldBlock(host, pageHost, u.toString(), NetFilter.inferType(u.toString(), null, request.isForMainFrame))) {
                    return WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) { showHost(url); spinRefresh() }
            override fun onPageFinished(view: WebView, url: String) = stopSpin()
            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) = showHost(url)
        }
    }

    /** 새로고침 아이콘: 불러오는 동안 빙글빙글 돈다 (이미 돌고 있으면 그대로) */
    private fun spinRefresh() {
        if (spinner?.isRunning == true) return
        spinner = android.animation.ObjectAnimator.ofFloat(refreshBtn, View.ROTATION, 0f, 360f).apply {
            duration = 700
            repeatCount = android.animation.ObjectAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            start()
        }
    }

    /** 다 불러왔으면 돌던 아이콘을 부드럽게 원래 각도로 멈춘다 */
    private fun stopSpin() {
        val a = spinner ?: return
        spinner = null
        val rest = 360f - (refreshBtn.rotation % 360f)
        a.cancel()
        refreshBtn.animate().rotationBy(rest).setDuration((rest / 360f * 300).toLong().coerceAtLeast(50)).setInterpolator(android.view.animation.DecelerateInterpolator())
            .withEndAction { refreshBtn.rotation = 0f }.start()
    }

    private fun showHost(url: String?) {
        val h = runCatching { Uri.parse(url).host }.getOrNull()
        pageHost = h
        hostText.text = h ?: url.orEmpty()
        // https 면 자물쇠, 아니면 경고색 지구본
        val secure = url?.startsWith("https://") == true
        lockIcon.setImageResource(if (secure) R.drawable.ic_lock else R.drawable.ic_globe)
        lockIcon.imageTintList = android.content.res.ColorStateList.valueOf(
            if (secure) ThemeColors.get(this, com.google.android.material.R.attr.colorPrimary, Color.GREEN) else 0xFFE5484D.toInt()
        )
    }

    private fun currentUrl(): String = web.url ?: intent?.data?.toString().orEmpty()

    private fun share() {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, currentUrl())
        startActivity(Intent.createChooser(send, null))
    }

    /** 번역: 구글 번역 웹 주소로 이 페이지를 다시 연다 (한국어로) */
    private fun translate() {
        val u = currentUrl()
        if (u.isEmpty()) return
        web.loadUrl("https://translate.google.com/translate?sl=auto&tl=ko&u=" + Uri.encode(u))
    }

    private fun copyLink() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("url", currentUrl()))
        AppToast.show(this, "링크를 복사했어요")
    }

    /** 더보기: evergreen 팝업 메뉴 (앱의 다른 메뉴와 같은 모양) */
    private fun showMenu(anchor: View) {
        val items = listOf(
            Popup.Item(R.drawable.ic_open_tab, "evergreen에서 열기", "일반 탭으로 옮겨요") { openInEvergreen(currentUrl()) },
            Popup.Item(R.drawable.ic_globe, "한국어로 번역", null) { translate() },
            Popup.Item(R.drawable.ic_copy, "링크 복사", null) { copyLink() },
            Popup.Item(R.drawable.ic_expand_more, "접기", "앱으로 돌아가요. 최근 앱에서 다시 열 수 있어요") { moveTaskToBack(true) }
        )
        Popup.menu(this, hostText.text.toString(), null, R.drawable.ic_globe, null, items, origin = anchor, nearOrigin = true)
    }

    /** 이 페이지를 evergreen 의 일반 탭으로 연다 (이 간이 창은 닫는다). 커스텀 탭 표시가 없는 인텐트라 다시 이리로 돌아오지 않는다 */
    private fun openInEvergreen(url: String) {
        startActivity(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(Uri.parse(url)))
        returnTo = null
        finish()
    }

    private fun closeTab() {
        finishAndRemoveTask()
        // evergreen 창 위에 얹혀 열렸다면, 닫은 뒤 그 창이 보이지 않게 뒤로 보내 부른 앱으로 돌아가게 한다
        val host = returnTo?.get()
        returnTo = null
        host?.let { h -> window.decorView.postDelayed({ runCatching { if (!h.isFinishing) h.moveTaskToBack(true) } }, 150) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        spinner?.cancel(); spinner = null
        runCatching { (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_SESSION = "android.support.customtabs.extra.SESSION"

        /** 닫을 때 뒤로 보낼 evergreen 창 (이미 켜져 있던 창에 커스텀 탭이 얹힌 경우) */
        private var returnTo: WeakReference<android.app.Activity>? = null

        /**
         * 설정 > 앱 정보 > 「간이 창 연결 확인」: 다른 앱이 커스텀 탭 브라우저를 고를 때와 같은 방법으로 이 기기에서
         * 누가 뽑히는지 보여 준다 (evergreen 이 안 뽑히는 이유를 찾는 용도).
         */
        fun showDiagnosis(act: android.app.Activity) {
            val pm = act.packageManager
            fun label(pkg: String?): String {
                if (pkg == null) return "없음"
                val name = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrNull()
                return if (name != null) "$name ($pkg)" else pkg
            }
            val defaultPkg = runCatching {
                pm.resolveActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://")), 0)?.activityInfo?.packageName
            }.getOrNull()
            val picked = runCatching { androidx.browser.customtabs.CustomTabsClient.getPackageName(act, null) }.getOrNull()
            val svc = Intent("android.support.customtabs.action.CustomTabsService").setPackage(act.packageName)
            val svcOk = runCatching { pm.resolveService(svc, 0) != null }.getOrDefault(false)
            val msg = buildString {
                append("기본 브라우저: ").append(label(defaultPkg)).append('\n')
                append("앱들이 고르는 커스텀 탭 브라우저: ").append(label(picked)).append('\n')
                append("evergreen 지원 서비스: ").append(if (svcOk) "등록됨" else "등록 안 됨").append("\n\n")
                append(
                    when {
                        picked == act.packageName -> "이 기기에서는 evergreen 이 뽑혀요. 그래도 크롬이 뜨는 앱은 크롬을 직접 지정한 앱이에요."
                        !svcOk -> "evergreen 의 지원 서비스가 인식되지 않아요. 앱을 최신 버전으로 다시 설치해 보세요."
                        defaultPkg != act.packageName -> "evergreen 이 기본 브라우저가 아니라서 다른 브라우저가 뽑혀요. 기본 앱 > 브라우저 앱에서 evergreen 을 골라 주세요."
                        else -> "서비스는 등록됐는데 뽑히지 않았어요. 이 화면을 캡처해서 알려 주세요."
                    }
                )
            }
            ThemedDialogBuilder(act).setTitle("간이 창 연결 확인").setMessage(msg).setPositiveButton("확인", null).show()
        }

        /** 다른 앱이 커스텀 탭으로 연 링크인가 */
        fun isCustomTabIntent(i: Intent?): Boolean {
            i ?: return false
            if (i.action != Intent.ACTION_VIEW) return false
            val sc = i.data?.scheme?.lowercase()
            return (sc == "http" || sc == "https") && i.hasExtra(EXTRA_SESSION)
        }

        /** [from] 위(같은 작업)에 커스텀 탭을 띄운다. [onTopOfHost] 가 true 면 닫을 때 [from] 도 뒤로 보낸다 */
        fun launch(from: android.app.Activity, source: Intent, onTopOfHost: Boolean) {
            val i = Intent(from, CustomTabActivity::class.java).setData(source.data)
            returnTo = if (onTopOfHost) WeakReference(from) else null
            from.startActivity(i)
        }
    }
}
