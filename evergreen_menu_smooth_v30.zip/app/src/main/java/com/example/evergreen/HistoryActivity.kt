package com.example.evergreen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 방문 기록.
 * - 날짜별(오늘 / 어제 / 11월 3일 (화) …)로 묶여 있고, 날짜 줄을 누르면 그 날의 기록이 펼쳐지고 접힌다.
 * - 항목을 누르면 현재 탭, ⋮ 메뉴(또는 길게 누르기)로 새 탭 열기 / 주소 복사 / 삭제
 * - 고른 주소는 북마크 화면과 같은 방식(EXTRA_URL)으로 MainActivity 에 돌려준다.
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private val adapter = RowAdapter()
    private lateinit var select: ListSelect<String>

    /** 목록에 그려지는 줄: 날짜 줄 또는 기록 한 개 */
    private sealed class Row {
        class Header(val day: Long, val label: String, val count: Int, val open: Boolean) : Row()
        class Entry(val item: HistoryItem) : Row()
    }

    private val rows = ArrayList<Row>()
    /** 선택 · 전체 선택의 대상: 접혀 있는 날의 기록까지 모두 */
    private val allItems = ArrayList<HistoryItem>()
    /** 펼쳐 둔 날 (그 날 0시의 시각). 처음엔 모두 접혀 있다 */
    private val openDays = HashSet<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        ListUi.fitSystemBars(this)
        ListUi.applyTabletPopup(this)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "방문 기록"
        findViewById<View>(R.id.btnListBack).setOnClickListener { ListUi.markBackToMenu(this); finish() }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        // 날짜별 목록이라 칩 줄은 쓰지 않는다
        (findViewById<View>(R.id.chipRow).parent as? View)?.visibility = View.GONE
        listView.adapter = adapter
        select = ListSelect(
            this, listView, findViewById(R.id.btnListAction), findViewById(R.id.listTitle),
            visibleKeys = { allItems.map { it.url } },
            onChanged = { adapter.notifyDataSetChanged() },
            onDelete = { urls -> deleteMany(urls) }
        )

        refreshView()
    }

    private fun startOfDay(t: Long): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun startOfToday(): Long = startOfDay(System.currentTimeMillis())

    /** 오늘 / 어제 / 11월 3일 (화) — 올해가 아니면 연도도 붙인다 */
    private fun dayLabel(day: Long): String {
        val today = startOfToday()
        if (day == today) return "오늘"
        if (day == startOfDay(today - 1)) return "어제"
        val sameYear = Calendar.getInstance().apply { timeInMillis = day }.get(Calendar.YEAR) ==
            Calendar.getInstance().apply { timeInMillis = today }.get(Calendar.YEAR)
        val fmt = if (sameYear) "M월 d일 (E)" else "yyyy년 M월 d일 (E)"
        return SimpleDateFormat(fmt, Locale.KOREA).format(Date(day))
    }

    private fun refreshView() {
        val all = prefs.historyItems().sortedByDescending { it.time }
        allItems.clear()
        allItems.addAll(all)

        // 날짜별로 묶는다 (시간이 없는 오래된 기록은 맨 아래 '날짜 없음' 으로)
        val byDay = LinkedHashMap<Long, MutableList<HistoryItem>>()
        all.forEach { byDay.getOrPut(if (it.time > 0L) startOfDay(it.time) else 0L) { ArrayList() }.add(it) }

        rows.clear()
        byDay.forEach { (day, list) ->
            val open = day in openDays
            rows.add(Row.Header(day, if (day == 0L) "날짜 없음" else dayLabel(day), list.size, open))
            if (open) list.forEach { rows.add(Row.Entry(it)) }
        }
        select.retain()
        adapter.notifyDataSetChanged()

        if (rows.isEmpty()) {
            emptyView.text = "방문 기록이 없습니다"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    /** 날짜 줄 안의 기록은 시각만 보여 준다 (날짜는 위 줄에 있다) */
    private fun timeLabel(t: Long): String =
        if (t <= 0L) "" else SimpleDateFormat("a h:mm", Locale.KOREA).format(Date(t))

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getViewTypeCount(): Int = 2
        override fun getItemViewType(position: Int): Int = if (rows[position] is Row.Header) 0 else 1

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
            when (val r = rows[position]) {
                is Row.Header -> headerView(r, convertView, parent)
                is Row.Entry -> entryView(r.item, convertView, parent)
            }

        private fun headerView(r: Row.Header, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_history_date, parent, false)
            v.findViewById<TextView>(R.id.dateLabel).text = r.label
            v.findViewById<ImageView>(R.id.dateChevron).rotation = if (r.open) 180f else 0f
            v.contentDescription = "${r.label}, 기록 ${r.count}개, " + if (r.open) "접기" else "펼치기"
            v.setOnClickListener {
                if (!openDays.remove(r.day)) openDays.add(r.day)
                refreshView()
            }
            return v
        }

        private fun entryView(h: HistoryItem, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)

            select.bindRow(v, h.url, R.drawable.ic_globe)
            if (!select.isSelected(h.url) || !select.active) Favicons.apply(v.findViewById(R.id.rowIcon), h.url)
            v.findViewById<ProgressBar>(R.id.rowProgress).visibility = View.GONE
            v.findViewById<TextView>(R.id.rowTitle).text = ListUi.displayTitle(h.title, h.url)
            val label = timeLabel(h.time)
            v.findViewById<TextView>(R.id.rowSub).text = if (label.isEmpty()) h.url else "$label · ${h.url}"

            v.setOnClickListener { if (select.active) select.toggle(h.url) else openUrl(h.url, newTab = false) }
            v.setOnLongClickListener {
                if (select.active) select.toggle(h.url) else select.enter(h.url)
                true
            }
            v.findViewById<ImageButton>(R.id.rowMore).setOnClickListener { showMenu(h) }
            return v
        }
    }

    private fun openUrl(url: String, newTab: Boolean) {
        setResult(
            RESULT_OK,
            Intent().putExtra(BookmarksActivity.EXTRA_URL, url)
                .putExtra(BookmarksActivity.EXTRA_NEW_TAB, newTab)
        )
        finish()
    }

    private fun showMenu(h: HistoryItem) {
        Popup.menu(
            this,
            title = ListUi.displayTitle(h.title, h.url),
            subtitle = h.url,
            headerIcon = R.drawable.ic_globe,
            items = listOf(
                Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { openUrl(h.url, newTab = true) },
                Popup.Item(R.drawable.ic_copy, "주소 복사") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("url", h.url))
                    ListUi.toast(this, "복사했습니다")
                },
                Popup.Item(R.drawable.ic_delete, "기록에서 삭제", danger = true) {
                    prefs.removeHistory(h.url)
                    refreshView()
                }
            )
        )
    }

    /** 묻지 않고 바로 지우고, 알림의 '실행 취소' 로 되돌릴 수 있게 한다 */
    private fun deleteMany(urls: Set<String>) {
        val n = urls.size
        val before = prefs.historyItems()
        if (n >= before.size) prefs.clearHistory() else prefs.removeHistories(urls)
        select.finishDelete()
        refreshView()
        ListUi.undoToast(this, "방문 기록 ${n}개를 삭제했습니다") {
            prefs.setHistoryItems(before)
            refreshView()
        }
    }

}
