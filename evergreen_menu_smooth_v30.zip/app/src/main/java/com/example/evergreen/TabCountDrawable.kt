package com.example.evergreen

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable

/**
 * 상/하단바 버튼 편집 화면에서 "탭 목록" 버튼을 실제 탭 버튼(ic_tab_stack + 숫자)과 똑같이 그려 주는 아이콘.
 * 24 단위 격자 기준: 둥근 네모(3~21, 모서리 3.5, 선 1.8) 안에 열린 탭 개수를 굵게 적는다.
 * 글자 크기 규칙(12 / 10 / 8)도 MainActivity.updateTabCount 와 같다.
 */
class TabCountDrawable(color: Int, private val count: Int) : Drawable() {

    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        this.color = color
    }
    private val rect = RectF()

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val u = b.width() / 24f
        box.strokeWidth = 1.8f * u
        rect.set(b.left + 3f * u, b.top + 3f * u, b.left + 21f * u, b.top + 21f * u)
        canvas.drawRoundRect(rect, 3.5f * u, 3.5f * u, box)

        val s = if (count > 99) "99+" else count.toString()
        num.textSize = (if (count > 99) 8f else if (count >= 10) 10f else 12f) * u
        // 실제 버튼(TextView, 글꼴 여백 없음, 가운데 정렬)처럼 글줄(ascent~descent)의 가운데를 상자 가운데에 둔다
        val fm = num.fontMetrics
        val cy = b.exactCenterY()
        canvas.drawText(s, b.exactCenterX(), cy - (fm.ascent + fm.descent) / 2f, num)
    }

    override fun setAlpha(alpha: Int) { box.alpha = alpha; num.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { box.colorFilter = cf; num.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
