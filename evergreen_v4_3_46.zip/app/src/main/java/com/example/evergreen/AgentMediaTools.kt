package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject

/**
 * 에이전트: 미디어 플레이어 조작 도구.
 * - 읽기(자동): list_media — 지금 재생 중이거나 방금 멈춘 영상 · 음악(웹 페이지의 것과 내장 플레이어)과 그 상태
 * - 변경(요청당 한 번 확인): control_media — 재생 · 일시정지 · 위치 옮기기 · 초 단위 건너뛰기 · 다음 · 이전 · 배속 · 볼륨
 * 메뉴의 미디어 카드 · 시스템 미디어 플레이어와 같은 길로 조작하며, 모두 [AgentHost] 만 통해 앱을 만진다.
 */
object AgentMediaTools {
    fun build(): List<AgentTool> = listOf(listMedia(), controlMedia())

    private fun fmt(sec: Double): String {
        val x = sec.toInt().coerceAtLeast(0)
        return if (x >= 3600) String.format("%d:%02d:%02d", x / 3600, (x % 3600) / 60, x % 60) else String.format("%d:%02d", x / 60, x % 60)
    }

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    /** [number] 가 0 이하면 재생 중인 것(없으면 첫 번째), 아니면 그 번호의 미디어 */
    private fun target(list: List<AgentMedia>, number: Int): AgentMedia? =
        if (number <= 0) list.firstOrNull { it.playing } ?: list.firstOrNull() else list.firstOrNull { it.number == number }

    private fun toJson(m: AgentMedia): JSONObject {
        val o = JSONObject()
            .put("number", m.number)
            .put("title", m.title.take(120))
            .put("kind", if (m.builtin) "내장 플레이어" else if (m.video) "영상" else "음악")
            .put("playing", m.playing)
            .put("where", m.where)
            .put("position", fmt(m.posSec))
        if (m.artist.isNotBlank()) o.put("artist", m.artist.take(80))
        if (m.site.isNotBlank()) o.put("site", m.site.take(80))
        if (m.buffering) o.put("buffering", true)
        if (m.speed > 0) o.put("speed", m.speed)
        if (m.volume >= 0) o.put("volume_percent", (m.volume * 100).toInt())
        if (m.durSec > 0) o.put("duration", fmt(m.durSec)) else o.put("live_or_unknown_length", true)
        return o
    }

    private fun listMedia() = AgentTool(
        name = "list_media",
        description = "지금 재생 중이거나 방금 멈춘 영상 · 음악 목록(번호 · 제목 · 아티스트 · 사이트 · 재생 중 여부 · 현재 위치 · 전체 길이 · 어느 창 몇 번 탭인지)을 돌려줍니다. " +
            "웹 페이지에서 재생하는 것과 내장 플레이어가 모두 들어 있고, 재생 중인 것이 먼저입니다. 재생·일시정지·건너뛰기 전에 이걸로 대상을 확인하세요.",
        risk = AgentRisk.READ,
        doing = { "재생 중인 미디어 확인하는 중…" },
        run = { _, ctx ->
            val list = ctx.host.media()
            val arr = JSONArray()
            for (m in list) arr.put(toJson(m))
            val playing = list.count { it.playing }
            AgentResult.ok(
                JSONObject().put("count", list.size).put("playing_count", playing).put("media", arr),
                if (list.isEmpty()) "재생 중인 미디어가 없어요" else "미디어 ${list.size}개를 확인했어요" + if (playing > 0) " (재생 중 ${playing}개)" else "",
                untrusted = true
            )
        }
    )

    private fun actionLabel(a: JSONObject): String = when (a.optString("action")) {
        "play" -> "재생"
        "pause" -> "일시정지"
        "toggle" -> "재생/일시정지"
        "seek" -> "${fmt(a.optInt("seconds", 0).toDouble())} 위치로 이동"
        "skip" -> {
            val s = a.optInt("seconds", 0)
            if (s < 0) "${-s}초 되감기" else "${s}초 앞으로"
        }
        "speed" -> "배속 ${a.optString("level")}배로 바꾸기"
        "volume" -> "볼륨 ${a.optString("level")}%로 바꾸기"
        "next" -> "다음으로 넘기기"
        "prev" -> "이전으로 돌아가기"
        else -> "조작"
    }

    private fun controlMedia() = AgentTool(
        name = "control_media",
        description = "재생 중이거나 방금 멈춘 영상 · 음악(웹 페이지의 것과 내장 플레이어)을 조작합니다. " +
            "action: play(재생) · pause(일시정지) · toggle(재생/일시정지 바꾸기) · seek(seconds 위치로 이동, 초 단위) · skip(seconds 만큼 건너뛰기, 음수면 되감기, 예: -10 · 30) · next(다음 곡/영상) · prev(이전 곡/영상). " +
            "number 는 list_media 의 번호이고, 비우면 지금 재생 중인 것(없으면 첫 번째)입니다. 길이를 모르는 라이브는 seek · skip 을 할 수 없습니다. " +
            "speed(level 배속, 0.25~4, 예: 1.5) · volume(level 볼륨 0~100 퍼센트, 그 미디어 자체의 볼륨이라 기기 볼륨과 별개). 새 영상을 트는 도구가 아니니, 재생할 영상을 열려면 go_to · click_element 를 쓰세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "action" to AgentSchema.oneOf("할 동작", "play", "pause", "toggle", "seek", "skip", "next", "prev", "speed", "volume"),
                "number" to AgentSchema.int("조작할 미디어 번호 (list_media 의 number, 비우면 재생 중인 것)"),
                "seconds" to AgentSchema.int("seek 이면 옮겨 갈 위치(초, 1분 30초 = 90), skip 이면 건너뛸 초(음수면 되감기)"),
                "level" to AgentSchema.str("speed 이면 배속 숫자(예: 1.5), volume 이면 볼륨 퍼센트(0~100)")
            ),
            listOf("action")
        ),
        doing = { a ->
            when (a.optString("action")) {
                "play" -> "재생하는 중…"
                "pause" -> "일시정지하는 중…"
                "toggle" -> "재생 상태를 바꾸는 중…"
                "seek" -> "재생 위치를 옮기는 중…"
                "skip" -> "건너뛰는 중…"
                "speed" -> "배속을 바꾸는 중…"
                "volume" -> "볼륨을 바꾸는 중…"
                "next" -> "다음으로 넘기는 중…"
                "prev" -> "이전으로 돌아가는 중…"
                else -> "미디어를 조작하는 중…"
            }
        },
        run = { a, ctx ->
            val action = a.optString("action").trim()
            val needSec = action == "seek" || action == "skip"
            val level = a.optString("level").trim().removeSuffix("%").removeSuffix("배").removeSuffix("x").trim().toDoubleOrNull()
            if (needSec && !a.has("seconds")) {
                AgentResult.fail("seconds(초)를 주세요 (seek 는 옮겨 갈 위치, skip 은 건너뛸 초)")
            } else if ((action == "speed" || action == "volume") && level == null) {
                AgentResult.fail("level 에 숫자를 주세요 (speed 는 배속 예: 1.5, volume 은 0~100 퍼센트)")
            } else {
                // 볼륨은 퍼센트로 받아 0~1 로 바꿔 넘긴다
                val value = when (action) {
                    "speed" -> level ?: 1.0
                    "volume" -> (level ?: 0.0) / 100.0
                    else -> a.optInt("seconds", 0).toDouble()
                }
                val o = ctx.host.controlMedia(a.optInt("number", 0), action, value)
                if (!o.ok) AgentResult.fail(o.message) else {
                    val d = JSONObject().put("message", o.message)
                    // 조작한 직후의 상태 (다음 · 이전은 새 미디어가 뜨는 데 시간이 걸려서 list_media 로 다시 보게 한다)
                    if (action != "next" && action != "prev") {
                        target(ctx.host.media(), a.optInt("number", 0))?.let { d.put("now", toJson(it)) }
                    }
                    AgentResult.ok(d, o.message, untrusted = true)
                }
            }
        },
        undoPlan = { a, ctx ->
            val action = a.optString("action").trim()
            val before = target(ctx.host.media(), a.optInt("number", 0))
            if (before == null || action == "next" || action == "prev") null else {
                { _ ->
                    // 번호는 밀릴 수 있어서 제목과 있는 곳이 같은 미디어를 다시 찾는다
                    fun find(h: AgentHost): AgentMedia? = h.media().firstOrNull { it.title == before.title && it.where == before.where }
                    when (action) {
                        "play", "pause", "toggle" -> AgentUndo(if (before.playing) "다시 재생하기" else "다시 일시정지하기") { h ->
                            val m = find(h)
                            if (m == null) AgentOutcome.fail("그 미디어는 이미 끝났거나 닫혀서 그대로 뒀어요")
                            else h.controlMedia(m.number, if (before.playing) "play" else "pause", 0.0)
                        }
                        "speed" -> if (before.speed <= 0) null else AgentUndo("배속 되돌리기 (${before.speed}배)") { h ->
                            val m = find(h)
                            if (m == null) AgentOutcome.fail("그 미디어는 이미 끝났거나 닫혀서 그대로 뒀어요")
                            else h.controlMedia(m.number, "speed", before.speed)
                        }
                        "volume" -> if (before.volume < 0) null else AgentUndo("볼륨 되돌리기 (${(before.volume * 100).toInt()}%)") { h ->
                            val m = find(h)
                            if (m == null) AgentOutcome.fail("그 미디어는 이미 끝났거나 닫혀서 그대로 뒀어요")
                            else h.controlMedia(m.number, "volume", before.volume)
                        }
                        "seek", "skip" -> if (before.durSec <= 0) null else AgentUndo("재생 위치 되돌리기 (${fmt(before.posSec)})") { h ->
                            val m = find(h)
                            if (m == null) AgentOutcome.fail("그 미디어는 이미 끝났거나 닫혀서 그대로 뒀어요")
                            else h.controlMedia(m.number, "seek", before.posSec)
                        }
                        else -> null
                    }
                }
            }
        },
        ask = { a, ctx ->
            val n = a.optInt("number", 0)
            val m = target(ctx.host.media(), n)
            val who = if (m == null) "미디어" else "「" + short(m.title, 22) + "」"
            "$who ${actionLabel(a)}"
        }
    )
}
