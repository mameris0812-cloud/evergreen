package com.example.evergreen

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.os.Bundle

/**
 * 런처(작업 표시줄) 아이콘 진입점. 화면 없이 바로 끝나는 중계 창이다 (크롬·삼성 인터넷과 같은 방식).
 *
 * 매니페스트에서 documentLaunchMode="always" 라서, 이 창은 열릴 때마다 시스템이 '새 작업'으로 만든다.
 * (이게 없으면 작업 표시줄에서 끌어다 놓을 때 시스템이 이미 떠 있는 에버그린 작업을 찾아 그 창을 옮겨 버리고,
 *  새 창은 안 열렸다.) 새 작업은 사용자가 놓은 자리(분할 화면·떠 있는 창)에 만들어지므로,
 * 새 창이면 실제 화면(MainActivity)을 이 작업 안에서 바로 이어서 열어 그 자리를 그대로 쓴다.
 *
 * - 새 창 요청(옆에 붙이기 / 멀티윈도우로 열림): 이 작업에 MainActivity 를 열어 새 창으로 쓴다
 * - 그 밖의 아이콘 탭: 이미 떠 있는 창이 있으면 그 작업을 앞으로 가져온다 (예전과 같은 동작)
 * - 떠 있는 창이 하나도 없으면: 최근 앱에 남은 작업이 있으면 그걸 앞으로, 없으면 이 작업에 MainActivity 를 연다
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val adjacent = (intent?.flags ?: 0) and Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT != 0
        val newWindow = adjacent || isInMultiWindowMode
        if (!(!newWindow && bringExistingToFront())) hostWindowHere()
        finish()
        overridePendingTransition(0, 0)
    }

    /** 이 작업(중계 창이 만든 새 작업) 안에서 실제 화면을 연다. 작업은 중계 창이 사라져도 MainActivity 와 함께 남는다 */
    private fun hostWindowHere() {
        val go = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        intent?.extras?.let { go.putExtras(it) }
        startActivity(go)
    }

    /** 이미 있는 에버그린 작업(가장 최근 것)을 앞으로 가져온다. 가져왔으면 true */
    private fun bringExistingToFront(): Boolean {
        return runCatching {
            val am = getSystemService(ActivityManager::class.java)
            val task = am.appTasks.firstOrNull { it.taskInfo.taskId != taskId } ?: return false
            task.moveToFront()
            true
        }.getOrDefault(false)
    }
}
