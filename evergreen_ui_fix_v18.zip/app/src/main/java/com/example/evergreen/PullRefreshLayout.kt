package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * 아래로 당겨 새로고침.
 * - 페이지(자식 WebView)가 손가락을 따라 고무줄처럼 내려오고, 그 빈자리에 표시기가 나타난다.
 * - 기준선을 넘으면 햅틱으로 알려 주고, 놓으면 스프링으로 자리를 잡은 채 돌다가 끝나면 부드럽게 올라간다.
 */
class PullRefreshLayout @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    /** 자식(웹페이지)이 위로 더 스크롤될 수 있으면 true → 당기기 비활성 */
    var canChildScrollUp: () -> Boolean = { false }
    var onRefresh: (() -> Unit)? = null

    /** 자식(NestedWebView)의 세로 스크롤을 먼저 받아 쓰는 쪽. dy 를 받아 실제로 쓴 양을 돌려준다. */
    var onNestedStart: (() -> Unit)? = null
    var onNestedPreScrollDy: ((Int) -> Int)? = null
    var onNestedStop: (() -> Unit)? = null

    var isRefreshing = false
        private set

    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val maxPull = 200f * d
    private val trigger = 96f * d
    private val hold = 56f * d
    private val discR = 19f * d
    private val arcR = 8.5f * d

    private var offset = 0f
    private var armed = false
    private var dragging = false
    private var pointerId = -1
    /** 손가락을 대는 순간 페이지가 이미 맨 위였는지. 아니면 이번 터치로는 새로고침하지 않는다 (맨 위로 올라가려고 끌어내린 동작과 구분) */
    private var downAtTop = false
    private var downX = 0f
    private var downY = 0f
    private var startY = 0f
    private var refreshStartedAt = 0L

    private var spinAngle = 90f
    private var spinner: ValueAnimator? = null
    private var spring: SpringAnimation? = null

    private val arc = RectF()
    private val gapPaint = Paint().apply { color = ContextCompat.getColor(ctx, R.color.ev_bg) }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22000000 }
    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ContextCompat.getColor(ctx, R.color.ev_surface) }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.ev_line)
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.ev_accent)
        style = Paint.Style.STROKE
        strokeWidth = 2.6f * d
        strokeCap = Paint.Cap.ROUND
    }

    private val offsetProp = object : FloatPropertyCompat<PullRefreshLayout>("pullOffset") {
        override fun getValue(o: PullRefreshLayout) = o.offset
        override fun setValue(o: PullRefreshLayout, v: Float) = o.applyOffset(v)
    }

    init {
        setWillNotDraw(false)
    }

    // ───────────────────────── 상태 ─────────────────────────

    /** 새로고침이 끝났을 때 부르면 표시기가 너무 빨리 사라지지 않게 잠깐 두었다가 올라간다. */
    fun endRefresh() {
        if (!isRefreshing) return
        val wait = 550L - (System.currentTimeMillis() - refreshStartedAt)
        if (wait > 0) postDelayed({ endRefresh() }, wait) else {
            isRefreshing = false
            animateTo(0f, 260f, 0.92f)
        }
    }

    /** 탭을 바꾸는 등 즉시 원래 상태로 되돌릴 때 */
    fun reset() {
        spring?.cancel()
        stopSpinner()
        isRefreshing = false
        dragging = false
        armed = false
        applyOffset(0f)
    }

    // ───────────────────────── 중첩 스크롤 (메뉴바 숨김용) ─────────────────────────

    override fun onStartNestedScroll(child: View, target: View, nestedScrollAxes: Int): Boolean {
        val accept = onNestedPreScrollDy != null && (nestedScrollAxes and View.SCROLL_AXIS_VERTICAL) != 0
        if (accept) onNestedStart?.invoke()
        return accept
    }

    override fun onNestedPreScroll(target: View, dx: Int, dy: Int, consumed: IntArray) {
        consumed[1] = onNestedPreScrollDy?.invoke(dy) ?: 0
    }

    override fun onStopNestedScroll(child: View) {
        super.onStopNestedScroll(child)
        onNestedStop?.invoke()
    }

    override fun onViewRemoved(child: View) {
        super.onViewRemoved(child)
        child.translationY = 0f
    }

    override fun onViewAdded(child: View) {
        super.onViewAdded(child)
        child.translationY = offset
    }

    override fun onDetachedFromWindow() {
        spring?.cancel()
        stopSpinner()
        super.onDetachedFromWindow()
    }

    // ───────────────────────── 터치 ─────────────────────────

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerId = ev.getPointerId(0)
                downX = ev.x
                downY = ev.y
                dragging = false
                downAtTop = !canChildScrollUp()
            }
            MotionEvent.ACTION_MOVE -> {
                val i = ev.findPointerIndex(pointerId)
                if (i < 0 || !isEnabled || isRefreshing) return false
                // 맨 위가 아닌 상태에서 시작한 끌어내리기는 '위로 스크롤'이다: 도중에 맨 위에 닿아도 새로고침으로 바꾸지 않는다.
                // 새로고침은 맨 위에 멈춘 페이지를 새로 당겨야만 된다.
                if (!downAtTop) return false
                val x = ev.getX(i)
                val y = ev.getY(i)
                if (canChildScrollUp()) {
                    // 아직 맨 위가 아니면 기준점을 계속 갱신 (맨 위에 닿은 순간부터 거리를 잰다)
                    downX = x
                    downY = y
                    return false
                }
                val dy = y - downY
                val dx = abs(x - downX)
                if (!dragging && dy > slop && dy > dx * 1.5f) {
                    dragging = true
                    startY = downY + slop
                    spring?.cancel()
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                pointerId = -1
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!dragging) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val i = ev.findPointerIndex(pointerId)
                if (i < 0) return true
                val raw = max(0f, ev.getY(i) - startY)
                applyOffset(rubber(raw))
                if (!armed && offset >= trigger) {
                    armed = true
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                } else if (armed && offset < trigger - 8f * d) {
                    armed = false
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                pointerId = -1
                val fire = ev.actionMasked == MotionEvent.ACTION_UP && offset >= trigger
                armed = false
                if (fire) {
                    isRefreshing = true
                    refreshStartedAt = System.currentTimeMillis()
                    startSpinner()
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    animateTo(hold, 380f, 0.75f)
                    onRefresh?.invoke()
                } else {
                    animateTo(0f, 300f, 0.9f)
                }
            }
        }
        return true
    }

    // ───────────────────────── 애니메이션 ─────────────────────────

    /** 당긴 거리 → 화면에서 내려오는 거리 (멀어질수록 저항이 커지는 고무줄) */
    private fun rubber(raw: Float): Float = maxPull * (1f - exp(-raw / (maxPull * 1.1f)))

    private fun applyOffset(v: Float) {
        offset = v
        for (i in 0 until childCount) getChildAt(i).translationY = v
        invalidate()
    }

    private fun animateTo(target: Float, stiffness: Float, damping: Float) {
        spring?.cancel()
        if (abs(offset - target) < 0.5f) {
            applyOffset(target)
            if (target == 0f && !isRefreshing) stopSpinner()
            return
        }
        spring = SpringAnimation(this, offsetProp).apply {
            setSpring(
                SpringForce(target)
                    .setStiffness(stiffness)
                    .setDampingRatio(damping)
            )
            setMinimumVisibleChange(0.5f)
            addEndListener { _, canceled, _, _ ->
                if (!canceled && target == 0f) {
                    applyOffset(0f)
                    if (!isRefreshing) stopSpinner()
                }
            }
            start()
        }
    }

    private fun startSpinner() {
        spinner?.cancel()
        spinner = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 900
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                spinAngle = 90f + it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopSpinner() {
        spinner?.cancel()
        spinner = null
        spinAngle = 90f
    }

    // ───────────────────────── 그리기 ─────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (offset <= 0.5f) return

        // 페이지가 내려오면서 생긴 빈자리
        canvas.drawRect(0f, 0f, width.toFloat(), offset, gapPaint)

        // 표시기: 빈자리 한가운데, 내려온 만큼 커지면서 나타난다
        val appear = (offset / hold).coerceIn(0f, 1f)
        val eased = appear * appear * (3f - 2f * appear)
        if (eased <= 0.01f) return
        val cx = width / 2f
        val cy = offset / 2f
        val progress = (offset / trigger).coerceIn(0f, 1f)

        discPaint.alpha = (255 * eased).toInt()
        rimPaint.alpha = (255 * eased).toInt()
        shadowPaint.alpha = (34 * eased).toInt()
        arcPaint.alpha = (255 * eased).toInt()


        val r = discR * (0.6f + 0.4f * eased)
        canvas.drawCircle(cx, cy + 1.2f * d, r, shadowPaint)
        canvas.drawCircle(cx, cy, r, discPaint)
        canvas.drawCircle(cx, cy, r, rimPaint)

        val ar = arcR * (0.6f + 0.4f * eased)
        arc.set(cx - ar, cy - ar, cx + ar, cy + ar)
        if (isRefreshing) {
            canvas.drawArc(arc, spinAngle, 270f, false, arcPaint)
        } else {
            // 당기는 동안: 호가 늘어나며 돌아간다 (놓으면 같은 모양에서 바로 회전으로 이어진다)
            canvas.drawArc(arc, -90f + progress * 180f, 30f + 240f * progress, false, arcPaint)
        }
    }
}
