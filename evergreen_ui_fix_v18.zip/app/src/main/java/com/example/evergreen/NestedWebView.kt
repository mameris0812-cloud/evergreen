package com.example.evergreen

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.webkit.WebView

/**
 * 세로 스크롤을 부모(PullRefreshLayout)에게 먼저 나눠 주는 WebView.
 *
 * 손가락이 움직이면 부모가 그 만큼을 먼저 써서 메뉴바를 밀어내고, 남은 움직임만 웹페이지가 스크롤한다.
 * (크롬처럼 메뉴바가 손가락을 그대로 따라 움직이고, 그동안 페이지는 제자리에 있다.)
 */
class NestedWebView(context: Context) : WebView(context) {
    private var lastY = 0
    private var nestedOffsetY = 0
    private val scrollOffset = IntArray(2)
    private val scrollConsumed = IntArray(2)

    init {
        isNestedScrollingEnabled = true
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val event = MotionEvent.obtain(ev)
        val action = event.actionMasked
        if (action == MotionEvent.ACTION_DOWN) nestedOffsetY = 0
        val eventY = event.y.toInt()
        event.offsetLocation(0f, nestedOffsetY.toFloat())
        val handled: Boolean
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                handled = super.onTouchEvent(event)
                lastY = eventY
                startNestedScroll(View.SCROLL_AXIS_VERTICAL)
            }
            MotionEvent.ACTION_MOVE -> {
                val deltaY = lastY - eventY
                if (dispatchNestedPreScroll(0, deltaY, scrollConsumed, scrollOffset)) {
                    lastY = eventY - scrollOffset[1]
                    event.offsetLocation(0f, (-scrollOffset[1]).toFloat())
                    nestedOffsetY += scrollOffset[1]
                } else {
                    lastY = eventY
                }
                handled = super.onTouchEvent(event)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                stopNestedScroll()
                handled = super.onTouchEvent(event)
            }
            else -> handled = super.onTouchEvent(event)
        }
        event.recycle()
        return handled
    }
}
