package com.example.evergreen

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * 유튜브 영상을 앱 안의 전용 화면에서 보는 플레이어.
 * 유튜브는 영상 주소가 암호화·분할돼 있어 일반 플레이어로는 못 여므로,
 * 유튜브가 공식으로 제공하는 삽입(embed) 플레이어를 전체 화면에 띄운다. (PiP·전체화면 지원)
 */
class YoutubePlayerActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        private const val EXTRA_POS = "pos"

        private val ID_RE = Regex("^[A-Za-z0-9_-]{6,20}$")

        /** 유튜브 영상 페이지 주소에서 영상 id 를 뽑는다. 영상 페이지가 아니면 null. */
        fun videoId(url: String?): String? {
            if (url.isNullOrBlank()) return null
            val u = runCatching { Uri.parse(url) }.getOrNull() ?: return null
            val host = u.host?.lowercase() ?: return null
            val id: String? = when {
                host == "youtu.be" -> u.pathSegments.firstOrNull()
                host == "youtube.com" || host.endsWith(".youtube.com") -> {
                    val seg = u.pathSegments
                    when {
                        seg.firstOrNull() == "watch" -> u.getQueryParameter("v")
                        seg.size >= 2 && seg[0] in setOf("shorts", "live", "embed", "v") -> seg[1]
                        else -> null
                    }
                }
                else -> null
            }
            return id?.takeIf { ID_RE.matches(it) }
        }

        fun start(ctx: Context, id: String, posSec: Int) {
            ctx.startActivity(
                Intent(ctx, YoutubePlayerActivity::class.java)
                    .putExtra(EXTRA_ID, id)
                    .putExtra(EXTRA_POS, posSec)
            )
            (ctx as? android.app.Activity)?.overridePendingTransition(R.anim.player_in, R.anim.player_hold)
        }
    }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra(EXTRA_ID)
        if (id == null) { finish(); return }
        val pos = intent.getIntExtra(EXTRA_POS, 0).coerceAtLeast(0)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    customView?.let { root.removeView(it) }
                    customView = view
                    customCallback = callback
                    root.addView(
                        view,
                        FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    )
                    setSystemBars(false)
                }

                override fun onHideCustomView() {
                    customView?.let { root.removeView(it) }
                    customView = null
                    customCallback?.onCustomViewHidden()
                    customCallback = null
                    setSystemBars(true)
                }
            }
            webViewClient = object : WebViewClient() {
                // 플레이어 안에서만 머문다: 유튜브/구글 주소만 허용하고 나머지는 열지 않는다
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val host = request.url.host?.lowercase().orEmpty()
                    val ok = host == "youtube.com" || host.endsWith(".youtube.com") ||
                        host.endsWith(".google.com") || host.endsWith(".googlevideo.com") ||
                        host.endsWith(".gstatic.com") || host.endsWith(".ytimg.com")
                    return !ok
                }
            }
        }
        root.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)
        setSystemBars(true)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) web.webChromeClient?.onHideCustomView() else finish()
            }
        })

        // 기준 주소를 youtube.com 으로 줘서 삽입 플레이어가 요구하는 Referer 를 보내게 한다
        val src = "https://www.youtube.com/embed/$id?autoplay=1&playsinline=1&rel=0&start=$pos"
        val html = "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>" +
            "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}" +
            "iframe{position:absolute;inset:0;width:100%;height:100%;border:0}</style></head><body>" +
            "<iframe src='$src' allow='autoplay; encrypted-media; picture-in-picture; fullscreen' " +
            "allowfullscreen referrerpolicy='strict-origin-when-cross-origin'></iframe></body></html>"
        web.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
    }

    private fun setSystemBars(visible: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) c.show(WindowInsetsCompat.Type.systemBars())
        else {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !isInPictureInPictureMode) {
            runCatching {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        web.onResume()
    }

    override fun onStop() {
        super.onStop()
        // PiP 로 떠 있는 동안은 계속 재생하고, 그 밖에는 멈춘다
        val pip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode
        if (!pip) web.onPause()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.player_hold, R.anim.player_hold)
    }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
