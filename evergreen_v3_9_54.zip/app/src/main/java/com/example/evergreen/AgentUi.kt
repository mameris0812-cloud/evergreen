package com.example.evergreen

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * AI 창에 뜨는 에이전트 진행 카드. AI 가 앱 기능(도구)을 쓰는 동안 "열린 탭 확인하는 중…" 같은 줄이 하나씩 쌓이고,
 * 줄마다 돌아가는 표시 → ✓(성공) / ✕(실패) 로 바뀐다. 머리글의 「중지」 로 바로 멈출 수 있다.
 */
class AgentProgressCard(
    context: Context,
    private val fg: Int,
    private val fgDim: Int,
    private val accent: Int,
    private val bad: Int,
    fill: Int,
    line: Int,
    private val onStop: () -> Unit
) : LinearLayout(context) {

    private class Row(val spinner: ProgressBar, val mark: TextView, val text: TextView)

    private val rows = LinkedHashMap<Int, Row>()
    private val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val status = TextView(context)
    private val stop = TextView(context)
    private var finished = false

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), line)
        }

        status.apply {
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fgDim)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            text = "작업 준비 중…"
        }
        stop.apply {
            text = "중지"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(bad)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), bad)
            }
            contentDescription = "AI 작업 중지"
            setOnClickListener {
                if (finished) return@setOnClickListener
                // 눌렀다는 걸 바로 보여 주고, 실제 중지는 AI 창이 맡는다
                isEnabled = false
                alpha = 0.5f
                status.text = "중지하는 중…"
                onStop()
            }
            Motion.pressable(this, 0.93f)
        }
        val head = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) })
        }
        addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    /** 머리글 한 줄 ("생각하는 중… (2/10단계)" 등). 끝난 뒤에는 바뀌지 않는다 */
    fun setStatus(text: String) {
        if (finished) return
        // 중지 버튼을 누른 뒤에는 "중지하는 중…" 을 덮어쓰지 않는다
        if (!stop.isEnabled) return
        status.text = text
    }

    /** 새 줄: 도구 하나를 실행하기 시작했다 */
    fun addStep(id: Int, label: String) {
        if (finished || rows.containsKey(id)) return
        val spinner = ProgressBar(context, null, android.R.attr.progressBarStyleSmall).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(accent)
        }
        val mark = TextView(context).apply {
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        val icon = FrameLayout(context).apply {
            addView(spinner, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER))
            addView(mark, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }
        val tv = TextView(context).apply {
            textSize = 13f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
            text = label
        }
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        }
        body.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        rows[id] = Row(spinner, mark, tv)
    }

    /** 줄 하나가 끝났다: 성공이면 ✓, 실패면 ✕ 와 이유 */
    fun finishStep(id: Int, ok: Boolean, summary: String) {
        val r = rows[id] ?: return
        r.spinner.visibility = View.GONE
        r.mark.visibility = View.VISIBLE
        r.mark.text = if (ok) "✓" else "✕"
        r.mark.setTextColor(if (ok) accent else bad)
        if (summary.isNotBlank()) {
            r.text.text = summary
            r.text.setTextColor(if (ok) fg else bad)
        }
    }

    /** 실행이 끝났다: 중지 버튼을 치우고 머리글에 결과를 적는다. 아직 돌던 줄은 멈춘 걸로 바꾼다 */
    fun finish(end: AgentEnd) {
        if (finished) return
        finished = true
        stop.visibility = View.GONE
        for ((_, r) in rows) {
            if (r.spinner.visibility == View.VISIBLE) {
                r.spinner.visibility = View.GONE
                r.mark.visibility = View.VISIBLE
                r.mark.text = "–"
                r.mark.setTextColor(fgDim)
            }
        }
        val (label, color) = when (end) {
            AgentEnd.DONE -> "작업을 마쳤어요" to accent
            AgentEnd.STOPPED -> "중지했어요" to fgDim
            AgentEnd.LIMIT -> "단계 한도에 도달해서 멈췄어요" to bad
            AgentEnd.ERROR -> "오류로 멈췄어요" to bad
        }
        status.text = label
        status.setTextColor(color)
    }
}

/**
 * 에이전트가 읽기가 아닌 일(탭 열기 · 설정 바꾸기 · 다운로드 등)을 하기 전에 AI 창에 뜨는 확인 카드.
 * 「허락」 / 「거절」 중 하나를 누르면 [onAnswer] 로 알리고, 이후 카드를 치우는 일은 부른 쪽이 맡는다.
 * [danger] 면 위험한 작업이라는 표시로 강조색을 쓴다.
 */
class AgentConfirmCard(
    context: Context,
    what: String,
    detail: String,
    danger: Boolean,
    fg: Int,
    private val fgDim: Int,
    accent: Int,
    bad: Int,
    private val fill: Int,
    line: Int,
    private val onAnswer: (Boolean) -> Unit
) : LinearLayout(context) {

    private var answered = false

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun button(label: String, color: Int, filled: Boolean, answer: Boolean) = TextView(context).apply {
        text = label
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setTextColor(if (filled) fill else color)
        setPadding(dp(18), dp(8), dp(18), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            if (filled) setColor(color) else setStroke(dp(1), color)
        }
        isClickable = true
        contentDescription = label
        setOnClickListener {
            if (answered) return@setOnClickListener
            answered = true
            // 두 번 눌러도 한 번만 전달되고, 눌렀다는 걸 바로 보여 준다
            this@AgentConfirmCard.alpha = 0.6f
            onAnswer(answer)
        }
        Motion.pressable(this, 0.94f)
    }

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        val tone = if (danger) bad else accent
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), tone)
        }
        addView(TextView(context).apply {
            text = if (danger) "⚠ 이 작업을 해도 될까요?" else "AI가 앱을 조작하려고 해요"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(tone)
        })
        addView(TextView(context).apply {
            text = what
            textSize = 14f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        if (detail.isNotBlank()) {
            addView(TextView(context).apply {
                text = detail
                textSize = 12f
                setTextColor(fgDim)
                setLineSpacing(0f, 1.1f)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            addView(button("거절", fgDim, filled = false, answer = false))
            addView(button("허락", tone, filled = true, answer = true), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
    }
}
