package com.example.evergreen

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * [AgentHost] 의 구현: AI 도구와 2만 줄짜리 MainActivity 사이의 얇은 연결 층.
 * MainActivity 안쪽을 직접 만지지 않고, MainActivity 가 열어 둔 `agentXxx()` 함수만 부른다.
 * 도구는 백그라운드 스레드에서 도니, 화면·탭을 만지는 일은 여기서 메인 스레드로 넘기고 결과를 기다린다.
 */
class MainAgentHost(private val activity: MainActivity) : AgentHost {
    private val handler = Handler(Looper.getMainLooper())

    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val task = FutureTask<T>(Callable<T> { block() })
        handler.post(task)
        try {
            return task.get(8, TimeUnit.SECONDS)
        } catch (e: TimeoutException) {
            task.cancel(false)
            throw IllegalStateException("앱이 응답하지 않아요")
        } catch (e: ExecutionException) {
            throw (e.cause ?: e)
        }
    }

    private fun alive(): Boolean = !activity.isFinishing && !activity.isDestroyed

    private fun gone() = AgentOutcome.fail("앱 화면이 닫혀서 실행할 수 없어요")

    override fun tabs(): List<AgentTab> = onMain { if (alive()) activity.agentTabs() else emptyList() }

    override fun history(query: String, limit: Int): List<AgentPage> =
        onMain { if (alive()) activity.agentHistory(query, limit) else emptyList() }

    override fun bookmarks(query: String, limit: Int): List<AgentBookmark> =
        onMain { if (alive()) activity.agentBookmarks(query, limit) else emptyList() }

    override fun settings(): JSONObject = onMain { if (alive()) activity.agentSettings() else JSONObject() }

    override fun extensions(): List<AgentExt> = onMain { if (alive()) activity.agentExtensions() else emptyList() }

    override fun openTab(target: String, incognito: Boolean, background: Boolean): AgentOutcome =
        onMain { if (alive()) activity.agentOpenTab(target, incognito, background) else gone() }

    override fun closeTab(number: Int): AgentOutcome = onMain { if (alive()) activity.agentCloseTab(number) else gone() }

    override fun switchTab(number: Int): AgentOutcome = onMain { if (alive()) activity.agentSwitchTab(number) else gone() }

    override fun navigate(target: String, number: Int): AgentOutcome =
        onMain { if (alive()) activity.agentNavigate(target, number) else gone() }

    override fun pageNav(action: String): AgentOutcome = onMain { if (alive()) activity.agentPageNav(action) else gone() }

    override fun addBookmark(number: Int): AgentOutcome = onMain { if (alive()) activity.agentAddBookmark(number) else gone() }

    override fun setSetting(name: String, value: String): AgentOutcome =
        onMain { if (alive()) activity.agentSetSetting(name, value) else gone() }

    override fun setExtension(id: String, on: Boolean): AgentOutcome =
        onMain { if (alive()) activity.agentSetExtension(id, on) else gone() }

    override fun download(url: String): AgentOutcome = onMain { if (alive()) activity.agentDownload(url) else gone() }
}
