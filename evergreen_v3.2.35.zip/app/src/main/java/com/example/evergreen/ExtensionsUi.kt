package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch

/** 설정 > 확장 프로그램 (상/하단바의 확장 프로그램 버튼도 같은 화면): 설치된 확장 프로그램을 켜고 끄고, 팝업·옵션을 열고, 지운다. */
object ExtensionsUi {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Float, ctx: Context) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp * ctx.resources.displayMetrics.density
    }

    /**
     * 테마 카드 위쪽의 단순한 미리보기: 탭바(선택된 탭 · 선택 안 된 탭) · 툴바(주소창) · 새 탭 바탕 — 모양과 색만 보여 준다.
     * 실제 앱과 같은 규칙으로 그린다. spec 이 null 이면 앱 기본 모양
     */
    private class ThemePreviewDrawable(
        private val spec: ExtensionManager.ThemeSpec?,
        private val defFrame: Int, private val defBar: Int, private val defBody: Int, private val defText: Int
    ) : android.graphics.drawable.Drawable() {
        private class Img(val bm: android.graphics.Bitmap, val sample: Int)

        private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val clipPath = android.graphics.Path()
        private val tmpPath = android.graphics.Path()
        private val m = android.graphics.Matrix()
        var radius = 0f

        private fun load(f: java.io.File?): Img? = try {
            if (f != null && f.exists()) {
                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeFile(f.path, o)
                var sample = 1
                // 미리보기는 작으므로 가로 1200px 안쪽으로 줄여 읽는다
                while (o.outWidth / (sample * 2) >= 1200) sample *= 2
                android.graphics.BitmapFactory.decodeFile(f.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
                    ?.let { Img(it, sample) }
            } else null
        } catch (e: Throwable) { null }

        private val frameImg = load(spec?.frameImage)
        private val toolbarImg = load(spec?.toolbarImage)
        private val tabBgImg = load(spec?.tabBgImage)
        private val ntpImg = load(spec?.ntpImage)

        private fun readableOn(bg: Int, want: Int?): Int {
            if (want != null) {
                val w = ColorUtils.setAlphaComponent(want, 255)
                if (ColorUtils.calculateContrast(w, bg) >= 3.0) return w
            }
            return if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF1F1F1F.toInt() else 0xFFF1F3F4.toInt()
        }

        /** 가로로 반복하는 테마 그림(크롬 1x 기준)을 (0,0) 에서 시작해 [r] 칸에 채운다. extendDown 이면 그림 아래쪽도 마지막 줄로 이어 칠한다 */
        private fun tile(c: Canvas, img: Img, r: RectF, unit: Float, oy: Float, extendDown: Boolean) {
            val s = unit * img.sample
            m.reset(); m.postScale(s, s); m.postTranslate(0f, oy)
            val sh = android.graphics.BitmapShader(img.bm, android.graphics.Shader.TileMode.REPEAT, android.graphics.Shader.TileMode.CLAMP)
            sh.setLocalMatrix(m)
            p.shader = sh
            val imgBottom = oy + img.bm.height * s
            val rr = RectF(r)
            if (!extendDown) rr.bottom = minOf(rr.bottom, imgBottom)
            rr.top = maxOf(rr.top, oy)
            if (rr.bottom > rr.top) c.drawRect(rr, p)
            p.shader = null
        }

        private fun slantPath(l: Float, t: Float, r: Float, b: Float, sl: Float, rad: Float): android.graphics.Path {
            tmpPath.reset()
            if (sl > 0f) {
                tmpPath.moveTo(l, b); tmpPath.lineTo(l + sl, t + rad); tmpPath.quadTo(l + sl, t, l + sl + rad, t)
                tmpPath.lineTo(r - sl - rad, t); tmpPath.quadTo(r - sl, t, r - sl, t + rad); tmpPath.lineTo(r, b); tmpPath.close()
            } else {
                tmpPath.addRoundRect(RectF(l, t, r, b), floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f), android.graphics.Path.Direction.CW)
            }
            return tmpPath
        }

        override fun draw(c: Canvas) {
            val b = bounds
            val w = b.width().toFloat(); val h = b.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val th = spec
            val unit = w / 360f   // 화면 폭 360dp 를 미리보기 폭에 맞춘 비율. 테마 그림(1x)이 실제 앱과 같은 비율로 보인다
            val frame = ColorUtils.setAlphaComponent(th?.frame ?: defFrame, 255)
            val bar = ColorUtils.setAlphaComponent(th?.toolbar ?: defBar, 255)
            val barFg = if (th != null) readableOn(bar, th.icon ?: th.tabText) else defText
            val selFg = if (th != null) readableOn(bar, th.tabText) else defText
            val frameFg = if (th != null) readableOn(frame, th.tabBgText ?: th.tabText) else defText
            val ntpBase = if (th != null && th.hasNtp) ColorUtils.setAlphaComponent(th.ntpBg ?: th.toolbar, 255) else defBody
            val bodyFg = if (th != null && th.hasNtp) readableOn(ntpBase, th.ntpText) else defText
            c.save()
            clipPath.reset()
            clipPath.addRoundRect(RectF(b), radius, radius, android.graphics.Path.Direction.CW)
            c.clipPath(clipPath)
            c.translate(b.left.toFloat(), b.top.toFloat())

            val tabH = h * 0.30f; val barH = h * 0.30f; val bmH = 0f
            val topEnd = tabH + barH + bmH
            p.style = Paint.Style.FILL

            // 몸통(새 탭): 테마에 새 탭 설정이 없으면 앱 기본 바탕
            p.color = ntpBase
            c.drawRect(0f, topEnd, w, h, p)
            val body = RectF(0f, topEnd, w, h)
            val ni = ntpImg
            if (th != null && ni != null) {
                val bw = ni.bm.width.toFloat() * ni.sample; val bh = ni.bm.height.toFloat() * ni.sample
                val a = th.ntpAlign
                val fx = when { a.contains("left") -> 0f; a.contains("right") -> 1f; else -> 0.5f }
                val fy = when { a.contains("top") -> 0f; a.contains("bottom") -> 1f; else -> 0.5f }
                c.save(); c.clipRect(body)
                if (th.ntpRepeat == "no-repeat") {
                    val sc = maxOf(w / bw, body.height() / bh)
                    val ox = (w - bw * sc) * fx; val oy = topEnd + (body.height() - bh * sc) * fy
                    m.reset(); m.postScale(sc * ni.sample, sc * ni.sample); m.postTranslate(ox, oy)
                    val sh = android.graphics.BitmapShader(ni.bm, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP)
                    sh.setLocalMatrix(m); p.shader = sh
                    c.drawRect(body, p)
                } else {
                    val sc = unit; val iw = bw * sc; val ih = bh * sc
                    val ox = (w - iw) * fx; val oy = topEnd + (body.height() - ih) * fy
                    val rx = th.ntpRepeat == "repeat" || th.ntpRepeat == "repeat-x"
                    val ry = th.ntpRepeat == "repeat" || th.ntpRepeat == "repeat-y"
                    m.reset(); m.postScale(sc * ni.sample, sc * ni.sample); m.postTranslate(ox, oy)
                    val sh = android.graphics.BitmapShader(ni.bm,
                        if (rx) android.graphics.Shader.TileMode.REPEAT else android.graphics.Shader.TileMode.CLAMP,
                        if (ry) android.graphics.Shader.TileMode.REPEAT else android.graphics.Shader.TileMode.CLAMP)
                    sh.setLocalMatrix(m); p.shader = sh
                    val r = RectF(if (rx) 0f else ox, if (ry) topEnd else oy, if (rx) w else ox + iw, if (ry) h else oy + ih)
                    r.intersect(body)
                    c.drawRect(r, p)
                }
                p.shader = null
                c.restore()
            }
            // 탭바: frame 색 + frame 그림
            p.color = frame
            val tabRect = RectF(0f, 0f, w, tabH)
            c.drawRect(tabRect, p)
            frameImg?.let { tile(c, it, tabRect, unit, 0f, false) }

            // 툴바(+북마크바 자리): 색 + theme_toolbar 그림(탭 줄 맨 위에서 시작, 북마크바 쪽까지 이어 칠함)
            val barRect = RectF(0f, tabH, w, topEnd)
            p.color = bar
            c.drawRect(barRect, p)
            toolbarImg?.let { tile(c, it, barRect, unit, 0f, true) }
            // 툴바 아래 구분선
            val line = ColorUtils.blendARGB(bar, barFg, 0.16f)
            p.color = line
            c.drawRect(0f, topEnd - 1f, w, topEnd, p)

            // 탭바와 툴바 색이 비슷하고 그림도 없으면 선택된 탭에 윤곽선 (앱의 tabOutlineColor 와 같은 규칙)
            val outline: Int? = if (th == null || th.toolbarImage != null || th.frameImage != null || th.tabBgImage != null || th.flareTabs || th.samsungTabs) null
                else if (ColorUtils.calculateContrast(bar, frame) >= 1.6) null
                else ColorUtils.blendARGB(bar, readableOn(bar, th.tabText), 0.35f)
            if (outline != null) { p.color = outline; c.drawRect(0f, tabH - 1f, w, tabH, p) }

            // 탭 두 개: 선택된 탭(툴바와 이어짐) · 선택 안 된 탭(background_tab 색 / theme_tab_background 그림)
            val shaped = tabBgImg != null && tabImageHasShape(tabBgImg.bm)   // 그림이 탭 모양을 직접 담고 있나
            val slant = if (th?.tabBgImage != null && !shaped) tabH * 0.22f else 0f
            val tr = tabH * 0.28f
            val tt = tabH * 0.16f
            val sl = w * 0.04f; val sr = w * 0.38f
            val selPath = if (th?.chromeTabs == true) {
                // 크롬 요즘 탭: 아래 양끝이 오목하게 퍼져 툴바와 이어진다
                val fl = tabH * 0.22f; val bb = tabH + 1f
                android.graphics.Path().apply {
                    moveTo(sl, bb); quadTo(sl + fl, bb, sl + fl, bb - fl); lineTo(sl + fl, tt + tr)
                    quadTo(sl + fl, tt, sl + fl + tr, tt); lineTo(sr - fl - tr, tt)
                    quadTo(sr - fl, tt, sr - fl, tt + tr); lineTo(sr - fl, bb - fl); quadTo(sr - fl, bb, sr, bb); close()
                }
            } else if (th?.samsungTabs == true) {
                // 삼성 테마: 모든 모서리가 둥근 흰색 알약 탭
                android.graphics.Path().apply { addRoundRect(RectF(sl, tt, sr, tabH - tt * 0.5f), tr, tr, android.graphics.Path.Direction.CW) }
            } else slantPath(sl, tt, sr, tabH + 1f, slant, tr)
            c.save(); c.clipPath(selPath)
            p.color = if (th?.samsungTabs == true) 0xFFFFFFFF.toInt() else bar
            c.drawRect(sl, tt, sr, tabH + 1f, p)
            toolbarImg?.let { tile(c, it, RectF(sl, tt, sr, tabH + 1f), unit, 0f, true) }
            c.restore()
            if (outline != null) {
                // 선택된 탭 둘레(위·양옆)만 긋고, 탭 바로 아래(툴바와 이어지는 자리)에는 선이 생기지 않게 탭바 높이에서 자른다
                c.save(); c.clipRect(0f, 0f, w, tabH)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = outline
                c.drawPath(selPath, p); p.style = Paint.Style.FILL
                c.restore()
                p.color = bar; c.drawRect(sl + 1f, tabH - 1f, sr - 1f, tabH + 1f, p)
            }
            val ul = w * 0.40f; val ur = w * 0.72f
            if (th?.bgTab != null || tabBgImg != null) {
                if (shaped) {
                    tile(c, tabBgImg!!, RectF(ul, tt, ur, tabH), unit, 0f, false)   // 그림이 정한 모양 그대로
                } else {
                    val up = slantPath(ul, tt, ur, tabH, slant, tr)
                    c.save(); c.clipPath(up)
                    th?.bgTab?.let { p.color = it; c.drawRect(ul, tt, ur, tabH, p) }
                    tabBgImg?.let { tile(c, it, RectF(ul, tt, ur, tabH), unit, 0f, false) }
                    c.restore()
                }
            }
            // 주소창: 테마 주소창 색, 없으면 옛 크롬 테마(탭 배경 그림)는 흰색, 그 밖에는 툴바 색에 글자색을 살짝 섞은 색
            val pill = if (th != null) (th.omnibox ?: if (th.tabBgImage != null) 0xFFFFFFFF.toInt() else ColorUtils.blendARGB(bar, barFg, 0.10f))
                else ColorUtils.blendARGB(bar, defText, 0.08f)
            val pillOpaque = ColorUtils.setAlphaComponent(pill, 255)
            val pf = if (th != null) readableOn(pillOpaque, th.omniboxText) else defText
            val ph = barH * 0.58f
            val pt = tabH + (barH - ph) / 2f
            p.color = pill
            c.drawRoundRect(RectF(w * 0.06f, pt, w * 0.94f, pt + ph), ph / 2f, ph / 2f, p)
            c.restore()
        }
        override fun setAlpha(alpha: Int) { p.alpha = alpha }
        override fun setColorFilter(cf: android.graphics.ColorFilter?) { p.colorFilter = cf }
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    /** 이 확장 프로그램이 페이지에 적용됐는지, 막혔는지, 오류가 났는지 보여 주는 기록 */
    private fun showDiag(ctx: Context, mgr: ExtensionManager, e: ExtensionManager.Ext) {
        val sb = StringBuilder()
        sb.append("${e.name} v${e.version}\n")
        sb.append(if (e.enabled) "켜짐" else "꺼짐").append(" · 스크립트 삽입 ")
            .append(if (mgr.supported) "지원" else "미지원(웹뷰 업데이트 필요)").append("\n")
        sb.append("웹페이지 스크립트 ${e.entries.size}개")
        e.entries.forEach { en -> sb.append("\n  · ").append(en.matches.joinToString(", ")).append("  [").append(en.runAt).append("]") }
        sb.append(if (e.hasBackground) "\n백그라운드 있음" else "")
        mgr.optSummary(e)?.let { sb.append("\n\n설치할 때 최적화\n").append(it) }
        val pop = mgr.popupOf(e)
        sb.append(
            if (pop != null) "\n팝업: $pop"
            else if (mgr.sidePanelOf(e) != null) "\n사이드 패널: ${mgr.sidePanelOf(e)} · 툴바 버튼을 누르면 하단 시트(태블릿은 옆 패널)로 열려요"
            else if (mgr.hasActionClick(e.id)) "\n팝업 없음 · 툴바 버튼을 누르면 백그라운드가 실행돼요 (action.onClicked)"
            else "\n팝업 없음 · 툴바 버튼 동작 없음"
        )
        val dnr = mgr.dnrRuleCount(e.id)
        if (dnr > 0) sb.append("\n요청 차단 규칙 ${dnr}개 적용 중")
        sb.append("\n\n기록 (이 확장이 적용된 페이지를 연 뒤에 보세요)\n")
        val lines = mgr.diagLines(e.id)
        if (lines.isEmpty()) sb.append("아직 없음 — 주소 조건에 맞는 페이지에서 한 번도 실행되지 않았어요")
        else lines.forEach { sb.append(it).append("\n") }
        val tv = TextView(ctx).apply {
            text = sb.toString()
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(ctx, 20), dp(ctx, 8), dp(ctx, 20), dp(ctx, 8))
        }
        val scroll = android.widget.ScrollView(ctx).apply { addView(tv) }
        ThemedDialogBuilder(ctx)
            .setTitle("확장 프로그램 진단")
            .setView(scroll)
            .setPositiveButton("닫기", null)
            .setNeutralButton("복사") { _, _ ->
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("진단", sb.toString()))
                AppToast.show(ctx, "복사했어요")
            }
            .setNegativeButton("기록 지우기") { _, _ -> mgr.diagClear(e.id) }
            .show()
    }

    /**
     * @param onAdd 웹스토어 / 파일(zip·crx) 중에 골라 추가하러 간다 (이 화면은 닫힌다)
     * @param onOpenPage 확장 프로그램 안의 페이지(옵션)를 새 탭으로 연다
     * @param onOpenPopup 확장 프로그램의 툴바 팝업을 앱 안 팝업으로 띄운다 (이 화면은 닫힌다)
     * @param onChanged 켜기/끄기/삭제로 바뀔 때마다 바로 부른다 (화면을 닫기를 기다리지 않는다)
     */
    fun show(
        ctx: Context,
        mgr: ExtensionManager,
        onAdd: () -> Unit,
        onOpenPage: (String) -> Unit,
        onOpenPopup: (ExtensionManager.Ext) -> Unit,
        onChanged: () -> Unit,
        /** 상/하단바에서 누른 버튼. 태블릿이면 이 버튼 바로 아래에 붙어 뜬다 (없으면 가운데 팝업) */
        anchor: View? = null,
        /** true 면 테마만 모아 보여 주는 '테마 목록' 창 (확장 프로그램 창의 '테마' 버튼으로 연다) */
        themes: Boolean = false
    ) {
        val allThemes = mgr.list().filter { mgr.isTheme(it) }
        fun loadItems() = mgr.list().filter { mgr.isTheme(it) == themes }.let { l ->
            // 테마 목록은 쓰는 테마를 골라도 순서가 바뀌지 않게 이름순으로만 둔다 (확장 프로그램은 켜진 것이 위)
            if (themes) l.sortedBy { it.name.lowercase() }
            else l.sortedWith(compareByDescending<ExtensionManager.Ext> { it.enabled }.thenBy { it.name.lowercase() })
        }
        val items = loadItems()
        val onSurface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = ThemeColors.get(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val surface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        // 메뉴창과 같은 색 조합: 회색 바탕 카드 · 연초록 아이콘 받침 · 짙은 초록 글자 · 연한 빨강 삭제 버튼
        val container = ThemeColors.get(ctx, com.google.android.material.R.attr.colorSurfaceContainer, 0xFFF7F8FA.toInt())
        val primaryContainer = ThemeColors.get(ctx, com.google.android.material.R.attr.colorPrimaryContainer, 0xFFE8F5EC.toInt())
        val onPrimaryContainer = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnPrimaryContainer, 0xFF14532D.toInt())
        val cardBg = surface
        val cardBgOff = ColorUtils.blendARGB(surface, container, 0.55f)
        val iconBg = primaryContainer
        val chipBg = primaryContainer
        val dangerFg = androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_danger)
        val dangerBg = androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_danger_soft)
        val enabledCount = items.count { it.enabled }

        val title = if (themes) "테마" else "확장 프로그램"
        val noun = if (themes) "테마" else "확장 프로그램"
        val subtitle = if (themes && items.isEmpty()) "내장 테마 ${mgr.builtinThemes.size}개" + (mgr.builtinThemes.firstOrNull { it.id == mgr.activeBuiltinId }?.let { " · 사용 중: ${it.name}" } ?: "")
            else if (themes && items.none { it.enabled } && mgr.activeBuiltinId != null) "${items.size}개 설치됨 · 사용 중: " + (mgr.builtinThemes.firstOrNull { it.id == mgr.activeBuiltinId }?.name ?: "")
            else if (items.isEmpty()) "설치된 ${noun}가 없어요"
            else if (themes) "${items.size}개 설치됨 · " + (items.firstOrNull { it.enabled }?.let { "사용 중: ${it.name}" } ?: "사용 중인 테마 없음")
            else "${items.size}개 설치됨 · ${enabledCount}개 켜짐"
        // 팝업이 있으면 팝업을 열고, 없으면 툴바 버튼을 누른 것처럼 확장 프로그램의 onClicked 를 부른다
        fun launch(e: ExtensionManager.Ext) {
            if (mgr.popupOf(e) != null || mgr.opensSidePanel(e)) onOpenPopup(e) else mgr.actionClick(e.id)
        }
        var fillRef: ((LinearLayout, () -> Unit, (() -> Unit) -> Unit) -> Unit)? = null
        val fill: (LinearLayout, () -> Unit, (() -> Unit) -> Unit) -> Unit = fill@{ list, close, onDismiss ->
            if (themes) {
                fillThemes(ctx, mgr, list, close, allThemes, items, onAdd, onOpenPage, onOpenPopup, onChanged, anchor)
                return@fill
            }
            // 켜기/끄기로 바뀐 뒤 같은 창 안에서 다시 그릴 때도 최신 상태로 (켜짐·꺼짐 묶음과 개수가 바로 맞게)
            val items = loadItems()
            val enabledCount = items.count { it.enabled }
            // 확장 프로그램 창 맨 위의 '테마' 버튼 / 테마 목록 창 맨 위의 '← 확장 프로그램' 버튼
            run {
                val label = if (themes) "←  확장 프로그램" else "테마"
                val sub = if (themes) null
                    else if (allThemes.isEmpty()) "설치된 테마가 없어요"
                    else "${allThemes.size}개 설치됨 · " + (allThemes.firstOrNull { it.enabled }?.let { "사용 중: ${it.name}" } ?: "사용 중인 테마 없음")
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    isClickable = true
                    background = RippleDrawable(
                        android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(onPrimaryContainer, 0x22)),
                        round(chipBg, 16f, ctx), null
                    )
                    setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(ctx, 4); bottomMargin = dp(ctx, 6)
                    }
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        addView(TextView(ctx).apply {
                            text = label
                            textSize = 14.5f
                            setTypeface(typeface, Typeface.BOLD)
                            setTextColor(onPrimaryContainer)
                        })
                        if (sub != null) addView(TextView(ctx).apply {
                            text = sub
                            textSize = 11.5f
                            maxLines = 1
                            ellipsize = android.text.TextUtils.TruncateAt.END
                            setTextColor(ColorUtils.setAlphaComponent(onPrimaryContainer, 0xBB))
                        })
                    })
                    if (!themes) addView(TextView(ctx).apply {
                        text = "›"
                        textSize = 20f
                        setTextColor(onPrimaryContainer)
                    })
                    setOnClickListener {
                        close()
                        show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged, anchor, !themes)
                    }
                })
            }
            if (!mgr.supported) {
                list.addView(TextView(ctx).apply {
                    text = "이 기기의 웹뷰(WebView)가 페이지 시작 시 스크립트 삽입을 지원하지 않아 확장 프로그램이 동작하지 않아요. 'Android System WebView'를 업데이트해 보세요."
                    textSize = 12f
                    setTextColor(dangerFg)
                    setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 4))
                })
            }
            // 테마 목록: 카드를 눌러 고른다 (하나만 선택됨). '기본' 을 고르면 테마 없이 앱 기본 모양
            fun selectTheme(id: String?) {
                if (id != null) mgr.setEnabled(id, true)
                else { mgr.list().filter { mgr.isTheme(it) && it.enabled }.forEach { mgr.setEnabled(it.id, false) }; mgr.setBuiltinTheme(null) }
                onChanged()
                close()
                show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged, anchor, true)
            }
            fun radio(selected: Boolean): View =
                if (selected) TextView(ctx).apply {
                    text = "사용 중"
                    textSize = 11.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFFFFFFFF.toInt())
                    background = round(primary, 100f, ctx)
                    setPadding(dp(ctx, 10), dp(ctx, 4), dp(ctx, 10), dp(ctx, 4))
                } else View(ctx).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setStroke(dp(ctx, 2), ColorUtils.setAlphaComponent(onVar, 0x88))
                    }
                    layoutParams = LinearLayout.LayoutParams(dp(ctx, 22), dp(ctx, 22)).apply { marginEnd = dp(ctx, 6) }
                }
            if (themes && allThemes.isNotEmpty()) {
                val none = allThemes.none { it.enabled }
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = round(cardBg, 20f, ctx)
                    setPadding(dp(ctx, 14), dp(ctx, 14), dp(ctx, 12), dp(ctx, 14))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(ctx, 4); bottomMargin = dp(ctx, 4)
                    }
                    addView(TextView(ctx).apply {
                        text = "기본 (테마 없음)"
                        textSize = 15f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(onSurface)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(radio(none))
                    isClickable = true
                    setOnClickListener { if (!none) selectTheme(null) }
                })
            }
            if (items.isEmpty()) {
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(ctx, 20), dp(ctx, 18), dp(ctx, 20), dp(ctx, 14))
                    addView(ImageView(ctx).apply {
                        setImageResource(R.drawable.ic_extension)
                        imageTintList = android.content.res.ColorStateList.valueOf(onPrimaryContainer)
                        background = round(chipBg, 28f, ctx)
                        val p = dp(ctx, 16)
                        setPadding(p, p, p, p)
                        layoutParams = LinearLayout.LayoutParams(dp(ctx, 64), dp(ctx, 64)).apply { bottomMargin = dp(ctx, 14) }
                    })
                    addView(TextView(ctx).apply {
                        text = if (themes) "아직 설치한 테마가 없어요" else "아직 설치한 확장 프로그램이 없어요"
                        textSize = 15f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(onSurface)
                        gravity = Gravity.CENTER
                    })
                    addView(TextView(ctx).apply {
                        text = if (themes) "＋ 추가를 눌러 크롬 웹스토어의 테마 주소(또는 ID)로 바로 설치하거나,\n.zip · .crx 파일을 추가해 보세요."
                        else "＋ 추가를 눌러 크롬 웹스토어 주소(또는 ID)로 바로 설치하거나,\n.zip · .crx 파일을 추가해 보세요.\n\n" +
                            "다크 모드 · 광고 차단 · 글자 정리처럼 웹페이지를 꾸미는 확장 프로그램과, 팝업 · 백그라운드 · 요청 차단 · 우클릭 메뉴를 쓰는 확장 프로그램도 지원해요."
                        textSize = 12.5f
                        setTextColor(onVar)
                        setLineSpacing(0f, 1.15f)
                        gravity = Gravity.CENTER
                        setPadding(0, dp(ctx, 8), 0, 0)
                    })
                })
                return@fill
            }
            var lastOn: Boolean? = null
            val hasBoth = items.any { it.enabled } && items.any { !it.enabled }
            items.forEach { e ->
                if (!themes && hasBoth && lastOn != e.enabled) {
                    list.addView(TextView(ctx).apply {
                        text = if (e.enabled) "켜짐 · ${enabledCount}" else "꺼짐 · ${items.size - enabledCount}"
                        textSize = 11.5f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(primary)
                        setPadding(dp(ctx, 6), dp(ctx, 10), 0, dp(ctx, 2))
                    })
                }
                lastOn = e.enabled
                val lit = e.enabled || themes   // 테마 카드는 선택 여부와 상관없이 흐리게 하지 않는다
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    alpha = if (lit) 1f else 0.85f
                    background = round(if (lit) cardBg else cardBgOff, 20f, ctx)
                    setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 8), dp(ctx, 10))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(ctx, 4)
                        bottomMargin = dp(ctx, 4)
                    }

                    // 윗줄: 아이콘 · 이름/버전/설명 · 스위치 (아이콘·이름을 누르면 팝업이 있는 확장 프로그램은 바로 팝업을 연다)
                    val top = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val info = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        if ((mgr.popupOf(e) != null || mgr.sidePanelOf(e) != null || mgr.hasActionClick(e.id)) && e.enabled) {
                            isClickable = true
                            background = RippleDrawable(
                                android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(onPrimaryContainer, 0x22)),
                                null, round(0xFFFFFFFF.toInt(), 14f, ctx)
                            )
                            setOnClickListener {
                                close()
                                launch(e)
                            }
                        }
                        addView(ImageView(ctx).apply {
                            val bmp = mgr.iconBitmap(e)
                            if (bmp != null) setImageBitmap(bmp)
                            else {
                                setImageResource(R.drawable.ic_extension)
                                imageTintList = android.content.res.ColorStateList.valueOf(onPrimaryContainer)
                                val p = dp(ctx, 8)
                                setPadding(p, p, p, p)
                            }
                            background = round(iconBg, 12f, ctx)
                            alpha = if (lit) 1f else 0.45f
                            layoutParams = LinearLayout.LayoutParams(dp(ctx, 42), dp(ctx, 42)).apply { marginEnd = dp(ctx, 12) }
                        })
                        addView(LinearLayout(ctx).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            alpha = if (lit) 1f else 0.55f
                            addView(LinearLayout(ctx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                addView(TextView(ctx).apply {
                                    text = e.name
                                    textSize = 15f
                                    setTypeface(typeface, Typeface.BOLD)
                                    setTextColor(onSurface)
                                    maxLines = 1
                                    ellipsize = android.text.TextUtils.TruncateAt.END
                                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(ctx, 6) }
                                })
                                addView(TextView(ctx).apply {
                                    text = "v${e.version}"
                                    textSize = 10.5f
                                    setTextColor(onPrimaryContainer)
                                    background = round(primaryContainer, 8f, ctx)
                                    setPadding(dp(ctx, 6), dp(ctx, 1), dp(ctx, 6), dp(ctx, 1))
                                })
                            })
                            if (e.description.isNotBlank()) addView(TextView(ctx).apply {
                                text = e.description
                                textSize = 12f
                                setTextColor(onVar)
                                maxLines = 2
                                ellipsize = android.text.TextUtils.TruncateAt.END
                                setPadding(0, dp(ctx, 2), 0, 0)
                            })
                            // 이 확장 프로그램이 하는 일을 작은 꼬리표로 (최대 3개)
                            val tags = ArrayList<String>()
                            if (mgr.popupOf(e) != null) tags.add("팝업") else if (mgr.sidePanelOf(e) != null) tags.add("사이드 패널") else if (mgr.hasActionClick(e.id)) tags.add("툴바 실행")
                            if (e.hasBackground) tags.add("백그라운드")
                            val rules = mgr.dnrRuleCount(e.id)
                            if (rules > 0) tags.add("차단 규칙 $rules")
                            else if (e.entries.isNotEmpty()) tags.add("페이지 ${e.entries.size}곳")
                            if (tags.isNotEmpty()) addView(LinearLayout(ctx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                setPadding(0, dp(ctx, 5), 0, 0)
                                tags.take(3).forEach { t ->
                                    addView(TextView(ctx).apply {
                                        text = t
                                        textSize = 10.5f
                                        maxLines = 1
                                        setTextColor(onPrimaryContainer)
                                        background = round(if (lit) primaryContainer else ColorUtils.blendARGB(surface, primaryContainer, 0.6f), 8f, ctx)
                                        setPadding(dp(ctx, 7), dp(ctx, 2), dp(ctx, 7), dp(ctx, 2))
                                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 5) }
                                    })
                                }
                            })
                        })
                    }
                    top.addView(info)
                    if (themes) {
                        top.addView(radio(e.enabled))
                        isClickable = true
                        setOnClickListener { if (!e.enabled) selectTheme(e.id) }
                    } else
                    top.addView(MaterialSwitch(ctx).apply {
                        isChecked = e.enabled
                        setOnCheckedChangeListener { _, on ->
                            mgr.setEnabled(e.id, on)
                            onChanged() // 닫기를 기다리지 않고 바로 적용
                            // 창을 닫지 않고 목록을 다시 그려 '켜짐 · 꺼짐' 묶음과 순서가 바로 바뀌게 한다
                            list.post {
                                android.transition.TransitionManager.beginDelayedTransition(list)
                                list.removeAllViews()
                                fillRef?.invoke(list, close, onDismiss)
                                // 머리말의 '○개 설치됨 · ○개 켜짐' 도 같이 맞춘다
                                val now = loadItems()
                                list.rootView.findViewById<TextView>(R.id.popupSub)?.text =
                                    "${now.size}개 설치됨 · ${now.count { it.enabled }}개 켜짐"
                            }
                        }
                    })
                    addView(top)

                    // 제한 사항 안내
                    val notes = ArrayList<String>()
                    if (!mgr.isTheme(e) && e.entries.isEmpty() && !e.hasBackground && mgr.popupOf(e) == null && mgr.sidePanelOf(e) == null && !mgr.hasActionClick(e.id)) notes.add("웹페이지에 넣는 스크립트가 없어서 이 앱에서는 할 수 있는 일이 없어요")
                    if (notes.isNotEmpty()) addView(TextView(ctx).apply {
                        text = notes.joinToString("\n")
                        textSize = 11.5f
                        setTextColor(0xFFC77700.toInt())
                        background = round(0x1AC77700, 10f, ctx)
                        setPadding(dp(ctx, 10), dp(ctx, 6), dp(ctx, 10), dp(ctx, 6))
                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                            topMargin = dp(ctx, 8)
                            marginEnd = dp(ctx, 4)
                        }
                    })

                    // 아랫줄: 팝업 · 옵션 ·········· 삭제 (알약 모양 버튼)
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, dp(ctx, 8), dp(ctx, 4), 0)
                        fun chip(label: String, fg: Int, bg: Int, click: () -> Unit) {
                            addView(TextView(ctx).apply {
                                text = label
                                textSize = 12.5f
                                setTypeface(typeface, Typeface.BOLD)
                                setTextColor(fg)
                                gravity = Gravity.CENTER
                                background = RippleDrawable(
                                    android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(fg, 0x33)),
                                    round(bg, 100f, ctx), null
                                )
                                setPadding(dp(ctx, 14), dp(ctx, 7), dp(ctx, 14), dp(ctx, 7))
                                isClickable = true
                                setOnClickListener { click() }
                                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 6) }
                            })
                        }
                        fun delBtn(click: () -> Unit) {
                            addView(ImageButton(ctx).apply {
                                setImageResource(R.drawable.ic_delete)
                                imageTintList = android.content.res.ColorStateList.valueOf(dangerFg)
                                contentDescription = "삭제"
                                background = RippleDrawable(
                                    android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(dangerFg, 0x33)),
                                    round(dangerBg, 100f, ctx), null
                                )
                                val pd = dp(ctx, 8)
                                setPadding(pd, pd, pd, pd)
                                layoutParams = LinearLayout.LayoutParams(dp(ctx, 36), dp(ctx, 36))
                                setOnClickListener { click() }
                            })
                        }
                        val hasPop = mgr.popupOf(e) != null
                        val hasSide = mgr.sidePanelOf(e) != null
                        if (hasPop || hasSide || mgr.hasActionClick(e.id)) {
                            chip(if (hasPop) "팝업 열기" else if (hasSide) "사이드 패널" else "실행", onPrimaryContainer, chipBg) {
                                if (!e.enabled) {
                                    AppToast.show(ctx, "꺼져 있는 확장 프로그램이에요. 먼저 켜 주세요")
                                } else {
                                    close()
                                    launch(e)
                                }
                            }
                        }
                        e.options?.let { o ->
                            chip("옵션", onPrimaryContainer, chipBg) {
                                close()
                                onOpenPage(mgr.pageUrl(e, o))
                            }
                        }
                        chip("진단", onPrimaryContainer, ColorUtils.blendARGB(surface, primaryContainer, 0.6f)) { showDiag(ctx, mgr, e) }
                        addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
                        delBtn {
                            Popup.confirm(
                                ctx, "'${e.name}'을(를) 삭제할까요?",
                                "확장 프로그램 파일과 저장된 설정이 모두 지워져요.",
                                "삭제", danger = true
                            ) {
                                mgr.remove(e.id)
                                onChanged()
                                close()
                                // 남은 목록으로 다시 연다 (바뀐 것은 바로 적용된다)
                                if (mgr.list().any { mgr.isTheme(it) == themes }) {
                                    show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged, anchor, themes)
                                } else if (themes) {
                                    show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged, anchor, false)
                                } else if (mgr.list().isNotEmpty()) {
                                    show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged, anchor, false)
                                }
                            }
                        }
                    })
                })
            }
        }
        fillRef = fill
        if (anchor != null && Popup.canAnchor(ctx, anchor)) {
            Popup.panelAnchored(
                ctx, anchor, title, subtitle, R.drawable.ic_extension, widthDp = 400,
                secondaryLabel = "＋ 추가",
                onSecondary = { close -> close(); onAdd() },
                build = fill
            )
        } else {
            Popup.panel(
                ctx,
                title = title,
                subtitle = subtitle,
                headerIcon = R.drawable.ic_extension,
                widthDp = 400,
                grayBackground = true,
                secondaryLabel = "＋ 추가",
                onSecondary = { d ->
                    d.dismiss()
                    onAdd()
                }
            ) { list, dialog -> fill(list, { dialog.dismiss() }, { cb -> dialog.setOnDismissListener { cb() } }) }
        }
    }

    /** 테마 목록 창: 미리보기가 있는 2열 카드. 카드를 누르면 바로 적용되고, 선택된 카드는 초록 테두리와 체크가 붙는다 */
    private fun fillThemes(
        ctx: Context, mgr: ExtensionManager, list: LinearLayout, close: () -> Unit,
        allThemes: List<ExtensionManager.Ext>, items: List<ExtensionManager.Ext>,
        onAdd: () -> Unit, onOpenPage: (String) -> Unit, onOpenPopup: (ExtensionManager.Ext) -> Unit,
        onChanged: () -> Unit, anchor: View?
    ) {
        fun color(attr: Int, def: Int) = ThemeColors.get(ctx, attr, def)
        val onSurface = color(com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = color(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = color(com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val surface = color(com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val container = color(com.google.android.material.R.attr.colorSurfaceContainer, 0xFFF7F8FA.toInt())
        val containerHigh = color(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFFE3E5E8.toInt())
        val outline = color(com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt())
        val primaryContainer = color(com.google.android.material.R.attr.colorPrimaryContainer, 0xFFE8F5EC.toInt())
        val onPrimaryContainer = color(com.google.android.material.R.attr.colorOnPrimaryContainer, 0xFF14532D.toInt())
        val dangerFg = androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_danger)
        val activeId = allThemes.firstOrNull { it.enabled }?.id
        val activeBuiltin = if (activeId == null) mgr.activeBuiltinId else null

        fun reopen(themesMode: Boolean) = show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged, anchor, themesMode)
        fun select(id: String?) {
            if (id != null) mgr.setEnabled(id, true)
            else { allThemes.filter { it.enabled }.forEach { mgr.setEnabled(it.id, false) }; mgr.setBuiltinTheme(null) }
            onChanged()
            close()
            reopen(true)
        }
        fun selectBuiltin(id: String) {
            mgr.setBuiltinTheme(id)
            onChanged()
            close()
            reopen(true)
        }

        // 확장 프로그램 창으로 돌아가는 작은 줄
        list.addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            background = RippleDrawable(
                android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(primary, 0x22)),
                round(0x00000000, 100f, ctx), null
            )
            setPadding(dp(ctx, 8), dp(ctx, 6), dp(ctx, 14), dp(ctx, 6))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(ctx, 6)
            }
            addView(ImageView(ctx).apply {
                setImageResource(R.drawable.ic_back)
                imageTintList = android.content.res.ColorStateList.valueOf(primary)
                layoutParams = LinearLayout.LayoutParams(dp(ctx, 18), dp(ctx, 18)).apply { marginEnd = dp(ctx, 4) }
            })
            addView(TextView(ctx).apply {
                text = "확장 프로그램"
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(primary)
            })
            setOnClickListener { close(); reopen(false) }
        })

        val radius = 18f
        fun card(name: String, sub: String, selected: Boolean, spec: ExtensionManager.ThemeSpec?, onPick: () -> Unit, onDelete: (() -> Unit)?): View {
            return LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                isClickable = true
                background = RippleDrawable(
                    android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(primary, 0x22)),
                    GradientDrawable().apply {
                        setColor(surface)
                        cornerRadius = dp(ctx, radius.toInt()).toFloat()
                        if (selected) setStroke(dp(ctx, 2), primary) else setStroke(dp(ctx, 1), ColorUtils.setAlphaComponent(outline, 0x99))
                    }, null
                )
                setPadding(dp(ctx, 7), dp(ctx, 7), dp(ctx, 7), dp(ctx, 9))
                setOnClickListener { if (!selected) onPick() }
                addView(FrameLayout(ctx).apply {
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 84))
                    addView(View(ctx).apply {
                        background = ThemePreviewDrawable(spec, containerHigh, surface, container, onSurface).also { it.radius = dp(ctx, 12).toFloat() }
                        layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    })
                    if (onDelete != null) addView(ImageButton(ctx).apply {
                        setImageResource(R.drawable.ic_delete)
                        imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt())
                        contentDescription = "삭제"
                        background = RippleDrawable(
                            android.content.res.ColorStateList.valueOf(0x33FFFFFF),
                            round(0x99000000.toInt(), 100f, ctx), null
                        )
                        val pd = dp(ctx, 6)
                        setPadding(pd, pd, pd, pd)
                        layoutParams = FrameLayout.LayoutParams(dp(ctx, 28), dp(ctx, 28), Gravity.TOP or Gravity.END).apply {
                            topMargin = dp(ctx, 5); marginEnd = dp(ctx, 5)
                        }
                        setOnClickListener { onDelete() }
                    })
                })
                addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(ctx, 4), dp(ctx, 8), dp(ctx, 2), 0)
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        addView(TextView(ctx).apply {
                            text = name
                            textSize = 13.5f
                            setTypeface(typeface, Typeface.BOLD)
                            setTextColor(onSurface)
                            maxLines = 1
                            ellipsize = android.text.TextUtils.TruncateAt.END
                        })
                        addView(TextView(ctx).apply {
                            text = sub
                            textSize = 11f
                            setTextColor(if (selected) primary else onVar)
                            maxLines = 1
                            ellipsize = android.text.TextUtils.TruncateAt.END
                        })
                    })
                    addView(FrameLayout(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(ctx, 22), dp(ctx, 22)).apply { marginStart = dp(ctx, 6) }
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            if (selected) setColor(primary) else setStroke(dp(ctx, 2), ColorUtils.setAlphaComponent(onVar, 0x77))
                        }
                        if (selected) addView(ImageView(ctx).apply {
                            setImageResource(R.drawable.ic_check)
                            imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt())
                            val pd = dp(ctx, 4)
                            setPadding(pd, pd, pd, pd)
                            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        })
                    })
                })
            }
        }

        // '기본' 카드 + 설치된 테마 카드를 2열로
        val cards = ArrayList<View>()
        cards.add(card("기본", "앱 기본 모양", activeId == null && activeBuiltin == null, null, { select(null) }, null))
        mgr.builtinThemes.forEach { bt ->
            val on = activeBuiltin == bt.id
            cards.add(card(bt.name, if (on) "사용 중" else "내장 테마", on, bt.spec, { selectBuiltin(bt.id) }, null))
        }
        items.forEach { e ->
            cards.add(card(
                e.name, if (e.enabled) "사용 중" else "v${e.version}", e.enabled, mgr.themeSpecOf(e),
                { select(e.id) },
                {
                    Popup.confirm(
                        ctx, "'${e.name}'을(를) 삭제할까요?",
                        "테마 파일이 지워져요. 사용 중이던 테마면 앱 기본 모양으로 돌아가요.",
                        "삭제", danger = true
                    ) {
                        mgr.remove(e.id)
                        onChanged()
                        close()
                        reopen(true)
                    }
                }
            ))
        }
        val gap = dp(ctx, 5)
        cards.chunked(2).forEach { pair ->
            list.addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = gap; bottomMargin = gap
                }
                pair.forEachIndexed { i, v ->
                    addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (i == 0) marginEnd = gap else marginStart = gap
                    })
                }
                if (pair.size == 1) addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = gap })
            })
        }
        if (items.isEmpty()) {
            list.addView(TextView(ctx).apply {
                text = "크롬 웹스토어의 테마는 아래 ＋ 추가에서 주소(또는 ID)를 넣거나 .zip · .crx 파일을 골라 더할 수 있어요."
                textSize = 12.5f
                setTextColor(onVar)
                setLineSpacing(0f, 1.15f)
                gravity = Gravity.CENTER
                setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 4))
            })
        }
    }
}
