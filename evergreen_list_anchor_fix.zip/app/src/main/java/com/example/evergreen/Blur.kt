package com.example.evergreen

import android.content.Context
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.PopupWindow
import androidx.annotation.RequiresApi
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 메뉴·팝업 뒤 배경 블러 (유리 느낌).
 * Android 12(API 31) 이상이고 기기가 창 블러를 지원/허용할 때만 켜진다.
 * 그 외 기기(또는 절전 모드 등으로 꺼진 경우)에서는 예전처럼 불투명 배경 + 어둡게 처리만 한다.
 */
object Blur {

    /** 설정의 "블러 효과" 스위치. false 면 앱의 모든 블러가 꺼진다 (앱 시작 때 Prefs 에서 읽는다) */
    @Volatile
    var enabled = true

    /** 앱 안 RenderEffect 블러를 쓸 수 있는지 (Android 12+ 이고 설정에서 켜 둔 경우) */
    fun active(): Boolean = enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    /**
     * 태블릿 UI(최소 너비 600dp 이상)인지.
     * 태블릿에서는 메뉴·설정 창 뒤에 블러를 깔지 않는다 (웹페이지가 깜빡이며 발작하는 문제).
     */
    fun tablet(ctx: Context): Boolean =
        ctx.resources.configuration.smallestScreenWidthDp >= 600

    /** 기기가 창 뒤 블러를 쓸 수 있는지 (설정에서 꺼져 있거나 절전 모드·태블릿 UI 면 false) */
    fun supported(ctx: Context): Boolean {
        if (!enabled) return false
        if (tablet(ctx)) return false
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        return try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled
        } catch (e: Throwable) {
            false
        }
    }

    private fun px(ctx: Context, dp: Int) = (dp * ctx.resources.displayMetrics.density).toInt()

    // ───── 앱 안 대체 블러 ─────
    // 팝업(프리폼) 창·절전 모드처럼 시스템 창 블러(isCrossWindowBlurEnabled)가 꺼져 있으면 FLAG_BLUR_BEHIND 가 아무 일도 안 한다.
    // 그럴 때는 앱 화면(액티비티 내용)에 직접 RenderEffect 블러를 걸고, 팝업이 닫히면(창이 떨어지면) 푼다.
    private var fallbackCount = 0
    private var fallbackTarget: View? = null

    private fun activityOf(ctx: Context): android.app.Activity? {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) return c
            c = c.baseContext
        }
        return null
    }

    /** [popupRoot] 창이 떠 있는 동안 앱 화면을 흐리게 한다. 적용(예정)이면 true */
    private fun fallbackBehind(popupRoot: View, ctx: Context, radiusDp: Int): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        val act = activityOf(ctx) ?: return false
        // 액티비티 자기 창이면(팝업 모양 액티비티) 자기 내용을 흐리게 되므로 하지 않는다
        if (popupRoot === act.window.decorView) return false
        val target = act.findViewById<View>(android.R.id.content) ?: return false
        val radius = px(ctx, radiusDp).toFloat()
        var on = false
        fun on() {
            if (on) return
            on = true
            fallbackCount++
            fallbackTarget = target
            blurView(target, radius)
        }
        fun off() {
            if (!on) return
            on = false
            fallbackCount--
            if (fallbackCount <= 0) {
                fallbackCount = 0
                blurView(target, 0f)
                fallbackTarget = null
            }
        }
        popupRoot.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = on()
            override fun onViewDetachedFromWindow(v: View) { off(); v.removeOnAttachStateChangeListener(this) }
        })
        if (popupRoot.isAttachedToWindow) on()
        return true
    }

    /**
     * 팝업 창 영역 "뒤"만 실시간으로 흐리는 뷰 (화면 전체가 아니라 팝업 카드 자리만).
     * 팝업 창 맨 뒤에 깔리고, 앱 화면을 이 자리만큼 그대로 다시 그린 뒤 RenderEffect 블러를 건다.
     * 앱 화면이 바뀔 때마다(영상·스크롤) 같이 갱신되므로 실시간이다.
     */
    @RequiresApi(Build.VERSION_CODES.S)
    private class BackdropView(
        ctx: Context, private val source: View, blurPx: Float, private val cornerPx: Float
    ) : View(ctx) {
        private val loc = IntArray(2)
        private val sloc = IntArray(2)
        private val pre = android.view.ViewTreeObserver.OnPreDrawListener { invalidate(); true }

        init {
            setRenderEffect(RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP))
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, cornerPx)
                }
            }
            importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        // 이 뷰는 팝업 창의 크기를 키우면 안 된다. 크기가 정해진(EXACTLY) 때만 그 크기를 따르고,
        // 아니면 0 으로 둔다. (MATCH_PARENT 로 붙이면 wrap_content 팝업 창이 화면 높이만큼 늘어난다)
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(widthMeasureSpec) else 0
            val h = if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(heightMeasureSpec) else 0
            setMeasuredDimension(w, h)
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            source.viewTreeObserver.addOnPreDrawListener(pre)
        }

        override fun onDetachedFromWindow() {
            super.onDetachedFromWindow()
            if (source.viewTreeObserver.isAlive) source.viewTreeObserver.removeOnPreDrawListener(pre)
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            getLocationOnScreen(loc)
            source.getLocationOnScreen(sloc)
            canvas.save()
            canvas.translate((sloc[0] - loc[0]).toFloat(), (sloc[1] - loc[1]).toFloat())
            source.draw(canvas)
            canvas.restore()
        }
    }

    /** 팝업 창(decor) 맨 뒤에 영역 전용 블러를 깐다. 못 깔면 false */
    private fun regionBackdrop(decor: View?, ctx: Context, blurDp: Int, cornerDp: Int): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        val group = decor as? android.view.ViewGroup ?: return false
        val act = activityOf(ctx) ?: return false
        val source = act.window.decorView
        if (decor === source) return false
        return try {
            val v = BackdropView(ctx, source, px(ctx, blurDp).toFloat(), px(ctx, cornerDp).toFloat())
            group.addView(v, 0, android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
            true
        } catch (e: Throwable) { false }
    }

    /** 다이얼로그/바텀시트 창 뒤(웹 페이지)를 흐리게 한다. 적용됐으면 true */
    fun behind(window: Window?, ctx: Context, radiusDp: Int = 18, dim: Float = 0.12f, cornerDp: Int = 26): Boolean {
        if (!enabled || window == null) return false
        if (tablet(ctx)) return false
        if (!supported(ctx)) {
            // 창이 카드 크기(가로·세로가 화면을 꽉 채우지 않음)면 그 자리만, 아니면(바텀시트 등) 앱 화면 전체를 흐린다
            val lp = window.attributes
            val card = lp.width != android.view.ViewGroup.LayoutParams.MATCH_PARENT &&
                lp.height != android.view.ViewGroup.LayoutParams.MATCH_PARENT
            if (card && regionBackdrop(window.decorView, ctx, maxOf(radiusDp, 24), cornerDp)) return true
            return fallbackBehind(window.decorView, ctx, radiusDp)
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND or WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                window.setDimAmount(dim)
                window.attributes = window.attributes.apply { blurBehindRadius = px(ctx, radiusDp) }
                true
            } else false
        } catch (e: Throwable) {
            false
        }
    }

    // ───── 목록 화면(별도 액티비티) 뒤 블러 ─────
    // 북마크·방문 기록·다운로드 시트는 다이얼로그가 아니라 투명한 '액티비티'라서 창 블러(FLAG_BLUR_BEHIND)가
    // 안 먹는 기기가 있다. 그래서 이 화면을 연 메인 화면(내용 뷰)에 직접 RenderEffect 블러를 걸고,
    // 시트가 닫히면(창이 떨어지면) 푼다. 시트가 올라오는 동안 블러도 서서히 짙어진다.
    private val launcherBlur = java.util.WeakHashMap<android.app.Activity, () -> Unit>()

    /** 같은 화면(target)을 지금 메뉴·팝업의 대체 블러가 흐리게 하고 있는지 */
    private fun menuHoldsBlur(target: View): Boolean = fallbackCount > 0 && fallbackTarget === target

    /** [list] 시트 뒤에 있는 [below] 화면을 흐리게 한다. 적용되면 true (못 하면 호출한 쪽이 다른 방법을 쓴다) */
    fun behindLauncher(
        list: android.app.Activity, below: android.app.Activity?, radiusDp: Int = 10, dim: Float = 0.12f
    ): Boolean {
        if (!active() || tablet(list) || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        val host = below ?: return false
        if (host === list || host.isFinishing || host.isDestroyed) return false
        val target = host.findViewById<View>(android.R.id.content) ?: return false
        val radius = px(list, radiusDp).toFloat()
        var cur = 0f
        var anim: android.animation.ValueAnimator? = null
        var released = false
        fun go(to: Float, ms: Long) {
            anim?.cancel()
            anim = android.animation.ValueAnimator.ofFloat(cur, to).apply {
                duration = ms
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener {
                    cur = it.animatedValue as Float
                    // 시트에서 ← 로 메뉴로 돌아오면 메뉴가 같은 화면에 자기 블러를 이미 걸었다 → 시트의 블러가 그걸 덮어 지우지 않게 한다
                    // 폰 시트의 늦은 블러 애니메이션이 태블릿 UI 로 바뀐 뒤에 블러를 거는 것도 막는다
                    if (menuHoldsBlur(target) || tablet(target.context)) it.cancel() else blurView(target, cur)
                }
                start()
            }
        }
        try { list.window.setDimAmount(dim) } catch (_: Throwable) {}
        go(radius, 280)
        val decor = list.window.decorView
        val releaseSoft = {
            if (!released) { released = true; go(0f, 150) }
        }
        val releaseNow = {
            released = true
            anim?.cancel()
            cur = 0f
            if (!menuHoldsBlur(target)) blurView(target, 0f)
        }
        launcherBlur[list] = releaseSoft
        decor.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) {
                releaseNow()
                launcherBlur.remove(list)
                v.removeOnAttachStateChangeListener(this)
            }
        })
        return true
    }

    /** 시트를 내릴 때 부르면 뒤 화면 블러가 서서히 풀린다 (창이 떨어질 때도 알아서 풀리니 안 불러도 된다) */
    fun releaseBehindLauncher(list: android.app.Activity) {
        launcherBlur.remove(list)?.invoke()
    }

    /**
     * 폰 → 태블릿 UI 로 바뀐 뒤 앱 화면에 남아 있는 블러를 모두 푼다.
     * (폰 시트가 걸어 둔 블러·대체 블러 개수를 초기화하고, 내용 뷰의 효과를 끈다)
     */
    fun clearAppBlur(act: android.app.Activity) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        try {
            for (release in launcherBlur.values.toList()) release()
            launcherBlur.clear()
            fallbackCount = 0
            fallbackTarget = null
            act.findViewById<View>(android.R.id.content)?.setRenderEffect(null)
        } catch (e: Throwable) {
            // 못 풀어도 그냥 넘어간다
        }
    }

    /** 뷰 자체(앱 안의 화면)를 흐리게 한다. radiusPx 가 0 에 가까우면 효과를 끈다. */
    @RequiresApi(Build.VERSION_CODES.S)
    fun blurView(v: View, radiusPx: Float) {
        try {
            v.setRenderEffect(
                if (radiusPx < 0.5f || !enabled) null
                else RenderEffect.createBlurEffect(radiusPx, radiusPx, Shader.TileMode.CLAMP)
            )
        } catch (e: Throwable) {
            // 블러를 못 쓰면 그냥 넘어간다
        }
    }

    fun dp(ctx: Context, dp: Int) = px(ctx, dp)

    /**
     * 이미 떠 있는 팝업 안의 아무 뷰로 그 팝업 창 뒤를 흐리게 한다 (자동완성 드롭다운처럼 창 객체를 못 얻는 경우).
     * 이미 적용돼 있으면 건너뛴다.
     */
    fun behindRootOf(v: View, ctx: Context, radiusDp: Int = 10) {
        if (!enabled || tablet(ctx)) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        if (!supported(ctx)) {
            if (!regionBackdrop(v.rootView, ctx, maxOf(radiusDp, 24), 12)) fallbackBehind(v.rootView, ctx, radiusDp)
            return
        }
        try {
            val root = v.rootView
            val lp = root.layoutParams as? WindowManager.LayoutParams ?: return
            if (lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND != 0) return
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = px(ctx, radiusDp)
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(root, lp)
        } catch (e: Throwable) {
            // 블러를 못 쓰면 그냥 넘어간다
        }
    }

    /** 드롭다운 팝업(PopupWindow, 보이고 난 뒤에 부른다) 뒤를 흐리게 한다 */
    fun behindPopup(pw: PopupWindow, ctx: Context, radiusDp: Int = 10) {
        if (!enabled || tablet(ctx)) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        if (!supported(ctx)) {
            val root = pw.contentView.rootView
            if (!regionBackdrop(root, ctx, maxOf(radiusDp, 24), 16)) fallbackBehind(root, ctx, radiusDp)
            return
        }
        try {
            val root = pw.contentView.rootView
            val lp = root.layoutParams as? WindowManager.LayoutParams ?: return
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = px(ctx, radiusDp)
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(root, lp)
        } catch (e: Throwable) {
            // 블러를 못 쓰면 그냥 넘어간다
        }
    }

    /** 테마 표면색. 블러가 켜져 있으면 뒤가 비치도록 반투명 */
    fun surface(ctx: Context, attr: Int, glass: Boolean, alpha: Int = 0xD6): Int {
        val c = MaterialColors.getColor(ctx, attr, 0xFFFFFFFF.toInt())
        return if (glass) ColorUtils.setAlphaComponent(c, alpha) else c
    }

    /** 반투명 유리 카드 배경 (모서리 반경: 왼위, 오른위, 오른아래, 왼아래 순서로 같은 값) */
    fun glass(ctx: Context, attr: Int, radiusPx: Float, topOnly: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            setColor(surface(ctx, attr, true))
            if (topOnly) cornerRadii = floatArrayOf(radiusPx, radiusPx, radiusPx, radiusPx, 0f, 0f, 0f, 0f)
            else cornerRadius = radiusPx
            // 얇은 테두리로 유리 가장자리 느낌
            setStroke(1, ColorUtils.setAlphaComponent(MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOutlineVariant, 0x33888888), 0x80))
        }
}
