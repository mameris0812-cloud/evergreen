package com.example.evergreen

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * AI 사용량 기록: Gemini 요청을 보낼 때마다 (키 · 모델 · 날짜)별로 호출 수 · 토큰 · 한도 도달 · 실패를 센다.
 *
 * - 하루의 기준은 구글의 무료 한도가 초기화되는 태평양 시간 자정이다 (한국 시간 오후 5시 · 미국 서머타임 기간에는 오후 4시).
 *   그래야 「오늘 쓴 양」이 「하루 한도」와 같은 날을 가리킨다.
 * - 구글은 남은 한도를 알려 주지 않는다. 그래서 이 기기에서 보낸 요청만 세고, 한도에 걸린 횟수를 따로 보여 준다.
 * - 키는 저장하지 않고 SHA-256 앞 8자리(되돌릴 수 없는 이름표)만 쓴다. 14일치만 남긴다.
 * - 저장 모양은 JSON 이 아닌 글 한 줄(`날짜|키표|모델|호출|한도|실패|입력토큰|출력토큰`)이라 단위 테스트로 확인할 수 있다.
 */
object GeminiUsage {
    /** 한 묶음(하루 · 키 · 모델)의 합계 */
    class Tally(
        var calls: Int = 0,
        var limit: Int = 0,
        var errors: Int = 0,
        var tokIn: Long = 0L,
        var tokOut: Long = 0L
    ) {
        val tokens: Long get() = tokIn + tokOut
        fun isEmpty(): Boolean = calls == 0 && limit == 0 && errors == 0
        fun add(o: Tally) {
            calls += o.calls; limit += o.limit; errors += o.errors; tokIn += o.tokIn; tokOut += o.tokOut
        }
    }

    /** 응답이 알려 준 토큰 수. [inTok] 은 보낸 쪽(질문 · 도구 설명), [outTok] 은 받은 쪽(답 + 생각) */
    class Tok(val inTok: Int, val outTok: Int)

    const val KEEP_DAYS = 14
    private const val PREF = "gemini_usage"
    private const val KEY_ROWS = "rows"
    private const val SAVE_GAP_MS = 2_000L

    private val PT: TimeZone = TimeZone.getTimeZone("America/Los_Angeles")

    /** "날짜|키표|모델" → 합계 */
    private val rows = LinkedHashMap<String, Tally>()
    private var sp: SharedPreferences? = null
    private var lastSave = 0L
    private var savePending = false

    // ───────── 저장 · 불러오기 ─────────

    @Synchronized
    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        sp = p
        load(p.getString(KEY_ROWS, "") ?: "")
        prune(now())
    }

    /** [text] 를 읽어 기록을 바꾼다 (깨진 줄은 건너뛴다) */
    @Synchronized
    fun load(text: String) {
        rows.clear()
        for (line in text.split('\n')) {
            val f = line.split('|')
            if (f.size != 8) continue
            val n = f.subList(3, 8).map { it.toLongOrNull() ?: -1L }
            if (n.any { it < 0 }) continue
            rows["${f[0]}|${f[1]}|${f[2]}"] = Tally(n[0].toInt(), n[1].toInt(), n[2].toInt(), n[3], n[4])
        }
    }

    @Synchronized
    fun dump(): String = rows.entries.joinToString("\n") { (k, t) ->
        "$k|${t.calls}|${t.limit}|${t.errors}|${t.tokIn}|${t.tokOut}"
    }

    private fun scheduleSave() {
        val p = sp ?: return
        val t = now()
        if (t - lastSave >= SAVE_GAP_MS) {
            lastSave = t
            p.edit().putString(KEY_ROWS, dump()).apply()
            return
        }
        if (savePending) return
        savePending = true
        Thread {
            try { Thread.sleep(SAVE_GAP_MS) } catch (_: InterruptedException) { }
            synchronized(this) {
                savePending = false
                lastSave = now()
                sp?.edit()?.putString(KEY_ROWS, dump())?.apply()
            }
        }.apply { isDaemon = true; name = "usage-save" }.start()
    }

    private fun now() = System.currentTimeMillis()

    // ───────── 기록 ─────────

    /** 키를 저장하지 않으려고 쓰는 이름표 (SHA-256 앞 8자리) */
    fun keyId(key: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
        return d.take(4).joinToString("") { "%02x".format(it) }
    }

    /**
     * 요청 하나의 결과를 센다. [code] 가 2xx 면 호출 + 토큰, 한도(429 중 [quota])면 한도 도달, 나머지(0 = 네트워크 오류 포함)는 실패.
     * 어느 스레드에서든 부를 수 있다.
     */
    @Synchronized
    fun record(key: String, model: String, code: Int, quota: Boolean, inTok: Int, outTok: Int, nowMs: Long = now()) {
        if (key.isEmpty()) return
        val id = "${dayKey(nowMs)}|${keyId(key)}|$model"
        val isNew = !rows.containsKey(id)
        val t = rows.getOrPut(id) { Tally() }
        when {
            code in 200..299 -> {
                t.calls++
                t.tokIn += maxOf(0, inTok)
                t.tokOut += maxOf(0, outTok)
            }
            code == 429 && quota -> t.limit++
            else -> t.errors++
        }
        if (isNew) prune(nowMs)
        scheduleSave()
    }

    /** 응답의 usageMetadata 에서 토큰 수를 읽는다. 없으면 0 */
    fun tokensOf(meta: JSONObject?): Tok {
        if (meta == null) return Tok(0, 0)
        val input = meta.optInt("promptTokenCount", 0) + meta.optInt("toolUsePromptTokenCount", 0)
        val output = meta.optInt("candidatesTokenCount", 0) + meta.optInt("thoughtsTokenCount", 0)
        return Tok(input, output)
    }

    /** 한 번에 받은 응답 글(generateContent)에서 토큰 수를 읽는다. 읽을 수 없으면 0 */
    fun tokensOfBody(body: String): Tok = try {
        tokensOf(JSONObject(body).optJSONObject("usageMetadata"))
    } catch (_: Exception) {
        Tok(0, 0)
    }

    /** 오래된 날은 지운다 */
    private fun prune(nowMs: Long) {
        val oldest = dayKey(nowMs - KEEP_DAYS * 24L * 3_600_000L)
        val it = rows.keys.iterator()
        while (it.hasNext()) if (it.next().substringBefore('|') < oldest) it.remove()
    }

    @Synchronized
    fun clear() {
        rows.clear()
        sp?.edit()?.remove(KEY_ROWS)?.apply()
    }

    // ───────── 날짜 ─────────

    /** [ms] 가 속한 한도 기준 날짜 ("20261121", 태평양 시간) */
    fun dayKey(ms: Long): String {
        val c = Calendar.getInstance(PT).apply { timeInMillis = ms }
        return String.format(Locale.US, "%04d%02d%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** 다음 한도 초기화(태평양 자정)까지 남은 시간 (ms) */
    fun msUntilReset(nowMs: Long = now()): Long = resetAt(nowMs) - nowMs

    /** 다음 한도 초기화 시각 (epoch ms) */
    fun resetAt(nowMs: Long = now()): Long {
        val c = Calendar.getInstance(PT).apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_MONTH, 1)
        }
        return c.timeInMillis
    }

    /** 날짜 "20261121" 의 요일 (0=일 … 6=토) */
    fun weekdayOf(day: String): Int {
        val c = Calendar.getInstance(PT).apply {
            clear()
            set(day.substring(0, 4).toInt(), day.substring(4, 6).toInt() - 1, day.substring(6, 8).toInt())
        }
        return c.get(Calendar.DAY_OF_WEEK) - 1
    }

    // ───────── 조회 ─────────

    @Synchronized
    fun day(day: String): Tally {
        val sum = Tally()
        for ((k, t) in rows) if (k.startsWith("$day|")) sum.add(t)
        return sum
    }

    fun today(nowMs: Long = now()): Tally = day(dayKey(nowMs))

    /** 오늘 이 키로 보낸 요청의 합계 */
    @Synchronized
    fun todayForKey(key: String, nowMs: Long = now()): Tally {
        val prefix = "${dayKey(nowMs)}|${keyId(key)}|"
        val sum = Tally()
        for ((k, t) in rows) if (k.startsWith(prefix)) sum.add(t)
        return sum
    }

    /** 오늘 모델별 합계 (호출이 많은 순) */
    @Synchronized
    fun todayByModel(nowMs: Long = now()): List<Pair<String, Tally>> {
        val prefix = "${dayKey(nowMs)}|"
        val by = LinkedHashMap<String, Tally>()
        for ((k, t) in rows) if (k.startsWith(prefix)) by.getOrPut(k.substringAfterLast('|')) { Tally() }.add(t)
        return by.entries.map { it.key to it.value }
            .sortedWith(compareByDescending<Pair<String, Tally>> { it.second.calls }.thenByDescending { it.second.tokens })
    }

    /** 오늘까지 [n]일의 날짜별 합계 (오래된 날 → 오늘 순, 기록이 없는 날도 빈 합계로 넣는다) */
    fun recentDays(n: Int, nowMs: Long = now()): List<Pair<String, Tally>> {
        val out = ArrayList<Pair<String, Tally>>(n)
        for (i in n - 1 downTo 0) {
            val d = dayKey(nowMs - i * 24L * 3_600_000L)
            out.add(d to day(d))
        }
        // 서머타임 전환으로 같은 날이 두 번 나오는 일을 막는다
        return out.distinctBy { it.first }
    }

    @Synchronized
    fun hasAnyRecord(): Boolean = rows.values.any { !it.isEmpty() }

    // ───────── 글 ─────────

    /** 1,234 → "1,234" · 12,345 → "1.2만" · 1,234,567 → "123만" · 123,456,789 → "1.2억" */
    fun formatTokens(n: Long): String {
        fun trim(v: Double): String {
            val s = String.format(Locale.US, "%.1f", v)
            return if (s.endsWith(".0")) s.dropLast(2) else s
        }
        return when {
            n < 10_000L -> String.format(Locale.US, "%,d", n)
            n < 1_000_000L -> trim(n / 10_000.0) + "만"
            n < 100_000_000L -> String.format(Locale.US, "%,d", n / 10_000L) + "만"
            else -> trim(n / 100_000_000.0) + "억"
        }
    }

    /** 5시간 12분 · 12분 · 1분 미만 */
    fun formatDuration(ms: Long): String {
        val min = (ms / 60_000L).toInt()
        return when {
            min < 1 -> "1분 미만"
            min < 60 -> "${min}분"
            min % 60 == 0 -> "${min / 60}시간"
            else -> "${min / 60}시간 ${min % 60}분"
        }
    }

    /** 키 한 줄 요약: "오늘 8회 · 4.1만 토큰 · 한도 1회". 기록이 없으면 null */
    fun summaryLine(t: Tally): String? {
        if (t.isEmpty()) return null
        val parts = ArrayList<String>()
        parts.add("오늘 ${t.calls}회")
        if (t.tokens > 0) parts.add("${formatTokens(t.tokens)} 토큰")
        if (t.limit > 0) parts.add("한도 ${t.limit}회")
        if (t.errors > 0) parts.add("실패 ${t.errors}회")
        return parts.joinToString(" · ")
    }
}
