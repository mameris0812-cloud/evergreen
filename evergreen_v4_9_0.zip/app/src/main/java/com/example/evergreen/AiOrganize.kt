package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AI 정리 · 말로 찾기의 글 처리 (프롬프트 만들기 · 답 읽기 · 중복 찾기). 화면과 네트워크는 쓰지 않아서 단위 테스트로 확인한다.
 * - 북마크 AI 정리: 폴더 분류 제안 + 같은 주소 중복 찾기
 * - 다운로드 AI 정리: 폴더 분류 · 알아보기 어려운 파일 이름 바꾸기 제안 + 같은 파일 중복 찾기
 * - 방문 기록 말로 찾기: 「지난주에 본 라면 레시피 페이지」 같은 말에 맞는 기록 고르기
 * AI 에는 제목 · 주소(앞부분) · 파일 이름 · 크기 같은 목록 정보만 보낸다. 페이지 내용이나 파일 내용은 보내지 않는다.
 */
object AiOrganize {
    /** 한 번에 AI 에 보내는 북마크 수 (최근 것부터) */
    const val MAX_BM = 120
    /** 한 번에 AI 에 보내는 다운로드 파일 수 */
    const val MAX_DL = 80
    /** 방문 기록 말로 찾기에서 AI 가 훑는 기록 수 (최근 것부터) */
    const val MAX_HISTORY = 400
    const val MAX_NEW_FOLDERS = 8

    private fun short(s: String, n: Int): String {
        val t = s.replace(Regex("\\s+"), " ").trim()
        return if (t.length <= n) t else t.take(n) + "…"
    }

    private fun hostOf(url: String): String =
        url.substringAfter("://", url).substringBefore('/').substringBefore('?').removePrefix("www.")

    // ───────────────────────── 주소 · 이름 다듬기 ─────────────────────────

    /** 같은 페이지인지 비교하려고 주소를 고르게 한다: 대소문자(주소 앞부분) · www · 끝 / · #조각 · 추적용 utm 값 */
    fun normUrl(u: String): String {
        var s = u.trim()
        s = s.substringBefore('#')
        val scheme = if (s.startsWith("http://", true)) "http" else if (s.startsWith("https://", true)) "https" else ""
        val rest = if (scheme.isEmpty()) s else s.substring(scheme.length + 3)
        val host = rest.substringBefore('/').substringBefore('?').lowercase().removePrefix("www.")
        var path = rest.substring(rest.substringBefore('/').substringBefore('?').length)
        var query = ""
        val q = path.indexOf('?')
        if (q >= 0) {
            query = path.substring(q + 1)
            path = path.substring(0, q)
        }
        path = path.trimEnd('/')
        val keep = query.split('&').filter { it.isNotEmpty() && !it.lowercase().startsWith("utm_") && !it.lowercase().startsWith("fbclid=") }
        return host + path + if (keep.isEmpty()) "" else "?" + keep.joinToString("&")
    }

    /** 폴더 이름: 줄바꿈 · 따옴표 · 슬래시를 빼고 14자까지 */
    fun cleanFolderName(s: String): String =
        s.replace(Regex("[\\r\\n\\t\"'`/\\\\]"), " ").replace(Regex("\\s+"), " ").trim().take(14).trim()

    /**
     * AI 가 알려 준 새 파일 이름을 안전하게 다듬는다. 확장자는 원래 것을 그대로 지키고, 쓸 수 없는 글자를 빼고, 60자까지.
     * 원래 이름과 같거나 쓸 수 없으면 null.
     */
    fun cleanFileName(original: String, suggested: String): String? {
        val ext = original.substringAfterLast('.', "")
        var base = suggested.trim()
        if (ext.isNotEmpty() && base.lowercase().endsWith(".${ext.lowercase()}")) base = base.dropLast(ext.length + 1)
        base = base.replace(Regex("[\\\\/:*?\"<>|\\r\\n\\t]"), " ").replace(Regex("\\s+"), " ").trim().trim('.').take(60).trim()
        if (base.isEmpty()) return null
        val out = if (ext.isEmpty()) base else "$base.$ext"
        return if (out == original) null else out
    }

    // ───────────────────────── 북마크 AI 정리 ─────────────────────────

    /**
     * 같은 페이지를 가리키는 북마크 묶음 (2개 이상인 묶음만). 각 묶음의 첫 번째가 남길 북마크다:
     * 폴더에 들어 있는 것이 먼저, 그 안에서는 목록에서 더 아래(먼저 저장한 것)에 있는 것.
     */
    fun bookmarkDuplicates(all: List<Bookmark>): List<List<Bookmark>> {
        val groups = LinkedHashMap<String, MutableList<Bookmark>>()
        for (b in all) groups.getOrPut(normUrl(b.url)) { ArrayList() }.add(b)
        return groups.values.filter { it.size > 1 }.map { g ->
            // 목록은 최근 저장이 앞이라 뒤쪽이 먼저 저장한 것
            val keep = g.lastOrNull { it.folderId != 0L } ?: g.last()
            listOf(keep) + g.filter { it.id != keep.id }
        }
    }

    /** 북마크 분류 요청. [targets] 의 번호(0부터)로 답을 받는다 */
    fun bookmarkPrompt(targets: List<Bookmark>, folderNameOf: (Long) -> String?, folders: List<String>): String {
        val sb = StringBuilder()
        sb.append("너는 웹 브라우저 북마크를 폴더로 정리해 주는 도우미야. 아래 북마크를 주제별 폴더로 나눠.\n")
        sb.append("규칙:\n")
        sb.append("- 이미 있는 폴더 중 알맞은 곳이 있으면 그 이름을 그대로 써. 없으면 새 폴더 이름을 지어(한국어, 2~8자, 예: 쇼핑 · 뉴스 · 개발 · 영상 · 학습).\n")
        sb.append("- 새 폴더는 최대 ${MAX_NEW_FOLDERS}개. 한두 개뿐인 주제는 새 폴더를 만들지 말고 빼 둬.\n")
        sb.append("- 이미 알맞은 폴더에 들어 있는 북마크는 옮기지 마. 어디에 둘지 확실하지 않으면 빼 둬.\n")
        sb.append("- 북마크는 한 폴더에만 넣어.\n")
        sb.append("JSON 으로만 답해: {\"groups\":[{\"folder\":\"폴더 이름\",\"items\":[번호,...]}]}\n\n")
        sb.append("이미 있는 폴더: ").append(if (folders.isEmpty()) "(없음)" else folders.joinToString(", ") { cleanFolderName(it) }).append("\n\n")
        sb.append("북마크 (번호 | 지금 폴더 | 제목 | 사이트):\n")
        targets.forEachIndexed { i, b ->
            val f = if (b.folderId == 0L) "-" else (folderNameOf(b.folderId) ?: "-")
            sb.append(i).append(" | ").append(f).append(" | ").append(short(b.title.ifBlank { b.url }, 50)).append(" | ")
                .append(short(b.url.substringAfter("://", b.url), 60)).append('\n')
        }
        return sb.toString()
    }

    class Group(val folder: String, val indexes: List<Int>)

    /** 분류 답 읽기: 번호가 범위 밖이거나 이미 다른 폴더에 넣은 것은 빼고, 새 폴더는 [MAX_NEW_FOLDERS] 개까지만 */
    fun parseGroups(json: String, size: Int, existing: Collection<String>): List<Group> {
        val arr = try {
            JSONObject(AiOneShot.clean(json)).optJSONArray("groups")
        } catch (e: Exception) {
            null
        } ?: return emptyList()
        val known = existing.associateBy { cleanFolderName(it).lowercase() }
        val used = HashSet<Int>()
        val out = ArrayList<Group>()
        var created = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val raw = cleanFolderName(o.optString("folder"))
            if (raw.isEmpty()) continue
            val name = known[raw.lowercase()] ?: raw
            val isNew = known[raw.lowercase()] == null
            val items = o.optJSONArray("items") ?: continue
            val ids = ArrayList<Int>()
            for (k in 0 until items.length()) {
                val n = items.optInt(k, -1)
                if (n in 0 until size && used.add(n)) ids.add(n)
            }
            if (ids.isEmpty()) continue
            if (isNew) {
                if (created >= MAX_NEW_FOLDERS) { ids.forEach { used.remove(it) }; continue }
                created++
            }
            out.add(Group(name, ids))
        }
        return out
    }

    // ───────────────────────── 다운로드 AI 정리 ─────────────────────────

    class DlFile(val key: String, val name: String, val size: Long, val time: Long, val mime: String?)

    /** 「이름 (1).pdf」 「이름 - 복사본.pdf」 「이름_copy.pdf」 같은 사본 표시를 뺀 이름 */
    internal fun baseKey(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        var b = if (ext.isEmpty()) name else name.dropLast(ext.length + 1)
        b = b.lowercase()
        var prev: String
        do {
            prev = b
            b = b.replace(Regex("\\s*\\(\\d{1,3}\\)\\s*$"), "")
                .replace(Regex("[\\s_-]*(copy|복사본)(\\s*\\d{1,3})?\\s*$"), "")
                .replace(Regex("[_-]\\d{1,2}$"), "")
        } while (b != prev)
        return if (ext.isEmpty()) b.trim() else b.trim() + "." + ext
    }

    /**
     * 같은 파일로 보이는 묶음 (2개 이상): 사본 표시를 뺀 이름이 같고 크기도 같은 것 (크기를 모르면 묶지 않는다).
     * 각 묶음의 첫 번째가 남길 파일(사본 표시가 없는 것 → 가장 먼저 받은 것)이다.
     */
    fun downloadDuplicates(files: List<DlFile>): List<List<DlFile>> {
        val groups = LinkedHashMap<String, MutableList<DlFile>>()
        for (f in files) {
            if (f.size <= 0L) continue
            groups.getOrPut(baseKey(f.name) + "|" + f.size) { ArrayList() }.add(f)
        }
        return groups.values.filter { it.size > 1 }.map { g ->
            val keep = g.filter { baseKey(it.name) == it.name.lowercase() }.minByOrNull { it.time } ?: g.minByOrNull { it.time }!!
            listOf(keep) + g.filter { it.key != keep.key }.sortedBy { it.time }
        }
    }

    fun downloadPrompt(files: List<DlFile>, folders: List<String>): String {
        val sb = StringBuilder()
        sb.append("너는 휴대폰 다운로드 폴더를 정리해 주는 도우미야. 파일 이름 · 종류 · 크기만 보고 정리 방법을 제안해.\n")
        sb.append("규칙:\n")
        sb.append("- folders: 비슷한 파일끼리 폴더로 묶어. 이미 있는 폴더 중 알맞은 곳이 있으면 그 이름을 그대로 써. 없으면 새 폴더 이름을 지어(한국어, 2~8자, 예: 문서 · 사진 · 영상 · 설치파일 · 압축).\n")
        sb.append("- 새 폴더는 최대 ${MAX_NEW_FOLDERS}개. 파일이 한두 개뿐인 종류는 폴더를 만들지 말고 빼 둬. 한 파일은 한 폴더에만.\n")
        sb.append("- renames: 이름이 의미 없는 파일(무작위 글자 · 긴 숫자 · 「download (3)」 · 「IMG_1234」 같은 것)만 알아보기 쉬운 이름으로 바꿔. ")
        sb.append("이름만으로 내용을 알 수 없으면 바꾸지 마. 이미 알아볼 수 있는 이름은 건드리지 마. 확장자는 빼고 이름만 적어(60자 이내, 슬래시 금지).\n")
        sb.append("JSON 으로만 답해: {\"folders\":[{\"name\":\"폴더 이름\",\"items\":[번호,...]}],\"renames\":[{\"i\":번호,\"name\":\"새 이름\"}]}\n\n")
        sb.append("이미 있는 폴더: ").append(if (folders.isEmpty()) "(없음)" else folders.joinToString(", ") { cleanFolderName(it) }).append("\n\n")
        sb.append("파일 (번호 | 이름 | 종류 | 크기):\n")
        files.forEachIndexed { i, f ->
            sb.append(i).append(" | ").append(short(f.name, 80)).append(" | ").append(f.mime ?: "-").append(" | ")
                .append(if (f.size > 0) ListUi.fmtSize(f.size) else "-").append('\n')
        }
        return sb.toString()
    }

    class Rename(val index: Int, val newName: String)
    class DlPlan(val groups: List<Group>, val renames: List<Rename>)

    fun parseDownloadPlan(json: String, files: List<DlFile>, existing: Collection<String>): DlPlan {
        val o = try { JSONObject(AiOneShot.clean(json)) } catch (e: Exception) { return DlPlan(emptyList(), emptyList()) }
        // 폴더 부분은 북마크 분류와 같은 모양이라 키 이름만 맞춰서 같은 해석기를 쓴다
        val arr = o.optJSONArray("folders") ?: JSONArray()
        val mapped = JSONArray()
        for (i in 0 until arr.length()) {
            val g = arr.optJSONObject(i) ?: continue
            mapped.put(JSONObject().put("folder", g.optString("name")).put("items", g.optJSONArray("items") ?: JSONArray()))
        }
        val groups = parseGroups(JSONObject().put("groups", mapped).toString(), files.size, existing)
        val renames = ArrayList<Rename>()
        val seen = HashSet<Int>()
        val rn = o.optJSONArray("renames") ?: JSONArray()
        for (i in 0 until rn.length()) {
            val r = rn.optJSONObject(i) ?: continue
            val idx = r.optInt("i", -1)
            if (idx !in files.indices || !seen.add(idx)) continue
            val nn = cleanFileName(files[idx].name, r.optString("name")) ?: continue
            renames.add(Rename(idx, nn))
        }
        return DlPlan(groups, renames)
    }

    // ───────────────────────── 방문 기록 말로 찾기 ─────────────────────────

    /** AI 에 보낼 기록 목록 (최근 순, [MAX_HISTORY] 개까지). 번호(0부터)는 [items] 의 자리 */
    fun historyPrompt(items: List<HistoryItem>, query: String, now: Long): String {
        val dayFmt = SimpleDateFormat("yyyy-MM-dd (E) HH:mm", Locale.KOREA)
        val rowFmt = SimpleDateFormat("M/d HH:mm", Locale.KOREA)
        val sb = StringBuilder()
        sb.append("너는 브라우저 방문 기록에서 사용자가 말로 설명한 페이지를 찾아 주는 도우미야.\n")
        sb.append("지금은 ").append(dayFmt.format(Date(now))).append(" 이야. 「어제」 「지난주」 「며칠 전」 같은 때 표현은 이 시각과 기록의 시각으로 따져.\n")
        sb.append("제목 · 주소의 뜻이 사용자가 말한 것과 맞는 기록을 가장 잘 맞는 순서로 골라 (최대 30개). 비슷한 말·다른 표기(예: 라면 = ramen)도 같은 것으로 봐. 맞는 게 없으면 빈 목록.\n")
        sb.append("JSON 으로만 답해: {\"matches\":[번호,...]}\n\n")
        sb.append("찾는 것: ").append(short(query, 200)).append("\n\n")
        sb.append("방문 기록 (번호 | 시각 | 제목 | 주소):\n")
        items.take(MAX_HISTORY).forEachIndexed { i, h ->
            sb.append(i).append(" | ").append(if (h.time > 0L) rowFmt.format(Date(h.time)) else "-").append(" | ")
                .append(short(h.title.ifBlank { hostOf(h.url) }, 50)).append(" | ").append(short(h.url.substringAfter("://", h.url), 70)).append('\n')
        }
        return sb.toString()
    }

    /** 찾기 답 읽기: 범위 밖 번호 · 겹치는 번호는 빼고 순서를 지킨다 */
    fun parseMatches(json: String, size: Int): List<Int> {
        val arr = try {
            JSONObject(AiOneShot.clean(json)).optJSONArray("matches")
        } catch (e: Exception) {
            null
        } ?: return emptyList()
        val out = LinkedHashSet<Int>()
        for (i in 0 until arr.length()) {
            val n = arr.optInt(i, -1)
            if (n in 0 until size) out.add(n)
            if (out.size >= 30) break
        }
        return out.toList()
    }

    /** 키가 없을 때의 대신 찾기: 말 속 낱말이 제목 · 주소에 모두 들어 있는 기록 */
    fun keywordMatches(items: List<HistoryItem>, query: String): List<HistoryItem> {
        val words = query.lowercase().split(Regex("\\s+")).map { it.trim() }.filter { it.length >= 1 }
        if (words.isEmpty()) return emptyList()
        return items.filter { h ->
            val hay = (h.title + " " + h.url).lowercase()
            words.all { hay.contains(it) }
        }
    }
}
