package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject

/**
 * 에이전트 4단계: 자율 모드 도구.
 * 목표를 하나 주면 계획 → 실행 → 확인을 스스로 이어 가고, 막히면 사용자에게 묻는다.
 * - make_plan: 계획을 세워 사용자에게 보여 주고 허락을 받는다 (허락하면 그 계획에 필요한 앱 조작은 다시 묻지 않는다)
 * - plan_step: 계획의 한 단계가 끝났다고 진행 카드에 표시한다 (카드에 줄을 따로 만들지 않는다)
 * - ask_user: 막혔을 때 사용자에게 묻고 답을 받는다
 */
object AgentAutoTools {
    /** 한 번의 실행에서 사용자에게 물을 수 있는 횟수 */
    const val MAX_ASKS = 3

    /** 계획 단계 수 한도 */
    const val MAX_PLAN_STEPS = 8

    fun build(): List<AgentTool> = listOf(makePlan(), planStep(), askUser())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    private fun stepsOf(a: JSONObject): List<String> {
        val arr = a.optJSONArray("steps") ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val t = arr.optString(i).trim()
            if (t.isNotEmpty()) out.add(short(t, 80))
            if (out.size >= MAX_PLAN_STEPS) break
        }
        return out
    }

    private fun makePlan() = AgentTool(
        name = "make_plan",
        description = "목표를 이루기 위한 계획을 짧은 단계 2~${MAX_PLAN_STEPS}개로 세워 사용자에게 보여 주고 허락을 받습니다. " +
            "앱을 바꾸는 도구를 쓰기 전에 반드시 먼저 한 번 부르세요. 허락되면 계획대로 이어서 실행하고, 계획이 크게 바뀔 때만 다시 부르세요. " +
            "읽기만 하면 되는 목표라면 계획 없이 바로 읽기 도구를 쓰세요.",
        risk = AgentRisk.CHANGE,
        alwaysAsk = true,
        askDetail = "허락하면 이 계획에 필요한 탭 · 이동 · 설정 같은 앱 조작은 다시 묻지 않아요. 다운로드처럼 위험한 작업은 그때그때 물어봐요. " +
            "중지하거나 끝난 뒤에도 「되돌리기」로 한 일을 취소할 수 있어요.",
        params = AgentSchema.obj(
            listOf(
                "goal" to AgentSchema.str("사용자가 이루려는 목표 한 문장"),
                "steps" to AgentSchema.strList("실행 순서대로 적은 짧은 단계들 (한 단계는 한 문장)")
            ),
            listOf("goal", "steps")
        ),
        doing = { "계획 세우는 중…" },
        run = { a, ctx ->
            val steps = stepsOf(a)
            if (steps.size < 2) {
                AgentResult.fail("계획은 단계 2개 이상으로 적어 주세요 (steps)")
            } else {
                ctx.planSize = steps.size
                ctx.onPlan(steps)
                AgentResult.ok(
                    JSONObject().put("message", "계획이 승인됐어요. 1번 단계부터 진행하고, 단계가 끝날 때마다 plan_step 으로 표시하세요").put("steps", steps.size),
                    "계획 ${steps.size}단계를 세웠어요"
                )
            }
        },
        ask = { a, _ ->
            val goal = short(a.optString("goal").trim(), 100)
            val steps = stepsOf(a)
            val sb = StringBuilder()
            if (goal.isNotEmpty()) sb.append("목표: ").append(goal).append("\n")
            steps.forEachIndexed { i, s -> sb.append("\n").append(i + 1).append(". ").append(s) }
            sb.toString()
        }
    )

    private fun planStep() = AgentTool(
        name = "plan_step",
        description = "계획의 [number] 번 단계가 끝났음(done) · 실패했음(failed) · 건너뛰었음(skipped) 을 진행 카드에 표시합니다. 단계를 마칠 때마다 부르세요.",
        risk = AgentRisk.READ,
        quiet = true,
        params = AgentSchema.obj(
            listOf(
                "number" to AgentSchema.int("계획 단계 번호 (1부터)"),
                "status" to AgentSchema.oneOf("단계 상태", "done", "failed", "skipped")
            ),
            listOf("number", "status")
        ),
        doing = { a -> "계획 ${a.optInt("number")}번 단계 표시 중…" },
        run = { a, ctx ->
            val n = a.optInt("number")
            val st = a.optString("status")
            when {
                ctx.planSize == 0 -> AgentResult.fail("아직 계획이 없어요. make_plan 을 먼저 부르세요")
                n < 1 || n > ctx.planSize -> AgentResult.fail("계획 단계는 1~${ctx.planSize}번이에요")
                st != "done" && st != "failed" && st != "skipped" -> AgentResult.fail("status 는 done · failed · skipped 중 하나예요")
                else -> {
                    ctx.onPlanStep(n, st)
                    AgentResult.ok(JSONObject().put("message", "${n}번 단계를 $st 로 표시했어요"), "")
                }
            }
        }
    )

    private fun askUser() = AgentTool(
        name = "ask_user",
        description = "목표를 이루려면 사용자만 정할 수 있는 것(여러 후보 중 선택 · 빠진 정보 · 되돌릴 수 없는 결정)이 있거나, 방법이 막혔을 때 사용자에게 한 가지를 묻습니다. " +
            "한 번의 실행에서 ${MAX_ASKS}번까지만 묻을 수 있으니, 스스로 정할 수 있는 건 묻지 말고 정하세요. 선택지가 있으면 options 에 2~4개로 적으세요 (사용자는 직접 입력도 할 수 있어요).",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "question" to AgentSchema.str("사용자에게 물을 질문 한 문장"),
                "options" to AgentSchema.strList("선택지 (없으면 비워도 됨)")
            ),
            listOf("question")
        ),
        doing = { "사용자에게 묻는 중…" },
        run = { a, ctx ->
            val q = a.optString("question").trim()
            if (q.isEmpty()) {
                AgentResult.fail("질문(question)이 비어 있어요")
            } else if (ctx.asked >= MAX_ASKS) {
                AgentResult.fail("더 물을 수 없어요 (한 번에 ${MAX_ASKS}번까지). 지금까지 알게 된 것으로 정하거나, 여기까지 한 일을 알리고 멈추세요")
            } else {
                ctx.asked++
                val opts = ArrayList<String>()
                val arr: JSONArray? = a.optJSONArray("options")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.optString(i).trim()
                    if (o.isNotEmpty()) opts.add(short(o, 40))
                    if (opts.size >= 4) break
                }
                val ans = ctx.askUser(short(q, 200), opts)
                if (ans.isNullOrBlank()) {
                    AgentResult.fail("사용자가 답하지 않았어요. 더 진행하지 말고 지금까지 한 일과 필요한 것을 알리세요")
                } else {
                    // 사용자가 직접 한 말이라 자료(untrusted)로 취급하지 않는다
                    AgentResult.ok(JSONObject().put("answer", ans.take(500)), "답: ${short(ans.trim(), 30)}")
                }
            }
        }
    )
}
