package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject

/**
 * 에이전트: 지금 받는 중인 다운로드 다루기.
 * - 읽기(자동): list_active_downloads
 * - 변경(요청당 한 번 확인): control_download 의 일시정지 · 재개 (서로 되돌리기 가능)
 * - 위험(실행할 때마다 확인): control_download 의 취소 (받던 파일이 지워져 되돌릴 수 없다)
 *
 * 앱의 빠른 다운로드(DownloadService)로 받는 파일만 다룬다. 시스템 다운로드 관리자로 넘어간 파일은 앱이 멈추거나 취소할 수 없다.
 */
object AgentDownloadTools {
    fun build(): List<AgentTool> = listOf(listActive(), controlDownload())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    private fun nameOf(ctx: AgentContext, id: Int): String =
        ctx.host.activeDownloads().firstOrNull { it.id == id }?.name?.ifBlank { null } ?: "다운로드 ${id}"

    private fun listActive() = AgentTool(
        name = "list_active_downloads",
        description = "지금 받는 중이거나 일시정지된 다운로드를 돌려줍니다. 파일마다 id · 이름 · 진행률 · 속도 · 일시정지 여부가 나오고, id 는 control_download 에 씁니다. " +
            "이미 다 받은 파일은 list_downloads 로 봅니다.",
        risk = AgentRisk.READ,
        doing = { "받는 중인 파일 확인하는 중…" },
        run = { _, ctx ->
            val list = ctx.host.activeDownloads()
            val arr = JSONArray()
            for (d in list) {
                val o = JSONObject().put("id", d.id).put("name", d.name.take(120)).put("paused", d.paused)
                    .put("downloaded", ListUi.fmtSize(d.downloaded.coerceAtLeast(0L)))
                if (d.total > 0) {
                    o.put("total", ListUi.fmtSize(d.total)).put("percent", (d.downloaded * 100 / d.total).toInt().coerceIn(0, 100))
                }
                if (d.speedBps > 0) o.put("speed", ListUi.fmtSize(d.speedBps) + "/s")
                arr.put(o)
            }
            // 파일 이름은 웹사이트가 정한 글이라 자료로만 다룬다
            AgentResult.ok(JSONObject().put("count", list.size).put("downloads", arr), "받는 중인 파일 ${list.size}개를 확인했어요", untrusted = true)
        }
    )

    private fun controlDownload() = AgentTool(
        name = "control_download",
        description = "받는 중인 다운로드를 일시정지(pause) · 재개(resume) · 취소(cancel) 합니다. id 에 list_active_downloads 의 id 를 주고, 비우면 받는 중인 모든 파일에 적용합니다. " +
            "취소하면 받던 파일이 지워지고 되돌릴 수 없으니 사용자가 취소하라고 분명히 했을 때만 쓰세요. 일시정지한 파일은 resume 으로 이어 받습니다(앱을 닫으면 이어 받지 못합니다). " +
            "앱의 빠른 다운로드로 받는 파일만 다룰 수 있고, 시스템 다운로더로 넘어간 파일은 못 합니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "action" to AgentSchema.oneOf("할 일", "pause", "resume", "cancel"),
                "id" to AgentSchema.int("대상 다운로드 id (list_active_downloads 의 id, 비우면 모두)")
            ),
            listOf("action")
        ),
        riskFor = { a, _ -> if (a.optString("action").trim() == "cancel") AgentRisk.DANGER else AgentRisk.CHANGE },
        doing = { a ->
            when (a.optString("action").trim()) {
                "pause" -> "다운로드 일시정지하는 중…"
                "resume" -> "다운로드 이어 받는 중…"
                "cancel" -> "다운로드 취소하는 중…"
                else -> "다운로드 조작하는 중…"
            }
        },
        run = { a, ctx ->
            val action = a.optString("action").trim()
            val id = a.optInt("id", 0)
            if (action != "pause" && action != "resume" && action != "cancel") {
                AgentResult.fail("action 은 pause · resume · cancel 중 하나여야 해요")
            } else {
                val targets = ctx.host.activeDownloads().filter { id <= 0 || it.id == id }
                    .filter { action == "cancel" || (action == "pause" && !it.paused) || (action == "resume" && it.paused) }
                val all = ctx.host.activeDownloads()
                when {
                    all.isEmpty() -> AgentResult.fail("지금 받는 중인 파일이 없어요 (이미 끝났거나, 시스템 다운로더가 받는 파일은 다룰 수 없어요)")
                    id > 0 && all.none { it.id == id } -> AgentResult.fail("그 다운로드를 찾지 못했어요 (list_active_downloads 의 id 를 주세요)")
                    targets.isEmpty() -> AgentResult.ok(
                        JSONObject().put("message", "이미 그 상태예요").put("changed", 0),
                        if (action == "pause") "이미 모두 일시정지 상태예요" else "일시정지된 파일이 없어요"
                    )
                    else -> {
                        var done = 0
                        for (t in targets) if (ctx.host.controlDownload(t.id, action).ok) done++
                        val what = when (action) { "pause" -> "일시정지했어요"; "resume" -> "이어 받기 시작했어요"; else -> "취소했어요" }
                        val msg = "다운로드 ${done}개를 $what"
                        val ids = JSONArray(); targets.forEach { ids.put(it.id) }
                        AgentResult.ok(JSONObject().put("message", msg).put("changed", done).put("ids", ids), msg)
                    }
                }
            }
        },
        undoPlan = { a, ctx ->
            val action = a.optString("action").trim()
            val id = a.optInt("id", 0)
            if (action == "cancel") null else {
                val before = ctx.host.activeDownloads()
                    .filter { id <= 0 || it.id == id }
                    .filter { (action == "pause" && !it.paused) || (action == "resume" && it.paused) }
                    .map { it.id }
                val plan: (AgentResult) -> AgentUndo? = { r ->
                    if (r.data.optInt("changed", 0) <= 0 || before.isEmpty()) null
                    else {
                        val back = if (action == "pause") "resume" else "pause"
                        AgentUndo(if (action == "pause") "일시정지 풀기" else "다시 일시정지") { h ->
                            val live = h.activeDownloads().map { it.id }.toSet()
                            var n = 0
                            for (i in before) if (i in live && h.controlDownload(i, back).ok) n++
                            if (n == 0) AgentOutcome.fail("그 다운로드는 이미 끝났거나 없어졌어요") else AgentOutcome.ok("다운로드 ${n}개를 되돌렸어요", n)
                        }
                    }
                }
                plan
            }
        },
        ask = { a, ctx ->
            val id = a.optInt("id", 0)
            val target = if (id > 0) "「${short(nameOf(ctx, id), 28)}」" else "받는 중인 모든 파일"
            when (a.optString("action").trim()) {
                "pause" -> "다운로드 일시정지: $target"
                "resume" -> "다운로드 이어 받기: $target"
                else -> "다운로드 취소 (받던 파일이 지워져요): $target"
            }
        }
    )
}
