package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 설정 > AI 설정 > 「AI 사용량」 카드: 오늘 호출 · 토큰 · 한도 도달, 최근 7일 막대, 모델별 합계, 한도 초기화까지 남은 시간.
 * 기록은 [GeminiUsage] 가 센다. 구글이 남은 한도를 알려 주지 않으므로 이 기기에서 보낸 요청만 보여 준다.
 */
object UsageUi {
    private val WEEK = arrayOf("일", "월", "화", "수", "목", "금", "토")
    private const val AMBER = 0xFFF29900.toInt()

    /** 하루 한 칸짜리 막대 그래프 (맨 오른쪽이 오늘) */
    class DayBars(
        ctx: Context,
        private val values: List<Int>,
        private val labels: List<String>,
        private val barColor: Int,
        private val textColor: Int,
        private val faint: Int,
        private val desc: String
    ) : View(ctx) {
        private val density = ctx.resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        init {
            contentDescription = desc
            importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        }

        private fun d(v: Float) = v * density

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val n = values.size
            if (n == 0) return
            val topPad = d(16f)       // 막대 위 숫자 자리
            val bottomPad = d(18f)    // 아래 요일 자리
            val slot = width.toFloat() / n
            val barW = minOf(d(22f), slot * 0.56f)
            val area = height - topPad - bottomPad
            val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
            val today = n - 1
            paint.textAlign = Paint.Align.CENTER
            for (i in 0 until n) {
                val cx = slot * i + slot / 2f
                val v = values[i]
                val h = if (v <= 0) d(2f) else maxOf(d(4f), area * v / max)
                val top = topPad + area - h
                rect.set(cx - barW / 2f, top, cx + barW / 2f, topPad + area)
                paint.style = Paint.Style.FILL
                paint.color = when {
                    v <= 0 -> faint
                    i == today -> barColor
                    else -> ColorUtils.setAlphaComponent(barColor, 0x66)
                }
                canvas.drawRoundRect(rect, d(4f), d(4f), paint)
                if (v > 0) {
                    paint.color = textColor
                    paint.textSize = d(10f)
                    paint.typeface = if (i == today) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    canvas.drawText(v.toString(), cx, top - d(4f), paint)
                }
                paint.color = textColor
                paint.textSize = d(11f)
                paint.typeface = if (i == today) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                canvas.drawText(labels[i], cx, height - d(3f), paint)
            }
        }
    }

    /**
     * 카드 뷰를 만든다.
     * [panel] 은 설정 창의 다른 카드와 같은 바탕, [onCleared] 는 기록을 지운 뒤 카드를 다시 그리라고 부른다.
     */
    fun build(
        activity: Activity,
        onSurface: Int,
        onSurfaceVar: Int,
        primary: Int,
        panel: Drawable,
        onCleared: () -> Unit
    ): View {
        val density = activity.resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()

        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = panel
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(activity).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        fun divider() = View(activity).apply {
            setBackgroundColor(ColorUtils.setAlphaComponent(onSurface, 0x14))
        }.also {
            card.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(12); bottomMargin = dp(12)
            })
        }

        val now = System.currentTimeMillis()
        val today = GeminiUsage.today(now)

        // 제목 + 초기화 안내
        val resetAt = GeminiUsage.resetAt(now)
        val clock = SimpleDateFormat("a h:mm", Locale.KOREA).format(Date(resetAt))
        card.addView(text("오늘 쓴 양", 14f, onSurface, bold = true))
        card.addView(
            text("$clock 에 하루 한도가 초기화돼요 · ${GeminiUsage.formatDuration(GeminiUsage.msUntilReset(now))} 뒤", 12f, onSurfaceVar),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) }
        )

        if (!GeminiUsage.hasAnyRecord()) {
            card.addView(
                text("아직 기록이 없어요. AI에게 물어보면 여기에 쌓여요.", 13f, onSurfaceVar),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) }
            )
            return card
        }

        // 숫자 세 칸: 호출 · 토큰 · 한도 도달
        fun stat(number: String, caption: String, numberColor: Int): View = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
            addView(text(number, 22f, numberColor, bold = true))
            addView(text(caption, 12f, onSurfaceVar))
        }
        val stats = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(stat(today.calls.toString(), "호출", onSurface), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(stat(GeminiUsage.formatTokens(today.tokens), "토큰", onSurface), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(
            stat(today.limit.toString(), "한도 도달", if (today.limit > 0) AMBER else onSurface),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        card.addView(stats, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        if (today.errors > 0) {
            card.addView(
                text("실패한 요청 ${today.errors}회 (인터넷 · 서버 문제 등)", 12f, onSurfaceVar),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
            )
        }

        // 최근 7일
        divider()
        card.addView(text("최근 7일 · 호출 수", 12f, onSurfaceVar, bold = true))
        val days = GeminiUsage.recentDays(7, now)
        val values = days.map { it.second.calls }
        val labels = days.mapIndexed { i, p -> if (i == days.size - 1) "오늘" else WEEK[GeminiUsage.weekdayOf(p.first)] }
        val desc = "최근 7일 호출 수: " + days.indices.joinToString(", ") { "${labels[it]} ${values[it]}회" }
        card.addView(
            DayBars(activity, values, labels, primary, onSurfaceVar, ColorUtils.setAlphaComponent(onSurface, 0x1F), desc),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(92)).apply { topMargin = dp(6) }
        )

        // 모델별 (오늘)
        val byModel = GeminiUsage.todayByModel(now)
        if (byModel.isNotEmpty()) {
            divider()
            card.addView(text("모델별 · 오늘", 12f, onSurfaceVar, bold = true))
            for ((model, t) in byModel) {
                val color = when (model) {
                    GeminiModels.LITE.id -> 0xFF4285F4.toInt()
                    GeminiModels.HYDROGEN.id -> AMBER
                    else -> primary
                }
                val row = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                row.addView(
                    View(activity).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) } },
                    LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(10) }
                )
                row.addView(text(GeminiAuto.label(model), 13f, onSurface), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val right = buildString {
                    append("${t.calls}회")
                    if (t.tokens > 0) append(" · ${GeminiUsage.formatTokens(t.tokens)}")
                    if (t.limit > 0) append(" · 한도 ${t.limit}")
                }
                row.addView(text(right, 12f, onSurfaceVar))
                card.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
            }
        }

        // 안내 + 지우기
        divider()
        card.addView(
            text(
                "이 기기에서 보낸 요청만 세요. 구글은 남은 한도를 알려 주지 않아서 「한도 도달」 횟수와 키 상태로 짐작할 수 있어요. 하루는 구글 한도 기준(태평양 시간 자정)으로 세고, 14일치만 남겨요.",
                12f, onSurfaceVar
            )
        )
        card.addView(
            text("사용량 기록 지우기", 13f, 0xFFD93025.toInt()).apply {
                setPadding(0, dp(10), dp(10), dp(4))
                setOnClickListener {
                    ThemedDialogBuilder(activity)
                        .setTitle("사용량 기록 지우기")
                        .setMessage("이 기기에 쌓인 AI 사용량 기록을 모두 지워요. API 키와 AI 설정은 그대로예요.")
                        .setPositiveButton("지우기") { _, _ ->
                            GeminiUsage.clear()
                            onCleared()
                        }
                        .setNegativeButton("취소", null)
                        .show()
                }
            }
        )
        return card
    }
}
