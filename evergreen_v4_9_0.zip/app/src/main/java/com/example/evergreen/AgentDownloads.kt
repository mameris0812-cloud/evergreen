package com.example.evergreen

import android.app.DownloadManager
import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.annotation.RequiresApi

/** 받은 파일 한 개. [key] 는 "m:123"(미디어 저장소) 또는 "d:55"(시스템 다운로드 관리자) — 다운로드 화면과 같은 키 */
data class AgentDownload(val key: String, val name: String, val size: Long, val time: Long, val mime: String)

/**
 * 에이전트가 쓰는 받은 파일 목록 · 삭제. 다운로드 화면(DownloadsActivity)과 같은 곳(Android 10+ 는 미디어 저장소,
 * 그 아래는 시스템 다운로드 관리자)을 보고, 받는 중인 파일은 다루지 않는다.
 * 삭제는 [list] 에 실제로 있는 키만 지운다 (모델이 지어낸 번호로 다른 파일을 지우지 못하게).
 */
object AgentDownloads {
    private val KEY = Regex("[md]:\\d+")

    fun list(ctx: Context): List<AgentDownload> = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) queryMediaStore(ctx) else queryDownloadManager(ctx)
    } catch (e: Exception) {
        emptyList()
    }

    /** 받은 파일 목록에 실제로 있는 [key] 의 파일 (없으면 null). 모델이 지어낸 id 로 다른 파일을 읽지 못하게 한다 */
    fun find(ctx: Context, key: String): AgentDownload? =
        if (!KEY.matches(key.trim())) null else list(ctx).firstOrNull { it.key == key.trim() }

    /** [find] 로 확인된 받은 파일의 내용을 읽는다. [max] 바이트를 넘거나 못 읽으면 null */
    fun readBytes(ctx: Context, key: String, max: Int): ByteArray? {
        val k = key.trim()
        if (find(ctx, k) == null) return null
        return try {
            val id = k.substring(2).toLong()
            val stream = if (k.startsWith("m:")) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
                ctx.contentResolver.openInputStream(ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id))
            } else {
                val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                android.os.ParcelFileDescriptor.AutoCloseInputStream(dm.openDownloadedFile(id))
            } ?: return null
            stream.use { s ->
                val buf = java.io.ByteArrayOutputStream()
                val chunk = ByteArray(16 * 1024)
                while (true) {
                    val n = s.read(chunk)
                    if (n < 0) break
                    buf.write(chunk, 0, n)
                    if (buf.size() > max) return null
                }
                buf.toByteArray()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** [keys] 중 실제로 있는 파일을 기기에서 지우고, 지워진 키들을 돌려준다 */
    fun delete(ctx: Context, keys: Collection<String>): List<String> {
        val known = list(ctx).associateBy { it.key }
        val done = ArrayList<String>()
        for (k in keys) {
            if (!KEY.matches(k) || known[k] == null) continue
            val ok = try {
                removeOne(ctx, k)
            } catch (e: Exception) {
                false
            }
            if (ok) done.add(k)
        }
        return done
    }

    private fun removeOne(ctx: Context, key: String): Boolean {
        val id = key.substring(2).toLong()
        return if (key.startsWith("m:")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) removeMedia(ctx, id) else false
        } else {
            (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id) > 0
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun removeMedia(ctx: Context, id: Long): Boolean {
        val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
        return ctx.contentResolver.delete(uri, null, null) > 0
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun queryMediaStore(ctx: Context): List<AgentDownload> {
        val out = ArrayList<AgentDownload>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.MIME_TYPE
        )
        ctx.contentResolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, null, null,
            MediaStore.MediaColumns.DATE_ADDED + " DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            while (c.moveToNext()) {
                out.add(
                    AgentDownload(
                        key = "m:" + c.getLong(iId),
                        name = c.getString(iName) ?: "(이름 없음)",
                        size = c.getLong(iSize),
                        time = c.getLong(iDate) * 1000L,
                        mime = c.getString(iMime) ?: ""
                    )
                )
            }
        }
        return out
    }

    private fun queryDownloadManager(ctx: Context): List<AgentDownload> {
        val out = ArrayList<AgentDownload>()
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.query(DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL))?.use { c ->
            val iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
            val iTitle = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
            val iSize = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val iMime = c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)
            val iTime = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
            while (c.moveToNext()) {
                out.add(
                    AgentDownload(
                        key = "d:" + c.getLong(iId),
                        name = c.getString(iTitle) ?: "(이름 없음)",
                        size = c.getLong(iSize),
                        time = c.getLong(iTime),
                        mime = c.getString(iMime) ?: ""
                    )
                )
            }
        }
        return out.sortedByDescending { it.time }
    }
}
