package com.example.evergreen

import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.color.MaterialColors

/**
 * 확장 프로그램의 툴바 팝업(action.default_popup)을 새 탭이 아니라 앱 안 카드 팝업으로 띄운다 (크롬 방식).
 * 폭 360dp 기본, 폭·높이는 팝업 페이지 내용에 맞춰 늘고 줄며, 화면(폭 94% · 높이 86%)을 넘으면 스크롤 대신 내용을 줄여서(최소 55%) 맞춘다.
 */
object ExtensionPopup {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun viewport(ctx: Context): Pair<Int, Int> {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) {
                val root = c.window?.decorView
                if (root != null && root.width > 0 && root.height > 0) return root.width to root.height
                break
            }
            c = c.baseContext
        }
        val dm = ctx.resources.displayMetrics
        return dm.widthPixels to dm.heightPixels
    }

    private fun activityOf(ctx: Context): android.app.Activity? {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) return c
            c = c.baseContext
        }
        return null
    }

    /**
     * @param anchor 태블릿에서 이 팝업을 띄운 버튼. 있으면 그 버튼 바로 아래에 붙어서 뜬다
     *   (버튼을 못 쓰면 상단바 메뉴 버튼 아래, 그것도 없으면 오른쪽 위). 폰에서는 늘 화면 가운데.
     * @param onOpenTab 팝업 안 링크나 '탭에서 열기'로 주소를 새 탭에 열 때
     */
    fun show(
        ctx: Context,
        mgr: ExtensionManager,
        e: ExtensionManager.Ext,
        anchor: View? = null,
        onOpenTab: (String) -> Unit
    ): Dialog? {
        val page = mgr.popupOf(e) ?: return null
        val url = mgr.pageUrl(e, page)
        val onSurface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val surface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorSurface, Color.WHITE)
        val primary = ThemeColors.get(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())

        val dialog = Dialog(ctx, R.style.Evergreen_Popup)
        Popup.trackDialog(dialog)
        val (vw, vh) = viewport(ctx)
        // 태블릿(폭 600dp 이상)에서는 화면 가운데가 아니라 누른 버튼 아래에 붙어서 뜬다
        val tablet = ctx.resources.configuration.screenWidthDp >= 600
        val width = minOf(dp(ctx, 360), (vw * 0.94f).toInt())
        var maxW = (vw * 0.94f).toInt()                       // 창 크기가 바뀌면 아래 locate() 가 다시 잰다
        var maxBody = (vh * 0.86f).toInt() - dp(ctx, 64)
        val minBody = dp(ctx, 120)

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(surface)
                cornerRadius = dp(ctx, 26).toFloat()
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            isClickable = true   // 카드 안을 눌러도 '바깥을 눌러 닫기'로 새지 않게
        }

        // 머리말: 아이콘 · 이름 · 탭에서 열기 · 닫기
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 8), dp(ctx, 6))
        }
        header.addView(ImageView(ctx).apply {
            val bmp = mgr.iconBitmap(e)
            if (bmp != null) setImageBitmap(bmp)
            else {
                setImageResource(R.drawable.ic_extension)
                imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 26), dp(ctx, 26)).apply { marginEnd = dp(ctx, 10) }
        })
        header.addView(TextView(ctx).apply {
            text = e.name
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(onSurface)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        fun iconBtn(res: Int, desc: String, click: () -> Unit) = ImageButton(ctx).apply {
            setImageResource(res)
            imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            contentDescription = desc
            val tv = android.util.TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            val p = dp(ctx, 10)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 40), dp(ctx, 40))
            setOnClickListener { click() }
        }
        header.addView(iconBtn(R.drawable.ic_open_tab, "탭에서 열기") {
            dialog.dismiss()
            onOpenTab(url)
        })
        header.addView(iconBtn(R.drawable.ic_close, "닫기") { dialog.dismiss() })
        card.addView(header)

        // 위쪽 로딩 막대 (페이지가 다 불러와지면 사라진다)
        val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(primary)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 2))
        }
        card.addView(bar)

        val wv: WebView = mgr.newPopupView { link -> dialog.dismiss(); onOpenTab(link) }
        wv.setBackgroundColor(surface)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        val body = FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 200))
        }
        body.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(body)

        // 창은 화면 전체를 덮는 투명한 틀이고, 카드가 그 안에서 자기 폭·자리를 갖는다.
        // (예전에는 창 자체를 카드 폭으로 줄이고 가운데에 놓았다 → 태블릿에서 버튼 곁에 놓을 수 없었다)
        val root = FrameLayout(ctx)
        root.isSoundEffectsEnabled = false
        root.setOnClickListener { dialog.dismiss() }   // 카드 밖(어두운 곳)을 누르면 닫는다
        root.addView(card, FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (tablet) Gravity.TOP or Gravity.START else Gravity.CENTER
        })
        if (tablet) card.alpha = 0f   // 자리를 잡은 뒤에 버튼에서 펼쳐지며 나타난다 (아래 enter)
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            // 태블릿은 카드가 버튼에서 펼쳐지므로 창 전체가 가운데에서 커지는 기본 등장 모션을 끄고, 닫을 때만 줄어든다
            if (tablet) setWindowAnimations(R.style.Evergreen_MenuPopupAnim)
            // 글자를 입력할 때 키보드가 입력칸을 가리지 않게
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        // ── 카드 폭 · 자리 ──
        var curW = width        // 카드의 지금 폭 (애니메이션 중에는 중간 값)
        var targetW = width     // 카드가 가려는 폭
        var wAnim: ValueAnimator? = null
        // 태블릿: 버튼 자리 (이 창 안 좌표)
        var located = false
        var aL = 0
        var aR = 0
        var topEdge = 0
        var baseH = 0   // 창이 가장 컸을 때의 높이 (키보드가 올라와 창이 줄어도 내용을 덩달아 줄이지 않는다)
        fun locate() {
            val rw = root.width
            val rh = root.height
            if (rw <= 0 || rh <= 0) return
            if (rh > baseH) baseH = rh
            maxW = (rw * 0.94f).toInt()
            if (!tablet) { maxBody = (baseH * 0.86f).toInt() - dp(ctx, 64); return }
            val rl = IntArray(2)
            root.getLocationOnScreen(rl)
            val pad = dp(ctx, 8)
            // 화면 좌표끼리 빼서 창 안 좌표를 얻는다 (분할·떠 있는 창에서도 어긋나지 않는다)
            val a = anchor?.takeIf { it.isAttachedToWindow && it.isShown && it.width > 0 && it.height > 0 }
            var aB: Int
            if (a != null) {
                val al = IntArray(2)
                a.getLocationOnScreen(al)
                aL = al[0] - rl[0]
                aR = aL + a.width
                aB = al[1] - rl[1] + a.height
                located = true
            } else if (!located) {
                // 눌린 버튼을 모르면 상단바 메뉴 버튼 아래, 그것도 없으면 오른쪽 위
                val inf = (activityOf(ctx) as? MainActivity)?.listAnchorInfo()
                if (inf != null) { aR = inf[2] - rl[0]; aL = aR; aB = inf[3] - rl[1] }
                else { aR = rw - pad; aL = aR; aB = dp(ctx, 52) }
                located = true
            } else aB = topEdge - dp(ctx, 4)
            topEdge = (aB + dp(ctx, 4)).coerceIn(pad, maxOf(pad, baseH - dp(ctx, 220)))
            // 카드 아래가 화면 밖으로 나가지 않게 남는 높이에 맞춘다
            maxBody = (baseH - topEdge - dp(ctx, 16) - dp(ctx, 64)).coerceAtLeast(minBody)
        }
        /** 카드 폭과 (태블릿은) 자리를 한 번에 반영. 바뀐 게 없으면 아무것도 하지 않는다 */
        fun setLp(w: Int) {
            val lp = card.layoutParams as FrameLayout.LayoutParams
            var changed = false
            if (lp.width != w) { lp.width = w; changed = true }
            if (tablet) {
                val rw = root.width
                if (rw > 0) {
                    val pad = dp(ctx, 8)
                    // 버튼이 화면 오른쪽 절반에 있으면 버튼의 오른쪽 끝에, 아니면 왼쪽 끝에 맞춘다
                    val left = (if ((aL + aR) / 2 > rw / 2) aR - w else aL).coerceIn(pad, maxOf(pad, rw - w - pad))
                    if (lp.leftMargin != left || lp.topMargin != topEdge) {
                        lp.leftMargin = left
                        lp.topMargin = topEdge
                        changed = true
                    }
                }
            }
            if (changed) card.layoutParams = lp
        }
        fun applyCardW(target: Int) {
            if (kotlin.math.abs(target - targetW) <= dp(ctx, 2)) return
            targetW = target
            wAnim?.cancel()
            wAnim = ValueAnimator.ofInt(curW, target).apply {
                duration = 180
                addUpdateListener {
                    curW = it.animatedValue as Int
                    setLp(curW)
                }
                start()
            }
        }
        var entered = false
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            locate()
            setLp(curW)
            if (tablet && !entered && root.width > 0) {
                entered = true
                root.post {
                    if (!Motion.enabled(ctx)) { card.alpha = 1f; return@post }
                    val lp = card.layoutParams as FrameLayout.LayoutParams
                    Popup.prepareAnchoredEnter(card, (aL + aR) / 2f - lp.leftMargin, curW)
                    Popup.playAnchoredEnter(card)
                }
            }
        }

        // 내용 높이에 맞춰 팝업 높이를 늘이고 줄인다 (크롬의 팝업처럼)
        val ui = Handler(Looper.getMainLooper())
        var closed = false
        var curH = dp(ctx, 200)
        var anim: ValueAnimator? = null
        var shrinkVotes = 0   // 줄이는 쪽은 같은 결과가 연달아 나올 때만 받아들인다 (늘었다 줄었다 하며 흔들리거나 아래가 잘리는 것을 막는다)
        fun resizeTo(target: Int) {
            val t = target.coerceIn(minBody, maxOf(minBody, maxBody))
            if (kotlin.math.abs(t - curH) < dp(ctx, 6)) { shrinkVotes = 0; return }
            if (t < curH) { if (++shrinkVotes < 3) return } else shrinkVotes = 0
            shrinkVotes = 0
            anim?.cancel()
            anim = ValueAnimator.ofInt(curH, t).apply {
                duration = 180
                addUpdateListener {
                    curH = it.animatedValue as Int
                    body.layoutParams = body.layoutParams.apply { height = curH }
                    body.requestLayout()
                }
                start()
            }
        }
        // 가로·세로 스크롤이 생기지 않게 크기를 맞춘다.
        //  1) 카드 폭은 내용 폭에 맞춘다: 내용이 360dp 보다 넓으면 (화면 폭의 94% 까지) 넓히고, 폭이 정해진 좁은 페이지면 그 폭으로 줄인다
        //     (예전에는 폭을 재는 값이 보이는 영역보다 작게 나오지 않아 360dp 밑으로 줄지 못하고 오른쪽이 비었다)
        //  2) 그래도 화면보다 크면 내용을 통째로 줄여서(최소 55%) 한 화면에 다 들어오게 한다 → 스크롤 대신 축소
        var natW = width      // 내용이 원래 차지하는 폭(px)
        var wVotes = 0        // 폭을 줄일 때는 줄인 결과가 연달아 나올 때만 받아들인다 (처음 한 번은 바로)
        var wDone = false
        var loaded = false    // 페이지가 다 불러와졌다 (그 전에는 스타일이 덜 붙어 폭이 틀리게 잴 수 있어 줄이지 않는다)
        var fitScale = 1f
        fun fitTo(nw: Int, nh: Int) {
            val minW = minOf(dp(ctx, 200), maxW)
            if (nw > natW + dp(ctx, 2)) {
                natW = nw; wVotes = 0
                if (loaded) wDone = true
            } else if (loaded) {
                if (kotlin.math.abs(nw - natW) <= dp(ctx, 2)) wVotes = 0
                else if (!wDone || ++wVotes >= 3) { natW = nw; wVotes = 0 }
                wDone = true
            }
            val wantW = natW.coerceAtLeast(minW)
            val sW = if (wantW > maxW) maxW.toFloat() / wantW else 1f
            val sH = if (nh > maxBody) maxBody.toFloat() / nh else 1f
            val raw = minOf(sW, sH).coerceAtLeast(0.55f)
            val scaled = raw < 0.995f
            val sc = if (scaled) raw else 1f
            val lp = wv.layoutParams as FrameLayout.LayoutParams
            val newW = if (scaled) wantW else ViewGroup.LayoutParams.MATCH_PARENT
            val newH = if (scaled) nh else ViewGroup.LayoutParams.MATCH_PARENT
            if (lp.width != newW || lp.height != newH || kotlin.math.abs(fitScale - sc) > 0.005f) {
                lp.width = newW; lp.height = newH
                wv.layoutParams = lp
                wv.pivotX = 0f; wv.pivotY = 0f
                wv.scaleX = sc; wv.scaleY = sc
                fitScale = sc
            }
            val cardW = (if (scaled) wantW * sc else minOf(wantW, maxW).toFloat()).toInt()
                .coerceIn(minW, maxW)
            applyCardW(cardW)
            resizeTo(if (scaled) (nh * sc).toInt() else nh)
        }
        lateinit var poll: Runnable
        poll = Runnable {
            if (closed) return@Runnable
            // 내용 크기: 문서가 보이는 영역보다 길면 그 길이, 아니면 안쪽 요소들의 맨 아래 (그래야 내용이 줄 때 같이 줄어든다)
            // 내용 폭: 가로로 넘치면 넘치는 폭, 아니면 문서(html · body) 자신의 폭 (scrollWidth 는 보이는 폭보다 작게 나오지 않는다)
            wv.evaluateJavascript(
                "(function(){var d=document.documentElement,b=document.body;if(!d||!b)return '0,0';" +
                    // 안쪽 요소까지 전부 훑어 가장 아래 끝(마진 포함)을 잰다. 창 높이에 따라 값이 달라지지 않게 한 가지 방법만 쓴다
                    "var sx=window.pageXOffset||0,sy=window.pageYOffset||0,m=0,k=b.getElementsByTagName('*'),n=Math.min(k.length,3000);" +
                    "for(var i=0;i<n;i++){var e=k[i],r=e.getBoundingClientRect();if(r.height<=0||r.width<=0)continue;" +
                    "var cs=getComputedStyle(e);if(cs.display==='none'||cs.visibility==='hidden')continue;" +
                    "var bt=r.bottom+sy+(parseFloat(cs.marginBottom)||0);if(bt>m)m=bt}" +
                    "var bs=getComputedStyle(b),h=m>0?Math.ceil(m+(parseFloat(bs.marginBottom)||0)+(parseFloat(bs.paddingBottom)||0)):b.scrollHeight;" +
                    "var sw=Math.max(d.scrollWidth,b.scrollWidth),cw=d.clientWidth;" +
                    "var br=b.getBoundingClientRect(),dr=d.getBoundingClientRect();" +
                    "var box=Math.min(Math.ceil(br.right+sx+(parseFloat(bs.marginRight)||0)),Math.ceil(dr.right+sx));" +
                    "return (sw>cw?sw:box)+','+h})()"
            ) { r ->
                val parts = r?.trim('"')?.split(',')
                val cssW = parts?.getOrNull(0)?.toDoubleOrNull() ?: 0.0
                val cssPx = parts?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
                val den = ctx.resources.displayMetrics.density
                if (!closed && cssPx > 0 && cssW > 0) fitTo(Math.ceil(cssW * den).toInt(), Math.ceil(cssPx * den).toInt())
            }
            ui.postDelayed(poll, 350)
        }
        // 새로 불러오기가 끝나면 로딩 막대를 걷는다
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView?, p: Int) {
                if (p >= 100) { bar.visibility = View.GONE; loaded = true }
            }

            // 팝업 안의 스크립트 오류를 진단 기록에 남긴다
            override fun onConsoleMessage(m: android.webkit.ConsoleMessage): Boolean {
                if (m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) {
                    mgr.diagLog(e.id, "팝업 콘솔: " + m.message().take(240) + " (" + m.sourceId().substringAfterLast('/').take(40) + ":" + m.lineNumber() + ")")
                }
                return true
            }

            override fun onCloseWindow(window: WebView?) { dialog.dismiss() }

            // 팝업 안에서 띄운 새 창(window.open)은 새 탭으로 연다
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                val t = view?.hitTestResult?.extra
                if (t != null && (t.startsWith("http://") || t.startsWith("https://"))) { dialog.dismiss(); onOpenTab(t); return false }
                return false
            }
        }
        mgr.popupClosers[e.id] = { dialog.dismiss() }
        dialog.setOnDismissListener {
            closed = true
            if (mgr.popupClosers[e.id] != null) mgr.popupClosers.remove(e.id)
            ui.removeCallbacksAndMessages(null)
            anim?.cancel()
            wAnim?.cancel()
            mgr.releasePopupView(wv)
        }
        card.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        mgr.diagLog(e.id, "팝업 열기: $page")
        wv.loadUrl(url)
        ui.postDelayed(poll, 250)
        // 진행률이 100 을 못 알려 주는 페이지도 1.5초 뒤에는 다 불러온 것으로 본다
        ui.postDelayed({ loaded = true }, 1500)
        return dialog
    }

    /**
     * 확장 프로그램의 사이드 패널(side_panel)을 띄운다.
     * 폰: 화면 아래에서 올라오는 시트 (높이 화면의 82%), 태블릿(폭 600dp 이상): 오른쪽 옆 패널 (폭 400dp).
     */
    fun showSidePanel(
        ctx: Context,
        mgr: ExtensionManager,
        e: ExtensionManager.Ext,
        onOpenTab: (String) -> Unit
    ): Dialog? {
        val page = mgr.sidePanelOf(e) ?: return null
        mgr.popupClosers[e.id]?.invoke()
        val url = mgr.pageUrl(e, page)
        val onSurface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = ThemeColors.get(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val surface = ThemeColors.get(ctx, com.google.android.material.R.attr.colorSurface, Color.WHITE)
        val primary = ThemeColors.get(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())

        val dialog = Dialog(ctx, R.style.Evergreen_Popup)
        Popup.trackDialog(dialog)
        val (vw, vh) = viewport(ctx)
        val tablet = vw >= dp(ctx, 600)
        val r = dp(ctx, 26).toFloat()

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(surface)
                if (tablet) cornerRadius = r else cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }

        // 폰: 위쪽 손잡이 막대
        if (!tablet) {
            card.addView(View(ctx).apply {
                background = GradientDrawable().apply { setColor(onVar and 0x00FFFFFF or 0x55000000); cornerRadius = dp(ctx, 2).toFloat() }
                layoutParams = LinearLayout.LayoutParams(dp(ctx, 36), dp(ctx, 4)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(ctx, 8) }
            })
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 8), dp(ctx, 6))
        }
        header.addView(ImageView(ctx).apply {
            val bmp = mgr.iconBitmap(e)
            if (bmp != null) setImageBitmap(bmp)
            else {
                setImageResource(R.drawable.ic_extension)
                imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 26), dp(ctx, 26)).apply { marginEnd = dp(ctx, 10) }
        })
        header.addView(TextView(ctx).apply {
            text = e.name
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(onSurface)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        fun iconBtn(res: Int, desc: String, click: () -> Unit) = ImageButton(ctx).apply {
            setImageResource(res)
            imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            contentDescription = desc
            val tv = android.util.TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            val p = dp(ctx, 10)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 40), dp(ctx, 40))
            setOnClickListener { click() }
        }
        header.addView(iconBtn(R.drawable.ic_open_tab, "탭에서 열기") { dialog.dismiss(); onOpenTab(url) })
        header.addView(iconBtn(R.drawable.ic_close, "닫기") { dialog.dismiss() })
        card.addView(header)

        val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(primary)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 2))
        }
        card.addView(bar)

        val wv: WebView = mgr.newPopupView { link -> dialog.dismiss(); onOpenTab(link) }
        wv.setBackgroundColor(surface)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        // 팝업과 같은 구조(FrameLayout 안에 웹뷰)로 담는다: 웹뷰를 LinearLayout 에 바로 넣으면 일부 기기에서 내용이 그려지지 않는다
        val body = FrameLayout(ctx)
        body.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val cardH = if (tablet) vh - dp(ctx, 24) else (vh * 0.82f).toInt()
        val cardW = if (tablet) minOf(dp(ctx, 400), (vw * 0.5f).toInt()) else ViewGroup.LayoutParams.MATCH_PARENT
        val root = FrameLayout(ctx).apply {
            if (tablet) setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12))
            addView(card, FrameLayout.LayoutParams(
                if (tablet) cardW else ViewGroup.LayoutParams.MATCH_PARENT,
                if (tablet) ViewGroup.LayoutParams.MATCH_PARENT else cardH
            ).apply { gravity = if (tablet) Gravity.END else Gravity.BOTTOM })
        }
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.apply {
            if (tablet) {
                setLayout(cardW + dp(ctx, 24), ViewGroup.LayoutParams.MATCH_PARENT)
                setGravity(Gravity.END or Gravity.CENTER_VERTICAL)
            } else {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, cardH)
                setGravity(Gravity.BOTTOM)
            }
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView?, p: Int) {
                if (p >= 100) bar.visibility = View.GONE
            }

            override fun onConsoleMessage(m: android.webkit.ConsoleMessage): Boolean {
                if (m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) {
                    mgr.diagLog(e.id, "사이드 패널 콘솔: " + m.message().take(240) + " (" + m.sourceId().substringAfterLast('/').take(40) + ":" + m.lineNumber() + ")")
                }
                return true
            }

            override fun onCloseWindow(window: WebView?) { dialog.dismiss() }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                val t = view?.hitTestResult?.extra
                if (t != null && (t.startsWith("http://") || t.startsWith("https://"))) { dialog.dismiss(); onOpenTab(t); return false }
                return false
            }
        }
        mgr.popupClosers[e.id] = { dialog.dismiss() }
        dialog.setOnDismissListener {
            if (mgr.popupClosers[e.id] != null) mgr.popupClosers.remove(e.id)
            mgr.releasePopupView(wv)
        }

        // 폰은 아래에서 올라오고, 태블릿은 오른쪽에서 밀려 들어온다
        card.post {
            if (tablet) { card.translationX = card.width.toFloat() } else { card.translationY = cardH.toFloat() }
            card.animate().translationX(0f).translationY(0f).setDuration(260)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        }
        // 애니메이션이 끝나지 않거나 취소돼도 패널이 화면 밖에 남지 않게, 끝난 뒤 제자리로 고정하고 웹뷰를 다시 그린다
        card.postDelayed({
            card.animate().cancel()
            card.translationX = 0f; card.translationY = 0f
            wv.invalidate()
        }, 600)
        card.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        mgr.diagLog(e.id, "사이드 패널 열기: $page")
        wv.loadUrl(url)
        return dialog
    }
}
