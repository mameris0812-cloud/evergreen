package com.example.evergreen

import android.app.DownloadManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 가져올 북마크 한 개 (파일에서 읽은 것). [folder] 가 비어 있으면 폴더 없이 맨 위에 넣는다 */
data class ParsedBookmark(val title: String, val url: String, val folder: String)

/**
 * 북마크 내보내기 · 가져오기.
 * 파일은 크롬 · 엣지 · 파이어폭스 · 사파리가 모두 쓰는 「북마크 HTML」(Netscape Bookmark File) 형식이라 다른 브라우저와 주고받을 수 있다.
 * 내보낸 파일은 받은 파일(다운로드) 폴더에 저장되고, 가져오기는 받은 파일 목록(AgentDownloads)에 있는 파일만 읽는다.
 * 폴더는 한 단계만 쓰는 앱이라, 안쪽 폴더는 가장 가까운 폴더 이름으로 펴서 가져온다.
 */
object BookmarkPorter {
    /** 한 번에 가져올 수 있는 북마크 수 (넘으면 앞에서부터) */
    const val MAX_IMPORT = 1000

    /** 읽을 파일의 최대 크기 */
    const val MAX_BYTES = 10L * 1024 * 1024

    private val KEY = Regex("[md]:\\d+")

    // ───────────────────────── 내보내기 ─────────────────────────

    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** 북마크를 북마크 HTML 로 만든다. 폴더 없는 북마크는 맨 위, 폴더가 있는 것은 폴더 아래에 둔다 */
    fun toHtml(bookmarks: List<Bookmark>, folders: List<Folder>, now: Long = System.currentTimeMillis()): String {
        val sec = now / 1000
        val sb = StringBuilder()
        sb.append("<!DOCTYPE NETSCAPE-Bookmark-file-1>\n")
        sb.append("<!-- This is an automatically generated file. It will be read and overwritten. DO NOT EDIT! -->\n")
        sb.append("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n")
        sb.append("<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n")
        fun item(b: Bookmark, indent: String) {
            sb.append(indent).append("<DT><A HREF=\"").append(esc(b.url)).append("\" ADD_DATE=\"").append(sec).append("\">")
                .append(esc(b.title.ifBlank { b.url })).append("</A>\n")
        }
        val known = folders.map { it.id }.toSet()
        for (f in folders) {
            val inside = bookmarks.filter { it.folderId == f.id }
            if (inside.isEmpty()) continue
            sb.append("    <DT><H3 ADD_DATE=\"").append(sec).append("\">").append(esc(f.name)).append("</H3>\n    <DL><p>\n")
            inside.forEach { item(it, "        ") }
            sb.append("    </DL><p>\n")
        }
        // 폴더 없는 북마크 (폴더가 지워졌는데 남은 것도 맨 위로)
        bookmarks.filter { it.folderId == 0L || it.folderId !in known }.forEach { item(it, "    ") }
        sb.append("</DL><p>\n")
        return sb.toString()
    }

    /** [html] 을 받은 파일 폴더에 저장하고, 저장한 파일 이름을 돌려준다 (못 하면 null 과 이유) */
    fun saveToDownloads(ctx: Context, html: String): Pair<String?, String> {
        val name = "evergreen_bookmarks_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".html"
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/html")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: return null to "파일을 만들지 못했어요"
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(html.toByteArray(Charsets.UTF_8)) }
                    ?: return null to "파일에 쓰지 못했어요"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists() && !dir.mkdirs()) return null to "다운로드 폴더를 만들지 못했어요"
                File(dir, name).writeText(html, Charsets.UTF_8)
            }
            name to ""
        } catch (e: SecurityException) {
            null to "저장 권한이 없어서 파일을 만들지 못했어요"
        } catch (e: Exception) {
            null to "파일을 저장하지 못했어요"
        }
    }

    // ───────────────────────── 가져오기 ─────────────────────────

    class Loaded(val items: List<ParsedBookmark>, val error: String?, val truncated: Boolean = false)

    /** 받은 파일 [key] (list_downloads 의 id) 를 읽어 북마크 목록으로 바꾼다. 받은 파일 목록에 없는 키는 읽지 않는다 */
    fun load(ctx: Context, key: String): Loaded {
        val k = key.trim()
        if (!KEY.matches(k)) return Loaded(emptyList(), "id 가 올바르지 않아요 (list_downloads 가 돌려준 id 를 그대로 주세요)")
        val file = AgentDownloads.list(ctx).firstOrNull { it.key == k }
            ?: return Loaded(emptyList(), "그 파일을 받은 파일 목록에서 찾지 못했어요 (list_downloads 로 다시 확인해 주세요)")
        if (file.size > MAX_BYTES) return Loaded(emptyList(), "파일이 너무 커요 (10MB 까지)")
        val text = try {
            readText(ctx, k)
        } catch (e: Exception) {
            null
        } ?: return Loaded(emptyList(), "파일을 읽지 못했어요")
        val all = parse(text)
        if (all.isEmpty()) return Loaded(emptyList(), "북마크를 찾지 못했어요. 크롬 · 엣지 · 파이어폭스에서 내보낸 북마크 HTML 파일이 맞는지 확인해 주세요")
        return Loaded(all.take(MAX_IMPORT), null, all.size > MAX_IMPORT)
    }

    private fun readText(ctx: Context, key: String): String? {
        val id = key.substring(2).toLong()
        val stream = if (key.startsWith("m:")) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
            ctx.contentResolver.openInputStream(ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id))
        } else {
            val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            android.os.ParcelFileDescriptor.AutoCloseInputStream(dm.openDownloadedFile(id))
        } ?: return null
        stream.use { s ->
            val buf = java.io.ByteArrayOutputStream()
            val chunk = ByteArray(16 * 1024)
            while (true) {
                val n = s.read(chunk)
                if (n < 0) break
                buf.write(chunk, 0, n)
                if (buf.size() > MAX_BYTES) return null
            }
            return buf.toString("UTF-8")
        }
    }

    private val TOKEN = Regex(
        "<h3\\b[^>]*>(.*?)</h3\\s*>|<a\\b([^>]*)>(.*?)</a\\s*>|</?dl\\b[^>]*>",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val HREF = Regex("\\bhref\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE)
    private val TAGS = Regex("<[^>]+>")
    private val ENTITY = Regex("&(#x[0-9a-fA-F]+|#\\d+|amp|lt|gt|quot|apos|nbsp);")

    private fun decode(s: String): String = ENTITY.replace(s) { m ->
        when (val e = m.groupValues[1]) {
            "amp" -> "&"
            "lt" -> "<"
            "gt" -> ">"
            "quot" -> "\""
            "apos" -> "'"
            "nbsp" -> " "
            else -> {
                val code = if (e.startsWith("#x")) e.substring(2).toIntOrNull(16) else e.substring(1).toIntOrNull()
                if (code != null && code in 1..0x10FFFF) String(Character.toChars(code)) else m.value
            }
        }
    }

    private fun clean(s: String, max: Int): String =
        decode(TAGS.replace(s, "")).replace(Regex("\\s+"), " ").trim().take(max)

    /** 북마크 HTML 을 읽어 http(s) 북마크만 순서대로 돌려준다. 같은 주소는 한 번만 */
    fun parse(html: String): List<ParsedBookmark> {
        val out = ArrayList<ParsedBookmark>()
        val seen = HashSet<String>()
        val stack = ArrayList<String>()
        var pending: String? = null
        for (m in TOKEN.findAll(html)) {
            val v = m.value
            when {
                v.startsWith("<h3", ignoreCase = true) -> pending = clean(m.groupValues[1], 30)
                v.startsWith("</dl", ignoreCase = true) -> if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
                v.startsWith("<dl", ignoreCase = true) -> {
                    stack.add(pending ?: "")
                    pending = null
                }
                else -> {
                    val href = HREF.find(m.groupValues[2])?.let { it.groupValues[1].ifEmpty { it.groupValues[2] } }
                        ?.let { decode(it).trim() } ?: continue
                    if (!(href.startsWith("http://", true) || href.startsWith("https://", true)) || href.length > 2000) continue
                    if (!seen.add(href.trimEnd('/'))) continue
                    val title = clean(m.groupValues[3], 200).ifEmpty { href }
                    // 가장 가까운 이름 있는 폴더. 맨 바깥(루트) 목록의 북마크는 폴더 없이
                    val folder = stack.drop(1).lastOrNull { it.isNotEmpty() }.orEmpty()
                    out.add(ParsedBookmark(title, href, folder))
                }
            }
        }
        return out
    }
}
