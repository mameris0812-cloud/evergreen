package com.example.evergreen

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import androidx.core.graphics.ColorUtils

/**
 * 크롬 테마의 새 탭 배경(theme_ntp_background): 바탕색 위에 그림을 깐다.
 * ntp_background_alignment(left/right/top/bottom/center 조합)와 ntp_background_repeating(no-repeat/repeat/repeat-x/repeat-y)을 따른다.
 * no-repeat 는 화면을 덮도록 키워서(cover) 정렬 쪽을 기준으로 맞추고, 반복 모양은 그림을 화면 밀도에 맞춰 타일로 깐다.
 */
class ThemeHomeBgDrawable(
    private val bm: Bitmap?, private val color: Int,
    align: String, private val repeat: String, private val density: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fx: Float
    private val fy: Float
    init {
        val a = align.lowercase()
        fx = when { a.contains("left") -> 0f; a.contains("right") -> 1f; else -> 0.5f }
        fy = when { a.contains("top") -> 0f; a.contains("bottom") -> 1f; else -> 0.5f }
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        paint.shader = null
        paint.color = color
        canvas.drawRect(b, paint)
        val bmp = bm ?: return
        if (bmp.isRecycled || b.width() <= 0 || b.height() <= 0) return
        val w = b.width().toFloat(); val h = b.height().toFloat()
        val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat()
        val m = Matrix()
        if (repeat == "no-repeat") {
            val s = maxOf(w / bw, h / bh)
            val ox = (w - bw * s) * fx
            val oy = (h - bh * s) * fy
            m.postScale(s, s); m.postTranslate(b.left + ox, b.top + oy)
            val sh = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            sh.setLocalMatrix(m)
            paint.shader = sh
            canvas.drawRect(b, paint)
        } else {
            val s = density
            val iw = bw * s; val ih = bh * s
            val ox = (w - iw) * fx
            val oy = (h - ih) * fy
            val rx = repeat == "repeat" || repeat == "repeat-x"
            val ry = repeat == "repeat" || repeat == "repeat-y"
            m.postScale(s, s); m.postTranslate(b.left + ox, b.top + oy)
            val sh = BitmapShader(bmp, if (rx) Shader.TileMode.REPEAT else Shader.TileMode.CLAMP, if (ry) Shader.TileMode.REPEAT else Shader.TileMode.CLAMP)
            sh.setLocalMatrix(m)
            paint.shader = sh
            // 반복하지 않는 방향은 그림 크기만큼만 그린다 (CLAMP 가 가장자리를 늘려 번지지 않게)
            val r = RectF(
                if (rx) b.left.toFloat() else b.left + ox, if (ry) b.top.toFloat() else b.top + oy,
                if (rx) b.right.toFloat() else b.left + ox + iw, if (ry) b.bottom.toFloat() else b.top + oy + ih
            )
            r.intersect(RectF(b))
            canvas.drawRect(r, paint)
        }
        paint.shader = null
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/**
 * 탭 배경 그림(theme_tab_background)이 탭 모양을 직접 담고 있는지 (모서리·옆면이 투명하게 비어 있는지).
 * 담고 있으면 그 모양 그대로 그리고, 꽉 찬 사각 그림이면 옛 크롬 테마처럼 비스듬한 사다리꼴 탭으로 자른다.
 */
fun tabImageHasShape(bm: Bitmap?): Boolean {
    bm ?: return false
    if (bm.isRecycled || !bm.hasAlpha() || bm.width < 2 || bm.height < 2) return false
    val w = bm.width; val h = bm.height
    var total = 0; var clear = 0
    val sx = maxOf(1, w / 48); val sy = maxOf(1, h / 24)
    var y = 0
    while (y < h) {
        var x = 0
        while (x < w) { total++; if (android.graphics.Color.alpha(bm.getPixel(x, y)) < 128) clear++; x += sx }
        y += sy
    }
    return total > 0 && clear.toFloat() / total > 0.03f
}

/** 가로로 반복하는 테마 그림 셰이더. 시작 자리가 바뀔 때만 행렬을 다시 계산해, 그릴 때마다 셰이더·행렬을 새로 만들지 않는다 */
private class TileShader(private val bm: Bitmap, private val density: Float, private val repeatY: Boolean = false) {
    private var sh: BitmapShader? = null
    private var lx = Float.NaN
    private var ly = Float.NaN
    private val m = Matrix()
    fun get(ox: Float, oy: Float): BitmapShader {
        val s = sh ?: BitmapShader(bm, Shader.TileMode.REPEAT, if (repeatY) Shader.TileMode.REPEAT else Shader.TileMode.CLAMP).also { sh = it }
        if (ox != lx || oy != ly) {
            m.reset(); m.postScale(density, density); m.postTranslate(ox, oy)
            s.setLocalMatrix(m)
            lx = ox; ly = oy
        }
        return s
    }
}

/**
 * 크롬 옛 탭 모양(비스듬한 사다리꼴) 윤곽을 [p] 에 이어 붙인다: 왼쪽 아래 → 비스듬히 올라가 윗모서리 → 오른쪽 아래 (닫지는 않는다).
 * 옆면은 곧은 비탈이고 윗모서리 두 곳만 둥글다.
 */
internal fun addSlantedTab(p: android.graphics.Path, l: Float, r: Float, t: Float, bt: Float, slant: Float, radius: Float) {
    val s = minOf(slant, (r - l) / 4f)
    val h = bt - t
    val len = Math.hypot(s.toDouble(), h.toDouble()).toFloat().coerceAtLeast(1f)
    val rad = minOf(radius, len / 2f, (r - l - 2f * s) / 2f).coerceAtLeast(0f)
    val ux = s / len; val uy = -h / len   // 왼쪽 비탈 방향 (아래 → 위)
    p.moveTo(l, bt)
    p.lineTo(l + s - ux * rad, t - uy * rad)
    p.quadTo(l + s, t, l + s + rad, t)
    p.lineTo(r - s - rad, t)
    p.quadTo(r - s, t, r - s + ux * rad, t - uy * rad)
    p.lineTo(r, bt)
}

/**
 * 크롬 테마가 바꾼 탭 모양: 선택 안 된 탭은 theme_tab_background 그림, 선택된 탭은 theme_toolbar 그림(없으면 기본 면 색)으로 채운다.
 * 윗면이 둥근 탭 모양으로 잘라 그리고, [setAlpha] 는 선택된 탭 쪽의 짙기(선택/해제 전환)에만 쓴다.
 */
class ThemeTabDrawable(
    private val shape: Drawable, private val selBm: Bitmap?, private val inactBm: Bitmap?,
    private val radius: Float, private val density: Float,
    /** 그림이 시작하는 자리(이 드로어블의 왼쪽 위 기준 px)를 [0]=x, [1]=y 에 채워 준다. 없으면 이 탭의 왼쪽 위.
     *  선택된 탭은 툴바와, 선택 안 된 탭은 탭바와 같은 자리에서 그림이 시작해야 줄이 끊겨 보이지 않는다 */
    private val selOrigin: ((FloatArray) -> Unit)? = null,
    private val inactOrigin: ((FloatArray) -> Unit)? = null,
    /** 0 보다 크면 크롬 옛 모양처럼 아래는 넓고 윗면은 이만큼(px) 좁아지는 비스듬한 사다리꼴 탭으로 자른다 */
    private val slant: Float = 0f,
    /** 선택 안 된 탭의 바탕색 (테마의 background_tab). 그림이 있으면 그 밑에 깔린다 */
    private val inactColor: Int? = null,
    /** 선택된 탭 둘레(아래는 제외)에 그리는 얇은 윤곽선. 탭바와 탭 색이 비슷한 테마에서 선택된 탭이 구분되게 한다 (크롬도 이때 윤곽선을 그린다) */
    private val stroke: Int? = null,
    private val strokeW: Float = 0f,
    /** true 면 탭처럼 아래로 퍼지지 않고, 모든 모서리가 둥근 납작한 역사다리꼴(위가 넓다)로 자른다 (새 탭 + 버튼용) */
    private val floating: Boolean = false,
    /** true 면 선택 안 된 탭은 앱이 모양을 자르지 않고 테마 그림(theme_tab_background)이 정한 모양(투명한 부분) 그대로 그린다 */
    private val imageShape: Boolean = false,
    /** 0 보다 크면 크롬 요즘 탭 모양: 윗모서리는 둥글고 아래 양끝(이만큼 px)은 오목하게 퍼져 툴바와 이어진다. 선택 안 된 탭은 바탕 없이 오른쪽 구분선만 그린다 */
    private val flare: Float = 0f,
    private val divider: Int? = null,
    /** true 면(flare 와 함께) 선택 안 된 탭을 [inactColor] 색의 둥근 알약으로 그린다 (구분선은 그리지 않는다) */
    private val pill: Boolean = false,
    /** true 면 모든 모서리가 둥근 알약 모양 탭 (삼성 테마). 위아래를 조금 띄우고, 선택 안 된 탭은 바탕 없이 오른쪽에 얇은 구분선만 */
    private val roundAll: Boolean = false
) : Drawable() {
    /** 오른쪽 이웃이 선택된 탭이면 구분선을 지운다 (1 = 그대로, 0 = 완전히 숨김). 크롬처럼 활성 탭 옆에는 선을 긋지 않는다 */
    var dividerFade: Float = 1f
        set(v) { val n = v.coerceIn(0f, 1f); if (n != field) { field = n; invalidateSelf() } }
    private val outline = android.graphics.Path()
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val selShader = selBm?.let { TileShader(it, density) }
    private val inactShader = inactBm?.let { TileShader(it, density) }
    private val org = FloatArray(2)
    private var selAlpha = 255
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val clip = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        shape.bounds = b
        clip.reset()
        outline.reset()
        if (roundAll) {
            clip.addRoundRect(RectF(b.left.toFloat(), b.top + 4f * density, b.right.toFloat(), b.bottom - 1f * density), radius, radius, android.graphics.Path.Direction.CW)
            return
        }
        if (floating) {
            val l = b.left.toFloat(); val r = b.right.toFloat(); val t = b.top.toFloat(); val bt = b.bottom.toFloat()
            if (slant <= 0f) {
                // 기울기가 없으면(탭 그림이 없는 테마) 탭 칩처럼 둥근 모양 그대로 — 사다리꼴로 만들지 않는다
                clip.addRoundRect(RectF(l, t, r, bt), radius, radius, android.graphics.Path.Direction.CW)
                return
            }
            val s = minOf(slant, (r - l) / 4f)
            val poly = android.graphics.Path().apply {
                moveTo(l + s, bt); lineTo(l, t); lineTo(r, t); lineTo(r - s, bt); close()   // 역사다리꼴 (위가 넓다)
            }
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { pathEffect = android.graphics.CornerPathEffect(radius) }
            p.getFillPath(poly, clip)
            return
        }
        if (flare > 0f) {
            val l = b.left.toFloat(); val r = b.right.toFloat(); val t = b.top.toFloat(); val bt = b.bottom.toFloat()
            val f = minOf(flare, (r - l) / 4f, (bt - t) / 2f)
            val rad = minOf(radius, (bt - t) / 2f - f / 2f).coerceAtLeast(0f)
            clip.moveTo(l, bt)
            clip.quadTo(l + f, bt, l + f, bt - f)
            clip.lineTo(l + f, t + rad)
            clip.quadTo(l + f, t, l + f + rad, t)
            clip.lineTo(r - f - rad, t)
            clip.quadTo(r - f, t, r - f, t + rad)
            clip.lineTo(r - f, bt - f)
            clip.quadTo(r - f, bt, r, bt)
            clip.close()
            return
        }
        if (stroke != null && strokeW > 0f) {
            val h = strokeW / 2f
            val l = b.left + h; val r = b.right - h; val t = b.top + h; val bt = b.bottom.toFloat()
            if (slant <= 0f) {
                val rad = radius
                outline.moveTo(l, bt); outline.lineTo(l, t + rad); outline.quadTo(l, t, l + rad, t)
                outline.lineTo(r - rad, t); outline.quadTo(r, t, r, t + rad); outline.lineTo(r, bt)
            } else {
                addSlantedTab(outline, l, r, t, bt, slant, radius)
            }
        }
        if (slant <= 0f) {
            clip.addRoundRect(RectF(b), floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f), android.graphics.Path.Direction.CW)
            return
        }
        // 크롬 옛 탭 모양: 밑에서 완만하게 올라와 비스듬히 서고, 윗모서리는 둥글다
        val l = b.left.toFloat(); val r = b.right.toFloat(); val t = b.top.toFloat(); val bt = b.bottom.toFloat()
        addSlantedTab(clip, l, r, t, bt, slant, radius)
        clip.close()
    }

    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dstIn = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)

    private fun tile(canvas: Canvas, bm: Bitmap, ts: TileShader?, origin: ((FloatArray) -> Unit)?, p: Paint = paint) {
        ts ?: return
        val b = bounds
        org[0] = 0f; org[1] = 0f
        origin?.invoke(org)
        val ox = b.left + org[0]; val oy = b.top + org[1]
        p.shader = ts.get(ox, oy)
        // 그림이 있는 높이만 그린다 (CLAMP 가 마지막 줄을 늘려 번지지 않게)
        val top = maxOf(b.top.toFloat(), oy)
        val bottom = minOf(b.bottom.toFloat(), oy + bm.height * density)
        if (bottom > top) canvas.drawRect(b.left.toFloat(), top, b.right.toFloat(), bottom, p)
        p.shader = null
    }

    override fun draw(canvas: Canvas) {
        if (bounds.isEmpty) return
        if (flare > 0f && pill) {
            // 선택 안 된 탭: 크롬처럼 둥근 알약 (선택될수록 사라진다). 이웃 탭과 살짝 떨어지고 아래는 탭바 바닥에서 띄운다
            val pa = ((255 - selAlpha) * (inactColor?.let { it ushr 24 } ?: 0) / 255f).toInt()
            if (inactColor != null && pa > 0) {
                val b = bounds
                val f = minOf(flare, b.width() / 4f, b.height() / 2f)
                val gap = 2f * density
                val r = RectF(b.left + f + gap, b.top.toFloat(), b.right - f - gap, b.bottom - 4f * density)
                val rad = minOf(radius, r.height() / 2f)
                paint.shader = null; paint.style = Paint.Style.FILL
                paint.color = androidx.core.graphics.ColorUtils.setAlphaComponent(inactColor, pa)
                canvas.drawRoundRect(r, rad, rad, paint)
            }
        } else if (flare > 0f) {
            // 선택 안 된 탭: 바탕 없이 오른쪽에 짧은 구분선만 (선택될수록 사라진다)
            val da = ((255 - selAlpha) * 0x66 / 255 * dividerFade).toInt()
            if (divider != null && da > 0) {
                val b = bounds
                paint.shader = null; paint.color = androidx.core.graphics.ColorUtils.setAlphaComponent(divider, da)
                val hh = 16f * density
                val cy = (b.top + b.bottom) / 2f
                // 탭끼리 겹쳐 놓여(오른쪽 이웃이 6dp 겹친다) 두 탭 몸통 사이 빈틈의 한가운데가 오른쪽 끝에서 7dp 안쪽이다. 크롬처럼 거기에 긋는다
                val dx = b.right - 7f * density
                canvas.drawRect(dx - density / 2f, cy - hh / 2f, dx + density / 2f, cy + hh / 2f, paint)
            }
        } else if (roundAll) {
            // 선택 안 된 탭: 바탕 없이 오른쪽에 얇은 세로 구분선만 (선택될수록, 오른쪽 이웃이 선택될수록 사라진다)
            val da = ((255 - selAlpha) * 0x55 / 255 * dividerFade).toInt()
            if (divider != null && da > 0) {
                val b = bounds
                paint.shader = null; paint.color = androidx.core.graphics.ColorUtils.setAlphaComponent(divider, da)
                val hh = 18f * density
                val cy = (b.top + b.bottom) / 2f + 1f * density
                canvas.drawRect(b.right - 1.5f * density, cy - hh / 2f, b.right - 0.5f * density, cy + hh / 2f, paint)
            }
        } else if (imageShape && inactBm != null && !inactBm.isRecycled) {
            // 탭 모양은 테마 그림이 정한다 — 앱이 사다리꼴 등으로 자르거나 그 뒤에 색을 깔지 않는다
            tile(canvas, inactBm, inactShader, inactOrigin)
        } else if (selAlpha < 255 && (inactColor != null || (inactBm != null && !inactBm.isRecycled))) {
            // 선택이 다 끝난 탭(selAlpha 255)은 선택된 면이 같은 모양을 완전히 덮으므로 뒤에 선택 안 된 탭 면을 깔지 않는다
            // (깔면 비스듬한 옆면 가장자리에 선택 안 된 탭 색이 가늘게 비쳐 탭 모양이 이중으로 보였다)
            val n = canvas.save(); canvas.clipPath(clip)
            if (inactColor != null) { paint.shader = null; paint.color = inactColor; canvas.drawRect(RectF(bounds), paint) }
            if (inactBm != null && !inactBm.isRecycled) tile(canvas, inactBm, inactShader, inactOrigin)
            canvas.restoreToCount(n)
        }
        if (selAlpha > 0) {
            val n = canvas.saveLayerAlpha(RectF(bounds), selAlpha)
            shape.alpha = 255
            val maskBm = if (imageShape && inactBm != null && !inactBm.isRecycled && inactShader != null) inactBm else null
            if (maskBm != null) {
                // 탭 그림이 모양을 담고 있으면 선택된 면도 그 모양(투명한 부분 제외)으로만 그린다 — 기본 탭(윗면만 둥근 네모)이 뒤에 비쳐 보이지 않게
                val m = canvas.saveLayer(RectF(bounds), null)
                shape.draw(canvas)
                if (selBm != null && !selBm.isRecycled) tile(canvas, selBm, selShader, selOrigin)
                maskPaint.xfermode = dstIn
                tile(canvas, maskBm, inactShader, inactOrigin, maskPaint)
                maskPaint.xfermode = null
                canvas.restoreToCount(m)
            } else {
                val k = canvas.save()
                canvas.clipPath(clip)
                shape.draw(canvas)
                if (selBm != null && !selBm.isRecycled) tile(canvas, selBm, selShader, selOrigin)
                canvas.restoreToCount(k)
            }
            if (stroke != null && strokeW > 0f) {
                strokePaint.color = stroke; strokePaint.strokeWidth = strokeW
                canvas.drawPath(outline, strokePaint)
            }
            canvas.restoreToCount(n)
        }
    }

    override fun setAlpha(alpha: Int) { selAlpha = alpha; invalidateSelf() }
    override fun getAlpha(): Int = selAlpha
    override fun setColorFilter(cf: ColorFilter?) {}
    override fun setTintList(tint: android.content.res.ColorStateList?) { shape.setTintList(tint); invalidateSelf() }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * 새 탭 화면의 버튼·카드 뒤를 흐리게(유리처럼) 보이게 하는 배경.
 * 새 탭 배경 그림을 미리 흐리게 만들어 둔 그림([bmp], 화면의 [scale] 배)에서 이 뷰가 놓인 자리만 잘라 둥근 모양으로 그리고,
 * 그 위에 살짝 색을 덮어 글자가 읽히게 한다. 뷰의 위치는 그릴 때마다 [root] 기준으로 다시 계산한다.
 */
class ThemeGlassDrawable(
    private val bmp: Bitmap, private val scale: Float,
    private val host: android.view.View, private val root: android.view.View,
    private val corner: Float, private val tint: Int, private val line: Int, private val lineW: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shaderM = android.graphics.Matrix()
    private val a = IntArray(2)
    private val b = IntArray(2)

    /** 흐린 그림을 루트(rw x rh) 크기로 늘려 루트의 왼쪽 위가 (ox, oy) 에 오도록 놓는 붓. 크기를 모르면 만들 때의 배율을 쓴다 */
    private fun glassShader(rw: Float, rh: Float, ox: Float, oy: Float): android.graphics.Shader {
        val sx = if (rw > 0f) bmp.width / rw else scale
        val sy = if (rh > 0f) bmp.height / rh else scale
        shaderM.reset()
        shaderM.setScale(1f / sx, 1f / sy)
        shaderM.postTranslate(ox, oy)
        // 그리기 목록에 기록된 뒤 붓을 바꾸면 이전 그림이 같이 바뀔 수 있어, 그릴 때마다 새 붓을 만든다
        return android.graphics.BitmapShader(bmp, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP)
            .also { it.setLocalMatrix(shaderM) }
    }
    private val path = android.graphics.Path()
    private val pos = FloatArray(2)
    private var lastX = Float.NaN
    private var lastY = Float.NaN

    /**
     * 이 뷰가 [root] 안에서 놓인 자리(루트 왼쪽 위 기준). 부모 크기·위치를 타고 올라가며 더하고
     * 루트 자신의 확대·이동(새 탭이 떠오르는 애니메이션)은 넣지 않는다 — 배경 그림도 루트와 같이 움직이므로 상대 자리는 그대로다.
     * 루트의 스크롤은 빼고, 루트 안쪽 뷰의 이동(translation)은 더한다.
     */
    private fun relPos(out: FloatArray) {
        var x = 0f; var y = 0f
        var v: View = host
        var ok = true
        while (v !== root) {
            x += v.left + v.translationX; y += v.top + v.translationY
            val p = v.parent as? View
            if (p == null) { ok = false; break }
            x -= p.scrollX; y -= p.scrollY
            v = p
        }
        if (!ok) {
            host.getLocationInWindow(a); root.getLocationInWindow(b)
            x = (a[0] - b[0]).toFloat(); y = (a[1] - b[1]).toFloat()
        }
        out[0] = x; out[1] = y
    }

    /** 마지막으로 그린 뒤 이 뷰가 배경 위에서 움직였는가 (스크롤·떠오르는 애니메이션·레이아웃 변경). 그렇면 다시 그려야 배경과 맞는다 */
    fun moved(): Boolean {
        if (lastX.isNaN()) return false
        relPos(pos)
        return pos[0] != lastX || pos[1] != lastY
    }

    override fun draw(canvas: Canvas) {
        val bd = bounds
        if (bd.isEmpty) return
        relPos(pos)
        val dx = pos[0]; val dy = pos[1]
        lastX = dx; lastY = dy
        val dst = RectF(bd)
        path.reset(); path.addRoundRect(dst, corner, corner, android.graphics.Path.Direction.CW)
        val n = canvas.save()
        canvas.clipPath(path)
        paint.style = Paint.Style.FILL
        // 흐린 그림은 화면의 1/10 크기라 한 칸이 화면 약 10px 이다. 예전에는 잘라 올 자리를 칸(정수) 단위로 맞춰서
        // 카드가 몇 px 움직이거나 크기가 바뀌면 블러가 한 칸씩 툭 튀고, 늘어나는 비율도 어긋났다.
        // 그림 전체를 실수 좌표로 정확히 겹쳐 그려(부드러운 보간) 카드가 어디에 있든 바로 뒤의 배경과 같은 자리에 오게 한다.
        bgPaint.shader = glassShader(root.width.toFloat(), root.height.toFloat(), bd.left - dx, bd.top - dy)
        canvas.drawRect(dst, bgPaint)
        paint.color = tint
        canvas.drawRect(dst, paint)
        canvas.restoreToCount(n)
        if (lineW > 0f) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = lineW; paint.color = line
            val h = lineW / 2f
            canvas.drawRoundRect(RectF(dst.left + h, dst.top + h, dst.right - h, dst.bottom - h), corner - h, corner - h, paint)
        }
    }

    private val c2 = IntArray(2)
    private val srcR = android.graphics.Rect()
    private val vis = RectF()

    /**
     * 카드 자리가 아니라 [dst](창 좌표) 자리의 흐린 배경을 같은 유리 모양으로 그린다.
     * 카드가 팝업으로 펼쳐질 때(MorphDialog) 커지는 면이 단색이 아니라 이 유리를 이어받게 한다.
     * ([winX],[winY]) = 그리는 창의 왼쪽 위가 화면에서 놓인 자리, [alpha] = 0..255 전체 짙기
     */
    fun paintAt(canvas: Canvas, dst: RectF, winX: Int, winY: Int, radius: Float, alpha: Int) {
        if (alpha <= 0 || dst.width() <= 0f || dst.height() <= 0f) return
        root.getLocationOnScreen(c2)
        val ox = (winX - c2[0]).toFloat(); val oy = (winY - c2[1]).toFloat()
        vis.set(dst.left + ox, dst.top + oy, dst.right + ox, dst.bottom + oy)
        if (!vis.intersect(0f, 0f, root.width.toFloat(), root.height.toFloat())) return
        val out = RectF(vis.left - ox, vis.top - oy, vis.right - ox, vis.bottom - oy)
        val a = alpha.coerceIn(0, 255)
        val layer = canvas.saveLayerAlpha(dst, a)
        path.reset(); path.addRoundRect(dst, radius, radius, android.graphics.Path.Direction.CW)
        canvas.clipPath(path)
        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        bgPaint.shader = glassShader(root.width.toFloat(), root.height.toFloat(), -ox, -oy)
        canvas.drawRect(out, bgPaint)
        paint.color = tint
        canvas.drawRect(out, paint)
        canvas.restoreToCount(layer)
        if (lineW > 0f) {
            val h = lineW / 2f
            paint.style = Paint.Style.STROKE; paint.strokeWidth = lineW
            paint.color = ColorUtils.setAlphaComponent(line, ((line ushr 24) * a / 255).coerceIn(0, 255))
            canvas.drawRoundRect(RectF(dst.left + h, dst.top + h, dst.right - h, dst.bottom - h), radius - h, radius - h, paint)
        }
        paint.style = Paint.Style.FILL; paint.color = 0xFFFFFFFF.toInt()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        /** 작은 그림을 상자 블러로 흐리게 한다 (가로·세로 두 번씩). 새 그림을 돌려준다 */
        fun blur(src: Bitmap, radius: Int): Bitmap {
            val w = src.width; val h = src.height
            var px = IntArray(w * h)
            src.getPixels(px, 0, w, 0, 0, w, h)
            var tmp = IntArray(w * h)
            repeat(2) {
                pass(px, tmp, w, h, radius, true)
                pass(tmp, px, w, h, radius, false)
            }
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            out.setPixels(px, 0, w, 0, 0, w, h)
            return out
        }

        private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
            val len = if (horiz) w else h
            val lines = if (horiz) h else w
            for (ln in 0 until lines) {
                for (i in 0 until len) {
                    var sa = 0; var sr = 0; var sg = 0; var sb = 0; var cnt = 0
                    for (k in -r..r) {
                        val j = (i + k).coerceIn(0, len - 1)
                        val c = if (horiz) src[ln * w + j] else src[j * w + ln]
                        sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255; cnt++
                    }
                    val v = ((sa / cnt) shl 24) or ((sr / cnt) shl 16) or ((sg / cnt) shl 8) or (sb / cnt)
                    if (horiz) dst[ln * w + i] = v else dst[i * w + ln] = v
                }
            }
        }
    }
}

/**
 * 탭바·툴바 배경에 까는 테마 그림: 크롬 1x 크기를 화면 밀도에 맞춰 가로로 반복해서 위쪽에 맞춰 그린다.
 * BitmapDrawable 과 달리 '자기 크기'가 없어서(-1), 그림이 크더라도 막대(뷰)의 높이를 키우지 않는다.
 */
class ThemeTileDrawable(
    private val bm: Bitmap, private val density: Float,
    /** 그림이 시작하는 자리(이 드로어블의 왼쪽 위 기준 px)를 [0]=x, [1]=y 에 채워 준다. 없으면 왼쪽 위.
     *  크롬처럼 상태표시줄·탭바·툴바가 하나의 그림 위에 이어져 보이도록, 서로 다른 뷰가 같은 기준점을 쓰게 하는 데 쓴다 */
    private val origin: ((FloatArray) -> Unit)? = null,
    /** true 면 그림이 끝난 아래쪽(툴바 밑에 붙는 북마크바 자리)도 그림을 세로로 이어 붙여 채운다 (맨 아래 줄을 늘이면 억지로 늘어난 띠로 보인다) */
    private val extendDown: Boolean = false
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val org = FloatArray(2)
    private val ts = TileShader(bm, density, extendDown)

    override fun draw(canvas: Canvas) {
        if (bm.isRecycled || bounds.isEmpty) return
        val b = bounds
        org[0] = 0f; org[1] = 0f
        origin?.invoke(org)
        val ox = b.left + org[0]; val oy = b.top + org[1]
        paint.shader = ts.get(ox, oy)
        val top = maxOf(b.top.toFloat(), oy)
        val bottom = if (extendDown) b.bottom.toFloat() else minOf(b.bottom.toFloat(), oy + bm.height * density)
        if (bottom > top) canvas.drawRect(b.left.toFloat(), top, b.right.toFloat(), bottom, paint)
        paint.shader = null
    }

    override fun getIntrinsicWidth(): Int = -1
    override fun getIntrinsicHeight(): Int = -1
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
