package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * AI 답변 속 ```graph 블록을 그리는 뷰 (함수 · 꺾은선 · 막대 · 점). 형식은 [GraphSpec] 에 적혀 있다.
 * 색은 바깥(AssistantUi.makeGraphView)에서 테마에 맞춰 넣어 준다. 받는 도중 형식이 덜 온 상태여도 그릴 수 있는 만큼만 그린다.
 */
class GraphView(context: Context) : View(context) {

    var fg: Int = 0xFF202124.toInt()
    var muted: Int = 0xFF73777F.toInt()
    var gridColor: Int = 0x22000000
    var accent: Int = 0xFF2FA35B.toInt()
    /** 카드 바탕색 (점 테두리 · 말풍선 바탕에 쓴다) */
    var surface: Int = 0xFFFFFFFF.toInt()

    private var spec: GraphSpec? = null
    private val palette = intArrayOf(0, 0xFF1A73E8.toInt(), 0xFFE8710A.toInt(), 0xFF9334E6.toInt(), 0xFFD93025.toInt(), 0xFF00897B.toInt())

    private val dens = resources.displayMetrics.density
    private fun dpx(v: Float) = v * dens
    private fun spx(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val fillPath = Path()

    // 눌러서 값 보기: 손가락이 닿은 가로 위치 (그래프 밖을 누르면 해제)
    private var touchX: Float? = null
    private var downX = 0f
    private var downY = 0f
    private var lastPlot: RectF? = null
    private var lastBox: Box? = null
    // 이름이 보이는 점 (눌러야 나타난다, 없으면 -1)
    private var selPoint = -1
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    // 처음 나타날 때 한 번만: 선은 왼쪽에서 오른쪽으로 그려지고, 막대는 아래에서 자라난다
    private var reveal = 1f
    private var played = false
    private var anim: ValueAnimator? = null

    /** 극댓값 · 극솟값 같은 이름은 값 알약만으로 충분해서 글자로는 띄우지 않는다 */
    private fun isExtremumName(label: String): Boolean {
        val t = label.replace(" ", "")
        return t == "극댓값" || t == "극솟값" || t == "극대값" || t == "극소값" || t == "극대" || t == "극소"
    }

    fun setSource(src: String) {
        spec = try { GraphSpec.parse(src) } catch (e: Exception) { null }
        val g = spec
        if (!played && g != null && !g.isEmpty()) {
            played = true
            if (Motion.enabled(context)) {
                reveal = 0f
                anim?.cancel()
                anim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 750
                    interpolator = DecelerateInterpolator(1.6f)
                    addUpdateListener { reveal = it.animatedValue as Float; invalidate() }
                    start()
                }
            }
        }
        requestLayout()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        reveal = 1f
        super.onDetachedFromWindow()
    }

    private fun color(i: Int): Int = if (i % palette.size == 0) accent else palette[i % palette.size]

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec).let { if (it <= 0) dpx(300f).toInt() else it }
        val base = (w * 0.68f).toInt().coerceIn(dpx(190f).toInt(), dpx(420f).toInt())
        // 범례는 그래프 위에 따로 줄을 차지하니 그만큼 키를 늘린다
        val extra = spec?.let { g -> val n = legendNames(g); if (n.isEmpty()) 0 else layoutLegend(n, w.toFloat()).second.toInt() } ?: 0
        setMeasuredDimension(w, base + extra)
    }

    // ───────── 범례 ─────────

    private class LegendSlot(val name: String, val color: Int, val x: Float, val y: Float)

    /** 이름이 있는 것만 (막대 → 함수 → 꺾은선 순서, 색 번호는 그리는 순서와 같다) */
    private fun legendNames(g: GraphSpec): List<Pair<String, Int>> {
        val names = ArrayList<Pair<String, Int>>()
        var ci = 0
        for (b in g.bars) { if (b.label.isNotBlank()) names.add(b.label to color(ci)); ci++ }
        for (f in g.fns) { if (f.label.isNotBlank()) names.add(f.label to color(ci)); ci++ }
        for (s in g.lines) { if (s.label.isNotBlank()) names.add(s.label to color(ci)); ci++ }
        return if (names.isNotEmpty() && (names.size > 1 || g.title.isBlank())) names else emptyList()
    }

    /** 범례를 제목 아래 한 줄로 늘어놓고, 넘치면 다음 줄로 넘긴다. (자리 목록 · 전체 높이) */
    private fun layoutLegend(names: List<Pair<String, Int>>, w: Float): Pair<List<LegendSlot>, Float> {
        text.reset(); text.isAntiAlias = true; text.textSize = spx(10.5f)
        val rowH = dpx(18f)
        val left = dpx(12f)
        val maxW = w - dpx(24f)
        val slots = ArrayList<LegendSlot>()
        var x = left
        var row = 0
        for ((n, c) in names) {
            val label = ellipsize(n, text, maxW * 0.6f)
            val itemW = dpx(13f) + text.measureText(label)
            if (x > left && x + itemW > left + maxW) { x = left; row++ }
            slots.add(LegendSlot(label, c, x, row * rowH))
            x += itemW + dpx(14f)
        }
        return slots to (row + 1) * rowH
    }

    /** 점들을 부드러운 곡선으로 잇는다 (단조 3차 보간: 점 사이에서 위아래로 출렁이지 않고 점을 그대로 지난다) */
    private fun smooth(p: Path, x: FloatArray, y: FloatArray, move: Boolean = true) {
        val n = x.size
        if (n == 0) return
        if (move) p.moveTo(x[0], y[0]) else p.lineTo(x[0], y[0])
        var ordered = n >= 3
        for (k in 0 until n - 1) if (x[k + 1] - x[k] <= 0f) ordered = false
        if (!ordered) { for (k in 1 until n) p.lineTo(x[k], y[k]); return }
        val dx = FloatArray(n - 1) { x[it + 1] - x[it] }
        val d = FloatArray(n - 1) { (y[it + 1] - y[it]) / dx[it] }
        val m = FloatArray(n)
        m[0] = d[0]; m[n - 1] = d[n - 2]
        for (k in 1 until n - 1) m[k] = if (d[k - 1] * d[k] <= 0f) 0f else (d[k - 1] + d[k]) / 2f
        for (k in 0 until n - 1) {
            if (d[k] == 0f) { m[k] = 0f; m[k + 1] = 0f } else {
                val a = m[k] / d[k]
                val b = m[k + 1] / d[k]
                val q = a * a + b * b
                if (q > 9f) {
                    val t = 3f / kotlin.math.sqrt(q)
                    m[k] = t * a * d[k]; m[k + 1] = t * b * d[k]
                }
            }
        }
        for (k in 0 until n - 1) {
            val h = dx[k] / 3f
            p.cubicTo(x[k] + h, y[k] + m[k] * h, x[k + 1] - h, y[k + 1] - m[k + 1] * h, x[k + 1], y[k + 1])
        }
    }

    // ───────── 눈금 ─────────

    private fun niceStep(range: Double, target: Int): Double {
        val raw = range / max(1, target)
        if (raw <= 0.0 || raw.isNaN() || raw.isInfinite()) return 1.0
        val mag = 10.0.pow(floor(log10(raw)))
        val f = raw / mag
        val nice = if (f <= 1.0) 1.0 else if (f <= 2.0) 2.0 else if (f <= 5.0) 5.0 else 10.0
        return nice * mag
    }

    private fun fmt(v: Double): String {
        if (abs(v) < 1e-12) return "0"
        if (abs(v - v.roundToLong()) < 1e-9 * max(1.0, abs(v)) && abs(v) < 1e9) return v.roundToLong().toString()
        val df = java.text.DecimalFormat("0.####", java.text.DecimalFormatSymbols(java.util.Locale.US))
        return df.format(v)
    }

    // ───────── 범위 ─────────

    private class Box(var xMin: Double, var xMax: Double, var yMin: Double, var yMax: Double)

    private fun autoRange(g: GraphSpec): Box {
        val hasBars = g.bars.isNotEmpty()
        var xMin = g.xMin
        var xMax = g.xMax
        if (xMin == null || xMax == null) {
            val xs = ArrayList<Double>()
            g.lines.forEach { s -> s.xs.forEach { xs.add(it) } }
            g.points.forEach { xs.add(it.x) }
            g.vLines.forEach { xs.add(it) }
            if (xs.isNotEmpty() && g.fns.isEmpty()) {
                var lo = xs.minOrNull() ?: 0.0
                var hi = xs.maxOrNull() ?: 1.0
                if (hi - lo < 1e-9) { lo -= 1.0; hi += 1.0 }
                val pad = (hi - lo) * 0.06
                xMin = lo - pad; xMax = hi + pad
            } else if (xs.isNotEmpty()) {
                val lo = min(-6.0, xs.minOrNull() ?: -6.0)
                val hi = max(6.0, xs.maxOrNull() ?: 6.0)
                xMin = lo; xMax = hi
            } else {
                xMin = -6.0; xMax = 6.0
            }
        }
        val x0 = xMin ?: -6.0
        val x1 = xMax ?: 6.0

        var yMin = g.yMin
        var yMax = g.yMax
        if (yMin == null || yMax == null) {
            val ys = ArrayList<Double>()
            for (f in g.fns) {
                val n = 240
                for (k in 0..n) {
                    val v = f.expr.eval(x0 + (x1 - x0) * k / n)
                    if (!v.isNaN() && !v.isInfinite()) ys.add(v)
                }
            }
            // 점근선처럼 튀는 값은 범위를 정할 때 버린다 (tan · 1/x 등)
            if (ys.size > 20) {
                val mags = ys.map { abs(it) }.sorted()
                val limit = max(mags[(mags.size * 9) / 10] * 3.0, 1.0)
                val kept = ys.filter { abs(it) <= limit }
                ys.clear(); ys.addAll(kept)
            }
            g.lines.forEach { s -> s.ys.forEach { ys.add(it) } }
            g.bars.forEach { b -> b.values.forEach { ys.add(it) } }
            g.points.forEach { ys.add(it.y) }
            g.hLines.forEach { ys.add(it) }
            var lo = ys.minOrNull() ?: -1.0
            var hi = ys.maxOrNull() ?: 1.0
            if (hasBars) { lo = min(lo, 0.0); hi = max(hi, 0.0) }
            if (hi - lo < 1e-9) { lo -= 1.0; hi += 1.0 }
            val pad = (hi - lo) * 0.08
            yMin = if (hasBars && lo >= 0.0) 0.0 else lo - pad
            yMax = hi + pad
        }
        return Box(x0, x1, yMin ?: -1.0, yMax ?: 1.0)
    }

    // ───────── 그리기 ─────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val g = spec
        val w = width.toFloat()
        val h = height.toFloat()
        if (g == null || g.isEmpty()) {
            text.reset(); text.isAntiAlias = true
            text.color = muted; text.textSize = spx(13f); text.textAlign = Paint.Align.CENTER
            canvas.drawText("그래프를 그리는 중…", w / 2f, h / 2f, text)
            return
        }
        val box = autoRange(g)
        lastBox = box
        val bars = g.bars.isNotEmpty()

        // 위에서 아래로: 제목 → 범례 → 세로축 이름 → 그래프
        val tickSize = spx(11f)
        var cy = dpx(10f)
        if (g.title.isNotBlank()) {
            text.reset(); text.isAntiAlias = true
            text.color = fg; text.textSize = spx(14f); text.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            text.textAlign = Paint.Align.LEFT
            canvas.drawText(ellipsize(g.title, text, w - dpx(20f)), dpx(12f), cy + spx(14f), text)
            cy += dpx(22f)
        }
        val names = legendNames(g)
        if (names.isNotEmpty()) {
            val lay = layoutLegend(names, w)
            val rowH = dpx(18f)
            for (sl in lay.first) {
                val mid = cy + sl.y + rowH / 2f
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.FILL; paint.color = sl.color
                canvas.drawCircle(sl.x + dpx(4f), mid, dpx(4f), paint)
                text.reset(); text.isAntiAlias = true
                text.color = fg; text.textSize = spx(10.5f); text.textAlign = Paint.Align.LEFT
                canvas.drawText(sl.name, sl.x + dpx(13f), mid + spx(10.5f) * 0.35f, text)
            }
            cy += lay.second
        }
        if (g.yLabel.isNotBlank()) {
            text.reset(); text.isAntiAlias = true
            text.color = muted; text.textSize = spx(10.5f); text.textAlign = Paint.Align.LEFT
            canvas.drawText(ellipsize(g.yLabel, text, w - dpx(20f)), dpx(12f), cy + spx(10.5f), text)
            cy += dpx(14f)
        }
        val top = cy + dpx(4f)
        val left = dpx(10f) + tickWidth(box, tickSize)
        val right = dpx(14f)
        var bottom = dpx(10f) + tickSize + dpx(6f)
        if (g.xLabel.isNotBlank()) bottom += dpx(14f)
        val plot = RectF(left, top, w - right, h - bottom)
        lastPlot = plot
        if (plot.width() < dpx(40f) || plot.height() < dpx(40f)) return

        fun px(x: Double): Float = (plot.left + (x - box.xMin) / (box.xMax - box.xMin) * plot.width()).toFloat()
        fun py(y: Double): Float = (plot.bottom - (y - box.yMin) / (box.yMax - box.yMin) * plot.height()).toFloat()

        // 함수 그래프는 테두리 대신 원점을 지나는 x축 · y축만 두고, 눈금 글자도 그 축 옆에 붙인다
        val mathAxes = g.fns.isNotEmpty()
        val zeroY = box.yMin <= 0.0 && box.yMax >= 0.0
        val zeroX = box.xMin <= 0.0 && box.xMax >= 0.0
        val ayPos = if (zeroY) py(0.0) else plot.bottom
        val axPos = if (zeroX) px(0.0) else plot.left
        val origin = mathAxes && zeroX && zeroY

        // 격자 + 눈금 글자
        paint.reset(); paint.isAntiAlias = true
        text.reset(); text.isAntiAlias = true
        text.color = muted; text.textSize = tickSize
        val yStep = niceStep(box.yMax - box.yMin, 5)
        var yt = ceil(box.yMin / yStep) * yStep
        var guard = 0
        while (yt <= box.yMax + yStep * 1e-6 && guard++ < 40) {
            val y = py(yt)
            paint.color = (gridColor and 0x00FFFFFF) or 0x18000000; paint.strokeWidth = max(1f, dpx(0.6f)); paint.style = Paint.Style.STROKE
            canvas.drawLine(plot.left, y, plot.right, y, paint)
            text.textAlign = Paint.Align.RIGHT
            if (!(origin && abs(yt) < yStep * 1e-6)) canvas.drawText(fmt(yt), (if (mathAxes) axPos else plot.left) - dpx(5f), y + tickSize * 0.35f, text)
            yt += yStep
        }
        if (!bars) {
            val xStep = niceStep(box.xMax - box.xMin, 6)
            var xt = ceil(box.xMin / xStep) * xStep
            guard = 0
            while (xt <= box.xMax + xStep * 1e-6 && guard++ < 40) {
                val x = px(xt)
                paint.color = (gridColor and 0x00FFFFFF) or 0x0C000000; paint.strokeWidth = max(1f, dpx(0.6f)); paint.style = Paint.Style.STROKE
                canvas.drawLine(x, plot.top, x, plot.bottom, paint)
                text.textAlign = Paint.Align.CENTER
                if (!(origin && abs(xt) < xStep * 1e-6)) canvas.drawText(fmt(xt), x, (if (mathAxes) ayPos else plot.bottom) + tickSize + dpx(4f), text)
                xt += xStep
            }
        }

        if (origin) {
            text.reset(); text.isAntiAlias = true
            text.color = muted; text.textSize = tickSize; text.textAlign = Paint.Align.RIGHT
            canvas.drawText("0", axPos - dpx(5f), ayPos + tickSize + dpx(4f), text)
        }

        // 좌표축 (0 이 범위 안에 있을 때만 가운데를 지난다)
        paint.color = muted; paint.strokeWidth = dpx(1.2f); paint.style = Paint.Style.STROKE
        if (box.yMin <= 0.0 && box.yMax >= 0.0) canvas.drawLine(plot.left, py(0.0), plot.right, py(0.0), paint)
        if (!bars && box.xMin <= 0.0 && box.xMax >= 0.0) canvas.drawLine(px(0.0), plot.top, px(0.0), plot.bottom, paint)
        if (!mathAxes) canvas.drawLine(plot.left, plot.bottom, plot.right, plot.bottom, paint)
        if (!bars && !mathAxes) canvas.drawLine(plot.left, plot.top, plot.left, plot.bottom, paint)

        // 가로축 · 세로축 끝에 화살표와 이름(x, y). 0 이 범위 안이면 원점을 지나는 축, 아니면 가장자리 축에 붙인다
        if (!bars) {
            val ay = ayPos
            val ax = axPos
            val tipX = plot.right + dpx(5f)
            val tipY = plot.top - dpx(5f)
            val ah = dpx(8f)
            val aw = dpx(3.6f)
            paint.reset(); paint.isAntiAlias = true
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dpx(1.2f); paint.color = muted
            // 함수 그래프는 축 전체를, 그 밖에는 화살촉이 붙는 끝만 그린다
            canvas.drawLine(if (mathAxes) plot.left else plot.right, ay, tipX - dpx(1f), ay, paint)
            canvas.drawLine(ax, if (mathAxes) plot.bottom else plot.top, ax, tipY + dpx(1f), paint)
            paint.style = Paint.Style.FILL
            path.reset()
            path.moveTo(tipX, ay); path.lineTo(tipX - ah, ay - aw); path.lineTo(tipX - ah, ay + aw); path.close()
            canvas.drawPath(path, paint)
            path.reset()
            path.moveTo(ax, tipY); path.lineTo(ax - aw, tipY + ah); path.lineTo(ax + aw, tipY + ah); path.close()
            canvas.drawPath(path, paint)
            text.reset(); text.isAntiAlias = true
            text.color = muted; text.textSize = spx(11f); text.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            if (g.xLabel.isBlank()) {
                text.textAlign = Paint.Align.RIGHT
                canvas.drawText("x", plot.right - dpx(3f), ay - dpx(7f), text)
            }
            if (g.yLabel.isBlank()) {
                text.textAlign = Paint.Align.LEFT
                canvas.drawText("y", ax + dpx(8f), plot.top + spx(11f), text)
            }
        }

        if (g.xLabel.isNotBlank()) {
            text.reset(); text.isAntiAlias = true
            text.color = muted; text.textSize = spx(10.5f); text.textAlign = Paint.Align.CENTER
            canvas.drawText(ellipsize(g.xLabel, text, plot.width()), plot.centerX(), h - dpx(8f), text)
        }

        // 그래프 영역 안에서만 그린다
        val save = canvas.save()
        canvas.clipRect(plot.left - 1f, plot.top - 1f, plot.right + 1f, plot.bottom + 1f)
        var colorIdx = 0

        // 보조선
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE; paint.strokeWidth = dpx(1.2f); paint.color = muted
        paint.pathEffect = DashPathEffect(floatArrayOf(dpx(5f), dpx(4f)), 0f)
        for (v in g.hLines) canvas.drawLine(plot.left, py(v), plot.right, py(v), paint)
        for (v in g.vLines) canvas.drawLine(px(v), plot.top, px(v), plot.bottom, paint)
        paint.pathEffect = null

        // 막대: 데이터 쪽 모서리만 둥글게, 너무 두껍지 않게
        if (bars) {
            val cats = g.bars[0].cats
            val n = cats.size
            val sets = g.bars.size
            val slot = plot.width() / n
            val bw = min(slot * 0.72f / sets, dpx(26f))
            val zero = py(0.0)
            var widest = 0f
            text.reset(); text.isAntiAlias = true; text.textSize = spx(10.5f)
            g.bars.forEach { b -> b.values.forEach { v -> widest = max(widest, text.measureText(fmt(v))) } }
            val showVals = widest <= bw + dpx(8f) || n * sets <= 6
            text.textAlign = Paint.Align.CENTER
            for (c in 0 until n) {
                val cx = plot.left + slot * (c + 0.5f)
                text.color = muted; text.textSize = spx(10.5f)
                canvas.drawText(ellipsize(cats[c], text, slot - dpx(2f)), cx, plot.bottom + tickSize + dpx(4f), text)
                for (k in 0 until sets) {
                    val b = g.bars[k]
                    if (c >= b.values.size) continue
                    val x0 = cx - bw * sets / 2f + bw * k
                    val y = zero + (py(b.values[c]) - zero) * reveal
                    val rect = RectF(x0 + dpx(1f), min(y, zero), x0 + bw - dpx(1f), max(y, zero))
                    val r = min(dpx(8f), min(rect.width(), rect.height()) / 2f)
                    val up = b.values[c] >= 0.0
                    path.reset()
                    path.addRoundRect(rect, if (up) floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) else floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r), Path.Direction.CW)
                    paint.style = Paint.Style.FILL; paint.color = color(k)
                    canvas.drawPath(path, paint)
                    if (showVals && reveal > 0.85f) {
                        text.color = fg; text.textSize = spx(10.5f)
                        canvas.drawText(fmt(b.values[c]), x0 + bw / 2f, if (up) y - dpx(4f) else y + spx(10.5f) + dpx(2f), text)
                    }
                }
            }
            colorIdx = sets
        }

        // 함수 · 꺾은선 · 점은 reveal 만큼만 (왼쪽에서 오른쪽으로 그려진다)
        val revSave = canvas.save()
        if (reveal < 1f) canvas.clipRect(plot.left - 1f, plot.top - 1f, plot.left + plot.width() * reveal, plot.bottom + 1f)

        // 함수
        for (f in g.fns) {
            paint.reset(); paint.isAntiAlias = true
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dpx(2.4f); paint.color = color(colorIdx)
            paint.strokeJoin = Paint.Join.ROUND; paint.strokeCap = Paint.Cap.ROUND
            path.reset()
            val n = (plot.width() / 2f).toInt().coerceIn(120, 700)
            var open = false
            var prevY = 0f
            for (k in 0..n) {
                val x = box.xMin + (box.xMax - box.xMin) * k / n
                val v = f.expr.eval(x)
                if (v.isNaN() || v.isInfinite()) { open = false; continue }
                val sx = px(x)
                val sy = py(v)
                // 점근선에서 위아래로 크게 튀면 선을 잇지 않는다
                if (open && abs(sy - prevY) > plot.height()) open = false
                if (!open) path.moveTo(sx, sy) else path.lineTo(sx, sy)
                open = true
                prevY = sy
            }
            canvas.drawPath(path, paint)
            colorIdx++
        }

        // 꺾은선: 하나뿐이면 아래를 옅게 채우고, 점에는 바탕색 테두리를 둘러 선 위에서 또렷하게
        val lineBase = colorIdx
        for (s in g.lines) {
            val col = color(colorIdx)
            val sx = FloatArray(s.xs.size) { px(s.xs[it]) }
            val sy = FloatArray(s.xs.size) { py(s.ys[it]) }
            if (g.lines.size == 1 && !bars && g.fns.isEmpty() && s.xs.size > 1) {
                fillPath.reset()
                fillPath.moveTo(sx[0], plot.bottom)
                smooth(fillPath, sx, sy, false)
                fillPath.lineTo(sx[sx.size - 1], plot.bottom)
                fillPath.close()
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.FILL; paint.color = (col and 0x00FFFFFF) or 0x26000000
                canvas.drawPath(fillPath, paint)
            }
            paint.reset(); paint.isAntiAlias = true
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dpx(2.4f); paint.color = col
            paint.strokeJoin = Paint.Join.ROUND; paint.strokeCap = Paint.Cap.ROUND
            path.reset()
            smooth(path, sx, sy)
            canvas.drawPath(path, paint)
            if (s.xs.size <= 40) {
                paint.style = Paint.Style.FILL
                for (k in s.xs.indices) {
                    paint.color = surface
                    canvas.drawCircle(px(s.xs[k]), py(s.ys[k]), dpx(4.6f), paint)
                    paint.color = col
                    canvas.drawCircle(px(s.xs[k]), py(s.ys[k]), dpx(3.2f), paint)
                }
            }
            colorIdx++
        }

        // 점: 평소엔 점만. 누르면 축으로 내리는 점선과 축 위의 값 알약, 점 위에 이름(글자만)이 나타난다
        fun chipW(txt: String): Float {
            text.reset(); text.isAntiAlias = true; text.textSize = spx(11f)
            return text.measureText(txt) + dpx(12f)
        }
        fun chip(txt: String, cx: Float, cy: Float, c: Int) {
            val w = chipW(txt)
            val hh = dpx(17f)
            paint.reset(); paint.isAntiAlias = true
            paint.style = Paint.Style.FILL; paint.color = c
            canvas.drawRoundRect(RectF(cx - w / 2f, cy - hh / 2f, cx + w / 2f, cy + hh / 2f), hh / 2f, hh / 2f, paint)
            text.reset(); text.isAntiAlias = true
            text.color = 0xFFFFFFFF.toInt(); text.textSize = spx(11f); text.textAlign = Paint.Align.CENTER
            canvas.drawText(txt, cx, cy + spx(11f) * 0.35f, text)
        }
        g.points.forEachIndexed { pi, m ->
            val sel = pi == selPoint
            val pc = color(colorIdx)
            val cx = px(m.x)
            val cy = py(m.y)
            if (sel) {
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dpx(1.2f); paint.color = pc
                paint.pathEffect = DashPathEffect(floatArrayOf(dpx(4f), dpx(3f)), 0f)
                canvas.drawLine(cx, cy, cx, ayPos, paint)
                canvas.drawLine(cx, cy, axPos, cy, paint)
                paint.pathEffect = null
            }
            paint.reset(); paint.isAntiAlias = true
            paint.style = Paint.Style.FILL; paint.color = surface
            canvas.drawCircle(cx, cy, dpx(if (sel) 6.8f else 5.6f), paint)
            paint.color = pc
            canvas.drawCircle(cx, cy, dpx(if (sel) 5.2f else 4.2f), paint)
            if (sel) {
                // 축 위의 값: 점이 있는 쪽 축 곁에 (0 이면 이미 축 위라 생략)
                if (zeroY && abs(m.x) > 1e-9) chip(fmt(m.x), cx, ayPos + (if (m.y < 0.0) -dpx(14f) else dpx(14f)), pc)
                if (zeroX && abs(m.y) > 1e-9) {
                    val w = chipW(fmt(m.y))
                    chip(fmt(m.y), axPos + (if (m.x > 0.0) -(w / 2f + dpx(6f)) else (w / 2f + dpx(6f))), cy, pc)
                }
                // 이름: 알약 없이 글자만, 선 위에서도 읽히게 바탕색 윤곽을 두른다
                if (m.label.isNotBlank() && !isExtremumName(m.label)) {
                    text.reset(); text.isAntiAlias = true
                    text.textSize = spx(11.5f); text.textAlign = Paint.Align.CENTER
                    val tw = text.measureText(m.label)
                    val tx = cx.coerceIn(plot.left + tw / 2f + dpx(4f), plot.right - tw / 2f - dpx(4f))
                    val ty = max(cy - dpx(13f), plot.top + spx(11.5f) + dpx(2f))
                    text.style = Paint.Style.STROKE; text.strokeWidth = dpx(3.5f); text.strokeJoin = Paint.Join.ROUND; text.color = surface
                    canvas.drawText(m.label, tx, ty, text)
                    text.style = Paint.Style.FILL; text.color = fg
                    canvas.drawText(m.label, tx, ty, text)
                }
            }
        }
        canvas.restoreToCount(revSave)
        canvas.restoreToCount(save)

        // 눌러서 값 보기
        val tx = touchX
        if (tx != null && tx >= plot.left && tx <= plot.right) {
            val rows = ArrayList<Pair<Int, String>>()
            var head = ""
            var anchor = tx
            fun guide(x: Float) {
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dpx(1.2f); paint.color = muted
                paint.pathEffect = DashPathEffect(floatArrayOf(dpx(4f), dpx(3f)), 0f)
                canvas.drawLine(x, plot.top, x, plot.bottom, paint)
                paint.pathEffect = null
            }
            fun dot(x: Float, y: Float, c: Int) {
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.FILL; paint.color = surface
                canvas.drawCircle(x, y, dpx(6f), paint)
                paint.color = c
                canvas.drawCircle(x, y, dpx(4.4f), paint)
            }
            if (bars && g.bars[0].cats.isNotEmpty()) {
                val cats = g.bars[0].cats
                val n = cats.size
                val slot = plot.width() / n
                val c = ((tx - plot.left) / slot).toInt().coerceIn(0, n - 1)
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.FILL; paint.color = (fg and 0x00FFFFFF) or 0x12000000
                canvas.drawRect(plot.left + slot * c, plot.top, plot.left + slot * (c + 1), plot.bottom, paint)
                head = cats[c]
                g.bars.forEachIndexed { k, b ->
                    if (c < b.values.size) rows.add(color(k) to ((if (b.label.isNotBlank()) b.label + "  " else "") + fmt(b.values[c])))
                }
                anchor = plot.left + slot * (c + 0.5f)
            } else if (g.lines.any { it.xs.isNotEmpty() }) {
                var bestX = g.lines.first { it.xs.isNotEmpty() }.xs[0]
                var bestD = Float.MAX_VALUE
                for (s in g.lines) for (xv in s.xs) {
                    val d = abs(px(xv) - tx)
                    if (d < bestD) { bestD = d; bestX = xv }
                }
                anchor = px(bestX)
                guide(anchor)
                head = "x = " + fmt(bestX)
                g.lines.forEachIndexed { j, s ->
                    val k = s.xs.indexOfFirst { abs(it - bestX) < 1e-9 }
                    if (k >= 0) {
                        dot(anchor, py(s.ys[k]), color(lineBase + j))
                        rows.add(color(lineBase + j) to ((if (s.label.isNotBlank()) s.label + "  " else "") + fmt(s.ys[k])))
                    }
                }
            } else if (g.fns.isNotEmpty()) {
                val xv = box.xMin + (tx - plot.left) / plot.width() * (box.xMax - box.xMin)
                guide(tx)
                head = "x = " + fmt(xv)
                g.fns.forEachIndexed { j, f ->
                    val v = f.expr.eval(xv)
                    if (!v.isNaN() && !v.isInfinite()) {
                        dot(tx, py(v), color(j))
                        rows.add(color(j) to ((if (f.label.isNotBlank()) f.label + "  " else "") + fmt(v)))
                    }
                }
            }
            if (rows.isNotEmpty()) drawTip(canvas, anchor, plot, head, rows)
        }
    }

    /** 누른 자리의 값을 알려 주는 작은 말풍선 */
    private fun drawTip(canvas: Canvas, anchor: Float, plot: RectF, head: String, rows: List<Pair<Int, String>>) {
        val ts = spx(11.5f)
        text.reset(); text.isAntiAlias = true; text.textSize = ts
        val pad = dpx(8f)
        val rowH = ts + dpx(5f)
        var wMax = if (head.isNotBlank()) text.measureText(head) else 0f
        for (r in rows) wMax = max(wMax, text.measureText(r.second) + dpx(14f))
        val bw = wMax + pad * 2
        val bh = pad * 2 - dpx(2f) + rowH * (rows.size + if (head.isNotBlank()) 1 else 0)
        var bx = anchor + dpx(10f)
        if (bx + bw > plot.right + dpx(8f)) bx = anchor - dpx(10f) - bw
        bx = bx.coerceIn(dpx(4f), max(dpx(4f), width - bw - dpx(4f)))
        val by = plot.top + dpx(4f)
        val rect = RectF(bx, by, bx + bw, by + bh)
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.FILL; paint.color = surface
        canvas.drawRoundRect(rect, dpx(12f), dpx(12f), paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = max(1f, dpx(0.8f)); paint.color = (muted and 0x00FFFFFF) or 0x66000000
        canvas.drawRoundRect(rect, dpx(12f), dpx(12f), paint)
        var y = by + pad - dpx(1f)
        text.textAlign = Paint.Align.LEFT
        if (head.isNotBlank()) {
            text.color = muted
            canvas.drawText(head, bx + pad, y + ts, text)
            y += rowH
        }
        for (r in rows) {
            paint.reset(); paint.isAntiAlias = true
            paint.style = Paint.Style.FILL; paint.color = r.first
            canvas.drawCircle(bx + pad + dpx(4f), y + ts * 0.55f, dpx(3.5f), paint)
            text.color = fg
            canvas.drawText(r.second, bx + pad + dpx(14f), y + ts * 0.95f, text)
            y += rowH
        }
    }

    /** 손가락 근처(26dp 안)에서 가장 가까운 점. 없으면 -1 */
    private fun hitPoint(x: Float, y: Float): Int {
        val g = spec ?: return -1
        val bx = lastBox ?: return -1
        val pl = lastPlot ?: return -1
        var best = -1
        var bd = dpx(26f)
        g.points.forEachIndexed { i, m ->
            val sx = (pl.left + (m.x - bx.xMin) / (bx.xMax - bx.xMin) * pl.width()).toFloat()
            val sy = (pl.bottom - (m.y - bx.yMin) / (bx.yMax - bx.yMin) * pl.height()).toFloat()
            val dd = kotlin.math.sqrt((sx - x) * (sx - x) + (sy - y) * (sy - y))
            if (dd < bd) { bd = dd; best = i }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val g = spec
        if (g == null || g.isEmpty()) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                val pl = lastPlot
                val hit = hitPoint(e.x, e.y)
                if (hit >= 0) {
                    // 점을 누르면 그 점의 이름만 (다시 누르면 숨김)
                    selPoint = if (selPoint == hit) -1 else hit
                    touchX = null
                } else {
                    selPoint = -1
                    touchX = if (pl != null && e.x >= pl.left && e.x <= pl.right) e.x else null
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                // 옆으로 끌면 값이 따라오고, 위아래로 끌면 대화창이 스크롤된다
                if (abs(e.x - downX) > slop && abs(e.x - downX) > abs(e.y - downY)) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    selPoint = -1
                    val pl = lastPlot
                    if (pl != null) touchX = e.x.coerceIn(pl.left, pl.right)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    /** 세로 눈금 글자가 들어갈 너비 */
    private fun tickWidth(box: Box, size: Float): Float {
        text.reset(); text.isAntiAlias = true; text.textSize = size
        val yStep = niceStep(box.yMax - box.yMin, 5)
        var widest = 0f
        var yt = ceil(box.yMin / yStep) * yStep
        var guard = 0
        while (yt <= box.yMax + yStep * 1e-6 && guard++ < 40) {
            widest = max(widest, text.measureText(fmt(yt)))
            yt += yStep
        }
        return widest + dpx(6f)
    }

    private fun ellipsize(s: String, p: Paint, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var n = s.length
        while (n > 1 && p.measureText(s.substring(0, n) + "…") > maxW) n--
        return s.substring(0, n) + "…"
    }
}
