package com.example.evergreen

import org.json.JSONObject

/**
 * 에이전트가 `change_setting` 으로 바꿀 수 있는 설정 목록 (이름 · 이름표 · 값의 모양).
 * 실제로 적용하는 곳은 `MainActivity.agentSetSetting` 이고, 설정 화면의 토글과 같은 효과를 낸다.
 *
 * 일부러 뺀 것 (에이전트가 스스로 바꾸면 안 되거나, 에이전트가 도는 중에 바꾸면 위험한 것):
 * - 에이전트 자신의 권한 (AI 에이전트 켜기 · 자율 모드 · 시크릿 탭 허용) · 내 폰 모드 · API 키
 * - 접속 차단 우회 (연결 방식 자체를 바꿈) · 알림 설정
 * - 블러 효과 (켜고 끌 때 화면을 통째로 다시 만들어서, 에이전트가 일하던 창이 닫힘)
 */
object AgentSettings {
    enum class Kind { BOOL, ENUM, INT, TEXT }

    /**
     * 설정 하나.
     * [protective] 가 true 면 켜 둔 쪽이 안전한 설정이라, 끄는 건 매번 사용자 확인을 받는다.
     * [alwaysAsk] 가 true 면 값을 바꿀 때마다 사용자 확인을 받는다 (잘못 바뀌면 피해가 큰 설정).
     */
    class Def(
        val name: String,
        val label: String,
        val kind: Kind,
        private val hint: String = "",
        val protective: Boolean = false,
        val alwaysAsk: Boolean = false,
        /** 모델에게만 알려 주는 덧말 (결과 카드의 이름표에는 안 나온다) */
        val note: String = ""
    ) {
        /** change_setting 설명에 들어가는 값의 모양 */
        val values: String get() = (if (kind == Kind.BOOL) "on · off" else hint) + (if (note.isEmpty()) "" else ", $note")
    }

    val ALL: List<Def> = listOf(
        // 화면 · 보기
        Def("web_dark_mode", "웹 페이지 다크 모드", Kind.ENUM, "off · device · always"),
        Def("text_zoom", "글자 크기", Kind.INT, "50~200 사이 숫자, 10 단위"),
        Def("page_zoom", "화면 확대/축소", Kind.INT, "50~500 사이 숫자(%)"),
        Def("bookmark_bar", "북마크바", Kind.BOOL),
        Def("hide_bars", "상/하단바 숨기기", Kind.BOOL),
        Def("hide_bars_on_scroll", "스크롤하면 바 숨기기", Kind.BOOL),
        Def("theme_menus", "메뉴·팝업에도 테마 색 적용", Kind.BOOL),
        Def("desktop_site", "데스크톱 사이트", Kind.BOOL, note = "지금 보는 탭을 바꾸고 페이지를 다시 불러옴"),
        Def("auto_site_mode", "모바일/데스크톱 자동 전환", Kind.BOOL),
        Def("drag_tab_to_window", "탭을 끌어서 새 창 열기", Kind.BOOL),
        // 광고 · 보안 · 개인정보
        Def("ad_block", "광고 차단", Kind.BOOL),
        Def("yt_ad_block", "유튜브 광고 차단", Kind.BOOL),
        Def("yt_ad_prune", "유튜브 광고 미리 지우기", Kind.BOOL),
        Def("yt_auto_skip", "유튜브 광고 건너뛰기 자동 클릭", Kind.BOOL),
        Def("strict_trackers", "트래커 차단(엄격)", Kind.BOOL, protective = true),
        Def("malware_warning", "악성 사이트 알림", Kind.BOOL, protective = true),
        Def("https_first", "HTTPS 우선 연결", Kind.BOOL, protective = true),
        Def("block_auto_download", "자동 다운로드 차단", Kind.BOOL, protective = true),
        Def("block_back_redirect", "뒤로가기 중 자동 이동 차단", Kind.BOOL, protective = true),
        Def("block_hijack_nav", "클릭 가로채기 이동 차단", Kind.BOOL, protective = true),
        Def("skip_captcha_tracking", "캡차 건너뛰기(추적 방지)", Kind.BOOL),
        Def("autofill", "비밀번호·자동완성", Kind.BOOL),
        // 번역
        Def("always_translate", "항상 번역", Kind.BOOL),
        Def("translate_images", "이미지 속 글자 번역", Kind.BOOL),
        // 미디어
        Def("background_audio", "백그라운드 재생", Kind.BOOL),
        Def("media_controls", "시스템 미디어 플레이어에 표시", Kind.BOOL),
        Def("swipe_down_exit", "전체화면에서 아래로 밀어 나가기", Kind.BOOL),
        Def("video_buttons", "영상 아래 버튼 표시", Kind.BOOL),
        Def("mirror_fallback", "영상 못 찾으면 미러링", Kind.BOOL),
        // 검색 · 시작
        Def("search_engine", "검색 엔진", Kind.TEXT, "get_settings 의 search_engines 에 있는 이름"),
        Def("homepage", "홈 페이지", Kind.TEXT, "https://… 주소, 기본 새 탭 화면으로 되돌리려면 default", alwaysAsk = true)
    )

    private val byName: Map<String, Def> = ALL.associateBy { it.name }

    fun find(name: String): Def? = byName[name]

    fun label(name: String): String = byName[name]?.label ?: name

    fun names(): Array<String> = ALL.map { it.name }.toTypedArray()

    /** change_setting 설명에 넣을 「이름(값)」 목록 */
    fun describe(): String = ALL.joinToString(" · ") { "${it.name}(${it.values})" }

    fun parseBool(v: String): Boolean? = when (v.trim().lowercase()) {
        "on", "true", "1", "yes", "켜기", "켬", "켜짐" -> true
        "off", "false", "0", "no", "끄기", "끔", "꺼짐" -> false
        else -> null
    }

    /**
     * 이번 호출은 실행할 때마다 사용자 확인을 받아야 하는가:
     * 값이 바뀌면 피해가 큰 설정(홈 페이지)이거나, 보호 설정을 끄는 경우.
     */
    fun needsEachConfirm(name: String, value: String): Boolean {
        val d = byName[name] ?: return false
        if (d.alwaysAsk) return true
        return d.protective && d.kind == Kind.BOOL && parseBool(value) == false
    }

    /**
     * [st] (host.settings() 의 결과) 에서 설정 [name] 의 지금 값을, change_setting 에 다시 넘길 수 있는 글로 꺼낸다.
     * 되돌리기 · 결과 카드의 토글이 쓴다. 알 수 없으면 null.
     */
    fun currentValue(st: JSONObject, name: String): String? {
        when (name) {
            "web_dark_mode" -> return st.optString("web_dark_mode").substringBefore(' ').ifEmpty { null }
            "text_zoom" -> return if (st.has("text_zoom_percent")) st.optInt("text_zoom_percent").toString() else null
        }
        val d = byName[name] ?: return null
        if (!st.has(name)) return null
        return when (d.kind) {
            Kind.BOOL -> if (st.optBoolean(name)) "on" else "off"
            Kind.INT -> st.optInt(name).toString()
            else -> st.optString(name)
        }
    }
}
