package com.example.evergreen

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** 대화 기록 목록에 보여 줄 한 줄 정보 */
class ChatMeta(val id: String, val title: String, val updated: Long, val count: Int, val preview: String)

/**
 * AI 대화 저장소. 대화 하나를 앱 전용 폴더(filesDir/ai_chats)의 파일 하나("id.json")로 저장한다.
 * 글(질문 · 답 · 생각 요약 · 검색어 · 출처)만 저장하고, 보낸 사진은 저장하지 않는다.
 * 파일 읽기 · 쓰기는 백그라운드 스레드에서 부르고, [encode] 만 화면 스레드에서 불러도 된다 (메모리 안에서만 돈다).
 */
class ChatStore(context: Context) {
    companion object {
        /** 남겨 두는 대화 수 (넘으면 가장 오래 안 본 것부터 지운다) */
        const val MAX_CHATS = 100

        private val ID_OK = Regex("^[a-z0-9]{4,24}$")

        fun newId(): String =
            java.lang.Long.toString(System.currentTimeMillis(), 36) + java.lang.Integer.toString((Math.random() * 1296).toInt() + 36, 36)

        /** 첫 질문을 제목으로 쓴다 (한 줄, 40자까지) */
        fun titleOf(msgs: List<ChatMsg>): String {
            val q = msgs.firstOrNull { it.role == "user" && it.text.isNotBlank() }?.text ?: msgs.firstOrNull()?.text ?: ""
            val one = q.replace(Regex("\\s+"), " ").trim()
            return if (one.isEmpty()) "새 대화" else if (one.length <= 40) one else one.take(40) + "…"
        }

        /** 대화를 파일에 쓸 JSON 글로 만든다. 빈 글 메시지는 뺀다 */
        fun encode(id: String, title: String, updated: Long, msgs: List<ChatMsg>): String {
            val arr = JSONArray()
            for (m in msgs) {
                if (m.text.isBlank()) continue
                val o = JSONObject().put("r", m.role).put("t", m.text)
                if (!m.shown.isNullOrEmpty()) o.put("sh", m.shown)
                if (m.thought.isNotEmpty()) o.put("th", m.thought)
                if (m.thought.isNotEmpty() && m.thoughtTranslated) o.put("tt", true)
                if (m.thinkMs > 0L) o.put("ms", m.thinkMs)
                if (m.searchQueries.isNotEmpty()) {
                    val qa = JSONArray()
                    for (q in m.searchQueries) qa.put(q)
                    o.put("q", qa)
                }
                if (m.sources.isNotEmpty()) {
                    val sa = JSONArray()
                    for (s in m.sources) sa.put(JSONObject().put("t", s.title).put("u", s.url))
                    o.put("s", sa)
                }
                arr.put(o)
            }
            return JSONObject().put("id", id).put("title", title).put("updated", updated).put("messages", arr).toString()
        }

        private fun decode(raw: String): List<ChatMsg> {
            val arr = JSONObject(raw).optJSONArray("messages") ?: return emptyList()
            val out = ArrayList<ChatMsg>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val role = if (o.optString("r") == "user") "user" else "model"
                val text = o.optString("t")
                if (text.isEmpty()) continue
                val m = ChatMsg(role, text)
                m.shown = o.optString("sh").takeIf { it.isNotEmpty() }
                m.thought = o.optString("th")
                m.thoughtTranslated = o.optBoolean("tt", false)
                m.thinkMs = o.optLong("ms", 0L)
                val qa = o.optJSONArray("q")
                if (qa != null) m.searchQueries = (0 until qa.length()).map { qa.optString(it) }.filter { it.isNotEmpty() }
                val sa = o.optJSONArray("s")
                if (sa != null) {
                    val srcs = ArrayList<SearchSource>()
                    for (k in 0 until sa.length()) {
                        val so = sa.optJSONObject(k) ?: continue
                        val u = so.optString("u")
                        if (u.startsWith("http")) srcs.add(SearchSource(so.optString("t"), u))
                    }
                    m.sources = srcs
                }
                out.add(m)
            }
            return out
        }
    }

    private val dir = File(context.filesDir, "ai_chats")

    private fun fileOf(id: String): File? = if (ID_OK.matches(id)) File(dir, "$id.json") else null

    /** [encode] 로 만든 글을 저장한다 (임시 파일에 쓴 뒤 바꿔치기해서, 도중에 꺼져도 옛 파일이 망가지지 않는다) */
    @Synchronized
    fun write(id: String, json: String) {
        val f = fileOf(id) ?: return
        try {
            dir.mkdirs()
            val tmp = File(dir, "$id.tmp")
            tmp.writeText(json, Charsets.UTF_8)
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
            trim()
        } catch (e: Exception) {
            // 저장을 못 해도 대화는 계속 쓸 수 있다
        }
    }

    private fun trim() {
        val files = dir.listFiles { x -> x.name.endsWith(".json") } ?: return
        if (files.size <= MAX_CHATS) return
        files.sortedBy { it.lastModified() }.take(files.size - MAX_CHATS).forEach { it.delete() }
    }

    /** 저장된 대화들 (최근 것이 위) */
    @Synchronized
    fun list(): List<ChatMeta> {
        val files = dir.listFiles { x -> x.name.endsWith(".json") } ?: return emptyList()
        val out = ArrayList<ChatMeta>()
        for (f in files) {
            try {
                val o = JSONObject(f.readText(Charsets.UTF_8))
                val id = f.name.removeSuffix(".json")
                val msgs = o.optJSONArray("messages")
                val n = msgs?.length() ?: 0
                if (n == 0) continue
                var preview = ""
                // 미리보기: 마지막 답 (없으면 마지막 질문)
                for (i in n - 1 downTo 0) {
                    val m = msgs!!.optJSONObject(i) ?: continue
                    val t = m.optString("t")
                    if (t.isNotBlank()) {
                        preview = t.replace(Regex("[*#`>_~]"), "").replace(Regex("\\s+"), " ").trim().take(80)
                        break
                    }
                }
                out.add(ChatMeta(id, o.optString("title").ifBlank { "새 대화" }, o.optLong("updated", f.lastModified()), n, preview))
            } catch (e: Exception) {
                // 깨진 파일은 목록에서 뺀다
            }
        }
        return out.sortedByDescending { it.updated }
    }

    @Synchronized
    fun load(id: String): List<ChatMsg>? {
        val f = fileOf(id) ?: return null
        if (!f.exists()) return null
        return try {
            decode(f.readText(Charsets.UTF_8)).takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            null
        }
    }

    @Synchronized
    fun delete(id: String) {
        fileOf(id)?.delete()
    }

    @Synchronized
    fun deleteAll() {
        dir.listFiles()?.forEach { it.delete() }
    }
}
