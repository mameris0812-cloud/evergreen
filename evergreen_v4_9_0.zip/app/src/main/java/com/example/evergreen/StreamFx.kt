package com.example.evergreen

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.os.SystemClock
import android.text.TextPaint
import android.text.style.CharacterStyle
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.SpringAnimation
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

/** 답이 쏟아질 때 새로 붙은 글자가 옅은 데서 또렷하게 떠오르게 한다 (그릴 때마다 시간으로 계산) */
class FadeInSpan(val birth: Long) : CharacterStyle() {
    override fun updateDrawState(tp: TextPaint) {
        val f = ((SystemClock.uptimeMillis() - birth) / DURATION).coerceIn(0f, 1f)
        if (f < 1f) {
            val e = 1f - (1f - f) * (1f - f)
            tp.alpha = (tp.alpha * (0.12f + 0.88f * e)).toInt()
        }
    }

    fun finished(): Boolean = SystemClock.uptimeMillis() - birth >= DURATION.toLong()

    companion object {
        const val DURATION = 300f
    }
}

/** 받는 중임을 알리는 글 끝의 커서(▍): 딱딱하게 꺼졌다 켜지지 않고 숨 쉬듯 옅어졌다 짙어진다 */
class BlinkCursorSpan(private val color: Int) : CharacterStyle() {
    override fun updateDrawState(tp: TextPaint) {
        val p = (SystemClock.uptimeMillis() % 1100L) / 1100f
        val a = 0.22f + 0.78f * (0.5f - 0.5f * cos(p * 2f * PI.toFloat()))
        tp.color = ColorUtils.setAlphaComponent(color, (255f * a).toInt())
    }
}

/**
 * 생각 요약이 흘러 들어오는 동안 보여 주는 고정 높이 창.
 * 글이 길어져도 카드가 계속 늘어나지 않고 [capPx] 높이를 지키며, 새 글이 아래에 붙으면
 * 이미 있던 글이 스프링으로 부드럽게 위로 밀려 올라간다. 맨 위는 카드 색으로 옅어진다.
 * [release] 하면 제한을 풀고 전체 높이까지 부드럽게 펼쳐진다 (끝난 뒤 직접 펼쳐 볼 때).
 */
class ThoughtClip(context: Context, private val capPx: Int, private val fadeColor: Int) : FrameLayout(context) {
    private var capped = true
    private var forcedH = -1
    private var shift = 0f
    private var lastTarget = 0f
    private var shiftAnim: SpringAnimation? = null
    private var heightAnim: ValueAnimator? = null
    private val fadePaint = Paint()
    private val fadeH = capPx * 0.3f
    private var shader: LinearGradient? = null

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val c = getChildAt(0)
        val cw = MeasureSpec.getSize(widthMeasureSpec)
        if (c == null) {
            setMeasuredDimension(cw, 0)
            return
        }
        c.measure(
            MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        )
        val ch = c.measuredHeight
        val h = when {
            forcedH >= 0 -> forcedH
            capped -> min(ch, capPx)
            else -> ch
        }
        setMeasuredDimension(cw, h)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        val c = getChildAt(0) ?: return
        c.layout(0, 0, right - left, c.measuredHeight)
        moveTo(max(0f, (c.measuredHeight - (bottom - top)).toFloat()))
    }

    private fun apply(v: Float) {
        shift = v
        getChildAt(0)?.translationY = -v
        invalidate()
    }

    private fun moveTo(target: Float) {
        if (target == lastTarget) return
        lastTarget = target
        shiftAnim?.cancel()
        if (forcedH >= 0 || !isAttachedToWindow || !Motion.enabled(context)) {
            apply(target)
            return
        }
        shiftAnim = Motion.springValue(shift, target, stiffness = 140f, damping = 1f, onUpdate = { apply(it) })
    }

    /** 높이 제한을 푼다. [animate] 이면 지금 높이에서 전체 높이까지 부드럽게 펼쳐진다 */
    fun release(animate: Boolean) {
        if (!capped) return
        capped = false
        heightAnim?.cancel()
        val full = getChildAt(0)?.measuredHeight ?: 0
        val from = height
        if (animate && isAttachedToWindow && Motion.enabled(context) && full > from) {
            heightAnim = ValueAnimator.ofInt(from, full).apply {
                duration = 240
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    forcedH = it.animatedValue as Int
                    requestLayout()
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        forcedH = -1
                        requestLayout()
                    }
                })
                start()
            }
        } else {
            requestLayout()
        }
    }

    override fun onDetachedFromWindow() {
        shiftAnim?.cancel()
        heightAnim?.cancel()
        forcedH = -1
        super.onDetachedFromWindow()
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (shift <= 1f) return
        val sh = shader ?: LinearGradient(
            0f, 0f, 0f, fadeH, fadeColor, ColorUtils.setAlphaComponent(fadeColor, 0), Shader.TileMode.CLAMP
        ).also { shader = it }
        fadePaint.shader = sh
        // 밀려 올라가기 시작하는 순간에는 옅게, 충분히 올라가면 온전히
        fadePaint.alpha = (255f * min(1f, shift / (fadeH * 0.8f))).toInt()
        canvas.drawRect(0f, 0f, width.toFloat(), fadeH, fadePaint)
    }
}
