package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.MaterialColors

/**
 * 시스템 토스트 대신 쓰는 앱 자체 알림.
 * 창 맨 위에 짧게 떴다가 사라지는 알약 모양 안내이고, 앱의 테마 색을 따른다.
 * 창(액티비티)을 못 찾을 때(서비스 등)만 시스템 토스트로 대신한다.
 */
object AppToast {
    private const val TAG = "evergreen_app_toast"
    private val main = Handler(Looper.getMainLooper())

    /** 팝업 · 바텀시트 · 대화상자(별도 창)가 떠 있을 때 알림을 그 위에 그리려고 따로 띄운 알림 창의 뷰 (없으면 null) */
    private var windowToast: Pair<Activity, View>? = null

    private fun removeWindowToast() {
        val w = windowToast ?: return
        windowToast = null
        w.second.animate().cancel()
        try { w.first.windowManager.removeViewImmediate(w.second) } catch (e: Exception) { /* 이미 사라짐 */ }
    }

    /**
     * 앱 알림(토스트)·다운로드 진행 카드는 같은 창의 어떤 화면·팝업 카드·오버레이보다 위에 그려지고 터치도 먼저 받는다.
     * 그리기 순서는 높이(Z)로 정해지므로 다른 오버레이(최대 약 24dp)보다 훨씬 크게 잡는다. 진행 카드는 토스트보다 한 단계 아래.
     * 그림자는 이 높이에서 너무 크게 번지므로 쓰지 않는다.
     */
    const val TOAST_Z_DP = 200
    const val CARD_Z_DP = 190

    fun raiseToTop(v: View, zPx: Int) {
        v.outlineProvider = null
        v.elevation = zPx.toFloat()
    }

    /** [lift] 가 0보다 크면 창 아래에서 그만큼 띄워 그린다 (아래 막대가 있을 때 그 위로 오게). 0 이면 기본 위치 */
    fun show(ctx: Context, msg: CharSequence, lift: Int = 0) {
        if (Looper.myLooper() == Looper.getMainLooper()) showNow(ctx, msg, lift) else main.post { showNow(ctx, msg, lift) }
    }

    /**
     * 오른쪽에 버튼이 달린 앱 자체 알림 (예: 다운로드 완료 · 열기).
     * 버튼을 누르면 [onAction] 을 하고 알림은 닫힌다. 일반 알림보다 조금 더 오래 떠 있다.
     */
    fun showAction(act: Activity, title: CharSequence, sub: CharSequence?, actionLabel: String, onAction: () -> Unit) {
        val lift = (act as? MainActivity)?.toastLift() ?: 0
        val run = Runnable { showNow(act, title, lift, sub, actionLabel, onAction) }
        if (Looper.myLooper() == Looper.getMainLooper()) run.run() else main.post(run)
    }

    private fun activityOf(ctx: Context): Activity? {
        var c: Context? = ctx
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return null
    }

    private fun showNow(
        ctx: Context, msg: CharSequence, lift: Int,
        sub: CharSequence? = null, actionLabel: String? = null, onAction: (() -> Unit)? = null
    ) {
        val act = activityOf(ctx)
        val root = act?.window?.decorView as? ViewGroup
        if (act == null || act.isFinishing || act.isDestroyed || root == null) {
            Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_SHORT).show()
            return
        }
        val d = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        // 알림 폭은 화면이 아니라 이 창의 너비를 기준으로 잡는다 (작은 팝업 창에서 잘리지 않게)
        val availW = if (root.width > 0) root.width else act.resources.displayMetrics.widthPixels

        // 이전 알림은 바로 치운다
        removeWindowToast()
        root.findViewWithTag<View>(TAG)?.let {
            it.animate().cancel()
            root.removeView(it)
        }

        val bg: Int = ThemeColors.get(root, com.google.android.material.R.attr.colorOnSurface, 0xFF303030.toInt())
        val fg: Int = ThemeColors.get(root, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val pillBg = GradientDrawable().apply {
            setColor((bg and 0x00FFFFFF) or 0xF0000000.toInt())
            cornerRadius = dp(if (actionLabel != null) 28 else 24).toFloat()
        }
        var actionView: TextView? = null
        val tv: View = if (actionLabel == null) {
            TextView(act).apply {
                tag = TAG
                text = msg
                setTextColor(fg)
                textSize = 14f
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                maxWidth = (availW * 0.86f).toInt().coerceAtMost(dp(480))
                setPadding(dp(18), dp(12), dp(18), dp(12))
                background = pillBg
                raiseToTop(this, dp(TOAST_Z_DP))
            }
        } else {
            // 알림 바탕이 어두우면 밝은 초록, 밝으면 진한 초록 (라이트·다크 테마 모두에서 잘 보이게)
            val accent: Int = if (androidx.core.graphics.ColorUtils.calculateLuminance(bg) < 0.5) 0xFF5FDB8A.toInt() else 0xFF1E8E4E.toInt()
            LinearLayout(act).apply {
                tag = TAG
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), dp(8), dp(8), dp(8))
                background = pillBg
                raiseToTop(this, dp(TOAST_Z_DP))
                val texts = LinearLayout(act).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(act).apply {
                        text = msg
                        setTextColor(fg)
                        textSize = 14f
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.MIDDLE
                    })
                    if (!sub.isNullOrBlank()) addView(TextView(act).apply {
                        text = sub
                        setTextColor((fg and 0x00FFFFFF) or 0xB3000000.toInt())
                        textSize = 12f
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    })
                }
                addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                actionView = TextView(act).apply {
                    text = actionLabel
                    setTextColor(accent)
                    textSize = 14f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setPadding(dp(16), dp(10), dp(16), dp(10))
                }
                addView(actionView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
            }
        }
        val bottomInset = ViewCompat.getRootWindowInsets(root)
            ?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val pillMaxW = (availW * 0.92f).toInt().coerceAtMost(dp(520))
        val toastBottom = (if (lift > 0) lift else bottomInset + dp(88)) + DownloadProgressCard.occupiedHeight(root)
        // 바텀시트 · 대화상자 · 팝업은 별도 창이라 이 창 안에서 아무리 높이를 올려도 그 아래에 깔린다.
        // 그런 창이 떠 있어(이 창이 입력 초점을 잃음) 알림이 가려질 때는, 맨 위에 새 창을 하나 더 띄워 거기에 그린다.
        var inOwnWindow = false
        if (!act.hasWindowFocus()) {
            try {
                val wp = WindowManager.LayoutParams(
                    if (actionLabel != null) pillMaxW else WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    y = toastBottom
                    windowAnimations = 0
                }
                act.windowManager.addView(tv, wp)
                windowToast = act to tv
                inOwnWindow = true
            } catch (e: Exception) { /* 창을 못 띄우면 아래처럼 이 창 안에 그린다 */ }
        }
        if (!inOwnWindow) {
            root.addView(
                tv,
                FrameLayout.LayoutParams(
                    if (actionLabel != null) pillMaxW else FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                ).apply {
                    // 다운로드 진행 카드가 떠 있으면 그 카드 위로 올린다 (진행 카드가 아래, 일반 알림이 위)
                    this.bottomMargin = toastBottom
                }
            )
            // 뒤늦게 붙은 다른 뷰에 가려지지 않게 맨 위로 (높이로도 위에 있지만 같은 높이끼리의 순서도 맞춘다)
            tv.bringToFront()
        }

        fun detach() {
            if (windowToast?.second === tv) removeWindowToast() else (tv.parent as? ViewGroup)?.removeView(tv)
        }

        val animate = Motion.enabled(act)
        val hold = if (actionLabel != null) 6000L else (1800L + msg.length * 40L).coerceAtMost(3800L)
        if (animate) {
            tv.alpha = 0f
            tv.translationY = dp(14).toFloat()
            tv.animate().alpha(1f).translationY(0f).setDuration(180).start()
        }

        fun dismiss(dx: Float = 0f, dy: Float = dp(10).toFloat()) {
            if (tv.parent == null) return
            if (animate) {
                tv.animate().alpha(0f).translationX(dx).translationY(dy).setDuration(160)
                    .withEndAction { detach() }.start()
            } else {
                detach()
            }
        }
        val auto = Runnable { dismiss() }
        tv.postDelayed(auto, hold)

        // 만지고 있는 동안은 사라지지 않고, 아래나 옆으로 밀거나 톡 치면 바로 치운다
        var downX = 0f
        var downY = 0f
        var downLocalX = 0f
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    downLocalX = e.x
                    v.animate().cancel()
                    v.removeCallbacks(auto)
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    v.translationX = e.rawX - downX
                    v.translationY = (e.rawY - downY).coerceAtLeast(0f)
                    v.alpha = (1f - Math.abs(v.translationX) / (v.width * 1.2f)).coerceIn(0.3f, 1f)
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    val mx = e.rawX - downX
                    val my = e.rawY - downY
                    val tap = Math.abs(mx) < dp(8) && Math.abs(my) < dp(8)
                    val onButton = tap && actionView != null && onAction != null &&
                        downLocalX >= (actionView!!.left - dp(12))
                    when {
                        onButton -> {
                            dismiss()
                            try { onAction!!.invoke() } catch (ex: Exception) { /* 무시 */ }
                        }
                        tap -> dismiss()
                        Math.abs(mx) > v.width * 0.3f -> dismiss(dx = if (mx > 0) v.width.toFloat() else -v.width.toFloat(), dy = v.translationY)
                        my > dp(36) -> dismiss(dx = v.translationX, dy = dp(60).toFloat())
                        else -> {
                            v.animate().translationX(0f).translationY(0f).alpha(1f).setDuration(140).start()
                            v.postDelayed(auto, 1500)
                        }
                    }
                    true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    v.animate().translationX(0f).translationY(0f).alpha(1f).setDuration(140).start()
                    v.postDelayed(auto, 1500)
                    true
                }
                else -> false
            }
        }
    }
}
