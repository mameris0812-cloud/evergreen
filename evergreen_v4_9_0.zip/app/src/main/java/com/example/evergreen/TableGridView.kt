package com.example.evergreen

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * AI 답변 속 마크다운 표를 그리는 뷰. 칸(자식)을 왼쪽 위부터 한 줄씩 [cols] 개씩 놓는다.
 *
 * - 폭은 줄 폭에 맞춘다(내용이 적어도 창 폭까지 칸이 고르게 늘어난다).
 * - 내용이 너무 길면 짧은 칸은 그대로 두고 긴 칸만 줄여 글이 칸 안에서 줄바꿈된다. 칸마다 최소 폭은 가장 긴 낱말이라
 *   「구분」 같은 짧은 칸이 글자 하나 폭으로 눌리지 않는다.
 * - 같은 줄의 칸은 높이를 가장 큰 칸에 맞춰 바탕색이 끝까지 차오른다.
 * 칸 사이의 [gap] 틈으로 이 뷰의 배경색이 비쳐 얇은 선이 된다 (바깥 테두리도 같은 틈).
 */
class TableGridView(context: Context) : ViewGroup(context) {

    var cols = 1
    var gap = 1

    private var colW = IntArray(0)
    private var rowH = IntArray(0)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val n = childCount
        val c = max(1, cols)
        val rows = (n + c - 1) / c
        val nat = IntArray(c)
        val minW = IntArray(c)
        val unspec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        for (i in 0 until n) {
            val ch = getChildAt(i)
            ch.measure(unspec, unspec)
            val k = i % c
            nat[k] = max(nat[k], ch.measuredWidth)
            minW[k] = max(minW[k], minWidthOf(ch))
        }
        for (k in 0 until c) minW[k] = min(minW[k], nat[k])

        val mode = MeasureSpec.getMode(widthMeasureSpec)
        val gaps = gap * (c + 1)
        val natSum = nat.sum()
        val avail = if (mode == MeasureSpec.UNSPECIFIED) natSum + gaps else MeasureSpec.getSize(widthMeasureSpec)
        val cellsA = max(0, avail - gaps)

        val w = IntArray(c)
        if (natSum <= cellsA) {
            // 남는 폭은 내용 폭에 비례해 나눠 창 폭을 꽉 채운다
            var used = 0
            for (k in 0 until c) {
                w[k] = if (natSum > 0) nat[k] + ((cellsA - natSum).toLong() * nat[k] / natSum).toInt() else cellsA / c
                used += w[k]
            }
            w[c - 1] += cellsA - used
        } else if (minW.sum() >= cellsA) {
            // 낱말 하나도 못 담을 만큼 좁다: 최소 폭 비율로 나눠 줄인다
            val ms = max(1, minW.sum())
            var used = 0
            for (k in 0 until c) { w[k] = (cellsA.toLong() * minW[k] / ms).toInt(); used += w[k] }
            w[c - 1] += cellsA - used
        } else {
            // 짧은 칸은 그대로, 긴 칸만 같은 폭 t 까지 줄인다 (칸마다 최소 폭 이상)
            var lo = 0
            var hi = nat.maxOrNull() ?: 0
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                var s = 0
                for (k in 0 until c) s += max(minW[k], min(nat[k], mid))
                if (s <= cellsA) lo = mid else hi = mid - 1
            }
            var used = 0
            var capped = 0
            for (k in 0 until c) {
                w[k] = max(minW[k], min(nat[k], lo))
                used += w[k]
                if (nat[k] > w[k]) capped++
            }
            var left = cellsA - used
            if (capped > 0) {
                var k = 0
                while (left > 0 && k < c * 2) {
                    val j = k % c
                    if (nat[j] > w[j]) { w[j]++; left-- }
                    k++
                }
            }
        }
        colW = w

        val h = IntArray(rows)
        for (i in 0 until n) {
            val ch = getChildAt(i)
            ch.measure(MeasureSpec.makeMeasureSpec(w[i % c], MeasureSpec.EXACTLY), unspec)
            h[i / c] = max(h[i / c], ch.measuredHeight)
        }
        rowH = h
        for (i in 0 until n) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(w[i % c], MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(h[i / c], MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(avail, h.sum() + gap * (rows + 1))
    }

    /** 칸의 최소 폭: 가장 긴 낱말 + 안쪽 여백 (낱말은 칸 안에서도 끊기지 않게) */
    private fun minWidthOf(v: View): Int {
        val tv = v as? TextView ?: return v.measuredWidth
        var best = 0f
        for (word in tv.text.split(' ', '\n')) best = max(best, tv.paint.measureText(word))
        return best.toInt() + tv.paddingLeft + tv.paddingRight + 2
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val c = max(1, cols)
        var y = gap
        for (row in rowH.indices) {
            var x = gap
            for (k in 0 until c) {
                val i = row * c + k
                if (i >= childCount) break
                val ch = getChildAt(i)
                ch.layout(x, y, x + colW[k], y + rowH[row])
                x += colW[k] + gap
            }
            y += rowH[row] + gap
        }
    }
}
