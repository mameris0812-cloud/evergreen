package com.example.evergreen

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * AI 답변을 소리 내어 읽어 준다 (기기의 음성 합성 엔진 사용, 인터넷 필요 없음).
 * 긴 답은 문장 끝에서 잘라 이어서 읽고, 마크다운 기호 · 코드 · 주소는 읽지 않는다.
 */
class ReadAloud(private val ctx: Context, private val onState: (Boolean) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var queued: String? = null
    private var lastId = ""
    private var gen = 0

    var speaking = false
        private set

    fun speak(raw: String) {
        stop()
        val text = clean(raw)
        if (text.isBlank()) return
        gen++
        setSpeaking(true)
        val engine = tts
        if (engine == null) {
            queued = text
            init()
        } else if (ready) {
            play(engine, text)
        } else {
            queued = text
        }
    }

    fun stop() {
        gen++
        queued = null
        try { tts?.stop() } catch (e: Exception) { }
        setSpeaking(false)
    }

    fun release() {
        gen++
        queued = null
        try { tts?.stop() } catch (e: Exception) { }
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        ready = false
        setSpeaking(false)
    }

    private fun setSpeaking(v: Boolean) {
        if (speaking == v) return
        speaking = v
        onState(v)
    }

    private fun init() {
        if (failed) { setSpeaking(false); return }
        tts = TextToSpeech(ctx.applicationContext) { status ->
            main.post {
                if (status != TextToSpeech.SUCCESS) {
                    failed = true
                    tts = null
                    queued = null
                    setSpeaking(false)
                    return@post
                }
                ready = true
                val t = queued
                queued = null
                val e = tts
                if (t != null && e != null && speaking) play(e, t)
            }
        }
    }

    private fun play(e: TextToSpeech, text: String) {
        // 한글이 섞인 답은 한국어, 아니면 기기 기본 언어로 읽는다
        val hangul = text.count { it in '가'..'힣' }
        val loc = if (hangul >= 2 || hangul * 4 >= text.length) Locale.KOREAN else Locale.getDefault()
        try {
            val r = e.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) e.setLanguage(Locale.getDefault())
        } catch (ex: Exception) { }
        val my = gen
        val parts = split(text)
        lastId = "ev_tts_${my}_${parts.size - 1}"
        e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == lastId) main.post { if (gen == my) setSpeaking(false) }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { if (gen == my) setSpeaking(false) }
            }
        })
        parts.forEachIndexed { i, p ->
            val r = e.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "ev_tts_${my}_$i")
            if (r != TextToSpeech.SUCCESS) { main.post { if (gen == my) setSpeaking(false) }; return }
        }
    }

    companion object {
        private val codeBlock = Regex("```[\\s\\S]*?(```|$)")
        private val inlineCode = Regex("`([^`]*)`")
        private val link = Regex("\\[([^\\]]*)]\\((?:[^)]*)\\)")
        private val bareUrl = Regex("https?://\\S+")
        private val tableBar = Regex("^\\s*\\|?[\\s:|-]+\\|?\\s*$", RegexOption.MULTILINE)
        private val mdMarks = Regex("(?m)^\\s{0,3}(#{1,6}|>|[-*+]|\\d+\\.)\\s+|[*_~#>|]+")
        private val spaces = Regex("[ \\t]+")
        private val manyLines = Regex("\\n{2,}")

        /** 소리 내어 읽기 좋게 다듬는다 */
        fun clean(s: String): String {
            var t = s
            t = t.replace(codeBlock, "\n코드는 생략할게요.\n")
            t = t.replace(inlineCode) { it.groupValues[1] }
            t = t.replace(link) { it.groupValues[1] }
            t = t.replace(bareUrl, "")
            t = t.replace(tableBar, "")
            t = t.replace(mdMarks, " ")
            t = t.replace(spaces, " ")
            t = t.replace(manyLines, "\n")
            return t.trim()
        }

        /** 합성 엔진의 한 번 읽기 한도(약 4000자) 안에 들게 문장 끝에서 자른다 */
        fun split(text: String, max: Int = 3000): List<String> {
            if (text.length <= max) return listOf(text)
            val out = ArrayList<String>()
            var rest = text
            while (rest.length > max) {
                var cut = rest.lastIndexOfAny(charArrayOf('\n', '.', '!', '?', '。', '요', '다'), max - 1)
                if (cut < max / 2) cut = max - 1
                out.add(rest.substring(0, cut + 1).trim())
                rest = rest.substring(cut + 1)
            }
            if (rest.isNotBlank()) out.add(rest.trim())
            return out.filter { it.isNotBlank() }
        }
    }
}

/**
 * 음성 입력: 말하는 동안 글이 입력창에 실시간으로 채워진다 (기기의 음성 인식 서비스 사용).
 * 권한(마이크)은 부르는 쪽이 먼저 받아 둔다.
 */
class VoiceInput(
    private val ctx: Context,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onEnd: (error: String?) -> Unit
) {
    private var rec: SpeechRecognizer? = null
    private var got = false

    var listening = false
        private set

    fun available() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun start(): Boolean {
        if (listening) return true
        if (!available()) return false
        val r = try { SpeechRecognizer.createSpeechRecognizer(ctx) } catch (e: Exception) { null } ?: return false
        rec = r
        got = false
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                // 대략 -2 ~ 10 dB → 0 ~ 1
                onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (!t.isNullOrEmpty()) { got = true; onPartial(t) }
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (!t.isNullOrEmpty()) { got = true; onFinal(t) }
                finish(null)
            }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        if (got) null else "목소리를 못 들었어요. 다시 눌러 말해 보세요"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "마이크 권한이 필요해요"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                        "음성 인식에 연결하지 못했어요. 인터넷을 확인해 주세요"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "음성 인식이 바빠요. 잠시 뒤 다시 눌러 주세요"
                    SpeechRecognizer.ERROR_CLIENT -> null   // 우리가 멈춘 경우
                    else -> "음성 입력을 쓸 수 없어요"
                }
                finish(msg)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        listening = true
        return try {
            r.startListening(i)
            true
        } catch (e: Exception) {
            finish(null)
            false
        }
    }

    /** 말하기를 마친다 (지금까지 들은 말은 결과로 온다) */
    fun stop() {
        if (!listening) return
        try { rec?.stopListening() } catch (e: Exception) { finish(null) }
    }

    /** 결과를 기다리지 않고 버린다 (창이 닫힐 때) */
    fun cancel() {
        if (!listening && rec == null) return
        listening = false
        try { rec?.cancel() } catch (e: Exception) { }
        try { rec?.destroy() } catch (e: Exception) { }
        rec = null
    }

    private fun finish(error: String?) {
        if (!listening && rec == null) return
        listening = false
        try { rec?.destroy() } catch (e: Exception) { }
        rec = null
        onEnd(error)
    }
}

/** 듣는 동안 입력칸에 뜨는 소리 파형: 막대 다섯 개가 목소리 크기에 맞춰 서로 다른 박자로 출렁인다 */
class VoiceWaveView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE5484D.toInt()
        strokeCap = Paint.Cap.ROUND
    }
    private val n = 5
    private val cur = FloatArray(n) { 0.2f }
    private var level = 0f
    private var phase = 0f

    fun push(l: Float) {
        level = maxOf(level, l)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val bar = w / (n * 2 - 1)
        paint.strokeWidth = bar
        phase += 0.2f
        for (i in 0 until n) {
            val wob = 0.5f + 0.5f * kotlin.math.sin(phase + i * 1.1f)
            val target = (0.2f + level * (0.4f + 0.4f * wob)).coerceIn(0.2f, 1f)
            cur[i] += (target - cur[i]) * 0.3f
            val bh = (h * cur[i]).coerceAtLeast(bar)
            val x = bar * (2 * i) + bar / 2f
            c.drawLine(x, h / 2f - bh / 2f + bar / 2f, x, h / 2f + bh / 2f - bar / 2f, paint)
        }
        level *= 0.94f
        postInvalidateOnAnimation()
    }
}
