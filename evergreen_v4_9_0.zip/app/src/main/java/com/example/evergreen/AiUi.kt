package com.example.evergreen

import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/** AI 정리 화면들이 함께 쓰는 「기다리는 창」과 「이렇게 정리할까요?」 제안 창 */
object AiUi {
    private val pool = Executors.newCachedThreadPool()
    private val ui = Handler(Looper.getMainLooper())

    /**
     * [work] 를 다른 스레드에서 돌리는 동안 취소할 수 있는 안내 창을 띄우고, 끝나면 화면 스레드에서 [done] 을 부른다.
     * [message] 가 null 이면 창 없이 조용히 돌린다 (화면 안에서 직접 「찾는 중」을 보여 줄 때).
     * [work] 가 [AiOneShot.Fail] 을 던지면 그 메시지를 알림으로 띄우고 [onError] 를 부른다. 창을 취소했거나 화면이 닫혔으면 [done] 은 부르지 않는다.
     */
    fun <T> run(
        act: AppCompatActivity,
        message: String?,
        work: () -> T,
        onError: (() -> Unit)? = null,
        done: (T) -> Unit
    ) {
        var cancelled = false
        val dialog: AlertDialog? = message?.let {
            ThemedDialogBuilder(act)
                .setMessage(it)
                .setCancelable(false)
                .setNegativeButton("취소") { _, _ -> cancelled = true }
                .show()
        }
        pool.execute {
            var result: T? = null
            var error: String? = null
            try {
                result = work()
            } catch (e: AiOneShot.Fail) {
                error = e.message ?: "AI 요청에 실패했어요"
            } catch (e: Exception) {
                error = "AI 요청에 실패했어요"
            }
            val err = error
            val res = result
            ui.post {
                try { dialog?.dismiss() } catch (e: Exception) { }
                if (cancelled || act.isFinishing || act.isDestroyed) return@post
                if (err != null) {
                    ListUi.toast(act, err)
                    onError?.invoke()
                } else {
                    @Suppress("UNCHECKED_CAST")
                    done(res as T)
                }
            }
        }
    }

    /**
     * 제안 목록을 체크박스로 보여 주고, 사용자가 고른 것만 [onApply] 로 넘긴다.
     * [checked] 는 처음 체크 상태. 아무것도 안 고르면 「적용」은 안내만 하고 창을 닫는다.
     */
    fun propose(
        act: AppCompatActivity,
        title: String,
        labels: List<String>,
        checked: BooleanArray,
        positive: String,
        onApply: (BooleanArray) -> Unit
    ) {
        val state = checked.copyOf()
        ThemedDialogBuilder(act)
            .setTitle(title)
            .setMultiChoiceItems(labels.toTypedArray(), state) { _, which, isChecked -> state[which] = isChecked }
            .setNegativeButton("닫기", null)
            .setPositiveButton(positive) { _, _ ->
                if (state.none { it }) ListUi.toast(act, "고른 것이 없어요") else onApply(state)
            }
            .show()
    }
}
