package com.example.evergreen

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.Base64
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * 'AI로 만들기': 한 줄 설명으로 확장 프로그램(MV3)을 만든다.
 *
 * 흐름: ① 생성(4 Hydrogen, 안 되면 앱의 다른 모델로 대신) → ② 검증(구조 · 파일 · 쓰면 안 되는 API · 숨은 웹뷰 문법 검사)
 * → 실패하면 오류를 모델에게 돌려줘 최대 [MAX_FIX]번 고친다 → ③ 미리보기 카드용 [Draft] 를 돌려준다.
 * 설치는 여기서 하지 않는다. 사용자가 카드에서 '적용'을 눌러야 [ExtensionManager.installDraft] 가 설치한다.
 *
 * 적용 범위(어느 사이트에 쓰는지)는 모델이 정하지 않는다. 사용자가 고른 [Scope] 를 매니페스트에 앱이 직접 써 넣는다.
 * 아이콘은 모델이 SVG 로 그리고, 앱이 숨은 웹뷰에서 PNG(48 · 128)로 바꿔 넣는다. 못 그리면 이름 첫 글자 아이콘으로 대신한다.
 * 설치된 확장은 AI 없이 [applyManualEdit] 로 직접 고칠 수도 있다(설명 · 적용 범위 · 제외할 사이트 · 코드).
 */
object ExtensionForge {

    const val MAX_FIX = 2
    private const val MAX_FILES = 8
    private const val MAX_FILE_CHARS = 60_000
    /** AI 에게 보내는 고칠 내용 · 앞의 결과 글자 수 한도 (앞의 결과는 파일 8개 × 6만 자까지 안 잘리게) */
    private const val FEEDBACK_MAX = 1_500
    private const val PREV_MAX = 250_000

    enum class ScopeKind { THIS_SITE, ALL, CUSTOM }

    /** 사용자가 고른 적용 범위. [patterns] 는 매니페스트의 match pattern 이다 */
    class Scope(val kind: ScopeKind, val patterns: List<String>, val excludes: List<String> = emptyList()) {
        val isAll: Boolean get() = kind == ScopeKind.ALL
    }

    class Draft(
        val name: String,
        val description: String,
        val manifest: JSONObject,
        val files: Map<String, String>,
        val scope: Scope,
        /** 쓰는 기능 칩: "콘텐츠 스크립트" · "백그라운드" · "저장소" … */
        val features: List<String>,
        /** 검사에서 끝내 못 고친 문제 / 주의할 점. 비어 있으면 검사 통과 */
        val problems: List<String>,
        val request: String
    ) {
        val passed: Boolean get() = problems.isEmpty()

        /** 모델이 적어 준 "이 코드가 하는 일" 한국어 줄들 (미리보기 카드의 코드 요약) */
        var summary: List<String> = emptyList()

        /** 모델이 적어 준 "이번에 고친 점" 한국어 줄들 (고치기 결과 화면의 고친 내용 요약). 처음 만들 때는 비어 있다 */
        var changes: List<String> = emptyList()

        /** 지금까지 만든 판의 기록 [{rev, date, request, files, ok}] — 확장 폴더의 evergreen_ai_history.json 로 저장된다 */
        var revs: JSONArray = JSONArray()

        /** 고치기 직전 판의 소스 {rev, files} (되돌릴 때를 위해 한 판만 남긴다) */
        var prevSource: JSONObject? = null

        /** 모델이 그린 아이콘 원본(SVG). 못 그렸거나 대신한 아이콘이면 null */
        var iconSvg: String? = null

        /** 확장 폴더에 들어갈 아이콘 PNG: 경로(icons/icon48.png · icons/icon128.png) → 바이트 */
        var icons: Map<String, ByteArray> = emptyMap()

        fun carryFrom(o: Draft): Draft { summary = o.summary; changes = o.changes; revs = o.revs; prevSource = o.prevSource; iconSvg = o.iconSvg; icons = o.icons; return this }
    }

    const val HISTORY_FILE = "evergreen_ai_history.json"
    const val ICON_48 = "icons/icon48.png"
    const val ICON_128 = "icons/icon128.png"
    const val ICON_SVG = "icons/icon.svg"
    private const val ICON_TAG = "아이콘: "
    private const val MAX_SVG_CHARS = 6_000

    class ForgeException(msg: String) : Exception(msg)

    /** 쓸 수 있는 chrome.* 이름공간 (앱의 ext_shim.js 가 실제로 구현한 것 가운데 AI 확장에 맞는 것만) */
    private val ALLOWED_NS = listOf(
        "runtime", "storage", "tabs", "scripting", "alarms", "i18n", "contextMenus", "menus",
        "action", "commands", "notifications", "webNavigation", "declarativeNetRequest"
    )

    /** 일부러 막는 이름공간: 사용자 데이터를 읽거나 앱이 구현하지 않은 것 */
    private val BLOCKED_NS = listOf(
        "cookies", "history", "bookmarks", "downloads", "management", "proxy", "privacy", "webRequest",
        "debugger", "tabCapture", "desktopCapture", "vpnProvider", "devtools", "printerProvider", "wallpaper",
        "identity", "pageCapture", "browsingData", "sessions", "topSites", "system", "tts", "userScripts"
    )

    private val ALLOWED_PERMS = setOf(
        "storage", "activeTab", "scripting", "alarms", "contextMenus", "notifications", "tabs",
        "webNavigation", "declarativeNetRequest", "declarativeNetRequestWithHostAccess", "unlimitedStorage"
    )

    // ───────────────────────── 만들기 ─────────────────────────

    /**
     * 확장 프로그램을 만든다. 인터넷을 쓰므로 화면 스레드가 아닌 곳에서만 부른다.
     * @param onStep 진행 단계 알림 ("write" · "check" · "fix:1" …). 부르는 스레드가 화면 스레드가 아닐 수 있다
     * @param previous 다시 만들기: 앞에서 만든 초안 (그것을 바탕으로 고친다)
     */
    fun generate(
        act: Activity,
        request: String,
        scope: Scope,
        pageUrl: String?,
        onStep: (String) -> Unit,
        previous: Draft? = null,
        feedback: String? = null
    ): Draft {
        if (Looper.myLooper() == Looper.getMainLooper()) throw ForgeException("화면 스레드에서는 쓸 수 없어요")
        val prefs = Prefs(act)
        val key = prefs.geminiKey
        if (key.isBlank()) throw ForgeException("설정에서 Gemini API 키를 먼저 저장해 주세요")
        val req = request.trim()
        if (req.isEmpty()) throw ForgeException("어떤 확장 프로그램을 만들지 적어 주세요")
        if (req.length > 2_000) throw ForgeException("설명이 너무 길어요 (2000자 이하)")

        val system = systemPrompt(scope)
        val history = ArrayList<ChatMsg>()
        history.add(ChatMsg("user", userPrompt(req, scope, pageUrl, previous, feedback)))

        var lastDraft: Draft? = null
        var lastProblems: List<String> = emptyList()
        var attempt = 0
        while (true) {
            onStep(if (attempt == 0) "write" else "fix:$attempt")
            val raw = callModel(key, system, history)
            history.add(ChatMsg("model", raw))
            onStep("check")
            val parsed = try { parse(raw, req, scope, previous?.name) } catch (e: ForgeException) { null to listOf(e.message ?: "형식이 맞지 않아요") }
            val draft = parsed.first
            val problems = ArrayList<String>(parsed.second)
            if (draft != null && previous != null) {
                stamp(draft.manifest, previous, feedback)
                draft.revs = previous.revs
                draft.prevSource = JSONObject().put("rev", previous.manifest.optString("version").substringBefore('.').toIntOrNull() ?: 1)
                    .put("ver", shownVersion(previous.manifest))
                    .put("files", JSONObject(previous.files))
            }
            if (draft != null && previous != null && !feedback.isNullOrBlank() && sameAsPrev(draft, previous))
                problems.add("앞의 결과와 코드가 똑같아요. 이번 요청을 실제로 코드에 반영해 주세요: " + feedback.take(200))
            if (draft != null) problems.addAll(validate(act, draft, onStep))
            if (draft != null) resolveIcon(act, draft, previous, problems)
            if (draft != null) lastDraft = draft
            lastProblems = problems
            if (problems.isEmpty() && draft != null) return draft
            if (attempt >= MAX_FIX) break
            attempt++
            history.add(
                ChatMsg(
                    "user",
                    "방금 만든 확장 프로그램을 검사했더니 아래 문제가 있어요. 문제를 모두 고친 전체 결과를 같은 JSON 형식으로 다시 보내 주세요.\n" +
                        problems.joinToString("\n") { "- $it" }
                )
            )
        }
        val d = lastDraft ?: throw ForgeException("확장 프로그램을 만들지 못했어요: " + (lastProblems.firstOrNull() ?: "알 수 없는 오류"))
        // 아이콘만 끝내 못 고쳤다면 그것 때문에 막지 않는다: 이름 첫 글자 아이콘으로 대신한다
        if (d.icons.isEmpty()) { d.icons = fallbackIcon(d.name); d.iconSvg = null }
        val rest = lastProblems.filterNot { it.startsWith(ICON_TAG) }
        return Draft(d.name, d.description, d.manifest, d.files, d.scope, d.features, rest, d.request).carryFrom(d)
    }

    private fun callModel(key: String, system: String, history: List<ChatMsg>): String {
        val sb = StringBuilder()
        var err: String? = null
        val tick = AgentProgress.Throttle()
        try {
            GeminiClient().stream(
                key, GeminiModels.HYDROGEN.id, system, history,
                onDelta = {
                    sb.append(it)
                    if (tick.ok()) AgentProgress.phase(1, 4, "코드를 쓰는 중", AgentProgress.chars(sb.length))
                }, onDone = { }, onError = { err = it },
                json = true, thinking = GeminiThinking.LOW
            )
        } catch (e: Exception) {
            err = e.message ?: "AI 요청에 실패했어요"
        }
        err?.let { throw ForgeException(it) }
        val out = sb.toString().trim()
        if (out.isEmpty()) throw ForgeException("AI가 빈 답을 보냈어요")
        return out
    }

    // ───────────────────────── 프롬프트 ─────────────────────────

    private fun systemPrompt(scope: Scope): String = buildString {
        append("당신은 안드로이드 브라우저 앱 'evergreen'의 확장 프로그램 제작자입니다. 사용자의 한 줄 설명을 Chrome 확장 프로그램(Manifest V3)으로 만듭니다.\n")
        append("반드시 아래 JSON 한 개만 출력하세요. 설명 글 · 마크다운 · 코드 울타리(```)는 쓰지 마세요.\n")
        append("{\"name\":\"짧은 한국어 이름\",\"description\":\"한 문장 설명(한국어)\",\"summary\":[\"이 코드가 하는 일을 한국어 한 줄씩, 2~4개\"],\"changes\":[\"앞의 결과에서 이번에 바꾼 점을 한국어 한 줄씩, 1~4개 (처음 만들 때는 빈 배열)\"],\"manifest\":{…manifest.json 내용…},\"files\":{\"경로\":\"파일 내용\", …},\"icon\":\"<svg …>…</svg>\"}\n\n")
        append("[규칙]\n")
        append("- manifest_version 은 3, version 은 \"1.0\". manifest 에 적은 모든 파일(js · css · html)은 files 에 있어야 합니다. 파일은 ")
        append(MAX_FILES).append("개 이하, 파일당 ").append(MAX_FILE_CHARS / 1000).append("천 자 이하입니다.\n")
        append("- 대부분은 콘텐츠 스크립트(content_scripts 의 js · css)만으로 충분합니다. 백그라운드(service_worker)·팝업·알람은 꼭 필요할 때만 쓰세요.\n")
        append("- 적용 범위는 앱이 정합니다. content_scripts 의 matches 에는 [\"")
        append(scope.patterns.joinToString("\",\"")).append("\"] 를 그대로 쓰고, host_permissions 는 쓰지 마세요(앱이 넣습니다).\n")
        append("- 쓸 수 있는 API: ").append(ALLOWED_NS.joinToString(" · ") { "chrome.$it" }).append(". 이 앱의 웹뷰는 크롬과 완전히 같지 않으므로 이 목록 밖의 API 는 쓰지 마세요.\n")
        append("- 쓰면 안 되는 API: ").append(BLOCKED_NS.joinToString(" · ")).append(" 과 chrome.webRequest(차단·수정). 요청을 막아야 하면 declarativeNetRequest 를 쓰세요.\n")
        append("- permissions 는 ").append(ALLOWED_PERMS.joinToString(" · ")).append(" 중에서 필요한 것만 쓰세요.\n")
        append("- 금지: eval · new Function · 문자열을 받는 setTimeout · 원격 코드 불러오기(외부 <script src> · importScripts(http…)) · 외부 서버로 데이터 보내기 · document.cookie 읽기 · 비밀번호/카드 입력칸 읽기.\n")
        append("- 페이지 글자를 바꿀 때는 사이트 디자인을 깨지 않게 !important 는 꼭 필요한 곳에만 쓰고, 동적으로 늘어나는 페이지는 MutationObserver 로 따라가되 성능을 해치지 마세요.\n")
        append("- 코드는 짧고 읽기 쉽게 쓰고, 주석은 한국어로 한 줄씩만 다세요. 사용자가 켜고 끌 수 있어야 하는 기능이면 chrome.storage.local 에 설정을 저장하세요.\n")
        append("- icon 은 이 확장의 아이콘이 될 SVG 한 개(문자열)입니다. viewBox=\"0 0 128 128\" 로 쓰고 width · height 는 쓰지 마세요. 둥근 사각형 배경(rect rx=\"28\", 선명한 색 한 가지 또는 linearGradient) 위에, 이 확장이 하는 일을 한눈에 알려 주는 단순한 도형 한두 개(흰색 등 배경과 크게 대비되는 색)를 그립니다.\n")
        append("- icon 에서 쓸 수 있는 태그: svg · defs · linearGradient · radialGradient · stop · rect · circle · ellipse · line · polyline · polygon · path · g. text · image · use · style · script · foreignObject · 외부 주소(href · url(http…)) · on… 속성은 쓰지 마세요. ").append(MAX_SVG_CHARS).append("자 이하입니다.\n")
        append("- [AI 기능] 사용자가 요약 · 번역 · 분류 · 질문 답하기 · 글 다듬기/쓰기 처럼 'AI 가 해야 하는 일'을 요청했을 때만 확장 안에 AI 를 넣으세요. 그런 요청이 없으면 AI 코드를 넣지 마세요. 넣는다면 반드시 앱이 주는 전역 객체 evergreenAI 로만 부릅니다(콘텐츠 스크립트 · 백그라운드 · 팝업 어디서나 chrome 처럼 그냥 쓰면 됩니다). 외부 AI 서버(OpenAI · Gemini · Claude 주소)에 직접 요청하거나 API 키를 코드에 적는 것은 금지입니다.\n")
        append("  · await evergreenAI.available() → 키가 저장돼 있으면 true. false 면 \"설정에서 Gemini API 키를 저장해 주세요\" 같은 안내를 화면에 보여 주세요.\n")
        append("  · await evergreenAI.ask(\"질문/지시 + 대상 글\", {system:\"역할 · 말투 안내\", json:false, quality:\"fast\"}) → 답 글자(string). json:true 면 JSON 으로 읽은 값(객체/배열)을 돌려줍니다. quality 는 \"fast\"(기본, 빠름) 또는 \"smart\"(어려운 추론 · 긴 글).\n")
        append("  · await evergreenAI.chat([{role:\"user\",text:\"…\"},{role:\"model\",text:\"…\"},{role:\"user\",text:\"…\"}], {system:…}) → 여러 턴 대화. 마지막은 user 여야 합니다.\n")
        append("  · 실패하면 예외(Error)가 던져집니다. try/catch 로 잡아 사용자가 알아볼 한국어 메시지를 화면에 보여 주세요. 한 번에 보내는 글은 너무 길지 않게 자르고(수만 자 이하), 1분에 20번까지만 부를 수 있으니 한 번에 여러 번 부르지 말고 묶어서 보내세요. 페이지 글을 AI 에 보낼 때 비밀번호 · 카드 입력칸 · 쿠키는 넣지 마세요.\n")
        append("  · AI 를 쓰는 확장은 요약 · 결과를 보여 줄 자리(팝업 · 페이지 위 작은 패널 · 버튼)를 직접 만들어야 하며, 결과 글은 innerHTML 이 아니라 textContent 로 넣으세요.\n")
        if (scope.isAll) append("- 이 확장은 모든 사이트에 적용됩니다. 로그인 · 결제 화면의 입력칸은 건드리지 마세요.\n")
    }

    private fun userPrompt(req: String, scope: Scope, pageUrl: String?, prev: Draft?, feedback: String?): String = buildString {
        val fix = prev != null && !feedback.isNullOrBlank()
        if (fix) {
            // 고치기: 이번 요청이 가장 앞에서 가장 중요하게 보이게 한다 (처음 설명이 앞에 있으면 모델이 처음 설명대로 되돌려 버린다)
            append("[고치기] 앞에서 만든 확장 프로그램을 아래 요청대로 고쳐 주세요.\n")
            append("이번 요청(가장 중요, 반드시 코드에 반영): ").append(feedback!!.take(FEEDBACK_MAX)).append(if (feedback.length > FEEDBACK_MAX) "…" else "").append("\n")
            append("처음 만들 때의 설명(참고만): ").append(req).append("\n")
        } else {
            append("만들 것: ").append(req).append("\n")
        }
        append("적용 범위: ").append(scope.patterns.joinToString(", ")).append("\n")
        if (!pageUrl.isNullOrBlank()) append("사용자가 지금 보는 페이지: ").append(pageUrl.take(200)).append("\n")
        if (prev != null) {
            if (fix) {
                append("\n규칙: 요청과 관계없는 동작 · 화면은 그대로 두세요. 요청한 대로 코드가 실제로 달라져야 하며 앞의 코드를 그대로 돌려주면 안 됩니다. ")
                append("files 에는 바뀐 파일만이 아니라 모든 파일의 전체 내용을 적으세요. changes 에는 이번 요청으로 바꾼 점을 적으세요.")
            } else append("\n앞에서 만든 결과를 바탕으로 다시 만들어 주세요.")
            append("\n앞의 결과:\n").append(JSONObject().put("name", prev.name).put("description", prev.description)
                .put("manifest", prev.manifest).put("files", JSONObject(prev.files)).put("icon", prev.iconSvg ?: "").toString().take(PREV_MAX))
            append("\n아이콘은 바꿀 필요가 없으면 앞의 icon 을 그대로 다시 적으세요.")
            append("\nchanges 에는 앞의 결과와 달라진 점만, 사용자가 이해할 말로 적으세요 (코드 줄이 아니라 동작이 어떻게 달라졌는지). summary 는 고친 뒤 코드 전체가 하는 일입니다.")
        }
    }

    /** 고치기 결과가 앞과 같은지 (버전 · 기록 칸만 다르면 같은 것) */
    private fun sameAsPrev(d: Draft, prev: Draft): Boolean {
        if (d.files != prev.files) return false
        fun key(m: JSONObject) = JSONObject(m.toString()).apply { remove("version"); remove("evergreen_ai") }.toString()
        return key(d.manifest) == key(prev.manifest)
    }

    // ───────────────────────── 읽기 ─────────────────────────

    /** 모델의 답을 읽어 [Draft] 로 만든다. 읽을 수 없으면 (null, 문제 목록) */
    private fun parse(raw: String, req: String, scope: Scope, forceName: String? = null): Pair<Draft?, List<String>> {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = try { JSONObject(s) } catch (e: Exception) {
            val a = s.indexOf('{'); val b = s.lastIndexOf('}')
            if (a < 0 || b <= a) return null to listOf("JSON 형식이 아니에요")
            try { JSONObject(s.substring(a, b + 1)) } catch (e2: Exception) { return null to listOf("JSON 을 읽을 수 없어요: ${e2.message}") }
        }
        val problems = ArrayList<String>()
        val mj = o.optJSONObject("manifest") ?: return null to listOf("manifest 가 없어요")
        val filesObj = o.optJSONObject("files") ?: JSONObject()
        val files = LinkedHashMap<String, String>()
        val keys = filesObj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val path = k.replace('\\', '/').removePrefix("/")
            if (path.isEmpty() || path.contains("..") || path == "manifest.json") { problems.add("파일 경로가 올바르지 않아요: $k"); continue }
            val v = filesObj.optString(k)
            if (v.length > MAX_FILE_CHARS) problems.add("$path 가 너무 길어요 (${MAX_FILE_CHARS / 1000}천 자 이하)")
            files[path] = v
        }
        if (files.size > MAX_FILES) problems.add("파일이 너무 많아요 (${MAX_FILES}개 이하)")
        val name = forceName ?: o.optString("name").ifBlank { mj.optString("name") }.trim().take(40)
        if (name.isBlank()) problems.add("name 이 비었어요")
        val desc = o.optString("description").ifBlank { mj.optString("description") }.trim().take(200)

        normalizeManifest(mj, name.ifBlank { "AI 확장" }, desc, scope, req)
        val dr = Draft(name.ifBlank { "AI 확장" }, desc, mj, files, scope, features(mj, files), emptyList(), req)
        o.optString("icon").trim().takeIf { it.isNotEmpty() && it != "null" }?.let { dr.iconSvg = it }
        o.optJSONArray("summary")?.let { a -> dr.summary = (0 until a.length()).map { a.optString(it).trim().take(80) }.filter { it.isNotEmpty() }.take(4) }
        o.optJSONArray("changes")?.let { a -> dr.changes = (0 until a.length()).map { a.optString(it).trim().take(100) }.filter { it.isNotEmpty() }.take(4) }
        return dr to problems
    }

    /** 고치기 전후 파일을 견줘 파일별로 한 줄씩: "content.js · +5줄 −2줄", 새 파일 · 지운 파일. 바뀐 게 없으면 빈 목록 */
    fun fileChanges(old: Map<String, String>, new: Map<String, String>): List<String> {
        val out = ArrayList<String>()
        fun counts(t: String): HashMap<String, Int> {
            val m = HashMap<String, Int>()
            for (l in t.lines()) { val k = l.trim(); if (k.isNotEmpty()) m[k] = (m[k] ?: 0) + 1 }
            return m
        }
        for ((path, text) in new) {
            val before = old[path]
            if (before == null) { out.add("$path · 새 파일"); continue }
            if (before == text) continue
            val a = counts(before); val b = counts(text)
            var plus = 0; var minus = 0
            for ((k, n) in b) plus += maxOf(0, n - (a[k] ?: 0))
            for ((k, n) in a) minus += maxOf(0, n - (b[k] ?: 0))
            out.add("$path · +${plus}줄 −${minus}줄")
        }
        for (path in old.keys) if (path !in new) out.add("$path · 지웠어요")
        return out
    }

    /** 모델이 쓴 매니페스트를 앱의 규칙에 맞게 고친다: 범위는 사용자가 고른 것으로, 위험한 키는 지운다 */
    private fun normalizeManifest(mj: JSONObject, name: String, desc: String, scope: Scope, req: String) {
        mj.put("manifest_version", 3)
        mj.put("name", name)
        mj.put("version", "1.0")
        if (desc.isNotBlank()) mj.put("description", desc)
        listOf("key", "update_url", "externally_connectable", "content_security_policy", "oauth2", "chrome_url_overrides", "devtools_page", "omnibox").forEach { mj.remove(it) }

        // 권한: 허용 목록에 없는 것은 뺀다
        val perms = JSONArray()
        val pa = mj.optJSONArray("permissions")
        if (pa != null) for (i in 0 until pa.length()) {
            val p = pa.optString(i)
            if (p in ALLOWED_PERMS) perms.put(p)
        }
        mj.put("permissions", perms)
        mj.remove("optional_permissions")
        mj.remove("optional_host_permissions")

        // 적용 범위: 콘텐츠 스크립트의 matches 와 host_permissions 를 사용자가 고른 것으로 덮어쓴다
        val pats = JSONArray().also { a -> scope.patterns.forEach { a.put(it) } }
        val cs = mj.optJSONArray("content_scripts")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.optJSONObject(i) ?: continue
            c.put("matches", JSONArray(pats.toString()))
            c.remove("exclude_matches")
            if (scope.excludes.isNotEmpty()) c.put("exclude_matches", JSONArray().also { a -> scope.excludes.forEach { a.put(it) } })
            c.remove("include_globs")
            c.remove("exclude_globs")
        }
        val needsHosts = mj.has("background") || (mj.optJSONArray("permissions")?.let { a -> (0 until a.length()).any { a.optString(it) == "scripting" || a.optString(it) == "declarativeNetRequestWithHostAccess" } } ?: false)
        mj.remove("host_permissions")
        if (needsHosts) mj.put("host_permissions", JSONArray(pats.toString()))
        mj.remove("web_accessible_resources")
        // 아이콘 경로는 앱이 정한다 (PNG 는 설치할 때 [toZip] 이 함께 넣는다)
        val ic = JSONObject().put("48", ICON_48).put("128", ICON_128)
        mj.put("icons", ic)
        mj.optJSONObject("action")?.put("default_icon", JSONObject(ic.toString()))
        // 이 확장이 AI 로 만들어졌다는 표시 (카드에 'AI 제작' 으로 보인다)
        mj.put("evergreen_ai", JSONObject().put("request", req.take(300)).put("requests", JSONArray().put(req.take(300))).put("created", System.currentTimeMillis()))
    }

    internal fun features(mj: JSONObject, files: Map<String, String> = emptyMap()): List<String> {
        val f = ArrayList<String>()
        if ((mj.optJSONArray("content_scripts")?.length() ?: 0) > 0) f.add("콘텐츠 스크립트")
        if (mj.has("background")) f.add("백그라운드")
        if (mj.has("action") && mj.optJSONObject("action")?.optString("default_popup").orEmpty().isNotEmpty()) f.add("팝업")
        val perms = mj.optJSONArray("permissions")
        val ps = (0 until (perms?.length() ?: 0)).map { perms!!.optString(it) }
        if ("storage" in ps || "unlimitedStorage" in ps) f.add("저장소")
        if ("alarms" in ps) f.add("알람")
        if ("notifications" in ps) f.add("알림")
        if ("contextMenus" in ps) f.add("길게 누르기 메뉴")
        if ("declarativeNetRequest" in ps || "declarativeNetRequestWithHostAccess" in ps) f.add("요청 차단")
        if ("tabs" in ps) f.add("탭 정보")
        if (files.values.any { USES_AI.containsMatchIn(it) }) f.add("AI 기능")
        return f
    }

    /** 크롬 확장 버전 글: 숫자 1~4개를 점으로 이어 쓴다(각 0~65535, 전부 0은 안 됨). 예: 2 · 1.5 · 1.2.3 */
    fun isValidVersion(v: String): Boolean {
        if (!Regex("""\d{1,5}(\.\d{1,5}){0,3}""").matches(v)) return false
        val nums = v.split('.').map { it.toInt() }
        return nums.all { it <= 65535 } && nums.any { it != 0 }
    }

    /** 사람에게 보여 줄 버전: 끝의 ".0" 은 뺀다 (2.0 → 2, 1.5 → 1.5) */
    fun shownVersion(m: JSONObject): String {
        var s = m.optString("version").ifBlank { "1" }
        while (s.contains('.') && s.endsWith(".0")) s = s.removeSuffix(".0")
        return s
    }

    /** 매니페스트에서 적용 범위(콘텐츠 스크립트 matches · exclude_matches)를 읽는다 */
    fun scopeOf(mj: JSONObject): Scope {
        val pats = ArrayList<String>()
        mj.optJSONArray("content_scripts")?.optJSONObject(0)?.optJSONArray("matches")?.let { a -> for (i in 0 until a.length()) pats.add(a.optString(i)) }
        if (pats.isEmpty()) mj.optJSONArray("host_permissions")?.let { a -> for (i in 0 until a.length()) pats.add(a.optString(i)) }
        val excl = ArrayList<String>()
        mj.optJSONArray("content_scripts")?.optJSONObject(0)?.optJSONArray("exclude_matches")?.let { a -> for (i in 0 until a.length()) excl.add(a.optString(i)) }
        return if ("<all_urls>" in pats) Scope(ScopeKind.ALL, listOf("<all_urls>"), excl) else Scope(ScopeKind.CUSTOM, pats, excl)
    }

    /** 고치기: 버전을 올리고(1.0 → 2.0) 지금까지의 요청 기록에 이번 요청을 더한다 */
    private fun stamp(mj: JSONObject, prev: Draft, change: String?, version: String? = null) {
        val rev = (prev.manifest.optString("version").substringBefore('.').toIntOrNull() ?: 1) + 1
        mj.put("version", version ?: "$rev.0")
        val reqs = JSONArray()
        val old = prev.manifest.optJSONObject("evergreen_ai")?.optJSONArray("requests")
        if (old != null) for (i in 0 until old.length()) reqs.put(old.optString(i)) else reqs.put(prev.request)
        if (!change.isNullOrBlank()) reqs.put(change.substringBefore("\n\n[").trim().take(300))
        val ai = mj.optJSONObject("evergreen_ai") ?: JSONObject().also { mj.put("evergreen_ai", it) }
        ai.put("requests", reqs)
        prev.manifest.optJSONObject("evergreen_ai")?.optLong("created")?.takeIf { it > 0 }?.let { ai.put("created", it) }
    }

    // ───────────────────────── 검증 ─────────────────────────

    private val EVAL = Regex("""(?<![\w.$])eval\s*\(|new\s+Function\s*\(|setTimeout\s*\(\s*["'`]|setInterval\s*\(\s*["'`]""")
    private val REMOTE_CODE = Regex("""importScripts\s*\(\s*["'`]https?:|<script[^>]+src\s*=\s*["']?https?:""", RegexOption.IGNORE_CASE)
    private val EXTERNAL_NET = Regex("""(fetch|XMLHttpRequest|sendBeacon|WebSocket|EventSource)\b[^;\n]{0,120}https?://""")
    private val COOKIE = Regex("""document\.cookie""")
    /** 확장 코드가 앱의 AI(evergreenAI)를 쓰는지 */
    internal val USES_AI = Regex("""\bevergreenAI\b""")
    /** 외부 AI 서버를 직접 부르거나 AI 키를 코드에 적은 흔적 */
    private val DIRECT_AI = Regex("""generativelanguage\.googleapis|api\.openai\.com|api\.anthropic\.com|openrouter\.ai|AIza[0-9A-Za-z_-]{20,}|sk-[A-Za-z0-9]{20,}""")
    private val NS_USE = Regex("""\b(?:chrome|browser)\s*\.\s*([A-Za-z]+)""")

    /** 설치 전 검사. 고쳐야 하는 문제 목록 (비어 있으면 통과) */
    private fun validate(act: Activity, d: Draft, onStep: (String) -> Unit): List<String> {
        val out = ArrayList<String>()
        val mj = d.manifest

        // 매니페스트가 가리키는 파일이 모두 있는지
        fun need(path: String?, where: String) {
            val p = path?.trim().orEmpty().removePrefix("/")
            if (p.isEmpty()) return
            if (!d.files.containsKey(p)) out.add("$where 에 적은 파일 '$p' 이(가) files 에 없어요")
        }
        val cs = mj.optJSONArray("content_scripts")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.optJSONObject(i) ?: continue
            for (k in listOf("js", "css")) c.optJSONArray(k)?.let { a -> for (j in 0 until a.length()) need(a.optString(j), "content_scripts.$k") }
            if ((c.optJSONArray("js")?.length() ?: 0) == 0 && (c.optJSONArray("css")?.length() ?: 0) == 0) out.add("content_scripts 에 js 나 css 가 없어요")
        }
        mj.optJSONObject("background")?.let { b ->
            need(b.optString("service_worker"), "background.service_worker")
            if (b.optString("service_worker").isBlank()) out.add("background 에는 service_worker 를 적어야 해요")
        }
        mj.optJSONObject("action")?.let { a -> need(a.optString("default_popup"), "action.default_popup") }
        need(mj.optString("options_page"), "options_page")
        mj.optJSONObject("options_ui")?.let { need(it.optString("page"), "options_ui.page") }
        if ((cs?.length() ?: 0) == 0 && !mj.has("background") && !(mj.optJSONObject("action")?.has("default_popup") ?: false))
            out.add("실행되는 코드가 없어요 (content_scripts · background · action 중 하나는 있어야 해요)")
        if (cs != null && cs.length() > 0 && d.scope.patterns.isEmpty()) out.add("적용할 사이트가 비어 있어요")

        // 코드 검사
        val syntaxJobs = ArrayList<Pair<String, String>>()
        for ((path, text) in d.files) {
            val lower = path.lowercase()
            if (lower.endsWith(".js") || lower.endsWith(".mjs") || lower.endsWith(".html")) {
                if (EVAL.containsMatchIn(text)) out.add("$path: eval · new Function · 문자열 setTimeout 은 쓸 수 없어요")
                if (REMOTE_CODE.containsMatchIn(text)) out.add("$path: 원격 코드를 불러올 수 없어요 (모든 코드는 파일에 넣어 주세요)")
                if (EXTERNAL_NET.containsMatchIn(text)) out.add("$path: 외부 주소로 요청을 보낼 수 없어요")
                if (COOKIE.containsMatchIn(text)) out.add("$path: document.cookie 는 읽을 수 없어요")
                if (DIRECT_AI.containsMatchIn(text)) out.add("$path: 외부 AI 서버를 직접 부르거나 API 키를 적을 수 없어요 (AI 는 evergreenAI.ask / evergreenAI.chat 으로 부르세요)")
                NS_USE.findAll(text).map { it.groupValues[1] }.toSet().forEach { ns ->
                    if (ns in BLOCKED_NS) out.add("$path: chrome.$ns 는 이 앱에서 쓸 수 없어요" + if (ns == "webRequest") " (declarativeNetRequest 를 쓰세요)" else "")
                }
            }
            if ((lower.endsWith(".js") || lower.endsWith(".mjs")) && text.isNotBlank()) syntaxJobs.add(path to text)
        }
        // 문법 검사: 숨은 웹뷰에서 new Function() 으로 읽어 본다 (실행은 하지 않는다)
        val isModuleBg = mj.optJSONObject("background")?.optString("type") == "module"
        for ((path, text) in syntaxJobs) {
            val err = SyntaxCheck.run(act, text, module = isModuleBg && path == mj.optJSONObject("background")?.optString("service_worker"))
            if (err != null) out.add("$path: 문법 오류 — $err")
        }
        // 시험 실행: 정적 검사를 통과했을 때만 숨은 웹뷰에서 한 번 돌려 시작 오류를 잡는다
        if (out.isEmpty()) {
            onStep("run")
            val bg = mj.optJSONObject("background")?.optString("service_worker")?.removePrefix("/")?.takeIf { it.isNotBlank() && d.files.containsKey(it) }
            val cs2 = ArrayList<String>()
            if (cs != null) for (i in 0 until cs.length()) cs.optJSONObject(i)?.optJSONArray("js")?.let { a ->
                for (j in 0 until a.length()) a.optString(j).removePrefix("/").let { if (d.files.containsKey(it)) cs2.add(it) }
            }
            out.addAll(DryRun.run(act, d.files, bg, cs2.distinct(), isModuleBg))
        }
        return out
    }

    // ───────────────────────── 설치용 zip ─────────────────────────

    /** 초안을 .zip 바이트로 묶는다 ([ExtensionManager.installDraft] 가 이것을 풀어 설치한다) */
    fun toZip(d: Draft): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            z.putNextEntry(ZipEntry("manifest.json"))
            z.write(d.manifest.toString(2).toByteArray(Charsets.UTF_8))
            z.closeEntry()
            for ((p, t) in d.files) {
                z.putNextEntry(ZipEntry(p))
                z.write(t.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            for ((p, b) in d.icons) {
                z.putNextEntry(ZipEntry(p))
                z.write(b)
                z.closeEntry()
            }
            d.iconSvg?.takeIf { d.icons.isNotEmpty() }?.let { svg ->
                z.putNextEntry(ZipEntry(ICON_SVG))
                z.write(svg.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            z.putNextEntry(ZipEntry(HISTORY_FILE))
            z.write(historyOf(d).toString(1).toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
        return bos.toByteArray()
    }

    /** 확장 폴더에 남기는 기록: 요청 · 판별 파일 목록, 그리고 고치기 직전 판의 소스 */
    private fun historyOf(d: Draft): JSONObject {
        val revs = JSONArray()
        val curVer = shownVersion(d.manifest)
        val from = maxOf(0, d.revs.length() - 19)
        for (i in from until d.revs.length()) {
            val o = d.revs.optJSONObject(i) ?: continue
            if (i == d.revs.length() - 1 && o.optString("ver") == curVer) continue   // 버전이 안 오른 편집은 같은 판의 기록을 갈아쓴다
            // 바꿀 수 있게 소스를 남기는 판은 최근 10개까지, 같은 버전 이름은 가장 새것만
            if (i < d.revs.length() - 9 || o.optString("ver") == curVer) o.remove("snap")
            revs.put(o)
        }
        val reqs = d.manifest.optJSONObject("evergreen_ai")?.optJSONArray("requests")
        revs.put(
            JSONObject()
                .put("rev", d.manifest.optString("version").substringBefore('.').toIntOrNull() ?: 1)
                .put("ver", curVer)
                .put("snap", JSONObject().put("manifest", d.manifest).put("files", JSONObject(d.files)))
                .put("date", System.currentTimeMillis())
                .put("request", reqs?.optString((reqs.length() - 1).coerceAtLeast(0)) ?: d.request)
                .put("files", JSONArray(d.files.keys.toList()))
                .put("ok", d.passed)
        )
        val o = JSONObject().put("revs", revs)
        d.prevSource?.let { o.put("prev", it) }
        return o
    }

    // ───────────────────────── 적용 범위 만들기 ─────────────────────────

    /** 주소(또는 호스트)에서 match pattern 들을 만든다. 예: playentry.org 는 정확한 주소와 하위 주소 두 패턴(스킴 · 호스트 · 경로 전체)이 된다 */
    fun siteScope(url: String?): Scope? {
        val host = try { android.net.Uri.parse(url ?: "").host } catch (e: Exception) { null }
        if (host.isNullOrBlank() || !host.contains('.') && host != "localhost") return null
        val base = host.removePrefix("www.")
        return Scope(ScopeKind.THIS_SITE, listOf("*://$base/*", "*://*.$base/*"))
    }

    fun allSitesScope() = Scope(ScopeKind.ALL, listOf("<all_urls>"))

    /** 직접 입력: 줄바꿈 · 쉼표로 나눈 주소들. 하나도 못 읽으면 null */
    fun customScope(text: String): Scope? {
        val pats = parseSites(text)
        if (pats.isEmpty()) return null
        if ("<all_urls>" in pats) return allSitesScope()
        return Scope(ScopeKind.CUSTOM, pats)
    }

    /** 주소 글(줄바꿈 · 쉼표 · 띄어쓰기 · 세미콜론으로 나눔)을 match pattern 들로 바꾼다. 하나도 못 읽으면 빈 목록, 모든 사이트를 뜻하면 ["<all_urls>"] */
    fun parseSites(text: String): List<String> {
        val out = ArrayList<String>()
        for (raw in text.split('\n', ',', ' ', ';')) {
            val s = raw.trim()
            if (s.isEmpty()) continue
            if (s == "<all_urls>" || s == "*" || s == "*://*/*") return listOf("<all_urls>")
            if (Regex("""^(\*|https?|file)://[^/]+/.*$""").matches(s)) { out.add(s); continue }
            val host = s.removePrefix("https://").removePrefix("http://").substringBefore('/').removePrefix("www.").trim()
            if (host.isEmpty() || !Regex("""^[A-Za-z0-9.*-]+$""").matches(host) || !host.contains('.')) continue
            out.add("*://$host/*")
            if (!host.startsWith("*.")) out.add("*://*.$host/*")
        }
        return out.distinct()
    }

    /** [parseSites] 의 반대: 적용 범위 패턴을 사람이 읽고 고칠 수 있는 줄들로 (예: a.com 과 그 하위 주소 두 패턴은 a.com 한 줄) — 주석 안에 슬래시+별표를 쓰면 중첩 주석이 열리므로 쓰지 않는다 */
    fun patternsToText(patterns: List<String>): String {
        val hosts = patterns.mapNotNull { Regex("""^\*://([^/]+)/\*$""").matchEntire(it)?.groupValues?.get(1) }.toSet()
        val lines = ArrayList<String>()
        for (p in patterns) {
            val h = Regex("""^\*://([^/]+)/\*$""").matchEntire(p)?.groupValues?.get(1)
            if (h == null) { lines.add(p); continue }
            if (h.startsWith("*.") && h.removePrefix("*.") in hosts) continue
            lines.add(h)
        }
        return lines.distinct().joinToString("\n")
    }

    // ───────────────────────── 직접 편집 ─────────────────────────

    /**
     * 설치된 AI 확장을 AI 없이 직접 고친 새 판을 만든다. 이름은 그대로(이름이 id 를 정한다)이고, 설명 · 적용 범위 · 제외할 사이트 · 코드를 바꿀 수 있다.
     * 코드를 바꿨으면 AI 가 만든 것과 같은 검사(문법 · 권한 · 시험 실행)를 거치고, 못 고친 문제는 [Draft.problems] 로 돌려준다 (화면 스레드가 아닌 곳에서 부른다).
     */
    fun applyManualEdit(act: Activity, prev: Draft, description: String, scope: Scope, files: Map<String, String>, version: String?, onStep: (String) -> Unit): Draft {
        if (Looper.myLooper() == Looper.getMainLooper()) throw ForgeException("화면 스레드에서는 쓸 수 없어요")
        val desc = description.trim().take(200)
        val parts = ArrayList<String>()
        if (scope.patterns != prev.scope.patterns || scope.excludes != prev.scope.excludes) parts.add("적용 범위")
        val filesChanged = files != prev.files
        if (filesChanged) parts.add("코드")
        if (desc != prev.description.trim()) parts.add("설명")
        val ver = version?.trim()?.takeIf { it.isNotEmpty() } ?: prev.manifest.optString("version")   // 안 정하면 버전은 그대로
        if (!isValidVersion(ver)) throw ForgeException("버전은 숫자를 점으로 이어 써 주세요 (예: 2 · 1.5 · 1.2.3)")
        val verChanged = ver != prev.manifest.optString("version")
        if (verChanged) parts.add("버전")
        if (parts.isEmpty()) throw ForgeException("바뀐 곳이 없어요")
        for ((path, text) in files) if (text.length > MAX_FILE_CHARS) throw ForgeException("$path 가 너무 길어요 (${MAX_FILE_CHARS / 1000}천 자 이하)")

        val mj = JSONObject(prev.manifest.toString())
        normalizeManifest(mj, prev.name, desc.ifBlank { prev.description }, scope, prev.request)
        stamp(mj, prev, "직접 편집: " + parts.joinToString(" · ") + (if (verChanged) " (v${shownVersion(mj)})" else ""), ver)
        val icons = prev.icons.ifEmpty { fallbackIcon(prev.name) }
        val draft = Draft(prev.name, desc.ifBlank { prev.description }, mj, LinkedHashMap(files), scope, features(mj, files), emptyList(), prev.request)
        draft.iconSvg = prev.iconSvg
        draft.icons = icons
        draft.revs = prev.revs
        draft.prevSource = JSONObject().put("rev", prev.manifest.optString("version").substringBefore('.').toIntOrNull() ?: 1)
            .put("ver", shownVersion(prev.manifest))
            .put("files", JSONObject(prev.files))
        if (!filesChanged) return draft
        val problems = validate(act, draft, onStep)
        if (problems.isEmpty()) return draft
        return Draft(draft.name, draft.description, mj, draft.files, scope, draft.features, problems, prev.request).carryFrom(draft)
    }

    // ───────────────────────── 아이콘 ─────────────────────────

    private val SVG_BAD = Regex("""<\s*(script|image|foreignObject|style|text|tspan|iframe|use|animate|set)\b|\bon\w+\s*=|href\s*=|javascript:|url\(\s*["']?\s*(?:https?:|data:|//|javascript:)""", RegexOption.IGNORE_CASE)

    /** 모델이 적은 아이콘 SVG 의 글만 보고 하는 검사. 고칠 문제(없으면 null) */
    private fun checkSvgText(svg: String): String? {
        val t = svg.trim()
        if (t.length > MAX_SVG_CHARS) return "icon 이 너무 길어요 (${MAX_SVG_CHARS}자 이하)"
        if (!t.startsWith("<svg", ignoreCase = true) || !t.contains("</svg>", ignoreCase = true)) return "icon 은 <svg> 로 시작해 </svg> 로 끝나는 SVG 한 개여야 해요"
        if (SVG_BAD.containsMatchIn(t)) return "icon 에 쓸 수 없는 태그나 속성이 있어요 (text · image · use · style · script · href · 외부 주소 · on… 은 금지)"
        return null
    }

    /** 크기(128)와 이름공간을 앱이 맞춰 준다 */
    private fun prepareSvg(svg: String): String {
        val s = svg.trim()
        val m = Regex("""<svg\b[^>]*>""", RegexOption.IGNORE_CASE).find(s) ?: return s
        var tag = m.value
        tag = tag.replace(Regex("""\s(width|height)\s*=\s*("[^"]*"|'[^']*')""", RegexOption.IGNORE_CASE), "")
        val head = Regex("<svg", RegexOption.IGNORE_CASE)
        if (!tag.contains("xmlns=")) tag = head.replaceFirst(tag, "<svg xmlns=\"http://www.w3.org/2000/svg\"")
        if (!tag.contains("viewBox", ignoreCase = true)) tag = head.replaceFirst(tag, "<svg viewBox=\"0 0 128 128\"")
        tag = head.replaceFirst(tag, "<svg width=\"128\" height=\"128\"")
        return s.replaceFirst(m.value, tag)
    }

    /**
     * 초안의 아이콘을 정한다: 모델이 그린 SVG 를 검사하고 PNG 로 바꿔 [Draft.icons] 에 넣는다.
     * 고칠 문제가 있으면 [problems] 에 (아이콘: …) 로 더한다 — 모델이 다시 그리게 하려고.
     */
    private fun resolveIcon(act: Activity, d: Draft, prev: Draft?, problems: MutableList<String>) {
        val raw = d.iconSvg
        if (raw.isNullOrBlank()) {
            // 고치는 중에 모델이 icon 을 안 적으면 앞의 것을 그대로 쓴다
            if (prev != null && prev.icons.isNotEmpty()) { d.iconSvg = prev.iconSvg; d.icons = prev.icons; return }
            if (prev != null) { d.icons = fallbackIcon(d.name); d.iconSvg = null; return }
            d.iconSvg = null
            problems.add(ICON_TAG + "icon(SVG) 을 적어 주세요")
            return
        }
        checkSvgText(raw)?.let { d.iconSvg = null; problems.add(ICON_TAG + it); return }
        val svg = prepareSvg(raw)
        if (prev != null && prev.icons.isNotEmpty() && svg == prev.iconSvg) { d.iconSvg = svg; d.icons = prev.icons; return }
        val r = IconRender.run(act, svg)
        when {
            r.first != null -> { d.iconSvg = svg; d.icons = r.first!! }
            r.second != null -> { d.iconSvg = null; problems.add(ICON_TAG + r.second) }
            else -> { d.iconSvg = null; d.icons = fallbackIcon(d.name) }   // 그리는 도구가 못 돌면 막지 않는다
        }
    }

    /** 아이콘을 못 그렸을 때 대신 쓰는 아이콘: 이름에서 색을 정한 둥근 사각형 + 이름 첫 글자 */
    fun fallbackIcon(name: String): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        for ((path, size) in listOf(ICON_48 to 48, ICON_128 to 128)) {
            val sz = size.toFloat()
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val hue = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.shader = LinearGradient(
                0f, 0f, sz, sz,
                Color.HSVToColor(floatArrayOf(hue, 0.62f, 0.92f)),
                Color.HSVToColor(floatArrayOf((hue + 35f) % 360f, 0.72f, 0.72f)),
                Shader.TileMode.CLAMP
            )
            c.drawRoundRect(RectF(0f, 0f, sz, sz), sz * 0.22f, sz * 0.22f, bg)
            val ch = name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "E"
            val tp = Paint(Paint.ANTI_ALIAS_FLAG)
            tp.color = Color.WHITE
            tp.textSize = sz * 0.52f
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.textAlign = Paint.Align.CENTER
            c.drawText(ch, sz / 2f, sz / 2f - (tp.descent() + tp.ascent()) / 2f, tp)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            bmp.recycle()
            out[path] = bos.toByteArray()
        }
        return out
    }

    /**
     * SVG 를 숨은 웹뷰의 canvas 에 그려 PNG(48 · 128)로 바꾼다. 읽을 수 없거나 거의 비어 있으면 (null, 이유),
     * 도구가 못 돌면 (null, null). 화면 스레드가 아닌 곳에서 부르면 결과를 기다린다.
     */
    private object IconRender {
        private val ui = Handler(Looper.getMainLooper())

        class Bridge(private val onDone: (String) -> Unit) {
            @JavascriptInterface
            fun done(r: String) { onDone(r) }
        }

        fun run(act: Activity, svg: String): Pair<Map<String, ByteArray>?, String?> {
            if (act.isFinishing || act.isDestroyed) return null to null
            val latch = CountDownLatch(1)
            val box = arrayOfNulls<String>(1)
            var wv: WebView? = null
            ui.post {
                try {
                    val w = WebView(act.applicationContext)
                    wv = w
                    w.settings.javaScriptEnabled = true
                    w.settings.allowFileAccess = false
                    w.settings.allowContentAccess = false
                    w.addJavascriptInterface(Bridge { r -> box[0] = r; latch.countDown() }, "EvIcon")
                    val js = "var svg=" + JSONObject.quote(svg) + ";" +
                        "var img=new Image();" +
                        "img.onload=function(){try{var o={},bad=false;[48,128].forEach(function(s){" +
                        "var c=document.createElement('canvas');c.width=s;c.height=s;var x=c.getContext('2d');x.drawImage(img,0,0,s,s);" +
                        "if(s===48){var d=x.getImageData(0,0,s,s).data,n=0;for(var i=3;i<d.length;i+=4){if(d[i]>16)n++}if(n<s*s*0.05)bad=true}" +
                        "o[s]=c.toDataURL('image/png').split(',')[1]});" +
                        "EvIcon.done(bad?'err:아이콘이 거의 비어 있어요. 도형을 더 크고 또렷하게 그려 주세요':JSON.stringify(o))}catch(e){EvIcon.done('err:'+(e&&e.message?e.message:e))}};" +
                        "img.onerror=function(){EvIcon.done('err:SVG 를 읽을 수 없어요 (문법을 확인해 주세요)')};" +
                        "img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);"
                    w.loadDataWithBaseURL("https://ext.evergreen.invalid/", "<html><body><script>$js</script></body></html>", "text/html", "utf-8", null)
                } catch (e: Exception) {
                    box[0] = null; latch.countDown()   // 도구가 못 돌면 막지 않는다
                }
            }
            val done = latch.await(8, TimeUnit.SECONDS)
            ui.post { try { wv?.destroy() } catch (e: Exception) { } }
            val r = box[0]
            if (!done || r == null) return null to null
            if (r.startsWith("err:")) return null to r.removePrefix("err:").take(160)
            return try {
                val o = JSONObject(r)
                val m = LinkedHashMap<String, ByteArray>()
                m[ICON_48] = Base64.decode(o.getString("48"), Base64.DEFAULT)
                m[ICON_128] = Base64.decode(o.getString("128"), Base64.DEFAULT)
                m to null
            } catch (e: Exception) { null to null }
        }
    }

    // ───────────────────────── 숨은 웹뷰 문법 검사 ─────────────────────────

    /** 자바스크립트 문법만 확인한다 (코드는 실행하지 않는다). 화면 스레드가 아닌 곳에서 부르면 결과를 기다린다 */
    private object SyntaxCheck {
        private val ui = Handler(Looper.getMainLooper())

        /** 웹뷰의 검사 결과를 받는 다리 (익명 객체는 reflection 접근이 막힐 수 있어 이름 있는 클래스로 둔다) */
        class Bridge(private val onDone: (String) -> Unit) {
            @JavascriptInterface
            fun done(r: String) { onDone(r) }
        }

        fun run(act: Activity, code: String, module: Boolean): String? {
            if (act.isFinishing || act.isDestroyed) return null
            val latch = CountDownLatch(1)
            val box = arrayOfNulls<String>(1)
            var wv: WebView? = null
            ui.post {
                try {
                    val w = WebView(act.applicationContext)
                    wv = w
                    w.settings.javaScriptEnabled = true
                    w.settings.allowFileAccess = false
                    w.settings.allowContentAccess = false
                    w.addJavascriptInterface(Bridge { r -> box[0] = r; latch.countDown() }, "EvSyn")
                    w.loadDataWithBaseURL(
                        "https://ext.evergreen.invalid/",
                        "<html><body><script>" +
                            "var src=" + JSONObject.quote(code) + ";var mod=" + module + ";" +
                            "try{ if(mod){ new Function(src.replace(/^\\s*(import|export)\\b[^;\\n]*;?/gm,'')); } else { new Function(src); } EvSyn.done('ok'); }" +
                            "catch(e){ EvSyn.done('err:'+(e&&e.message?e.message:e)); }" +
                            "</script></body></html>",
                        "text/html", "utf-8", null
                    )
                } catch (e: Exception) {
                    box[0] = "ok"; latch.countDown()   // 검사 도구가 못 돌면 막지 않는다
                }
            }
            val done = latch.await(8, TimeUnit.SECONDS)
            ui.post { try { wv?.destroy() } catch (e: Exception) { } }
            val r = box[0]
            if (!done || r == null || r == "ok") return null
            return r.removePrefix("err:").take(160)
        }
    }

    // ───────────────────────── 시험 실행 (숨은 웹뷰) ─────────────────────────

    /**
     * 만든 코드를 숨은 웹뷰에서 한 번 돌려 시작 오류를 잡는다. chrome.* 은 무엇을 불러도 조용히 받아 주는 가짜(Proxy)라서
     * 이 검사는 "코드 자체의 오류"(정의 안 된 변수 · null 을 읽는 실수 등)만 잡는다. 실제 chrome.* 호환은 앱의 shim 이 맡는다.
     * 백그라운드는 모든 오류를, 콘텐츠 스크립트는 빈 페이지에서 돌리므로 ReferenceError · SyntaxError 만 문제로 본다.
     */
    private object DryRun {
        private val ui = Handler(Looper.getMainLooper())

        class Bridge(private val onDone: (String) -> Unit) {
            @JavascriptInterface
            fun report(json: String) { onDone(json) }
        }

        private const val PRELUDE = """
var __errs=[];
function __mk(p){var f=function(){var a=arguments,cb=a[a.length-1];if(typeof cb==='function'){setTimeout(function(){try{cb()}catch(e){}},0)}return Promise.resolve(undefined)};
 return new Proxy(f,{get:function(t,k){if(k==='then'||typeof k==='symbol')return undefined;
  if(k==='addListener'||k==='removeListener'||k==='hasListener')return function(){};return __mk(p.concat(k))}})}
var __C=__mk([]);
window.chrome=__C;window.browser=__C;window.importScripts=function(){};window.evergreenAI=__mk(['evergreenAI']);
function __run(path,code,bg){try{new Function('chrome','browser',code)(__C,__C)}catch(e){__push(path,e,bg)}}
function __push(path,e,bg){var n=(e&&e.name)||'Error';if(!bg&&n!=='ReferenceError'&&n!=='SyntaxError')return;__errs.push(path+': '+n+' — '+((e&&e.message)||e))}
window.addEventListener('error',function(ev){__push('실행 중',ev.error||{name:'Error',message:ev.message},__BG)});
window.addEventListener('unhandledrejection',function(ev){__push('비동기',ev.reason||{name:'Error',message:'거부된 약속'},__BG)});
"""

        fun run(act: Activity, files: Map<String, String>, bg: String?, content: List<String>, module: Boolean): List<String> {
            if (act.isFinishing || act.isDestroyed) return emptyList()
            if (bg == null && content.isEmpty()) return emptyList()
            val latch = CountDownLatch(1)
            val box = arrayOfNulls<String>(1)
            var wv: WebView? = null
            ui.post {
                try {
                    val w = WebView(act.applicationContext)
                    wv = w
                    w.settings.javaScriptEnabled = true
                    w.settings.allowFileAccess = false
                    w.settings.allowContentAccess = false
                    w.addJavascriptInterface(Bridge { r -> box[0] = r; latch.countDown() }, "EvDry")
                    val sb = StringBuilder()
                    sb.append("<html><body><div id=\"app\"></div><script>var __BG=false;").append(PRELUDE).append("</script><script>")
                    // 백그라운드 → 콘텐츠 스크립트 순서. 모듈 백그라운드는 import/export 줄을 뺀다
                    fun add(path: String, isBg: Boolean) {
                        var code = files[path] ?: return
                        if (isBg && module) code = code.replace(Regex("(?m)^\\s*(import|export)\\b[^;\\n]*;?"), "")
                        sb.append("__BG=").append(isBg).append(";__run(").append(JSONObject.quote(path)).append(",").append(JSONObject.quote(code)).append(",").append(isBg).append(");\n")
                    }
                    if (bg != null) add(bg, true)
                    content.forEach { add(it, false) }
                    sb.append("setTimeout(function(){EvDry.report(JSON.stringify(__errs))},1500);</script></body></html>")
                    w.loadDataWithBaseURL("https://ext.evergreen.invalid/", sb.toString(), "text/html", "utf-8", null)
                } catch (e: Exception) {
                    box[0] = "[]"; latch.countDown()   // 시험 도구가 못 돌면 막지 않는다
                }
            }
            val done = latch.await(8, TimeUnit.SECONDS)
            ui.post { try { wv?.destroy() } catch (e: Exception) { } }
            val r = box[0]
            if (!done || r == null) return emptyList()
            return try {
                val a = JSONArray(r)
                (0 until a.length()).map { a.optString(it) }.distinct().take(4).map { (if (it.startsWith("실행 중") || it.startsWith("비동기")) "시작 오류 — " else "시작 오류: ") + it }
            } catch (e: Exception) { emptyList() }
        }
    }
}
