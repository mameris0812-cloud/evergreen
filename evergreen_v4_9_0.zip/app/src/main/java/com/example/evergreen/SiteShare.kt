package com.example.evergreen

import android.app.Activity
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * AI 가 만든 웹사이트(HTML 한 장)를 계정 · 토큰 없이 무료 호스팅(ship.page)에 올려 웹사이트 주소(URL)를 받는다.
 * POST https://ship.page/deploy (Content-Type: text/html, 본문이 HTML) → {"url": "https://….ship.place/"}
 * 주소를 아는 사람은 누구나 볼 수 있다. 같은 문서를 다시 공유하면 새로 올리지 않고 받아 둔 주소를 그대로 쓴다.
 */
object SiteShare {
    private const val ENDPOINT = "https://ship.page/deploy"

    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /** onDone(주소) 는 화면 스레드에서 불린다. 실패하면 알림만 띄운다 */
    fun publish(act: Activity, html: String, onDone: (String) -> Unit) {
        AppToast.show(act, "웹사이트를 올리는 중이에요…")
        Thread {
            var url: String? = null
            var err: String? = null
            try {
                val req = Request.Builder().url(ENDPOINT)
                    .header("User-Agent", "evergreen-app")
                    .post(html.toRequestBody("text/html; charset=utf-8".toMediaType()))
                    .build()
                client.newCall(req).execute().use { resp ->
                    val text = resp.body?.string() ?: ""
                    if (!resp.isSuccessful) {
                        err = "올리지 못했어요 (서버 오류 ${resp.code}). 잠시 뒤 다시 시도해 주세요"
                    } else {
                        url = runCatching { JSONObject(text).optString("url") }.getOrDefault("")
                            .ifEmpty { Regex("https://[^\\s\"]+").find(text)?.value ?: "" }
                            .takeIf { it.startsWith("https://") }
                        if (url == null) err = "웹사이트 주소를 받지 못했어요"
                    }
                }
            } catch (e: Exception) {
                err = "인터넷에 연결되어 있는지 확인해 주세요"
            }
            main.post {
                if (act.isFinishing || act.isDestroyed) return@post
                val u = url
                if (u != null) onDone(u) else AppToast.show(act, err ?: "올리지 못했어요")
            }
        }.start()
    }
}
