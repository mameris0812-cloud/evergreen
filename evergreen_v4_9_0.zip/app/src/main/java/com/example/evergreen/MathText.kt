package com.example.evergreen

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.ReplacementSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.SubscriptSpan
import android.text.style.SuperscriptSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan

/**
 * AI 답변 속 수학식( $…$ · $$…$$ · \(…\) · \[…\] )을 기호로 바꿔 보여 준다.
 * 그리스 문자 · 연산 기호 · 위/아래 첨자 · 분수 · 제곱근 · 윗줄 · 벡터 · 행렬/연립식(cases)을 글자만으로 그린다.
 * 알 수 없는 식이 나오면 원문 그대로 둔다(식 하나가 깨져도 답변 전체는 멀쩡하게).
 */
object MathText {
    private const val FLAG = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE

    // 글 속 수식 찾기: 1=$$…$$  2=\[…\]  3=\(…\)  4=$…$  (달러 금액 "$5 … $10" 은 수식으로 보지 않는다. AssistantUi.inlineRe 와 같은 규칙)
    private val mathRe = Regex(
        "\\$\\$(.+?)\\$\\$|\\\\\\[(.+?)\\\\\\]|\\\\\\((.+?)\\\\\\)|" +
            "(?<![\\\\$])\\$(?![\\s$])([^$\\n]+?)(?<![\\s\\\\])\\$(?!\\d)"
    )

    /** 한 줄 글(대화 기록의 제목 · 미리보기 등) 속 수식을 기호로 바꾼 글을 돌려준다. 수식이 없으면 원문 그대로 */
    fun render(text: String): CharSequence {
        if (!text.contains('$') && !text.contains("\\(") && !text.contains("\\[")) return text
        val out = SpannableStringBuilder()
        var last = 0
        for (m in mathRe.findAll(text)) {
            out.append(text, last, m.range.first)
            val g = m.groups
            val tex = (g[1] ?: g[2] ?: g[3] ?: g[4])?.value ?: m.value
            append(out, tex, false)
            last = m.range.last + 1
        }
        out.append(text, last, text.length)
        return out
    }

    /** tex(달러 기호 · 괄호 빼고 식만)를 out 뒤에 덧붙인다 */
    fun append(out: SpannableStringBuilder, tex: String, display: Boolean = false) {
        val src = tex.trim()
        val st = out.length
        try {
            Renderer(src).emit(out, 0, src.length, true)
        } catch (e: Exception) {
            out.delete(st, out.length)
            out.append(tex)
            return
        }
        if (out.length > st) {
            // 수식은 명조 계열 글꼴로 — 본문(고딕)과 한눈에 구분된다
            out.setSpan(TypefaceSpan("serif"), st, out.length, FLAG)
            if (display) out.setSpan(RelativeSizeSpan(1.08f), st, out.length, FLAG)
        }
    }

    // ───────────────────────── 기호 표 ─────────────────────────

    private val GREEK: Map<String, String> = mapOf(
        "alpha" to "α", "beta" to "β", "gamma" to "γ", "delta" to "δ", "epsilon" to "ε", "varepsilon" to "ε",
        "zeta" to "ζ", "eta" to "η", "theta" to "θ", "vartheta" to "ϑ", "iota" to "ι", "kappa" to "κ",
        "lambda" to "λ", "mu" to "μ", "nu" to "ν", "xi" to "ξ", "omicron" to "ο", "pi" to "π", "varpi" to "ϖ",
        "rho" to "ρ", "varrho" to "ϱ", "sigma" to "σ", "varsigma" to "ς", "tau" to "τ", "upsilon" to "υ",
        "phi" to "φ", "varphi" to "φ", "chi" to "χ", "psi" to "ψ", "omega" to "ω"
    )

    private val SYMBOLS: Map<String, String> = mapOf(
        "Gamma" to "Γ", "Delta" to "Δ", "Theta" to "Θ", "Lambda" to "Λ", "Xi" to "Ξ", "Pi" to "Π",
        "Sigma" to "Σ", "Upsilon" to "Υ", "Phi" to "Φ", "Psi" to "Ψ", "Omega" to "Ω",
        "times" to "×", "div" to "÷", "cdot" to "·", "pm" to "±", "mp" to "∓", "circ" to "∘", "ast" to "∗",
        "star" to "⋆", "bullet" to "•", "oplus" to "⊕", "otimes" to "⊗", "odot" to "⊙", "setminus" to "∖",
        "leq" to "≤", "le" to "≤", "leqslant" to "≤", "geq" to "≥", "ge" to "≥", "geqslant" to "≥",
        "neq" to "≠", "ne" to "≠", "approx" to "≈", "equiv" to "≡", "sim" to "∼", "simeq" to "≃", "cong" to "≅",
        "propto" to "∝", "doteq" to "≐", "ll" to "≪", "gg" to "≫", "lt" to "<", "gt" to ">",
        "nleq" to "≰", "ngeq" to "≱", "infty" to "∞", "partial" to "∂", "nabla" to "∇", "prime" to "′",
        "degree" to "°", "hbar" to "ℏ", "ell" to "ℓ", "aleph" to "ℵ", "Re" to "ℜ", "Im" to "ℑ", "wp" to "℘",
        "in" to "∈", "notin" to "∉", "ni" to "∋", "subset" to "⊂", "subseteq" to "⊆", "subsetneq" to "⊊",
        "nsubseteq" to "⊈", "supset" to "⊃", "supseteq" to "⊇", "cup" to "∪", "cap" to "∩",
        "bigcup" to "⋃", "bigcap" to "⋂", "emptyset" to "∅", "varnothing" to "∅",
        "forall" to "∀", "exists" to "∃", "nexists" to "∄", "neg" to "¬", "lnot" to "¬",
        "land" to "∧", "wedge" to "∧", "lor" to "∨", "vee" to "∨", "top" to "⊤", "bot" to "⊥",
        "vdash" to "⊢", "models" to "⊨", "because" to "∵", "therefore" to "∴",
        "to" to "→", "rightarrow" to "→", "leftarrow" to "←", "gets" to "←", "leftrightarrow" to "↔",
        "Rightarrow" to "⇒", "Leftarrow" to "⇐", "Leftrightarrow" to "⇔", "implies" to "⟹", "impliedby" to "⟸",
        "iff" to "⟺", "mapsto" to "↦", "longrightarrow" to "⟶", "longleftarrow" to "⟵",
        "uparrow" to "↑", "downarrow" to "↓", "nearrow" to "↗", "searrow" to "↘",
        "ldots" to "…", "dots" to "…", "dotsc" to "…", "dotsb" to "⋯", "cdots" to "⋯", "vdots" to "⋮", "ddots" to "⋱",
        "int" to "∫", "iint" to "∬", "iiint" to "∭", "oint" to "∮", "sum" to "∑", "prod" to "∏", "coprod" to "∐",
        "angle" to "∠", "measuredangle" to "∡", "triangle" to "△", "square" to "□", "blacksquare" to "■",
        "diamond" to "◇", "perp" to "⊥", "parallel" to "∥", "nparallel" to "∦", "mid" to "∣", "nmid" to "∤",
        "vert" to "|", "Vert" to "‖", "lvert" to "|", "rvert" to "|", "lbrace" to "{", "rbrace" to "}",
        "langle" to "⟨", "rangle" to "⟩", "lfloor" to "⌊", "rfloor" to "⌋", "lceil" to "⌈", "rceil" to "⌉",
        "backslash" to "\\", "checkmark" to "✓", "dagger" to "†", "S" to "§", "copyright" to "©",
        "quad" to "\u2003", "qquad" to "\u2003\u2003", "cdotp" to "·", "triangleq" to "≜"
    )

    private val FUNCS = setOf(
        "sin", "cos", "tan", "sec", "csc", "cot", "arcsin", "arccos", "arctan", "sinh", "cosh", "tanh", "coth",
        "log", "ln", "lg", "exp", "max", "min", "sup", "inf", "det", "gcd", "lcm", "lim", "limsup", "liminf",
        "dim", "ker", "deg", "arg", "mod", "Pr", "hom", "rank"
    )

    private val BB: Map<Char, String> = mapOf('R' to "ℝ", 'N' to "ℕ", 'Z' to "ℤ", 'Q' to "ℚ", 'C' to "ℂ", 'P' to "ℙ", 'H' to "ℍ")

    private val SUP: Map<Char, Char> = mapOf(
        '0' to '⁰', '1' to '¹', '2' to '²', '3' to '³', '4' to '⁴', '5' to '⁵', '6' to '⁶', '7' to '⁷', '8' to '⁸', '9' to '⁹',
        '+' to '⁺', '\u2212' to '⁻', '=' to '⁼', '(' to '⁽', ')' to '⁾', 'n' to 'ⁿ', 'i' to 'ⁱ'
    )
    private val SUB: Map<Char, Char> = mapOf(
        '0' to '₀', '1' to '₁', '2' to '₂', '3' to '₃', '4' to '₄', '5' to '₅', '6' to '₆', '7' to '₇', '8' to '₈', '9' to '₉',
        '+' to '₊', '\u2212' to '₋', '=' to '₌', '(' to '₍', ')' to '₎'
    )

    /** 분수·괄호 없이 그대로 붙여도 되는 짧은 식 */
    private val SIMPLE = Regex("[\\p{L}\\p{N}.\u2032\u2212]+(\\([^()]*\\))?")

    private val MATRIX_OPEN = mapOf("pmatrix" to "(", "bmatrix" to "[", "Bmatrix" to "{", "vmatrix" to "|", "Vmatrix" to "‖", "cases" to "{ ")
    private val MATRIX_CLOSE = mapOf("pmatrix" to ")", "bmatrix" to "]", "Bmatrix" to "}", "vmatrix" to "|", "Vmatrix" to "‖")
    private val MATRICES = setOf("pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix", "smallmatrix")

    private fun al(c: Char) = c in 'a'..'z' || c in 'A'..'Z'

    // ───────────────────────── 변환기 ─────────────────────────

    private class Renderer(val s: String) {
        private val envs = ArrayList<String>()

        fun emit(out: SpannableStringBuilder, from: Int, to: Int, ital: Boolean) {
            var i = from
            while (i < to) {
                val c = s[i]
                when {
                    c == '\\' -> i = command(out, i, to, ital)
                    c == '{' -> {
                        val e = closeOf(i, to)
                        emit(out, i + 1, e, ital)
                        i = e + 1
                    }
                    c == '}' -> i++
                    c == '^' || c == '_' -> i = script(out, i, to)
                    c == '&' -> { out.append("  "); i++ }
                    c == '~' -> { out.append('\u00A0'); i++ }
                    c == '-' -> { out.append('\u2212'); i++ }
                    c == '\'' -> { out.append('\u2032'); i++ }
                    c == '\n' -> { out.append(' '); i++ }
                    al(c) -> {
                        var j = i
                        while (j < to && al(s[j])) j++
                        val st = out.length
                        out.append(s, i, j)
                        // 문자 변수는 기울임꼴
                        if (ital) out.setSpan(StyleSpan(Typeface.ITALIC), st, out.length, FLAG)
                        i = j
                    }
                    else -> { out.append(c); i++ }
                }
            }
        }

        /** s[open] 의 '{' 와 짝이 되는 '}' 의 위치 (없으면 to) */
        private fun closeOf(open: Int, to: Int): Int {
            var depth = 0
            var k = open
            while (k < to) {
                val ch = s[k]
                if (ch == '\\') { k += 2; continue }
                if (ch == '{') depth++
                else if (ch == '}') {
                    depth--
                    if (depth == 0) return k
                }
                k++
            }
            return to
        }

        /** from 뒤의 인자 하나: {…} · \명령 · 글자 한 개. [시작, 끝, 다음 위치] */
        private fun arg(from: Int, to: Int): IntArray? {
            var i = from
            while (i < to && s[i] == ' ') i++
            if (i >= to) return null
            return when (s[i]) {
                '{' -> {
                    val e = closeOf(i, to)
                    intArrayOf(i + 1, e, minOf(e + 1, to))
                }
                '\\' -> {
                    var j = i + 1
                    if (j < to && al(s[j])) {
                        while (j < to && al(s[j])) j++
                    } else j = minOf(j + 1, to)
                    intArrayOf(i, j, j)
                }
                else -> intArrayOf(i, i + 1, i + 1)
            }
        }

        private fun sub(a: IntArray, ital: Boolean = true): SpannableStringBuilder =
            SpannableStringBuilder().also { emit(it, a[0], a[1], ital) }

        private fun raw(out: SpannableStringBuilder, a: IntArray) {
            out.append(s.substring(a[0], a[1]).replace("{", "").replace("}", ""))
        }

        private fun operand(out: SpannableStringBuilder, t: CharSequence) {
            val p = t.toString()
            if (p.isEmpty() || SIMPLE.matches(p)) out.append(t)
            else {
                out.append('(')
                out.append(t)
                out.append(')')
            }
        }

        private fun script(out: SpannableStringBuilder, i: Int, to: Int): Int {
            val up = s[i] == '^'
            val a = arg(i + 1, to)
            if (a == null) {
                out.append(s[i])
                return i + 1
            }
            putScript(out, sub(a), up)
            return a[2]
        }

        private fun putScript(out: SpannableStringBuilder, t: SpannableStringBuilder, up: Boolean) {
            val plain = t.toString()
            if (plain.isEmpty()) return
            if (plain == "\u2032" || plain == "\u2033" || plain == "\u00B0") { out.append(plain); return }
            if (plain == "\u2218") { out.append('\u00B0'); return }   // ^\circ = 도(°)
            val table = if (up) SUP else SUB
            if (plain.all { table.containsKey(it) }) {
                for (ch in plain) out.append(table[ch]!!)
                return
            }
            val st = out.length
            out.append(t)
            out.setSpan(RelativeSizeSpan(0.72f), st, out.length, FLAG)
            out.setSpan(if (up) SuperscriptSpan() else SubscriptSpan(), st, out.length, FLAG)
        }

        private fun accent(out: SpannableStringBuilder, j: Int, to: Int, ital: Boolean, mark: Char): Int {
            val a = arg(j, to) ?: return j
            emit(out, a[0], a[1], ital)
            out.append(mark)
            return a[2]
        }

        private fun rowBreak(out: SpannableStringBuilder) {
            val env = envs.lastOrNull()
            when {
                env != null && env in MATRICES -> out.append(" ; ")
                env == "cases" -> out.append("\n    ")
                else -> out.append('\n')
            }
        }

        private fun command(out: SpannableStringBuilder, i: Int, to: Int, ital: Boolean): Int {
            var j = i + 1
            if (j >= to) { out.append('\\'); return to }
            if (!al(s[j])) {
                val ch = s[j]
                when (ch) {
                    '{', '}', '%', '$', '&', '#', '_' -> out.append(ch)
                    ',', ';', ':', ' ' -> out.append('\u2009')
                    '!' -> {}
                    '|' -> out.append('\u2016')
                    '\\' -> rowBreak(out)
                    '(', ')', '[', ']' -> {}
                    else -> out.append(ch)
                }
                return j + 1
            }
            val k0 = j
            while (j < to && al(s[j])) j++
            val name = s.substring(k0, j)

            GREEK[name]?.let {
                val st = out.length
                out.append(it)
                if (ital) out.setSpan(StyleSpan(Typeface.ITALIC), st, out.length, FLAG)
                return j
            }
            SYMBOLS[name]?.let { out.append(it); return j }
            if (name in FUNCS) { out.append(name); return j }

            when (name) {
                "frac", "dfrac", "tfrac", "cfrac" -> {
                    val a = arg(j, to) ?: return j
                    val b = arg(a[2], to) ?: return a[2]
                    operand(out, sub(a, ital))
                    out.append('/')
                    operand(out, sub(b, ital))
                    return b[2]
                }
                "binom", "dbinom", "tbinom" -> {
                    val a = arg(j, to) ?: return j
                    val b = arg(a[2], to) ?: return a[2]
                    out.append("C(")
                    emit(out, a[0], a[1], ital)
                    out.append(", ")
                    emit(out, b[0], b[1], ital)
                    out.append(')')
                    return b[2]
                }
                "sqrt" -> {
                    var p = j
                    var idx: SpannableStringBuilder? = null
                    if (p < to && s[p] == '[') {
                        val e = s.indexOf(']', p)
                        if (e in 0 until to) {
                            idx = SpannableStringBuilder().also { emit(it, p + 1, e, ital) }
                            p = e + 1
                        }
                    }
                    val a = arg(p, to)
                    if (a == null) { out.append('√'); return p }
                    if (idx != null) putScript(out, idx, true)
                    out.append('√')
                    val st = out.length
                    emit(out, a[0], a[1], ital)
                    // 루트 기호 위로 뻗는 윗줄
                    if (out.length > st) out.setSpan(OverlineSpan(), st, out.length, FLAG)
                    return a[2]
                }
                "overline", "bar", "widebar" -> {
                    val a = arg(j, to) ?: return j
                    val st = out.length
                    emit(out, a[0], a[1], ital)
                    if (out.length > st) out.setSpan(OverlineSpan(), st, out.length, FLAG)
                    return a[2]
                }
                "underline" -> {
                    val a = arg(j, to) ?: return j
                    val st = out.length
                    emit(out, a[0], a[1], ital)
                    if (out.length > st) out.setSpan(UnderlineSpan(), st, out.length, FLAG)
                    return a[2]
                }
                "cancel", "bcancel", "xcancel" -> {
                    val a = arg(j, to) ?: return j
                    val st = out.length
                    emit(out, a[0], a[1], ital)
                    if (out.length > st) out.setSpan(StrikethroughSpan(), st, out.length, FLAG)
                    return a[2]
                }
                "vec", "overrightarrow" -> return accent(out, j, to, ital, '\u20D7')
                "overleftarrow" -> return accent(out, j, to, ital, '\u20D6')
                "overleftrightarrow" -> return accent(out, j, to, ital, '\u20E1')
                "hat", "widehat" -> return accent(out, j, to, ital, '\u0302')
                "tilde", "widetilde" -> return accent(out, j, to, ital, '\u0303')
                "dot" -> return accent(out, j, to, ital, '\u0307')
                "ddot" -> return accent(out, j, to, ital, '\u0308')
                "mathbb", "Bbb" -> {
                    val a = arg(j, to) ?: return j
                    val t = s.substring(a[0], a[1]).trim()
                    out.append(t.singleOrNull()?.let { BB[it] } ?: t)
                    return a[2]
                }
                "mathbf", "boldsymbol", "bm", "textbf", "mathbfit" -> {
                    val a = arg(j, to) ?: return j
                    val st = out.length
                    emit(out, a[0], a[1], false)
                    if (out.length > st) out.setSpan(StyleSpan(Typeface.BOLD), st, out.length, FLAG)
                    return a[2]
                }
                "text", "textrm", "textit", "textsf", "mbox" -> {
                    val a = arg(j, to) ?: return j
                    raw(out, a)
                    return a[2]
                }
                "mathrm", "operatorname", "mathsf", "mathtt", "mathcal", "mathscr", "mathfrak", "mathop", "mathrel", "mathbin",
                "overbrace", "underbrace" -> {
                    val a = arg(j, to) ?: return j
                    emit(out, a[0], a[1], false)
                    return a[2]
                }
                "mathit" -> {
                    val a = arg(j, to) ?: return j
                    emit(out, a[0], a[1], true)
                    return a[2]
                }
                "left", "right", "bigl", "bigr", "big", "Big", "bigg", "Bigg", "biggl", "biggr", "Bigl", "Bigr" -> {
                    var p = j
                    if (p < to && s[p] == '.') p++      // \left. \right. 는 보이지 않는 경계
                    return p
                }
                "displaystyle", "textstyle", "scriptstyle", "limits", "nolimits", "nonumber", "notag", "hline", "centering",
                "rm", "it", "bf", "mathstrut", "relax" -> return j
                "label", "tag", "vspace", "hspace", "phantom", "vphantom", "hphantom", "color" -> {
                    val a = arg(j, to) ?: return j
                    return a[2]
                }
                "textcolor" -> {
                    val a = arg(j, to) ?: return j
                    val b = arg(a[2], to) ?: return a[2]
                    emit(out, b[0], b[1], ital)
                    return b[2]
                }
                "boxed" -> {
                    val a = arg(j, to) ?: return j
                    out.append('[')
                    emit(out, a[0], a[1], ital)
                    out.append(']')
                    return a[2]
                }
                "pmod" -> {
                    val a = arg(j, to) ?: return j
                    out.append(" (mod ")
                    emit(out, a[0], a[1], ital)
                    out.append(')')
                    return a[2]
                }
                "bmod" -> { out.append("mod"); return j }
                "not" -> {
                    if (j < to && s[j] == '=') { out.append('≠'); return j + 1 }
                    if (s.startsWith("\\in", j)) { out.append('∉'); return j + 3 }
                    out.append('/')
                    return j
                }
                "begin" -> {
                    val a = arg(j, to) ?: return j
                    val env = s.substring(a[0], a[1]).trim()
                    envs.add(env)
                    MATRIX_OPEN[env]?.let { out.append(it) }
                    var p = a[2]
                    if (env == "array" || env == "tabular") {
                        val b = arg(p, to)       // 열 모양 {ccc} 는 버린다
                        if (b != null) p = b[2]
                    }
                    return p
                }
                "end" -> {
                    val a = arg(j, to) ?: return j
                    val env = s.substring(a[0], a[1]).trim()
                    if (envs.isNotEmpty()) envs.removeAt(envs.size - 1)
                    MATRIX_CLOSE[env]?.let { out.append(it) }
                    return a[2]
                }
            }
            // 모르는 명령은 이름만 보여 준다
            out.append(name)
            return j
        }
    }

    /** 글자 위에 선을 긋는 span (선분 AB · 제곱근 안쪽) */
    private class OverlineSpan : ReplacementSpan() {
        override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int =
            Math.ceil(paint.measureText(text, start, end).toDouble()).toInt()

        override fun draw(
            canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float,
            top: Int, y: Int, bottom: Int, paint: Paint
        ) {
            if (text == null) return
            canvas.drawText(text, start, end, x, y.toFloat(), paint)
            val w = paint.measureText(text, start, end)
            val ly = y + paint.ascent() * 0.84f
            val old = paint.strokeWidth
            paint.strokeWidth = (paint.textSize * 0.06f).coerceAtLeast(1f)
            canvas.drawLine(x, ly, x + w, ly, paint)
            paint.strokeWidth = old
        }
    }
}
