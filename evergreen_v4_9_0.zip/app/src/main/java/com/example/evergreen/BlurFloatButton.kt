package com.example.evergreen

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 상/하단바 숨기기를 켰을 때 뜨는 작은 '더보기' 버튼.
 * Android 12(API 31) 이상에서는 버튼 바로 뒤의 웹 페이지 색을 흐리게 깐 유리 모양이 된다.
 * 블러가 꺼져 있거나 그 아래 버전에서는 블러 없이 반투명 배경만 쓴다.
 * 웹뷰를 직접 다시 그리지 않고 화면에 그려진 픽셀을 복사해 쓴다 (GlassBackdrop 참고).
 * 버튼 자리 자체는 버튼이 덮고 있어 찍을 수 없으므로, 버튼 둘레 띠를 복사해 가운데를 매끄럽게 이어 채운다.
 */
class BlurFloatButton @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null, defStyle: Int = androidx.appcompat.R.attr.imageButtonStyle
) : AppCompatImageButton(ctx, attrs, defStyle) {

    /** 웹 페이지가 붙는 영역 (이 안에서만 가져온다) */
    var source: View? = null
        set(v) { field = v; invalidate() }

    // 버튼 전체 투명도(alpha)는 1 로 둔다. 1 보다 작으면 뒤 페이지가 비쳐 흐린 그림과 겹쳐 보인다.
    private val blurOn = Blur.active()
    private var glass: Any? = null
    private val clip = Path()
    private val a = IntArray(2)
    private val pre = ViewTreeObserver.OnPreDrawListener {
        if (source != null && alpha > 0.01f) (glass as? GlassBackdrop)?.refresh()
        true
    }

    /** 버튼 사각형을 사방으로 EDGE_DP 만큼 넓힌 곳(버튼 바로 뒤 + 둘레)을 가져온다. 가운데(버튼 자리)는 GlassBackdrop 이 둘레 색으로 채운다 */
    private fun region(): Rect? {
        if (source == null || width <= 0) return null
        getLocationInWindow(a)
        val e = (EDGE_DP * resources.displayMetrics.density).toInt()
        return Rect(a[0] - e, a[1] - e, a[0] + width + e, a[1] + height + e)
    }

    private companion object {
        /** 버튼 둘레로 넓히는 폭 (dp). 버튼 바깥 여백(12dp)보다 작아야 화면 밖으로 나가지 않는다 */
        const val EDGE_DP = 10f
    }

    init {
        // 블러가 켜져 있으면 뒤 페이지를 흐리게 깐 유리 모양, 꺼져 있으면 블러 없이 반투명 배경만 쓴다
        val fillAlpha = if (blurOn) 0x8C else 0xB8
        val fill = ColorUtils.setAlphaComponent(
            ThemeColors.get(this, com.google.android.material.R.attr.colorSurfaceContainerHighest), fillAlpha
        )
        val edge = ColorUtils.setAlphaComponent(
            ThemeColors.get(this, com.google.android.material.R.attr.colorOutlineVariant), 0xA0
        )
        val shape = GradientDrawable().apply {
            this.shape = GradientDrawable.OVAL
            setColor(fill)
            setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), edge)
        }
        val ripple = ThemeColors.get(this, android.R.attr.colorControlHighlight, 0x22000000)
        background = RippleDrawable(ColorStateList.valueOf(ripple), shape, null)
        // 그림자가 버튼 둘레 띠에 찍혀 유리가 어둡게 물드는 것을 막는다 (테두리선은 그대로)
        if (blurOn) outlineProvider = null
    }

    // 숨겨졌다가 다시 나타나면 옛 그림 대신 새로 복사해서 서서히 짙어지게 한다
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (changedView === this && visibility != View.VISIBLE) (glass as? GlassBackdrop)?.resetFade()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (blurOn) {
            if (glass == null) glass = GlassBackdrop(this, edgeDp = EDGE_DP) { region() }
            viewTreeObserver.addOnPreDrawListener(pre)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (blurOn) {
            if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(pre)
            (glass as? GlassBackdrop)?.release()
        }
    }

    // 배경(반투명 유리)보다 먼저 흐린 그림을 그려야 하므로 onDraw 가 아니라 draw 에서 한다
    override fun draw(canvas: Canvas) {
        val g = glass as? GlassBackdrop
        if (blurOn && g != null && source != null && width > 0 && height > 0) {
            val n = canvas.save()
            try {
                clip.reset()
                clip.addOval(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
                canvas.clipPath(clip)
                g.draw(canvas, width, height)
            } catch (e: Throwable) { /* 못 그리면 유리 배경만 */ } finally {
                canvas.restoreToCount(n)
            }
        }
        super.draw(canvas)
    }
}
