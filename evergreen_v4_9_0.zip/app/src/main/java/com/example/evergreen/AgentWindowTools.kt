package com.example.evergreen

import org.json.JSONObject

/**
 * 에이전트: 창 · 영상 보기 도구 (모두 변경, 요청당 한 번 확인).
 * - open_window: 새 창(분할 · 전체화면 · 팝업)을 열거나, 닫혀 있는 창을 다시 연다
 * - close_window: 열려 있는 다른 창을 닫는다 (탭은 저장돼서 다시 열 수 있다)
 * - rename_window: 창 이름 바꾸기
 * - enter_pip: 재생 중인 영상을 작은 창(PiP)으로
 * - set_mirroring: 미러링(영상을 그대로 창 가득 보기) 켜기 · 끄기
 * - open_in_player: 지금 보는 영상을 내장 플레이어로 열기
 * 모두 [AgentHost] 만 통해 앱을 만진다.
 */
object AgentWindowTools {
    fun build(): List<AgentTool> = listOf(openWindow(), closeWindow(), renameWindow(), enterPip(), setMirroring(), openInPlayer())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    private fun outcome(o: AgentOutcome): AgentResult =
        if (o.ok) AgentResult.ok(JSONObject().put("message", o.message), o.message) else AgentResult.fail(o.message)

    /** 「2」 「창 2」 「2번 창」 「#2」 → 2 (list_windows 의 번호). 번호가 아니면 이름으로 본다 */
    private fun numberOf(q: String): Int? {
        val s = q.trim()
        s.toIntOrNull()?.let { return it }
        return Regex("^(?:창|window|win|#)?\\s*(\\d+)\\s*(?:번\\s*째?\\s*창?|째\\s*창?)?$", RegexOption.IGNORE_CASE)
            .find(s)?.groupValues?.get(1)?.toIntOrNull()
    }

    /** 되돌리기 준비용: list_windows 목록에서 [q](번호나 이름)의 창을 찾는다. 여러 개로 갈리면 null */
    private fun findWindow(ws: List<AgentWindow>, q: String): AgentWindow? {
        val s = q.trim().replace(Regex("\\s*[(\\[（].*?[)\\]）]\\s*"), " ").trim().ifEmpty { q.trim() }
        if (s.isEmpty()) return null
        numberOf(s)?.let { n -> return ws.firstOrNull { it.no == n } }
        val exact = ws.filter { it.name.equals(s, true) }
        if (exact.size == 1) return exact[0]
        if (exact.size > 1) return null
        return ws.filter { it.name.contains(s, true) }.singleOrNull()
    }

    private fun windowLabel(w: AgentWindow): String = short(w.name.ifBlank { "창 ${w.no}" }, 20)

    private fun modeLabel(mode: String): String = when (mode.trim().replace(" ", "")) {
        "전체화면", "전체", "full", "fullscreen" -> "전체 화면"
        "팝업", "팝업창", "popup" -> "팝업 창"
        else -> "분할 화면"
    }

    private fun openWindow() = AgentTool(
        name = "open_window",
        description = "새 창을 엽니다. mode 로 분할(화면을 나눠 옆에 나란히, 기본) · 전체화면 · 팝업(떠 있는 작은 창) 중에 고릅니다(이 창이 팝업이면 분할은 못 하고 팝업이 기본). " +
            "target 에 주소나 검색어를 주면 새 창에서 그 페이지를 열고, 비우면 빈 새 창입니다. " +
            "window 에 닫혀 있지만 탭이 저장된 창의 번호나 이름(list_windows 에서 open=false)을 주면 그 창을 다시 엽니다(그때는 target 을 같이 줄 수 없습니다). " +
            "창은 최대 5개까지 열 수 있고, 가득 차 있으면 close_window 로 하나를 닫은 뒤 여세요. " +
            "창은 시스템이 띄워서 바로 뜨지 않으니, 새 창을 이어서 다루기 전에 list_windows 로 새 창 번호를 확인하세요. " +
            "탭을 옮겨 새 창으로 보내는 일은 move_tabs_to_window 를 쓰세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "mode" to AgentSchema.oneOf("새 창을 여는 방식 (비우면 분할)", "분할", "전체화면", "팝업"),
                "target" to AgentSchema.str("새 창에서 열 주소(https://…)나 검색어 (비우면 빈 새 창)"),
                "window" to AgentSchema.str("다시 열 닫힌 창의 번호나 이름 (새 창이 아니라 저장된 창을 열 때만)")
            )
        ),
        doing = { a ->
            val w = a.optString("window").trim()
            val t = a.optString("target").trim()
            when {
                w.isNotEmpty() -> "닫힌 창 다시 여는 중: ${short(w, 16)}…"
                t.isNotEmpty() -> "새 창 여는 중: ${short(t, 24)}…"
                else -> "새 창 여는 중…"
            }
        },
        run = { a, ctx -> outcome(ctx.host.openWindow(a.optString("mode"), a.optString("target"), a.optString("window"))) },
        undoPlan = { _, ctx ->
            // 새로 뜬 창을 알 수 없으니, 실행 전에 열려 있던 창 번호를 적어 두고 되돌릴 때 새로 생긴 창을 찾는다
            val before = ctx.host.windows().filter { it.open }.map { it.no }.toSet()
            val plan: (AgentResult) -> AgentUndo? = { _ ->
                AgentUndo("새로 연 창 닫기") { h ->
                    val fresh = h.windows().filter { it.open && !it.current && it.no !in before }
                    when (fresh.size) {
                        0 -> AgentOutcome.fail("새로 연 창을 찾지 못했어요 (아직 안 떴거나 이미 닫혔어요)")
                        1 -> h.closeWindow(fresh[0].no.toString())
                        else -> AgentOutcome.fail("새로 생긴 창이 여러 개라 어느 것인지 몰라서 그대로 뒀어요")
                    }
                }
            }
            plan
        },
        ask = { a, _ ->
            val w = a.optString("window").trim()
            val t = a.optString("target").trim()
            val how = modeLabel(a.optString("mode"))
            when {
                w.isNotEmpty() -> "닫힌 창 '${short(w, 20)}' 을(를) ${how}로 다시 열기"
                t.isNotEmpty() -> "새 창을 ${how}로 열기: ${short(t, 50)}"
                else -> "새 창을 ${how}로 열기"
            }
        }
    )

    private fun closeWindow() = AgentTool(
        name = "close_window",
        description = "열려 있는 다른 창을 닫습니다. window 에 창 번호나 이름(list_windows 참고)을 줍니다. " +
            "창만 닫히고 안의 탭은 저장돼 있어서 open_window 의 window 로 다시 열 수 있습니다(창과 탭까지 지우는 건 지원하지 않습니다). " +
            "지금 이 AI 가 떠 있는 창(list_windows 의 current)은 닫으면 AI 도 멈추니 닫을 수 없고, 시크릿 탭이 든 창은 닫으면 그 탭이 사라져서 닫을 수 없습니다. 이 창이나 그런 창을 닫아 달라고 하면 사용자가 직접 닫도록 안내하세요. " +
            "그 창에서 재생 중이던 영상 · 음악은 멈춥니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf("window" to AgentSchema.str("닫을 창의 번호나 이름 (list_windows 참고)")),
            listOf("window")
        ),
        doing = { a -> "창 닫는 중: ${short(a.optString("window").trim(), 16)}…" },
        run = { a, ctx -> outcome(ctx.host.closeWindow(a.optString("window"))) },
        undoPlan = { a, ctx ->
            val w = findWindow(ctx.host.windows(), a.optString("window"))
            if (w == null || !w.open || w.current) null else {
                val no = w.no
                val plan: (AgentResult) -> AgentUndo? = { _ ->
                    AgentUndo("닫은 창 다시 열기 (${windowLabel(w)})") { h -> h.openWindow("", "", no.toString()) }
                }
                plan
            }
        },
        ask = { a, ctx ->
            val w = findWindow(ctx.host.windows(), a.optString("window"))
            if (w == null) "창 닫기: ${short(a.optString("window").trim(), 20)}"
            else "창 닫기: ${windowLabel(w)} (탭 ${w.tabCount}개는 저장돼요)"
        }
    )

    private fun renameWindow() = AgentTool(
        name = "rename_window",
        description = "창의 이름을 바꿉니다. window 에 창 번호나 이름(list_windows 참고, 지금 이 창이나 닫힌 창도 됨), new_name 에 새 이름(20자까지)을 줍니다. " +
            "new_name 을 빈 글로 주면 기본 이름(「창 N」)으로 돌립니다. 숫자뿐인 이름 · 「창 2」 꼴 · 「새 창」 「닫힌 창」 · 다른 창과 같은 이름은 창을 찾을 때 헷갈려서 쓸 수 없습니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "window" to AgentSchema.str("이름을 바꿀 창의 번호나 이름 (list_windows 참고)"),
                "new_name" to AgentSchema.str("새 이름 (20자까지, 빈 글이면 기본 이름으로 돌림)")
            ),
            listOf("window", "new_name")
        ),
        doing = { a -> "창 이름 바꾸는 중: ${short(a.optString("window").trim(), 14)} → ${short(a.optString("new_name").trim(), 14)}…" },
        run = { a, ctx ->
            if (!a.has("new_name")) AgentResult.fail("new_name 이 없어요 (기본 이름으로 돌리려면 빈 글로 주세요)")
            else outcome(ctx.host.renameWindow(a.optString("window"), a.optString("new_name")))
        },
        undoPlan = { a, ctx ->
            val w = findWindow(ctx.host.windows(), a.optString("window"))
            if (w == null) null else {
                val no = w.no
                // 이름을 붙이지 않았던 창은 기본 이름(빈 글)으로, 붙였던 창은 그 이름으로 되돌린다
                val old = if (w.name == "창 ${w.no}") "" else w.name
                val plan: (AgentResult) -> AgentUndo? = { _ ->
                    AgentUndo("창 이름 되돌리기 (${windowLabel(w)})") { h -> h.renameWindow(no.toString(), old) }
                }
                plan
            }
        },
        ask = { a, ctx ->
            val w = findWindow(ctx.host.windows(), a.optString("window"))
            val from = if (w != null) windowLabel(w) else short(a.optString("window").trim(), 20)
            val to = a.optString("new_name").trim()
            if (to.isEmpty()) "창 이름 기본값으로: $from" else "창 이름 바꾸기: $from → ${short(to, 20)}"
        }
    )

    private fun enterPip() = AgentTool(
        name = "enter_pip",
        description = "지금 보는 탭에서 재생 중인 동영상을 작은 창(PiP, 다른 화면 위에 떠 있는 작은 영상 창)으로 바꿉니다. " +
            "재생 중인 동영상이 없으면 안 되니, 먼저 영상이 재생 중인지 list_media 로 확인하고 멈춰 있으면 control_media 로 재생하세요. 다른 탭의 영상이면 switch_tab 으로 그 탭부터 보세요. " +
            "작은 창이 되면 AI 창은 닫히니, 이 도구는 항상 마지막 단계로 쓰고 부른 뒤에는 더 이어서 하지 마세요. 작은 창에서 앱으로 돌아오는 건 사용자가 직접 합니다(되돌리기는 없습니다).",
        risk = AgentRisk.CHANGE,
        doing = { "작은 창(PiP)으로 바꾸는 중…" },
        run = { _, ctx -> outcome(ctx.host.enterPip()) },
        ask = { _, _ -> "재생 중인 영상을 작은 창(PiP)으로 바꾸기" }
    )

    private fun setMirroring() = AgentTool(
        name = "set_mirroring",
        description = "미러링(페이지에서 재생되는 영상을 파일을 가져오지 않고 그대로 창 가득 크게 보기, 메뉴의 「화면 그대로 보기」)을 켜거나(on=true) 끕니다. " +
            "영상이 있는 웹 페이지에서만 켤 수 있고(새 탭 · 빈 탭 불가), 소리 · 화질은 페이지 재생 그대로입니다. 켜면 영상 위에 재생 · 이동 · 배속 컨트롤이 뜨고 AI 창은 가려지니, 켠 뒤에는 더 이어서 하지 말고 한 줄로 알리세요. " +
            "내장 플레이어로 열고 싶다는 말이면 open_in_player 를 쓰고, 그게 안 되는 영상(암호화 · blob 방식)일 때 이 도구를 쓰세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf("on" to AgentSchema.flag("true 면 켜기, false 면 끄기")),
            listOf("on")
        ),
        doing = { a -> if (a.optBoolean("on", true)) "미러링 켜는 중…" else "미러링 끄는 중…" },
        run = { a, ctx ->
            if (!a.has("on")) AgentResult.fail("on 이 없어요 (true 면 켜기, false 면 끄기)")
            else outcome(ctx.host.setMirroring(a.optBoolean("on", true)))
        },
        undoPlan = { a, _ ->
            val turnedOn = a.optBoolean("on", true)
            val plan: (AgentResult) -> AgentUndo? = { _ ->
                if (turnedOn) AgentUndo("미러링 끄기") { h -> h.setMirroring(false) } else null
            }
            plan
        },
        ask = { a, _ -> if (a.optBoolean("on", true)) "미러링(영상을 창 가득 보기) 켜기" else "미러링 끄기" }
    )

    private fun openInPlayer() = AgentTool(
        name = "open_in_player",
        description = "지금 보는 탭의 영상을 내장 플레이어로 엽니다(이어 보던 위치부터, 영상 아래 「내장 플레이어로 열기」 버튼과 같습니다). " +
            "영상이 있는 웹 페이지에서만 되고, 재생 중인 영상이 있으면 그것을, 재생 중인 것이 없으면 후보가 하나뿐일 때만 엽니다. 여러 개라 정할 수 없으면 영상을 재생한 뒤 다시 시도하세요. " +
            "유튜브는 내장 플레이어를 쓰지 않아 미러링(화면 가득 보기)으로 열립니다. 플레이어가 화면을 덮어 AI 창이 가려지니, 연 뒤에는 더 이어서 하지 말고 한 줄로 알리세요. " +
            "이미 열려 있는 내장 플레이어의 재생 · 일시정지 · 건너뛰기는 control_media 로 합니다.",
        risk = AgentRisk.CHANGE,
        doing = { "내장 플레이어로 여는 중…" },
        run = { _, ctx -> outcome(ctx.host.openInPlayer()) },
        ask = { _, ctx ->
            val t = ctx.host.tabs().firstOrNull { it.current }
            if (t == null) "지금 영상을 내장 플레이어로 열기" else "내장 플레이어로 열기: ${short(t.title.ifBlank { t.url }, 36)}"
        }
    )
}
