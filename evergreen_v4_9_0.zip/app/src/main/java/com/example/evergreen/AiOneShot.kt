package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * 채팅과 따로, 한 번 물어보고 한 번 답을 받는 가벼운 Gemini 요청 (북마크 · 다운로드 AI 정리, 방문 기록 말로 찾기).
 * 키 돌려쓰기(GeminiKeyPool) 는 다른 기능과 같다: 한도(429)·거부된 키는 쉬게 하고 다른 키로 다시 보낸다.
 * 반드시 화면 스레드가 아닌 곳에서 부른다.
 */
object AiOneShot {
    class Fail(message: String) : Exception(message)

    /**
     * [prompt] 를 보내고 JSON 글을 돌려받는다 (코드 울타리는 벗겨 준다).
     * 키가 없거나 요청이 실패하면 [Fail] 을 던진다. 메시지는 그대로 사용자에게 보여 줘도 되는 한국어다.
     */
    fun askJson(prefs: Prefs, prompt: String): String = ask(prefs, prompt, true)

    /** [askJson] 과 같지만 JSON 이 아니라 그냥 글로 답을 받는다 (긴 문서 요점 정리처럼) */
    fun askText(prefs: Prefs, prompt: String): String = ask(prefs, prompt, false)

    private fun ask(prefs: Prefs, prompt: String, json: Boolean): String {
        val keys = prefs.geminiKeys
        if (keys.isEmpty()) throw Fail("AI 설정에서 Gemini API 키를 먼저 넣어 주세요")
        val model = GeminiAuto.SUMMARY
        var key = prefs.geminiKey
        val tried = HashSet<String>()
        var think = true
        var attempts = 0
        while (attempts < 6) {
            attempts++
            tried.add(key)
            val r = send(key, model, prompt, think, json)
            if (r.code in 200..299) {
                val tk = GeminiUsage.tokensOfBody(r.body)
                GeminiUsage.record(key, model, r.code, false, tk.inTok, tk.outTok)
                return if (json) clean(extract(r.body)) else extract(r.body).trim()
            }
            if (r.code == 400 && think && GeminiThinking.rejected(r.code, r.body, model, true)) {
                think = false
                continue
            }
            val badKey = r.code == 401 || r.code == 403 || (r.code == 400 && r.body.contains("API key", ignoreCase = true))
            val quota = r.code == 429 && GeminiKeyPool.isQuota(r.body)
            GeminiUsage.record(key, model, r.code, quota, 0, 0)
            if (quota || badKey) {
                GeminiKeyPool.onLimit(key, model, r.body, badKey)
                val alt = GeminiKeyPool.alternative(tried, model)
                if (alt != null) {
                    GeminiKeyPool.notifySwitch(key, alt, badKey)
                    key = alt
                    continue
                }
            }
            throw Fail(
                when {
                    badKey -> "API 키를 확인해 주세요 (${r.code})"
                    r.code == 429 -> if (quota) "무료 사용 한도에 걸렸어요. 잠시 뒤 다시 해 주세요" else "Gemini 서버가 붐벼요. 잠시 뒤 다시 해 주세요"
                    r.code >= 500 -> "Gemini 서버에 문제가 있어요 (${r.code}). 잠시 뒤 다시 해 주세요"
                    r.code == 0 -> "인터넷 연결을 확인해 주세요"
                    else -> "AI 요청에 실패했어요 (${r.code})"
                }
            )
        }
        throw Fail("AI 요청에 실패했어요")
    }

    private class Raw(val code: Int, val body: String)

    private fun send(key: String, model: String, prompt: String, think: Boolean, json: Boolean): Raw {
        var c: HttpURLConnection? = null
        return try {
            c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            GeminiKeyPool.used(key)
            val gen = JSONObject().put("temperature", 0.2)
            if (json) gen.put("responseMimeType", "application/json")
            if (think) GeminiThinking.apply(gen, model, GeminiThinking.MINIMAL)
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
                )
                .put("generationConfig", gen)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = try {
                val s = if (code in 200..299) c.inputStream else c.errorStream
                s?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            } catch (e: Exception) {
                ""
            }
            Raw(code, text)
        } catch (e: Exception) {
            Raw(0, "")
        } finally {
            try { c?.disconnect() } catch (e: Exception) { }
        }
    }

    private fun extract(body: String): String {
        val parts = try {
            JSONObject(body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        } catch (e: Exception) {
            null
        } ?: throw Fail("AI 답을 읽지 못했어요. 다시 해 주세요")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text", ""))
        }
        return sb.toString()
    }

    /** ```json … ``` 울타리를 벗긴다 */
    internal fun clean(s: String): String =
        s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
}
