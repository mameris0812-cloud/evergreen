package com.example.evergreen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * 북마크 목록.
 * - 위쪽 칩으로 폴더를 만들고(＋ 폴더), 칩을 길게 누르면 이름 변경 / 삭제
 * - 북마크를 누르면 현재 탭에서 열기, ⋮ 메뉴(또는 길게 누르기)로 새 탭 열기 / 수정 / 폴더로 이동 / 삭제
 * - 고른 주소는 결과(EXTRA_URL)로 MainActivity 에 돌려준다.
 */
class BookmarksActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var chipRow: LinearLayout
    private val adapter = RowAdapter()
    private lateinit var select: ListSelect<Long>

    private val shown = ArrayList<Bookmark>()
    private var folderNames: Map<Long, String> = emptyMap()
    private var selected = ListUi.ALL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        ThemeColors.skin(findViewById(android.R.id.content))   // XML 의 ?attr 색에도 테마 색 입히기 (목록 줄은 만들어질 때마다 자동)
        ListUi.fitSystemBars(this)
        ListUi.applyTabletPopup(this)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "북마크"
        findViewById<View>(R.id.btnListBack).setOnClickListener { ListUi.closeSheet(this, backToMenu = true) }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        chipRow = findViewById(R.id.chipRow)
        listView.adapter = adapter
        select = ListSelect(
            this, listView, findViewById(R.id.btnListAction), findViewById(R.id.listTitle),
            visibleKeys = { shown.map { it.id } },
            onChanged = { adapter.notifyDataSetChanged() },
            onDelete = { ids -> deleteMany(ids) }
        )
        findViewById<View>(R.id.btnListAi).apply {
            visibility = View.VISIBLE
            setOnClickListener { aiOrganize() }
        }

        refreshView()
    }

    // ───────────────────────── AI 정리 ─────────────────────────

    /** 폴더로 옮길 제안 한 묶음 */
    private class Move(val folder: String, val isNew: Boolean, val items: List<Bookmark>)

    /**
     * AI 에 북마크 제목 · 주소를 보내 주제별 폴더 분류를 제안받고, 같은 주소의 중복도 찾아서 한 화면에 보여 준다.
     * 사용자가 체크한 것만 적용하고, 적용한 뒤에는 알림의 「실행 취소」 로 통째로 되돌릴 수 있다.
     */
    private fun aiOrganize() {
        val all = prefs.bookmarks()
        if (all.size < 3) {
            ListUi.toast(this, "북마크가 3개 이상 있어야 정리할 수 있어요")
            return
        }
        val folders = prefs.folders(Prefs.KIND_BM)
        val targets = all.take(AiOrganize.MAX_BM)
        val dupes = AiOrganize.bookmarkDuplicates(all)
        val nameOf: (Long) -> String? = { id -> folders.firstOrNull { it.id == id }?.name }
        AiUi.run(
            this,
            "AI가 북마크 ${targets.size}개를 살펴보는 중이에요…\n제목과 사이트 주소만 Gemini 로 보내요.",
            { AiOneShot.askJson(prefs, AiOrganize.bookmarkPrompt(targets, nameOf, folders.map { it.name })) }
        ) { json ->
            val groups = AiOrganize.parseGroups(json, targets.size, folders.map { it.name })
            val moves = ArrayList<Move>()
            for (g in groups) {
                val exist = folders.firstOrNull { it.name.equals(g.folder, ignoreCase = true) }
                // 이미 그 폴더에 든 북마크는 제안에서 뺀다
                val items = g.indexes.map { targets[it] }.filter { exist == null || it.folderId != exist.id }
                if (items.isNotEmpty()) moves.add(Move(exist?.name ?: g.folder, exist == null, items))
            }
            if (moves.isEmpty() && dupes.isEmpty()) {
                ListUi.toast(this, "정리할 게 없어요. 이미 깔끔해요")
            } else {
                showBookmarkProposal(moves, dupes)
            }
        }
    }

    private fun showBookmarkProposal(moves: List<Move>, dupes: List<List<Bookmark>>) {
        val labels = ArrayList<String>()
        for (m in moves) {
            val first = ListUi.displayTitle(m.items[0].title, m.items[0].url)
            val more = if (m.items.size > 1) " 외 ${m.items.size - 1}개" else ""
            labels.add("📁 ${m.folder}${if (m.isNew) " (새 폴더)" else ""}  ·  ${m.items.size}개\n$first$more")
        }
        val dupCount = dupes.sumOf { it.size - 1 }
        if (dupCount > 0) {
            val first = ListUi.displayTitle(dupes[0][0].title, dupes[0][0].url)
            labels.add("🗑 같은 주소 중복 ${dupCount}개 삭제\n「$first」 등 — 하나씩은 남겨요")
        }
        val checked = BooleanArray(labels.size) { true }
        AiUi.propose(this, "이렇게 정리할까요?", labels, checked, "적용") { sel ->
            val beforeBm = prefs.bookmarks()
            val beforeFolders = prefs.folders(Prefs.KIND_BM).map { it.id }.toSet()
            var moved = 0
            moves.forEachIndexed { i, m ->
                if (!sel[i]) return@forEachIndexed
                val fid = prefs.folders(Prefs.KIND_BM).firstOrNull { it.name.equals(m.folder, ignoreCase = true) }?.id
                    ?: prefs.addFolder(Prefs.KIND_BM, m.folder).id
                m.items.forEach { prefs.moveBookmark(it.id, fid); moved++ }
            }
            var removed = 0
            if (dupCount > 0 && sel[labels.lastIndex]) {
                val ids = dupes.flatMap { g -> g.drop(1).map { it.id } }.toSet()
                prefs.removeBookmarks(ids)
                removed = ids.size
            }
            refreshView()
            val parts = ArrayList<String>()
            if (moved > 0) parts.add("${moved}개 폴더로 옮김")
            if (removed > 0) parts.add("중복 ${removed}개 삭제")
            ListUi.undoToast(this, "북마크를 정리했어요 · " + parts.joinToString(", ")) {
                // 새로 만든 폴더를 먼저 치우고, 북마크는 정리 전 목록 그대로 되돌린다
                prefs.folders(Prefs.KIND_BM).filter { it.id !in beforeFolders }.forEach { prefs.removeFolder(Prefs.KIND_BM, it.id) }
                prefs.restoreBookmarks(beforeBm)
                refreshView()
            }
        }
    }

    /** 묻지 않고 바로 지우고, 알림의 '실행 취소' 로 되돌릴 수 있게 한다 */
    private fun deleteMany(ids: Set<Long>) {
        val n = ids.size
        val before = prefs.bookmarks()
        prefs.removeBookmarks(ids)
        select.finishDelete()
        refreshView()
        ListUi.undoToast(this, "북마크 ${n}개를 삭제했습니다") {
            prefs.restoreBookmarks(before)
            refreshView()
        }
    }

    private fun refreshView() {
        val all = prefs.bookmarks()
        val folders = prefs.folders(Prefs.KIND_BM)
        folderNames = folders.associate { it.id to it.name }
        if (selected != ListUi.ALL && folders.none { it.id == selected }) selected = ListUi.ALL

        val entries = ArrayList<ListUi.ChipEntry>()
        entries.add(ListUi.ChipEntry(ListUi.ALL, "전체 (${all.size})"))
        folders.forEach { f ->
            entries.add(ListUi.ChipEntry(f.id, "${f.name} (${all.count { it.folderId == f.id }})"))
        }
        ListUi.renderChips(
            chipRow, entries, selected,
            onSelect = {
                selected = it
                select.exit()
                refreshView()
            },
            onLongPress = { id ->
                folders.firstOrNull { it.id == id }?.let { f ->
                    ListUi.showFolderMenu(this, prefs, Prefs.KIND_BM, f) { refreshView() }
                }
            },
            onAdd = {
                ListUi.createFolder(this, prefs, Prefs.KIND_BM) {
                    selected = it.id
                    refreshView()
                }
            }
        )

        shown.clear()
        shown.addAll(if (selected == ListUi.ALL) all else all.filter { it.folderId == selected })
        select.retain()
        adapter.notifyDataSetChanged()

        if (shown.isEmpty()) {
            emptyView.text =
                if (selected == ListUi.ALL) "북마크가 없습니다\n웹페이지에서 메뉴 → '북마크에 추가' 를 눌러 보세요"
                else "이 폴더는 비어 있습니다\n북마크의 ⋮ 메뉴 → '폴더로 이동' 으로 옮겨 보세요"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = shown[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)
            val b = shown[position]

            select.bindRow(v, b.id, R.drawable.ic_bookmark)
            if (!select.active || !select.isSelected(b.id)) Favicons.apply(v.findViewById(R.id.rowIcon), b.url)
            v.findViewById<ProgressBar>(R.id.rowProgress).visibility = View.GONE
            v.findViewById<TextView>(R.id.rowTitle).text = ListUi.displayTitle(b.title, b.url)
            val folder = folderNames[b.folderId]
            v.findViewById<TextView>(R.id.rowSub).text =
                if (folder != null && selected == ListUi.ALL) "${b.url} · $folder" else b.url

            v.setOnClickListener { if (select.active) select.toggle(b.id) else openUrl(b.url, newTab = false) }
            v.setOnLongClickListener {
                if (select.active) select.toggle(b.id) else select.enter(b.id)
                true
            }
            v.findViewById<ImageButton>(R.id.rowMore).setOnClickListener { showMenu(b) }
            return v
        }
    }

    private fun openUrl(url: String, newTab: Boolean) {
        setResult(
            RESULT_OK,
            Intent().putExtra(EXTRA_URL, url).putExtra(EXTRA_NEW_TAB, newTab)
        )
        ListUi.closeSheet(this)
    }

    private fun showMenu(b: Bookmark) {
        Popup.menu(
            this,
            title = ListUi.displayTitle(b.title, b.url),
            subtitle = b.url,
            headerIcon = R.drawable.ic_bookmark,
            items = listOf(
                Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { openUrl(b.url, newTab = true) },
                Popup.Item(R.drawable.ic_edit, "수정") {
                    ListUi.showBookmarkEditor(this, prefs, b, b.url, b.title) { msg ->
                        ListUi.toast(this, msg)
                        refreshView()
                    }
                },
                Popup.Item(R.drawable.ic_folder, "폴더로 이동") {
                    ListUi.pickFolder(this, prefs, Prefs.KIND_BM, b.folderId) { folderId ->
                        prefs.moveBookmark(b.id, folderId)
                        refreshView()
                        val name = prefs.folders(Prefs.KIND_BM).firstOrNull { it.id == folderId }?.name
                        ListUi.toast(this, if (name == null) "폴더에서 뺐습니다" else "'$name' 폴더로 옮겼습니다")
                    }
                },
                Popup.Item(R.drawable.ic_copy, "주소 복사") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("url", b.url))
                    ListUi.toast(this, "복사했습니다")
                },
                Popup.Item(R.drawable.ic_delete, "삭제", danger = true) {
                    Popup.confirm(
                        this, "북마크를 삭제할까요?",
                        "'${ListUi.displayTitle(b.title, b.url)}'", "삭제", danger = true
                    ) {
                        prefs.removeBookmark(b.id)
                        refreshView()
                    }
                }
            )
        )
    }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_NEW_TAB = "newTab"
    }
}
