package com.example.evergreen

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.text.InputType
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * AI 창에 뜨는 에이전트 진행 카드. AI 가 앱 기능(도구)을 쓰는 동안 "열린 탭 확인하는 중…" 같은 줄이 하나씩 쌓이고,
 * 줄마다 돌아가는 표시 → ✓(성공) / ✕(실패) 로 바뀐다. 머리글의 「중지」 로 바로 멈출 수 있다.
 */
class AgentProgressCard(
    context: Context,
    private val fg: Int,
    private val fgDim: Int,
    private val accent: Int,
    private val bad: Int,
    private val fill: Int,
    private val line: Int,
    private val onStop: () -> Unit
) : LinearLayout(context) {

    /** [sub] 는 진행 한 줄 전체 (단계 막대 + 설명 + 글자 수). 막대 · 글자는 [setStepDetail] 이 채운다 */
    private class Row(
        val spinner: ProgressBar, val mark: TextView, val text: TextView, val sub: LinearLayout,
        val segs: LinearLayout, val count: TextView, val what: TextView, val extra: TextView,
        /** 만들기 · 고치기 줄에서 돌림 막대 자리에 보이는 「만드는 중」 모양 (그 밖의 줄은 null) */
        val glyph: View? = null,
        /** 만들기 줄에서 처음엔 접어 두는 아이콘 칸과 글 칸 (끝나면 ✓ / ✕ 를 보이려고 펼친다) */
        val hiddenIcon: View? = null,
        val textCol: View? = null
    ) {
        var pulse: android.animation.ObjectAnimator? = null
        var segTotal = 0
    }

    private val rows = LinkedHashMap<Int, Row>()

    /** 자율 모드 계획의 한 줄 */
    private class PlanRow(val mark: TextView, val text: TextView)

    private val planRows = ArrayList<PlanRow>()
    private val planBox = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        visibility = View.GONE
    }
    private var undoBtn: TextView? = null
    private var resumeBox: LinearLayout? = null
    private var settingsBox: LinearLayout? = null
    private val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val status = TextView(context)
    /** 만들기 · 고치기 도구가 도는 동안 「만드는 중…」 글자 바로 앞(머리글 맨 앞)에 보이는 「만드는 중」 애니메이션 */
    private val buildGlyph = ThinkingGlyphView(context, ThinkKind.BUILD, scale = 0.85f).apply { visibility = View.GONE }
    private val stop = TextView(context)
    private var finished = false
    private var failedSteps = 0

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), line)
        }

        status.apply {
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fgDim)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            text = "작업 준비 중…"
        }
        stop.apply {
            text = "중지"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(bad)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), bad)
            }
            contentDescription = "AI 작업 중지"
            setOnClickListener {
                if (finished) return@setOnClickListener
                // 눌렀다는 걸 바로 보여 주고, 실제 중지는 AI 창이 맡는다
                isEnabled = false
                alpha = 0.5f
                status.text = "중지하는 중…"
                onStop()
            }
            Motion.pressable(this, 0.93f)
        }
        val head = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(buildGlyph, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(8) })
            addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) })
        }
        addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(planBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    /** 자율 모드: 승인된 계획을 단계별 체크 목록으로 보여 준다 (계획이 다시 세워지면 새로 그린다) */
    fun setPlan(steps: List<String>) {
        if (finished) return
        planBox.removeAllViews()
        planRows.clear()
        planBox.visibility = View.VISIBLE
        planBox.addView(TextView(context).apply {
            text = "계획"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fgDim)
        })
        steps.forEachIndexed { i, s ->
            val mark = TextView(context).apply {
                text = "○"
                textSize = 13f
                setTextColor(fgDim)
                gravity = Gravity.CENTER
            }
            val tv = TextView(context).apply {
                text = "${i + 1}. $s"
                textSize = 13f
                setTextColor(fg)
                setLineSpacing(0f, 1.1f)
            }
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(mark, LinearLayout.LayoutParams(dp(20), ViewGroup.LayoutParams.WRAP_CONTENT))
                addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
            }
            planBox.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
            planRows.add(PlanRow(mark, tv))
        }
    }

    /** 계획의 [index] 번(1부터) 단계 상태: done → ✓, failed → ✕, skipped → – */
    fun markPlan(index: Int, status: String) {
        val r = planRows.getOrNull(index - 1) ?: return
        when (status) {
            "done" -> {
                r.mark.text = "✓"
                r.mark.setTextColor(accent)
            }
            "failed" -> {
                r.mark.text = "✕"
                r.mark.setTextColor(bad)
                r.text.setTextColor(bad)
            }
            else -> {
                r.mark.text = "–"
                r.mark.setTextColor(fgDim)
                r.text.setTextColor(fgDim)
            }
        }
    }

    /**
     * 에이전트가 바꾼 설정을 토글 · 세 칸 선택 · −/+ 로 보여 준다. 누르면 그 설정만 바로 바뀐다 ([onChange]).
     * [values] 는 이름 → 지금 값 (ad_block · bookmark_bar: on/off, web_dark_mode: off/device/always, text_zoom: 50~200)
     */
    fun showSettingControls(values: Map<String, String>, onChange: (name: String, value: String) -> Unit) {
        if (settingsBox != null || values.isEmpty()) return
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        box.addView(View(context).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(match, dp(1)).apply { topMargin = dp(10) })
        var added = 0
        for ((name, v0) in values) {
            val def = AgentSettings.find(name) ?: continue
            val label = def.label
            val control: View = when {
                name == "web_dark_mode" -> settingSegment(listOf("off" to "끔", "device" to "기기", "always" to "항상"), v0) { onChange(name, it) }
                name == "text_zoom" -> settingStepper(v0.toIntOrNull() ?: 100) { onChange(name, it.toString()) }
                // 켜고 끄는 설정은 모두 스위치로 (광고 차단 · 북마크바 · 번역 · 보안 …)
                def.kind == AgentSettings.Kind.BOOL -> settingSwitch(v0 == "on") { on -> onChange(name, if (on) "on" else "off") }
                else -> continue
            }
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(TextView(context).apply {
                    text = label
                    textSize = 13f
                    setTextColor(fg)
                }, LinearLayout.LayoutParams(0, wrap, 1f))
                addView(control, LinearLayout.LayoutParams(wrap, wrap))
            }
            box.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
            added++
        }
        if (added == 0) return
        box.addView(TextView(context).apply {
            text = "누르면 그 설정만 바로 바뀌어요"
            textSize = 11f
            setTextColor(fgDim)
        }, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(6) })
        settingsBox = box
        addView(box, LinearLayout.LayoutParams(match, wrap))
    }

    // 설정 화면의 켜고 끄는 항목과 같은 MaterialSwitch 를 그대로 쓴다 (색도 같은 테마 색)
    private fun settingSwitch(on: Boolean, onToggle: (Boolean) -> Unit): View =
        com.google.android.material.materialswitch.MaterialSwitch(context).apply {
            isChecked = on
            contentDescription = "설정 켜고 끄기"
            ThemeColors.skin(this)
            setOnCheckedChangeListener { _, c -> onToggle(c) }
        }

    private fun settingSegment(options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit): View {
        var sel = current
        val cells = ArrayList<Pair<String, TextView>>()
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadius = dp(15).toFloat()
                setStroke(dp(1), accent)
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        fun paint() {
            for ((key, tv) in cells) {
                val on = key == sel
                tv.setTextColor(if (on) fill else accent)
                tv.background = if (on) GradientDrawable().apply {
                    cornerRadius = dp(13).toFloat()
                    setColor(accent)
                } else null
            }
        }
        for ((key, text) in options) {
            val tv = TextView(context).apply {
                this.text = text
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(4), dp(10), dp(4))
                isClickable = true
                setOnClickListener {
                    if (sel == key) return@setOnClickListener
                    sel = key
                    paint()
                    onPick(key)
                }
            }
            cells.add(key to tv)
            bar.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        paint()
        return bar
    }

    private fun settingStepper(start: Int, onValue: (Int) -> Unit): View {
        var v = start
        val value = TextView(context).apply {
            text = "$v%"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fg)
            gravity = Gravity.CENTER
            minWidth = dp(46)
        }
        fun btn(label: String, delta: Int) = TextView(context).apply {
            text = label
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(1), accent)
            }
            isClickable = true
            contentDescription = if (delta > 0) "글자 크기 키우기" else "글자 크기 줄이기"
            setOnClickListener {
                val n = (v + delta).coerceIn(50, 200)
                if (n == v) return@setOnClickListener
                v = n
                value.text = "$v%"
                onValue(v)
            }
        }
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(btn("−", -10), LinearLayout.LayoutParams(dp(28), dp(28)))
            addView(value, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(btn("+", 10), LinearLayout.LayoutParams(dp(28), dp(28)))
        }
    }

    /**
     * 오류 · 단계 한도로 멈췄을 때 맨 아래에 「이어서 하기」 를 단다. [done] 은 이미 끝낸 일의 수 (0 이면 안 보여 준다).
     * 누르면 [onResume] 으로 알리고, 부른 쪽이 [reopen] 으로 카드를 다시 돌리는 모양으로 되돌린다.
     */
    fun showResume(done: Int, onResume: () -> Unit) {
        if (resumeBox != null) return
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        box.addView(View(context).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(match, dp(1)).apply { topMargin = dp(10) })
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(context).apply {
            text = if (done > 0) "${done}개 끝냈어요 · 남은 일만 이어서 해요" else "남은 일만 이어서 해요"
            textSize = 12f
            setTextColor(fgDim)
            setLineSpacing(0f, 1.1f)
        }, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(TextView(context).apply {
            text = "↻ 이어서 하기"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fill)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(accent)
            }
            isClickable = true
            contentDescription = "멈춘 곳에서부터 이어서 하기"
            setOnClickListener {
                // 두 번 눌러도 한 번만 이어 가게 바로 잠근다
                if (!isEnabled) return@setOnClickListener
                isEnabled = false
                alpha = 0.6f
                text = "이어 가는 중…"
                onResume()
            }
            Motion.pressable(this, 0.94f)
        }, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(10) })
        box.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })
        resumeBox = box
        addView(box, LinearLayout.LayoutParams(match, wrap))
    }

    /**
     * 멈췄던 카드를 다시 돌아가는 모양으로 되돌린다 (이어서 하기). 앞에서 한 일 줄은 그대로 두고,
     * 「이어서 하기」 · 「되돌리기」 · 설정 토글은 치웠다가 다음에 멈출 때 새로 단다. 중지 버튼이 다시 보인다.
     */
    fun reopen() {
        if (!finished) return
        finished = false
        resumeBox?.let { removeView(it) }
        resumeBox = null
        undoBtn?.let { removeView(it) }
        undoBtn = null
        settingsBox?.let { removeView(it) }
        settingsBox = null
        stop.visibility = View.VISIBLE
        stop.isEnabled = true
        stop.alpha = 1f
        status.setTextColor(fgDim)
        status.text = "이어서 하는 중…"
        // 앞 줄과 이어서 하는 줄 사이에 작은 구분 글을 둔다
        body.addView(TextView(context).apply {
            text = "↻ 여기서부터 이어서"
            textSize = 11f
            setTextColor(fgDim)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
            bottomMargin = dp(2)
        })
    }

    /** 끝난 뒤 맨 아래에 「되돌리기」 버튼을 단다 ([count] 건을 되돌릴 수 있다). 누르면 [onUndo] 로 알린다 */
    fun showUndo(count: Int, onUndo: () -> Unit) {
        if (undoBtn != null || count <= 0) return
        val b = TextView(context).apply {
            text = "↶ 한 일 되돌리기 ($count)"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), accent)
            }
            isClickable = true
            contentDescription = "에이전트가 한 일 되돌리기"
            setOnClickListener {
                isEnabled = false
                alpha = 0.5f
                text = "되돌리는 중…"
                onUndo()
            }
            Motion.pressable(this, 0.94f)
        }
        undoBtn = b
        addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
            gravity = Gravity.END
        })
    }

    /** 되돌리기가 끝났다: 버튼에 결과를 적고, 못 되돌린 건 이유를 아래에 보여 준다 */
    fun setUndoResult(results: List<Pair<Boolean, String>>) {
        val ok = results.count { it.first }
        undoBtn?.apply {
            text = if (ok == results.size) "↶ ${ok}건 되돌렸어요" else "↶ ${ok}건 되돌림 · ${results.size - ok}건은 그대로예요"
            setTextColor(fgDim)
            background = null
        }
        for ((good, line) in results) {
            if (good) continue
            addView(TextView(context).apply {
                text = "✕ $line"
                textSize = 12f
                setTextColor(bad)
                setLineSpacing(0f, 1.1f)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
    }

    /** 만들기 · 고치기 도구가 도는 동안 「만드는 중…」 앞에 애니메이션을 보이고 끈다 (끝난 카드에는 보이지 않는다) */
    fun setBuilding(on: Boolean) {
        buildGlyph.visibility = if (on && !finished) View.VISIBLE else View.GONE
    }

    /** 머리글 한 줄 ("생각하는 중… (2/10단계)" 등). 끝난 뒤에는 바뀌지 않는다 */
    fun setStatus(text: String) {
        if (finished) return
        // 중지 버튼을 누른 뒤에는 "중지하는 중…" 을 덮어쓰지 않는다
        if (!stop.isEnabled) return
        status.text = text
    }

    /** 새 줄: 도구 하나를 실행하기 시작했다 */
    fun addStep(id: Int, label: String, building: Boolean = false) {
        if (finished || rows.containsKey(id)) return
        val spinner = ProgressBar(context, null, android.R.attr.progressBarStyleSmall).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(accent)
        }
        // 만드는 줄: 맨 위 머리글에 「만드는 중」 애니메이션이 있으니 줄의 돌림 막대(로딩원)는 안 보이게 한다.
        // 막대는 진행 상태 표시용으로만 남겨 두고 투명하게 둔다 (setStepDetail 이 막대가 보이는 줄만 갱신한다)
        val glyph: View? = null
        if (building) spinner.alpha = 0f
        val mark = TextView(context).apply {
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        val icon = FrameLayout(context).apply {
            addView(spinner, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER))
            if (glyph != null) addView(glyph, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
            addView(mark, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }
        val tv = TextView(context).apply {
            textSize = 13f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
            text = label
        }
        // 글 아래에 진행 한 줄이 실시간으로 뜬다 (AI 로 만드는 일처럼 오래 걸리는 도구):
        //  [━━ ━━ ━━ ━━]  1/4          ← 단계 막대 (끝난 칸은 꽉 차고, 지금 칸은 깜빡인다)
        //  코드를 쓰는 중        1,240자  ← 하는 일 + 덧붙이는 말(글자 수 · 몇 번째 고침)
        val segs = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val count = TextView(context).apply {
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fgDim)
        }
        val barRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(segs, LinearLayout.LayoutParams(0, dp(4), 1f))
            addView(count, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) })
        }
        val what = TextView(context).apply {
            textSize = 12.5f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
        }
        val extra = TextView(context).apply {
            textSize = 11.5f
            setTextColor(accent)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.END
            visibility = View.GONE
        }
        val textRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(what, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(extra, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }
        val sub = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(barRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(textRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) })
        }
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv)
            addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        }
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            // 아래에 진행 줄이 붙어 줄 묶음이 길어져도 아이콘은 글자가 있는 첫 줄에 붙어 있게 위쪽에 맞춘다
            gravity = Gravity.TOP
            addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = if (building) 0 else dp(8) })
        }
        // 만드는 줄: 로딩원이 없으니 빈 아이콘 칸을 접어서 글이 카드 왼쪽 여백에 바로 붙게 한다 (오른쪽 여백과 같아짐)
        if (building) icon.visibility = View.GONE
        body.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        rows[id] = Row(spinner, mark, tv, sub, segs, count, what, extra, glyph, if (building) icon else null, if (building) col else null)
    }

    private val phaseRe = Regex("^(\\d+)/(\\d+) · (.+?)(?: · (.+))?$")

    /**
     * 돌고 있는 줄 아래에 진행 한 줄을 띄운다 (끝난 줄 · 없는 줄은 무시).
     * 「2/4 · 코드를 쓰는 중 · 1,240자」 꼴이면 단계 막대 + 설명 + 글자 수로 그리고, 아니면 설명 한 줄로만 보여 준다.
     */
    fun setStepDetail(id: Int, text: String) {
        if (finished) return
        val r = rows[id] ?: return
        if (r.spinner.visibility != View.VISIBLE) return
        val m = phaseRe.matchEntire(text)
        val n = m?.groupValues?.get(1)?.toIntOrNull()
        val total = m?.groupValues?.get(2)?.toIntOrNull()
        if (m != null && n != null && total != null && total in 1..8 && n in 1..total) {
            if (r.segTotal != total) buildSegments(r, total)
            paintSegments(r, n, total)
            r.segs.visibility = View.VISIBLE
            r.count.visibility = View.VISIBLE
            r.count.text = "$n/$total"
            val extra = m.groupValues[4]
            // 짧은 덧붙임(글자 수 · 몇 번째)은 오른쪽에, 긴 안내 문장은 설명 아래 줄에 (오른쪽에 두면 설명이 접힌다)
            val longExtra = extra.length > 9
            val what = if (longExtra) m.groupValues[3] + "\n" + extra else m.groupValues[3]
            if (r.what.text.toString() != what) r.what.text = what
            r.extra.text = if (longExtra) "" else extra
            r.extra.visibility = if (extra.isEmpty() || longExtra) View.GONE else View.VISIBLE
        } else {
            r.segs.visibility = View.GONE
            r.count.visibility = View.GONE
            r.extra.visibility = View.GONE
            if (r.what.text.toString() != text) r.what.text = text
        }
        r.sub.visibility = View.VISIBLE
    }

    private fun buildSegments(r: Row, total: Int) {
        r.pulse?.cancel()
        r.pulse = null
        r.segs.removeAllViews()
        r.segTotal = total
        repeat(total) { i ->
            r.segs.addView(View(context), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                if (i > 0) marginStart = dp(3)
            })
        }
    }

    /** [n] 번째 칸까지 채운다: 앞 칸은 꽉 찬 색, 지금 칸은 깜빡이는 색, 뒤 칸은 빈 색. 마지막 단계(미리보기)는 모두 꽉 찬다 */
    private fun paintSegments(r: Row, n: Int, total: Int) {
        r.pulse?.cancel()
        r.pulse = null
        for (i in 0 until total) {
            val v = r.segs.getChildAt(i) ?: continue
            v.alpha = 1f
            val on = i < n
            v.background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(if (on) accent else line)
            }
        }
        if (n < total) {
            val cur = r.segs.getChildAt(n - 1) ?: return
            r.pulse = android.animation.ObjectAnimator.ofFloat(cur, View.ALPHA, 1f, 0.35f).apply {
                duration = 700
                repeatMode = android.animation.ValueAnimator.REVERSE
                repeatCount = android.animation.ValueAnimator.INFINITE
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        for ((_, r) in rows) { r.pulse?.cancel(); r.pulse = null }
        super.onDetachedFromWindow()
    }

    /** 접어 두었던 아이콘 칸을 펼친다 (끝난 줄에 ✓ / ✕ / – 를 보이려고) */
    private fun unfoldIcon(r: Row) {
        val ic = r.hiddenIcon ?: return
        ic.visibility = View.VISIBLE
        (r.textCol?.layoutParams as? LinearLayout.LayoutParams)?.marginStart = dp(8)
        r.textCol?.requestLayout()
    }

    /** 줄 하나가 끝났다: 성공이면 ✓, 실패면 ✕ 와 이유 */
    fun finishStep(id: Int, ok: Boolean, summary: String) {
        val r = rows[id] ?: return
        r.pulse?.cancel(); r.pulse = null
        r.glyph?.visibility = View.GONE
        unfoldIcon(r)
        r.sub.visibility = View.GONE
        if (!ok) failedSteps++
        r.spinner.visibility = View.GONE
        r.mark.visibility = View.VISIBLE
        r.mark.text = if (ok) "✓" else "✕"
        r.mark.setTextColor(if (ok) accent else bad)
        if (summary.isNotBlank()) {
            r.text.text = summary
            r.text.setTextColor(if (ok) fg else bad)
        }
    }

    /** 실행이 끝났다: 중지 버튼을 치우고 머리글에 결과를 적는다. 아직 돌던 줄은 멈춘 걸로 바꾼다 */
    fun finish(end: AgentEnd) {
        if (finished) return
        finished = true
        stop.visibility = View.GONE
        buildGlyph.visibility = View.GONE
        for ((_, r) in rows) {
            if (r.spinner.visibility == View.VISIBLE) {
                r.pulse?.cancel(); r.pulse = null
                r.glyph?.visibility = View.GONE
                unfoldIcon(r)
                r.sub.visibility = View.GONE
                r.spinner.visibility = View.GONE
                r.mark.visibility = View.VISIBLE
                r.mark.text = "–"
                r.mark.setTextColor(fgDim)
            }
        }
        val (label, color) = when (end) {
            AgentEnd.DONE -> if (failedSteps > 0) "마쳤지만 일부는 못 했어요" to bad else "작업을 마쳤어요" to accent
            AgentEnd.STOPPED -> "중지했어요" to fgDim
            AgentEnd.LIMIT -> "단계 한도에 도달해서 멈췄어요" to bad
            AgentEnd.ERROR -> "오류로 멈췄어요" to bad
        }
        status.text = label
        status.setTextColor(color)
    }
}

/**
 * 에이전트가 읽기가 아닌 일(탭 열기 · 설정 바꾸기 · 다운로드 등)을 하기 전에 AI 창에 뜨는 확인 카드.
 * 「허락」 / 「거절」 중 하나를 누르면 [onAnswer] 로 알리고, 이후 카드를 치우는 일은 부른 쪽이 맡는다.
 * [danger] 면 위험한 작업이라는 표시로 강조색을 쓴다.
 */
class AgentConfirmCard(
    context: Context,
    what: String,
    detail: String,
    danger: Boolean,
    fg: Int,
    private val fgDim: Int,
    accent: Int,
    bad: Int,
    private val fill: Int,
    line: Int,
    private val onAnswer: (Boolean) -> Unit
) : LinearLayout(context) {

    private var answered = false

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun button(label: String, color: Int, filled: Boolean, answer: Boolean) = TextView(context).apply {
        text = label
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setTextColor(if (filled) fill else color)
        setPadding(dp(18), dp(8), dp(18), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            if (filled) setColor(color) else setStroke(dp(1), color)
        }
        isClickable = true
        contentDescription = label
        setOnClickListener {
            if (answered) return@setOnClickListener
            answered = true
            // 두 번 눌러도 한 번만 전달되고, 눌렀다는 걸 바로 보여 준다
            this@AgentConfirmCard.alpha = 0.6f
            onAnswer(answer)
        }
        Motion.pressable(this, 0.94f)
    }

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        val tone = if (danger) bad else accent
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), tone)
        }
        addView(TextView(context).apply {
            text = if (danger) "⚠ 이 작업을 해도 될까요?" else "AI가 앱을 조작하려고 해요"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(tone)
        })
        addView(TextView(context).apply {
            text = what
            textSize = 14f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        if (detail.isNotBlank()) {
            addView(TextView(context).apply {
                text = detail
                textSize = 12f
                setTextColor(fgDim)
                setLineSpacing(0f, 1.1f)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            addView(button("거절", fgDim, filled = false, answer = false))
            addView(button("허락", tone, filled = true, answer = true), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
    }
}

/**
 * 에이전트가 사용자에게 묻는 카드 (자율 모드에서 막혔을 때 · 확장 프로그램 적용 범위 고르기 등).
 * 모양은 에이전트 진행 카드와 같다: 같은 바탕 · 테두리, 머리글(굵은 회색 글) + 오른쪽 알약 버튼(「건너뛰기」), 아래에 줄(○ + 글)로 선택지.
 * 선택지 줄을 눌러 고르거나 직접 입력한 뒤 「확인」 을 눌러야 답이 전달된다. 「건너뛰기」 는 답하지 않겠다는 뜻이라 [onAnswer] 에 null 을 준다. 한 번 답하면 다시 눌러도 전달되지 않는다.
 */
class AgentAskCard(
    context: Context,
    question: String,
    options: List<String>,
    private val fg: Int,
    private val fgDim: Int,
    private val accent: Int,
    private val fill: Int,
    private val line: Int,
    private val onAnswer: (String?) -> Unit
) : LinearLayout(context) {

    private var answered = false

    /** 지금 고른 선택지 (직접 입력을 시작하면 비워진다) */
    private var selected: String? = null
    private val optionMarks = ArrayList<Pair<String, TextView>>()
    private var okBtn: TextView? = null
    private var input: EditText? = null

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun answer(v: String?) {
        if (answered) return
        answered = true
        alpha = 0.6f
        onAnswer(v)
    }

    /** 고른 선택지 · 직접 입력 글 (없으면 null) */
    private fun chosen(): String? = selected ?: input?.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }

    private fun refreshChoice() {
        for ((label, mark) in optionMarks) mark.text = if (label == selected) "●" else "○"
        okBtn?.alpha = if (chosen() != null) 1f else 0.4f
    }

    private fun pill(label: String, color: Int, desc: String, onClick: () -> Unit) = TextView(context).apply {
        text = label
        textSize = 12f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(5), dp(12), dp(5))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), color)
        }
        contentDescription = desc
        isClickable = true
        setOnClickListener { onClick() }
        Motion.pressable(this, 0.93f)
    }

    private fun optionRow(label: String): LinearLayout {
        val mark = TextView(context).apply {
            text = "○"
            textSize = 14f
            setTextColor(accent)
            gravity = Gravity.CENTER
        }
        val tv = TextView(context).apply {
            text = label
            textSize = 13.5f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
        }
        optionMarks.add(label to mark)
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), line)
            }
            addView(mark, LinearLayout.LayoutParams(dp(20), ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
            isClickable = true
            contentDescription = label
            setOnClickListener {
                if (answered) return@setOnClickListener
                // 고르기만 한다: 「확인」 을 눌러야 전달된다
                selected = label
                input?.setText("")
                refreshChoice()
            }
            Motion.pressable(this, 0.98f)
        }
    }

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), line)
        }
        // 머리글: 진행 카드의 머리글과 같은 모양 (굵은 회색 글 + 오른쪽 알약)
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(context).apply {
                text = "AI가 물어봐요"
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(fgDim)
                maxLines = 1
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(pill("건너뛰기", fgDim, "답하지 않고 건너뛰기") { answer(null) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(TextView(context).apply {
            text = question
            textSize = 13.5f
            setTextColor(fg)
            setLineSpacing(0f, 1.1f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        for (o in options) {
            addView(optionRow(o), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        }
        val field = EditText(context).apply {
            hint = if (options.isEmpty()) "답을 입력하세요" else "직접 입력"
            textSize = 13.5f
            setTextColor(fg)
            setHintTextColor(fgDim)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            maxLines = 3
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), line)
            }
        }
        input = field
        val confirm = {
            val v = chosen()
            if (v != null) answer(v)
        }
        field.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                // 직접 입력을 시작하면 고른 선택지는 풀린다
                if (!e.isNullOrEmpty() && selected != null) selected = null
                refreshChoice()
            }
        })
        field.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                confirm()
                true
            } else false
        }
        addView(field, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        val ok = TextView(context).apply {
            text = "확인"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(fill)
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(8), dp(20), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(accent)
            }
            contentDescription = "선택 확인"
            isClickable = true
            setOnClickListener { confirm() }
            Motion.pressable(this, 0.94f)
        }
        okBtn = ok
        addView(ok, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.END
            topMargin = dp(10)
        })
        refreshChoice()
    }
}
