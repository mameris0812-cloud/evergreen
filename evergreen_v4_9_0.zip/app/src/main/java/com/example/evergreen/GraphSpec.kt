package com.example.evergreen

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * AI 답변 속 ```graph 코드 블록을 읽은 결과. 한 줄에 「키: 값」 하나씩 쓴다.
 *
 *   title: 제목            xlabel: 가로축 이름        ylabel: 세로축 이름
 *   x: -5..5               y: -10..10 (생략하면 자동)
 *   fn: x^2 - 2x + 1 | f(x)          (함수. 여러 줄이면 여러 개)
 *   line: 이름 | 1:3, 2:5, 3:4        (꺾은선. 「3, 5, 4」 처럼 y 만 쓰면 x 는 1, 2, 3…)
 *   bar: 이름 | 1월:30, 2월:45        (막대. 여러 줄이면 묶음 막대)
 *   point: 2, 3, 꼭짓점               (점)
 *   hline: 0    vline: 2              (점선 보조선)
 *
 * 화면 그리기는 [GraphView] 가 맡는다. 이 파일에는 안드로이드 의존이 없다.
 */
class GraphSpec {
    class Fn(val label: String, val expr: GraphExpr)
    class Series(val label: String, val xs: DoubleArray, val ys: DoubleArray)
    class BarSet(val label: String, val cats: List<String>, val values: DoubleArray)
    class Marker(val x: Double, val y: Double, val label: String)

    var title = ""
    var xLabel = ""
    var yLabel = ""
    var xMin: Double? = null
    var xMax: Double? = null
    var yMin: Double? = null
    var yMax: Double? = null
    val fns = ArrayList<Fn>()
    val lines = ArrayList<Series>()
    val bars = ArrayList<BarSet>()
    val points = ArrayList<Marker>()
    val hLines = ArrayList<Double>()
    val vLines = ArrayList<Double>()

    /** 그릴 것이 하나도 없다 (아직 받는 중이거나 형식이 틀린 경우) */
    fun isEmpty(): Boolean = fns.isEmpty() && lines.isEmpty() && bars.isEmpty() && points.isEmpty()

    companion object {
        private val fnPrefix = Regex("^[A-Za-z]\\w*\\s*(\\(\\s*x\\s*\\))?\\s*=\\s*")

        private fun num(s: String): Double? {
            val v = GraphExpr.parse(s.trim())?.eval(0.0) ?: return null
            return if (v.isNaN() || v.isInfinite()) null else v
        }

        /** 「-5..5」 「-5, 5」 「-5 ~ 5」 → (-5, 5) */
        private fun range(v: String): Pair<Double, Double>? {
            val parts = v.split("..", "~", ",", "에서", " to ").map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size != 2) return null
            val a = num(parts[0]) ?: return null
            val b = num(parts[1]) ?: return null
            return if (a < b) a to b else if (b < a) b to a else null
        }

        fun parse(src: String): GraphSpec {
            val g = GraphSpec()
            for (raw in src.split("\n")) {
                val line = raw.trim()
                val c = line.indexOf(':')
                if (line.isEmpty() || c <= 0) continue
                val key = line.substring(0, c).trim().lowercase()
                val value = line.substring(c + 1).trim()
                if (value.isEmpty()) continue
                try {
                    when (key) {
                        "title", "제목" -> g.title = value
                        "xlabel", "x축" -> g.xLabel = value
                        "ylabel", "y축" -> g.yLabel = value
                        "x", "xrange" -> range(value)?.let { g.xMin = it.first; g.xMax = it.second }
                        "y", "yrange" -> range(value)?.let { g.yMin = it.first; g.yMax = it.second }
                        "fn", "f", "function", "함수" -> {
                            val bar = value.indexOf('|')
                            val body = (if (bar >= 0) value.substring(0, bar) else value).trim().replace(fnPrefix, "")
                            val label = if (bar >= 0) value.substring(bar + 1).trim() else ""
                            val e = GraphExpr.parse(body)
                            if (e != null) g.fns.add(Fn(label.ifEmpty { body }, e))
                        }
                        "line", "선" -> {
                            val bar = value.indexOf('|')
                            val label = if (bar >= 0) value.substring(0, bar).trim() else ""
                            val data = (if (bar >= 0) value.substring(bar + 1) else value).split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val xs = ArrayList<Double>()
                            val ys = ArrayList<Double>()
                            data.forEachIndexed { i, d ->
                                val p = d.split(":")
                                if (p.size >= 2) {
                                    val x = num(p[0])
                                    val y = num(p[1])
                                    if (x != null && y != null) { xs.add(x); ys.add(y) }
                                } else {
                                    val y = num(d)
                                    if (y != null) { xs.add((i + 1).toDouble()); ys.add(y) }
                                }
                            }
                            if (xs.isNotEmpty()) g.lines.add(Series(label, xs.toDoubleArray(), ys.toDoubleArray()))
                        }
                        "bar", "막대" -> {
                            val bar = value.indexOf('|')
                            val label = if (bar >= 0) value.substring(0, bar).trim() else ""
                            val data = (if (bar >= 0) value.substring(bar + 1) else value).split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val cats = ArrayList<String>()
                            val vals = ArrayList<Double>()
                            for (d in data) {
                                val k = d.lastIndexOf(':')
                                if (k <= 0) continue
                                val y = num(d.substring(k + 1)) ?: continue
                                cats.add(d.substring(0, k).trim())
                                vals.add(y)
                            }
                            if (cats.isNotEmpty()) g.bars.add(BarSet(label, cats, vals.toDoubleArray()))
                        }
                        "point", "점" -> {
                            val p = value.split(",").map { it.trim() }
                            if (p.size >= 2) {
                                val x = num(p[0])
                                val y = num(p[1])
                                if (x != null && y != null) g.points.add(Marker(x, y, p.drop(2).joinToString(", ")))
                            }
                        }
                        "hline" -> num(value)?.let { g.hLines.add(it) }
                        "vline" -> num(value)?.let { g.vLines.add(it) }
                    }
                } catch (e: Exception) {
                    // 한 줄이 틀려도 나머지는 그린다
                }
            }
            return g
        }
    }
}

/**
 * 한 변수 x 의 수식. 덧셈 · 뺄셈 · 곱셈 · 나눗셈 · 거듭제곱(^)과 곱셈 기호 생략(2x, 2(x+1), x(x-1))을 읽고,
 * sin cos tan asin acos atan sqrt abs ln log(상용로그) exp 와 상수 pi · e 를 쓸 수 있다. 각은 라디안이다.
 * 읽지 못하는 식은 [parse] 가 null 을 돌려준다.
 */
class GraphExpr private constructor(private val fn: (Double) -> Double) {

    fun eval(x: Double): Double = fn(x)

    companion object {
        private val funcs: Map<String, (Double) -> Double> = mapOf(
            "asin" to { v: Double -> asin(v) },
            "acos" to { v: Double -> acos(v) },
            "atan" to { v: Double -> atan(v) },
            "sqrt" to { v: Double -> sqrt(v) },
            "sin" to { v: Double -> sin(v) },
            "cos" to { v: Double -> cos(v) },
            "tan" to { v: Double -> tan(v) },
            "abs" to { v: Double -> abs(v) },
            "ln" to { v: Double -> ln(v) },
            "log" to { v: Double -> log10(v) },
            "exp" to { v: Double -> exp(v) }
        )
        // 긴 이름부터 맞춰 본다 ("sinx" → sin + x, "exp" 가 e 보다 먼저)
        private val names = listOf("asin", "acos", "atan", "sqrt", "sin", "cos", "tan", "abs", "exp", "log", "ln", "pi", "x", "e")

        fun parse(src: String): GraphExpr? {
            return try {
                val s = src.trim()
                    .replace("−", "-").replace("–", "-")
                    .replace("×", "*").replace("·", "*").replace("⋅", "*").replace("\\cdot", "*")
                    .replace("÷", "/").replace("**", "^")
                    .replace("²", "^2").replace("³", "^3")
                    .replace("π", "pi").replace("√", "sqrt")
                    .replace(Regex("\\s+"), "")
                    .lowercase()
                if (s.isEmpty() || s.length > 200) return null
                val p = Parser(s)
                val f = p.parseAll()
                GraphExpr(f)
            } catch (e: Exception) {
                null
            }
        }
    }

    private class Parser(val s: String) {
        var i = 0

        fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        fun parseAll(): (Double) -> Double {
            val e = expr()
            if (i < s.length) throw IllegalArgumentException("남은 글자")
            return e
        }

        fun expr(): (Double) -> Double {
            var l: (Double) -> Double = term()
            while (true) {
                val c = peek()
                if (c == '+') {
                    i++
                    val a = l
                    val r = term()
                    l = { x -> a(x) + r(x) }
                } else if (c == '-') {
                    i++
                    val a = l
                    val r = term()
                    l = { x -> a(x) - r(x) }
                } else return l
            }
        }

        private fun startsFactor(c: Char): Boolean = c.isLetter() || c.isDigit() || c == '(' || c == '.'

        fun term(): (Double) -> Double {
            var l: (Double) -> Double = unary()
            while (true) {
                val c = peek()
                if (c == '*') {
                    i++
                    val a = l
                    val r = unary()
                    l = { x -> a(x) * r(x) }
                } else if (c == '/') {
                    i++
                    val a = l
                    val r = unary()
                    l = { x -> a(x) / r(x) }
                } else if (startsFactor(c)) {
                    // 곱셈 기호 생략: 2x, 2(x+1), x(x-1), 3sinx
                    val a = l
                    val r = power()
                    l = { x -> a(x) * r(x) }
                } else return l
            }
        }

        fun unary(): (Double) -> Double {
            val c = peek()
            if (c == '-') {
                i++
                val u = unary()
                return { x -> -u(x) }
            }
            if (c == '+') {
                i++
                return unary()
            }
            return power()
        }

        fun power(): (Double) -> Double {
            val base = atom()
            if (peek() == '^') {
                i++
                val ex = unary()
                return { x -> base(x).pow(ex(x)) }
            }
            return base
        }

        fun atom(): (Double) -> Double {
            val c = peek()
            if (c == '(') {
                i++
                val e = expr()
                if (peek() != ')') throw IllegalArgumentException("괄호")
                i++
                return e
            }
            if (c.isDigit() || c == '.') {
                val st = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                val v = s.substring(st, i).toDouble()
                return { _ -> v }
            }
            if (c.isLetter()) {
                var j = i
                while (j < s.length && s[j].isLetter()) j++
                val run = s.substring(i, j)
                val name = names.firstOrNull { run.startsWith(it) } ?: throw IllegalArgumentException("모르는 이름")
                i += name.length
                if (name == "x") return { x -> x }
                if (name == "e") return { _ -> Math.E }
                if (name == "pi") return { _ -> Math.PI }
                val f = funcs[name] ?: throw IllegalArgumentException("함수")
                val arg = if (peek() == '(') atom() else power()
                return { x -> f(arg(x)) }
            }
            throw IllegalArgumentException("읽을 수 없는 글자")
        }
    }
}
