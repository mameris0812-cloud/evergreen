package com.example.evergreen

import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Region
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.PathParser
import androidx.dynamicanimation.animation.SpringAnimation
import kotlin.math.roundToInt

/**
 * 상/하단바 버튼 아이콘을 직접 그려서, 누르면 아이콘 '모양 자체'가 변하게 한다.
 * 가만히 있을 때(progress = 0)는 ic_*.xml 과 똑같은 모양(24 격자 · 선 1.8 · 둥근 끝)이다.
 *
 *  back/forward : 화살표 몸통이 짧아지며 화살촉이 앞으로 쏜다     home : 지붕이 솟고 문이 길어진다
 *  menu         : 누르는 동안 세 점이 살짝 커지고, 떼면 아래 점부터 차례로 출렁이며 원래 크기로 자리를 잡는다
 *  ai           : 피어남 — 누르는 동안 속이 찬 4갈래 별이 둥글게 오므라들고, 떼면 씨앗처럼 작게 모였다가 피어나(살짝 넘쳤다 자리를 잡음) 제자리로 돌아온다 (돌지도 기울지도 않는다)
 *  newtab       : + 의 선이 줄었다 늘어난다
 *  bookmark     : 누르면 아래가 살짝 말리고, 떼면 현수막처럼 돌돌 말려 올라갔다 펼쳐진다                 bookmarks : 누르면 리본이 좁아지고, 떼면 앞 리본이 비켜서며 뒤에 리본이 한 장 더 펼쳐졌다가 통통 튕기며 모인다
 *  history      : 누르면 바늘이 반시계로 살짝 감기고, 떼면 분침이 시계 방향으로 한 바퀴 돈다(꼬리가 따라 돈다)
 *  downloads    : 누르면 화살표가 살짝 들리고, 떼면 화살표가 받침대 선 속으로 내려가며 가려져 사라지고, 곧 위에서 다시 내려와 자리를 잡는다
 *  find         : 렌즈가 커지며 손잡이를 빨아들여 둥근 링이 되었다가, 손잡이가 튀어나오며 돋보기로 돌아온다
 *  player       : 재생 삼각형이 갈라져 일시정지가 된다
 *  hidebars     : 네 모서리 괄호가 가운데로 모인다                   settings : 톱니가 돌고 가운데 구멍이 커진다
 *  tabs         : 누르는 동안 앞 카드가 왼쪽 아래로 움츠리고, 떼면 뒤 카드가 오른쪽 위로 튀어 오른다. 숫자는 앞 카드와 함께 움직이고,
 *                 탭 개수가 바뀌면 숫자가 위/아래로 굴러 바뀌며 카드가 한 번 출렁인다 (숫자도 이 그림이 직접 그린다)
 *  openplayer   : 상/하단바의 「내장 플레이어로 재생」 — 누르는 동안 삼각형이 작아지고, 떼면 튀어 오르며 삼각형이 세 조각으로 갈라져 그대로 막대(이퀄라이저)가 되어 출렁이다 다시 합쳐진다
 *  pip          : 안쪽 작은 창이 커지며 튀어나온다                   rotate : 폰 모양이 기울었다 돌아온다
 *  extensions   : 퍼즐 조각 — 누르는 동안 조각이 살짝 작아지며 왼쪽으로 기울고, 튀어나온 두 돌기가 몸통 속으로 납작하게 들어간다.
 *                 떼면 조각이 위로 폴짝 뛰어올랐다 내려앉고(기울기도 반대편으로 살짝 넘었다 돌아온다), 위쪽 돌기 → 오른쪽 돌기가 차례로
 *                 '딸깍' 튀어나올 때마다 조각이 그 반대 방향으로 한 번씩 흔들린다
 *  skipback/skipfwd : 10초 이동 — 숫자 10 은 그대로, 꺾이는 화살표만 되감기/빨리감기 방향으로 쏘았다 돌아온다
 *  player (재생/일시정지 버튼) : progress 0 = 재생 삼각형, 1 = 일시정지 — 눌림이 아니라 상태(settle)를 따른다
 */
class MorphIconDrawable(
    private val kind: String,
    private val density: Float,
    private var baseColor: Int = Color.BLACK
) : Drawable() {

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.8f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val backPath = Path()
    private val starPath = Path()
    private val rect = RectF()
    private var tint: ColorStateList? = null
    private var alphaValue = 255

    /** 모양이 변한 정도. 0 = 평소 모양, 1 = 가장 많이 변한 모양 (튕기면서 조금 넘나든다) */
    /** 뒤로·앞으로 버튼을 화살표 대신 < > 모양(몸통 없이 꺾쇠만)으로 그린다 (삼성 테마) */
    var chevron = false
        set(v) { if (field != v) { field = v; invalidateSelf() } }
    var progress = 0f
        private set
    private var anim: SmoothSpring? = null
    private var settled = false

    // ── 탭 버튼 숫자 (tabs): 숫자도 그림이 그려서 카드와 같이 움직이고, 바뀔 때 굴러 바뀐다 ──
    // SUBPIXEL/LINEAR: 글자 크기가 계속 바뀌는 동안에도 글자 사이 간격이 정수 칸으로 끊겨 벌어졌다 붙지 않게 한다
    private val num = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.LINEAR_TEXT_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private var label = ""
    private var prevLabel = ""
    /** 숫자가 굴러 바뀐 정도. 1 = 새 숫자가 자리를 잡음 (튕기면서 조금 넘는다) */
    private var roll = 1f
    /** +1 = 개수가 늘어남 (새 숫자가 아래에서 올라옴), -1 = 줄어듦 (위에서 내려옴) */
    private var rollDir = 1
    private var rollAnim: SpringAnimation? = null

    // ── 내장 플레이어 버튼 (openplayer): 삼각형 ↔ 이퀄라이저 막대로 바뀌는 흐름 (0 → 1, 1.2초 직선) ──
    private var swap = 0f
    private var swapAnim: SmoothClock? = null
    // 재생 ↔ 일시정지 모양 변환용 시계 (스프링처럼 출렁이지 않고 시작·끝이 부드럽게 이어지는 곡선)
    private var settleClock: SmoothClock? = null
    private var menuFrom = 0f // 더보기: 떼는 순간 점이 줄어 있던 정도 (순차로 부푸는 동안 기준)
    private var extFrom = 0.4f // 확장 프로그램: 떼는 순간 조각이 오므라들어 있던 정도 (돌기가 튀어나오는 동안 기준)
    private var aiFrom = 0f // AI: 떼는 순간 큰 별이 오므라들어 있던 정도 0~1 (떼면 이 자세에서 부풀어 오른다)

    private val gearOuter: Path? by lazy {
        try {
            PathParser.createPathFromPathData(GEAR)
        } catch (e: Exception) { null }
    }
    private val rotateArrow: Path? by lazy {
        try { PathParser.createPathFromPathData(ROTATE_ARROW) } catch (e: Exception) { null }
    }
    /** 10초 뒤로/앞으로: 꺾쇠 + 줄 + 반원 (화살표). 눌리면 이것만 가는 방향으로 쏜다 */
    private val skipArrow: Path? by lazy {
        val data = if (kind == "skipback") SKIP_BACK_ARROW else SKIP_FWD_ARROW
        try { PathParser.createPathFromPathData(data) } catch (e: Exception) { null }
    }
    /** 10초 뒤로/앞으로: 숫자 10 (제자리에 그대로 있는다) */
    private val skipDigits: Path? by lazy {
        val data = if (kind == "skipback") SKIP_BACK_DIGITS else SKIP_FWD_DIGITS
        try { PathParser.createPathFromPathData(data) } catch (e: Exception) { null }
    }

    /**
     * AI 버튼의 4갈래 별 (ic_ai.xml 과 같은 모양: 24 격자 한가운데, 꼭짓점 3.5~20.5).
     * [m] = 1 이면 평소 별, 0 이면 같은 네 꼭짓점을 지나는 둥근 원이다. 사이는 곡선의 조절점을 섞어 만들고, 1 보다 크면 꼭지가 더 뾰족해진다.
     */
    private fun buildBigStar(m: Float, out: Path) {
        fun l(a: Float, b: Float) = a + (b - a) * m
        out.reset()
        out.moveTo(12f, 3.5f)
        out.cubicTo(l(16.7f, 12.8f), l(3.5f, 8.6f), l(20.5f, 15.4f), l(7.3f, 11.2f), 20.5f, 12f)
        out.cubicTo(l(20.5f, 15.4f), l(16.7f, 12.8f), l(16.7f, 12.8f), l(20.5f, 15.4f), 12f, 20.5f)
        out.cubicTo(l(7.3f, 11.2f), l(20.5f, 15.4f), l(3.5f, 8.6f), l(16.7f, 12.8f), 3.5f, 12f)
        out.cubicTo(l(3.5f, 8.6f), l(7.3f, 11.2f), l(7.3f, 11.2f), l(3.5f, 8.6f), 12f, 3.5f)
        out.close()
    }

    private fun set(v: Float) {
        progress = v
        invalidateSelf()
    }

    /** 스프링이 지금 실제로 돌고 있는가 (끊겨서 모양만 중간에 남은 경우와 구분한다) */
    private fun running(): Boolean = anim?.isRunning == true

    /**
     * 버튼이 화면에서 떼어지거나(바 버튼 재배치 · 숨김) 손가락이 사라져 끝내 못 돌아온 경우를 위해
     * 진행 중인 움직임을 멈추고 평소 모양으로 되돌린다. 상태가 모양을 정하는 종류(player · desktop)는 건드리지 않는다.
     */
    fun reset() {
        if (kind == "player" || kind == "desktop") return
        anim?.cancel()
        swapAnim?.cancel()
        swap = 0f
        set(0f)
    }

    /** 누르고 있는 동안 모양이 머무는 정도 (미리 움츠리는 동작). 이 종류가 아니면 0 */
    private fun holdLevel(): Float = when (kind) {
        "tabs" -> 0.4f
        "openplayer" -> 0.5f
        "history" -> -0.1f // 시계 바늘이 반시계 방향으로 살짝 감겨 준비 (떼면 시계 방향으로 한 바퀴 돈다)
        "downloads" -> -0.2f // 화살표가 살짝 위로 들려 준비 (떼면 받침대로 내려꽂힌다)
        "bookmarks" -> 0.22f // 리본이 살짝 좁아지며 준비 (떼면 뒤에 리본이 한 장 더 펼쳐졌다가 모인다)
        "bookmark" -> 0.15f // 현수막 아래쪽이 살짝 말리며 준비 (떼면 위로 돌돌 말려 올라갔다가 펼쳐지며 돌아온다)
        "home" -> 0.4f // 집이 바닥에 눌려 낮고 넓어지며 준비 (떼면 위로 뛰어올라 늘어났다가 통통 튀며 자리를 잡는다)
        "menu" -> 0.5f // 세 점이 살짝 커지며 준비 (누르는 동안 25% 커지고, 떼면 아래 점부터 차례로 출렁이며 원래 크기로 돌아온다)
        "extensions" -> 0.4f // 퍼즐 조각이 살짝 오므라들고 두 돌기가 움츠러들며 준비 (떼면 위쪽 → 오른쪽 돌기 순서로 튀어나왔다 자리를 잡는다)
        "find" -> -0.12f // 렌즈가 살짝 작아지고 손잡이가 길어지며 준비 (떼면 손잡이가 렌즈로 빨려 들어가 링이 되었다 돌아온다)
        "ai" -> 0.5f // 별이 12% 작아지며 둥글게 오므라들어 준비 (떼면 씨앗처럼 모였다가 피어난다)
        else -> 0f
    }

    /**
     * 손가락이 닿는 순간(down = true)에 떼기 전 자세로 미리 움츠리고, 떼면(탭이 아니거나 밖으로 나가서 뗌) 제자리로 돌아온다.
     * 탭으로 뗐을 때는 이 자세에서 [play] 가 이어받아 튀어 나간다.
     */
    fun press(down: Boolean) {
        val hold = holdLevel()
        if (hold == 0f) return
        // 방문 기록: 바늘이 도는 중에 또 눌러도 되감기지 않고 계속 돈다 (다음 탭이 이어서 한 바퀴 더 돈다)
        if (kind == "history" && progress > 0.05f && running()) return
        if (kind == "downloads" && progress > 0.3f && running()) return // 내려꽂히는 중에 또 눌러도 되감지 않는다
        if (kind == "bookmarks" && progress > 0.3f && running()) return // 펼쳐지는 중에 또 눌러도 되감지 않는다
        if (kind == "bookmark" && progress > 0.05f && running()) return // 말려 올라가는 중에 또 눌러도 되감지 않는다
        if (kind == "openplayer" && swap > 0.001f && swapAnim?.isRunning == true) return
        if (kind == "extensions" && swap > 0.001f && swapAnim?.isRunning == true) return // 돌기가 튀어나오는 중에 또 눌러도 끊지 않는다
        if (kind == "menu" && swap > 0.001f && swapAnim?.isRunning == true) return // 부푸는 중에 또 눌러도 끊지 않는다
        if (kind == "ai" && swap > 0.001f && swapAnim?.isRunning == true) return // 피어나는 중에 또 눌러도 모양을 건드리지 않는다 (떼면 처음부터 다시 피어난다)
        anim?.cancel()
        val to = if (down) hold else 0f
        anim = SmoothSpring.run(
            from = progress, to = to, stiffness = 700f, damping = 0.85f,
            onUpdate = { set(it) },
            onEnd = { set(to) }
        )
    }

    /** 눌렀을 때: 모양이 변했다가 튕기며 돌아온다 */
    fun play() {
        if (kind == "desktop") return // 데스크톱/폰은 상태가 바뀔 때(settle) 모양이 바뀐다
        when (kind) {
            "tabs" -> {
                // 누르고 있던 자세(앞 카드가 움츠림)에서 뒤 카드가 튀어 오르고, 출렁이며 제자리
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = progress, to = 0f, stiffness = 380f, damping = 0.55f, velocity = 30f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
            "home" -> {
                // 눌려 말랑하게 찌그러진 자세(p > 0)에서 위로 늘어났다가(p < 0) 젤리처럼 출렁이며 자리를 잡는다.
                // 눌림 없이 불렸을 때도 먼저 살짝 웅크렸다 뛰도록 시작 자세를 잡는다
                val from = if (progress > 0.05f) progress else 0.4f
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = from, to = 0f, stiffness = 450f, damping = 0.5f, velocity = -10f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
            "ai" -> {
                // 눌려 오므라든 별(aiFrom)이 씨앗처럼 모였다 피어나는 흐름을 swap(0 → 1, 0.9초)이 정한다. p 는 곧바로 0 으로 돌리고 모양은 swap 이 이어받는다.
                // 피어나는 중에 또 누르면 처음부터 다시 피어난다
                aiFrom = if (progress > 0.001f) (progress / 0.5f).coerceIn(0f, 1f) else 0f
                anim?.cancel()
                set(0f)
                swapAnim?.cancel()
                swap = 0.001f
                swapAnim = SmoothClock(
                    AI_MS,
                    onFrame = { swap = it.coerceAtLeast(0.001f); invalidateSelf() },
                    onEnd = { swap = 0f; invalidateSelf() }
                ).start()
            }
            "history" -> {
                // 눌러서 반시계로 살짝 감겨 있던 자세(-0.1)에서 시계 방향으로 한 바퀴 돌고 살짝 넘었다가 자리를 잡는다.
                // 예전에는 0 → 0.8 → 0 으로 갔다 와서 바늘이 한쪽으로 돌다가 도로 풀리며 반대로 돌아 보였다.
                // 0 → 1 로 한 방향으로만 가고(1 = 360° = 평소 모양), 끝나면 0 으로 되돌려도 모양이 같아 튀지 않는다.
                // 도는 중에 또 누르면 지금 각도에서 한 바퀴를 더 이어서 돈다.
                // 끊겨서 모양만 중간에 남아 있다면(돌고 있지 않다면) 그 각도에서 이어 돌지 않고 눌림 자세(음수)나 0 에서 시작한다
                val base = if (running() || progress < 0f) progress else 0f
                val to = if (base > 0.05f) kotlin.math.ceil(base.toDouble()).toFloat() + 1f else 1f
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = base, to = to, stiffness = 230f, damping = 0.74f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
            "extensions" -> {
                // 눌려 오므라든 조각(p = 0.4)의 돌기가 위쪽 → 오른쪽 순서로 튀어나왔다가 살짝 넘치며(스프링 한 번 반) 자리를 잡는다.
                // swap(0 → 1, 0.7초)이 그 흐름을 정하고 p 는 곧바로 0 으로 돌려, 모양은 swap 이 이어받는다 (깜박이지 않게 첫 프레임부터 같은 자세).
                // 눌림 없이 불렸어도 오므라든 자세에서 시작한다. 튀어나오는 중에 또 눌러도 처음부터 다시 하지 않고 그대로 끝낸다
                if (swapAnim?.isRunning == true && swap > 0.05f) return
                extFrom = if (progress > 0.05f) progress.coerceAtMost(0.4f) else 0.4f
                anim?.cancel()
                set(0f)
                swapAnim?.cancel()
                swap = 0.001f
                swapAnim = SmoothClock(
                    EXT_MS,
                    onFrame = { swap = it.coerceAtLeast(0.001f); invalidateSelf() },
                    onEnd = { swap = 0f; invalidateSelf() }
                ).start()
            }
            "find" -> {
                // 준비했던 돋보기(p = -0.12)의 손잡이가 렌즈 안으로 빨려 들어가 둥근 링(p = 1)이 되었다가, 손잡이가 길게 튀어나오며(p < 0) 돋보기로 돌아온다
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = progress, to = 0f, stiffness = 240f, damping = 0.5f, velocity = 30f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
            "downloads" -> {
                // 내려가는 중(0 < p < 1)이나 다시 내려오는 중(p > 1)에 또 눌러도 그대로 이어서 간다
                if (progress > 0.3f && running()) return
                // 들려 있던 화살표(p = -0.2)가 받침대 속으로 내려가 사라지고(0 → 1),
                // 위에서 다시 내려와(1 → 2) 살짝 눌렸다 자리를 잡는다. 2 = 평소 모양과 같아서 끝나면 0 으로 되돌려도 튀지 않는다
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = progress, to = 1f, stiffness = 360f, damping = 1f,
                    onUpdate = { set(it) },
                    onEnd = {
                        anim = SmoothSpring.run(
                            from = 1f, to = 2f, stiffness = 240f, damping = 0.7f,
                            onUpdate = { set(it) },
                            onEnd = { set(0f) }
                        )
                    }
                )
            }
            "bookmarks" -> {
                // 눌려 좁아져 있던 리본(p = 0.22)이 왼쪽 아래로 비켜서며 뒤에 리본이 한 장 더 펼쳐지고(0 → 1, 부드럽게),
                // 잠시 뒤 통통 튕기며 다시 한 장으로 모인다 (p < 0 까지 살짝 넘어 앞 리본이 길게 내려왔다 돌아온다)
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = progress, to = 1f, stiffness = 420f, damping = 0.78f,
                    onUpdate = { set(it) },
                    onEnd = {
                        anim = SmoothSpring.run(
                            from = 1f, to = 0f, stiffness = 260f, damping = 0.52f,
                            onUpdate = { set(it) },
                            onEnd = { set(0f) }
                        )
                    }
                )
            }
            "bookmark" -> {
                // 현수막이 아래에서부터 돌돌 말려 올라가고(0 → 1, 부드럽게), 다 말리면 툭 풀리며(p < 0 까지 튕기며) 제자리로 펼쳐진다
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = progress, to = 1f, stiffness = 260f, damping = 1f,
                    onUpdate = { set(it) },
                    onEnd = {
                        anim = SmoothSpring.run(
                            from = 1f, to = 0f, stiffness = 220f, damping = 0.5f,
                            onUpdate = { set(it) },
                            onEnd = { set(0f) }
                        )
                    }
                )
            }
            "menu" -> {
                // 커져 있던 점(p > 0)이 아래 점부터 차례로 살짝 오므라들었다가 원래 크기로 자리를 잡는다. 눌림 없이 불렸으면 커진 데서 시작한다.
                // 프레임이 밀려도 건너뛰지 않는 시계로 돌려서, 메뉴를 만드느라 메인 스레드가 막혀도 끊겨 튀지 않는다.
                menuFrom = if (progress > 0.05f) progress else 0.5f
                anim?.cancel()
                swapAnim?.cancel()
                set(0f)
                swap = 0.001f // 첫 프레임부터 커진 자세에서 시작 (깜박이지 않게)
                swapAnim = SmoothClock(
                    800L,
                    onFrame = { swap = it.coerceAtLeast(0.001f); invalidateSelf() },
                    onEnd = { swap = 0f; invalidateSelf() }
                ).start()
            }
            "skipback", "skipfwd" -> {
                // 화살표 방향(되감기 = 반시계, 빨리감기 = 시계)으로 한 바퀴만 돌고 제자리.
                // 예전에는 progress 가 0 → 0.7 → 0 으로 갔다 와서 한쪽으로 돌다가 도로 풀리며 반대로 돌아 보였다.
                // 0 → 1 로 한 방향으로만 가고(살짝 넘었다 돌아오는 정도), 끝나면 360° 와 같은 0 으로 되돌린다.
                // 도는 중에 또 누르면 지금 각도에서 한 바퀴를 더 이어서 돈다.
                val base = if (running()) progress else 0f
                val to = if (base > 0.02f) kotlin.math.ceil(base.toDouble()).toFloat() + 1f else 1f
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = base, to = to, stiffness = 260f, damping = 0.8f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
            "openplayer" -> {
                // 눌려 움츠려 있던 삼각형(p = 0.5)이 앞으로 튀어 오르며 살짝 커졌다가(p < 0) 자리를 잡는다.
                // 그 사이 swap(0 → 1, 1.2초)이 흐르며 삼각형이 세 조각으로 갈라져 그대로 이퀄라이저 막대가 되어 출렁이다 다시 합쳐진다.
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = progress, to = 0f, stiffness = 520f, damping = 0.45f, velocity = -6f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
                swapAnim?.cancel()
                swap = 0f
                swapAnim = SmoothClock(
                    1200L,
                    onFrame = { swap = it; invalidateSelf() },
                    onEnd = { swap = 0f; invalidateSelf() }
                ).start()
            }
            else -> {
                anim?.cancel()
                anim = SmoothSpring.run(
                    from = progress, to = 0f, stiffness = 420f, damping = 0.5f, velocity = 30f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
        }
    }

    /**
     * 탭 버튼의 숫자를 바꾼다. animate = true 면 숫자가 굴러 바뀌고 카드가 한 번 출렁인다 (모양이 눌려 있는 중이면 이어서).
     * dir: +1 = 늘어남, -1 = 줄어듦. tabs 가 아닌 종류에서는 아무 일도 하지 않는다.
     */
    fun setLabel(text: String, animate: Boolean, dir: Int = 1) {
        if (kind != "tabs" || text == label) return
        rollAnim?.cancel()
        if (!animate || label.isEmpty()) {
            label = text; prevLabel = text; roll = 1f
            invalidateSelf()
            return
        }
        prevLabel = label
        label = text
        rollDir = if (dir >= 0) 1 else -1
        roll = 0f
        rollAnim = Motion.springValue(
            from = 0f, to = 1f, stiffness = 500f, damping = 0.8f,
            onUpdate = { roll = it; invalidateSelf() },
            onEnd = { roll = 1f; invalidateSelf() }
        )
        // 카드도 한 번 출렁인다
        anim?.cancel()
        anim = SmoothSpring.run(
            from = progress, to = 0f, stiffness = 380f, damping = 0.55f, velocity = 34f,
            onUpdate = { set(it) },
            onEnd = { set(0f) }
        )
    }

    /** 숫자 한 개를 그린다 (24 격자 기준, 카드 가운데가 (12, 12)). 글자 크기 규칙은 TabCountDrawable 과 같다: 99+ → 8, 두 자리 → 10, 한 자리 → 12 */
    private fun drawLabel(canvas: Canvas, s: String, dx: Float, dy: Float, scale: Float, frac: Float, color: Int, a: Int) {
        if (s.isEmpty() || frac <= 0.01f) return
        num.color = color
        num.alpha = (a * frac.coerceIn(0f, 1f)).roundToInt()
        // 글자 크기는 고정하고, 커지고 작아지는 건 캔버스 확대·축소로 한다 (크기를 바꾸며 그리면 글자 모양과 간격이 프레임마다 어긋난다)
        num.textSize = if (s.endsWith("+")) 8f else if (s.length >= 2) 10f else 12f
        // 실제 버튼(TextView, 글꼴 여백 없음, 가운데 정렬)처럼 글줄(ascent~descent)의 가운데를 카드 가운데에 둔다
        val fm = num.fontMetrics
        canvas.save()
        canvas.scale(scale, scale, 12f + dx, 12f + dy)
        canvas.drawText(s, 12f + dx, 12f + dy - (fm.ascent + fm.descent) / 2f, num)
        canvas.restore()
    }

    /** 상태에 맞는 모양으로 자리를 잡는다 (처음에는 바로, 그 뒤로는 부드럽게 모양이 바뀐다) */
    fun settle(target: Float, animate: Boolean) {
        anim?.cancel()
        settleClock?.cancel()
        if (!animate || !settled) {
            settled = true
            set(target)
            return
        }
        if (kind == "player") {
            // 재생 ↔ 일시정지: 넘치거나 출렁이지 않고 한 번에 매끄럽게 변한다.
            // 도중에 상태가 또 바뀌면 지금 모양에서 곧바로 반대로 이어서 간다 (남은 거리만큼만 시간을 쓴다).
            val from = progress
            val dist = kotlin.math.abs(target - from)
            if (dist < 0.002f) { set(target); return }
            val ms = (PLAYER_MORPH_MS * dist.coerceIn(0.45f, 1f)).toLong()
            settleClock = SmoothClock(
                ms,
                onFrame = { t -> set(lerp(from, target, PLAYER_EASE.getInterpolation(t))) },
                onEnd = { set(target) }
            ).start()
            return
        }
        anim = SmoothSpring.run(
            from = progress, to = target, stiffness = 260f, damping = 0.62f,
            onUpdate = { set(it) },
            onEnd = { set(target) }
        )
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    /** 0 → 1 로 가며 한 번 반쯤 넘쳤다(약 20%) 자리를 잡는 스프링 곡선. 1 이상이면 1 */
    private fun springOut(x: Float): Float =
        if (x >= 1f) 1f else 1f - Math.exp(-4.5 * x).toFloat() * Math.cos(9.0 * x).toFloat()
    /** t 가 [from, to] 구간에서 0 → 1 로 가는 정도 */
    private fun seg(t: Float, from: Float, to: Float): Float = ((t - from) / (to - from)).coerceIn(0f, 1f)
    private fun ease(x: Float): Float = x * x * (3f - 2f * x)
    /** 끝에서 살짝 넘었다 돌아오는 ease (0 → 1, 넘침 약 10%) */
    private fun easeOutBack(x: Float): Float {
        val c1 = 1.2f
        val c3 = c1 + 1f
        val u = x - 1f
        return 1f + c3 * u * u * u + c1 * u * u
    }

    private fun curColor(): Int {
        val t = tint
        return if (t != null) t.getColorForState(state, t.defaultColor) else baseColor
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val side = minOf(b.width(), b.height()).toFloat()
        val u = side / 24f
        val c = curColor()
        val a = (Color.alpha(c) * alphaValue / 255)
        stroke.color = c; stroke.alpha = a
        fill.color = c; fill.alpha = a
        canvas.save()
        canvas.translate(b.exactCenterX() - side / 2f, b.exactCenterY() - side / 2f)
        canvas.scale(u, u)
        val p = progress
        val q = p.coerceIn(0f, 1f)
        path.reset()
        when (kind) {
            "back", "forward" -> {
                // 몸통이 짧아지며 화살촉이 앞으로 쏜다
                val d = if (kind == "back") 1f else -1f
                fun x(v: Float) = if (d > 0f) v else 24f - v
                if (!chevron) { path.moveTo(x(19f - 6f * p), 12f); path.lineTo(x(5f - 2.5f * p), 12f) }
                path.moveTo(x(11f - 2.5f * p), 6f); path.lineTo(x(5f - 2.5f * p), 12f); path.lineTo(x(11f - 2.5f * p), 18f)
                canvas.drawPath(path, stroke)
            }
            "home" -> {
                // 모양은 그대로 두고 '스쿼시 & 스트레치'만 한다 (바닥을 딛고 눌렸다가 뛰어오르며 늘어났다가 통통 튀며 자리를 잡음).
                // p > 0: 바닥(y = 20.2)에 눌려 낮고 넓어짐 / p < 0: 위로 떠서 좁고 길어짐
                val up = (-p).coerceIn(0f, 0.5f)
                val dn = p.coerceIn(0f, 0.5f)
                val n = canvas.save()
                canvas.translate(0f, -3.5f * up)
                canvas.scale(1f + 0.12f * dn - 0.13f * up, 1f - 0.25f * dn + 0.30f * up, 12f, 20.2f)
                path.moveTo(4f, 11.2f); path.lineTo(12f, 4.2f); path.lineTo(20f, 11.2f)
                path.moveTo(6f, 9.6f); path.lineTo(6f, 19.2f); path.quadTo(6f, 20.2f, 7f, 20.2f)
                path.lineTo(10f, 20.2f); path.lineTo(10f, 15f); path.lineTo(14f, 15f); path.lineTo(14f, 20.2f)
                path.lineTo(17f, 20.2f); path.quadTo(18f, 20.2f, 18f, 19.2f); path.lineTo(18f, 9.6f)
                canvas.drawPath(path, stroke)
                canvas.restoreToCount(n)
            }
            "menu" -> {
                // 눌리면(p > 0) 점이 살짝 커지고(최대 25%), 떼면 아래 점부터 차례로 원래 크기보다 조금 더 오므라들었다가(약 7%) 자리를 잡는다
                val big = 1f + 0.5f * (if (swap > 0f) menuFrom else p).coerceIn(0f, 1f)
                for (i in 0..2) {
                    val scale = if (swap > 0f) {
                        val t = (swap * 1.9f - (2 - i) * 0.3f).coerceIn(0f, 1f) // 아래 점부터, 간격을 넓게
                        val u = t - 1f
                        val e = 1f + 4.4f * u * u * u + 3.4f * u * u   // 0 → 약 1.3 까지 갔다가 1 로 돌아와 멈춤
                        big + (1f - big) * e
                    } else big
                    canvas.drawCircle(12f, 5f + 7f * i, 1.7f * scale, fill)
                }
            }
            "desktop" -> {
                // 0 = 모니터, 1 = 폰
                rect.set(lerp(3f, 7f, p), lerp(4f, 3f, p), lerp(21f, 17f, p), lerp(16f, 21f, p))
                val r = lerp(2f, 2.5f, q)
                canvas.drawRoundRect(rect, r, r, stroke)
                val ly = lerp(20f, 18f, p)
                path.moveTo(lerp(9f, 11f, p), ly); path.lineTo(lerp(15f, 13f, p), ly)
                path.moveTo(12f, lerp(16f, 18f, p)); path.lineTo(12f, ly)
                canvas.drawPath(path, stroke)
            }
            "ai" -> {
                // 피어남. 누르는 동안(swap = 0)에는 별이 p 만큼 작아지며 둥글게 오므라든다.
                // 떼면 swap(0 → 1, 0.9초)이 한 번 지나간다: 씨앗(작은 동그라미)으로 모였다가(0.16초) 감쇠 진동으로 피어난다(살짝 넘침). 돌지도 기울지도 않는다
                val playing = swap > 0.001f
                val tt = swap.coerceIn(0f, 1f) * (AI_MS / 1000f) // 초
                var sc: Float
                var mm: Float
                if (!playing) {
                    val h = (p / 0.5f).coerceIn(0f, 1f)
                    sc = 1f - 0.12f * h
                    mm = 1f - 0.45f * h
                } else {
                    val s0 = 1f - 0.12f * aiFrom
                    val m0 = 1f - 0.45f * aiFrom
                    if (tt < AI_COLLAPSE) {
                        val w = tt / AI_COLLAPSE
                        val e = w * w * w
                        sc = s0 + (0.3f - s0) * e
                        mm = m0 * (1f - e)
                    } else {
                        val tau = tt - AI_COLLAPSE
                        val x = 1f - Math.exp((-6.5f * tau).toDouble()).toFloat() * Math.cos((10f * tau).toDouble()).toFloat()
                        sc = 0.3f + 0.7f * x
                        mm = x.coerceIn(0f, 1.15f)
                    }
                }
                buildBigStar(mm, starPath)
                canvas.save()
                canvas.scale(sc, sc, 12f, 12f)
                // 속을 채운 별 (ic_ai.xml 과 같다)
                canvas.drawPath(starPath, fill)
                stroke.strokeWidth = 1.8f / sc
                canvas.drawPath(starPath, stroke)
                stroke.strokeWidth = 1.8f
                canvas.restore()
            }
            "newtab" -> {
                // + 의 두 선이 가운데로 줄어들었다가 다시 늘어난다
                val l = (7f * (1f - p)).coerceAtLeast(0.2f)
                canvas.drawLine(12f, 12f - l, 12f, 12f + l, stroke)
                canvas.drawLine(12f - l, 12f, 12f + l, 12f, stroke)
            }
            "bookmark" -> {
                // 현수막(리본)이 아래에서부터 돌돌 말려 올라간다 (p = 0 → 1): 아래 끝이 올라오고, 갈라진 꼬리는 펴지며, 아래에 입체적인 말림(원통)이 생긴다.
                // 원통은 몸통보다 넓고, 속을 살짝 채우고, 한쪽 끝에 말린 단면(동그라미)과 윤이 나는 줄이 보이며, 몸통에는 말려 들어가는 주름선이 생긴다.
                // p < 0 이면 말린 것이 툭 풀려 꼬리가 아래로 더 늘어난다 (펼쳐지며 튕기는 반동).
                val q = p.coerceIn(0f, 1f)
                val yb = if (p >= 0f) 20.2f - 9.5f * p else 20.2f - 6f * p
                val depth = if (p >= 0f) 3.6f * (1f - (p / 0.45f).coerceIn(0f, 1f)) else 3.6f - 4f * p
                val notchY = yb - depth
                path.moveTo(7f, 4f); path.lineTo(17f, 4f); path.quadTo(18f, 4f, 18f, 5f); path.lineTo(18f, yb)
                path.lineTo(12f, notchY); path.lineTo(6f, yb); path.lineTo(6f, 5f); path.quadTo(6f, 4f, 7f, 4f); path.close()
                if (q > 0.02f) {
                    fill.alpha = (a * 0.14f * q).roundToInt()
                    canvas.drawPath(path, fill)
                }
                canvas.drawPath(path, stroke)
                val rd = 4.4f * minOf(p / 0.6f, 1.12f)
                if (rd > 0.7f) {
                    val top = yb - rd * 0.3f
                    val keep = stroke.alpha
                    rect.set(4.4f, top, 19.6f, top + rd)
                    fill.alpha = (a * 0.28f).roundToInt()
                    canvas.drawRoundRect(rect, rd / 2f, rd / 2f, fill)
                    canvas.drawRoundRect(rect, rd / 2f, rd / 2f, stroke)
                    if (rd > 1.8f) {
                        stroke.strokeWidth = 1.2f
                        // 몸통이 말려 들어가는 주름선
                        stroke.alpha = (keep * 0.5f).roundToInt()
                        canvas.drawLine(7.6f, top - 1.3f, 16.4f, top - 1.3f, stroke)
                        // 윤이 나는 줄
                        canvas.drawLine(9.2f, top + rd * 0.3f, 15.4f, top + rd * 0.3f, stroke)
                        // 말린 단면
                        stroke.alpha = (keep * 0.9f).roundToInt()
                        canvas.drawCircle(4.4f + rd / 2f, top + rd / 2f, rd * 0.26f, stroke)
                        stroke.strokeWidth = 1.8f
                        stroke.alpha = keep
                    }
                }
            }
            "bookmarks" -> {
                // 앞 리본은 왼쪽 아래로 비켜서고(q), 그 뒤로 테두리만 있는 리본이 오른쪽 위에서 펼쳐진다.
                // 누르는 동안(0 < p < 1)은 앞 리본이 좁아지며 홈이 깊어지고, p < 0 이면 앞 리본이 아래로 길게 늘어났다 돌아온다.
                val fan = 2.6f * q
                val sx = 0.7f * p.coerceIn(0f, 0.4f)
                val notch = 16.6f - 2.6f * p.coerceIn(0f, 0.4f) + (if (p < 0f) 4f * p else 0f)
                val tip = 20.2f + 1.2f * p.coerceIn(0f, 0.4f) - (if (p < 0f) 6f * p else 0f)
                val fx = -fan * 0.8f
                val fy = 0.8f * q
                // 앞 리본 모양
                path.moveTo(7f + sx + fx, 4f + fy); path.lineTo(17f - sx + fx, 4f + fy)
                path.quadTo(18f - sx + fx, 4f + fy, 18f - sx + fx, 5f + fy); path.lineTo(18f - sx + fx, tip + fy)
                path.lineTo(12f + fx, notch + fy); path.lineTo(6f + sx + fx, tip + fy)
                path.lineTo(6f + sx + fx, 5f + fy); path.quadTo(6f + sx + fx, 4f + fy, 7f + sx + fx, 4f + fy); path.close()
                if (q > 0.02f) {
                    // 뒤 리본: 앞 리본이 가리는 부분은 비우고 테두리만 그린다
                    canvas.save()
                    if (Build.VERSION.SDK_INT >= 26) {
                        canvas.clipOutPath(path)
                    } else {
                        @Suppress("DEPRECATION")
                        canvas.clipPath(path, Region.Op.DIFFERENCE)
                    }
                    val bx = fan * 0.9f
                    val by = -1.6f * q
                    val bt = 20.2f - 0.6f * q
                    val back = backPath
                    back.reset()
                    back.moveTo(7f + bx, 4f + by); back.lineTo(17f + bx, 4f + by)
                    back.quadTo(18f + bx, 4f + by, 18f + bx, 5f + by); back.lineTo(18f + bx, bt + by)
                    back.lineTo(12f + bx, 16.6f + by); back.lineTo(6f + bx, bt + by)
                    back.lineTo(6f + bx, 5f + by); back.quadTo(6f + bx, 4f + by, 7f + bx, 4f + by); back.close()
                    stroke.alpha = (a * ease(q)).roundToInt()
                    canvas.drawPath(back, stroke)
                    stroke.alpha = a
                    canvas.restore()
                }
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
            }
            "history" -> {
                // 눌리는 동안(p < 0)은 두 바늘이 반시계 방향으로 살짝 감기고, 떼면 분침이 시계 방향으로 한 바퀴 돈다 (p = 1 → 360°).
                // 분침 뒤에 흐릿한 꼬리가 따라 돌고, 시침은 분침의 1/12 만큼 갔다가 제자리로 돌아온다 (한 바퀴가 끝나면 평소 모양과 같다).
                canvas.drawCircle(12f, 12f, 8.5f, stroke)
                val lap = if (p > 0f) kotlin.math.floor(p.toDouble()).toFloat() else 0f
                val fr = if (p > 0f) p - lap else 0f
                val trail = kotlin.math.sin(Math.PI * fr).toFloat().coerceIn(0f, 1f)
                if (trail > 0.02f) {
                    // 분침 끝(반지름 4.5)을 따라 지나온 자리를 그린다. 시계 방향으로 도니 꼬리는 반시계 쪽(음수 sweep)에 남는다
                    rect.set(12f - 4.5f, 12f - 4.5f, 12f + 4.5f, 12f + 4.5f)
                    stroke.alpha = (a * 0.4f * trail).roundToInt()
                    canvas.drawArc(rect, -90f + 360f * p, -120f * trail, false, stroke)
                    stroke.alpha = a
                }
                canvas.save()
                canvas.rotate(360f * p, 12f, 12f)
                canvas.drawLine(12f, 12f, 12f, 7.5f, stroke)
                canvas.restore()
                val hourDeg = if (p < 0f) 30f * p else 30f * kotlin.math.sin(Math.PI * fr).toFloat()
                canvas.save()
                canvas.rotate(hourDeg, 12f, 12f)
                canvas.drawLine(12f, 12f, 15f, 14f, stroke)
                canvas.restore()
            }
            "downloads" -> {
                // p < 0: 화살표가 위로 살짝 들린다 (준비 자세)
                // 0 → 1: 화살표가 받침대 선 쪽으로 내려가, 선에 닿은 부분부터 가려지며 끝까지 들어가 사라진다 (투명해지지 않는다)
                // 1 → 2: 사라진 화살표가 위쪽 가장자리에서 내려와 자리를 잡는다 (2 를 넘으면 살짝 더 내려갔다 돌아온다. 2 = 평소 모양)
                val dy = when {
                    p < 0f -> 6f * p
                    p <= 1f -> 18f * p // 꼬리(몸통 윗끝)까지 선 아래로 다 들어가야 해서 화살표 길이보다 더 내려간다
                    else -> -14f * (2f - p)
                }
                // 받침대: 화살표가 닿기 시작할 때부터 살짝 눌리고, 다시 내려올 때 가라앉는다
                val hit = if (p <= 1f) ease(seg(p, 0.25f, 0.8f)) else 1f - ease(seg(p, 1f, 1.35f))
                canvas.save()
                // 아래는 받침대 선 윗면(20 - 선 굵기 절반)에서 자르고, 위는 아이콘 위쪽 가장자리에서 자른다.
                // 받침대가 눌려 내려가면 자르는 선도 같이 내려가야 화살표와 받침대 사이가 벌어져 중간에 끊기지 않는다
                canvas.clipRect(0f, 2.2f, 24f, 19.1f + 0.9f * hit)
                path.moveTo(12f, 4f + dy); path.lineTo(12f, 15f + dy)
                path.moveTo(7.5f, 10.5f + dy); path.lineTo(12f, 15f + dy); path.lineTo(16.5f, 10.5f + dy)
                canvas.drawPath(path, stroke)
                canvas.restore()
                path.reset()
                path.moveTo(5f - 1.6f * hit, 20f + 0.9f * hit); path.lineTo(19f + 1.6f * hit, 20f + 0.9f * hit)
                canvas.drawPath(path, stroke)
            }
            "find" -> {
                // 렌즈가 커지며 손잡이를 빨아들여 둥근 링이 된다 (p = 0 → 1). 손잡이는 렌즈 가장자리에서 사라진다.
                // p < 0 이면 렌즈가 작아지고 손잡이가 길어진다 (준비 자세 / 튕겨 돌아올 때의 반동).
                val r = 6.5f + 2.5f * p
                val c = 11f + p
                val s0 = c + (r + 0.57f) * 0.7071f
                val e0 = 20f - (20f - s0) * p.coerceIn(0f, 1f)
                canvas.drawCircle(c, c, r, stroke)
                if (kotlin.math.abs(e0 - s0) > 0.4f) canvas.drawLine(s0, s0, e0, e0, stroke)
            }
            "player" -> {
                // 재생 삼각형이 둘로 갈라져 일시정지 막대 두 개가 된다.
                // 바뀌는 중간에는 살짝 작아졌다 돌아와서(최대 6%) 모양이 늘어나는 느낌 없이 숨 쉬듯 이어진다.
                val pp = q
                val breathe = 1f - 0.06f * kotlin.math.sin(Math.PI * pp).toFloat()
                canvas.scale(breathe, breathe, 12f, 12f)
                path.moveTo(lerp(8f, 7.5f, pp), lerp(5.5f, 5f, pp))
                path.lineTo(lerp(13f, 10.5f, pp), lerp(8.6f, 5f, pp))
                path.lineTo(lerp(13f, 10.5f, pp), lerp(15.4f, 19f, pp))
                path.lineTo(lerp(8f, 7.5f, pp), lerp(18.5f, 19f, pp))
                path.close()
                path.moveTo(lerp(13f, 13.5f, pp), lerp(8.6f, 5f, pp))
                path.lineTo(lerp(18.5f, 16.5f, pp), lerp(12f, 5f, pp))
                path.lineTo(lerp(18.5f, 16.5f, pp), lerp(12f, 19f, pp))
                path.lineTo(lerp(13f, 13.5f, pp), lerp(15.4f, 19f, pp))
                path.close()
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
            }
            "hidebars" -> {
                // 네 모서리 괄호가 가운데로 모인다
                val m = 2.6f * p
                canvas.save(); canvas.translate(m, m)
                path.moveTo(4f, 9f); path.lineTo(4f, 5.5f); path.quadTo(4f, 4f, 5.5f, 4f); path.lineTo(9f, 4f)
                canvas.drawPath(path, stroke); canvas.restore(); path.reset()
                canvas.save(); canvas.translate(-m, m)
                path.moveTo(15f, 4f); path.lineTo(18.5f, 4f); path.quadTo(20f, 4f, 20f, 5.5f); path.lineTo(20f, 9f)
                canvas.drawPath(path, stroke); canvas.restore(); path.reset()
                canvas.save(); canvas.translate(-m, -m)
                path.moveTo(20f, 15f); path.lineTo(20f, 18.5f); path.quadTo(20f, 20f, 18.5f, 20f); path.lineTo(15f, 20f)
                canvas.drawPath(path, stroke); canvas.restore(); path.reset()
                canvas.save(); canvas.translate(m, -m)
                path.moveTo(9f, 20f); path.lineTo(5.5f, 20f); path.quadTo(4f, 20f, 4f, 18.5f); path.lineTo(4f, 15f)
                canvas.drawPath(path, stroke); canvas.restore()
            }
            "settings" -> {
                val g = gearOuter
                if (g != null) {
                    canvas.save()
                    canvas.rotate(60f * p, 12f, 12f)
                    canvas.drawPath(g, stroke)
                    canvas.restore()
                }
                canvas.drawCircle(12f, 12f, 2.8f + 1.6f * p, stroke)
            }
            "tabs" -> {
                // 앞 카드(숫자 포함)는 왼쪽 아래로 움츠리고, 뒤 카드는 오른쪽 위로 튀어 오른다.
                // 뒤 카드는 앞 카드에 가려지는 부분(+ 얇은 틈)을 잘라 내고 그려서 겹쳐 보이지 않는다.
                val sh = 2f * p
                val r = 3.5f
                val k = 1f - 0.12f * q
                canvas.save()
                canvas.scale(k, k, 12f, 12f)
                if (q > 0.01f) {
                    val gap = 1.5f
                    path.reset()
                    rect.set(3f - sh - gap, 3f + sh - gap, 21f - sh + gap, 21f + sh + gap)
                    path.addRoundRect(rect, r + gap, r + gap, Path.Direction.CW)
                    canvas.save()
                    if (Build.VERSION.SDK_INT >= 26) {
                        canvas.clipOutPath(path)
                    } else {
                        @Suppress("DEPRECATION")
                        canvas.clipPath(path, Region.Op.DIFFERENCE)
                    }
                    rect.set(3f + sh, 3f - sh, 21f + sh, 21f - sh)
                    stroke.alpha = (a * q).roundToInt()
                    canvas.drawRoundRect(rect, r, r, stroke)
                    stroke.alpha = a
                    canvas.restore()
                }
                rect.set(3f - sh, 3f + sh, 21f - sh, 21f + sh)
                canvas.drawRoundRect(rect, r, r, stroke)
                // 숫자: 카드 안쪽에서만 굴러 바뀐다
                val rolling = roll < 0.999f
                canvas.save()
                if (rolling) canvas.clipRect(4.4f - sh, 4.4f + sh, 19.6f - sh, 19.6f + sh)
                if (rolling) {
                    val t = roll
                    val travel = 6f * rollDir
                    // 옛 숫자: 가는 쪽으로 밀려 나가며 사라짐 / 새 숫자: 반대쪽에서 들어오며 커짐
                    // 두 숫자가 동시에 보이지 않게 투명도 구간을 나눈다: 옛 숫자는 0~0.4 에서 사라지고, 새 숫자는 0.5~1 에서 나타난다
                    drawLabel(canvas, prevLabel, -sh, sh - travel * t, 1f - 0.2f * t, 1f - t / 0.4f, c, a)
                    drawLabel(canvas, label, -sh, sh + travel * (1f - t), 0.75f + 0.25f * t.coerceAtMost(1f), (t - 0.5f) / 0.45f, c, a)
                } else {
                    drawLabel(canvas, label, -sh, sh, 1f, 1f, c, a)
                }
                canvas.restore()
                canvas.restore()
            }
            "openplayer" -> {
                // 누르면 삼각형이 작아지고(p > 0), 떼면 튀어 오르며 커졌다가(p < 0) 자리를 잡는다.
                // swap(0 → 1): 삼각형을 세로 조각 세 개로 나눠, 조각이 왼쪽부터 차례로 벌어지며 그대로 막대(이퀄라이저)가 되고,
                // 막대가 출렁이다 오른쪽부터 차례로 다시 합쳐져 삼각형이 된다. 조각 하나하나가 이어서 변하니 사라지고 나타나는 것이 없다.
                val k = if (p >= 0f) 1f - 0.3f * p else 1f - 0.55f * p
                val t = swap
                canvas.save()
                canvas.scale(k, k, 11.5f, 12f)
                if (t <= 0.001f) {
                    drawPlayTriangle(canvas, a, 1f)
                } else {
                    for (i in 0..2) {
                        // 삼각형 상태: 가로 3.5 폭의 조각, 왼쪽·오른쪽 끝의 세로 반높이가 삼각형 윤곽을 따른다
                        val xl = 8f + 3.5f * i
                        val xr = xl + 3.5f
                        val hl = 6.5f * (18.5f - xl) / 10.5f
                        val hr = 6.5f * (18.5f - xr) / 10.5f
                        // 막대 상태: 아래가 18.2 에 맞춰진 막대 (선 두께 1.8 을 빼고 그린다), 높이는 막대마다 출렁인다
                        val form = easeOutBack(seg(t, 0.03f + 0.045f * i, 0.33f + 0.045f * i))
                        val back = ease(seg(t, 0.72f + 0.045f * (2 - i), 0.97f - 0.045f * i))
                        val m = form * (1f - back)
                        val bounce = 0.5f + 0.5f * kotlin.math.sin(EQ_PHASE[i] + t * EQ_SPEED)
                        val ho = 4f + 9.5f * bounce
                        val hb = (ho - 1.8f) / 2f
                        val yb = 18.2f - ho / 2f
                        val xc = 7.3f + 4.7f * i
                        val xL = lerp(xl, xc - 0.6f, m)
                        val xR = lerp(xr, xc + 0.6f, m)
                        val hL = lerp(hl, hb, m)
                        val hR = lerp(hr, hb, m)
                        val cy = lerp(12f, yb, m)
                        path.reset()
                        path.moveTo(xL, cy - hL); path.lineTo(xR, cy - hR); path.lineTo(xR, cy + hR); path.lineTo(xL, cy + hL); path.close()
                        canvas.drawPath(path, fill)
                        canvas.drawPath(path, stroke)
                    }
                }
                canvas.restore()
            }
            "extensions" -> {
                // p(0 ~ 0.4): 누르는 동안 조각이 작아지고 왼쪽으로 기울며 돌기가 몸통 속으로 납작하게 들어간 정도 (f = p / 0.4).
                // swap(0 → 1): 뗀 뒤. 조각이 폴짝 뛰어올랐다 내려앉고, 위쪽 돌기(0.14 ~ 0.66) → 오른쪽 돌기(0.28 ~ 0.82)가 차례로 튀어나온다.
                // 돌기가 다 나온 순간마다 조각이 반대 방향으로 한 번씩 흔들려 '딸깍' 맞물리는 느낌을 준다.
                // swap = 0 이고 p = 0 인 모양은 ic_extension 과 같다.
                if (swap <= 0f) {
                    val f = (p / 0.4f).coerceIn(0f, 1f)
                    drawPuzzle(canvas, 1f - EXT_KNOB_IN * f, 1f - EXT_KNOB_IN * f, 1f - EXT_SQUASH * f, -EXT_TILT * f, 0f, 0f)
                } else {
                    val f0 = (extFrom / 0.4f).coerceIn(0f, 1f)
                    val k0 = 1f - EXT_KNOB_IN * f0
                    val s0 = 1f - EXT_SQUASH * f0
                    val xt = springOut(seg(swap, 0.14f, 0.66f))
                    val xr = springOut(seg(swap, 0.28f, 0.82f))
                    val xs = springOut(seg(swap, 0f, 0.55f))
                    // 폴짝: 올라갔다 내려앉는다 (내려앉은 뒤에 돌기가 맞물린다)
                    val hop = -EXT_HOP * kotlin.math.sin(Math.PI * seg(swap, 0f, 0.32f)).toFloat() * f0
                    // 기울기: 왼쪽으로 기운 데서 반대편으로 살짝 넘었다가 돌아온다
                    val tilt = -EXT_TILT * f0 * (1f - xs)
                    // 딸깍 흔들림: 위쪽 돌기는 조각을 아래로, 오른쪽 돌기는 조각을 왼쪽으로 한 번 튕긴다
                    val dy = hop + clickKick(swap - 0.23f, EXT_KICK)
                    val dx = -clickKick(swap - 0.374f, EXT_KICK)
                    drawPuzzle(
                        canvas,
                        k0 + (1f - k0) * xt, k0 + (1f - k0) * xr,
                        s0 + (1f - s0) * xs, tilt, dx, dy
                    )
                }
            }
            "pip" -> {
                // 바깥 화면은 그대로, 안쪽 작은 창이 왼쪽 위로 커지며 튀어나온다
                rect.set(3f, 5f, 21f, 19f)
                canvas.drawRoundRect(rect, 2f, 2f, stroke)
                rect.set(lerp(11.5f, 8.8f, p), lerp(12f, 9.6f, p), 18f, lerp(16f, 16.4f, p))
                canvas.drawRoundRect(rect, 1f, 1f, fill)
                canvas.drawRoundRect(rect, 1f, 1f, stroke)
            }
            "rotate" -> {
                // 폰 모양이 시계 방향으로 기울어졌다가 돌아온다
                val arrow = rotateArrow
                canvas.save()
                canvas.rotate(90f * p, 12f, 12f)
                rect.set(8f, 9f, 20f, 20f)
                canvas.drawRoundRect(rect, 1.5f, 1.5f, stroke)
                if (arrow != null) canvas.drawPath(arrow, stroke)
                canvas.restore()
            }
            "skipback", "skipfwd" -> {
                // 숫자 10 은 가만히 있고, 화살표만 가는 방향(되감기 = 왼쪽, 빨리감기 = 오른쪽)으로 쏘았다가 제자리로 돌아온다.
                // p 가 한 칸(0 → 1) 갈 때마다 한 번 쏜다. 끝(정수)에서는 늘 제자리라서 끝나고 0 으로 되돌려도 튀지 않는다.
                val dir = if (kind == "skipback") -1f else 1f
                stroke.strokeWidth = 2f
                skipDigits?.let { canvas.drawPath(it, stroke) }
                canvas.save()
                canvas.translate(dir * 2.4f * kotlin.math.sin(Math.PI * p).toFloat(), 0f)
                skipArrow?.let { canvas.drawPath(it, stroke) }
                canvas.restore()
                stroke.strokeWidth = 1.8f
            }
            else -> {
                canvas.drawCircle(12f, 12f, 8f, stroke)
            }
        }
        canvas.restore()
    }

    /**
     * 돌기가 맞물릴 때 조각이 한 번 튕기는 정도. t = 맞물린 뒤 흐른 시간(swap 단위, 음수면 아직 안 맞물림).
     * 처음에 힘껏 튕기고 점점 잦아드는 흔들림 (몇 번 왕복하고 멈춘다).
     */
    private fun clickKick(t: Float, amp: Float): Float =
        if (t <= 0f) 0f else amp * Math.exp(-9.0 * t).toFloat() * kotlin.math.sin(2.0 * Math.PI * 3.2 * t).toFloat()

    /**
     * 퍼즐 조각을 그린다 (ic_extension 과 같은 모양).
     * kt = 위쪽 돌기, kr = 오른쪽 돌기가 튀어나온 정도 (1 = 평소, 1 보다 크면 더 튀어나옴, 0 에 가까우면 몸통 속으로 납작하게 들어감).
     * 돌기는 줄어들 때 작은 공이 되지 않고 폭은 거의 그대로, 높이만 낮아진다 (몸통 속으로 밀려 들어가는 모양).
     * scale: 조각 가운데 기준 크기, rot: 가운데 기준 기울기(도), dx · dy: 조각 전체의 이동(격자 단위).
     */
    private fun drawPuzzle(canvas: Canvas, kt: Float, kr: Float, scale: Float, rot: Float, dx: Float, dy: Float) {
        canvas.save()
        canvas.translate(-0.75f + dx, 1.25f + dy) // 그림의 실제 가운데(12.75, 10.75)를 격자 가운데(12, 12)로 옮긴다
        canvas.scale(scale, scale, 12.75f, 10.75f)
        if (rot != 0f) canvas.rotate(rot, 12.75f, 10.75f)
        // 돌기 높이 비율(h) 과 가로 반지름 비율(w): 납작해져도 폭은 72% 까지만 좁아진다
        val ht = kt.coerceAtLeast(0.02f)
        val hr = kr.coerceAtLeast(0.02f)
        val wt = (0.72f + 0.28f * ht).coerceAtMost(1.06f)
        val wr = (0.72f + 0.28f * hr).coerceAtMost(1.06f)
        val rxT = 2f * wt;  val ryT = 2f * ht;  val stT = 0.5f * ht
        val rxR = 2f * wr;  val ryR = 2f * hr;  val stR = 0.5f * hr
        path.reset()
        path.moveTo(5f, 7f)
        rect.set(5f, 6f, 7f, 8f); path.arcTo(rect, 180f, 90f)
        path.lineTo(11f - rxT, 6f)
        path.lineTo(11f - rxT, 6f - stT)
        rect.set(11f - rxT, 6f - stT - ryT, 11f + rxT, 6f - stT + ryT); path.arcTo(rect, 180f, 180f)
        path.lineTo(11f + rxT, 6f)
        path.lineTo(17f, 6f)
        rect.set(16f, 6f, 18f, 8f); path.arcTo(rect, 270f, 90f)
        path.lineTo(18f, 12f - rxR)
        path.lineTo(18f + stR, 12f - rxR)
        rect.set(18f + stR - ryR, 12f - rxR, 18f + stR + ryR, 12f + rxR); path.arcTo(rect, 270f, 180f)
        path.lineTo(18f, 12f + rxR)
        path.lineTo(18f, 17f)
        rect.set(16f, 16f, 18f, 18f); path.arcTo(rect, 0f, 90f)
        path.lineTo(13.5f, 18f)
        path.lineTo(13.5f, 17.5f)
        rect.set(9.5f, 15.5f, 13.5f, 19.5f); path.arcTo(rect, 0f, -180f)
        path.lineTo(9.5f, 18f)
        path.lineTo(6f, 18f)
        rect.set(5f, 16f, 7f, 18f); path.arcTo(rect, 90f, 90f)
        path.lineTo(5f, 14f)
        path.lineTo(5.5f, 14f)
        rect.set(3.5f, 10f, 7.5f, 14f); path.arcTo(rect, 90f, -180f)
        path.lineTo(5f, 10f)
        path.close()
        canvas.drawPath(path, stroke)
        canvas.restore()
    }

    /** 재생 삼각형 (ic_play 와 같은 모양) */
    private fun drawPlayTriangle(canvas: Canvas, a: Int, frac: Float) {
        path.reset()
        path.moveTo(8f, 5.5f); path.lineTo(18.5f, 12f); path.lineTo(8f, 18.5f); path.close()
        val al = (a * frac.coerceIn(0f, 1f)).roundToInt()
        fill.alpha = al
        stroke.alpha = al
        canvas.drawPath(path, fill)
        canvas.drawPath(path, stroke)
        fill.alpha = a
        stroke.alpha = a
    }

    override fun getIntrinsicWidth(): Int = (24f * density).roundToInt()
    override fun getIntrinsicHeight(): Int = (24f * density).roundToInt()

    override fun isStateful(): Boolean = true
    override fun onStateChange(stateSet: IntArray): Boolean {
        val t = tint ?: return false
        t.getColorForState(stateSet, t.defaultColor)
        invalidateSelf()
        return true
    }

    override fun setTintList(tint: ColorStateList?) {
        this.tint = tint
        invalidateSelf()
    }

    override fun setAlpha(alpha: Int) { alphaValue = alpha; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) { stroke.colorFilter = cf; fill.colorFilter = cf; invalidateSelf() }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        // 확장 프로그램(퍼즐 조각) 버튼 애니메이션 수치
        /** 뗀 뒤 전체 흐름 길이(ms) */
        private const val EXT_MS = 800L
        /** AI 버튼 피어남 전체 시간(ms) */
        private const val AI_MS = 900L
        /** AI 버튼: 씨앗으로 모이는 구간(초). 이 뒤로 피어난다 */
        private const val AI_COLLAPSE = 0.16f
        /** 누르면 돌기가 들어가는 정도 (0.8 = 높이가 20% 로 납작해짐) */
        private const val EXT_KNOB_IN = 0.8f
        /** 누르면 조각이 작아지는 정도 (0.1 = 90%) */
        private const val EXT_SQUASH = 0.1f
        /** 누르면 왼쪽으로 기우는 각도(도) */
        private const val EXT_TILT = 6f
        /** 뗐을 때 폴짝 뛰는 높이 (24 격자 단위) */
        private const val EXT_HOP = 1.5f
        /** 돌기가 맞물릴 때 조각이 튕기는 세기 (24 격자 단위) */
        private const val EXT_KICK = 1.1f

        /** 이퀄라이저 막대 세 개가 출렁이는 시작 위상과 속도 (swap 1.0 당 라디안) */
        private val EQ_PHASE = floatArrayOf(0f, 2.1f, 4.2f)
        private const val EQ_SPEED = 22f

        private const val GEAR =
            "M10.23,4.92 L10.66,2.49 L13.34,2.49 L13.77,4.92 A7.3,7.3 0 0 1 15.76,5.74 L17.78,4.33 L19.67,6.22 " +
            "L18.26,8.24 A7.3,7.3 0 0 1 19.08,10.23 L21.51,10.66 L21.51,13.34 L19.08,13.77 A7.3,7.3 0 0 1 18.26,15.76 " +
            "L19.67,17.78 L17.78,19.67 L15.76,18.26 A7.3,7.3 0 0 1 13.77,19.08 L13.34,21.51 L10.66,21.51 L10.23,19.08 " +
            "A7.3,7.3 0 0 1 8.24,18.26 L6.22,19.67 L4.33,17.78 L5.74,15.76 A7.3,7.3 0 0 1 4.92,13.77 L2.49,13.34 " +
            "L2.49,10.66 L4.92,10.23 A7.3,7.3 0 0 1 5.74,8.24 L4.33,6.22 L6.22,4.33 L8.24,5.74 A7.3,7.3 0 0 1 10.23,4.92 Z"
        /** 재생 ↔ 일시정지 모양 변환 시간(ms)과 곡선 */
        private const val PLAYER_MORPH_MS = 300L
        private val PLAYER_EASE = android.view.animation.PathInterpolator(0.4f, 0f, 0.2f, 1f)

        private const val ROTATE_ARROW = "M4,12 V9.5 A4.5,4.5 0 0 1 8.5,5 H12 M10,2.8 L12.2,5 L10,7.2"
        // Tabler rewind-backward-10 / rewind-forward-10 (24 격자 · 선 2). 화살표와 숫자를 따로 그려서 화살표만 움직인다
        private const val SKIP_BACK_ARROW = "M7,9 L4,6 L7,3 M15.997,17.918 A6.002,6.002 0 0 0 15,6 H4"
        private const val SKIP_BACK_DIGITS = "M6,14 V20 M9,15.5 V18.5 A1.5,1.5 0 0 0 12,18.5 V15.5 A1.5,1.5 0 0 0 9,15.5"
        private const val SKIP_FWD_ARROW = "M17,9 L20,6 L17,3 M8,17.918 A5.997,5.997 0 0 1 3,12 A6,6 0 0 1 9,6 H20"
        private const val SKIP_FWD_DIGITS = "M12,14 V20 M15,15.5 V18.5 A1.5,1.5 0 0 0 18,18.5 V15.5 A1.5,1.5 0 0 0 15,15.5"

        /** 모양이 그려져 있는 버튼 종류. 이 밖의 종류는 아이콘을 바꾸지 않고 눌림 효과만 준다. */
        private val KINDS = setOf(
            "back", "forward", "home", "menu", "desktop", "ai", "newtab", "bookmark", "bookmarks", "history",
            "downloads", "find", "player", "openplayer", "hidebars", "settings", "tabs", "tablist", "pip", "rotate",
            "skipback", "skipfwd", "extensions"
        )

        /** 버튼 종류에 맞는 모양 변하는 아이콘을 버튼에 끼운다. 못 끼우는 버튼이면 null. */
        fun install(v: View, kind: String): MorphIconDrawable? {
            if (kind == "refresh" || kind !in KINDS) return null
            val density = v.resources.displayMetrics.density
            return when {
                v is ImageView -> {
                    val d = MorphIconDrawable(kind, density)
                    v.setImageDrawable(d)
                    d
                }
                v is ViewGroup && (kind == "tabs" || kind == "tablist") -> {
                    val tv = (0 until v.childCount).map { v.getChildAt(it) }.filterIsInstance<TextView>().firstOrNull() ?: return null
                    val color = ThemeColors.get(
                        tv, com.google.android.material.R.attr.colorOnSurface
                    )
                    val d = MorphIconDrawable("tabs", density, color)
                    tv.background = d
                    // 숫자는 그림이 직접 그린다 (카드와 같이 움직이고 굴러 바뀌어야 해서). 글자는 자리만 잡고 보이지 않게 한다
                    d.setLabel(tv.text.toString(), animate = false)
                    tv.setTextColor(Color.TRANSPARENT)
                    d
                }
                else -> null
            }
        }
    }
}
