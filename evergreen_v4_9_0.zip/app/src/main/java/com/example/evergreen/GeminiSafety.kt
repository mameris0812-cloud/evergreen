package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject

/**
 * Gemini 요청에 붙이는 안전 필터 설정.
 * 기본값은 멀쩡한 질문까지 막는 경우가 있어서, 조절할 수 있는 네 분류를 "막지 않음"으로 낮춘다.
 * (구글이 항상 막는 심각한 분류는 이 설정과 상관없이 그대로 막힌다)
 */
object GeminiSafety {
    private val CATEGORIES = listOf(
        "HARM_CATEGORY_HARASSMENT",
        "HARM_CATEGORY_HATE_SPEECH",
        "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "HARM_CATEGORY_DANGEROUS_CONTENT",
        "HARM_CATEGORY_CIVIC_INTEGRITY"
    )

    const val THRESHOLD = "BLOCK_NONE"

    fun settings(): JSONArray {
        val a = JSONArray()
        for (c in CATEGORIES) a.put(JSONObject().put("category", c).put("threshold", THRESHOLD))
        return a
    }

    /** 요청 본문에 안전 설정을 넣는다 */
    fun apply(body: JSONObject) {
        body.put("safetySettings", settings())
    }
}
