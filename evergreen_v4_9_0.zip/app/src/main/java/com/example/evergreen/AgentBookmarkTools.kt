package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject

/**
 * 에이전트: 북마크 정리 도구.
 * - 읽기(자동): list_bookmark_folders
 * - 변경(요청당 한 번 확인): rename_bookmark · move_bookmarks · rename_bookmark_folder · delete_bookmark_folder(폴더만 지우고 북마크는 남김, 되돌리기 가능) · export_bookmarks(북마크 HTML 파일로 내보내기) · import_bookmarks(받은 북마크 HTML 파일에서 가져오기)
 *
 * 폴더를 정해서 담는 건 add_bookmark 의 folder 인자(AgentAppTools). 대상 북마크는 search_bookmarks 가 돌려준 주소(url)로만 고른다.
 * 바꾸기 직전 북마크 상태를 붙들어 둬서 「되돌리기」로 제목 · 폴더를 원래대로 돌릴 수 있다.
 */
object AgentBookmarkTools {
    const val MAX_MOVE = 30

    fun build(): List<AgentTool> = listOf(listFolders(), renameBookmark(), moveBookmarks(), renameFolder(), deleteFolder(), exportBookmarks(), importBookmarks())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    private fun outcome(o: AgentOutcome): AgentResult =
        if (!o.ok) AgentResult.fail(o.message)
        else AgentResult.ok(JSONObject().put("message", o.message).put("changed", o.number), o.message)

    private fun strsOf(a: JSONObject, key: String): List<String> {
        val arr = a.optJSONArray(key) ?: return emptyList()
        val out = LinkedHashSet<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty()) out.add(s)
        }
        return out.toList()
    }

    private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

    private fun titleOf(ctx: AgentContext, url: String): String =
        ctx.host.bookmarks("", Int.MAX_VALUE).firstOrNull { sameUrl(it.url, url) }?.title?.ifBlank { null } ?: url

    // ───────────────────────── 읽기 ─────────────────────────

    private fun listFolders() = AgentTool(
        name = "list_bookmark_folders",
        description = "북마크 폴더 목록과 폴더마다 든 북마크 수를 돌려줍니다. 북마크를 폴더에 담거나 옮기기 전에 어떤 폴더가 있는지 볼 때 쓰세요. " +
            "폴더에 들어 있지 않은 북마크(맨 위)의 수는 top_level_count 로 나옵니다.",
        risk = AgentRisk.READ,
        doing = { "북마크 폴더 확인하는 중…" },
        run = { _, ctx ->
            val fs = ctx.host.bookmarkFolders()
            val top = ctx.host.bookmarks("", Int.MAX_VALUE).count { it.folder.isEmpty() }
            val arr = JSONArray()
            for (f in fs) arr.put(JSONObject().put("name", f.name.take(60)).put("count", f.count))
            AgentResult.ok(
                JSONObject().put("count", fs.size).put("folders", arr).put("top_level_count", top),
                "북마크 폴더 ${fs.size}개를 확인했어요",
                untrusted = true
            )
        }
    )

    // ───────────────────────── 변경 ─────────────────────────

    private fun renameBookmark() = AgentTool(
        name = "rename_bookmark",
        description = "북마크의 이름(제목)을 바꿉니다. url 에 search_bookmarks 가 돌려준 북마크 주소를 그대로 주고, new_title 에 새 이름을 줍니다. " +
            "사용자가 이름을 바꾸라고 했을 때만 쓰고, 먼저 search_bookmarks 로 대상을 정확히 확인하세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "url" to AgentSchema.str("이름을 바꿀 북마크의 주소 (search_bookmarks 의 url)"),
                "new_title" to AgentSchema.str("새 이름 (200자 이내)")
            ),
            listOf("url", "new_title")
        ),
        doing = { a -> "북마크 이름 바꾸는 중: ${short(a.optString("new_title").trim(), 20)}…" },
        run = { a, ctx ->
            val url = a.optString("url").trim()
            val title = a.optString("new_title").trim()
            when {
                url.isEmpty() -> AgentResult.fail("url 이 비어 있어요 (search_bookmarks 의 url 을 주세요)")
                title.isEmpty() -> AgentResult.fail("new_title 이 비어 있어요")
                else -> outcome(ctx.host.renameBookmark(url, title))
            }
        },
        undoPlan = { a, ctx ->
            val snap = ctx.host.bookmarkSnapshot()
            val url = a.optString("url").trim()
            if (snap == null || url.isEmpty()) null else {
                { r ->
                    if (r.data.optInt("changed", 0) <= 0) null
                    else AgentUndo("북마크 이름 되돌리기") { h -> h.restoreBookmarkEdits(snap, listOf(url)) }
                }
            }
        },
        ask = { a, ctx ->
            "북마크 이름 바꾸기: 「${short(titleOf(ctx, a.optString("url").trim()), 22)}」 → 「${short(a.optString("new_title").trim(), 22)}」"
        }
    )

    private fun moveBookmarks() = AgentTool(
        name = "move_bookmarks",
        description = "북마크들을 폴더로 옮깁니다 (한 번에 최대 ${MAX_MOVE}개). urls 에 search_bookmarks 가 돌려준 주소를 그대로 주고, folder 에 옮길 폴더 이름을 줍니다. " +
            "그 이름의 폴더가 없으면 새로 만들어 넣습니다. 폴더에서 빼서 맨 위로 되돌리려면 folder 에 \"없음\" 을 주세요. " +
            "사용자가 북마크를 옮기거나 폴더로 정리해 달라고 했을 때만 쓰고, 먼저 list_bookmark_folders 로 있는 폴더를 보고 알맞은 폴더가 있으면 그 이름을 그대로 쓰세요. " +
            "주제별로 정리할 때는 주제마다 한 번씩 부르세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "urls" to AgentSchema.strList("옮길 북마크 주소들 (search_bookmarks 의 url)"),
                "folder" to AgentSchema.str("옮길 폴더 이름 (없으면 새로 만듦, 폴더에서 빼려면 \"없음\")")
            ),
            listOf("urls", "folder")
        ),
        doing = { a -> "북마크 옮기는 중: ${short(a.optString("folder").trim(), 20)}…" },
        run = { a, ctx ->
            val urls = strsOf(a, "urls")
            when {
                urls.isEmpty() -> AgentResult.fail("urls 가 비어 있어요 (search_bookmarks 의 url 을 주세요)")
                urls.size > MAX_MOVE -> AgentResult.fail("한 번에 ${MAX_MOVE}개까지만 옮길 수 있어요. 나눠서 다시 불러 주세요")
                a.optString("folder").isBlank() -> AgentResult.fail("folder 가 비어 있어요 (폴더에서 빼려면 \"없음\")")
                else -> outcome(ctx.host.moveBookmarks(urls, a.optString("folder")))
            }
        },
        undoPlan = { a, ctx ->
            val snap = ctx.host.bookmarkSnapshot()
            val urls = strsOf(a, "urls")
            if (snap == null || urls.isEmpty()) null else {
                { r ->
                    if (r.data.optInt("changed", 0) <= 0) null
                    else AgentUndo("북마크 ${r.data.optInt("changed")}개 폴더 되돌리기") { h -> h.restoreBookmarkEdits(snap, urls) }
                }
            }
        },
        ask = { a, ctx ->
            val urls = strsOf(a, "urls")
            val names = urls.take(3).joinToString(", ") { "「${short(titleOf(ctx, it), 22)}」" } +
                if (urls.size > 3) " 외 ${urls.size - 3}개" else ""
            val f = a.optString("folder").trim()
            val to = if (f.isEmpty() || f == "없음") "폴더에서 빼기" else "'${short(f, 20)}' 폴더로"
            "북마크 ${urls.size}개 $to: $names"
        }
    )

    // ───────────────────────── 폴더 이름 바꾸기 · 지우기 ─────────────────────────

    private fun renameFolder() = AgentTool(
        name = "rename_bookmark_folder",
        description = "북마크 폴더의 이름을 바꿉니다. folder 에 list_bookmark_folders 가 돌려준 폴더 이름을, new_name 에 새 이름(30자 이내)을 줍니다. " +
            "같은 이름의 폴더가 이미 있으면 실패합니다. 사용자가 폴더 이름을 바꾸라고 했을 때만 쓰세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "folder" to AgentSchema.str("지금 폴더 이름 (list_bookmark_folders 의 name)"),
                "new_name" to AgentSchema.str("새 폴더 이름")
            ),
            listOf("folder", "new_name")
        ),
        doing = { a -> "폴더 이름 바꾸는 중: ${short(a.optString("new_name").trim(), 20)}…" },
        run = { a, ctx ->
            val f = a.optString("folder").trim()
            val n = a.optString("new_name").trim()
            when {
                f.isEmpty() -> AgentResult.fail("folder 가 비어 있어요 (list_bookmark_folders 의 name 을 주세요)")
                n.isEmpty() -> AgentResult.fail("new_name 이 비어 있어요")
                else -> outcome(ctx.host.renameBookmarkFolder(f, n))
            }
        },
        undoPlan = { a, _ ->
            val f = a.optString("folder").trim()
            val n = a.optString("new_name").trim().replace(Regex("\\s+"), " ").take(30)
            val plan: (AgentResult) -> AgentUndo? = { r ->
                if (r.data.optInt("changed", 0) <= 0) null
                else AgentUndo("폴더 이름 되돌리기 (${short(f, 16)})") { h -> h.renameBookmarkFolder(n, f) }
            }
            plan
        },
        ask = { a, _ -> "북마크 폴더 이름 바꾸기: 「${short(a.optString("folder").trim(), 22)}」 → 「${short(a.optString("new_name").trim(), 22)}」" }
    )

    private fun deleteFolder() = AgentTool(
        name = "delete_bookmark_folder",
        description = "북마크 폴더를 지웁니다. 폴더만 지워지고 안에 있던 북마크는 지워지지 않고 폴더 없이 맨 위로 나옵니다 (북마크까지 지우려면 delete_bookmarks). " +
            "folder 에 list_bookmark_folders 가 돌려준 폴더 이름을 줍니다. 사용자가 폴더를 지우라고 분명히 했을 때만 쓰고, 「되돌리기」로 폴더와 안의 북마크를 되살릴 수 있습니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf("folder" to AgentSchema.str("지울 폴더 이름 (list_bookmark_folders 의 name)")),
            listOf("folder")
        ),
        doing = { a -> "폴더 지우는 중: ${short(a.optString("folder").trim(), 20)}…" },
        run = { a, ctx ->
            val f = a.optString("folder").trim()
            if (f.isEmpty()) AgentResult.fail("folder 가 비어 있어요 (list_bookmark_folders 의 name 을 주세요)")
            else {
                val o = ctx.host.deleteBookmarkFolder(f)
                if (!o.ok) AgentResult.fail(o.message)
                else AgentResult.ok(JSONObject().put("message", o.message).put("bookmarks_moved_to_top", o.number).put("deleted", 1), o.message)
            }
        },
        undoPlan = { a, ctx ->
            val snap = ctx.host.bookmarkFolderSnapshot(a.optString("folder").trim())
            if (snap == null) null else {
                val plan: (AgentResult) -> AgentUndo? = { r ->
                    if (r.data.optInt("deleted", 0) <= 0) null
                    else AgentUndo("지운 폴더 되살리기") { h -> h.restoreBookmarkFolder(snap) }
                }
                plan
            }
        },
        ask = { a, ctx ->
            val f = a.optString("folder").trim()
            val n = ctx.host.bookmarkFolders().firstOrNull { it.name.equals(f, ignoreCase = true) }?.count ?: 0
            "북마크 폴더 삭제: 「${short(f, 22)}」" + if (n > 0) " (안의 북마크 ${n}개는 남아요)" else ""
        }
    )

    // ───────────────────────── 내보내기 · 가져오기 ─────────────────────────

    private fun exportBookmarks() = AgentTool(
        name = "export_bookmarks",
        description = "북마크 전체(폴더 포함)를 북마크 HTML 파일로 내보내 기기의 다운로드 폴더에 저장합니다. 크롬 · 엣지 · 파이어폭스 같은 다른 브라우저에서 그대로 가져올 수 있는 형식입니다. " +
            "사용자가 북마크를 내보내거나 백업해 달라고 했을 때만 쓰세요. 저장된 파일은 다운로드 화면이나 list_downloads 에서 볼 수 있습니다.",
        risk = AgentRisk.CHANGE,
        doing = { "북마크 내보내는 중…" },
        run = { _, ctx ->
            val o = ctx.host.exportBookmarks()
            if (!o.ok) AgentResult.fail(o.message)
            else AgentResult.ok(JSONObject().put("message", o.message).put("exported", o.number), o.message)
        },
        ask = { _, ctx ->
            val n = ctx.host.bookmarks("", Int.MAX_VALUE).size
            "북마크 ${n}개를 파일로 내보내기 (다운로드 폴더에 저장)"
        }
    )

    private fun importBookmarks() = AgentTool(
        name = "import_bookmarks",
        description = "기기에 받아 둔 북마크 HTML 파일(크롬 · 엣지 · 파이어폭스 등에서 내보낸 파일)을 읽어 북마크에 더합니다. " +
            "file_id 에 list_downloads 가 돌려준 파일의 id 를 그대로 줍니다. 이미 있는 주소는 건너뛰고, 파일 속 폴더는 같은 이름의 폴더에 넣거나 새로 만듭니다. " +
            "한 번에 최대 ${BookmarkPorter.MAX_IMPORT}개까지 읽습니다. 사용자가 북마크를 가져오라고 했을 때만 쓰고, 어느 파일인지 모호하면 list_downloads 로 확인해 사용자에게 물어보세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf("file_id" to AgentSchema.str("가져올 북마크 파일의 id (list_downloads 의 id, 예: m:123)")),
            listOf("file_id")
        ),
        doing = { "북마크 가져오는 중…" },
        run = { a, ctx ->
            val id = a.optString("file_id").trim()
            if (id.isEmpty()) AgentResult.fail("file_id 가 비어 있어요 (list_downloads 의 id 를 주세요)")
            else {
                val o = ctx.host.importBookmarks(id)
                if (!o.ok) AgentResult.fail(o.message)
                else AgentResult.ok(JSONObject().put("message", o.message).put("imported", o.number), o.message)
            }
        },
        undoPlan = { _, ctx ->
            val before = ctx.host.bookmarks("", Int.MAX_VALUE).map { it.url.trimEnd('/') }.toHashSet()
            val plan: (AgentResult) -> AgentUndo? = { r ->
                if (r.data.optInt("imported", 0) <= 0) null else {
                    val added = ctx.host.bookmarks("", Int.MAX_VALUE).map { it.url }.filter { it.trimEnd('/') !in before }
                    if (added.isEmpty()) null
                    else AgentUndo("가져온 북마크 ${added.size}개 지우기") { h -> h.deleteBookmarks(added) }
                }
            }
            plan
        },
        ask = { a, ctx ->
            val id = a.optString("file_id").trim()
            val name = ctx.host.downloads("", Int.MAX_VALUE).firstOrNull { it.key == id }?.name
            "북마크 가져오기: " + if (name != null) "「${short(name, 30)}」" else id
        }
    )
}
