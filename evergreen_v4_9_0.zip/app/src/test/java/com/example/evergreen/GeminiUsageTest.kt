package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * AI 사용량 기록(GeminiUsage) 중 화면 · 네트워크를 안 쓰는 부분:
 * 세기(호출 · 한도 · 실패 · 토큰) · 키별/모델별/날짜별 합계 · 태평양 하루 기준 · 14일 보관 · 저장 글 · 숫자 글.
 * 응답 JSON 읽기(tokensOf)는 단위 테스트에서 org.json 을 못 써서 시험하지 않는다.
 */
class GeminiUsageTest {
    private val pt = ZoneId.of("America/Los_Angeles")
    private fun pt(y: Int, mo: Int, d: Int, h: Int = 0, mi: Int = 0): Long =
        ZonedDateTime.of(y, mo, d, h, mi, 0, 0, pt).toInstant().toEpochMilli()

    @Before
    fun reset() = GeminiUsage.clear()

    // ───────── 세기 ─────────

    @Test
    fun record_countsEachKindSeparately() {
        val t = pt(2026, 11, 21, 12)
        GeminiUsage.record("keyA", "m1", 200, false, 100, 50, t)
        GeminiUsage.record("keyA", "m1", 200, false, 300, 70, t)
        GeminiUsage.record("keyA", "m1", 429, true, 0, 0, t)    // 사용량 한도
        GeminiUsage.record("keyA", "m1", 429, false, 0, 0, t)   // 서버 붐빔: 한도가 아니라 실패
        GeminiUsage.record("keyA", "m1", 500, false, 0, 0, t)
        GeminiUsage.record("keyA", "m1", 0, false, 0, 0, t)     // 네트워크 오류
        val s = GeminiUsage.today(t)
        assertEquals(2, s.calls)
        assertEquals(1, s.limit)
        assertEquals(3, s.errors)
        assertEquals(400L, s.tokIn)
        assertEquals(120L, s.tokOut)
        assertEquals(520L, s.tokens)
    }

    @Test
    fun record_failureDoesNotAddTokensAndNegativeIsIgnored() {
        val t = pt(2026, 11, 21, 12)
        GeminiUsage.record("keyA", "m1", 500, false, 999, 999, t)
        GeminiUsage.record("keyA", "m1", 200, false, -5, -7, t)
        val s = GeminiUsage.today(t)
        assertEquals(0L, s.tokIn)
        assertEquals(0L, s.tokens)
        assertEquals(1, s.calls)
    }

    @Test
    fun record_emptyKeyIsIgnored() {
        GeminiUsage.record("", "m1", 200, false, 1, 1, pt(2026, 11, 21, 12))
        assertFalse(GeminiUsage.hasAnyRecord())
    }

    // ───────── 합계 ─────────

    @Test
    fun totals_byKeyAndByModel() {
        val t = pt(2026, 11, 21, 12)
        GeminiUsage.record("keyA", "lite", 200, false, 10, 5, t)
        GeminiUsage.record("keyA", "lite", 200, false, 10, 5, t)
        GeminiUsage.record("keyA", "pro", 200, false, 100, 50, t)
        GeminiUsage.record("keyB", "lite", 200, false, 1, 1, t)
        assertEquals(3, GeminiUsage.todayForKey("keyA", t).calls)   // lite 2 + pro 1
        assertEquals(1, GeminiUsage.todayForKey("keyB", t).calls)
        assertTrue(GeminiUsage.todayForKey("keyC", t).isEmpty())
        val by = GeminiUsage.todayByModel(t)
        assertEquals(listOf("lite", "pro"), by.map { it.first })      // 호출이 많은 순
        assertEquals(3, by[0].second.calls)
        assertEquals(1, by[1].second.calls)
    }

    @Test
    fun keyId_isStableShortAndHidesTheKey() {
        val id = GeminiUsage.keyId("AIzaSyExampleExampleExample1234")
        assertEquals(id, GeminiUsage.keyId("AIzaSyExampleExampleExample1234"))
        assertEquals(8, id.length)
        assertTrue(id.all { it in "0123456789abcdef" })
        assertNotEquals(id, GeminiUsage.keyId("AIzaSyExampleExampleExample1235"))
        assertFalse(id.contains("Example"))
    }

    // ───────── 하루 기준 (태평양 자정) ─────────

    @Test
    fun dayKey_changesAtPacificMidnight() {
        val start = pt(2026, 11, 21, 0, 0)
        assertEquals("20261121", GeminiUsage.dayKey(start))
        assertEquals("20261120", GeminiUsage.dayKey(start - 1))
        assertEquals("20261121", GeminiUsage.dayKey(start + 23 * 3_600_000L))
    }

    @Test
    fun resetTime_isNextPacificMidnight() {
        val start = pt(2026, 11, 21, 0, 0)
        assertEquals(24 * 3_600_000L, GeminiUsage.msUntilReset(start))
        assertEquals(23 * 3_600_000L, GeminiUsage.msUntilReset(start + 3_600_000L))
        assertEquals(1L, GeminiUsage.msUntilReset(start + 24 * 3_600_000L - 1))
        assertEquals(pt(2026, 11, 22, 0, 0), GeminiUsage.resetAt(start + 5 * 3_600_000L))
    }

    @Test
    fun resetTime_handlesDaylightSavingEnd() {
        // 2026-11-01 은 서머타임이 끝나는 날이라 하루가 25시간이다
        val start = pt(2026, 11, 1, 0, 0)
        assertEquals(25 * 3_600_000L, GeminiUsage.msUntilReset(start))
        assertEquals("20261101", GeminiUsage.dayKey(start + 24 * 3_600_000L))
    }

    @Test
    fun weekdayOf_sundayIsZero() {
        assertEquals(6, GeminiUsage.weekdayOf("20261121"))   // 토요일
        assertEquals(0, GeminiUsage.weekdayOf("20261122"))   // 일요일
        assertEquals(1, GeminiUsage.weekdayOf("20261123"))   // 월요일
    }

    @Test
    fun record_goesToTheDayItHappenedOn() {
        val d1 = pt(2026, 11, 21, 23, 59)
        val d2 = pt(2026, 11, 22, 0, 1)
        GeminiUsage.record("keyA", "m1", 200, false, 1, 1, d1)
        GeminiUsage.record("keyA", "m1", 200, false, 1, 1, d2)
        GeminiUsage.record("keyA", "m1", 200, false, 1, 1, d2)
        assertEquals(1, GeminiUsage.today(d1).calls)
        assertEquals(2, GeminiUsage.today(d2).calls)
        assertEquals(1, GeminiUsage.todayForKey("keyA", d1).calls)
    }

    // ───────── 최근 며칠 · 보관 ─────────

    @Test
    fun recentDays_oldestFirstEndsToday_andFillsEmptyDays() {
        val now = pt(2026, 11, 21, 12)
        GeminiUsage.record("keyA", "m1", 200, false, 1, 1, now)
        GeminiUsage.record("keyA", "m1", 200, false, 1, 1, now - 2 * 24 * 3_600_000L)
        val days = GeminiUsage.recentDays(7, now)
        assertEquals(7, days.size)
        assertEquals("20261121", days.last().first)
        assertEquals("20261115", days.first().first)
        assertEquals(listOf(0, 0, 0, 0, 1, 0, 1), days.map { it.second.calls })
    }

    @Test
    fun oldRecordsAreDroppedAfterKeepDays() {
        val now = pt(2026, 11, 21, 12)
        val old = now - (GeminiUsage.KEEP_DAYS + 6) * 24L * 3_600_000L
        GeminiUsage.record("keyA", "m1", 200, false, 1, 1, old)
        assertEquals(1, GeminiUsage.day(GeminiUsage.dayKey(old)).calls)
        GeminiUsage.record("keyA", "m1", 200, false, 1, 1, now)        // 새 날의 첫 기록이 오래된 날을 치운다
        assertTrue(GeminiUsage.day(GeminiUsage.dayKey(old)).isEmpty())
        assertEquals(1, GeminiUsage.today(now).calls)
    }

    // ───────── 저장 글 ─────────

    @Test
    fun dumpAndLoad_roundTrip() {
        val t = pt(2026, 11, 21, 12)
        GeminiUsage.record("keyA", "m1", 200, false, 10, 5, t)
        GeminiUsage.record("keyA", "m1", 429, true, 0, 0, t)
        GeminiUsage.record("keyB", "m2", 500, false, 0, 0, t)
        val text = GeminiUsage.dump()
        GeminiUsage.clear()
        assertFalse(GeminiUsage.hasAnyRecord())
        GeminiUsage.load(text)
        val s = GeminiUsage.today(t)
        assertEquals(1, s.calls)
        assertEquals(1, s.limit)
        assertEquals(1, s.errors)
        assertEquals(15L, s.tokens)
        assertEquals(1, GeminiUsage.todayForKey("keyA", t).limit)
        assertEquals(text, GeminiUsage.dump())
    }

    @Test
    fun load_skipsBrokenLines() {
        val id = GeminiUsage.keyId("keyA")
        val good = "20261121|$id|m1|3|1|0|100|50"
        GeminiUsage.load(listOf("", "깨진 줄", "20261121|$id|m1|x|1|0|100|50", "20261121|$id|m1|3|1|0|100", "20261121|$id|m1|-1|0|0|0|0", good).joinToString("\n"))
        val s = GeminiUsage.today(pt(2026, 11, 21, 12))
        assertEquals(3, s.calls)
        assertEquals(1, s.limit)
        assertEquals(150L, s.tokens)
    }

    // ───────── 글 ─────────

    @Test
    fun formatTokens_koreanUnits() {
        assertEquals("0", GeminiUsage.formatTokens(0))
        assertEquals("9,999", GeminiUsage.formatTokens(9_999))
        assertEquals("1만", GeminiUsage.formatTokens(10_000))
        assertEquals("1.2만", GeminiUsage.formatTokens(12_345))
        assertEquals("12.3만", GeminiUsage.formatTokens(123_456))
        assertEquals("100만", GeminiUsage.formatTokens(999_999))
        assertEquals("123만", GeminiUsage.formatTokens(1_234_567))
        assertEquals("1.2억", GeminiUsage.formatTokens(123_456_789))
    }

    @Test
    fun formatDuration_hoursAndMinutes() {
        assertEquals("1분 미만", GeminiUsage.formatDuration(0))
        assertEquals("1분 미만", GeminiUsage.formatDuration(59_999))
        assertEquals("1분", GeminiUsage.formatDuration(60_000))
        assertEquals("12분", GeminiUsage.formatDuration(12 * 60_000L))
        assertEquals("1시간", GeminiUsage.formatDuration(60 * 60_000L))
        assertEquals("5시간 12분", GeminiUsage.formatDuration((5 * 60 + 12) * 60_000L))
    }

    @Test
    fun summaryLine_showsOnlyWhatHappened() {
        assertNull(GeminiUsage.summaryLine(GeminiUsage.Tally()))
        assertEquals("오늘 8회 · 4.1만 토큰 · 한도 1회", GeminiUsage.summaryLine(GeminiUsage.Tally(8, 1, 0, 30_000L, 11_000L)))
        assertEquals("오늘 3회", GeminiUsage.summaryLine(GeminiUsage.Tally(3, 0, 0, 0, 0)))
        assertEquals("오늘 0회 · 한도 2회 · 실패 1회", GeminiUsage.summaryLine(GeminiUsage.Tally(0, 2, 1, 0, 0)))
    }
}
