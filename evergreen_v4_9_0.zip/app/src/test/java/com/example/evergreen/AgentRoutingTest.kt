package com.example.evergreen

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 어떤 질문을 에이전트(도구를 쓰는 쪽)로 보낼지 가르는 [AgentRouting] 테스트.
 * 도구가 있는 앱 조작이 일반 채팅으로 새서 「지원하지 않는다」 는 답이 나오지 않아야 한다.
 * 실행: ./gradlew :app:testDebugUnitTest
 */
class AgentRoutingTest {
    @Test
    fun 앱_조작_말은_에이전트로_간다() {
        val asks = listOf(
            "탭 다 닫아 줘", "구글 열어봐", "새 창으로 옮겨 줘", "시크릿 탭 열어 줘", "다크 모드 켜줘",
            "데스크톱 사이트로 바꿔 줘", "글자 크기 키워 줘", "광고 차단 꺼 줘", "북마크 폴더 정리해 줘",
            "닫힌 창에 넣어 줘", "창 2로 옮겨 줘", "2번 창에 보내 줘", "열린 창으로 옮겨줘",
            "웹스토어에서 확장 설치해 줘", "페이지 확대해 줘", "맨 아래로 스크롤해 줘", "항상 번역 켜 줘", "시작 페이지 바꿔 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 사진_낱말이_있어도_앱_조작이_분명하면_에이전트로_간다() {
        assertTrue(AgentRouting.useAgent("이 이미지 다운로드해 줘"))
        assertTrue(AgentRouting.useAgent("사진 있는 탭 닫아 줘"))
        assertTrue(AgentRouting.useAgent("이 그림 북마크해 줘"))
    }

    @Test
    fun 사진을_읽어야_하는_말과_잡담은_일반_채팅으로_간다() {
        assertFalse(AgentRouting.useAgent("이 사진 뭐야?"))
        assertFalse(AgentRouting.useAgent("이 그래프 설명해 줘"))
        assertFalse(AgentRouting.useAgent("안녕"))
        assertFalse(AgentRouting.useAgent("고마워"))
    }

    @Test
    fun 웹_페이지_조작_말은_에이전트로_간다() {
        val asks = listOf(
            "로그인 버튼 눌러 줘", "장바구니에 담아 줘", "좋아요 눌러줘", "구독해 줘", "검색창에 날씨 입력해 줘",
            "더보기 펼쳐 줘", "팝업 닫아 줘", "웹 조작 해 봐", "이거 대신 해 줘", "영상 재생해 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 에이전트가_하던_일의_짧은_이어_말하기는_에이전트로_간다() {
        assertTrue(AgentRouting.isFollowUp("응 그걸로 해", true))
        assertTrue(AgentRouting.isFollowUp("두 번째 걸로", true))
        assertFalse(AgentRouting.isFollowUp("응 그걸로 해", false))
        assertFalse(AgentRouting.isFollowUp("고마워", true))
        assertFalse(AgentRouting.isFollowUp("이 사진 뭐야?", true))
        assertFalse(AgentRouting.isFollowUp("a".repeat(41), true))
    }

    @Test
    fun 미디어_조작_말은_에이전트로_간다() {
        val asks = listOf(
            "일시정지해 줘", "음악 멈춰 줘", "노래 꺼 줘", "다음 곡으로 넘겨 줘", "이전 곡으로 돌아가 줘",
            "10초 뒤로 감아 줘", "30초 앞으로 가 줘", "되감아 줘", "이전 영상으로 돌아가 줘", "재생 중인 거 멈춰 줘", "이 영상 처음부터 재생해 줘", "1.5배속으로 틀어 줘", "볼륨 줄여 줘", "소리 키워 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 창_열기_닫기_이름_말은_에이전트로_간다() {
        val asks = listOf(
            "분할 화면으로 열어 줘", "구글을 팝업 창으로 띄워 줘", "창 2 닫아 줘", "2번 창 닫아 줘",
            "이 창 이름을 업무로 바꿔 줘", "창 이름 변경해 줘", "닫은 창 다시 열어 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 영상_보기_말은_에이전트로_간다() {
        val asks = listOf(
            "이 영상 PiP로 해 줘", "작은 창으로 띄워 줘", "미러링 켜 줘", "미러링 꺼 줘",
            "화면 그대로 보여 줘", "내장 플레이어로 열어 줘", "플레이어로 재생해 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 확장_프로그램_팝업_옵션_말은_에이전트로_간다() {
        val asks = listOf(
            "광고 차단 확장 팝업 열어 줘", "확장 프로그램 옵션 열어 줘", "다크 리더 옵션 화면 보여 줘", "비밀번호 확장 팝업 띄워 줘", "옵션 페이지 열어 줘"
        )
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 테마_꾸미기_말은_에이전트로_간다() {
        val asks = listOf("파란 테마로 꾸며 줘", "툴바 색을 연보라로 바꿔 줘 테마", "테마를 내 맘대로 꾸며 줘", "어두운 초록 테마 만들어 줘")
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 받은_사진_보기_말은_에이전트로_간다() {
        val asks = listOf("다운로드한 사진 뭐야?", "방금 받은 이미지 설명해 줘", "내려받은 사진 읽어 줘", "이 이미지 주소 좀 봐 줘")
        for (q in asks) assertTrue(q, AgentRouting.useAgent(q))
    }

    @Test
    fun 흔한_낱말만_든_일반_질문은_도구_없이_답한다() {
        assertFalse(AgentRouting.useAgent("오늘 뭐 먹을까"))
        assertFalse(AgentRouting.useAgent("이 글 정리해 줘"))
        assertFalse(AgentRouting.useAgent("목표를 세우는 법 알려 줘"))
    }

    @Test
    fun 노래_추천_같은_일반_질문은_도구_없이_답한다() {
        assertFalse(AgentRouting.useAgent("노래 가사 뜻이 뭐야?"))
        assertFalse(AgentRouting.useAgent("음악 추천해 주세요"))
    }
}
