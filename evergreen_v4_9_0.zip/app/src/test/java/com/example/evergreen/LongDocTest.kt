package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** 긴 글 파일 나눠 읽기(LongDoc) 중 네트워크를 안 쓰는 부분: 나누기 · 요점 잇기 */
class LongDocTest {
    @Test
    fun split_shortTextStaysWhole() {
        assertEquals(listOf("짧은 글"), LongDoc.split("짧은 글", 100))
        assertFalse(LongDoc.needsCondense("a".repeat(LongDoc.THRESHOLD_CHARS)))
        assertTrue(LongDoc.needsCondense("a".repeat(LongDoc.THRESHOLD_CHARS + 1)))
    }

    @Test
    fun split_joinsBackToOriginalAndPrefersParagraphBreaks() {
        val para = "가나다라마바사 ".repeat(20).trim()   // 139자 안팎의 문단
        val text = (1..30).joinToString("\n\n") { "$it $para" }
        val parts = LongDoc.split(text, 1000)
        assertEquals(text, parts.joinToString(""))
        assertTrue(parts.size > 1)
        // 끝이 아닌 조각은 문단 경계(빈 줄)에서 끊긴다
        parts.dropLast(1).forEach { assertTrue(it.endsWith("\n\n")) }
        assertTrue(parts.all { it.length <= 1000 })
    }

    @Test
    fun split_noBreakAtAll_stillMakesProgress() {
        val text = "x".repeat(2500)
        val parts = LongDoc.split(text, 1000)
        assertEquals(listOf(1000, 1000, 500), parts.map { it.length })
        assertEquals(text, parts.joinToString(""))
    }

    @Test
    fun assemble_marksFailedPartsWithHead() {
        val chunks = listOf("첫째 부분 본문", "둘째 부분 본문")
        val r = LongDoc.assemble("보고서.txt", listOf("요점 1", null), chunks)
        assertTrue(r.contains("2개 부분으로 나눠"))
        assertTrue(r.contains("## 1/2 부분\n요점 1"))
        assertTrue(r.contains("실패해 앞머리만"))
        assertTrue(r.contains("둘째 부분 본문"))
    }
}
