package com.example.evergreen

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * AI 에게 주는 앱 기능 설명서 [AppGuide] 의 본문 확인. 설정의 큰 묶음 이름이 빠지거나 바뀌지 않았는지 본다.
 * (BuildConfig 를 쓰는 [AppGuide.text] 대신 본문 [AppGuide] 의 글을 리플렉션으로 읽는다)
 * 실행: ./gradlew :app:testDebugUnitTest
 */
class AppGuideTest {
    private fun body(): String {
        val f = AppGuide::class.java.getDeclaredField("BODY")
        f.isAccessible = true
        return f.get(AppGuide) as String
    }

    @Test
    fun 설정_큰_묶음이_다_있다() {
        val b = body()
        for (big in listOf("브라우저", "화면", "미디어", "알림", "광고 차단", "보안", "개인정보", "앱 정보")) {
            assertTrue(big, b.contains("- $big"))
        }
    }

    @Test
    fun 핵심_규칙과_경로_표기가_있다() {
        val b = body()
        assertTrue(b.contains("메뉴(⋮) → 설정"))
        assertTrue(b.contains("지어내지 마세요"))
        assertTrue(b.contains("도구를 쓰지 말고 안내로 답"))
        assertTrue(b.contains("AI 에이전트"))
    }

    @Test
    fun 문자열_템플릿_기호가_없다() {
        assertFalse(body().contains('$'))
    }
}
