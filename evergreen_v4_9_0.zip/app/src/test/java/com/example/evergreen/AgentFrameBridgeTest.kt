package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * iframe 조작 스크립트(AgentPageTools.frameBridgeScript)가 사이트의 CSP 에 막히지 않고, 치환하다 만 자리가 없는지 본다.
 * 자바스크립트를 실제로 돌려 보는 시험은 아니고 (그건 브라우저가 필요하다), 만들어진 글만 확인한다.
 */
class AgentFrameBridgeTest {
    private val js = AgentPageTools.frameBridgeScript()

    @Test
    fun usesTheListenerNameTheAppRegisters() {
        assertEquals("EvFrame", AgentPageTools.FRAME_BRIDGE_NAME)
        assertTrue(js.contains("window." + AgentPageTools.FRAME_BRIDGE_NAME))
    }

    @Test
    fun doesNotNeedEval() {
        // iframe 의 CSP 가 unsafe-eval 을 막아도 돌아야 한다: 코드는 미리 들어 있고 글을 코드로 바꾸지 않는다
        assertFalse(js.contains("eval("))
        assertFalse(js.contains("new Function"))
        assertFalse(js.contains("setTimeout(\""))
    }

    @Test
    fun doesNothingInTheMainFrame() {
        assertTrue(js.contains("if(top0)return;"))
    }

    @Test
    fun hasNoLeftoverPlaceholders() {
        for (ph in listOf("__GRAD__", "__ID__", "__SCOPE__", "__TEXT__", "__KIND__", "__VAL__", "__HOLD__", "__SUBMIT__", "__TO__", "__DX__", "__DY__", "__DIR__", "__AMT__")) {
            assertFalse("남은 자리표시: $ph", js.contains(ph))
        }
    }

    @Test
    fun carriesEveryOperation() {
        for (op in listOf("read", "aim", "info", "click", "fill", "drag", "scroll")) {
            assertTrue("동작 없음: $op", js.contains("$op:function(P){"))
        }
    }
}
