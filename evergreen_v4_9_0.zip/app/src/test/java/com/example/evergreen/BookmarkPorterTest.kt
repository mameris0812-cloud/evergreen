package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 북마크 HTML 내보내기 · 가져오기 (BookmarkPorter) 의 글 처리만 확인한다. 파일 입출력은 기기가 필요해 다루지 않는다 */
class BookmarkPorterTest {
    private val chrome = """
        <!DOCTYPE NETSCAPE-Bookmark-file-1>
        <TITLE>Bookmarks</TITLE><H1>Bookmarks</H1>
        <DL><p>
          <DT><H3 ADD_DATE="1">Bookmarks bar</H3>
          <DL><p>
            <DT><A HREF="https://a.com/?x=1&amp;y=2" ADD_DATE="1">A &amp; B</A>
            <DT><H3>뉴스</H3>
            <DL><p><DT><A HREF="https://n.com">N</A></DL><p>
            <DT><A HREF="javascript:void(0)">bad</A>
          </DL><p>
          <DT><A HREF="https://top.com">Top</A>
          <DT><A HREF="https://top.com/">Top again</A>
        </DL><p>
    """.trimIndent()

    @Test
    fun parse_keepsFoldersAndSkipsBadOrDuplicate() {
        val r = BookmarkPorter.parse(chrome)
        assertEquals(3, r.size)
        assertEquals(ParsedBookmark("A & B", "https://a.com/?x=1&y=2", "Bookmarks bar"), r[0])
        assertEquals(ParsedBookmark("N", "https://n.com", "뉴스"), r[1])
        assertEquals(ParsedBookmark("Top", "https://top.com", ""), r[2])
    }

    @Test
    fun export_thenParse_roundTrips() {
        val folders = listOf(Folder(1, "읽을거리"))
        val marks = listOf(
            Bookmark(10, "https://x.com/?a=1&b=2", "X <b>&</b>", 1),
            Bookmark(11, "https://y.com", "Y", 0)
        )
        val html = BookmarkPorter.toHtml(marks, folders, 0L)
        assertTrue(html.contains("&amp;"))
        val back = BookmarkPorter.parse(html)
        assertEquals(2, back.size)
        assertEquals("읽을거리", back[0].folder)
        assertEquals("https://x.com/?a=1&b=2", back[0].url)
        assertEquals("", back[1].folder)
    }
}
