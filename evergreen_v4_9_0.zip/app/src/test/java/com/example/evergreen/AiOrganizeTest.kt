package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * AI 정리 · 말로 찾기 중 JSON 을 쓰지 않는 글 처리만 확인한다 (주소 고르기 · 중복 묶기 · 이름 다듬기 · 낱말 찾기).
 * 단위 테스트 환경에는 org.json 이 없어서 AI 답 읽기(parseGroups 등)는 다루지 않는다.
 */
class AiOrganizeTest {
    @Test
    fun normUrl_ignoresSchemeWwwSlashFragmentAndTracking() {
        val a = AiOrganize.normUrl("https://www.Example.com/a/b/?utm_source=x&id=3#top")
        assertEquals("example.com/a/b?id=3", a)
        assertEquals(a, AiOrganize.normUrl("http://example.com/a/b?id=3"))
        assertEquals("example.com", AiOrganize.normUrl("https://example.com/"))
        assertEquals("example.com?x=1", AiOrganize.normUrl("https://example.com?x=1"))
        // 경로의 대소문자는 다른 페이지일 수 있어 그대로 둔다
        assertTrue(AiOrganize.normUrl("https://a.com/Page") != AiOrganize.normUrl("https://a.com/page"))
    }

    @Test
    fun bookmarkDuplicates_keepsFolderedOrOldest() {
        // 목록은 최근 저장이 앞
        val b1 = Bookmark(1, "https://x.com/p", "x", 0L)
        val b2 = Bookmark(2, "https://www.x.com/p/", "x", 5L)
        val b3 = Bookmark(3, "https://y.com", "y", 0L)
        val g = AiOrganize.bookmarkDuplicates(listOf(b1, b2, b3))
        assertEquals(1, g.size)
        assertEquals(listOf(2L, 1L), g[0].map { it.id })   // 폴더에 든 b2 를 남긴다

        val c1 = Bookmark(1, "https://x.com/p", "x", 0L)
        val c2 = Bookmark(2, "https://x.com/p#a", "x", 0L)
        val g2 = AiOrganize.bookmarkDuplicates(listOf(c1, c2))
        assertEquals(2L, g2[0][0].id)                       // 둘 다 폴더 밖이면 먼저 저장한(뒤쪽) 것
        assertTrue(AiOrganize.bookmarkDuplicates(listOf(b3)).isEmpty())
    }

    @Test
    fun cleanFolderName_stripsBadCharsAndLimitsLength() {
        assertEquals("쇼핑 할인", AiOrganize.cleanFolderName("  쇼핑/할인 "))
        assertEquals("", AiOrganize.cleanFolderName("\"\" /"))
        assertEquals(14, AiOrganize.cleanFolderName("가".repeat(40)).length)
    }

    @Test
    fun cleanFileName_keepsExtensionAndDropsIllegalChars() {
        assertEquals("여행 사진 제주.jpg", AiOrganize.cleanFileName("IMG_1234.jpg", "여행 사진: 제주.jpg"))
        assertEquals("여행 사진 제주.jpg", AiOrganize.cleanFileName("IMG_1234.jpg", "여행 사진/제주"))
        assertNull(AiOrganize.cleanFileName("a.pdf", "a"))          // 같은 이름
        assertNull(AiOrganize.cleanFileName("a.pdf", "  ///  "))    // 남는 글이 없음
        assertEquals("메모", AiOrganize.cleanFileName("download", "메모"))
        assertTrue(AiOrganize.cleanFileName("a.zip", "가".repeat(100))!!.length <= 64)
    }

    @Test
    fun downloadDuplicates_needsSameBaseNameAndSize() {
        fun f(k: String, n: String, size: Long, t: Long) = AiOrganize.DlFile(k, n, size, t, null)
        val files = listOf(
            f("m:3", "보고서 (2).pdf", 100, 30), f("m:2", "보고서 (1).pdf", 100, 20),
            f("m:1", "보고서.pdf", 100, 10), f("m:4", "보고서 (3).pdf", 999, 40),   // 크기가 다르면 다른 파일
            f("m:5", "메모.txt", 0, 50), f("m:6", "메모 (1).txt", 0, 60)            // 크기를 모르면 묶지 않는다
        )
        val g = AiOrganize.downloadDuplicates(files)
        assertEquals(1, g.size)
        assertEquals(listOf("m:1", "m:2", "m:3"), g[0].map { it.key })   // 사본 표시 없는 것이 남고, 나머지는 받은 순
    }

    @Test
    fun baseKey_stripsCopyMarkers() {
        assertEquals("a.pdf", AiOrganize.baseKey("A (1).PDF"))
        assertEquals("a.pdf", AiOrganize.baseKey("a - copy.pdf"))
        assertEquals("a.pdf", AiOrganize.baseKey("a_복사본 2.pdf"))
        assertEquals("readme", AiOrganize.baseKey("README"))
    }

    @Test
    fun keywordMatches_requiresAllWords() {
        val items = listOf(
            HistoryItem("https://a.com/ramen", "라면 레시피 모음", 3),
            HistoryItem("https://b.com", "라면 가격 비교", 2),
            HistoryItem("https://c.com", "파스타 레시피", 1)
        )
        assertEquals(listOf("https://a.com/ramen"), AiOrganize.keywordMatches(items, "라면 레시피").map { it.url })
        assertEquals(2, AiOrganize.keywordMatches(items, "라면").size)
        assertTrue(AiOrganize.keywordMatches(items, "  ").isEmpty())
    }
}
