package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 여러 탭 읽기(read_tabs)의 글자 수 배분 · 탭 글 읽기 스크립트 · 에이전트로 가는 말 테스트.
 * org.json 은 단위 테스트에서 못 쓰므로 도구 실행 자체는 시험하지 않고, 글과 숫자로 정해지는 부분만 확인한다.
 * 실행: ./gradlew :app:testDebugUnitTest
 */
class AgentReadTabsTest {

    @Test
    fun 탭이_많을수록_탭마다_글자_수가_줄고_결과_한도_안에_든다() {
        // 한 탭이면 기본 한도(4000), 여러 탭이면 9000 자를 나눠 쓴다
        assertEquals(4000, AgentPageTools.perTabChars(1, 0))
        assertEquals(3000, AgentPageTools.perTabChars(3, 0))
        assertEquals(1125, AgentPageTools.perTabChars(8, 0))
        for (n in 1..AgentPageTools.TABS_MAX) {
            assertTrue("탭 ${n}개: 글 합계가 결과 한도(${AgentRunner.RESULT_CHARS}) 안에 들어야 해요",
                AgentPageTools.perTabChars(n, 0) * n <= 9000)
        }
    }

    @Test
    fun 글자_수를_직접_줘도_한도를_넘지_않고_너무_작지도_않다() {
        assertEquals(1000, AgentPageTools.perTabChars(2, 1000))
        // 탭 하나에 큰 값을 줘도 4000 을 넘지 않는다
        assertEquals(4000, AgentPageTools.perTabChars(1, 50000))
        // 너무 작은 값은 최소(600)로 올린다
        assertEquals(600, AgentPageTools.perTabChars(2, 50))
        // 0 이하 탭 수가 들어와도 죽지 않는다
        assertEquals(4000, AgentPageTools.perTabChars(0, 0))
    }

    @Test
    fun 탭_글_스크립트는_자리표시가_남지_않고_값을_건드리지_않는다() {
        val js = AgentPageTools.tabTextScript(3000)
        assertFalse("글자 수 자리표시가 남아 있어요", js.contains("__MAX__"))
        assertTrue(js.contains("var M=3000;"))
        assertTrue(js.startsWith("(function(){"))
        assertTrue(js.trimEnd().endsWith("})()"))
        // 본문 · 제목 · 소개를 읽고, 입력칸의 값(.value)은 읽지 않는다
        assertTrue(js.contains("innerText"))
        assertTrue(js.contains("og:description"))
        assertFalse(js.contains(".value"))
        // 사이트의 CSP(eval 금지)에 막히지 않게 eval · Function 을 쓰지 않는다
        assertFalse(js.contains("eval("))
        assertFalse(js.contains("new Function"))
    }

    @Test
    fun 탭_글_스크립트의_글자_수는_범위_안으로_맞춘다() {
        assertTrue(AgentPageTools.tabTextScript(5).contains("var M=200;"))
        assertTrue(AgentPageTools.tabTextScript(999999).contains("var M=20000;"))
    }

    @Test
    fun 여러_페이지를_견주는_말은_에이전트로_간다() {
        for (q in listOf(
            "열린 탭 세 개 비교해 줘", "탭들 내용 요약해 줘", "열어 둔 페이지들 비교해 줘",
            "여러 페이지 한꺼번에 읽고 정리해 줘", "이 사이트들 중에 뭐가 나은지 알려 줘", "두 사이트 비교해 줘 탭에 열어 뒀어"
        )) {
            assertTrue("$q 는 에이전트로 가야 해요", AgentRouting.useAgent(q))
        }
    }

    @Test
    fun 가벼운_말은_여전히_일반_채팅으로_간다() {
        assertFalse(AgentRouting.useAgent("이 글 정리해 줘"))
        assertFalse(AgentRouting.useAgent("오늘 뭐 먹을까"))
    }
}
