package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** 읽어주기 글 다듬기 · 나누기 (안드로이드 없이 돌아가는 부분만) */
class ReadAloudTest {

    @Test
    fun cleanDropsMarkdownCodeAndUrls() {
        val raw = "## 제목\n- **굵게** 글자와 [링크](https://a.com) 입니다\n```kotlin\nval x = 1\n```\n끝 https://b.com"
        val out = ReadAloud.clean(raw)
        assertFalse(out.contains("#"))
        assertFalse(out.contains("*"))
        assertFalse(out.contains("http"))
        assertFalse(out.contains("val x"))
        assertTrue(out.contains("굵게 글자와 링크 입니다"))
        assertTrue(out.contains("코드는 생략"))
    }

    @Test
    fun cleanKeepsPlainSentences() {
        assertEquals("안녕하세요. 반가워요", ReadAloud.clean("안녕하세요. 반가워요"))
    }

    @Test
    fun splitKeepsShortTextWhole() {
        assertEquals(listOf("짧은 글"), ReadAloud.split("짧은 글"))
    }

    @Test
    fun splitCutsLongTextWithinLimitAndLosesNothing() {
        val sentence = "이것은 아주 긴 답변의 한 문장입니다. "
        val text = sentence.repeat(400).trim()
        val parts = ReadAloud.split(text, 3000)
        assertTrue(parts.size >= 2)
        assertTrue(parts.all { it.length <= 3000 })
        assertEquals(text.replace(" ", ""), parts.joinToString("").replace(" ", ""))
    }
}
