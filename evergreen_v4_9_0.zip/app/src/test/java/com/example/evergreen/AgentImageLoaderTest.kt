package com.example.evergreen

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 사진 보기 도구가 기기 안 · 내부 네트워크 주소를 막는지([AgentImageLoader.blockedHost]) 확인한다.
 * 실행: ./gradlew :app:testDebugUnitTest
 */
class AgentImageLoaderTest {
    @Test
    fun 내부_주소는_막는다() {
        val bad = listOf(
            "http://localhost/a.png", "http://127.0.0.1/a.png", "http://10.0.0.5/a.png", "http://192.168.0.1/a.png",
            "http://172.16.3.4/a.png", "http://169.254.169.254/latest", "http://100.64.0.1/a.png", "http://nas/a.png",
            "http://printer.local/a.png", "http://[::1]/a.png", "not a url"
        )
        for (u in bad) assertTrue(u, AgentImageLoader.blockedHost(u))
    }

    @Test
    fun 바깥_주소는_연다() {
        val ok = listOf("https://example.com/a.png", "http://8.8.8.8/a.png", "https://cdn.site.co.kr/img/1.jpg?x=1", "http://172.32.0.1/a.png")
        for (u in ok) assertFalse(u, AgentImageLoader.blockedHost(u))
    }
}
