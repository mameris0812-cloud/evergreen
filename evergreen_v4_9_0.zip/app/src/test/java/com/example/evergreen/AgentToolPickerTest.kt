package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 요청마다 모델에게 알려 줄 도구 묶음을 고르는 [AgentToolPicker.groupsFor] 테스트.
 * 빠진 묶음의 도구를 모델이 부르면 러너가 그 자리에서 불러오지만, 흔한 요청은 처음부터 맞게 골라야 한 단계를 아낀다.
 * 실행: ./gradlew :app:testDebugUnitTest
 */
class AgentToolPickerTest {
    private fun g(q: String, sticky: Set<String> = emptySet()) = AgentToolPicker.groupsFor(q, sticky)

    @Test
    fun 탭_이동_말은_추가_묶음_없이_기본_도구만() {
        assertEquals(emptySet<String>(), g("탭 다 닫아 줘"))
        assertEquals(emptySet<String>(), g("구글 열어 줘"))
        assertEquals(emptySet<String>(), g("맨 아래로 스크롤해 줘"))
    }

    @Test
    fun 분야_낱말이_있으면_그_묶음을_싣는다() {
        assertTrue("settings" in g("다크 모드 켜 줘"))
        assertTrue("bookmark" in g("북마크 폴더 정리해 줘"))
        assertTrue("tabgroup" in g("탭 그룹으로 묶어 줘"))
        assertTrue("ext" in g("웹스토어에서 확장 설치해 줘"))
        assertTrue("media" in g("음악 멈춰 줘"))
        assertTrue("window" in g("새 창으로 옮겨 줘"))
        assertTrue("download" in g("이 이미지 다운로드해 줘"))
        assertTrue("history" in g("방문 기록 열어 줘"))
    }

    @Test
    fun 지우기_말은_지울_수_있는_묶음을_모두_싣는다() {
        val s = g("다 지워 줘")
        assertTrue("bookmark" in s && "history" in s && "download" in s)
    }

    @Test
    fun 북마크_가져오기는_받은_파일_도구도_싣는다() {
        assertTrue("download" in g("북마크 가져와 줘"))
    }

    @Test
    fun 바로_앞_묶음은_이어_말하기에서_이어진다() {
        val s = g("응 그걸로 해", setOf("bookmark"))
        assertTrue("bookmark" in s)
        assertFalse("media" in s)
    }
}
