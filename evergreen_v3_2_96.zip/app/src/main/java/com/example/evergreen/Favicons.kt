package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * 방문 기록 · 북마크 목록에 보여 줄 웹사이트 아이콘.
 * - 웹페이지가 알려 준 아이콘은 사이트(호스트)별로 파일에 저장해 둔다 (MainActivity 의 onReceivedIcon).
 * - 저장된 게 없으면 사이트의 /favicon.ico 를 받아 보고, 그래도 없으면 EXTERNAL_FALLBACK 서비스에서 받는다.
 *   (외부 서비스를 쓰고 싶지 않으면 EXTERNAL_FALLBACK 을 null 로 바꾸면 된다)
 * - 끝내 못 구하면 원래 아이콘(지구본/북마크)을 그대로 둔다.
 */
object Favicons {

    private const val EXTERNAL_FALLBACK = "https://www.google.com/s2/favicons?sz=64&domain=%s"

    private val mem = LruCache<String, Bitmap>(120)
    private val failed = HashSet<String>()
    private val pending = HashMap<String, MutableList<(Bitmap?) -> Unit>>()
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    /** 확장 프로그램 안의 페이지(ext.evergreen.invalid)면 그 확장 프로그램 자신의 아이콘을 돌려주는 함수 (MainActivity 가 정해 둔다) */
    @Volatile var extIcon: ((String) -> Bitmap?)? = null

    private fun isExt(url: String?): Boolean =
        url != null && try { Uri.parse(url).host == ExtensionManager.HOST } catch (e: Exception) { false }

    private fun extBitmap(url: String?): Bitmap? =
        if (!isExt(url)) null else try { extIcon?.invoke(url!!) } catch (e: Exception) { null }

    fun host(url: String): String? =
        try { Uri.parse(url).host?.lowercase()?.removePrefix("www.")?.ifEmpty { null } } catch (e: Exception) { null }

    private fun dir(ctx: Context) = File(ctx.applicationContext.filesDir, "favicons").also { it.mkdirs() }
    private fun file(ctx: Context, host: String) = File(dir(ctx), host.replace(Regex("[^a-z0-9.-]"), "_") + ".png")

    /** 웹페이지가 알려 준 아이콘을 저장한다 (너무 작은 건 무시) */
    fun save(ctx: Context, url: String?, icon: Bitmap?) {
        if (isExt(url)) return
        val host = host(url ?: return) ?: return
        if (icon == null || icon.width < 16 || icon.height < 16) return
        val copy = icon.copy(Bitmap.Config.ARGB_8888, false) ?: return
        io.execute {
            try {
                file(ctx, host).outputStream().use { copy.compress(Bitmap.CompressFormat.PNG, 100, it) }
                synchronized(this) { mem.put(host, copy); failed.remove(host) }
            } catch (_: Exception) {}
        }
    }

    /** 네트워크 없이, 이미 저장해 둔 아이콘만 바로 돌려준다 (앱을 다시 켠 뒤 탭 아이콘 복원용). 없으면 null */
    fun cached(ctx: Context, url: String?): Bitmap? {
        if (isExt(url)) return extBitmap(url)
        val host = host(url ?: return null) ?: return null
        synchronized(this) { mem.get(host)?.let { return it } }
        return try {
            val f = file(ctx, host)
            if (!f.exists()) return null
            val b = BitmapFactory.decodeFile(f.path) ?: return null
            synchronized(this) { mem.put(host, b) }
            b
        } catch (_: Exception) { null }
    }

    private fun fetch(urlStr: String): Bitmap? = try {
        val c = URL(urlStr).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 4000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode == 200) {
            val bytes = c.inputStream.use { it.readBytes() }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.takeIf { it.width >= 16 && it.height >= 16 }
        } else null
    } catch (_: Exception) { null }

    private fun load(ctx: Context, host: String): Bitmap? {
        val f = file(ctx, host)
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return it }
        val bmp = fetch("https://$host/favicon.ico")
            ?: EXTERNAL_FALLBACK?.let { fetch(it.format(host)) }
        if (bmp != null) try { f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Exception) {}
        return bmp
    }

    private val genCache = LruCache<String, Bitmap>(80)

    /**
     * 사이트 아이콘을 못 구했을 때 쓰는 앱 자체 아이콘: 사이트 주소(호스트)마다 정해진 색의 동그라미 + 첫 글자.
     * 같은 사이트는 항상 같은 모양이고, 같은 호스트면 같은 비트맵 객체를 돌려준다. 주소가 없으면 null
     */
    fun generated(url: String?): Bitmap? {
        extBitmap(url)?.let { return it }
        val host = host(url ?: return null) ?: return null
        synchronized(genCache) { genCache.get(host)?.let { return it } }
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hue = ((host.hashCode().toLong() and 0x7fffffffL) % 360L).toFloat()
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.78f)) }
        c.drawCircle(size / 2f, size / 2f, size / 2f, bg)
        val letter = (host.firstOrNull { it.isLetterOrDigit() } ?: '?').uppercaseChar().toString()
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = size * 0.54f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        val y = size / 2f - (tp.descent() + tp.ascent()) / 2f
        c.drawText(letter, size / 2f, y, tp)
        synchronized(genCache) { genCache.put(host, bmp) }
        return bmp
    }

    private const val STALE_MS = 12L * 60 * 60 * 1000
    private val refreshedHosts = HashSet<String>()

    private fun readText(urlStr: String): String? = try {
        val c = URL(urlStr).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 4000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode == 200) {
            val buf = ByteArray(150_000)
            var n = 0
            c.inputStream.use { ins -> while (n < buf.size) { val r = ins.read(buf, n, buf.size - n); if (r < 0) break; n += r } }
            String(buf, 0, n, Charsets.UTF_8)
        } else null
    } catch (_: Exception) { null }

    /** 사이트 첫 페이지의 <link rel="icon"> 중 가장 큰 것을 받는다 (svg 등 못 읽는 건 건너뜀). 없으면 null */
    private fun fetchFromPage(host: String): Bitmap? {
        val base = "https://$host/"
        val html = readText(base) ?: return null
        val cands = ArrayList<Pair<Int, String>>()
        Regex("<link\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html).forEach { m ->
            val tag = m.value
            fun attr(n: String) = Regex("\\b$n\\s*=\\s*([\"'])(.*?)\\1", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(2)
            val rel = attr("rel")?.lowercase() ?: return@forEach
            if (!rel.split(Regex("\\s+")).any { it == "icon" || it == "shortcut" || it == "apple-touch-icon" }) return@forEach
            val href = attr("href")?.trim()?.takeIf { it.isNotEmpty() } ?: return@forEach
            val size = attr("sizes")?.let { Regex("(\\d+)x\\d+").find(it)?.groupValues?.get(1)?.toIntOrNull() } ?: 0
            cands.add(size to href)
        }
        for ((_, href) in cands.sortedByDescending { it.first }.take(4)) {
            val abs = try { URL(URL(base), href).toString() } catch (_: Exception) { continue }
            fetch(abs)?.let { return it }
        }
        return null
    }

    /**
     * 저장해 둔 아이콘이 오래됐으면(12시간) 사이트에서 새 아이콘을 받아 저장하고 [onDone] 으로 알려 준다.
     * 앱이 켜져 있는 동안 사이트마다 한 번만 확인한다. 새로 못 받으면 아무것도 안 한다 (옛 아이콘 유지).
     */
    fun refreshIfStale(ctx: Context, url: String, onDone: (Bitmap) -> Unit) {
        if (isExt(url)) return
        val host = host(url) ?: return
        val app = ctx.applicationContext
        synchronized(this) {
            if (host in refreshedHosts) return
            val f = file(app, host)
            if (f.exists() && System.currentTimeMillis() - f.lastModified() < STALE_MS) return
            refreshedHosts.add(host)
        }
        io.execute {
            val bmp = fetchFromPage(host) ?: fetch("https://$host/favicon.ico") ?: fetch(EXTERNAL_FALLBACK.format(host))
            if (bmp != null) {
                try { file(app, host).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Exception) {}
                synchronized(this) { mem.put(host, bmp); failed.remove(host) }
                main.post { onDone(bmp) }
            } else {
                // 받기 실패: 다음에 다시 시도하도록 시간만 갱신하지 않고 목록에서 뺀다
                synchronized(this) { refreshedHosts.remove(host) }
            }
        }
    }

    /** 사이트 아이콘을 (저장된 게 있으면 바로, 없으면 받아 와서) 메인 스레드에서 [onDone] 으로 알려 준다. 못 구하면 null */
    fun fetch(ctx: Context, url: String, onDone: (Bitmap?) -> Unit) {
        if (isExt(url)) { val b = extBitmap(url); main.post { onDone(b) }; return }
        val host = host(url) ?: return onDone(null)
        val app = ctx.applicationContext
        synchronized(this) {
            mem.get(host)?.let { b -> main.post { onDone(b) }; return }
            if (host in failed) { main.post { onDone(null) }; return }
            val waiting = pending[host]
            if (waiting != null) { waiting.add(onDone); return }
            pending[host] = mutableListOf(onDone)
        }
        io.execute {
            val bmp = load(app, host)
            val cbs: List<(Bitmap?) -> Unit>
            synchronized(this) {
                if (bmp != null) mem.put(host, bmp) else failed.add(host)
                cbs = pending.remove(host) ?: emptyList()
            }
            main.post { cbs.forEach { it(bmp) } }
        }
    }

    /** 아이콘 뷰에 사이트 아이콘을 입힌다. 아직 없으면 받아 오는 동안 원래 아이콘을 그대로 둔다. */
    fun apply(iv: ImageView, url: String) {
        if (isExt(url)) {
            extBitmap(url)?.let { iv.tag = null; iv.imageTintList = null; iv.setImageBitmap(it) }
            return
        }
        val host = host(url)
        iv.tag = host
        if (host == null) return
        val ctx = iv.context.applicationContext
        fun show(b: Bitmap) {
            if (iv.tag != host) return
            iv.imageTintList = null
            iv.setImageBitmap(b)
        }
        synchronized(this) {
            mem.get(host)?.let { show(it); return }
            if (host in failed) return
            val waiting = pending[host]
            val cb: (Bitmap?) -> Unit = { b -> if (b != null) show(b) }
            if (waiting != null) { waiting.add(cb); return }
            pending[host] = mutableListOf(cb)
        }
        io.execute {
            val bmp = load(ctx, host)
            val cbs: List<(Bitmap?) -> Unit>
            synchronized(this) {
                if (bmp != null) mem.put(host, bmp) else failed.add(host)
                cbs = pending.remove(host) ?: emptyList()
            }
            main.post { cbs.forEach { it(bmp) } }
        }
    }
}
