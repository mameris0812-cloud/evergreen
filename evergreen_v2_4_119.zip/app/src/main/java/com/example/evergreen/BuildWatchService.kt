package com.example.evergreen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * GitHub Actions 빌드를 앱이 화면 밖에 있어도 지켜보는 포그라운드 서비스.
 *  - 알림에 진행률(%)과 경과 시간(시스템 스톱워치, 1초마다 올라감)을 보여 준다.
 *  - 빌드가 끝나면 알림이 '빌드 완료/실패/취소'(걸린 시간 포함)로 바뀌고 서비스는 내려간다.
 *  - 진행 창(BuildStatus)이 끝을 직접 처리했으면 [stop] 으로 서비스와 완료 알림을 함께 치운다.
 *  - 화면이 꺼진 채 무한정 붙들지 않도록 40분 뒤에는 스스로 내려간다.
 */
class BuildWatchService : Service() {

    companion object {
        private const val CH_RUN = "build_watch"
        private const val CH_DONE = "build_done"
        private const val CH_RUN_HIDDEN = "build_watch_hidden"
        private const val ID_RUN = 4302
        private const val ID_DONE = 4303
        private const val MAX_MS = 40 * 60 * 1000L
        private const val POLL_MS = 15_000L
        private const val ACTION_STOP = "com.example.evergreen.BUILD_WATCH_STOP"

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, BuildWatchService::class.java))
            } catch (e: Exception) {
                // 시작이 막혀도 진행 창은 그대로 동작한다
            }
        }

        /** 서비스를 내리고 떠 있던 완료 알림도 치운다 */
        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, BuildWatchService::class.java))
            } catch (e: Exception) {
                // 이미 내려간 상태
            }
            try {
                (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID_DONE)
            } catch (e: Exception) {
                // 무시
            }
        }
    }

    @Volatile private var stopped = false
    private var worker: Thread? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun openIntent(): PendingIntent? {
        val launch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        } ?: return null
        return PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun runNotification(startedMs: Long, done: Int, total: Int, queued: Boolean): Notification {
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, BuildWatchService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, if (Prefs(this).notifyBuildProgress) CH_RUN else CH_RUN_HIDDEN)
            .setSmallIcon(R.drawable.ic_notif_evergreen)
            .setContentTitle("빌드 중")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent())
            .addAction(0, "그만 보기", stopPi)
        if (startedMs > 0L) {
            // 기기 시계가 서버보다 느려도 음수로 안 나오게 현재 시각을 넘지 않게 한다
            b.setWhen(minOf(startedMs, System.currentTimeMillis()))
                .setShowWhen(true)
                .setUsesChronometer(true)
        }
        val pctText: String
        if (queued || total == 0) {
            b.setContentText("대기 중…")
            b.setProgress(0, 0, true)
            pctText = "대기"
        } else {
            val pct = done * 100 / total
            b.setContentText("진행 $pct%")
            b.setProgress(100, pct, false)
            pctText = "$pct%"
        }
        // 안드로이드 16(One UI 8) Live Updates: 삼성 Now Bar·상태표시줄 칩에 빌드 진행을 올려 달라고 요청한다.
        // (지원하지 않는 기기에서는 이 값들이 무시되고 일반 알림으로만 뜬다)
        val pf = Prefs(this)
        if (pf.notifyBuildProgress && pf.notifyBuildLive) {
            b.addExtras(Bundle().apply {
                putBoolean("android.requestPromotedOngoing", true)
                putString("android.shortCriticalText", pctText) // 칩에 짧게 보이는 글자 (7자 안쪽)
            })
        }
        return b.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopped = true
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (worker != null) return START_NOT_STICKY   // 이미 지켜보는 중
        if (Build.VERSION.SDK_INT >= 26) {
            nm().createNotificationChannel(NotificationChannel(CH_RUN, "빌드 진행", NotificationManager.IMPORTANCE_LOW))
            nm().createNotificationChannel(NotificationChannel(CH_DONE, "빌드 결과", NotificationManager.IMPORTANCE_DEFAULT))
            // 진행 알림을 끄면 알림창·상태표시줄에 나타나지 않게 '알림 끔' 채널로 보낸다 (포그라운드 서비스는 알림 객체가 꼭 있어야 한다)
            nm().createNotificationChannel(NotificationChannel(CH_RUN_HIDDEN, "빌드 진행 (표시 안 함)", NotificationManager.IMPORTANCE_NONE))
        }
        try {
            ServiceCompat.startForeground(
                this, ID_RUN, runNotification(0L, 0, 0, true),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "evergreen:build").apply {
            setReferenceCounted(false)
            try { acquire(MAX_MS) } catch (e: Exception) { /* 무시 */ }
        }
        val app = applicationContext
        worker = Thread { watch(app) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun watch(ctx: Context) {
        val token = runCatching { GitUpload.loadToken(ctx) }.getOrNull()
        val begin = System.currentTimeMillis()
        var startedMs = 0L
        while (!stopped && System.currentTimeMillis() - begin < MAX_MS) {
            var snap: BuildStatus.Snapshot? = null
            var fatal = false
            try {
                snap = BuildStatus.fetch(null, token)
            } catch (e: BuildStatus.RateLimited) {
                fatal = true   // 한도에 닿았으면 더 묻지 않는다
            } catch (e: Exception) {
                // 일시적인 네트워크 오류: 다음 차례에 다시 시도
            }
            if (fatal) break
            val s = snap
            if (s != null) {
                if (s.startedMs > 0L) startedMs = s.startedMs
                if (s.status == "completed") {
                    finishWith(s, startedMs)
                    return
                }
                try {
                    nm().notify(ID_RUN, runNotification(startedMs, s.done, s.total, s.status == "queued"))
                } catch (e: Exception) {
                    // 무시
                }
            } else {
                // 진행 중인 빌드가 없다
                break
            }
            try { Thread.sleep(POLL_MS) } catch (e: InterruptedException) { return }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun finishWith(s: BuildStatus.Snapshot, startedMs: Long) {
        val took = if (startedMs > 0L) "걸린 시간 ${BuildStatus.fmtElapsed(System.currentTimeMillis() - startedMs)}" else ""
        val (title, text) = when (s.conclusion) {
            "success" -> "빌드 완료" to (if (took.isNotEmpty()) "$took · 눌러서 업데이트 확인" else "눌러서 업데이트 확인")
            "cancelled" -> "빌드가 취소됐어요" to took
            else -> "빌드에 실패했어요" to took
        }
        val n = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_notif_evergreen)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openIntent())
            .build()
        if (Prefs(this).notifyBuildResult) try { nm().notify(ID_DONE, n) } catch (e: Exception) { /* 무시 */ }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopped = true
        worker?.interrupt()
        worker = null
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // 무시
        }
        wake = null
        super.onDestroy()
    }
}
