package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.SystemClock
import android.view.PixelCopy
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.dynamicanimation.animation.SpringAnimation

/**
 * '내장 플레이어로 열기' 를 누르면 웹페이지 속 영상이 그 자리에서 화면 가득 커지면서 플레이어가 열리게 하는 전환.
 *
 * 1. 영상이 있던 자리를 PixelCopy 로 복사해 온다 (복사가 안 되면 어두운 판으로 대신한다).
 * 2. 브라우저 창 위에 그 그림을 얹어, 영상 자리에서 화면 가운데(영상 비율 그대로)로 스프링처럼 커지게 한다.
 *    살짝 넘쳤다가 돌아오며 자리를 잡는다. 뒤의 페이지는 크기는 그대로 두고 어둡게만 가린다.
 *    이때부터 페이지 영상은 멈춰 소리가 겹치지 않는다.
 * 3. 확대가 진행되어 뒤가 다 가려지면 플레이어 창을 페이드 없이 연다. 플레이어는 같은 그림을 덮어 두고,
 *    **같은 스프링 값(progress)으로 같은 움직임을 이어서 그린다.** 그래서 창이 바뀌는 순간에도 영상이 튀거나 두 장이 비치지 않고,
 *    넘쳤다 돌아오는 움직임이 끊김 없이 끝까지 이어진다.
 * 4. 스프링이 자리를 잡고 영상 첫 화면이 그려지면, 덮어 둔 그림을 서서히 걷어 실제 영상으로 이어지게 한다.
 */
object PlayerZoom {
    /** 확대는 고정 시간 곡선이 아니라 스프링(앱의 다른 움직임과 같은 방식): 빠르게 붙고, 살짝 넘쳤다가 부드럽게 자리를 잡는다 */
    private const val STIFFNESS = 240f
    private const val DAMPING = 0.72f
    /** 확대가 이만큼(0~1) 진행하면 플레이어 창을 연다. 이때 뒤 페이지는 이미 완전히 가려져 있다(SCRIM_FULL_AT) */
    private const val START_AT = 0.8f
    private const val SCRIM_FULL_AT = 0.8f
    /** 복사해 오는 그림의 긴 쪽 최대 길이(px) */
    private const val MAX_SIDE = 1280f
    private const val FAILSAFE_MS = 4600L

    /** 확대 전후의 자리. 브라우저 창과 플레이어 창이 같은 값으로 같은 움직임을 그리게 하려고 한곳에 둔다 */
    private class Geo(
        val l: Int, val t: Int, val w: Int, val h: Int,
        val fl: Float, val ft: Float, val endScale: Float, val corner0: Float
    )

    private class Corner : ViewOutlineProvider() {
        var r = 0f
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }

    private var cover: Bitmap? = null
    private var coverAt = 0L
    private var geo: Geo? = null

    private var overlay: View? = null
    private var mainGhost: ImageView? = null
    private var coverGhost: ImageView? = null
    private var spring: SpringAnimation? = null
    private var settled = true
    private var cur = 0f
    private var pendingSettle: (() -> Unit)? = null
    private val failsafe = Runnable { dismiss() }

    /** 플레이어가 처음 덮어 둘 그림을 맡겨 둔다 (플레이어가 attachCover 로 가져간다) */
    private fun put(b: Bitmap?) {
        cover = b
        coverAt = SystemClock.uptimeMillis()
    }

    private fun take(): Bitmap? {
        val b = cover
        cover = null
        return if (b != null && !b.isRecycled && SystemClock.uptimeMillis() - coverAt < 10_000L) b else null
    }

    /** 브라우저 창 위의 확대 오버레이를 치운다. 플레이어의 덮개가 움직이는 중이면 스프링은 끝까지 두고, 아니면 멈춘다 */
    fun dismiss() {
        mainGhost = null
        overlay?.let {
            it.removeCallbacks(failsafe)
            (it.parent as? ViewGroup)?.removeView(it)
        }
        overlay = null
        if (coverGhost == null) {
            spring?.cancel()
            spring = null
            settled = true
        }
    }

    private fun makeGhost(ctx: Context, bmp: Bitmap?, g: Geo): ImageView = ImageView(ctx).apply {
        scaleType = ImageView.ScaleType.FIT_XY
        if (bmp != null) setImageBitmap(bmp) else setBackgroundColor(0xFF111111.toInt())
        pivotX = 0f
        pivotY = 0f
        outlineProvider = Corner().also { it.r = g.corner0 }
        clipToOutline = true
    }

    /** 진행값 p(0 → 1, 넘치면 1 보다 커짐)에 맞춰 영상 그림의 자리·크기·모서리를 정한다. 브라우저 창과 플레이어 창이 같은 식을 쓴다 */
    private fun place(iv: ImageView, g: Geo, p: Float) {
        val s = 1f + (g.endScale - 1f) * p
        iv.scaleX = s
        iv.scaleY = s
        iv.translationX = g.l + (g.fl - g.l) * p
        iv.translationY = g.t + (g.ft - g.t) * p
        // 모서리는 커질수록 각지게 (뷰 자체 좌표로 그려지므로 확대 배율로 나눠 화면에서의 둥글기를 맞춘다)
        (iv.outlineProvider as? Corner)?.r = (g.corner0 * (1f - p) / s).coerceAtLeast(0f)
        iv.invalidateOutline()
    }

    /** 자리를 잡았으니 창 크기에 맞춘 평범한 배치(화면에 맞추기)로 바꾼다. 방향이 바뀌어도 알아서 따라간다 */
    private fun snapFinal(iv: ImageView) {
        iv.scaleX = 1f
        iv.scaleY = 1f
        iv.translationX = 0f
        iv.translationY = 0f
        iv.clipToOutline = false
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setBackgroundColor(Color.BLACK)
        iv.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    /**
     * 플레이어 창이 부른다: 확대하던 그림과 같은 그림을 [root] 맨 위에 덮고, 같은 움직임을 이어서 그린다.
     * 맡겨진 그림이 없으면 null (그냥 연 경우).
     */
    fun attachCover(ctx: Context, root: FrameLayout): ImageView? {
        val bmp = take() ?: return null
        val g = geo ?: return null
        val iv = makeGhost(ctx, bmp, g)
        if (settled) {
            snapFinal(iv)
            root.addView(iv)
        } else {
            root.addView(iv, FrameLayout.LayoutParams(g.w, g.h))
            place(iv, g, cur)
            coverGhost = iv
        }
        return iv
    }

    /** 화면 방향이 바뀌는 등으로 움직임을 이어 그릴 수 없을 때: 바로 최종 배치로 */
    fun settleCoverNow() {
        coverGhost?.let { snapFinal(it) }
        coverGhost = null
    }

    /** 덮어 둔 그림을 서서히 걷는다. 스프링이 아직 움직이는 중이면 자리를 잡은 뒤에 걷는다 */
    fun fadeOutCover(iv: ImageView) {
        val go = {
            iv.animate().alpha(0f).setDuration(160L).withEndAction {
                (iv.parent as? ViewGroup)?.removeView(iv)
                dismiss()
            }.start()
        }
        if (settled) go() else pendingSettle = go
    }

    /**
     * [src] (창 좌표, px) 자리에서 화면 가득 커지는 전환을 보여 주고, 뒤가 다 가려지면 [onStart] 를 부른다(여기서 플레이어를 연다).
     * [onBegin] 은 움직임이 시작되는 순간 부른다(페이지 영상을 멈추는 데 쓴다).
     * [exact] 가 false(영상이 화면 밖으로 많이 잘려 있음)이면 플레이어에 그림을 넘기지 않는다 (영상 모양이 달라 어긋나 보이므로).
     * 전환을 보여 줄 수 없으면 [onStart] 를 부르지 않고 false 를 돌려준다 (부른 쪽이 그냥 연다).
     */
    fun play(act: Activity, src: Rect, exact: Boolean, handler: Handler, onBegin: () -> Unit, onStart: () -> Unit): Boolean {
        spring?.cancel()
        spring = null
        coverGhost = null
        pendingSettle = null
        dismiss()
        val deco = act.window.decorView as? ViewGroup
        if (deco == null || deco.width <= 0 || deco.height <= 0) return false
        val r = Rect(src)
        if (!r.intersect(0, 0, deco.width, deco.height) || r.width() < 8 || r.height() < 8) return false
        // 영상 위의 버튼이 사라진 뒤의 화면을 복사하도록 아주 잠깐만 기다린다
        handler.postDelayed({
            if (act.isFinishing || act.isDestroyed) return@postDelayed
            capture(act, r, handler) { bmp ->
                if (act.isFinishing || act.isDestroyed) return@capture
                animate(act, deco, r, bmp, exact, onBegin, onStart)
            }
        }, 30L)
        return true
    }

    private fun capture(act: Activity, r: Rect, handler: Handler, done: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            done(null)
            return
        }
        try {
            val sc = minOf(1f, MAX_SIDE / maxOf(r.width(), r.height()).toFloat())
            val bmp = Bitmap.createBitmap(
                (r.width() * sc).toInt().coerceAtLeast(1),
                (r.height() * sc).toInt().coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            PixelCopy.request(act.window, r, bmp, { result ->
                done(if (result == PixelCopy.SUCCESS) bmp else null)
            }, handler)
        } catch (e: Throwable) {
            done(null)
        }
    }

    private fun animate(act: Activity, deco: ViewGroup, r: Rect, bmp: Bitmap?, exact: Boolean, onBegin: () -> Unit, onStart: () -> Unit) {
        val dw = deco.width.toFloat()
        val dh = deco.height.toFloat()
        val d = act.resources.displayMetrics.density

        // 끝 모양: 영상 비율 그대로 화면에 맞춘다 (플레이어의 '화면에 맞추기' 와 같은 자리)
        val ar = r.width().toFloat() / r.height()
        val fw: Float
        val fh: Float
        if (dw / dh > ar) { fh = dh; fw = dh * ar } else { fw = dw; fh = dw / ar }
        val g = Geo(r.left, r.top, r.width(), r.height(), (dw - fw) / 2f, (dh - fh) / 2f, fw / r.width(), 12f * d)
        geo = g

        val layer = FrameLayout(act)
        layer.isClickable = true // 전환 중에는 뒤 페이지가 터치를 받지 않게
        val scrim = View(act).apply {
            setBackgroundColor(Color.BLACK)
            alpha = 0f
        }
        layer.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val iv = makeGhost(act, bmp, g)
        layer.addView(iv, FrameLayout.LayoutParams(g.w, g.h))
        place(iv, g, 0f)
        deco.addView(layer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay = layer
        mainGhost = iv
        layer.postDelayed(failsafe, FAILSAFE_MS)

        var started = false
        fun start() {
            if (started) return
            started = true
            put(if (exact) bmp else null)
            onStart()
        }

        settled = false
        cur = 0f
        onBegin()
        spring = Motion.springValue(
            from = 0f, to = 1f, stiffness = STIFFNESS, damping = DAMPING,
            onUpdate = { p ->
                cur = p
                // 뒤 페이지는 크기를 그대로 두고 어둡게만 가린다
                scrim.alpha = (p / SCRIM_FULL_AT).coerceIn(0f, 1f)
                mainGhost?.let { place(it, g, p) }
                coverGhost?.let { place(it, g, p) }
                if (p >= START_AT) start()
            },
            onEnd = {
                settled = true
                cur = 1f
                scrim.alpha = 1f
                mainGhost?.let { place(it, g, 1f) }
                coverGhost?.let { snapFinal(it) }
                coverGhost = null
                start()
                pendingSettle?.invoke()
                pendingSettle = null
            }
        )
    }
}
