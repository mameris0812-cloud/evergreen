package com.example.evergreen

/** 페이지 안에서 돌아가는 스크립트 모음 (재생 상태 알림 / 일시정지 / PiP 용 화면 꾸미기) */
object MediaScripts {

    /**
     * 모든 프레임에서 문서 시작 시점에 실행된다.
     * - 영상/소리 재생 상태가 바뀌면 EvMedia.state() 로 앱에 알린다.
     * - 백그라운드 재생이 켜져 있으면 페이지가 "숨겨짐"을 감지해 스스로 멈추지 못하게 가시성 API 를 가린다.
     * - postMessage({__ev:'pause'}) 를 받으면 (iframe 포함) 재생 중인 미디어를 멈춘다.
     * - 탭 음소거: EvMedia.muted() 가 true 인 동안 모든 video/audio 와 WebAudio 출력을 끈다.
     *   postMessage({__ev:'mute'}) 를 받으면 (iframe 포함) 상태를 다시 읽어 적용한다.
     */
    const val INJECT = """
(function(){
 if(window.__evMedia) return; window.__evMedia=1;
 var fid=Math.random().toString(36).slice(2);
 function bg(){try{return EvMedia.bg()}catch(e){return false}}
 try{
  var dh=Object.getOwnPropertyDescriptor(Document.prototype,'hidden');
  var dv=Object.getOwnPropertyDescriptor(Document.prototype,'visibilityState');
  Object.defineProperty(document,'hidden',{configurable:true,get:function(){return bg()?false:dh.get.call(document)}});
  Object.defineProperty(document,'visibilityState',{configurable:true,get:function(){return bg()?'visible':dv.get.call(document)}});
  var stop=function(e){if(bg())e.stopImmediatePropagation()};
  window.addEventListener('visibilitychange',stop,true);
  document.addEventListener('visibilitychange',stop,true);
 }catch(e){}

 /* ── 문서에 붙어 있지 않은 미디어도 잡는다 ──
    스포티파이 같은 사이트는 new Audio() / createElement('video') 로 만든 요소를 문서에 붙이지 않고 재생한다.
    그러면 querySelectorAll 로는 안 보여서 재생 중인 걸 모르고, 백그라운드 유지도 알림도 안 켜져 곧 소리가 끊긴다.
    그래서 play() 가 불리는 순간 그 요소를 직접 기억해 두고 함께 살핀다. ── */
 var reg=[];
 function onEl(e){
  var t=e&&e.target;
  if(t&&(e.type=='play'||e.type=='playing'))act=t;
  setTimeout(function(){try{chk()}catch(e1){} try{prog()}catch(e2){}},60);
 }
 function track(x){
  if(!x||x.__evT)return; x.__evT=1; reg.push(x);
  ['play','playing','pause','ended','emptied','loadeddata','seeked'].forEach(function(n){x.addEventListener(n,onEl,true)});
  if(reg.length>30){
   for(var i=0;i<reg.length;i++){var y=reg[i]; if(!y.isConnected&&(y.paused||y.ended)){reg.splice(i,1);break}}
  }
 }
 function all(){
  var m=[].slice.call(document.querySelectorAll('video,audio'));
  for(var i=0;i<reg.length;i++){if(m.indexOf(reg[i])<0)m.push(reg[i])}
  return m;
 }
 try{
  var MP=window.HTMLMediaElement&&HTMLMediaElement.prototype,op=MP&&MP.play;
  if(op){MP.play=function(){try{track(this);if(!this.isConnected)act=this}catch(e){} return op.apply(this,arguments)}}
 }catch(e){}
 try{
  var hf=Document.prototype.hasFocus;
  document.hasFocus=function(){return bg()?true:hf.call(document)};
 }catch(e){}

 /* ── 탭 음소거: 이 탭이 음소거면 video/audio 를 muted 로, WebAudio 는 게인 0 으로 만든다 ── */
 var muteOn=false,gains=[];
 function mu(){try{return !!EvMedia.muted()}catch(e){return false}}
 function applyMute(){
  var m=all();
  for(var i=0;i<m.length;i++){var x=m[i];
   try{
    if(muteOn){ if(!x.__evM){x.__evM=1;x.__evWas=x.muted} if(!x.muted)x.muted=true }
    else if(x.__evM){x.__evM=0;x.muted=!!x.__evWas}
   }catch(e){}
  }
  for(var g=0;g<gains.length;g++){try{gains[g].gain.value=muteOn?0:1}catch(e){}}
 }
 function syncMute(){var n=mu(); if(n!==muteOn){muteOn=n} applyMute()}
 try{
  var AN=window.AudioNode&&AudioNode.prototype,oc=AN&&AN.connect,od=AN&&AN.disconnect;
  if(oc){
   AN.connect=function(d){
    var a=arguments;
    if(window.AudioDestinationNode&&d instanceof AudioDestinationNode){
     var c=this.context;
     if(!c.__evG){var gn=c.createGain();oc.call(gn,c.destination);gn.gain.value=muteOn?0:1;c.__evG=gn;gains.push(gn)}
     a=[].slice.call(arguments);a[0]=c.__evG;
     oc.apply(this,a);return d;
    }
    return oc.apply(this,a);
   };
   AN.disconnect=function(d){
    var a=arguments;
    if(window.AudioDestinationNode&&d instanceof AudioDestinationNode&&d.context.__evG){
     a=[].slice.call(arguments);a[0]=d.context.__evG;
    }
    return od.apply(this,a);
   };
  }
 }catch(e){}
 muteOn=mu();
 ['play','playing','loadeddata','volumechange'].forEach(function(n){
  document.addEventListener(n,function(){if(muteOn)applyMute()},true);
 });
 setInterval(function(){if(muteOn)applyMute()},1200);
 /* ── fetch / XHR 응답의 종류(Content-Type)가 스트리밍 목록(HLS·DASH·스무스)이면 그 주소를 앱에 알린다 ──
    주소에 .m3u8 / .mpd 가 없는 영상(예: /api/stream?id=3)도 내장 플레이어·저장 후보에 오른다.
    조각(ts / m4s)은 같은 종류로 보내는 경우가 많아 일부러 목록 형식만 잡는다. 응답 내용은 읽지 않는다. */
 var MRE=/^(application[/](vnd[.]apple[.]mpegurl|x-mpegurl|dash[+]xml|vnd[.]ms-sstr[+]xml)|audio[/](x-)?mpegurl)/i,mseen={};
 function mrep(u,ct){
  try{
   if(!u||!ct||!MRE.test(ct))return;
   u=new URL(u,location.href).href;
   if(!/^https?:/i.test(u)||mseen[u])return; mseen[u]=1; EvMedia.src(u);
  }catch(e){}
 }
 try{
  var ofe=window.fetch;
  if(ofe){window.fetch=function(){
   var pr=ofe.apply(this,arguments);
   try{pr.then(function(r){try{mrep(r.url,r.headers.get('content-type'))}catch(e1){}},function(){})}catch(e2){}
   return pr;
  }}
 }catch(e){}
 try{
  var XP=window.XMLHttpRequest&&XMLHttpRequest.prototype,xop=XP&&XP.open;
  if(xop){XP.open=function(m,u){
   try{var xr=this;xr.addEventListener('readystatechange',function(){
    if(xr.readyState===2){try{mrep(xr.responseURL||u,xr.getResponseHeader('content-type'))}catch(e3){}}
   })}catch(e4){}
   return xop.apply(this,arguments);
  }}
 }catch(e){}
 /* ── 재생이 시작된 영상 주소를 앱에 알린다 ──
    다른 도메인의 iframe 안에 있는 영상은 주 프레임이 들여다볼 수 없다. 그 iframe 안에서도 이 스크립트가 돌고 있으니
    영상 주소(http/https 만, blob 제외)를 직접 보내서 내장 플레이어 후보에 오르게 한다. */
 function rep(x){
  try{
   var u=x.currentSrc||x.src;
   if(u&&/^https?:/i.test(u)&&u!==x.__evU){x.__evU=u;EvMedia.src(u)}
  }catch(e){}
 }
 ['loadstart','loadedmetadata','playing'].forEach(function(n){
  document.addEventListener(n,function(e){
   var t=e.target; if(t&&(t.tagName=='VIDEO'||t.tagName=='AUDIO'))rep(t);
  },true);
 });
 /* ── 화면에 크게 보이는 영상은 재생 전에도 미리 받아 둔다 ──
    모바일 브라우저는 preload 가 metadata/none 이면 조금만 받고 멈춘다('suspend'). 그러면 재생을 누른 뒤에야
    받기 시작해서 첫 화면이 늦다. 지금 화면에 크게 보이는 영상만 골라 preload=auto 로 바꿔 계속 받게 한다.
    (피드의 작은 영상이나 화면 밖 영상은 건드리지 않아 데이터를 아낀다) */
 document.addEventListener('suspend',function(e){
  var x=e.target;
  try{
   if(!x||x.tagName!=='VIDEO'||x.preload==='auto')return;
   var r=x.getBoundingClientRect(),vw=window.innerWidth,vh=window.innerHeight;
   if(r.width<vw*0.5||r.height<80||r.bottom<0||r.top>vh)return;
   x.preload='auto';
  }catch(err){}
 },true);
 var last='';
 function chk(){
  var m=all(),p=false,v=false,w=0,h=0;
  for(var i=0;i<m.length;i++){var x=m[i];
   if(!x.paused&&!x.ended&&x.readyState>2){p=true;
    if(x.tagName=='VIDEO'&&x.videoWidth>0&&!v){v=true;w=x.videoWidth;h=x.videoHeight}}}
  var k=p+','+v+','+w+','+h;
  if(k===last)return; last=k;
  try{EvMedia.state(fid,p,v,w,h)}catch(e){}
 }
 ['play','playing','pause','ended','emptied','loadeddata'].forEach(function(n){
  document.addEventListener(n,function(){setTimeout(chk,60)},true);
 });
 setInterval(function(){if(reg.length||document.querySelector('video,audio'))chk()},2500);
 /* ── 메뉴의 미디어 플레이어용: 진행 상황 보고 / 조작 명령 받기 ── */
 var act=null;
 function pick(){
  var m=all();
  for(var i=0;i<m.length;i++){var x=m[i]; if(!x.paused&&!x.ended&&x.readyState>2)return x}
  return (act&&(document.contains(act)||reg.indexOf(act)>=0))?act:null;
 }
 /* 곡·영상이 바뀌면 페이지가 알려 주는 제목/아티스트(mediaSession)를 앱에 전한다. 바뀐 때만 보낸다.
    (사이트 탭 제목은 곡이 바뀌어도 그대로인 곳이 많아서 메뉴 카드가 옛날 정보에 머물렀다) */
 var lastMeta='';
 /* 시스템 미디어 플레이어에 쓸 그림 주소: 페이지가 알려 준 mediaSession 그림(가장 큰 것) → 영상 poster → og:image 순서 */
 /* poster / og:image 는 단일 페이지 사이트(SPA)에서 영상이 바뀌어도 그대로 남아 있는 경우가 많다.
    영상 주소(currentSrc)가 바뀌었는데 이 대체 그림 주소가 그대로면 옛날 그림으로 보고 쓰지 않는다
    (그러면 앱이 사이트 아이콘으로 대신한다). 페이지가 mediaSession 으로 직접 알려 준 그림은 그대로 믿는다 */
 var fbArt='', fbSrc='';
 function fallbackArt(x, c){
  if(!c){fbArt='';fbSrc='';return ''}
  var src=(x&&x.currentSrc)||'';
  if(c!==fbArt){fbArt=c;fbSrc=src;return c}
  if(src&&fbSrc&&src!==fbSrc)return '';
  if(src&&!fbSrc)fbSrc=src;
  return c;
 }
 function artUrl(x){
  try{
   var md=navigator.mediaSession&&navigator.mediaSession.metadata;
   var aw=md&&md.artwork, best='', bs=-1, fromSite=false;
   if(aw){
    for(var i=0;i<aw.length;i++){
     var s=aw[i]&&aw[i].src; if(!s)continue;
     var m=/(\d+)x(\d+)/.exec(aw[i].sizes||''); var sz=m?parseInt(m[1],10):0;
     if(sz>bs){bs=sz;best=s}
    }
    if(best)fromSite=true;
   }
   if(!best&&x&&x.poster)best=x.poster;
   if(!best){var o=document.querySelector('meta[property="og:image"],meta[name="twitter:image"]'); if(o)best=o.content||''}
   if(!best){fbArt='';fbSrc='';return ''}
   var u=new URL(best,location.href).href;
   if(!/^https?:/i.test(u))return '';
   return fromSite?u:fallbackArt(x,u);
  }catch(e){return ''}
 }
 function meta(){
  try{
   var md=navigator.mediaSession&&navigator.mediaSession.metadata;
   var t=md&&md.title?String(md.title):'', a=md&&md.artist?String(md.artist):'';
   var px=pick();
   /* 페이지가 mediaSession 을 안 쓰는 사이트: 영상 요소 자체의 제목(title / aria-label) 이라도 쓴다 */
   if(!t&&px){try{t=(px.getAttribute('title')||px.getAttribute('aria-label')||'').trim()}catch(e0){}}
   var im=artUrl(px);
   var k=t+'\u0001'+a+'\u0001'+im;
   if(k===lastMeta)return; lastMeta=k;
   thOk=false;thLast=0;   /* 곡·영상이 바뀌었으니 영상 화면에서 새로 썸네일을 뽑는다 */
   EvMedia.meta(fid,t,a,im);
  }catch(e){}
 }
 /* 페이지가 navigator.mediaSession.metadata 를 새로 넣는 순간 바로 보고한다 (곡이 바뀐 직후 옛 그림이 남지 않게) */
 try{
  var ms=navigator.mediaSession;
  if(ms&&!ms.__evHook){
   var md0=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(ms),'metadata');
   if(md0&&md0.get&&md0.set){
    Object.defineProperty(ms,'metadata',{configurable:true,enumerable:true,
     get:function(){return md0.get.call(ms)},
     set:function(v){md0.set.call(ms,v);setTimeout(meta,30)}});
    ms.__evHook=1;
   }
  }
 }catch(e){}
 /* 썸네일 주소가 없거나 못 받는 사이트를 위해, 재생 중인 영상의 지금 화면을 작게 떠서 앱에 보낸다.
    다른 사이트의 영상이라 canvas 로 못 읽는 경우(보안 제한)는 조용히 건너뛴다. */
 var thLast=0,thSrc='',thOk=false;
 function thumb(x){
  try{
   if(!x||x.readyState<2||!x.videoWidth||x.paused)return;
   var src=x.currentSrc||'',now=Date.now();
   if(src!==thSrc){thSrc=src;thOk=false;thLast=0}
   if(thOk||now<thLast)return;
   thLast=now+4000;
   var w=x.videoWidth,h=x.videoHeight,sc=Math.min(1,320/Math.max(w,h));
   var c=document.createElement('canvas');c.width=Math.max(1,Math.round(w*sc));c.height=Math.max(1,Math.round(h*sc));
   var g=c.getContext('2d');g.drawImage(x,0,0,c.width,c.height);
   var px=g.getImageData(0,0,c.width,c.height).data,sum=0;
   for(var i=0;i<px.length;i+=64)sum+=px[i]+px[i+1]+px[i+2];
   if(sum<300)return;   /* 아직 검은 화면 */
   var u=c.toDataURL('image/jpeg',0.7);
   thOk=true;EvMedia.thumb(fid,u);
  }catch(e){thLast=Date.now()+30000}
 }
 function prog(){
  var x=pick(); if(!x)return;
  thumb(x);
  var d=x.duration;
  try{EvMedia.progress(fid,x.currentTime||0,(isFinite(d)&&d>0)?d:-1,!x.paused&&!x.ended)}catch(e){}
  meta();
 }
 ['play','playing'].forEach(function(n){
  document.addEventListener(n,function(e){
   var t=e.target; if(t&&(t.tagName=='VIDEO'||t.tagName=='AUDIO')){act=t;setTimeout(prog,60)}
  },true);
 });
 ['pause','ended','seeked','loadstart','loadedmetadata','durationchange','loadeddata','emptied'].forEach(function(n){
  document.addEventListener(n,function(){setTimeout(prog,60)},true);
 });
 setInterval(function(){var x=pick(); if(!x)return; if(!x.paused&&!x.ended)prog(); else meta()},1000);
 /* ── 메뉴 미디어 플레이어의 파형: 켜져 있는 동안만 소리 크기를 막대 값으로 보고한다.
    captureStream 으로 복사본만 분석하므로 실제 소리 출력에는 손대지 않는다.
    다른 사이트의 보호된 미디어는 무음으로 읽혀서, 그러면 'x' 를 보내 앱이 대체 움직임을 쓰게 한다 ── */
 var WN=28,wc=null,wan=null,wsrc=null,wsrcEl=null,wtimer=0,wbuf=null,wzero=0;
 function waveStop(){
  if(wtimer){clearInterval(wtimer);wtimer=0}
  try{if(wc&&wc.state==='running')wc.suspend()}catch(e){}
  try{EvMedia.wave(fid,'')}catch(e){}
 }
 function waveSetup(x){
  try{
   if(!wc){
    var AC=window.AudioContext||window.webkitAudioContext; if(!AC)return false;
    wc=new AC(); wan=wc.createAnalyser(); wan.fftSize=256; wan.smoothingTimeConstant=0.55;
    wbuf=new Uint8Array(wan.frequencyBinCount);
   }
   if(wc.state==='suspended'){var r=wc.resume(); if(r&&r.catch)r.catch(function(){})}
   if(wsrcEl!==x){
    var cs=x.captureStream?x.captureStream():(x.mozCaptureStream?x.mozCaptureStream():null);
    if(!cs||!cs.getAudioTracks().length)return false;
    if(wsrc){try{wsrc.disconnect()}catch(e){}}
    wsrc=wc.createMediaStreamSource(cs); wsrc.connect(wan); wsrcEl=x;
   }
   return true;
  }catch(e){return false}
 }
 function waveTick(){
  var x=pick();
  if(!x||x.paused||x.ended){try{EvMedia.wave(fid,'')}catch(e){}return}
  if(!waveSetup(x)){try{EvMedia.wave(fid,'x')}catch(e){}return}
  wan.getByteFrequencyData(wbuf);
  var sum=0,vals=[];
  for(var i=0;i<WN;i++){
   var lo=Math.floor(Math.pow(i/WN,1.7)*100)+1,hi=Math.max(lo+1,Math.floor(Math.pow((i+1)/WN,1.7)*100)+1);
   var s=0,c=0; for(var b=lo;b<hi&&b<wbuf.length;b++){s+=wbuf[b];c++}
   var v=c?s/c:0; sum+=v; vals.push(Math.min(99,Math.round(v/255*99)));
  }
  if(sum<1)wzero++; else wzero=0;
  try{EvMedia.wave(fid,wzero>25?'x':vals.join(','))}catch(e){}
 }
 window.addEventListener('pagehide',function(){last='';try{EvMedia.state(fid,false,false,0,0);EvMedia.gone(fid)}catch(e){}});
 var mfit=0,mtimer=0;
 /* ── 미러링 자막: 영상의 자막 트랙 목록을 앱에 알리고, 앱이 고른 트랙의 글을 시간에 맞춰 보낸다 (그리기·번역은 앱이 한다) ── */
 var msubSel=-1,msubT=null,msubLast='',msubSig='';
 function msubList(v){
  var out=[],tl=v.textTracks; if(!tl)return out;
  var map=[],te=v.querySelectorAll('track');
  for(var q=0;q<te.length;q++){try{map.push([te[q].track,te[q].src||''])}catch(e){}}
  for(var i=0;i<tl.length;i++){
   var t=tl[i]; if(t.kind!=='subtitles'&&t.kind!=='captions')continue;
   var u=''; for(var z=0;z<map.length;z++){if(map[z][0]===t){u=map[z][1];break}}
   out.push({i:i,l:t.label||'',g:t.language||'',u:u});
  }
  return out;
 }
 function msubRep(){
  var v=document.querySelector('video.__ev_pip'); if(!v)return;
  var sig=JSON.stringify(msubList(v));
  if(sig!==msubSig){msubSig=sig;try{EvMedia.msubs(sig)}catch(e){}}
 }
 function msubCue(){
  if(msubSel<0||!msubT)return;
  var a=msubT.activeCues,s=[];
  if(a)for(var i=0;i<a.length;i++){var x=a[i].text; if(x)s.push(x)}
  var txt=s.join('\n');
  if(txt===msubLast)return;
  msubLast=txt;
  try{EvMedia.mcue(txt)}catch(e){}
 }
 function msubPick(n){
  var v=document.querySelector('video.__ev_pip'); if(!v)return;
  var tl=v.textTracks; if(!tl)return;
  if(msubT){try{msubT.removeEventListener('cuechange',msubCue)}catch(e){}}
  msubT=null;msubSel=-1;msubLast='';
  for(var i=0;i<tl.length;i++){
   var t=tl[i]; if(t.kind!=='subtitles'&&t.kind!=='captions')continue;
   if(t.__evMode===undefined)t.__evMode=t.mode;
   if(i===n){
    /* hidden: 글은 계속 받아 오되 페이지가 직접 그리지 않는다 (앱이 번역·모양을 입혀 그린다) */
    t.mode='hidden'; msubT=t; msubSel=i;
    try{t.addEventListener('cuechange',msubCue)}catch(e){}
   } else t.mode='disabled';
  }
  if(msubSel<0){try{EvMedia.mcue('')}catch(e){}}
  setTimeout(msubCue,80);
 }
 function msubRestore(){
  try{
   if(msubT){msubT.removeEventListener('cuechange',msubCue)}
   var vs=document.querySelectorAll('video');
   for(var k=0;k<vs.length;k++){var tl=vs[k].textTracks; if(!tl)continue;
    for(var i=0;i<tl.length;i++){var t=tl[i]; if(t.__evMode!==undefined){try{t.mode=t.__evMode}catch(e){} t.__evMode=undefined}}}
  }catch(e){}
  msubT=null;msubSel=-1;msubLast='';msubSig='';
 }
 /* 영상(또는 영상이 든 iframe)의 윗대 요소에 transform·contain·overflow 같은 것이 걸려 있으면 position:fixed 가 창 전체가 아니라 그 안에 갇혀 영상이 안 보인다 → 윗대 요소의 그 속성들을 풀어 준다 */
 function mAnc(el){
  try{ var p=el.parentElement,n=0; while(p&&p!==document.documentElement&&n<60){p.classList.add('__ev_anc');p=p.parentElement;n++} }catch(e){}
 }
 function mirrorStyle(){
  var st=document.getElementById('__ev_pip_style');
  if(!st){st=document.createElement('style');st.id='__ev_pip_style';document.documentElement.appendChild(st)}
  st.textContent='html,body{overflow:hidden!important;background:#000!important}'
   +'body *{visibility:hidden!important}'
   +'video.__ev_pip{visibility:visible!important;position:fixed!important;top:0!important;left:0!important;'
   +'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;'
   +'z-index:2147483647!important;background:#000!important;object-fit:'+['contain','cover','fill'][mfit]+'!important;transform:none!important}'
   +'.__ev_anc{transform:none!important;filter:none!important;perspective:none!important;contain:none!important;will-change:auto!important;'
   +'overflow:visible!important;clip:auto!important;clip-path:none!important;mask:none!important;backdrop-filter:none!important;'
   +'opacity:1!important;content-visibility:visible!important;container-type:normal!important;transition:none!important}'
   +'iframe.__ev_mfr{visibility:visible!important;position:fixed!important;top:0!important;left:0!important;'
   +'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;'
   +'z-index:2147483647!important;border:0!important;background:#000!important;transform:none!important}';
 }
 /* 미러링 중인 영상의 재생 상태를 앱의 덧씌운 컨트롤 막대에 알린다 (영상이 든 프레임만 보고한다) */
 function mrep(){
  var v=document.querySelector('video.__ev_pip'); if(!v)return;
  var d=v.duration;
  try{EvMedia.mprog(v.currentTime||0,(isFinite(d)&&d>0)?d:-1,!v.paused&&!v.ended,v.playbackRate||1)}catch(e){}
  try{msubRep();msubCue()}catch(e){}
 }
 function mrepOn(v){
  if(!v.__evMr){v.__evMr=1;['play','playing','pause','ended','seeked','ratechange','loadedmetadata','durationchange'].forEach(function(n){v.addEventListener(n,function(){setTimeout(mrep,40)},true)})}
  if(!mtimer)mtimer=setInterval(mrep,500);
  mrep();
 }
 function mirrorSet(on,own){
  var vs=[].slice.call(document.querySelectorAll('video'));
  if(!on){
   if(mtimer){clearInterval(mtimer);mtimer=0}
   mfit=0;
   msubRestore();
   var st=document.getElementById('__ev_pip_style'); if(st) st.remove();
   var ms=document.querySelectorAll('video.__ev_pip');
   for(var i=0;i<ms.length;i++){
    ms[i].classList.remove('__ev_pip');
    if(ms[i].__evCtl===0)ms[i].controls=false; else if(ms[i].__evCtl===1)ms[i].controls=true;
    ms[i].__evCtl=undefined;
   }
   var fs=document.querySelectorAll('iframe.__ev_mfr');
   for(var j=0;j<fs.length;j++)fs[j].classList.remove('__ev_mfr');
   var an=document.querySelectorAll('.__ev_anc');
   for(var a2=0;a2<an.length;a2++)an[a2].classList.remove('__ev_anc');
   return;
  }
  if(!vs.length)return;
  var v=null,k;
  /* 영상 아래 버튼으로 방금 고른 영상 → 재생 중인 영상 → 이 프레임에서 가장 큰 영상 */
  for(k=0;k<vs.length;k++){if(vs[k].__evPrefAt&&Date.now()-vs[k].__evPrefAt<8000){v=vs[k];break}}
  if(!v)for(k=0;k<vs.length;k++){if(!vs[k].paused&&!vs[k].ended){v=vs[k];break}}
  if(!v){
   if(window!==window.top)return;
   vs.sort(function(a,b){return b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight});v=vs[0];
  }
  mirrorStyle();
  v.classList.add('__ev_pip');
  mAnc(v);
  /* 페이지의 조작 버튼은 가려지므로 기본 조작(재생·탐색)을 켠다 */
  /* 앱이 컨트롤 막대를 직접 덧씌우는 경우(own)에는 페이지 영상의 기본 조작을 끈다 */
  if(v.__evCtl===undefined){v.__evCtl=v.controls?1:0;v.controls=!own}
  if(own)mrepOn(v);
  try{if(window.parent!==window)window.parent.postMessage({__ev:'mirrorUp'},'*')}catch(x){}
 }
 window.addEventListener('message',function(e){
  var d=e.data; if(!d)return;
  if(d.__ev==='cmd'){
   if(d.f===fid){
    if(d.a==='wave'){ if(d.v===1){if(!wtimer)wtimer=setInterval(waveTick,90)} else waveStop() }
    var x=(d.a==='wave')?null:pick();
    if(x){
     try{
      if(d.a==='toggle'){ if(x.paused||x.ended){var pr=x.play(); if(pr&&pr.catch)pr.catch(function(){})} else x.pause() }
      else if(d.a==='seek'){ x.currentTime=Math.max(0,d.v) }
      else if(d.a==='skip'){ x.currentTime=Math.max(0,(x.currentTime||0)+d.v) }
      else if(d.a==='next'){
       /* 재생 목록의 '다음' 버튼이 있으면 누르고, 없으면 끝으로 보내 사이트가 다음 영상을 이어 틀게 한다 */
       var nb=null;
       try{nb=document.querySelector('.ytp-next-button,.next-button,[data-testid="control-button-skip-forward"],[aria-label="Next" i],[aria-label="Next track" i],[aria-label="다음" i],[aria-label="다음 곡" i]')}catch(e2){}
       var nbOk=nb&&nb.offsetParent!==null&&!nb.disabled&&nb.getAttribute('aria-disabled')!=='true';
       if(nbOk){ nb.click() } else if(isFinite(x.duration)&&x.duration>0){ x.currentTime=Math.max(0,x.duration-0.05) }
      }
      else if(d.a==='prev'){
       /* 재생 목록의 '이전' 버튼이 있으면 그걸 누르고(처음 3초 안일 때), 없거나 3초 이상 봤으면 처음부터 다시 */
       var pb=null;
       try{pb=document.querySelector('.ytp-prev-button,.previous-button,[data-testid="control-button-skip-back"],[aria-label="Previous" i],[aria-label="Previous track" i],[aria-label="이전" i],[aria-label="이전 곡" i]')}catch(e1){}
       var pbOk=pb&&pb.offsetParent!==null&&!pb.disabled&&pb.getAttribute('aria-disabled')!=='true';
       if(pbOk&&(x.currentTime||0)<3){ pb.click() } else { x.currentTime=0 }
      }
     }catch(err){}
     setTimeout(prog,120);
    }
   }
   var f3=document.querySelectorAll('iframe');
   for(var q=0;q<f3.length;q++){try{f3[q].contentWindow.postMessage(d,'*')}catch(x2){}}
   return;
  }
  if(d.__ev==='mute'){
   syncMute();
   var f2=document.querySelectorAll('iframe');
   for(var k=0;k<f2.length;k++){try{f2[k].contentWindow.postMessage(d,'*')}catch(x){}}
   return;
  }
  if(d.__ev==='mirror'){
   /* 내장 플레이어가 못 여는 영상: 이 프레임에서 고른 영상을 창 가득 키워 그대로 보여 준다 (파일을 가져오지 않는다) */
   try{mirrorSet(!!d.on,!!d.ui)}catch(x3){}
   var f4=document.querySelectorAll('iframe');
   for(var m4=0;m4<f4.length;m4++){try{f4[m4].contentWindow.postMessage(d,'*')}catch(x3){}}
   return;
  }
  if(d.__ev==='mcmd'){
   /* 덧씌운 컨트롤 막대의 조작: 이 프레임에 미러링 중인 영상이 있으면 그 영상에, 없으면 안쪽 iframe 으로 넘긴다 */
   var mv=document.querySelector('video.__ev_pip');
   if(mv){
    try{
     if(d.a==='toggle'){ if(mv.paused||mv.ended){var pr2=mv.play(); if(pr2&&pr2.catch)pr2.catch(function(){})} else mv.pause() }
     else if(d.a==='seek'){ mv.currentTime=Math.max(0,d.v) }
     else if(d.a==='skip'){ var du=mv.duration; var nt=(mv.currentTime||0)+d.v; if(isFinite(du)&&du>0)nt=Math.min(nt,du); mv.currentTime=Math.max(0,nt) }
     else if(d.a==='rate'){ mv.playbackRate=d.v; if(window.__sbRate!==undefined)window.__sbRate=d.v }
     else if(d.a==='fit'){ mfit=Math.max(0,Math.min(2,d.v|0)); mirrorStyle() }
     else if(d.a==='sub'){ msubPick(d.v|0) }
    }catch(err2){}
    setTimeout(mrep,60);
   }
   var f5=document.querySelectorAll('iframe');
   for(var q5=0;q5<f5.length;q5++){try{f5[q5].contentWindow.postMessage(d,'*')}catch(x6){}}
   return;
  }
  if(d.__ev==='mirrorUp'){
   /* 안쪽 iframe 이 영상을 키웠다: 이 프레임에서는 그 iframe 만 창 가득 보이게 하고 위로 알린다 */
   var fr=document.querySelectorAll('iframe');
   for(var q2=0;q2<fr.length;q2++){try{if(fr[q2].contentWindow===e.source){fr[q2].classList.add('__ev_mfr');mAnc(fr[q2]);break}}catch(x4){}}
   mirrorStyle();
   try{if(window.parent!==window)window.parent.postMessage({__ev:'mirrorUp'},'*')}catch(x5){}
   return;
  }
  if(d.__ev!=='pause')return;
  var m=all();
  for(var i=0;i<m.length;i++){try{m[i].pause()}catch(x){}}
  var f=document.querySelectorAll('iframe');
  for(var j=0;j<f.length;j++){try{f[j].contentWindow.postMessage(d,'*')}catch(x){}}
 },false);

 /* ── 영상 아래에 '내장 플레이어로 열기' / 'PiP로 보기' 버튼 ──
    페이지에서 크게 보이는 영상(재생 중인 것 우선) 바로 아래 오른쪽에 띄운다. 아래에 자리가 없으면 영상 안쪽 위 오른쪽에 띄운다.
    영상이 전체화면이거나 PiP(작은 창) 중이면 숨긴다. 모든 프레임에서 돌므로 iframe 안의 영상에도 뜬다. */
 (function(){
  try{
   var b1El=null,host=null,wrap=null,cur=null,raf=0,shown=false,hideT=0,bw=250,bh=34,mode='below',lastPick=0,lastEvt=0,relBase=false,lastT='',ro=null,lastAct=0,idleT=0,IDLE=2500;
   function pipOn(){return !!document.getElementById('__ev_pip_style')}
   /* 설정에서 버튼을 껐는지: 매 프레임 묻지 않게 0.4초 동안 기억한다 */
   var btnAt=0,btnV=true;
   function btnOn(){var n=Date.now();if(n-btnAt>400){btnAt=n;try{btnV=!!EvMedia.buttons()}catch(x){btnV=true}}return btnV}
   /* 유튜브 페이지에서도 '내장 플레이어로 열기' 버튼을 보인다 (누르면 앱이 유튜브 영상을 창 가득 보기로 연다) */
   function b1Ok(){return true}
   function fsOn(){return !!(document.fullscreenElement||document.webkitFullscreenElement)}
   function pickVideo(){
    var vs=document.querySelectorAll('video'),best=null,bs=0,H=window.innerHeight,W=window.innerWidth;
    for(var i=0;i<vs.length;i++){
     var v=vs[i],r=v.getBoundingClientRect();
     if(r.width<200||r.height<110)continue;
     var cs=getComputedStyle(v);
     if(cs.visibility==='hidden'||cs.display==='none'||+cs.opacity===0)continue;
     var vw=Math.min(r.right,W)-Math.max(r.left,0),vh=Math.min(r.bottom,H)-Math.max(r.top,0);
     if(vw<r.width*0.3||vh<r.height*0.3)continue;
     var s=vw*vh*((!v.paused&&!v.ended)?4:1);
     if(s>bs){bs=s;best=v}
    }
    return best;
   }
   function make(){
    host=document.createElement('div');
    host.setAttribute('data-ev-ui','1');
    /* 문서 좌표(absolute)+transform 으로 놓는다: 페이지 스크롤은 브라우저가 알아서 같이 움직여 주니 끊기지 않고,
       위치 갱신은 레이아웃 없이 GPU 가 처리하는 transform 만 쓴다 */
    host.style.cssText='position:absolute;left:0;top:0;z-index:2147483646;display:none;pointer-events:none;margin:0;padding:0;border:0;background:none;width:auto;height:auto;will-change:transform;transform:translate3d(0,0,0)';
    var root=host.attachShadow({mode:'closed'});
    var st=document.createElement('style');
    st.textContent='.w{display:flex;gap:6px;white-space:nowrap;justify-content:flex-end}'
     +'button{all:unset;box-sizing:border-box;font:600 12px/1 sans-serif;color:#fff;background:rgba(20,20,20,.82);border:1px solid rgba(255,255,255,.28);border-radius:16px;padding:9px 13px;cursor:pointer;-webkit-tap-highlight-color:transparent;'
     +'opacity:0;transform:translateY(10px) scale(.88);transform-origin:100% 100%;will-change:transform,opacity;'
     +'transition:opacity .12s ease,transform .14s ease,background-color .15s ease}'
     +'.w.up button{transform:translateY(-10px) scale(.88);transform-origin:100% 0}'
     +'.w.in button{opacity:1;transform:none;transition:opacity .2s ease,transform .32s cubic-bezier(.2,.9,.25,1.12),background-color .15s ease}'
     +'.w.in button:nth-child(2){transition-delay:.05s,.05s,0s}'
     +'.w.in button:active{transform:scale(.93);background:rgba(70,70,70,.96);transition-delay:0s;transition-duration:.08s}';
    var w=document.createElement('div');w.className='w';wrap=w;
    var b1=document.createElement('button');b1.textContent='\u25B6 내장 플레이어로 열기';b1El=b1;
    var b2=document.createElement('button');b2.textContent='PiP로 보기';
    function eat(e){e.stopPropagation()}
    ['touchstart','touchend','mousedown','mouseup','pointerdown','pointerup','dblclick'].forEach(function(n){host.addEventListener(n,eat)});
    b1.addEventListener('click',function(e){
     e.stopPropagation();e.preventDefault();
     var v=cur,u='';
     /* currentSrc 가 blob: 이더라도 실제 주소가 source/src 속성에 남아 있을 수 있다.
        blob 주소만 보고 후보 검색으로 넘기면 iframe/MSE 영상은 엉뚱한 선택 팝업이 뜰 수 있어
        사용자가 누른 video 요소에서 HTTP 주소를 우선 찾는다. */
     try{
      if(v){
       var srcs=[v.currentSrc,v.getAttribute('src'),v.src];
       var ss=v.querySelectorAll('source[src]');
       for(var si=0;si<ss.length;si++)srcs.push(ss[si].src,ss[si].getAttribute('src'));
       for(var sj=0;sj<srcs.length;sj++)if(/^https?:/i.test(srcs[sj]||'')){u=srcs[sj];break}
      }
     }catch(x){}
     if(!u){
      try{
       var h=location.href;
       if(location.hostname.indexOf('youtu')>=0&&(h.indexOf('/watch')>0||h.indexOf('/shorts/')>0||h.indexOf('/embed/')>0||h.indexOf('/live/')>0))u=h;
      }catch(x){}
     }
     /* 세 번째 인수는 영상 아래 버튼에서 호출했는지 표시한다.
        blob/MSE 영상은 주소를 직접 얻지 못할 수 있으므로 앱에서 가장 유력한 후보를 자동 선택한다. */
     try{if(v)v.__evPrefAt=Date.now()}catch(x){}
     try{EvMedia.openPlayer(/^https?:/i.test(u)?u:'',v?(v.currentTime||0):0,true)}catch(x){}
    });
    b2.addEventListener('click',function(e){
     e.stopPropagation();e.preventDefault();
     var v=cur; if(!v)return;
     try{v.__evPrefAt=Date.now()}catch(x){}
     function go(){try{EvMedia.pip()}catch(x){}}
     if(v.paused||v.ended){
      try{var p=v.play();if(p&&p.catch)p.catch(function(){})}catch(x){}
      setTimeout(go,450);
     }else go();
    });
    w.appendChild(b1);w.appendChild(b2);root.appendChild(st);root.appendChild(w);
    document.documentElement.appendChild(host);
   }
   /* 부드럽게 나타나고(아래에서 살짝 떠오르며 커짐) 사라진다(작아지며 흐려짐) */
   function setShown(on){
    if(on){
     if(hideT){clearTimeout(hideT);hideT=0}
     if(!shown){
      shown=true;
      host.style.display='block';host.style.pointerEvents='auto';
      bw=host.offsetWidth||bw;bh=host.offsetHeight||bh;
      void wrap.offsetWidth;
      requestAnimationFrame(function(){if(shown)wrap.classList.add('in')});
     }
    }else if(shown){
     shown=false;
     wrap.classList.remove('in');host.style.pointerEvents='none';
     hideT=setTimeout(function(){hideT=0;if(!shown)host.style.display='none'},260);
    }
   }
   function watch(v){
    try{
     if(!window.ResizeObserver)return;
     if(!ro)ro=new ResizeObserver(function(){sched(1)});
     ro.disconnect();if(v)ro.observe(v);
    }catch(x){}
   }
   function place(){
    if(!document.documentElement)return;
    if(fsOn()||pipOn()||!btnOn()){cur=null;if(host)setShown(false);return}
    /* 화면이 가만히 있으면(터치·스크롤이 없으면) 버튼을 숨긴다. 다시 만지거나 스크롤하면 나타난다 */
    if(Date.now()-lastAct>IDLE){if(host)setShown(false);return}
    var now=Date.now(),fresh=false,v=cur,r=null;
    if(v&&v.isConnected&&now-lastPick<=250){
     r=v.getBoundingClientRect();
     if(r.width<200||r.height<110)r=null;
    }
    if(!r){
     v=pickVideo();lastPick=now;fresh=true;
     if(v!==cur){cur=v;watch(v)}
     if(!v){if(host)setShown(false);return}
     r=v.getBoundingClientRect();
    }
    if(!host)make();
    if(!host.isConnected)document.documentElement.appendChild(host);
    var okB1=b1Ok();
    if(b1El&&(b1El.style.display!=='none')!==okB1){b1El.style.display=okB1?'':'none';bw=host.offsetWidth||bw}
    if(fresh||!shown){
     try{relBase=getComputedStyle(document.documentElement).position!=='static'}catch(x){relBase=false}
     if(!shown){host.style.display='block'}
     bw=host.offsetWidth||bw;bh=host.offsetHeight||bh;
    }
    var H=window.innerHeight,W=window.innerWidth;
    /* 아래 자리가 있으면 영상 아래, 없으면 영상 안쪽 위. 경계에서 깜빡이지 않게 여유(히스테리시스)를 둔다 */
    var need=bh+(mode==='below'?6:20);
    var nm=(r.bottom+need<=H)?'below':'in';
    if(nm!==mode){mode=nm;wrap.classList.toggle('up',mode==='in')}
    else if(!shown)wrap.classList.toggle('up',mode==='in');
    var edge=Math.min(r.right,W)-(mode==='below'?4:8);
    var x=Math.max(edge-bw,4);
    var y=(mode==='below')?(r.bottom+6):(Math.max(r.top,0)+8);
    var ox,oy;
    if(relBase){var hr=document.documentElement.getBoundingClientRect();ox=-hr.left;oy=-hr.top}
    else{ox=window.pageXOffset||0;oy=window.pageYOffset||0}
    var t='translate3d('+Math.round(x+ox)+'px,'+Math.round(y+oy)+'px,0)';
    if(t!==lastT){lastT=t;host.style.transform=t}
    setShown(true);
   }
   function tick(){
    raf=0;
    place();
    /* 스크롤/터치 중(그리고 직후 관성 스크롤 동안)에는 매 프레임 따라간다 */
    if(Date.now()-lastEvt<350)raf=requestAnimationFrame(tick);
   }
   function sched(loop){
    if(loop)lastEvt=Date.now();
    if(!raf)raf=requestAnimationFrame(tick);
   }
   function onMove(){lastAct=Date.now();sched(1);armIdle()}
   /* 마지막 움직임 뒤 IDLE 이 지나면 정확히 그때 한 번 확인해서 숨긴다 */
   function armIdle(){
    if(idleT)clearTimeout(idleT);
    idleT=setTimeout(function(){idleT=0;sched(0)},IDLE+40);
   }
   window.addEventListener('scroll',onMove,{capture:true,passive:true});
   window.addEventListener('touchmove',onMove,{capture:true,passive:true});
   window.addEventListener('touchend',onMove,{capture:true,passive:true});
   window.addEventListener('touchstart',onMove,{capture:true,passive:true});
   window.addEventListener('pointerdown',onMove,{capture:true,passive:true});
   window.addEventListener('mousemove',onMove,{capture:true,passive:true});
   window.addEventListener('wheel',onMove,{capture:true,passive:true});
   window.addEventListener('resize',onMove);
   window.addEventListener('orientationchange',onMove);
   ['fullscreenchange','webkitfullscreenchange','play','pause','loadedmetadata'].forEach(function(n){document.addEventListener(n,onMove,true)});
   setInterval(function(){if(document.querySelector('video')||host)sched(0)},500);
  }catch(e){}
 })();

 /* ── 유튜브: 영상을 틀 때마다 자막이 저절로 켜지는 것을 막는다 ──
    유튜브는 한 번 켠 자막(또는 계정의 '항상 자막 표시')을 기억해서 다음 영상마다 자동으로 켠다.
    새 영상이 시작된 직후에만 켜져 있는 자막을 한 번 꺼 주고, 그 뒤에 사용자가 직접 켜는 것은 건드리지 않는다. ── */
 (function(){
  try{
   if(!/(^|\.)youtube(-nocookie)?\.com${'$'}/.test(location.hostname)) return;
   var ccKey='',ccTouched=false,ccDone=false,ccSelf=false,ccTries=0,ccTimer=0;
   var CCSEL='.ytp-subtitles-button,.ytmClosedCaptioningButtonButton';
   function ccPlayer(){return document.getElementById('movie_player')||document.querySelector('.html5-video-player')}
   function ccStop(){if(ccTimer){clearInterval(ccTimer);ccTimer=0}}
   function ccOff(){
    var p=ccPlayer();
    try{ if(p&&p.isSubtitlesOn&&p.isSubtitlesOn()&&p.toggleSubtitles){ p.toggleSubtitles(); return true } }catch(e){}
    var b=document.querySelector(CCSEL);
    if(b&&b.getAttribute('aria-pressed')==='true'){ ccSelf=true; try{b.click()}catch(e){} ccSelf=false; return true }
    return false;
   }
   function ccRun(){
    if(ccTouched||ccDone){ccStop();return}
    if(!ccPlayer()){ if(++ccTries>24)ccStop(); return }
    if(document.querySelector('.ad-showing')) return;      // 광고 중엔 기다린다
    if(ccOff()) ccDone=true;
    if(++ccTries>14)ccStop();                                // 켜져 있지 않았으면 몇 초 지켜보다 그만둔다
   }
   function ccStart(){
    ccStop(); ccDone=false; ccTouched=false; ccTries=0;
    ccTimer=setInterval(ccRun,500);
   }
   function ccKeyNow(){var m=location.search.match(/[?&]v=([^&]+)/);return m?m[1]:location.pathname}
   ['loadeddata','playing'].forEach(function(n){
    document.addEventListener(n,function(e){
     if(!e.target||e.target.tagName!=='VIDEO')return;
     var k=ccKeyNow(); if(k===ccKey)return; ccKey=k; ccStart();
    },true);
   });
   // 사용자가 직접 자막 버튼·메뉴를 누르거나 C 키를 누르면 더는 끄지 않는다
   document.addEventListener('click',function(e){
    if(ccSelf||!e.isTrusted)return;
    var t=e.target; if(t&&t.closest&&t.closest(CCSEL+',.ytp-popup,.ytp-settings-menu')) ccTouched=true;
   },true);
   document.addEventListener('keydown',function(e){
    if(e.isTrusted&&(e.key==='c'||e.key==='C')) ccTouched=true;
   },true);
  }catch(e){}
 })();

 /* ── 유튜브: 광고에 '건너뛰기' 버튼이 나타나면 자동으로 눌러 준다 (설정에서 끌 수 있다) ── */
 (function(){
  try{
   if(location.hostname.indexOf('youtube.com')<0&&location.hostname.indexOf('youtube-nocookie.com')<0) return;
   var SKIP='.ytp-skip-ad-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button,.ytp-ad-skip-button-container button,.ytp-ad-skip-button-slot button,.videoAdUiSkipButton';
   var onAt=0,onV=true,lastAt=0;
   function on(){var n=Date.now();if(n-onAt>500){onAt=n;try{onV=!!EvMedia.ytAutoSkip()}catch(e){onV=true}}return onV}
   function shown(b){
    try{
     var r=b.getBoundingClientRect(); if(r.width<=0||r.height<=0) return false;
     var cs=getComputedStyle(b); return cs.visibility!=='hidden'&&cs.display!=='none';
    }catch(e){return false}
   }
   setInterval(function(){
    if(!on()) return;
    var bs=document.querySelectorAll(SKIP);
    for(var i=0;i<bs.length;i++){
     if(!shown(bs[i])) continue;
     var n=Date.now(); if(n-lastAt<800) return;   // 한 번 누른 뒤 잠깐은 기다린다
     lastAt=n; try{bs[i].click()}catch(e){}
     return;
    }
   },300);
  }catch(e){}
 })();
})();
"""

    /**
     * 내장 플레이어로 넘길 영상 주소를 찾는다 (blob/data 는 제외). 재생 중인 것이 앞에 온다.
     * video/audio/source 태그뿐 아니라 같은 출처 iframe 안, data-src 같은 지연 로딩 속성, og:video 메타,
     * JSON-LD(contentUrl), embed/object, 영상 파일로 연결된 링크, 그리고 페이지가 실제로 불러온 요청 기록(performance)까지 훑는다.
     */
    const val FIND_MEDIA = """
(function(){
 var out=[],seen={},subs=[],sseen={},blobs=[],bseen={};
 var SRE=/\.(vtt|srt|ass|ssa|ttml|dfxp)(\?|#|${'$'})/i;
 var RE=/\.(m3u8|mpd|mp4|webm|m4v|mov|mkv|avi|flv|3gp|3g2|f4v|m2ts|mts|ogv|ogm|wmv|asf|ismv|mpe?g)(\?|#|${'$'})|\.m3u8|\.mpd|\.ism\/manifest/i;
 /* 인라인 스크립트(JSON 설정 포함)에 적힌 영상 주소: https:\/\/ 처럼 슬래시가 이스케이프된 것도 잡는다 */
 var SCRE=/https?:(?:\\?\/){2}(?:\\\/|[^\s"'<>\\])+?\.(?:m3u8|mpd|mp4|webm|m4v|mov|mkv)(?:\?(?:\\\/|\\u0026|[^\s"'<>\\])*)?/gi;
 function scanText(t,addf,max){
  if(!t||typeof t!=='string')return; var m,n=0; SCRE.lastIndex=0;
  while((m=SCRE.exec(t))&&n<max){n++; addf(m[0].replace(/\\\//g,'/').replace(/\\u0026/g,'&'),0,false)}
 }
 function add(u,t,p){
  if(!u||typeof u!=='string'||u.indexOf('data:')==0) return;
  if(u.indexOf('blob:')==0){
   /* blob 주소는 재생용으로는 못 쓰지만, 페이지가 만들어 둔 파일(URL.createObjectURL)이면 저장은 된다 */
   if(!bseen[u]){bseen[u]=1;blobs.push({u:u,t:t||0,p:!!p})}
   return;
  }
  try{u=new URL(u,location.href).href}catch(e){return}
  if(seen[u]) return; seen[u]=1; out.push({u:u,t:t||0,p:!!p});
 }
 /* 같은 출처 iframe 은 여러 겹까지 들어가 본다 (최대 12개 문서) */
 var docs=[document];
 (function collect(doc,depth){
  if(depth>3)return;
  try{
   var fr=doc.querySelectorAll('iframe,frame');
   for(var f=0;f<fr.length&&docs.length<12;f++){
    try{var d=fr[f].contentDocument; if(d&&d.documentElement&&docs.indexOf(d)<0){docs.push(d);collect(d,depth+1)}}catch(e){}
   }
  }catch(e){}
 })(document,0);
 docs.forEach(function(doc){
  var base=doc.location&&doc.location.href||location.href;
  function addd(u,t,p){ if(!u||typeof u!=='string') return; try{u=new URL(u,base).href}catch(e){return} add(u,t,p) }
  var ms=[].slice.call(doc.querySelectorAll('video,audio'));
  /* 열린 shadow DOM 안의 영상 (웹 컴포넌트 플레이어) */
  try{
   var all=doc.querySelectorAll('*');
   for(var sh=0;sh<all.length&&sh<4000;sh++){
    var rt=all[sh].shadowRoot;
    if(rt){var sm=rt.querySelectorAll('video,audio'); for(var sq=0;sq<sm.length;sq++)ms.push(sm[sq])}
   }
  }catch(e){}
  for(var i=0;i<ms.length;i++){
   var m=ms[i],p=!m.paused&&!m.ended;
   addd(m.currentSrc,m.currentTime,p); addd(m.getAttribute('src'),m.currentTime,p);
   ['data-src','data-url','data-video','data-hls','data-mp4','data-stream','data-video-src','data-file','data-source','data-lazy-src'].forEach(function(a){addd(m.getAttribute(a),m.currentTime,p)});
   var ss=m.querySelectorAll('source');
   for(var j=0;j<ss.length;j++){addd(ss[j].src,m.currentTime,p); addd(ss[j].getAttribute('data-src'),m.currentTime,p)}
  }
  var tk=doc.querySelectorAll('video track[src],audio track[src]');
  for(var z=0;z<tk.length&&subs.length<8;z++){
   var tt=tk[z],kd=(tt.kind||'subtitles').toLowerCase();
   if(kd!=='subtitles'&&kd!=='captions')continue;
   try{var su=new URL(tt.getAttribute('src'),base).href;
    if(!sseen[su]&&/^https?:/i.test(su)){sseen[su]=1;subs.push({u:su,l:tt.label||'',g:tt.srclang||''})}}catch(e){}
  }
  var ds=doc.querySelectorAll('source[src],source[data-src],embed[src],object[data]');
  for(var k=0;k<ds.length;k++){var x=ds[k],v=x.getAttribute('src')||x.getAttribute('data-src')||x.getAttribute('data'); if(v&&RE.test(v)) addd(v,0,false)}
  var mt=doc.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
  for(var q=0;q<mt.length;q++){var c=mt[q].getAttribute('content'); if(c&&RE.test(c)) addd(c,0,false)}
  var ld=doc.querySelectorAll('script[type="application/ld+json"]');
  for(var l=0;l<ld.length;l++){
   try{
    (function walk(o){
     if(!o||typeof o!=='object') return;
     if(Array.isArray(o)){o.forEach(walk);return}
     if(typeof o.contentUrl==='string') addd(o.contentUrl,0,false);
     for(var key in o) if(typeof o[key]==='object') walk(o[key]);
    })(JSON.parse(ld[l].textContent));
   }catch(e){}
  }
  /* 재생기 설정이 data-* 속성에 들어 있는 경우 (video.js data-setup 등) / 지연 로딩 속성 / 미리 불러오기 링크 */
  var cf=doc.querySelectorAll('[data-setup],[data-config],[data-options],[data-player],[data-sources]');
  for(var cc=0;cc<cf.length&&cc<60;cc++){
   var cv=cf[cc].getAttribute('data-setup')||cf[cc].getAttribute('data-config')||cf[cc].getAttribute('data-options')||cf[cc].getAttribute('data-player')||cf[cc].getAttribute('data-sources');
   scanText(cv,addd,6);
  }
  var lz=doc.querySelectorAll('[data-video],[data-video-src],[data-video-url],[data-hls],[data-mp4],[data-stream],[data-file],[data-src],[data-url]');
  for(var zz=0;zz<lz.length&&zz<300;zz++){
   ['data-video','data-video-src','data-video-url','data-hls','data-mp4','data-stream','data-file','data-src','data-url'].forEach(function(a){
    var av=lz[zz].getAttribute(a); if(av&&RE.test(av)) addd(av,0,false)
   });
  }
  var lk=doc.querySelectorAll('link[as=video][href],link[rel=preload][href],link[rel=alternate][href]');
  for(var lq=0;lq<lk.length&&lq<40;lq++){var lh=lk[lq].getAttribute('href'); if(lh&&RE.test(lh)) addd(lh,0,false)}
  /* 인라인 스크립트에 적힌 주소 (JW Player / hls.js 설정, 초기 상태 JSON 등) */
  var sc=doc.querySelectorAll('script:not([src])');
  var scn=0;
  for(var sx=0;sx<sc.length&&sx<150&&scn<24;sx++){
   var tx=sc[sx].textContent; if(!tx||tx.length>800000)continue;
   var before=out.length; scanText(tx,addd,8); scn+=out.length-before;
  }
  var as=doc.querySelectorAll('a[href]');
  for(var n=0;n<as.length&&n<400;n++){var h=as[n].getAttribute('href'); if(h&&RE.test(h)) addd(h,0,false)}
  try{
   var es=(doc.defaultView||window).performance.getEntriesByType('resource');
   for(var r=0;r<es.length;r++){
    var it=es[r].initiatorType;
    /* <video>/<audio> 가 직접 불러온 요청은 확장자가 없어도 영상이다 */
    if((it==='video'||it==='audio')&&!SRE.test(es[r].name)&&/^https?:/i.test(es[r].name)) add(es[r].name,0,false);
    else if(RE.test(es[r].name)) add(es[r].name,0,false);
    else if(SRE.test(es[r].name)&&subs.length<8&&!sseen[es[r].name]&&/^https?:/i.test(es[r].name)){sseen[es[r].name]=1;subs.push({u:es[r].name,l:'',g:''})}
   }
  }catch(e){}
 });
 out.sort(function(a,b){return (b.p?1:0)-(a.p?1:0)});
 return JSON.stringify({title:document.title,items:out,subs:subs,blobs:blobs});
})();
"""

    /** 내장 플레이어가 못 여는 영상을 페이지에서 재생 중인 그대로 창 가득 보여 준다 / 되돌린다 (모든 프레임에 전달) */
    const val MIRROR_ON = "window.postMessage({__ev:'mirror',on:1},'*');"
    const val MIRROR_OFF = "window.postMessage({__ev:'mirror',on:0},'*');"

    /** 앱이 컨트롤 막대를 직접 덧씌우는 미러링: 페이지 영상의 기본 조작은 끈다 */
    const val MIRROR_ON_OWN = "window.postMessage({__ev:'mirror',on:1,ui:1},'*');"

    /** 덧씌운 컨트롤 막대의 조작을 미러링 중인 영상에 보낸다 (a: toggle / seek / skip / rate / fit / sub = 자막 트랙 번호, -1 은 끔) */
    fun mirrorCmd(a: String, v: Double = 0.0): String =
        "window.postMessage({__ev:'mcmd',a:'$a',v:$v},'*');"

    const val PAUSE_ALL = "window.postMessage({__ev:'pause'},'*');"

    /** 탭의 음소거 상태가 바뀌었음을 모든 프레임에 알린다 (각 프레임이 EvMedia.muted() 를 다시 읽는다) */
    const val MUTE_SYNC = "window.postMessage({__ev:'mute'},'*');"

    /** 작은 창(PiP)에서 재생 중인 동영상만 화면 가득 보이게 한다. */
    const val PIP_ON = """
(function(){
 var vs=[].slice.call(document.querySelectorAll('video'));
 if(!vs.length) return '';
 var v=null;
 /* '영상 아래 PiP 버튼'으로 방금 고른 영상이 있으면 그것을 먼저 */
 for(var k=0;k<vs.length;k++){if(vs[k].__evPrefAt&&Date.now()-vs[k].__evPrefAt<8000){v=vs[k];break}}
 if(!v)for(var i=0;i<vs.length;i++){if(!vs[i].paused&&!vs[i].ended){v=vs[i];break}}
 if(!v){vs.sort(function(a,b){return b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight});v=vs[0]}
 var st=document.getElementById('__ev_pip_style');
 if(!st){st=document.createElement('style');st.id='__ev_pip_style';document.documentElement.appendChild(st)}
 st.textContent='html,body{overflow:hidden!important;background:#000!important}'
  +'body *{visibility:hidden!important}'
  +'video.__ev_pip{visibility:visible!important;position:fixed!important;top:0!important;left:0!important;'
  +'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;'
  +'z-index:2147483647!important;background:#000!important;object-fit:contain!important;transform:none!important}';
 v.classList.add('__ev_pip');
 return 'ok';
})();
"""

    const val PIP_OFF = """
(function(){
 var st=document.getElementById('__ev_pip_style'); if(st) st.remove();
 var m=document.querySelectorAll('video.__ev_pip');
 for(var i=0;i<m.length;i++) m[i].classList.remove('__ev_pip');
})();
"""

    /**
     * 당겨서 새로고침 오작동 방지용. 모든 프레임에서 문서 시작 시점에 실행된다.
     * 페이지 안의 '안쪽 스크롤 영역'(채팅/피드 등 body 가 아닌 요소가 스크롤되는 사이트)은
     * WebView 의 scrollY 가 늘 0 이라서 앱이 맨 위로 착각한다. 그래서 손가락이 닿은 자리의 조상 중
     * 이미 스크롤된(scrollTop>0) 요소가 있거나, 터치 중 안쪽 요소가 스크롤되거나,
     * 페이지가 touchmove 를 직접 처리(preventDefault)하면 EvMedia.pullInner(true) 로 알린다.
     */
    const val PULL_GUARD = """
(function(){
 if(window.__evPull) return; window.__evPull=1;
 var touching=false, sent=false;
 function send(v){ if(sent===v) return; sent=v; try{EvMedia.pullInner(v)}catch(e){} }
 function scrolledAncestor(t){
  try{
   var e=t;
   while(e){
    if(e.nodeType===1 && e.scrollTop>0){
     var o=getComputedStyle(e).overflowY;
     if(o==='auto'||o==='scroll'||o==='overlay'||e===document.scrollingElement||e===document.body||e===document.documentElement) return true;
    }
    e=e.parentNode||e.host||null;
   }
  }catch(x){}
  return false;
 }
 window.addEventListener('touchstart',function(e){
  touching=true; sent=null;
  var t=(e.composedPath&&e.composedPath()[0])||e.target;
  send(scrolledAncestor(t));
 },{capture:true,passive:true});
 function end(){touching=false}
 window.addEventListener('touchend',end,{capture:true,passive:true});
 window.addEventListener('touchcancel',end,{capture:true,passive:true});
 window.addEventListener('scroll',function(e){
  if(!touching) return;
  var t=e.target;
  if(t && t!==document && t.scrollTop>0) send(true);
 },true);
 window.addEventListener('touchmove',function(e){
  if(touching && e.defaultPrevented) send(true);
 },{passive:true});
})();
"""
}
