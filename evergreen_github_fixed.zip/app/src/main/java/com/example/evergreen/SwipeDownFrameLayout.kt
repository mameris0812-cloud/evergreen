package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * 전체화면 동영상용 컨테이너: 아래로 끌어내리면 화면이 손가락을 따라 내려오며 흐려지고,
 * 충분히 내리고 놓으면 [onSwipeDown] 을 부른다(전체화면 해제). 모자라면 제자리로 돌아간다.
 * 탭·가로 드래그(재생바) 등 다른 터치는 자식에게 그대로 간다.
 */
class SwipeDownFrameLayout @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    var onSwipeDown: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val trigger = 110f * d
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var multi = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y
                dragging = false; multi = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> multi = true // 두 손가락(확대 등)은 건드리지 않는다
            MotionEvent.ACTION_MOVE -> if (!multi && !dragging) {
                val dx = ev.x - downX
                val dy = ev.y - downY
                // 아래로, 가로보다 뚜렷하게 세로로 움직일 때만 가져온다
                if (dy > slop * 2 && dy > abs(dx) * 1.5f) {
                    dragging = true
                    return true
                }
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!dragging) return super.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val dy = (ev.y - downY).coerceAtLeast(0f)
                translationY = dy
                alpha = (1f - dy / (trigger * 3f)).coerceIn(0.4f, 1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val fire = ev.actionMasked == MotionEvent.ACTION_UP && translationY > trigger
                dragging = false
                if (fire) {
                    onSwipeDown?.invoke()
                    // 숨겨진 뒤 다음에 다시 쓸 수 있게 원래 상태로
                    post { translationY = 0f; alpha = 1f }
                } else {
                    animate().translationY(0f).alpha(1f).setDuration(180).start()
                }
            }
        }
        return true
    }
}
