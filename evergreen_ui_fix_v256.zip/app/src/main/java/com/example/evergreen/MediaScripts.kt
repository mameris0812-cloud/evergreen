package com.example.evergreen

/** 페이지 안에서 돌아가는 스크립트 모음 (재생 상태 알림 / 일시정지 / PiP 용 화면 꾸미기) */
object MediaScripts {

    /**
     * 모든 프레임에서 문서 시작 시점에 실행된다.
     * - 영상/소리 재생 상태가 바뀌면 EvMedia.state() 로 앱에 알린다.
     * - 백그라운드 재생이 켜져 있으면 페이지가 "숨겨짐"을 감지해 스스로 멈추지 못하게 가시성 API 를 가린다.
     * - postMessage({__ev:'pause'}) 를 받으면 (iframe 포함) 재생 중인 미디어를 멈춘다.
     * - 탭 음소거: EvMedia.muted() 가 true 인 동안 모든 video/audio 와 WebAudio 출력을 끈다.
     *   postMessage({__ev:'mute'}) 를 받으면 (iframe 포함) 상태를 다시 읽어 적용한다.
     */
    const val INJECT = """
(function(){
 if(window.__evMedia) return; window.__evMedia=1;
 var fid=Math.random().toString(36).slice(2);
 function bg(){try{return EvMedia.bg()}catch(e){return false}}
 try{
  var dh=Object.getOwnPropertyDescriptor(Document.prototype,'hidden');
  var dv=Object.getOwnPropertyDescriptor(Document.prototype,'visibilityState');
  Object.defineProperty(document,'hidden',{configurable:true,get:function(){return bg()?false:dh.get.call(document)}});
  Object.defineProperty(document,'visibilityState',{configurable:true,get:function(){return bg()?'visible':dv.get.call(document)}});
  var stop=function(e){if(bg())e.stopImmediatePropagation()};
  window.addEventListener('visibilitychange',stop,true);
  document.addEventListener('visibilitychange',stop,true);
 }catch(e){}

 /* ── 문서에 붙어 있지 않은 미디어도 잡는다 ──
    스포티파이 같은 사이트는 new Audio() / createElement('video') 로 만든 요소를 문서에 붙이지 않고 재생한다.
    그러면 querySelectorAll 로는 안 보여서 재생 중인 걸 모르고, 백그라운드 유지도 알림도 안 켜져 곧 소리가 끊긴다.
    그래서 play() 가 불리는 순간 그 요소를 직접 기억해 두고 함께 살핀다. ── */
 var reg=[];
 function onEl(e){
  var t=e&&e.target;
  if(t&&(e.type=='play'||e.type=='playing'))act=t;
  setTimeout(function(){try{chk()}catch(e1){} try{prog()}catch(e2){}},60);
 }
 function track(x){
  if(!x||x.__evT)return; x.__evT=1; reg.push(x);
  ['play','playing','pause','ended','emptied','loadeddata','seeked'].forEach(function(n){x.addEventListener(n,onEl,true)});
  if(reg.length>30){
   for(var i=0;i<reg.length;i++){var y=reg[i]; if(!y.isConnected&&(y.paused||y.ended)){reg.splice(i,1);break}}
  }
 }
 function all(){
  var m=[].slice.call(document.querySelectorAll('video,audio'));
  for(var i=0;i<reg.length;i++){if(m.indexOf(reg[i])<0)m.push(reg[i])}
  return m;
 }
 try{
  var MP=window.HTMLMediaElement&&HTMLMediaElement.prototype,op=MP&&MP.play;
  if(op){MP.play=function(){try{track(this);if(!this.isConnected)act=this}catch(e){} return op.apply(this,arguments)}}
 }catch(e){}
 try{
  var hf=Document.prototype.hasFocus;
  document.hasFocus=function(){return bg()?true:hf.call(document)};
 }catch(e){}

 /* ── 탭 음소거: 이 탭이 음소거면 video/audio 를 muted 로, WebAudio 는 게인 0 으로 만든다 ── */
 var muteOn=false,gains=[];
 function mu(){try{return !!EvMedia.muted()}catch(e){return false}}
 function applyMute(){
  var m=all();
  for(var i=0;i<m.length;i++){var x=m[i];
   try{
    if(muteOn){ if(!x.__evM){x.__evM=1;x.__evWas=x.muted} if(!x.muted)x.muted=true }
    else if(x.__evM){x.__evM=0;x.muted=!!x.__evWas}
   }catch(e){}
  }
  for(var g=0;g<gains.length;g++){try{gains[g].gain.value=muteOn?0:1}catch(e){}}
 }
 function syncMute(){var n=mu(); if(n!==muteOn){muteOn=n} applyMute()}
 try{
  var AN=window.AudioNode&&AudioNode.prototype,oc=AN&&AN.connect,od=AN&&AN.disconnect;
  if(oc){
   AN.connect=function(d){
    var a=arguments;
    if(window.AudioDestinationNode&&d instanceof AudioDestinationNode){
     var c=this.context;
     if(!c.__evG){var gn=c.createGain();oc.call(gn,c.destination);gn.gain.value=muteOn?0:1;c.__evG=gn;gains.push(gn)}
     a=[].slice.call(arguments);a[0]=c.__evG;
     oc.apply(this,a);return d;
    }
    return oc.apply(this,a);
   };
   AN.disconnect=function(d){
    var a=arguments;
    if(window.AudioDestinationNode&&d instanceof AudioDestinationNode&&d.context.__evG){
     a=[].slice.call(arguments);a[0]=d.context.__evG;
    }
    return od.apply(this,a);
   };
  }
 }catch(e){}
 muteOn=mu();
 ['play','playing','loadeddata','volumechange'].forEach(function(n){
  document.addEventListener(n,function(){if(muteOn)applyMute()},true);
 });
 setInterval(function(){if(muteOn)applyMute()},1200);
 /* ── fetch / XHR 응답의 종류(Content-Type)가 스트리밍 목록(HLS·DASH·스무스)이면 그 주소를 앱에 알린다 ──
    주소에 .m3u8 / .mpd 가 없는 영상(예: /api/stream?id=3)도 내장 플레이어·저장 후보에 오른다.
    조각(ts / m4s)은 같은 종류로 보내는 경우가 많아 일부러 목록 형식만 잡는다. 응답 내용은 읽지 않는다. */
 var MRE=/^(application[/](vnd[.]apple[.]mpegurl|x-mpegurl|dash[+]xml|vnd[.]ms-sstr[+]xml)|audio[/](x-)?mpegurl)/i,mseen={};
 function mrep(u,ct){
  try{
   if(!u||!ct||!MRE.test(ct))return;
   u=new URL(u,location.href).href;
   if(!/^https?:/i.test(u)||mseen[u])return; mseen[u]=1; EvMedia.src(u);
  }catch(e){}
 }
 try{
  var ofe=window.fetch;
  if(ofe){window.fetch=function(){
   var pr=ofe.apply(this,arguments);
   try{pr.then(function(r){try{mrep(r.url,r.headers.get('content-type'))}catch(e1){}},function(){})}catch(e2){}
   return pr;
  }}
 }catch(e){}
 try{
  var XP=window.XMLHttpRequest&&XMLHttpRequest.prototype,xop=XP&&XP.open;
  if(xop){XP.open=function(m,u){
   try{var xr=this;xr.addEventListener('readystatechange',function(){
    if(xr.readyState===2){try{mrep(xr.responseURL||u,xr.getResponseHeader('content-type'))}catch(e3){}}
   })}catch(e4){}
   return xop.apply(this,arguments);
  }}
 }catch(e){}
 /* ── 재생이 시작된 영상 주소를 앱에 알린다 ──
    다른 도메인의 iframe 안에 있는 영상은 주 프레임이 들여다볼 수 없다. 그 iframe 안에서도 이 스크립트가 돌고 있으니
    영상 주소(http/https 만, blob 제외)를 직접 보내서 내장 플레이어 후보에 오르게 한다. */
 function rep(x){
  try{
   var u=x.currentSrc||x.src;
   if(u&&/^https?:/i.test(u)&&u!==x.__evU){x.__evU=u;EvMedia.src(u)}
  }catch(e){}
 }
 ['loadstart','loadedmetadata','playing'].forEach(function(n){
  document.addEventListener(n,function(e){
   var t=e.target; if(t&&(t.tagName=='VIDEO'||t.tagName=='AUDIO'))rep(t);
  },true);
 });
 /* ── 화면에 크게 보이는 영상은 재생 전에도 미리 받아 둔다 ──
    모바일 브라우저는 preload 가 metadata/none 이면 조금만 받고 멈춘다('suspend'). 그러면 재생을 누른 뒤에야
    받기 시작해서 첫 화면이 늦다. 지금 화면에 크게 보이는 영상만 골라 preload=auto 로 바꿔 계속 받게 한다.
    (피드의 작은 영상이나 화면 밖 영상은 건드리지 않아 데이터를 아낀다) */
 document.addEventListener('suspend',function(e){
  var x=e.target;
  try{
   if(!x||x.tagName!=='VIDEO'||x.preload==='auto')return;
   var r=x.getBoundingClientRect(),vw=window.innerWidth,vh=window.innerHeight;
   if(r.width<vw*0.5||r.height<80||r.bottom<0||r.top>vh)return;
   x.preload='auto';
  }catch(err){}
 },true);
 var last='';
 function chk(){
  var m=all(),p=false,v=false,w=0,h=0;
  for(var i=0;i<m.length;i++){var x=m[i];
   if(!x.paused&&!x.ended&&x.readyState>2){p=true;
    if(x.tagName=='VIDEO'&&x.videoWidth>0&&!v){v=true;w=x.videoWidth;h=x.videoHeight}}}
  var k=p+','+v+','+w+','+h;
  if(k===last)return; last=k;
  try{EvMedia.state(fid,p,v,w,h)}catch(e){}
 }
 ['play','playing','pause','ended','emptied','loadeddata'].forEach(function(n){
  document.addEventListener(n,function(){setTimeout(chk,60)},true);
 });
 setInterval(function(){if(reg.length||document.querySelector('video,audio'))chk()},2500);
 /* ── 메뉴의 미디어 플레이어용: 진행 상황 보고 / 조작 명령 받기 ── */
 var act=null;
 function pick(){
  var m=all();
  for(var i=0;i<m.length;i++){var x=m[i]; if(!x.paused&&!x.ended&&x.readyState>2)return x}
  return (act&&(document.contains(act)||reg.indexOf(act)>=0))?act:null;
 }
 /* 곡·영상이 바뀌면 페이지가 알려 주는 제목/아티스트(mediaSession)를 앱에 전한다. 바뀐 때만 보낸다.
    (사이트 탭 제목은 곡이 바뀌어도 그대로인 곳이 많아서 메뉴 카드가 옛날 정보에 머물렀다) */
 var lastMeta='';
 /* 시스템 미디어 플레이어에 쓸 그림 주소: 페이지가 알려 준 mediaSession 그림(가장 큰 것) → 영상 poster → og:image 순서 */
 function artUrl(x){
  try{
   var md=navigator.mediaSession&&navigator.mediaSession.metadata;
   var aw=md&&md.artwork, best='', bs=-1;
   if(aw){
    for(var i=0;i<aw.length;i++){
     var s=aw[i]&&aw[i].src; if(!s)continue;
     var m=/(\d+)x(\d+)/.exec(aw[i].sizes||''); var sz=m?parseInt(m[1],10):0;
     if(sz>bs){bs=sz;best=s}
    }
   }
   if(!best&&x&&x.poster)best=x.poster;
   if(!best){var o=document.querySelector('meta[property="og:image"],meta[name="twitter:image"]'); if(o)best=o.content||''}
   if(!best)return '';
   var u=new URL(best,location.href).href;
   return /^https?:/i.test(u)?u:'';
  }catch(e){return ''}
 }
 function meta(){
  try{
   var md=navigator.mediaSession&&navigator.mediaSession.metadata;
   var t=md&&md.title?String(md.title):'', a=md&&md.artist?String(md.artist):'';
   var im=artUrl(pick());
   var k=t+'\u0001'+a+'\u0001'+im;
   if(k===lastMeta)return; lastMeta=k;
   EvMedia.meta(fid,t,a,im);
  }catch(e){}
 }
 function prog(){
  var x=pick(); if(!x)return;
  var d=x.duration;
  try{EvMedia.progress(fid,x.currentTime||0,(isFinite(d)&&d>0)?d:-1,!x.paused&&!x.ended)}catch(e){}
  meta();
 }
 ['play','playing'].forEach(function(n){
  document.addEventListener(n,function(e){
   var t=e.target; if(t&&(t.tagName=='VIDEO'||t.tagName=='AUDIO')){act=t;setTimeout(prog,60)}
  },true);
 });
 ['pause','ended','seeked','loadedmetadata','durationchange','loadeddata','emptied'].forEach(function(n){
  document.addEventListener(n,function(){setTimeout(prog,60)},true);
 });
 setInterval(function(){var x=pick(); if(!x)return; if(!x.paused&&!x.ended)prog(); else meta()},1000);
 /* ── 메뉴 미디어 플레이어의 파형: 켜져 있는 동안만 소리 크기를 막대 값으로 보고한다.
    captureStream 으로 복사본만 분석하므로 실제 소리 출력에는 손대지 않는다.
    다른 사이트의 보호된 미디어는 무음으로 읽혀서, 그러면 'x' 를 보내 앱이 대체 움직임을 쓰게 한다 ── */
 var WN=28,wc=null,wan=null,wsrc=null,wsrcEl=null,wtimer=0,wbuf=null,wzero=0;
 function waveStop(){
  if(wtimer){clearInterval(wtimer);wtimer=0}
  try{if(wc&&wc.state==='running')wc.suspend()}catch(e){}
  try{EvMedia.wave(fid,'')}catch(e){}
 }
 function waveSetup(x){
  try{
   if(!wc){
    var AC=window.AudioContext||window.webkitAudioContext; if(!AC)return false;
    wc=new AC(); wan=wc.createAnalyser(); wan.fftSize=256; wan.smoothingTimeConstant=0.55;
    wbuf=new Uint8Array(wan.frequencyBinCount);
   }
   if(wc.state==='suspended'){var r=wc.resume(); if(r&&r.catch)r.catch(function(){})}
   if(wsrcEl!==x){
    var cs=x.captureStream?x.captureStream():(x.mozCaptureStream?x.mozCaptureStream():null);
    if(!cs||!cs.getAudioTracks().length)return false;
    if(wsrc){try{wsrc.disconnect()}catch(e){}}
    wsrc=wc.createMediaStreamSource(cs); wsrc.connect(wan); wsrcEl=x;
   }
   return true;
  }catch(e){return false}
 }
 function waveTick(){
  var x=pick();
  if(!x||x.paused||x.ended){try{EvMedia.wave(fid,'')}catch(e){}return}
  if(!waveSetup(x)){try{EvMedia.wave(fid,'x')}catch(e){}return}
  wan.getByteFrequencyData(wbuf);
  var sum=0,vals=[];
  for(var i=0;i<WN;i++){
   var lo=Math.floor(Math.pow(i/WN,1.7)*100)+1,hi=Math.max(lo+1,Math.floor(Math.pow((i+1)/WN,1.7)*100)+1);
   var s=0,c=0; for(var b=lo;b<hi&&b<wbuf.length;b++){s+=wbuf[b];c++}
   var v=c?s/c:0; sum+=v; vals.push(Math.min(99,Math.round(v/255*99)));
  }
  if(sum<1)wzero++; else wzero=0;
  try{EvMedia.wave(fid,wzero>25?'x':vals.join(','))}catch(e){}
 }
 window.addEventListener('pagehide',function(){last='';try{EvMedia.state(fid,false,false,0,0);EvMedia.gone(fid)}catch(e){}});
 window.addEventListener('message',function(e){
  var d=e.data; if(!d)return;
  if(d.__ev==='cmd'){
   if(d.f===fid){
    if(d.a==='wave'){ if(d.v===1){if(!wtimer)wtimer=setInterval(waveTick,90)} else waveStop() }
    var x=(d.a==='wave')?null:pick();
    if(x){
     try{
      if(d.a==='toggle'){ if(x.paused||x.ended){var pr=x.play(); if(pr&&pr.catch)pr.catch(function(){})} else x.pause() }
      else if(d.a==='seek'){ x.currentTime=Math.max(0,d.v) }
      else if(d.a==='skip'){ x.currentTime=Math.max(0,(x.currentTime||0)+d.v) }
      else if(d.a==='next'){
       /* 재생 목록의 '다음' 버튼이 있으면 누르고, 없으면 끝으로 보내 사이트가 다음 영상을 이어 틀게 한다 */
       var nb=null;
       try{nb=document.querySelector('.ytp-next-button,.next-button,[data-testid="control-button-skip-forward"],[aria-label="Next" i],[aria-label="Next track" i],[aria-label="다음" i],[aria-label="다음 곡" i]')}catch(e2){}
       var nbOk=nb&&nb.offsetParent!==null&&!nb.disabled&&nb.getAttribute('aria-disabled')!=='true';
       if(nbOk){ nb.click() } else if(isFinite(x.duration)&&x.duration>0){ x.currentTime=Math.max(0,x.duration-0.05) }
      }
      else if(d.a==='prev'){
       /* 재생 목록의 '이전' 버튼이 있으면 그걸 누르고(처음 3초 안일 때), 없거나 3초 이상 봤으면 처음부터 다시 */
       var pb=null;
       try{pb=document.querySelector('.ytp-prev-button,.previous-button,[data-testid="control-button-skip-back"],[aria-label="Previous" i],[aria-label="Previous track" i],[aria-label="이전" i],[aria-label="이전 곡" i]')}catch(e1){}
       var pbOk=pb&&pb.offsetParent!==null&&!pb.disabled&&pb.getAttribute('aria-disabled')!=='true';
       if(pbOk&&(x.currentTime||0)<3){ pb.click() } else { x.currentTime=0 }
      }
     }catch(err){}
     setTimeout(prog,120);
    }
   }
   var f3=document.querySelectorAll('iframe');
   for(var q=0;q<f3.length;q++){try{f3[q].contentWindow.postMessage(d,'*')}catch(x2){}}
   return;
  }
  if(d.__ev==='mute'){
   syncMute();
   var f2=document.querySelectorAll('iframe');
   for(var k=0;k<f2.length;k++){try{f2[k].contentWindow.postMessage(d,'*')}catch(x){}}
   return;
  }
  if(d.__ev!=='pause')return;
  var m=all();
  for(var i=0;i<m.length;i++){try{m[i].pause()}catch(x){}}
  var f=document.querySelectorAll('iframe');
  for(var j=0;j<f.length;j++){try{f[j].contentWindow.postMessage(d,'*')}catch(x){}}
 },false);

 /* ── 영상 아래에 '내장 플레이어로 열기' / 'PiP로 보기' 버튼 ──
    페이지에서 크게 보이는 영상(재생 중인 것 우선) 바로 아래 오른쪽에 띄운다. 아래에 자리가 없으면 영상 안쪽 위 오른쪽에 띄운다.
    영상이 전체화면이거나 PiP(작은 창) 중이면 숨긴다. 모든 프레임에서 돌므로 iframe 안의 영상에도 뜬다. */
 (function(){
  try{
   var b1El=null,host=null,wrap=null,cur=null,raf=0,shown=false,hideT=0,bw=250,bh=34,mode='below',lastPick=0,lastEvt=0,relBase=false,lastT='',ro=null;
   function pipOn(){return !!document.getElementById('__ev_pip_style')}
   /* 설정에서 버튼을 껐는지: 매 프레임 묻지 않게 0.4초 동안 기억한다 */
   var btnAt=0,btnV=true;
   var ytAt=0,ytV=false;
   function btnOn(){var n=Date.now();if(n-btnAt>400){btnAt=n;try{btnV=!!EvMedia.buttons()}catch(x){btnV=true}}return btnV}
   /* 유튜브 페이지에서는 설정에서 허용했을 때만 '내장 플레이어로 열기' 버튼을 보인다 */
   var isYt=false;try{isYt=location.hostname.indexOf('youtu')>=0}catch(x){}
   function b1Ok(){if(!isYt)return true;var n=Date.now();if(n-ytAt>400){ytAt=n;try{ytV=!!EvMedia.ytInternal()}catch(x){ytV=false}}return ytV}
   function fsOn(){return !!(document.fullscreenElement||document.webkitFullscreenElement)}
   function pickVideo(){
    var vs=document.querySelectorAll('video'),best=null,bs=0,H=window.innerHeight,W=window.innerWidth;
    for(var i=0;i<vs.length;i++){
     var v=vs[i],r=v.getBoundingClientRect();
     if(r.width<200||r.height<110)continue;
     var cs=getComputedStyle(v);
     if(cs.visibility==='hidden'||cs.display==='none'||+cs.opacity===0)continue;
     var vw=Math.min(r.right,W)-Math.max(r.left,0),vh=Math.min(r.bottom,H)-Math.max(r.top,0);
     if(vw<r.width*0.3||vh<r.height*0.3)continue;
     var s=vw*vh*((!v.paused&&!v.ended)?4:1);
     if(s>bs){bs=s;best=v}
    }
    return best;
   }
   function make(){
    host=document.createElement('div');
    host.setAttribute('data-ev-ui','1');
    /* 문서 좌표(absolute)+transform 으로 놓는다: 페이지 스크롤은 브라우저가 알아서 같이 움직여 주니 끊기지 않고,
       위치 갱신은 레이아웃 없이 GPU 가 처리하는 transform 만 쓴다 */
    host.style.cssText='position:absolute;left:0;top:0;z-index:2147483646;display:none;pointer-events:none;margin:0;padding:0;border:0;background:none;width:auto;height:auto;will-change:transform;transform:translate3d(0,0,0)';
    var root=host.attachShadow({mode:'closed'});
    var st=document.createElement('style');
    st.textContent='.w{display:flex;gap:6px;white-space:nowrap;justify-content:flex-end}'
     +'button{all:unset;box-sizing:border-box;font:600 12px/1 sans-serif;color:#fff;background:rgba(20,20,20,.82);border:1px solid rgba(255,255,255,.28);border-radius:16px;padding:9px 13px;cursor:pointer;-webkit-tap-highlight-color:transparent;'
     +'opacity:0;transform:translateY(10px) scale(.88);transform-origin:100% 100%;will-change:transform,opacity;'
     +'transition:opacity .12s ease,transform .14s ease,background-color .15s ease}'
     +'.w.up button{transform:translateY(-10px) scale(.88);transform-origin:100% 0}'
     +'.w.in button{opacity:1;transform:none;transition:opacity .2s ease,transform .32s cubic-bezier(.2,.9,.25,1.12),background-color .15s ease}'
     +'.w.in button:nth-child(2){transition-delay:.05s,.05s,0s}'
     +'.w.in button:active{transform:scale(.93);background:rgba(70,70,70,.96);transition-delay:0s;transition-duration:.08s}';
    var w=document.createElement('div');w.className='w';wrap=w;
    var b1=document.createElement('button');b1.textContent='\u25B6 내장 플레이어로 열기';b1El=b1;
    var b2=document.createElement('button');b2.textContent='PiP로 보기';
    function eat(e){e.stopPropagation()}
    ['touchstart','touchend','mousedown','mouseup','pointerdown','pointerup','dblclick'].forEach(function(n){host.addEventListener(n,eat)});
    b1.addEventListener('click',function(e){
     e.stopPropagation();e.preventDefault();
     var v=cur,u='';
     try{u=v?(v.currentSrc||v.src||''):''}catch(x){}
     if(!/^https?:/i.test(u)){
      try{
       var h=location.href;
       if(location.hostname.indexOf('youtu')>=0&&(h.indexOf('/watch')>0||h.indexOf('/shorts/')>0||h.indexOf('/embed/')>0||h.indexOf('/live/')>0))u=h;
      }catch(x){}
     }
     try{EvMedia.openPlayer(/^https?:/i.test(u)?u:'',v?(v.currentTime||0):0)}catch(x){}
    });
    b2.addEventListener('click',function(e){
     e.stopPropagation();e.preventDefault();
     var v=cur; if(!v)return;
     try{v.__evPrefAt=Date.now()}catch(x){}
     function go(){try{EvMedia.pip()}catch(x){}}
     if(v.paused||v.ended){
      try{var p=v.play();if(p&&p.catch)p.catch(function(){})}catch(x){}
      setTimeout(go,450);
     }else go();
    });
    w.appendChild(b1);w.appendChild(b2);root.appendChild(st);root.appendChild(w);
    document.documentElement.appendChild(host);
   }
   /* 부드럽게 나타나고(아래에서 살짝 떠오르며 커짐) 사라진다(작아지며 흐려짐) */
   function setShown(on){
    if(on){
     if(hideT){clearTimeout(hideT);hideT=0}
     if(!shown){
      shown=true;
      host.style.display='block';host.style.pointerEvents='auto';
      bw=host.offsetWidth||bw;bh=host.offsetHeight||bh;
      void wrap.offsetWidth;
      requestAnimationFrame(function(){if(shown)wrap.classList.add('in')});
     }
    }else if(shown){
     shown=false;
     wrap.classList.remove('in');host.style.pointerEvents='none';
     hideT=setTimeout(function(){hideT=0;if(!shown)host.style.display='none'},260);
    }
   }
   function watch(v){
    try{
     if(!window.ResizeObserver)return;
     if(!ro)ro=new ResizeObserver(function(){sched(1)});
     ro.disconnect();if(v)ro.observe(v);
    }catch(x){}
   }
   function place(){
    if(!document.documentElement)return;
    if(fsOn()||pipOn()||!btnOn()){cur=null;if(host)setShown(false);return}
    var now=Date.now(),fresh=false,v=cur,r=null;
    if(v&&v.isConnected&&now-lastPick<=250){
     r=v.getBoundingClientRect();
     if(r.width<200||r.height<110)r=null;
    }
    if(!r){
     v=pickVideo();lastPick=now;fresh=true;
     if(v!==cur){cur=v;watch(v)}
     if(!v){if(host)setShown(false);return}
     r=v.getBoundingClientRect();
    }
    if(!host)make();
    if(!host.isConnected)document.documentElement.appendChild(host);
    var okB1=b1Ok();
    if(b1El&&(b1El.style.display!=='none')!==okB1){b1El.style.display=okB1?'':'none';bw=host.offsetWidth||bw}
    if(fresh||!shown){
     try{relBase=getComputedStyle(document.documentElement).position!=='static'}catch(x){relBase=false}
     if(!shown){host.style.display='block'}
     bw=host.offsetWidth||bw;bh=host.offsetHeight||bh;
    }
    var H=window.innerHeight,W=window.innerWidth;
    /* 아래 자리가 있으면 영상 아래, 없으면 영상 안쪽 위. 경계에서 깜빡이지 않게 여유(히스테리시스)를 둔다 */
    var need=bh+(mode==='below'?6:20);
    var nm=(r.bottom+need<=H)?'below':'in';
    if(nm!==mode){mode=nm;wrap.classList.toggle('up',mode==='in')}
    else if(!shown)wrap.classList.toggle('up',mode==='in');
    var edge=Math.min(r.right,W)-(mode==='below'?4:8);
    var x=Math.max(edge-bw,4);
    var y=(mode==='below')?(r.bottom+6):(Math.max(r.top,0)+8);
    var ox,oy;
    if(relBase){var hr=document.documentElement.getBoundingClientRect();ox=-hr.left;oy=-hr.top}
    else{ox=window.pageXOffset||0;oy=window.pageYOffset||0}
    var t='translate3d('+Math.round(x+ox)+'px,'+Math.round(y+oy)+'px,0)';
    if(t!==lastT){lastT=t;host.style.transform=t}
    setShown(true);
   }
   function tick(){
    raf=0;
    place();
    /* 스크롤/터치 중(그리고 직후 관성 스크롤 동안)에는 매 프레임 따라간다 */
    if(Date.now()-lastEvt<350)raf=requestAnimationFrame(tick);
   }
   function sched(loop){
    if(loop)lastEvt=Date.now();
    if(!raf)raf=requestAnimationFrame(tick);
   }
   function onMove(){sched(1)}
   window.addEventListener('scroll',onMove,{capture:true,passive:true});
   window.addEventListener('touchmove',onMove,{capture:true,passive:true});
   window.addEventListener('touchend',onMove,{capture:true,passive:true});
   window.addEventListener('resize',onMove);
   window.addEventListener('orientationchange',onMove);
   ['fullscreenchange','webkitfullscreenchange','play','pause','loadedmetadata'].forEach(function(n){document.addEventListener(n,onMove,true)});
   setInterval(function(){if(document.querySelector('video')||host)sched(0)},500);
  }catch(e){}
 })();

 /* ── 유튜브: 영상을 틀 때마다 자막이 저절로 켜지는 것을 막는다 ──
    유튜브는 한 번 켠 자막(또는 계정의 '항상 자막 표시')을 기억해서 다음 영상마다 자동으로 켠다.
    새 영상이 시작된 직후에만 켜져 있는 자막을 한 번 꺼 주고, 그 뒤에 사용자가 직접 켜는 것은 건드리지 않는다. ── */
 (function(){
  try{
   if(!/(^|\.)youtube(-nocookie)?\.com${'$'}/.test(location.hostname)) return;
   var ccKey='',ccTouched=false,ccDone=false,ccSelf=false,ccTries=0,ccTimer=0;
   var CCSEL='.ytp-subtitles-button,.ytmClosedCaptioningButtonButton';
   function ccPlayer(){return document.getElementById('movie_player')||document.querySelector('.html5-video-player')}
   function ccStop(){if(ccTimer){clearInterval(ccTimer);ccTimer=0}}
   function ccOff(){
    var p=ccPlayer();
    try{ if(p&&p.isSubtitlesOn&&p.isSubtitlesOn()&&p.toggleSubtitles){ p.toggleSubtitles(); return true } }catch(e){}
    var b=document.querySelector(CCSEL);
    if(b&&b.getAttribute('aria-pressed')==='true'){ ccSelf=true; try{b.click()}catch(e){} ccSelf=false; return true }
    return false;
   }
   function ccRun(){
    if(ccTouched||ccDone){ccStop();return}
    if(!ccPlayer()){ if(++ccTries>24)ccStop(); return }
    if(document.querySelector('.ad-showing')) return;      // 광고 중엔 기다린다
    if(ccOff()) ccDone=true;
    if(++ccTries>14)ccStop();                                // 켜져 있지 않았으면 몇 초 지켜보다 그만둔다
   }
   function ccStart(){
    ccStop(); ccDone=false; ccTouched=false; ccTries=0;
    ccTimer=setInterval(ccRun,500);
   }
   function ccKeyNow(){var m=location.search.match(/[?&]v=([^&]+)/);return m?m[1]:location.pathname}
   ['loadeddata','playing'].forEach(function(n){
    document.addEventListener(n,function(e){
     if(!e.target||e.target.tagName!=='VIDEO')return;
     var k=ccKeyNow(); if(k===ccKey)return; ccKey=k; ccStart();
    },true);
   });
   // 사용자가 직접 자막 버튼·메뉴를 누르거나 C 키를 누르면 더는 끄지 않는다
   document.addEventListener('click',function(e){
    if(ccSelf||!e.isTrusted)return;
    var t=e.target; if(t&&t.closest&&t.closest(CCSEL+',.ytp-popup,.ytp-settings-menu')) ccTouched=true;
   },true);
   document.addEventListener('keydown',function(e){
    if(e.isTrusted&&(e.key==='c'||e.key==='C')) ccTouched=true;
   },true);
  }catch(e){}
 })();
})();
"""

    /**
     * 내장 플레이어로 넘길 영상 주소를 찾는다 (blob/data 는 제외). 재생 중인 것이 앞에 온다.
     * video/audio/source 태그뿐 아니라 같은 출처 iframe 안, data-src 같은 지연 로딩 속성, og:video 메타,
     * JSON-LD(contentUrl), embed/object, 영상 파일로 연결된 링크, 그리고 페이지가 실제로 불러온 요청 기록(performance)까지 훑는다.
     */
    const val FIND_MEDIA = """
(function(){
 var out=[],seen={},subs=[],sseen={},blobs=[],bseen={};
 var SRE=/\.(vtt|srt|ass|ssa|ttml|dfxp)(\?|#|${'$'})/i;
 var RE=/\.(m3u8|mpd|mp4|webm|m4v|mov|mkv|avi|flv|3gp|3g2|f4v|m2ts|mts|ogv|ogm|wmv|asf|ismv|mpe?g)(\?|#|${'$'})|\.m3u8|\.mpd|\.ism\/manifest/i;
 /* 인라인 스크립트(JSON 설정 포함)에 적힌 영상 주소: https:\/\/ 처럼 슬래시가 이스케이프된 것도 잡는다 */
 var SCRE=/https?:(?:\\?\/){2}(?:\\\/|[^\s"'<>\\])+?\.(?:m3u8|mpd|mp4|webm|m4v|mov|mkv)(?:\?(?:\\\/|\\u0026|[^\s"'<>\\])*)?/gi;
 function scanText(t,addf,max){
  if(!t||typeof t!=='string')return; var m,n=0; SCRE.lastIndex=0;
  while((m=SCRE.exec(t))&&n<max){n++; addf(m[0].replace(/\\\//g,'/').replace(/\\u0026/g,'&'),0,false)}
 }
 function add(u,t,p){
  if(!u||typeof u!=='string'||u.indexOf('data:')==0) return;
  if(u.indexOf('blob:')==0){
   /* blob 주소는 재생용으로는 못 쓰지만, 페이지가 만들어 둔 파일(URL.createObjectURL)이면 저장은 된다 */
   if(!bseen[u]){bseen[u]=1;blobs.push({u:u,t:t||0,p:!!p})}
   return;
  }
  try{u=new URL(u,location.href).href}catch(e){return}
  if(seen[u]) return; seen[u]=1; out.push({u:u,t:t||0,p:!!p});
 }
 /* 같은 출처 iframe 은 여러 겹까지 들어가 본다 (최대 12개 문서) */
 var docs=[document];
 (function collect(doc,depth){
  if(depth>3)return;
  try{
   var fr=doc.querySelectorAll('iframe,frame');
   for(var f=0;f<fr.length&&docs.length<12;f++){
    try{var d=fr[f].contentDocument; if(d&&d.documentElement&&docs.indexOf(d)<0){docs.push(d);collect(d,depth+1)}}catch(e){}
   }
  }catch(e){}
 })(document,0);
 docs.forEach(function(doc){
  var base=doc.location&&doc.location.href||location.href;
  function addd(u,t,p){ if(!u||typeof u!=='string') return; try{u=new URL(u,base).href}catch(e){return} add(u,t,p) }
  var ms=[].slice.call(doc.querySelectorAll('video,audio'));
  /* 열린 shadow DOM 안의 영상 (웹 컴포넌트 플레이어) */
  try{
   var all=doc.querySelectorAll('*');
   for(var sh=0;sh<all.length&&sh<4000;sh++){
    var rt=all[sh].shadowRoot;
    if(rt){var sm=rt.querySelectorAll('video,audio'); for(var sq=0;sq<sm.length;sq++)ms.push(sm[sq])}
   }
  }catch(e){}
  for(var i=0;i<ms.length;i++){
   var m=ms[i],p=!m.paused&&!m.ended;
   addd(m.currentSrc,m.currentTime,p); addd(m.getAttribute('src'),m.currentTime,p);
   ['data-src','data-url','data-video','data-hls','data-mp4','data-stream','data-video-src','data-file','data-source','data-lazy-src'].forEach(function(a){addd(m.getAttribute(a),m.currentTime,p)});
   var ss=m.querySelectorAll('source');
   for(var j=0;j<ss.length;j++){addd(ss[j].src,m.currentTime,p); addd(ss[j].getAttribute('data-src'),m.currentTime,p)}
  }
  var tk=doc.querySelectorAll('video track[src],audio track[src]');
  for(var z=0;z<tk.length&&subs.length<8;z++){
   var tt=tk[z],kd=(tt.kind||'subtitles').toLowerCase();
   if(kd!=='subtitles'&&kd!=='captions')continue;
   try{var su=new URL(tt.getAttribute('src'),base).href;
    if(!sseen[su]&&/^https?:/i.test(su)){sseen[su]=1;subs.push({u:su,l:tt.label||'',g:tt.srclang||''})}}catch(e){}
  }
  var ds=doc.querySelectorAll('source[src],source[data-src],embed[src],object[data]');
  for(var k=0;k<ds.length;k++){var x=ds[k],v=x.getAttribute('src')||x.getAttribute('data-src')||x.getAttribute('data'); if(v&&RE.test(v)) addd(v,0,false)}
  var mt=doc.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
  for(var q=0;q<mt.length;q++){var c=mt[q].getAttribute('content'); if(c&&RE.test(c)) addd(c,0,false)}
  var ld=doc.querySelectorAll('script[type="application/ld+json"]');
  for(var l=0;l<ld.length;l++){
   try{
    (function walk(o){
     if(!o||typeof o!=='object') return;
     if(Array.isArray(o)){o.forEach(walk);return}
     if(typeof o.contentUrl==='string') addd(o.contentUrl,0,false);
     for(var key in o) if(typeof o[key]==='object') walk(o[key]);
    })(JSON.parse(ld[l].textContent));
   }catch(e){}
  }
  /* 재생기 설정이 data-* 속성에 들어 있는 경우 (video.js data-setup 등) / 지연 로딩 속성 / 미리 불러오기 링크 */
  var cf=doc.querySelectorAll('[data-setup],[data-config],[data-options],[data-player],[data-sources]');
  for(var cc=0;cc<cf.length&&cc<60;cc++){
   var cv=cf[cc].getAttribute('data-setup')||cf[cc].getAttribute('data-config')||cf[cc].getAttribute('data-options')||cf[cc].getAttribute('data-player')||cf[cc].getAttribute('data-sources');
   scanText(cv,addd,6);
  }
  var lz=doc.querySelectorAll('[data-video],[data-video-src],[data-video-url],[data-hls],[data-mp4],[data-stream],[data-file],[data-src],[data-url]');
  for(var zz=0;zz<lz.length&&zz<300;zz++){
   ['data-video','data-video-src','data-video-url','data-hls','data-mp4','data-stream','data-file','data-src','data-url'].forEach(function(a){
    var av=lz[zz].getAttribute(a); if(av&&RE.test(av)) addd(av,0,false)
   });
  }
  var lk=doc.querySelectorAll('link[as=video][href],link[rel=preload][href],link[rel=alternate][href]');
  for(var lq=0;lq<lk.length&&lq<40;lq++){var lh=lk[lq].getAttribute('href'); if(lh&&RE.test(lh)) addd(lh,0,false)}
  /* 인라인 스크립트에 적힌 주소 (JW Player / hls.js 설정, 초기 상태 JSON 등) */
  var sc=doc.querySelectorAll('script:not([src])');
  var scn=0;
  for(var sx=0;sx<sc.length&&sx<150&&scn<24;sx++){
   var tx=sc[sx].textContent; if(!tx||tx.length>800000)continue;
   var before=out.length; scanText(tx,addd,8); scn+=out.length-before;
  }
  var as=doc.querySelectorAll('a[href]');
  for(var n=0;n<as.length&&n<400;n++){var h=as[n].getAttribute('href'); if(h&&RE.test(h)) addd(h,0,false)}
  try{
   var es=(doc.defaultView||window).performance.getEntriesByType('resource');
   for(var r=0;r<es.length;r++){
    var it=es[r].initiatorType;
    /* <video>/<audio> 가 직접 불러온 요청은 확장자가 없어도 영상이다 */
    if((it==='video'||it==='audio')&&!SRE.test(es[r].name)&&/^https?:/i.test(es[r].name)) add(es[r].name,0,false);
    else if(RE.test(es[r].name)) add(es[r].name,0,false);
    else if(SRE.test(es[r].name)&&subs.length<8&&!sseen[es[r].name]&&/^https?:/i.test(es[r].name)){sseen[es[r].name]=1;subs.push({u:es[r].name,l:'',g:''})}
   }
  }catch(e){}
 });
 out.sort(function(a,b){return (b.p?1:0)-(a.p?1:0)});
 return JSON.stringify({title:document.title,items:out,subs:subs,blobs:blobs});
})();
"""

    const val PAUSE_ALL = "window.postMessage({__ev:'pause'},'*');"

    /** 탭의 음소거 상태가 바뀌었음을 모든 프레임에 알린다 (각 프레임이 EvMedia.muted() 를 다시 읽는다) */
    const val MUTE_SYNC = "window.postMessage({__ev:'mute'},'*');"

    /** 작은 창(PiP)에서 재생 중인 동영상만 화면 가득 보이게 한다. */
    const val PIP_ON = """
(function(){
 var vs=[].slice.call(document.querySelectorAll('video'));
 if(!vs.length) return '';
 var v=null;
 /* '영상 아래 PiP 버튼'으로 방금 고른 영상이 있으면 그것을 먼저 */
 for(var k=0;k<vs.length;k++){if(vs[k].__evPrefAt&&Date.now()-vs[k].__evPrefAt<8000){v=vs[k];break}}
 if(!v)for(var i=0;i<vs.length;i++){if(!vs[i].paused&&!vs[i].ended){v=vs[i];break}}
 if(!v){vs.sort(function(a,b){return b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight});v=vs[0]}
 var st=document.getElementById('__ev_pip_style');
 if(!st){st=document.createElement('style');st.id='__ev_pip_style';document.documentElement.appendChild(st)}
 st.textContent='html,body{overflow:hidden!important;background:#000!important}'
  +'body *{visibility:hidden!important}'
  +'video.__ev_pip{visibility:visible!important;position:fixed!important;top:0!important;left:0!important;'
  +'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;'
  +'z-index:2147483647!important;background:#000!important;object-fit:contain!important;transform:none!important}';
 v.classList.add('__ev_pip');
 return 'ok';
})();
"""

    const val PIP_OFF = """
(function(){
 var st=document.getElementById('__ev_pip_style'); if(st) st.remove();
 var m=document.querySelectorAll('video.__ev_pip');
 for(var i=0;i<m.length;i++) m[i].classList.remove('__ev_pip');
})();
"""

    /**
     * 당겨서 새로고침 오작동 방지용. 모든 프레임에서 문서 시작 시점에 실행된다.
     * 페이지 안의 '안쪽 스크롤 영역'(채팅/피드 등 body 가 아닌 요소가 스크롤되는 사이트)은
     * WebView 의 scrollY 가 늘 0 이라서 앱이 맨 위로 착각한다. 그래서 손가락이 닿은 자리의 조상 중
     * 이미 스크롤된(scrollTop>0) 요소가 있거나, 터치 중 안쪽 요소가 스크롤되거나,
     * 페이지가 touchmove 를 직접 처리(preventDefault)하면 EvMedia.pullInner(true) 로 알린다.
     */
    const val PULL_GUARD = """
(function(){
 if(window.__evPull) return; window.__evPull=1;
 var touching=false, sent=false;
 function send(v){ if(sent===v) return; sent=v; try{EvMedia.pullInner(v)}catch(e){} }
 function scrolledAncestor(t){
  try{
   var e=t;
   while(e){
    if(e.nodeType===1 && e.scrollTop>0){
     var o=getComputedStyle(e).overflowY;
     if(o==='auto'||o==='scroll'||o==='overlay'||e===document.scrollingElement||e===document.body||e===document.documentElement) return true;
    }
    e=e.parentNode||e.host||null;
   }
  }catch(x){}
  return false;
 }
 window.addEventListener('touchstart',function(e){
  touching=true; sent=null;
  var t=(e.composedPath&&e.composedPath()[0])||e.target;
  send(scrolledAncestor(t));
 },{capture:true,passive:true});
 function end(){touching=false}
 window.addEventListener('touchend',end,{capture:true,passive:true});
 window.addEventListener('touchcancel',end,{capture:true,passive:true});
 window.addEventListener('scroll',function(e){
  if(!touching) return;
  var t=e.target;
  if(t && t!==document && t.scrollTop>0) send(true);
 },true);
 window.addEventListener('touchmove',function(e){
  if(touching && e.defaultPrevented) send(true);
 },{passive:true});
})();
"""
}
