package com.example.evergreen

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import kotlin.math.abs

/**
 * 앱 안에 들어 있는 동영상 플레이어.
 * - mp4/webm 같은 파일과 HLS(m3u8) / DASH(mpd) 스트리밍을 재생한다.
 * - 더블탭 ±10초(연속으로 하면 누적), 길게 누르면 2배속, 세로로 쓸어서 밝기(왼쪽) / 볼륨(오른쪽), 가로로 쓸어서 시간 이동
 * - 위쪽 바: 배속(눌러서 순환) / 화면 비율(맞추기·채우기·늘리기) / 화면 회전 / 작은 창(PiP)
 * - 화질·자막은 아래쪽 컨트롤의 설정(톱니)에서. 재생 오류가 나면 '다시 시도' 버튼이 뜬다
 * - 영상에 들어 있는(또는 페이지의 <track> 으로 딸린) 자막은 CC 버튼으로 직접 켜고, 위쪽 바의 '자막 번역' 으로 키 없이 한국어 번역을 겹쳐 보여 준다
 */
@UnstableApi
class PlayerActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_URL = "url"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_REFERER = "referer"
        private const val EXTRA_UA = "ua"
        private const val EXTRA_COOKIE = "cookie"
        private const val EXTRA_POS = "pos"
        private const val EXTRA_SUBS = "subs"

        fun start(
            ctx: Context, url: String, title: String?, referer: String?,
            userAgent: String?, cookie: String?, positionMs: Long,
            subsJson: String? = null
        ) {
            ctx.startActivity(
                Intent(ctx, PlayerActivity::class.java)
                    .putExtra(EXTRA_URL, url)
                    .putExtra(EXTRA_TITLE, title)
                    .putExtra(EXTRA_REFERER, referer)
                    .putExtra(EXTRA_UA, userAgent)
                    .putExtra(EXTRA_COOKIE, cookie)
                    .putExtra(EXTRA_POS, positionMs)
                    .putExtra(EXTRA_SUBS, subsJson)
            )
            // 부드럽게 떠오르며 열린다
            (ctx as? android.app.Activity)?.overridePendingTransition(R.anim.player_in, R.anim.player_hold)
        }
    }

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var osd: TextView
    private lateinit var errorBox: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var speedChip: TextView
    private lateinit var subChip: TextView
    private lateinit var liveChip: TextView

    // 실시간 자막 (소리를 Gemini 로 보내 한국어 자막을 만든다)
    private val pcmTap = PcmTap()
    private var liveCap: PcmSink? = null
    private var liveSrcKo = false
    private val liveQueue = ArrayDeque<LiveSeg>()
    private var liveShowing = false
    private var lastLiveErrAt = 0L
    private lateinit var subOverlay: LinearLayout
    private lateinit var subMain: TextView
    private lateinit var subOrig: TextView

    // 자막 번역 상태
    private val subTranslator = FreeTranslator()
    private val subExec = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val subCache = android.util.LruCache<String, String>(600)
    private val subPending = HashSet<String>()
    private var lastCues: List<Cue> = emptyList()
    private var curSubKey = ""
    private var curSubOrig = ""
    private var subSourceKo = false
    private var autoSubDone = false
    private var lastSubErrAt = 0L
    private var subsJson: String? = null
    private var useSubs = true
    private lateinit var prefs: Prefs

    private var title = ""
    private var landscapeLocked = false
    private var videoRatio = Rational(16, 9)
    private var bgServiceOn = false
    private var longPressing = false
    private var prevSpeed = 1f

    // 연속 더블탭 누적 / 가로 쓸기 시간 이동
    private var tapAcc = 0
    private var tapDir = 0
    private var lastTapAt = 0L
    private var seekStart = 0L
    private var seekTarget = -1L

    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("화면에 맞추기", "화면 채우기 (확대)", "화면 늘리기")
    private var resizeIdx = 0

    // 세로 쓸기 제스처 상태
    private var scrollMode = 0 // 0 미정, 1 세로, 2 가로(무시)

    private val hideOsd = Runnable { fadeOutOsd() }
    private var resumeKey = ""
    private var resumed = false

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.player_hold, R.anim.player_out)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // 가로 화면에서 노치 쪽까지 영상이 차도록 (버튼은 아래 인셋 처리로 노치를 피한다)
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        hideSystemBars()

        val url = intent.getStringExtra(EXTRA_URL)
        if (url.isNullOrBlank()) {
            finish()
            return
        }
        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val referer = intent.getStringExtra(EXTRA_REFERER)
        val ua = intent.getStringExtra(EXTRA_UA)
        val cookie = intent.getStringExtra(EXTRA_COOKIE)
        pageReferer = referer
        pageUa = ua
        pageCookie = cookie
        subsJson = intent.getStringExtra(EXTRA_SUBS)
        var startPos = intent.getLongExtra(EXTRA_POS, 0L)
        // 유튜브 영상 주소면 영상 번호를 뽑아 둔다 (페이지의 영상은 blob 이라 재생 주소를 유튜브에서 따로 받아야 한다)
        val ytVid = YouTube.videoIdOf(url)
        ytId = ytVid
        if (ytVid != null) useSubs = false
        // 같은 영상을 다시 열면 지난번에 보던 곳부터 (주소의 ? 뒤는 매번 바뀌는 경우가 많아 뺀다)
        // 유튜브는 주소가 전부 /watch 로 같으니 영상 번호로 구분한다
        resumeKey = if (ytVid != null) "yt$ytVid" else "p" + url.substringBefore('?').hashCode()
        if (startPos <= 0L) {
            val saved = getSharedPreferences("player_pos", Context.MODE_PRIVATE).getLong(resumeKey, 0L)
            if (saved > 5_000L) {
                startPos = saved
                resumed = true
            }
        }

        buildUi()
        // 톱니 버튼: 기본 설정 창 대신 앱 스타일의 설정 패널(화질·음성·자막·속도·화면 비율·저장)
        playerView.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.setOnClickListener { openSettings() }

        // 영상 서버가 요구하는 Referer / UA / 쿠키를 그대로 보낸다
        val headers = HashMap<String, String>()
        if (ytVid == null) {
            if (!referer.isNullOrBlank()) headers["Referer"] = referer
            if (!cookie.isNullOrBlank()) headers["Cookie"] = cookie
        }
        // OkHttp: 연결 재사용 + HTTP/2 로 첫 화면과 조각 받기가 빨라진다
        val http = androidx.media3.datasource.okhttp.OkHttpDataSource.Factory(PlayerHttp.client)
            .setDefaultRequestProperties(headers)
        // 유튜브 재생 주소는 받을 때 쓴 앱(안드로이드 VR/iOS)의 User-Agent 로 불러야 한다
        if (ytVid != null) http.setUserAgent(YouTube.UA_VR) else if (!ua.isNullOrBlank()) http.setUserAgent(ua)
        httpFactory = http

        // 어떤 기기에서든 되도록 재생되게: 하드웨어 디코더가 실패하면 다른 디코더(소프트웨어 포함)로 자동 전환
        val renderers = androidx.media3.exoplayer.DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .forceEnableMediaCodecAsynchronousQueueing() // 디코더 입력 지연을 줄여 첫 화면이 빨리 나온다
        // 실시간 자막: 소리를 그대로 통과시키면서 엿듣는 처리기를 오디오 출력에 끼운다
        val audioSink = androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(this)
            .setAudioProcessors(arrayOf<androidx.media3.common.audio.AudioProcessor>(pcmTap))
            .build()
        val rendererFactory = androidx.media3.exoplayer.RenderersFactory { handler, videoL, audioL, textO, metaO ->
            renderers.createRenderers(handler, videoL, audioL, textO, metaO).map { r ->
                if (r is androidx.media3.exoplayer.audio.MediaCodecAudioRenderer) {
                    androidx.media3.exoplayer.audio.MediaCodecAudioRenderer(
                        this, androidx.media3.exoplayer.mediacodec.MediaCodecSelector.DEFAULT,
                        true, handler, audioL, audioSink
                    )
                } else r
            }.toTypedArray()
        }
        // 기본값은 2.5초(재버퍼링 뒤 5초)가 쌓여야 재생을 시작한다. 1초만 쌓이면 시작하고, 평소엔 더 넉넉히 미리 받아 둔다.
        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs = */ 30_000,
                /* maxBufferMs = */ 60_000,
                /* bufferForPlaybackMs = */ 1_000,
                /* bufferForPlaybackAfterRebufferMs = */ 3_000
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        player = ExoPlayer.Builder(this, rendererFactory)
            .setLoadControl(loadControl)
            // 목차(인덱스)가 없는 mp3·aac 같은 파일도 위치 이동이 되게 한다
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(
                    http,
                    androidx.media3.extractor.DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
                )
            )
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        playerView.player = player
        // 자막은 자동으로 켜지 않는다: 기본은 꺼 두고, 사용자가 CC(자막) 버튼으로 직접 고르면 켜진다
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguages("ko", "en")
            .setSelectUndeterminedTextLanguage(true)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()

        mediaUrl = url
        retryPos = startPos
        if (ytVid != null) {
            // 유튜브: 재생 주소를 받아 와서 튼다
            startYouTube(startPos)
        } else {
            // 주소만으로 종류를 알 수 있으면 그것부터, 실패하면 다른 방식(HLS → DASH → 스무스 → 일반 파일)으로 차례로 다시 시도한다
            val guess = guessMime(url)
            tries = (listOf(guess) + listOf(null, MimeTypes.APPLICATION_M3U8, MimeTypes.APPLICATION_MPD, MimeTypes.APPLICATION_SS)).distinct()
            tryIdx = 0
            loadAttempt(startPos)
        }

        if (resumed) playerView.post { showOsd("이어서 재생  ${fmt(startPos)}", 1800) }

        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                if (size.width > 0 && size.height > 0) {
                    val r = size.width.toFloat() / size.height
                    videoRatio = when {
                        r > 2.39f -> Rational(239, 100)
                        r < 0.4184f -> Rational(100, 239)
                        else -> Rational(size.width, size.height)
                    }
                    // 가로 영상이면 처음 한 번 가로 화면으로
                    if (!landscapeLocked && size.width >= size.height) {
                        landscapeLocked = true
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                    updatePipParams()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePipParams()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                // 재생/일시정지 버튼이 톡 눌렸다 튀어 오르는 느낌
                playerView.findViewById<View>(androidx.media3.ui.R.id.exo_play_pause)?.let { b ->
                    b.animate().cancel()
                    b.scaleX = 0.82f; b.scaleY = 0.82f
                    b.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
                }
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                updateSpeedChip(playbackParameters.speed)
            }

            override fun onCues(cueGroup: CueGroup) {
                lastCues = cueGroup.cues
                handleCues(cueGroup.cues)
            }

            override fun onTracksChanged(tracks: Tracks) {
                handleTracks(tracks)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY || state == Player.STATE_BUFFERING) errorBox.visibility = View.GONE
            }

            override fun onPlayerError(error: PlaybackException) {
                // 딸린 자막 파일을 못 받아서 재생이 멈춘 경우: 자막 없이 한 번 더 시도
                if (useSubs && !subsJson.isNullOrBlank()) {
                    useSubs = false
                    autoSubDone = false
                    loadAttempt(maxOf(retryPos, player.currentPosition))
                    return
                }
                // 유튜브: 이 형식이 안 되면(주소 거절·코덱 미지원 등) 다음 형식, 그래도 안 되면 다음 클라이언트로 받아 다시
                if (ytId != null) {
                    if (recoverYouTube(error)) return
                    if (advanceYouTube()) return
                    ytFailed = true
                }
                // 종류를 잘못 짚었거나 확장자가 없는 주소: 다른 방식으로 다시 시도
                val retryable = error.errorCode in intArrayOf(
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
                    PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                    PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
                )
                if (retryable && tryIdx + 1 < tries.size) {
                    tryIdx++
                    loadAttempt(maxOf(retryPos, player.currentPosition))
                    return
                }
                showError(
                    "재생할 수 없는 영상이에요",
                    errorHint(error) + if (ytId != null && error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) "\n'다시 시도'를 누르면 새 주소로 불러와요" else "",
                    error.errorCodeName
                )
            }
        })
    }

    private var mediaUrl = ""
    /** 저장(다운로드) 때 영상 서버로 같이 보낼 Referer / UA */
    private var pageReferer: String? = null
    private var pageUa: String? = null
    private var pageCookie: String? = null
    private var lastSaveUrl = ""
    private var lastSaveAt = 0L
    private var tries: List<String?> = listOf(null)
    private var tryIdx = 0
    private var retryPos = 0L

    private fun guessMime(url: String): String? {
        val l = url.lowercase()
        val path = l.substringBefore('?')
        return when {
            path.endsWith(".m3u8") -> MimeTypes.APPLICATION_M3U8
            path.endsWith(".mpd") -> MimeTypes.APPLICATION_MPD
            path.endsWith(".ism/manifest") || path.endsWith(".ism") -> MimeTypes.APPLICATION_SS
            l.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            l.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
    }

    /** 페이지의 <track> 으로 딸려 온 자막 파일들 (VTT / SRT / ASS / TTML) */
    private fun subConfigs(): List<MediaItem.SubtitleConfiguration> {
        val raw = subsJson
        if (raw.isNullOrBlank()) return emptyList()
        val out = ArrayList<MediaItem.SubtitleConfiguration>()
        try {
            val a = org.json.JSONArray(raw)
            for (i in 0 until minOf(a.length(), 8)) {
                val o = a.getJSONObject(i)
                val u = o.optString("u")
                if (!u.startsWith("http://") && !u.startsWith("https://")) continue
                val path = u.substringBefore('?').lowercase()
                val mime = when {
                    path.endsWith(".srt") -> MimeTypes.APPLICATION_SUBRIP
                    path.endsWith(".ass") || path.endsWith(".ssa") -> MimeTypes.TEXT_SSA
                    path.endsWith(".ttml") || path.endsWith(".dfxp") || path.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
                    else -> MimeTypes.TEXT_VTT
                }
                val lang = o.optString("g").ifBlank { null }
                val label = o.optString("l").ifBlank { null }
                out.add(
                    MediaItem.SubtitleConfiguration.Builder(android.net.Uri.parse(u))
                        .setMimeType(mime)
                        .setLanguage(lang)
                        .setLabel(label)
                        .setSelectionFlags(if (out.isEmpty()) C.SELECTION_FLAG_DEFAULT else 0)
                        .build()
                )
            }
        } catch (e: Exception) {
            // 읽지 못하면 자막 없이
        }
        return out
    }

    // ───────────────────────── 자막 표시 / 번역 ─────────────────────────

    /** 영상에 들어 있는 자막 트랙을 찾아서: 있으면 '자막 번역' 버튼을 보이고, 자막은 자동으로 켜지 않는다(사용자가 CC 버튼으로 켠다). */
    private fun handleTracks(tracks: Tracks) {
        val groups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        subChip.visibility = if (groups.isEmpty()) View.GONE else View.VISIBLE
        if (groups.isEmpty()) {
            subSourceKo = false
            return
        }
        val selected = groups.firstOrNull { it.isSelected }
        subSourceKo = selected != null && (0 until selected.length).any {
            selected.isTrackSelected(it) && selected.getTrackFormat(it).language?.lowercase()?.startsWith("ko") == true
        }
        if (!autoSubDone) {
            autoSubDone = true
            if (prefs.subTranslateMode == 0) {
                playerView.post { showOsd("자막이 있어요 · 아래 CC 버튼으로 켤 수 있어요", 2200) }
            }
        }
        // 선택된 자막이 바뀌었을 수 있으니 지금 자막을 다시 그린다
        handleCues(lastCues)
    }

    /** 기본 자막(플레이어 자체)을 그대로 보여 준다 — 번역을 쓰지 않을 때 */
    private fun showDefaultSubs() {
        subOverlay.visibility = View.GONE
        playerView.subtitleView?.visibility = View.VISIBLE
        curSubKey = ""
    }

    private fun handleCues(cues: List<Cue>) {
        if (!::subOverlay.isInitialized) return
        if (liveCap != null) return // 실시간 자막을 쓰는 동안은 영상 안의 자막을 가리지 않는다
        val text = cues.mapNotNull { it.text?.toString()?.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
        // 번역을 안 쓰거나, 글이 아닌 그림 자막(PGS 등)이거나, 이미 한국어면 기본 자막 그대로
        if (prefs.subTranslateMode == 0 || text.isEmpty() || cues.any { it.bitmap != null } || subSourceKo) {
            showDefaultSubs()
            return
        }
        val norm = text.replace(Regex("<[^>]+>"), "").replace(Regex("\\s*\\n\\s*"), " ").trim()
        if (norm.isEmpty() || FreeTranslator.isKoreanOrEmpty(norm)) {
            showDefaultSubs()
            return
        }
        curSubKey = norm
        curSubOrig = text.replace(Regex("<[^>]+>"), "")
        val cached = subCache.get(norm)
        renderSub(cached)
        if (cached == null) requestSubTranslation(norm)
    }

    /** 번역(없으면 번역 중인 원문)을 자막 자리에 겹쳐 그린다 */
    private fun renderSub(translated: String?) {
        playerView.subtitleView?.visibility = View.GONE
        subOverlay.visibility = View.VISIBLE
        if (translated != null) {
            subMain.alpha = 1f
            subMain.text = translated
            if (prefs.subTranslateMode == 2) {
                subOrig.text = curSubOrig
                subOrig.visibility = View.VISIBLE
            } else {
                subOrig.visibility = View.GONE
            }
        } else {
            // 번역이 오기 전엔 원문을 흐리게 보여 준다 (자막이 비어 보이지 않게)
            subMain.alpha = 0.65f
            subMain.text = curSubOrig
            subOrig.visibility = View.GONE
        }
    }

    private fun requestSubTranslation(key: String) {
        if (!subPending.add(key)) return
        subExec.execute {
            val (res, err) = subTranslator.translate(listOf(key))
            runOnUiThread {
                subPending.remove(key)
                if (isDestroyed || isFinishing) return@runOnUiThread
                val tr = res?.firstOrNull()
                if (tr != null) {
                    subCache.put(key, tr)
                    if (key == curSubKey && prefs.subTranslateMode != 0) renderSub(tr)
                } else if (err != null) {
                    // 같은 오류 안내가 계속 뜨지 않게 15초에 한 번만
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastSubErrAt > 15_000L) {
                        lastSubErrAt = now
                        showOsd("자막 번역 실패 · $err", 2500)
                    }
                }
            }
        }
    }

    // ───────────────────────── 실시간 자막 ─────────────────────────

    private val micPerm = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) toggleLiveCaption() else showOsd("마이크 권한이 있어야 기기 안 음성 인식을 쓸 수 있어요", 2500)
    }

    private val liveLangs = listOf("en-US" to "영어", "ko-KR" to "한국어", "ja-JP" to "일본어", "zh-CN" to "중국어", "es-ES" to "스페인어")

    /** Gemini 키가 없으면 키 없이 되는 '기기 안 인식'을 쓴다 (저장된 선택은 그대로 두어서, 키를 넣으면 다시 Gemini) */
    private fun liveModeEff(): Int = if (prefs.liveMode == 0 && prefs.geminiKey.isBlank()) 1 else prefs.liveMode

    private fun liveModeLabel() =
        if (liveModeEff() == 1) "기기 안 인식 · " + (liveLangs.firstOrNull { it.first == prefs.liveLang }?.second ?: prefs.liveLang)
        else "Gemini"

    /** 칩을 꾹 누르면: 실시간 자막 방식(Gemini / 기기 안)과 기기 안 인식의 언어를 고른다 */
    private fun chooseLiveMode() {
        val names = ArrayList<String>()
        names.add("Gemini  (정확해요 · 키 필요 · 소리가 Google 로 전송돼요)")
        liveLangs.forEach { names.add("기기 안 인식 · ${it.second}  (오프라인 · 정확도 낮음)") }
        val cur = if (prefs.liveMode == 1) 1 + liveLangs.indexOfFirst { it.first == prefs.liveLang } else 0
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("실시간 자막 방식")
            .setSingleChoiceItems(names.toTypedArray(), cur) { d, i ->
                if (i == 0) prefs.liveMode = 0 else { prefs.liveMode = 1; prefs.liveLang = liveLangs[i - 1].first }
                d.dismiss()
                if (liveCap != null) stopLiveCaption()
                showOsd("실시간 자막: ${liveModeLabel()}", 1800)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun startOnDeviceCaption() {
        if (Build.VERSION.SDK_INT < 33) {
            showOsd("기기 안 음성 인식은 Android 13 이상에서만 돼요" + if (prefs.geminiKey.isBlank()) " · 낮은 버전은 Gemini 키가 필요해요" else "", 2800)
            return
        }
        if (!android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            showOsd("이 기기는 기기 안 음성 인식을 지원하지 않아요" + if (prefs.geminiKey.isBlank()) " · Gemini 키를 넣으면 쓸 수 있어요" else " · 방식을 Gemini 로 바꿔 보세요", 3200)
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            micPerm.launch(android.Manifest.permission.RECORD_AUDIO)
            return
        }
        val lang = prefs.liveLang
        liveSrcKo = lang.startsWith("ko")
        val cap = OnDeviceCaptioner(
            this, lang,
            onPartial = { t -> livePartial(t) },
            onFinal = { t -> liveFinal(t) },
            onError = { msg -> liveError(msg) },
            onReset = { liveClear() }
        )
        liveCap = cap
        pcmTap.sink = cap
        cap.start()
        liveOnUi()
        showOsd("기기 안에서 소리를 글로 바꿔요 · ${liveModeLabel()}", 2600)
    }

    private fun liveOnUi() {
        liveChip.text = "실시간 켬"
        liveChip.alpha = 1f
        liveChip.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(getColor(R.color.ev_accent))
        }
        playerView.subtitleView?.visibility = View.GONE
    }

    private fun liveError(msg: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastLiveErrAt > 15_000L) {
            lastLiveErrAt = now
            showOsd("실시간 자막 · $msg", 2800)
        }
    }

    /** 인식 중인 글 (아직 끝나지 않음): 흐리게 바로 보여 준다 */
    private fun livePartial(t: String) {
        if (liveCap == null || liveShowing) return
        playerView.subtitleView?.visibility = View.GONE
        subOverlay.visibility = View.VISIBLE
        subMain.alpha = 0.65f
        subMain.text = t
        subOrig.visibility = View.GONE
    }

    /** 한 문장 인식이 끝남: 한국어가 아니면 번역해서 자막 줄로 넣는다 */
    private fun liveFinal(t: String) {
        if (liveCap == null) return
        fun push(s: String) = liveEnqueue(listOf(LiveSeg(s, (s.length * 90L).coerceIn(1800L, 5000L))))
        if (liveSrcKo) {
            push(t)
            return
        }
        subExec.execute {
            val tr = try { subTranslator.translate(listOf(t)).first?.firstOrNull() } catch (e: Exception) { null }
            runOnUiThread { push(tr ?: t) }
        }
    }

    private fun toggleLiveCaption() {
        if (liveCap != null) {
            stopLiveCaption()
            showOsd("실시간 자막을 껐어요", 1500)
            return
        }
        if (liveModeEff() == 1) {
            startOnDeviceCaption()
            return
        }
        val key = prefs.geminiKey
        if (key.isBlank()) {
            showOsd("설정에서 Gemini API 키를 먼저 넣어 주세요 (무료 키 가능)", 2800)
            return
        }
        val cap = LiveCaptioner(
            key, prefs.geminiModel,
            onSegs = { segs -> runOnUiThread { liveEnqueue(segs) } },
            onError = { msg ->
                runOnUiThread {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastLiveErrAt > 15_000L) {
                        lastLiveErrAt = now
                        showOsd("실시간 자막 · $msg", 2500)
                    }
                }
            },
            onReset = { runOnUiThread { liveClear() } }
        )
        liveCap = cap
        pcmTap.sink = cap
        liveSrcKo = true
        liveOnUi()
        showOsd("소리를 Gemini 로 보내 한국어 자막을 만들어요 · 몇 초 늦게 나와요", 3000)
    }

    private fun stopLiveCaption() {
        pcmTap.sink = null
        liveCap?.stop()
        liveCap = null
        liveClear()
        liveChip.text = "실시간 끔"
        liveChip.alpha = 0.7f
        liveChip.background = null
        handleCues(lastCues)
    }

    private fun liveEnqueue(segs: List<LiveSeg>) {
        if (liveCap == null) return
        segs.forEach { liveQueue.addLast(it) }
        while (liveQueue.size > 6) liveQueue.removeFirst() // 밀리면 오래된 줄은 버린다
        if (!liveShowing) liveNext()
    }

    private val liveNextRun = Runnable { liveNext() }

    private fun liveNext() {
        val n = if (liveQueue.isEmpty()) null else liveQueue.removeFirst()
        if (n == null || liveCap == null) {
            liveShowing = false
            if (liveCap != null) subOverlay.visibility = View.GONE
            return
        }
        liveShowing = true
        playerView.subtitleView?.visibility = View.GONE
        subOverlay.visibility = View.VISIBLE
        subMain.alpha = 1f
        subMain.text = n.text
        subOrig.visibility = View.GONE
        // 줄이 많이 밀려 있으면 조금 빠르게 넘긴다
        val hold = if (liveQueue.size >= 3) (n.holdMs * 0.6).toLong() else n.holdMs
        ui.removeCallbacks(liveNextRun)
        ui.postDelayed(liveNextRun, hold)
    }

    private fun liveClear() {
        ui.removeCallbacks(liveNextRun)
        liveQueue.clear()
        liveShowing = false
        if (::subOverlay.isInitialized && liveCap != null) subOverlay.visibility = View.GONE
    }

    private fun subChipLabel() = when (prefs.subTranslateMode) {
        1 -> "자막 번역"
        2 -> "번역+원문"
        else -> "번역 끔"
    }

    private fun cycleSubTranslate() {
        prefs.subTranslateMode = (prefs.subTranslateMode + 1) % 3
        subChip.text = subChipLabel()
        handleCues(lastCues)
        val msg = when (prefs.subTranslateMode) {
            1 -> "자막을 한국어로 번역해요"
            2 -> "한국어 번역 + 원문을 함께 보여요"
            else -> "자막 번역을 껐어요"
        }
        showOsd(
            if (prefs.subTranslateMode != 0 && subSourceKo) "한국어 자막이라 번역하지 않아요" else msg,
            1500
        )
    }

    /** 지금 보는 영상을 기기에 저장한다 (앱의 다운로드 서비스로, 여러 연결로 나눠 받는다). HLS(m3u8) 는 조각을 받아 mp4 로 묶는다. */
    private fun saveVideo() {
        if (ytId != null) {
            showOsd("유튜브 영상은 저장할 수 없어요", 2200)
            return
        }
        val url = mediaUrl
        val lower = url.lowercase()
        val cur = tries.getOrNull(tryIdx)
        val manifest = player.currentManifest
        // 주소엔 안 보여도 플레이어가 HLS 목록으로 읽고 있으면 HLS 다
        val hls = cur == MimeTypes.APPLICATION_M3U8 || lower.contains(".m3u8") ||
            manifest is androidx.media3.exoplayer.hls.HlsManifest
        // DASH / 스무스 스트리밍은 영상과 소리가 따로 쪼개져 있어 파일 하나로 받을 수 없다
        val otherStream = !hls && (
            cur == MimeTypes.APPLICATION_MPD || cur == MimeTypes.APPLICATION_SS ||
                lower.contains(".mpd") || lower.contains(".ism") || manifest != null
            )
        if (otherStream) {
            showOsd("이 방식(mpd/ism) 스트리밍 영상은 저장할 수 없어요", 2200)
            return
        }
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            showOsd("이 영상은 저장할 수 없어요", 2000)
            return
        }
        if (hls && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            showOsd("스트리밍(m3u8) 영상 저장은 안드로이드 10 이상에서 가능해요", 2400)
            return
        }
        val now = android.os.SystemClock.uptimeMillis()
        if (url == lastSaveUrl && now - lastSaveAt < 5000L) return // 연타로 두 번 받지 않게
        lastSaveUrl = url
        lastSaveAt = now

        // 안드로이드 13+: 다운로드 진행 알림을 보려면 알림 권한이 필요하다 (거절해도 저장은 된다)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            androidx.core.app.ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // 재생할 때 쓴 쿠키·제목을 같이 넘겨서, 로그인이 필요한 영상도 받을 수 있고 파일 이름도 제목으로 정해진다
                DownloadService.start(
                    this, url, pageUa, null, if (hls) MimeTypes.APPLICATION_M3U8 else null, pageReferer,
                    title, pageCookie
                )
                showOsd(
                    if (hls) "스트리밍 영상 저장을 시작했어요 · 조각을 모아 mp4 로 만들어요" else "저장을 시작했어요 · 다운로드 목록에서 볼 수 있어요",
                    2400
                )
                return
            }
        } catch (e: Exception) {
            // 서비스를 못 켜면 시스템 다운로더로
        }
        val name = SystemDownload.enqueue(this, url, pageUa, null, null, pageReferer)
        showOsd(if (name != null) "저장 중: $name" else "저장에 실패했어요", 2200)
    }

    // ───────────────────────── 유튜브 ─────────────────────────

    private var ytId: String? = null
    private var ytInfo: YouTube.Info? = null
    private var ytIdx = 0
    private var ytFailed = false
    private var ytSeq = 0
    private lateinit var httpFactory: androidx.media3.datasource.okhttp.OkHttpDataSource.Factory


    /** 재생 오류 안내: 제목 + 원인 설명 + (작게) 오류 코드. 긴 코드도 줄바꿈되게 밑줄 뒤에 끊을 자리를 둔다 */
    private fun showError(title: String, hint: String? = null, code: String? = null) {
        val sb = android.text.SpannableStringBuilder()
        fun add(s: String, sizeSp: Int, color: Int, bold: Boolean) {
            if (sb.isNotEmpty()) sb.append('\n')
            val st = sb.length
            sb.append(s)
            sb.setSpan(android.text.style.AbsoluteSizeSpan(sizeSp, true), st, sb.length, 0)
            sb.setSpan(android.text.style.ForegroundColorSpan(color), st, sb.length, 0)
            if (bold) sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), st, sb.length, 0)
        }
        add(title, 16, Color.WHITE, true)
        if (!hint.isNullOrBlank()) add(hint, 14, 0xCCFFFFFF.toInt(), false)
        if (!code.isNullOrBlank()) add(code.replace("_", "_\u200B"), 11, 0x80FFFFFF.toInt(), false)
        errorText.text = sb
        showErrorBox()
    }

    /** ExoPlayer 오류를 사용자가 이해할 수 있는 말로 */
    private fun errorHint(e: PlaybackException): String {
        val http = (e.cause as? androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)?.responseCode
        return when (e.errorCode) {
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "네트워크 연결이 불안정해요"
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                if (http == 403 || http == 410) "재생 주소가 만료됐거나 서버가 거절했어요 (HTTP $http)"
                else "영상 서버가 오류를 돌려줬어요" + (http?.let { " (HTTP $it)" } ?: "")
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "영상 파일을 찾을 수 없어요"
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES -> "이 기기가 이 영상 형식을 재생하지 못해요"
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> "영상 파일이 올바르지 않아요"
            else -> "재생 중 문제가 생겼어요"
        }
    }

    private var ytRecover = 0
    private var ytRecoverPos = 0L

    /**
     * 유튜브 재생 중 네트워크·주소 오류(만료·거절·끊김)가 나면 바로 오류를 띄우지 않고,
     * 같은 방식으로 새 재생 주소를 받아 보던 곳부터 이어 튼다. 20초 넘게 잘 재생된 뒤의 오류는 새 상황으로 보고 다시 2번까지 시도한다.
     */
    private fun recoverYouTube(error: PlaybackException): Boolean {
        val info = ytInfo ?: return false
        if (error.errorCode !in 2000..2999) return false
        val pos = maxOf(retryPos, player.currentPosition)
        if (pos - ytRecoverPos > 20_000L || pos < ytRecoverPos) ytRecover = 0
        if (ytRecover >= 2) return false
        ytRecover++
        ytRecoverPos = pos
        startYouTube(pos, info.clientIdx)
        return true
    }

    private fun showErrorBox() {
        errorBox.animate().cancel()
        errorBox.alpha = 0f
        errorBox.scaleX = 0.94f; errorBox.scaleY = 0.94f
        errorBox.visibility = View.VISIBLE
        errorBox.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        playerView.showController()
    }

    /** 유튜브에서 재생 주소를 받아 와서 튼다. fromClient > 0 이면 앞 클라이언트가 막혔을 때 다음 것으로 다시 받는 것 */
    private fun startYouTube(pos: Long, fromClient: Int = 0) {
        val id = ytId ?: return
        ytFailed = false
        ytInfo = null
        errorBox.visibility = View.GONE
        showOsd(if (ytRecover > 0 && pos > 0) "연결이 끊겨서 다시 불러오는 중…" else "유튜브 영상을 불러오는 중…", 30_000L)
        val seq = ++ytSeq
        Thread {
            var got: YouTube.Info? = null
            var err = ""
            try {
                got = YouTube.resolve(id, fromClient)
            } catch (e: Exception) {
                err = e.message ?: "알 수 없는 오류"
            }
            val info = got
            runOnUiThread {
                if (isDestroyed || isFinishing || seq != ytSeq) return@runOnUiThread
                ui.removeCallbacks(hideOsd)
                fadeOutOsd()
                if (info == null) {
                    ytFailed = true
                    showError("유튜브 영상을 열지 못했어요", err)
                    return@runOnUiThread
                }
                ytInfo = info
                ytIdx = 0
                if (info.title.isNotBlank()) title = info.title
                playYtStream(pos)
            }
        }.start()
    }

    /**
     * 재생바를 옮기면 플레이어는 중간 위치부터 `Range: bytes=a-b` 헤더로 새로 요청하는데,
     * 유튜브(googlevideo) 서버는 이런 헤더 요청을 거절(403)하거나 끊는 일이 잦다.
     * 그래서 구간이 정해진 요청은 헤더 대신 주소의 `&range=a-b` 로 바꿔 보낸다 (유튜브 앱·yt-dlp 와 같은 방식).
     */
    private val ytRangeResolver = androidx.media3.datasource.ResolvingDataSource.Resolver { spec ->
        val u = spec.uri
        val host = u.host.orEmpty()
        if (!host.endsWith("googlevideo.com") || u.path?.contains("videoplayback") != true ||
            u.getQueryParameter("range") != null || spec.length <= 0L
        ) {
            spec
        } else {
            val end = spec.position + spec.length - 1
            spec.buildUpon()
                .setUri(u.buildUpon().appendQueryParameter("range", "${spec.position}-$end").build())
                .setPosition(0L)
                .setLength(C.LENGTH_UNSET.toLong())
                .build()
        }
    }

    /** 받아 둔 형식 중 ytIdx 번째를 튼다 */
    private fun playYtStream(pos: Long) {
        val info = ytInfo ?: return
        val st = info.streams.getOrNull(ytIdx) ?: return
        httpFactory.setUserAgent(st.ua)
        autoSubDone = false
        retryPos = pos
        try {
            when (st.kind) {
                YouTube.DASH -> {
                    val manifest = androidx.media3.exoplayer.dash.manifest.DashManifestParser().parse(
                        android.net.Uri.parse("https://www.youtube.com/"),
                        java.io.ByteArrayInputStream(st.value.toByteArray(Charsets.UTF_8))
                    )
                    val src = androidx.media3.exoplayer.dash.DashMediaSource.Factory(
                        androidx.media3.datasource.ResolvingDataSource.Factory(httpFactory, ytRangeResolver)
                    ).createMediaSource(manifest)
                    mediaUrl = "https://www.youtube.com/watch?v=" + ytId
                    player.setMediaSource(src)
                }
                YouTube.HLS -> {
                    mediaUrl = st.value
                    player.setMediaItem(
                        MediaItem.Builder().setUri(st.value).setMimeType(MimeTypes.APPLICATION_M3U8).build()
                    )
                }
                else -> {
                    mediaUrl = st.value
                    player.setMediaItem(MediaItem.fromUri(st.value))
                }
            }
        } catch (e: Exception) {
            if (!advanceYouTube()) {
                ytFailed = true
                showError("유튜브 영상을 열지 못했어요", "재생 형식을 만들지 못했어요")
            }
            return
        }
        if (pos > 0) player.seekTo(pos)
        player.prepare()
        player.playWhenReady = true
    }

    /** 지금 형식이 안 될 때: 다음 형식으로, 형식이 다 떨어지면 다음 클라이언트로 주소를 다시 받는다. 더 시도할 게 없으면 false */
    private fun advanceYouTube(): Boolean {
        val info = ytInfo ?: return false
        val pos = maxOf(retryPos, player.currentPosition)
        if (ytIdx + 1 < info.streams.size) {
            ytIdx++
            playYtStream(pos)
            return true
        }
        if (info.hasMoreClients) {
            startYouTube(pos, info.clientIdx + 1)
            return true
        }
        return false
    }

    private fun loadAttempt(pos: Long) {
        if (ytId != null) { playYtStream(pos); return }
        // 새로 불러올 때마다 자막 자동 선택을 다시 한다 (재시도 뒤에 자막이 안 켜지던 문제)
        autoSubDone = false
        val item = MediaItem.Builder().setUri(mediaUrl).apply {
            tries[tryIdx]?.let { setMimeType(it) }
            if (useSubs) {
                val subs = subConfigs()
                if (subs.isNotEmpty()) setSubtitleConfigurations(subs)
            }
        }.build()
        player.setMediaItem(item)
        if (pos > 0) player.seekTo(pos)
        player.prepare()
        player.playWhenReady = true
    }


    // ───────────────────────── 설정 (톱니 버튼) ─────────────────────────

    private var settingsDlg: android.app.Dialog? = null
    private var settingsCard: LinearLayout? = null

    private class TrackOpt(val label: String, val group: Tracks.Group, val index: Int, val selected: Boolean)

    private fun trackLabel(type: Int, f: androidx.media3.common.Format, n: Int): String {
        if (type == C.TRACK_TYPE_VIDEO) {
            if (f.height > 0) return "${f.height}p" + if (f.frameRate > 30.5f) "${Math.round(f.frameRate)}" else ""
            return if (f.bitrate > 0) "${f.bitrate / 1000}kbps" else "화질 ${n + 1}"
        }
        f.label?.takeIf { it.isNotBlank() }?.let { return it }
        val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }
        val name = lang?.let { java.util.Locale.forLanguageTag(it).getDisplayLanguage(java.util.Locale.KOREAN) }
        return name?.takeIf { it.isNotBlank() } ?: "트랙 ${n + 1}"
    }

    private fun trackOpts(type: Int): List<TrackOpt> {
        val out = ArrayList<TrackOpt>()
        for (g in player.currentTracks.groups) {
            if (g.type != type || !g.isSupported) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                out.add(TrackOpt(trackLabel(type, g.getTrackFormat(i), out.size), g, i, g.isTrackSelected(i)))
            }
        }
        return if (type == C.TRACK_TYPE_VIDEO) out.sortedByDescending { it.group.getTrackFormat(it.index).height } else out
    }

    private fun hasVideoOverride(): Boolean =
        player.trackSelectionParameters.overrides.values.any { it.type == C.TRACK_TYPE_VIDEO }

    private fun applyTrack(type: Int, o: TrackOpt) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(type, false)
            .setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, listOf(o.index)))
            .build()
    }

    private fun settingsRow(label: String, value: String?, checked: Boolean, chevron: Boolean, onClick: () -> Unit): View {
        val accent = getColor(R.color.ev_accent)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(14), 0)
            minimumHeight = dp(52)
            isClickable = true
            tag = if (checked) ROW_ON else ROW // 배경(묶음 모양)은 settingsShow 가 위치를 보고 입힌다
            setOnClickListener { onClick() }
        }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            if (checked) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (value != null) row.addView(TextView(this).apply {
            text = value
            setTextColor(0xFF9AA0A6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            maxWidth = dp(150)
        })
        if (chevron) row.addView(TextView(this).apply {
            text = "›"
            setTextColor(0xFF9AA0A6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setPadding(dp(8), 0, 0, 0)
        })
        if (checked) row.addView(TextView(this).apply {
            text = "✓"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
        }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginStart = dp(10) })
        return row
    }

    private val ROW = "ev_row"
    private val ROW_ON = "ev_row_on"

    private fun isSettingsRow(v: View) = v.tag == ROW || v.tag == ROW_ON

    /** 이어진 항목들을 한 덩어리(둥근 카드)로 묶어 보이게: 첫·끝 항목만 바깥쪽 모서리를 둥글게, 사이는 얇은 틈 */
    private fun groupSettingsRows(card: LinearLayout) {
        val accent = getColor(R.color.ev_accent)
        val n = card.childCount
        var i = 0
        while (i < n) {
            if (!isSettingsRow(card.getChildAt(i))) { i++; continue }
            var j = i
            while (j + 1 < n && isSettingsRow(card.getChildAt(j + 1))) j++
            for (k in i..j) {
                val row = card.getChildAt(k)
                val top = if (k == i) dp(16).toFloat() else 0f
                val bottom = if (k == j) dp(16).toFloat() else 0f
                val radii = floatArrayOf(top, top, top, top, bottom, bottom, bottom, bottom)
                val on = row.tag == ROW_ON
                row.background = android.graphics.drawable.StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply {
                        cornerRadii = radii; setColor(0x33FFFFFF)
                    })
                    addState(intArrayOf(), GradientDrawable().apply {
                        cornerRadii = radii
                        setColor(if (on) (accent and 0x00FFFFFF) or 0x33000000 else 0x14FFFFFF)
                    })
                }
                (row.layoutParams as? LinearLayout.LayoutParams)?.let { lp ->
                    lp.topMargin = if (k == i) 0 else dp(1)
                    row.layoutParams = lp
                }
            }
            i = j + 1
        }
    }

    private fun settingsHeader(title: String, onBack: (() -> Unit)?): View {
        val main = onBack == null && title == "설정"
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            when {
                main -> { setPadding(dp(16), dp(8), dp(8), dp(8)); minimumHeight = dp(48) }
                onBack != null -> { setPadding(dp(4), dp(4), dp(14), dp(8)); minimumHeight = dp(48) }
                else -> { setPadding(dp(18), dp(14), dp(14), dp(6)); minimumHeight = dp(32) } // 작은 구역 제목
            }
        }
        if (onBack != null) row.addView(TextView(this).apply {
            text = "‹"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x1AFFFFFF) }
            setOnClickListener { onBack() }
        }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) })
        row.addView(TextView(this).apply {
            text = title
            when {
                main || onBack != null -> {
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, if (main) 19f else 17f)
                }
                else -> {
                    setTextColor(0xFF9AA0A6.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                }
            }
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (main) row.addView(TextView(this).apply {
            text = "✕"
            setTextColor(0xFFE8EAED.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x1AFFFFFF) }
            setOnClickListener { settingsClose() }
        }, LinearLayout.LayoutParams(dp(32), dp(32)))
        return row
    }

    private fun settingsShow(build: LinearLayout.() -> Unit) {
        val card = settingsCard ?: return
        card.removeAllViews()
        card.build()
        groupSettingsRows(card)
        // 앞으로 가면 오른쪽에서, 뒤로 가면 왼쪽에서 살짝 밀려 들어온다
        val dir = settingsDir
        settingsDir = 1
        card.animate().cancel()
        card.alpha = 0f
        card.translationX = dp(18).toFloat() * dir
        card.animate().alpha(1f).translationX(0f).setDuration(190)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
    }

    /** 설정 패널 쪽 이동 방향: 1 = 앞으로(오른쪽에서), -1 = 뒤로(왼쪽에서) */
    private var settingsDir = 1

    private fun settingsClose(msg: String? = null) {
        val dlg = settingsDlg
        val card = settingsCard
        if (dlg != null && card != null && card.isAttachedToWindow) {
            // 열릴 때의 반대로: 오른쪽 아래로 작아지며 사라진다
            card.animate().cancel()
            card.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).translationY(dp(10).toFloat()).translationX(0f)
                .setDuration(130).setInterpolator(android.view.animation.AccelerateInterpolator())
                .withEndAction { if (dlg.isShowing) dlg.dismiss() }.start()
        } else {
            dlg?.dismiss()
        }
        if (msg != null) showOsd(msg, 1600)
    }

    private fun openSettings() {
        settingsDlg?.dismiss()
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat(); setColor(0xF2121212.toInt()); setStroke(dp(1), 0x26FFFFFF)
            }
        }
        val scroll = android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(card)
        }
        settingsCard = card
        settingsDlg = dlg
        dlg.setContentView(scroll)
        dlg.setOnDismissListener {
            if (settingsDlg === dlg) { settingsDlg = null; settingsCard = null }
            if (!isFinishing && !isDestroyed) playerView.showController()
        }
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.35f)
            val dm = resources.displayMetrics
            setLayout(minOf(dp(340), dm.widthPixels - dp(24)), ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM or Gravity.END)
            attributes = attributes.apply { x = dp(12); y = dp(64); windowAnimations = 0 }
        }
        renderSettingsMain()
        dlg.show()
        dlg.window?.let {
            val c = WindowInsetsControllerCompat(it, it.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
        // 오른쪽 아래(톱니 버튼 쪽)에서 살짝 커지며 나타난다
        card.animate().cancel()
        card.alpha = 0f; card.scaleX = 0.94f; card.scaleY = 0.94f; card.translationX = 0f; card.translationY = dp(14).toFloat()
        card.post {
            card.pivotX = card.width.toFloat(); card.pivotY = card.height.toFloat()
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(260)
                .setInterpolator(android.view.animation.OvershootInterpolator(0.9f)).start()
        }
    }

    private fun renderSettingsMain(): Unit = settingsShow {
        addView(settingsHeader("설정", null))
        val video = trackOpts(C.TRACK_TYPE_VIDEO)
        val audio = trackOpts(C.TRACK_TYPE_AUDIO)
        val text = trackOpts(C.TRACK_TYPE_TEXT)
        if (video.size > 1) {
            val cur = video.firstOrNull { it.selected }?.label
            val v = if (hasVideoOverride()) cur ?: "고정" else "자동" + if (cur != null) " ($cur)" else ""
            addView(settingsRow("화질", v, false, true) { renderSettingsPage("quality") })
        }
        if (audio.size > 1) {
            addView(settingsRow("음성", audio.firstOrNull { it.selected }?.label, false, true) { renderSettingsPage("audio") })
        }
        run {
            val off = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || text.none { it.selected }
            val v = when {
                liveCap != null -> "실시간 켬"
                text.isEmpty() -> "끔"
                off -> "끔"
                else -> text.firstOrNull { it.selected }?.label
            }
            addView(settingsRow("자막", v, false, true) { renderSettingsPage("subs") })
        }
        addView(settingsRow("재생 속도", speedLabel(player.playbackParameters.speed), false, true) { renderSettingsPage("speed") })
        addView(settingsRow("화면 비율", resizeNames[resizeIdx], false, true) { renderSettingsPage("resize") })
        addView(settingsRow("동영상 저장", null, false, false) {
            settingsClose()
            saveVideo()
        })
    }

    private fun renderSettingsPage(kind: String): Unit = settingsShow {
        val back: () -> Unit = { settingsDir = -1; renderSettingsMain() }
        when (kind) {
            "quality" -> {
                addView(settingsHeader("화질", back))
                addView(settingsRow("자동", null, !hasVideoOverride(), false) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_VIDEO).build()
                    settingsClose("화질: 자동")
                })
                for (o in trackOpts(C.TRACK_TYPE_VIDEO)) {
                    addView(settingsRow(o.label, null, hasVideoOverride() && o.selected, false) {
                        applyTrack(C.TRACK_TYPE_VIDEO, o)
                        settingsClose("화질: ${o.label}")
                    })
                }
            }
            "audio" -> {
                addView(settingsHeader("음성", back))
                for (o in trackOpts(C.TRACK_TYPE_AUDIO)) {
                    addView(settingsRow(o.label, null, o.selected, false) {
                        applyTrack(C.TRACK_TYPE_AUDIO, o)
                        settingsClose("음성: ${o.label}")
                    })
                }
            }
            "subs" -> {
                addView(settingsHeader("자막", back))
                // 실시간 자막: 소리를 듣고 바로 만들어 주는 자막 (켜고 끄기)
                val liveOn = liveCap != null
                addView(settingsHeader("실시간 자막", null))
                addView(settingsRow("실시간 자막", if (liveOn) "켬" else "끔", liveOn, false) {
                    toggleLiveCaption()
                    // 켜지 못했으면(키 없음·권한 요청 등) 안내 문구가 보이게 창을 닫는다
                    if (!liveOn && liveCap == null) settingsClose() else renderSettingsPage("subs")
                })
                // 방식: 키가 있어도 키 없이 되는 '기기 안 인식'을 고를 수 있다
                val hasKey = prefs.geminiKey.isNotBlank()
                val langName = liveLangs.firstOrNull { it.first == prefs.liveLang }?.second ?: prefs.liveLang
                addView(settingsRow("Gemini", if (hasKey) "정확해요" else "키 필요", liveModeEff() == 0, false) {
                    if (!hasKey) {
                        settingsClose("Gemini 는 설정에서 API 키를 넣어야 해요")
                        return@settingsRow
                    }
                    if (prefs.liveMode != 0) {
                        prefs.liveMode = 0
                        if (liveCap != null) stopLiveCaption()
                    }
                    renderSettingsPage("subs")
                })
                addView(settingsRow("기기 안 인식 (키 없이)", langName, liveModeEff() == 1, true) { renderSettingsPage("livemode") })

                val opts = trackOpts(C.TRACK_TYPE_TEXT)
                if (opts.isNotEmpty()) {
                    addView(settingsHeader("영상 자막", null))
                    val off = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || opts.none { it.selected }
                    addView(settingsRow("끔", null, off, false) {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                        settingsClose("자막을 껐어요")
                    })
                    for (o in opts) {
                        addView(settingsRow(o.label, null, !off && o.selected, false) {
                            applyTrack(C.TRACK_TYPE_TEXT, o)
                            settingsClose("자막: ${o.label}")
                        })
                    }
                    addView(settingsHeader("자막 번역", null))
                    val names = arrayOf("번역 안 함", "한국어로 번역", "번역 + 원문")
                    for (m in 0..2) {
                        addView(settingsRow(names[m], null, prefs.subTranslateMode == m, false) {
                            prefs.subTranslateMode = m
                            subChip.text = subChipLabel()
                            handleCues(lastCues)
                            settingsClose(names[m])
                        })
                    }
                }
            }
            "livemode" -> {
                addView(settingsHeader("기기 안 인식 · 언어", { settingsDir = -1; renderSettingsPage("subs") }))
                for ((code, name) in liveLangs) {
                    addView(settingsRow("기기 안 인식 · $name", null, liveModeEff() == 1 && prefs.liveLang == code, false) {
                        prefs.liveMode = 1
                        prefs.liveLang = code
                        if (liveCap != null) stopLiveCaption()
                        renderSettingsPage("subs")
                    })
                }
            }
            "speed" -> {
                addView(settingsHeader("재생 속도", back))
                val cur = player.playbackParameters.speed
                for (sp in speeds) {
                    addView(settingsRow(if (sp == 1f) "보통 (1x)" else speedLabel(sp), null, abs(sp - cur) < 0.01f, false) {
                        player.setPlaybackSpeed(sp)
                        settingsClose("${speedLabel(sp)} 배속")
                    })
                }
            }
            "resize" -> {
                addView(settingsHeader("화면 비율", back))
                for (i in resizeNames.indices) {
                    addView(settingsRow(resizeNames[i], null, i == resizeIdx, false) {
                        resizeIdx = i
                        playerView.resizeMode = resizeModes[i]
                        settingsClose(resizeNames[i])
                    })
                }
            }
            else -> {}
        }
    }

    // ───────────────────────── 화면 구성 ─────────────────────────

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val accent = getColor(R.color.ev_accent)

        playerView = (layoutInflater.inflate(R.layout.ev_player_view, null) as PlayerView).apply {
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            controllerShowTimeoutMs = 3000
            controllerHideOnTouch = false // 탭으로 보이기/숨기기는 setupGestures 에서 직접 처리
            setShowSubtitleButton(true)
            setShowRewindButton(true)
            setShowFastForwardButton(true)
            setShowPreviousButton(false)
            setShowNextButton(false)
            keepScreenOn = true
        }
        root.addView(playerView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        styleController(accent)

        // 번역 자막: 영상 아래쪽에 겹쳐 그린다 (터치는 그대로 아래 영상으로 통과)
        subMain = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(dp(3).toFloat(), 0f, 0f, Color.BLACK)
        }
        subOrig = TextView(this).apply {
            setTextColor(0xCCFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            setShadowLayer(dp(3).toFloat(), 0f, 0f, Color.BLACK)
            visibility = View.GONE
        }
        subOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(0x99000000.toInt())
            }
            visibility = View.GONE
            addView(subMain)
            addView(subOrig)
        }
        root.addView(
            subOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply {
                bottomMargin = dp(28)
                marginStart = dp(32)
                marginEnd = dp(32)
            }
        )

        // 컨트롤: 위·아래만 어두워지는 그라데이션(밝은 영상 위에서도 글자가 보이게), 진행 막대는 앱 포인트 색
        (playerView.findViewById<View>(androidx.media3.ui.R.id.exo_progress) as? DefaultTimeBar)?.apply {
            setPlayedColor(accent)
            setScrubberColor(accent)
            setBufferedColor(0x59FFFFFF)
            setUnplayedColor(0x40FFFFFF)
        }

        // 위쪽 바: 뒤로 / 제목·사이트 / 회전 / PiP  (컨트롤이 보일 때만 보인다)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        // 시안 A: 동그라미 배경 없이 아이콘만 (눌림 효과만 준다)
        fun iconBtn(res: Int, desc: String, pad: Int, onClick: () -> Unit) = ImageButton(this).apply {
            setImageResource(res)
            setColorFilter(Color.WHITE)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            background = null
            contentDescription = desc
            setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
            setOnClickListener { onClick() }
            Motion.pressable(this, 0.86f)
        }
        fun lp(w: Int, h: Int, start: Int = 0) =
            LinearLayout.LayoutParams(w, h).apply { marginStart = dp(start) }

        bar.addView(iconBtn(R.drawable.ic_back, "닫기", 8) { finish() }, lp(dp(40), dp(40)))

        val host = runCatching { android.net.Uri.parse(intent.getStringExtra(EXTRA_URL)).host }
            .getOrNull().orEmpty().removePrefix("www.")
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        titleCol.addView(MarqueeTextView(this).apply {
            text = title.ifBlank { host.ifBlank { "동영상" } }
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        bar.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })

        liveChip = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(64)
            setPadding(dp(12), 0, dp(12), 0)
            text = "실시간 끔"
            alpha = 0.7f
            contentDescription = "실시간 자막"
            setOnClickListener { toggleLiveCaption() }
            setOnLongClickListener { chooseLiveMode(); true }
            Motion.pressable(this, 0.92f)
        }

        subChip = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(64)
            setPadding(dp(12), 0, dp(12), 0)
            text = subChipLabel()
            contentDescription = "자막 번역"
            visibility = View.GONE // 영상에 자막 트랙이 있을 때만 보인다
            setOnClickListener { cycleSubTranslate() }
            Motion.pressable(this, 0.92f)
        }

        speedChip = playerView.findViewById<TextView>(R.id.ev_speed_chip).apply {
            setOnClickListener { cycleSpeed() }
            Motion.pressable(this, 0.92f)
        }
        // CC: 자막 설정(자막 켜기·번역·실시간 자막)을 바로 연다
        playerView.findViewById<View>(R.id.ev_cc_chip)?.apply {
            setOnClickListener { openSettings(); renderSettingsPage("subs") }
            Motion.pressable(this, 0.92f)
        }
        updateSpeedChip(1f)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            bar.addView(iconBtn(R.drawable.ic_pip, "작은 창으로 보기", 9) { enterPip() }, lp(dp(40), dp(40)))
        }
        bar.addView(iconBtn(R.drawable.ic_rotate, "화면 회전", 9) { toggleOrientation() }, lp(dp(40), dp(40)))
        topBar = bar
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            // 컨트롤(진행 막대)이 보이면 번역 자막이 가리지 않게 위로 올린다
            subOverlay.animate().cancel()
            subOverlay.animate().translationY(if (v == View.VISIBLE) -dp(64).toFloat() else 0f).setDuration(180).start()
            animateTopBar(v == View.VISIBLE)
        })
        // 노치(카메라 구멍)가 있는 쪽은 버튼이 가리지 않게 비워 둔다
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val c = insets.getInsets(WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.systemBars())
            topBar.setPadding(dp(10) + c.left, dp(10) + c.top, dp(10) + c.right, dp(10))
            applyControlInsets(c.left, c.right, c.bottom)
            insets
        }

        // 가운데 표시창 (밝기·볼륨·시간 이동 등)
        osd = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xCC000000.toInt())
                setStroke(dp(1), 0x1FFFFFFF)
            }
            visibility = View.GONE
        }
        root.addView(osd, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        // 재생 오류 화면: 안내 + 다시 시도
        errorText = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            setLineSpacing(dp(3).toFloat(), 1f)
            maxWidth = minOf(dp(320), resources.displayMetrics.widthPixels - dp(96))
        }
        val retry = Button(this).apply {
            text = "다시 시도"
            isAllCaps = false
            stateListAnimator = null
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(accent)
            }
            setPadding(dp(24), 0, dp(24), 0)
            setOnClickListener {
                errorBox.visibility = View.GONE
                if (ytId != null && (ytFailed || ytInfo == null)) {
                    // 유튜브: 재생 주소부터 처음부터 다시 받는다
                    startYouTube(maxOf(retryPos, player.currentPosition))
                } else {
                    player.prepare()
                    player.playWhenReady = true
                }
            }
        }
        errorBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(22), dp(28), dp(22))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xE6121212.toInt())
                setStroke(dp(1), 0x1FFFFFFF)
            }
            visibility = View.GONE
            addView(errorText)
            addView(retry, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { topMargin = dp(16) })
        }
        root.addView(errorBox, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        setContentView(root)
        setupGestures()
    }

    /** 컨트롤 버튼에 눌림 효과(스프링)를 주고, 로딩 표시를 앱 포인트 색으로 */
    private fun styleController(accent: Int) {
        fun byName(name: String): View? {
            val id = resources.getIdentifier(name, "id", packageName)
            return if (id != 0) playerView.findViewById<View>(id) else null
        }
        for (n in listOf("exo_play_pause", "exo_rew", "exo_ffwd", "exo_settings")) {
            byName(n)?.let { Motion.pressable(it, 0.88f) }
        }
        for (n in listOf("exo_position", "exo_duration")) {
            (byName(n) as? TextView)?.apply {
                fontFeatureSettings = "tnum" // 숫자 폭을 맞춰서 흐를 때 흔들리지 않게
                setShadowLayer(dp(2).toFloat(), 0f, 0f, 0xAA000000.toInt())
            }
        }
        (byName("exo_buffering") as? android.widget.ProgressBar)?.indeterminateTintList =
            android.content.res.ColorStateList.valueOf(accent)
    }

    /** 아래 컨트롤이 노치·제스처 바에 가려지지 않게 인셋만큼 띄운다 */
    private fun applyControlInsets(left: Int, right: Int, bottom: Int) {
        fun byName(name: String): View? {
            val id = resources.getIdentifier(name, "id", packageName)
            return if (id != 0) playerView.findViewById<View>(id) else null
        }
        byName("exo_bottom_bar")?.setPadding(dp(10) + left, 0, dp(12) + right, dp(8) + bottom)
        (byName("exo_progress"))?.let { tb ->
            (tb.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
                lp.marginStart = dp(14) + left
                lp.marginEnd = dp(14) + right
                lp.bottomMargin = dp(38) + bottom
                tb.layoutParams = lp
            }
        }
    }

    /** 위쪽 바가 위에서 살짝 내려오며 나타나고, 사라질 땐 위로 올라가며 흐려진다 */
    private fun animateTopBar(show: Boolean) {
        topBar.animate().cancel()
        if (show) {
            if (topBar.visibility != View.VISIBLE) {
                topBar.alpha = 0f
                topBar.translationY = -dp(12).toFloat()
                topBar.visibility = View.VISIBLE
            }
            topBar.animate().alpha(1f).translationY(0f).setDuration(200)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f)).start()
        } else {
            topBar.animate().alpha(0f).translationY(-dp(8).toFloat()).setDuration(180)
                .withEndAction { if (topBar.alpha <= 0.01f) topBar.visibility = View.GONE }.start()
        }
    }

    // ───────────────────────── 배속 / 화면 비율 ─────────────────────────

    private fun speedLabel(v: Float) = if (v % 1f == 0f) "${v.toInt()}x" else "${v}x"

    private fun updateSpeedChip(speed: Float) {
        speedChip.text = speedLabel(speed)
        // 1배속이 아니면 포인트 색으로 눈에 띄게
        val bg = if (abs(speed - 1f) < 0.01f) 0x29FFFFFF else getColor(R.color.ev_accent)
        speedChip.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(bg)
        }
    }

    private fun cycleSpeed() {
        val cur = player.playbackParameters.speed
        val i = speeds.indexOfFirst { abs(it - cur) < 0.01f }
        val next = if (i < 0) 1f else speeds[(i + 1) % speeds.size]
        player.setPlaybackSpeed(next)
        showOsd("${speedLabel(next)} 배속")
    }

    private fun cycleResize() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        playerView.resizeMode = resizeModes[resizeIdx]
        showOsd(resizeNames[resizeIdx])
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(java.util.Locale.US, "%d:%02d", m, sec)
    }

    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scrollMode = 0
                seekStart = player.currentPosition
                seekTarget = -1L
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController() else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val left = e.x < playerView.width / 2f
                val dir = if (left) -1 else 1
                // 같은 쪽을 연달아 두 번 탭하면 20초, 30초… 로 쌓여서 표시
                val now = SystemClock.uptimeMillis()
                tapAcc = if (dir == tapDir && now - lastTapAt < 900) tapAcc + 10 else 10
                tapDir = dir
                lastTapAt = now
                val target = (player.currentPosition + dir * 10_000L)
                    .coerceIn(0L, if (player.duration > 0) player.duration else Long.MAX_VALUE)
                player.seekTo(target)
                showOsd(
                    if (left) "‹‹  ${tapAcc}초" else "${tapAcc}초  ››", 700,
                    if (left) Gravity.CENTER_VERTICAL or Gravity.START else Gravity.CENTER_VERTICAL or Gravity.END
                )
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!player.isPlaying) return
                longPressing = true
                playerView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                prevSpeed = player.playbackParameters.speed
                player.playbackParameters = PlaybackParameters(2f)
                showOsd("››  2배속", 100_000)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || longPressing) return false
                if (scrollMode == 0) {
                    scrollMode = if (abs(dy) > abs(dx)) 1 else 2
                }
                if (scrollMode == 2) {
                    // 가로로 쓸어서 시간 이동 (화면 폭 전체 = 최대 2분). 손을 떼면 그 위치로 이동
                    val dur = player.duration
                    if (dur <= 0 || !player.isCurrentMediaItemSeekable) return false
                    val total = e2.x - e1.x
                    val span = minOf(dur, 120_000L)
                    seekTarget = (seekStart + total / playerView.width.coerceAtLeast(1) * span).toLong().coerceIn(0L, dur)
                    val diff = (seekTarget - seekStart) / 1000
                    showOsd("${fmt(seekTarget)} / ${fmt(dur)}\n${if (diff >= 0) "+" else ""}${diff}초", 1500)
                    return true
                }
                // 세로로 쓸어도 아무 동작 없음 (밝기·음량 조절 제거)
                return false
            }
        })
        playerView.setOnTouchListener { v, ev ->
            val handled = detector.onTouchEvent(ev)
            if ((ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL)) {
                if (longPressing) {
                    longPressing = false
                    player.playbackParameters = PlaybackParameters(prevSpeed)
                    ui.removeCallbacks(hideOsd)
                    fadeOutOsd()
                }
                if (ev.actionMasked == MotionEvent.ACTION_UP && seekTarget >= 0) {
                    player.seekTo(seekTarget)
                    ui.removeCallbacks(hideOsd)
                    ui.postDelayed(hideOsd, 500)
                }
                seekTarget = -1L
                // v.performClick() 를 부르지 않는다: PlayerView 가 클릭을 받으면 스스로 컨트롤을 껐다 켜서,
                // 아래 onSingleTapConfirmed 의 토글과 겹쳐 한 번 눌러도 버튼이 다시 나타났다 (표시/숨김은 우리 쪽에서만 한다)
            }
            handled
        }
    }

    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    private fun showOsd(text: String, hideAfterMs: Long = 700, gravity: Int = Gravity.CENTER) {
        (osd.layoutParams as FrameLayout.LayoutParams).let { lp ->
            if (lp.gravity != gravity) {
                lp.gravity = gravity
                lp.marginStart = if ((gravity and Gravity.START) == Gravity.START) dp(56) else 0
                lp.marginEnd = if ((gravity and Gravity.END) == Gravity.END) dp(56) else 0
                osd.layoutParams = lp
            }
        }
        osd.text = text
        ui.removeCallbacks(hideOsd)
        if (osd.visibility != View.VISIBLE || osd.alpha < 1f) {
            // 톡 하고 커지며 나타난다
            osd.animate().cancel()
            if (osd.visibility != View.VISIBLE) {
                osd.alpha = 0f
                osd.scaleX = 0.9f
                osd.scaleY = 0.9f
            }
            osd.visibility = View.VISIBLE
            osd.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
        ui.postDelayed(hideOsd, hideAfterMs)
    }

    private fun fadeOutOsd() {
        osd.animate().cancel()
        osd.animate().alpha(0f).scaleX(0.95f).scaleY(0.95f).setDuration(160)
            .withEndAction { if (osd.alpha <= 0.01f) osd.visibility = View.GONE }.start()
    }

    private fun toggleOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        landscapeLocked = true
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    // ───────────────────────── PiP ─────────────────────────

    /** PiP 작은 창에 시스템이 그려 주는 재생/일시정지 버튼 */
    private val pipActionName by lazy { "$packageName.PLAYER_PIP_TOGGLE.${System.identityHashCode(this)}" }
    private var pipReceiver: android.content.BroadcastReceiver? = null

    private fun registerPipReceiver() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || pipReceiver != null) return
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (!::player.isInitialized) return
                if (player.isPlaying) player.pause() else player.play()
            }
        }
        try {
            androidx.core.content.ContextCompat.registerReceiver(
                this, r, android.content.IntentFilter(pipActionName), androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
            )
            pipReceiver = r
        } catch (e: Exception) {
            // 무시
        }
    }

    private fun pipParams(): PictureInPictureParams {
        registerPipReceiver()
        val playing = ::player.isInitialized && player.isPlaying
        val b = PictureInPictureParams.Builder().setAspectRatio(videoRatio)
        val label = if (playing) "일시정지" else "재생"
        val pi = android.app.PendingIntent.getBroadcast(
            this, 0, Intent(pipActionName).setPackage(packageName),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icon = android.graphics.drawable.Icon.createWithResource(
            this, if (playing) R.drawable.ic_pip_pause else R.drawable.ic_pip_play
        )
        b.setActions(listOf(android.app.RemoteAction(icon, label, label, pi)))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) b.setAutoEnterEnabled(playing)
        return b.build()
    }

    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            setPictureInPictureParams(pipParams())
        } catch (e: Exception) {
            // 무시
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            enterPictureInPictureMode(pipParams())
        } catch (e: Exception) {
            // 무시
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && ::player.isInitialized && player.isPlaying) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        playerView.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            osd.visibility = View.GONE
        } else if (!lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            // 작은 창의 X 로 닫은 경우
            player.pause()
            finish()
        }
    }

    // ───────────────────────── 수명 주기 ─────────────────────────

    override fun onStart() {
        super.onStart()
        if (bgServiceOn) {
            bgServiceOn = false
            MediaBridge.playerStop = null
            MediaService.stop(this)
        }
    }

    /** 보던 위치를 기억해 둔다 (끝부분이거나 라이브면 지운다) */
    private fun savePosition() {
        if (!::player.isInitialized || resumeKey.isEmpty()) return
        val dur = player.duration
        val pos = player.currentPosition
        val sp = getSharedPreferences("player_pos", Context.MODE_PRIVATE)
        val e = sp.edit()
        if (dur > 0 && pos > 5_000L && pos < dur - 10_000L) {
            if (sp.all.size > 200) e.clear()
            e.putLong(resumeKey, pos)
        } else {
            e.remove(resumeKey)
        }
        e.apply()
    }

    override fun onStop() {
        super.onStop()
        savePosition()
        if (!::player.isInitialized || isInPictureInPictureMode) return
        if (prefs.backgroundAudio && player.isPlaying && !isFinishing) {
            // 화면을 끄거나 앱을 나가도 소리는 계속 (알림의 '정지' 로 멈춤)
            bgServiceOn = true
            MediaBridge.playerStop = { ui.post { player.pause() } }
            MediaBridge.openTabId = 0
            MediaService.start(this, title.ifBlank { "재생 중" }, "내장 플레이어")
        } else {
            player.pause()
        }
    }

    override fun onDestroy() {
        settingsDlg?.dismiss()
        pipReceiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        pipReceiver = null
        savePosition()
        ui.removeCallbacks(hideOsd)
        ui.removeCallbacks(liveNextRun)
        pcmTap.sink = null
        liveCap?.stop()
        liveCap = null
        subTranslator.cancel()
        subExec.shutdownNow()
        if (bgServiceOn) {
            MediaBridge.playerStop = null
            MediaService.stop(this)
        }
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
