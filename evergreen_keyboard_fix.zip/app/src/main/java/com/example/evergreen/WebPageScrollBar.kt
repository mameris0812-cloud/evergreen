package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.webkit.WebView
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors
import kotlin.math.max
import kotlin.math.roundToInt

/** A draggable scrollbar overlay that controls the currently visible WebView. */
class WebPageScrollBar(context: Context) : View(context) {
    private var target: WebView? = null
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trackRect = RectF()
    private val thumbRect = RectF()
    private var dragging = false
    private var dragOffset = 0f
    private var lastMaxScroll = 0

    private val density = resources.displayMetrics.density
    private fun dp(value: Float) = value * density

    init {
        isClickable = true
        isFocusable = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        contentDescription = "웹페이지 스크롤바"
        refresh()
    }

    fun bind(webView: WebView?) {
        target = webView
        dragging = false
        refresh()
        postInvalidateOnAnimation()
    }

    /** Call after scroll, page load, or a WebView size change. */
    fun refresh() {
        val web = target
        val maxScroll = web?.let { max(0, (it.contentHeight * it.scale).roundToInt() - it.height) } ?: 0
        lastMaxScroll = maxScroll
        val shouldShow = web != null && web.height > 0 && maxScroll > dp(2f).roundToInt()
        val newVisibility = if (shouldShow) VISIBLE else GONE
        if (visibility != newVisibility) visibility = newVisibility
        if (shouldShow) invalidate()
    }

    private fun metrics(): Triple<Float, Float, Float> {
        val inset = dp(10f)
        val trackTop = inset
        val trackHeight = max(0f, height - inset * 2f)
        val web = target
        val contentHeight = web?.let { (it.contentHeight * it.scale).toFloat() } ?: 0f
        val viewportHeight = web?.height?.toFloat() ?: 0f
        val ratio = if (contentHeight > 0f) (viewportHeight / contentHeight).coerceIn(0f, 1f) else 1f
        val minThumb = minOf(dp(38f), trackHeight)
        val thumbHeight = (trackHeight * ratio).coerceIn(minThumb, trackHeight)
        return Triple(trackTop, trackHeight, thumbHeight)
    }

    private fun thumbTop(trackTop: Float, trackHeight: Float, thumbHeight: Float): Float {
        val web = target ?: return trackTop
        val travel = max(0f, trackHeight - thumbHeight)
        val maxScroll = max(1, lastMaxScroll)
        val fraction = (web.scrollY.toFloat() / maxScroll).coerceIn(0f, 1f)
        return trackTop + travel * fraction
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        refresh()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val web = target ?: return
        val (top, trackHeight, thumbHeight) = metrics()
        if (trackHeight <= 0f || lastMaxScroll <= 0) return

        val railWidth = dp(3f)
        val thumbWidth = dp(if (dragging) 6f else 5f)
        val right = width - dp(7f)
        val centerX = right - thumbWidth / 2f
        val railLeft = centerX - railWidth / 2f
        val railTop = top
        val railBottom = top + trackHeight

        val onSurface = MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, 0xFF777777.toInt())
        val primary = MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimary, 0xFF555555.toInt())
        trackPaint.color = ColorUtils.setAlphaComponent(onSurface, 48)
        thumbPaint.color = ColorUtils.setAlphaComponent(primary, if (dragging) 235 else 190)

        canvas.drawRoundRect(railLeft, railTop, railLeft + railWidth, railBottom, railWidth, railWidth, trackPaint)
        val y = thumbTop(top, trackHeight, thumbHeight)
        thumbRect.set(centerX - thumbWidth / 2f, y, centerX + thumbWidth / 2f, y + thumbHeight)
        canvas.drawRoundRect(thumbRect, thumbWidth, thumbWidth, thumbPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val web = target ?: return false
        if (lastMaxScroll <= 0) return false
        val (top, trackHeight, thumbHeight) = metrics()
        if (trackHeight <= 0f) return false
        val currentTop = thumbTop(top, trackHeight, thumbHeight)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                dragOffset = if (event.y in currentTop..(currentTop + thumbHeight)) {
                    event.y - currentTop
                } else {
                    thumbHeight / 2f
                }
                moveTo(event.y, top, trackHeight, thumbHeight)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                moveTo(event.y, top, trackHeight, thumbHeight)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) return false
                moveTo(event.y, top, trackHeight, thumbHeight)
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
                return true
            }
        }
        return true
    }

    private fun moveTo(y: Float, trackTop: Float, trackHeight: Float, thumbHeight: Float) {
        val web = target ?: return
        val travel = max(1f, trackHeight - thumbHeight)
        val thumbTop = (y - dragOffset).coerceIn(trackTop, trackTop + travel)
        val fraction = ((thumbTop - trackTop) / travel).coerceIn(0f, 1f)
        val maxScroll = max(0, (web.contentHeight * web.scale).roundToInt() - web.height)
        lastMaxScroll = maxScroll
        web.scrollTo(web.scrollX, (fraction * maxScroll).roundToInt())
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
