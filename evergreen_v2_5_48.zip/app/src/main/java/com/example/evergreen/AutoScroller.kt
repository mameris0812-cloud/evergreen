package com.example.evergreen

import android.app.Activity
import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.MaterialColors

/**
 * 웹 페이지를 저절로 아래로 스크롤해 주는 기능 (웹툰·긴 글을 손 안 대고 볼 때).
 *
 * - 화면 프레임(Choreographer)마다 지난 시간만큼 계산한 거리를 WebView 에 스크롤한다. 속도는 설정의 「자동 스크롤 속도」.
 * - 화면 아래에 작은 조작 막대(느리게 / 속도 / 빠르게 / 정지)를 띄운다 (설정에서 끌 수 있음).
 *   블러 없는 불투명한 알약 모양이고([DragPillLayout]), 왼쪽 X 는 자동 스크롤을 끝내고 막대를 닫고,
 *   오른쪽 ▮▮ 는 막대를 연 채로 일시정지/이어가기를 번갈아 한다. −/+ 는 꾹 누르면 계속 바뀐다.
 *   위쪽의 가는 손잡이를 아래로 끌면(막대 어디든 가능) 막대가 아래로 내려가 완전히 숨는다 (숨긴 뒤에는 아무것도 남지 않는다).
 *   다시 보려면 화면 아래 가운데에서 위로 쓸어 올린다.
 * - 웹 화면을 손가락으로 만지면 설정에 따라 '만지는 동안 잠깐 멈춤' 또는 '완전히 멈춤'.
 * - 다른 탭·탭 화면·전체화면·새 페이지 이동·앱 나가기에서는 저절로 멈춘다.
 * - 페이지 끝에 닿은 채로 잠깐(이미지가 더 불러와질 시간) 지나면 멈춘다.
 */
class AutoScroller(
    private val act: Activity,
    private val prefs: Prefs,
    /** 이 WebView 에서 자동 스크롤을 계속해도 되는 상황인지 (현재 탭인지, 탭 화면·전체화면이 아닌지) */
    private val allowed: (WebView) -> Boolean,
    /** 창 아래에서 띄울 높이(px). 아래 막대가 보이면 그 위, 없으면 0 */
    private val liftProvider: () -> Int,
    private val notify: (String) -> Unit
) {
    companion object {
        const val MIN_LEVEL = 1
        const val MAX_LEVEL = 20
        const val DEFAULT_LEVEL = 6

        /** 단계 → 초당 dp. 1단계 = 25dp/초 (아주 천천히), 20단계 = 500dp/초 */
        fun dpPerSecond(level: Int): Float = 25f * level.coerceIn(MIN_LEVEL, MAX_LEVEL)

        /** 손가락을 떼고 이만큼(ms) 지나서 다시 흐른다 (뗀 뒤 이어지는 관성 스크롤이 가라앉을 시간) */
        private const val RESUME_DELAY_MS = 500L

        /** 끝에 닿은 채 이만큼(ms) 지나면 멈춘다 */
        private const val END_HOLD_MS = 1500L

        private const val PILL_TAG = "evergreen_auto_scroll_pill"
    }

    private val density = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private var target: WebView? = null
    private var running = false
    private var touching = false
    private var resumeAt = 0L
    private var lastNanos = 0L
    private var carry = 0f
    private var endSince = 0L
    private var everMoved = false
    /** 사용자가 막대의 일시정지 버튼으로 멈춰 둔 상태 (막대는 그대로 열려 있다) */
    private var userPaused = false
    private var frames = 0

    private var pill: DragPillLayout? = null
    private var levelText: TextView? = null
    private var pauseBtn: ImageView? = null
    private var pauseIcon: PlayPauseDrawable? = null
    private var slowerBtn: View? = null
    private var fasterBtn: View? = null
    private val ui = Handler(Looper.getMainLooper())
    /** −/+ 를 꾹 누르는 동안 계속 바꾸는 반복 */
    private var repeat: Runnable? = null
    /** 막대를 내려서 숨긴 상태인지 (새로 시작할 때마다 다시 보이게 돌려 둔다) */
    private var collapsed = false
    /** 숨긴 막대를 다시 불러내는 쓸어올리기를 따라가는 중인지 / 처음 닿은 곳 */
    private var restoreTracking = false
    private var restoreX = 0f
    private var restoreY = 0f
    /** 숨기는 방법·다시 보는 방법 안내는 한 번만 띄운다 */
    private var hintShown = false

    val isRunning: Boolean get() = running

    fun isRunningOn(wv: WebView?): Boolean = running && wv != null && wv === target

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) = onFrame(frameTimeNanos)
    }

    fun start(wv: WebView) {
        if (running && target === wv) return
        stop(null)
        target = wv
        running = true
        touching = false
        resumeAt = 0L
        lastNanos = 0L
        carry = 0f
        endSince = 0L
        everMoved = false
        userPaused = false
        frames = 0
        collapsed = false
        if (prefs.autoScrollControls) showPill()
        notify("자동 스크롤을 시작했어요")
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    /** 설정에서 조작 막대를 켜거나 껐을 때: 흐르는 중이면 막대만 바로 보이거나 치운다 (스크롤은 그대로) */
    fun applyControlsSetting() {
        if (!running) return
        if (prefs.autoScrollControls) { if (pill == null) showPill() } else removePill()
    }

    /** 멈춘다. [message] 가 있으면 안내를 띄운다 */
    fun stop(message: String?) {
        val was = running
        running = false
        target = null
        touching = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        removePill()
        if (was && message != null) notify(message)
    }

    private fun onFrame(nanos: Long) {
        val wv = target
        if (!running || wv == null) return
        if (act.isFinishing || act.isDestroyed || !wv.isAttachedToWindow || !allowed(wv)) {
            stop(null)
            return
        }
        val dt = if (lastNanos == 0L) 0f else ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNanos = nanos

        val now = SystemClock.uptimeMillis()
        if (!userPaused && !touching && now >= resumeAt) {
            carry += dpPerSecond(prefs.autoScrollSpeed) * density * dt
            val dy = carry.toInt()
            if (dy > 0) {
                carry -= dy
                val before = wv.scrollY
                wv.scrollBy(0, dy)
                if (wv.scrollY != before) {
                    everMoved = true
                    endSince = 0L
                } else {
                    // 더 못 내려간다: 이미지가 더 불러와질 수 있으니 잠깐 기다려 본다
                    if (endSince == 0L) endSince = now
                    else if (now - endSince >= END_HOLD_MS) {
                        stop(if (everMoved) "페이지 끝에 닿아 자동 스크롤을 멈췄어요" else "이 페이지는 자동으로 스크롤할 수 없어요")
                        return
                    }
                }
            }
        }
        // 아래 막대가 나타나고 사라지는 만큼 조작 막대 높이를 맞춘다
        if (++frames % 15 == 0) placePill()
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    /** 액티비티의 dispatchTouchEvent 에서 모든 터치를 넘겨 받는다 (조작 막대 위의 터치는 건드리지 않는다) */
    fun onTouch(ev: MotionEvent) {
        if (!running) return
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                restoreTracking = false
                if (hitPill(ev) || !hitWeb(ev)) return
                // 일시정지 중에는 화면을 만져도 아무 일도 없다 (직접 스크롤해서 보다가 ▶ 로 이어간다)
                if (userPaused) return
                if (collapsed && inRestoreZone(ev)) {
                    // 숨긴 막대를 불러내려는 쓸어올리기일 수 있다: 멈추지는 않고 만지는 동안만 잠깐 쉰다
                    restoreTracking = true
                    restoreX = ev.rawX
                    restoreY = ev.rawY
                    touching = true
                    return
                }
                if (prefs.autoScrollTouch == 1) stop("자동 스크롤을 멈췄어요") else touching = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (restoreTracking) {
                    val dy = ev.rawY - restoreY
                    val dx = ev.rawX - restoreX
                    if (dy < -dp(40) && Math.abs(dy) > Math.abs(dx) * 1.2f) {
                        restoreTracking = false
                        expand(true)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                restoreTracking = false
                if (touching) {
                    touching = false
                    resumeAt = SystemClock.uptimeMillis() + RESUME_DELAY_MS
                    lastNanos = 0L
                    carry = 0f
                }
            }
        }
    }

    /**
     * 뷰가 화면에 보이는 영역을 '화면(스크린) 좌표' 로 돌려준다. ev.rawX/rawY 가 화면 좌표라서 같은 좌표계로 맞춰야 한다.
     * getGlobalVisibleRect 는 창 안의 좌표라, 분할 화면·멀티윈도우처럼 창이 화면의 (0,0) 이 아닐 때는 창 위치만큼 어긋난다.
     */
    private fun screenRect(v: View): Rect? {
        val r = Rect()
        if (!v.getGlobalVisibleRect(r)) return null
        val rootView = v.rootView
        val w = IntArray(2)
        val s = IntArray(2)
        // 뷰의 창 안 위치와 화면 위치의 차이 = 창이 화면에서 떨어진 만큼
        v.getLocationInWindow(w)
        v.getLocationOnScreen(s)
        r.offset(s[0] - w[0], s[1] - w[1])
        return if (rootView != null) r else null
    }

    /** 웹 화면 아래 가운데: 숨긴 막대를 위로 쓸어 올려 다시 보는 자리. 창 아래쪽 가장자리까지 넉넉히 잡는다 (멀티윈도우에서는 창 아래가 화면 아래가 아니다) */
    private fun inRestoreZone(ev: MotionEvent): Boolean {
        val w = target ?: return false
        val r = screenRect(w) ?: return false
        val cx = (r.left + r.right) / 2
        val x = ev.rawX.toInt(); val y = ev.rawY.toInt()
        return x in (cx - dp(110))..(cx + dp(110)) && y in (r.bottom - dp(120))..(r.bottom - dp(6))
    }

    private fun hitPill(ev: MotionEvent): Boolean {
        val v = pill ?: return false
        if (!v.isShown) return false
        val r = screenRect(v) ?: return false
        return r.contains(ev.rawX.toInt(), ev.rawY.toInt())
    }

    private fun hitWeb(ev: MotionEvent): Boolean {
        val w = target ?: return false
        val r = screenRect(w) ?: return false
        return r.contains(ev.rawX.toInt(), ev.rawY.toInt())
    }

    // ───────────────────────── 조작 막대 ─────────────────────────

    private fun root(): ViewGroup? = act.window?.decorView as? ViewGroup

    /**
     * ▮▮ ↔ ▶ 로 모양이 이어서 변하는 아이콘. 두 막대가 각각 삼각형의 왼쪽·오른쪽 조각으로 변하고,
     * 기울이거나 튕기지 않고, 거의 넘치지 않는 부드러운 스프링으로 이어서 변한다.
     */
    private class PlayPauseDrawable(tint: Int, private val density: Float) : android.graphics.drawable.Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            style = Paint.Style.FILL_AND_STROKE
            strokeJoin = Paint.Join.ROUND
        }
        private val path = android.graphics.Path()
        private var t = 0f          // 0 = ▮▮, 1 = ▶ (스프링이 넘어가면 1 을 조금 지나쳤다 돌아온다)
        private var target = 0f
        private var anim: DynamicAnimation<*>? = null

        // 24dp 격자 기준 네 꼭짓점(x,y)씩 두 조각: [왼쪽 조각, 오른쪽 조각]
        private val pause = arrayOf(
            floatArrayOf(7.5f, 5.5f, 10.5f, 5.5f, 10.5f, 18.5f, 7.5f, 18.5f),
            floatArrayOf(13.5f, 5.5f, 16.5f, 5.5f, 16.5f, 18.5f, 13.5f, 18.5f)
        )
        private val play = arrayOf(
            floatArrayOf(8f, 5.5f, 13.2f, 8.7f, 13.2f, 15.3f, 8f, 18.5f),
            floatArrayOf(13.2f, 8.7f, 18.5f, 12f, 18.5f, 12f, 13.2f, 15.3f)
        )

        fun setPlay(isPlay: Boolean, animate: Boolean) {
            target = if (isPlay) 1f else 0f
            anim?.cancel()
            if (animate) {
                anim = Motion.springValue(t, target, stiffness = 420f, damping = 0.82f, onUpdate = { t = it; invalidateSelf() })
            } else {
                t = target
                invalidateSelf()
            }
        }

        fun cancel() { anim?.cancel() }

        override fun draw(c: Canvas) {
            val b = bounds
            if (b.isEmpty) return
            val u = b.width() / 24f
            val n = c.save()
            c.translate(b.left.toFloat(), b.top.toFloat())
            c.scale(u, u)
            val prog = t.coerceIn(0f, 1f)
            // ▶ 는 시각적 무게중심이 왼쪽이라 완성될수록 오른쪽으로 조금 옮긴다
            c.translate(0.6f * prog, 0f)
            paint.strokeWidth = 1.8f
            for (i in 0..1) {
                path.rewind()
                val a = pause[i]; val e = play[i]
                for (k in 0..3) {
                    val x = a[k * 2] + (e[k * 2] - a[k * 2]) * t
                    val y = a[k * 2 + 1] + (e[k * 2 + 1] - a[k * 2 + 1]) * t
                    if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                c.drawPath(path, paint)
            }
            c.restoreToCount(n)
        }

        override fun getIntrinsicWidth() = (24 * density).toInt()
        override fun getIntrinsicHeight() = (24 * density).toInt()
        override fun setAlpha(alpha: Int) { paint.alpha = alpha; invalidateSelf() }
        override fun setColorFilter(cf: android.graphics.ColorFilter?) { paint.colorFilter = cf; invalidateSelf() }
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showPill() {
        val root = root() ?: return
        removePill()
        val fg = MaterialColors.getColor(root, com.google.android.material.R.attr.colorOnSurface, 0xFF202020.toInt())
        val accent = MaterialColors.getColor(root, com.google.android.material.R.attr.colorPrimary, 0xFF2E9E5B.toInt())
        val container = MaterialColors.getColor(root, com.google.android.material.R.attr.colorPrimaryContainer, 0xFFDDF3E4.toInt())
        val onContainer = MaterialColors.getColor(root, com.google.android.material.R.attr.colorOnPrimaryContainer, 0xFF0B3A1D.toInt())
        val webArea = act.findViewById<View>(R.id.browserUi)

        fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

        /** 동그란 물결 (바탕색이 있으면 그 위에) */
        fun circleRipple(rippleColor: Int, fill: Int?) = RippleDrawable(
            ColorStateList.valueOf(ColorUtils.setAlphaComponent(rippleColor, 0x33)),
            fill?.let { oval(it) }, oval(Color.BLACK)
        )

        fun iconButton(res: Int, desc: String, tint: Int, fill: Int?, pad: Int) = ImageView(act).apply {
            setImageResource(res)
            setColorFilter(tint)
            contentDescription = desc
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
            isClickable = true
            isFocusable = true
            background = circleRipple(tint, fill)
        }

        // −/+ : 누르면 쏙 들어가고, 꾹 누르면 계속 바뀐다 (떼거나 끌기로 넘어가면 멈춘다)
        fun stepButton(res: Int, desc: String, delta: Int): ImageView = iconButton(res, desc, fg, null, 9).apply {
            setOnClickListener { changeLevel(delta) }
            setOnLongClickListener {
                startRepeat(delta)
                true
            }
            Motion.pressable(this, pressedScale = 0.86f, extra = { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) stopRepeat()
                false
            })
        }

        val slower = stepButton(R.drawable.ic_remove, "느리게", -1)
        val faster = stepButton(R.drawable.ic_add, "빠르게", +1)
        slowerBtn = slower
        fasterBtn = faster

        // 속도: 숫자만
        val lv = TextView(act).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(accent)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            // 숫자가 바뀔 때 자리가 흔들리지 않게 숫자 폭을 같게
            fontFeatureSettings = "tnum"
        }
        levelText = lv
        val speed = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            minimumWidth = dp(40)
            contentDescription = "자동 스크롤 속도"
            addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        // 닫기: 자동 스크롤을 끝내고 막대를 치운다 (왼쪽 끝)
        val closeBtn = iconButton(R.drawable.ic_close, "자동 스크롤 끝내기", ColorUtils.setAlphaComponent(fg, 0xCC), null, 10).apply {
            setOnClickListener { stop("자동 스크롤을 멈췄어요") }
            Motion.pressable(this, pressedScale = 0.86f)
        }

        // 일시정지 ↔ 이어가기: 막대는 그대로 열어 두고 흐름만 멈췄다 잇는다. 강조 바탕의 동그란 버튼이라 −/+ 와 구분된다
        val pauseBtnView = iconButton(R.drawable.ic_pause, "일시정지", onContainer, container, 11).apply {
            setOnClickListener { togglePause() }
            Motion.pressable(this, pressedScale = 0.88f)
        }
        pauseBtn = pauseBtnView
        val pd = PlayPauseDrawable(onContainer, density)
        pauseIcon = pd
        pauseBtnView.setImageDrawable(pd)
        pauseBtnView.clearColorFilter()

        // 위쪽 가는 손잡이: 아래로 끌면 막대가 내려가 숨는다는 표시
        val grip = View(act).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(ColorUtils.setAlphaComponent(fg, 0x40))
            }
        }
        val row = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(closeBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(4) })
            addView(slower, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(speed, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)))
            addView(faster, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(pauseBtnView, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(8) })
        }

        val pillView = DragPillLayout(act).apply {
            tag = PILL_TAG
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(10), dp(0), dp(10), dp(6))
            addView(grip, LinearLayout.LayoutParams(dp(30), dp(4)).apply { topMargin = dp(6); bottomMargin = dp(2) })
            addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            // 아래로 끌면 막대가 손가락을 따라 내려가고, 충분히 내리거나 빠르게 쓸면 숨는다 (버튼 위에서 시작해도 된다)
            onDrag = { dy -> dragPill(dy) }
            onDragEnd = { dy, vy -> endDragPill(dy, vy) }
            // 앱 알림(토스트·진행 카드)보다는 아래, 일반 화면보다는 위
            AppToast.raiseToTop(this, dp(AppToast.CARD_Z_DP - 20))
        }

        pill = pillView
        refreshLevelText(animate = false)
        refreshPauseButton(animate = false)
        root.addView(pillView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ))
        placePill()
        pillView.bringToFront()
        if (collapsed) {
            pillView.visibility = View.GONE
        } else {
            // 아래에서 떠오르며 살짝 커지면서 나타난다
            Motion.enter(pillView, delayMs = 60, rise = 16f, scale = 0.94f, riseDamping = 0.8f, scaleDamping = 0.7f)
        }
    }

    /** 일시정지 ↔ 이어가기. 막대는 닫지 않는다 */
    private fun togglePause() {
        if (!running) return
        userPaused = !userPaused
        if (!userPaused) {
            // 이어갈 때: 쉬는 동안 쌓인 시간·끝 대기를 지워 갑자기 튀지 않게 한다
            lastNanos = 0L
            carry = 0f
            endSince = 0L
            touching = false
            resumeAt = 0L
        }
        pill?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        refreshPauseButton(animate = true)
    }

    private fun refreshPauseButton(animate: Boolean) {
        val b = pauseBtn ?: return
        b.contentDescription = if (userPaused) "자동 스크롤 이어가기" else "일시정지"
        val anim = animate && Motion.enabled(act)
        pauseIcon?.setPlay(userPaused, anim)
        // 버튼 전체도 살짝만 눌렀다 놓은 듯 부드럽게
        if (anim) {
            b.scaleX = 0.92f
            b.scaleY = 0.92f
            Motion.spring(b, DynamicAnimation.SCALE_X, 1f, 500f, 0.6f)
            Motion.spring(b, DynamicAnimation.SCALE_Y, 1f, 500f, 0.6f)
        }
    }

    /** −/+ 를 꾹 누른 동안 일정 간격으로 계속 바꾼다. 끝 단계에 닿으면 저절로 멈춘다 */
    private fun startRepeat(delta: Int) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                if (pill == null || !changeLevel(delta)) { repeat = null; return }
                ui.postDelayed(this, 110L)
            }
        }
        repeat = r
        r.run()
    }

    private fun stopRepeat() {
        repeat?.let { ui.removeCallbacks(it) }
        repeat = null
    }

    private fun placePill() {
        val root = root() ?: return
        val p = pill ?: return
        val lp = p.layoutParams as? FrameLayout.LayoutParams ?: return
        val bottomInset = ViewCompat.getRootWindowInsets(root)
            ?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val lift = liftProvider()
        val m = if (lift > 0) lift + dp(8) else bottomInset + dp(24)
        if (lp.bottomMargin != m) {
            lp.bottomMargin = m
            p.layoutParams = lp
        }
    }

    private fun removePill() {
        val p = pill ?: return
        stopRepeat()
        pill = null
        levelText = null
        pauseBtn = null
        pauseIcon?.cancel()
        pauseIcon = null
        slowerBtn = null
        fasterBtn = null
        Motion.cancel(p)
        p.animate().cancel()
        (p.parent as? ViewGroup)?.removeView(p)
    }

    // ───────────────────────── 내려서 숨기기 ─────────────────────────

    /** 막대를 화면 아래로 완전히 내려 보내는 데 필요한 거리 */
    private fun hideDistance(p: View): Float {
        val m = (p.layoutParams as? FrameLayout.LayoutParams)?.bottomMargin ?: 0
        return (p.height + m + dp(12)).toFloat()
    }

    /** 끄는 동안 막대가 손가락을 따라 내려가며 점점 옅어진다 (위로는 살짝만) */
    private fun dragPill(dy: Float) {
        val p = pill ?: return
        Motion.cancel(p)
        p.animate().cancel()
        p.scaleX = 1f
        p.scaleY = 1f
        if (dy >= 0f) {
            p.translationY = dy
            p.alpha = (1f - 0.5f * (dy / hideDistance(p)).coerceIn(0f, 1f))
        } else {
            p.translationY = dy * 0.12f
            p.alpha = 1f
        }
    }

    private fun endDragPill(dy: Float, vy: Float) {
        val p = pill ?: return
        if (dy > dp(36) || (dy > dp(12) && vy > 1000f)) collapse(true)
        else if (Motion.enabled(act)) {
            // 놓으면 탄성 있게 제자리로 돌아온다
            Motion.spring(p, DynamicAnimation.TRANSLATION_Y, 0f, 700f, 0.7f)
            Motion.spring(p, DynamicAnimation.ALPHA, 1f, 500f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        } else {
            p.translationY = 0f
            p.alpha = 1f
        }
    }

    /** 막대를 아래로 내려 완전히 숨긴다 (아무것도 남기지 않는다) */
    private fun collapse(animated: Boolean) {
        val p = pill ?: return
        collapsed = true
        stopRepeat()
        Motion.cancel(p)
        fun finish() {
            if (pill !== p || !collapsed) return
            p.animate().cancel()
            p.visibility = View.GONE
            p.translationY = 0f
            p.alpha = 1f
            if (!hintShown) {
                hintShown = true
                notify("화면 아래 가운데를 위로 쓸어 올리면 조작 막대가 다시 나와요")
            }
        }
        if (animated && Motion.enabled(act)) {
            p.animate().translationY(hideDistance(p)).alpha(0f).setDuration(170)
                .setInterpolator(AccelerateInterpolator()).withEndAction { finish() }.start()
        } else finish()
    }

    /** 숨긴 막대를 다시 올린다 */
    private fun expand(animated: Boolean) {
        val p = pill ?: return
        collapsed = false
        Motion.cancel(p)
        p.animate().cancel()
        p.visibility = View.VISIBLE
        p.bringToFront()
        p.scaleX = 1f
        p.scaleY = 1f
        if (animated && Motion.enabled(act)) {
            p.alpha = 0f
            p.translationY = dp(40).toFloat()
            Motion.spring(p, DynamicAnimation.TRANSLATION_Y, 0f, 380f, 0.78f)
            Motion.spring(p, DynamicAnimation.ALPHA, 1f, 400f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        } else {
            p.translationY = 0f
            p.alpha = 1f
        }
    }

    /** 단계를 바꾼다. 바뀌었으면 true, 이미 끝 단계라 그대로면 false */
    private fun changeLevel(delta: Int): Boolean {
        val next = (prefs.autoScrollSpeed + delta).coerceIn(MIN_LEVEL, MAX_LEVEL)
        if (next == prefs.autoScrollSpeed) {
            // 끝에 닿았다는 느낌만 짧게 (꾹 눌러 반복 중이면 여기서 멈춘다)
            pill?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            return false
        }
        prefs.autoScrollSpeed = next
        refreshLevelText(animate = true)
        pill?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        return true
    }

    private fun refreshLevelText(animate: Boolean) {
        val v = prefs.autoScrollSpeed
        val t = levelText
        val changed = t != null && t.text.toString() != v.toString()
        t?.text = v.toString()
        // 숫자가 바뀔 때 살짝 통통 튄다
        if (animate && changed && t != null && Motion.enabled(act)) {
            t.scaleX = 1.22f
            t.scaleY = 1.22f
            Motion.spring(t, DynamicAnimation.SCALE_X, 1f, 700f, 0.5f)
            Motion.spring(t, DynamicAnimation.SCALE_Y, 1f, 700f, 0.5f)
        }
        // 더 못 느리게/빠르게 할 때는 해당 버튼을 흐리게
        slowerBtn?.animate()?.alpha(if (v <= MIN_LEVEL) 0.3f else 1f)?.setDuration(120)?.start()
        fasterBtn?.animate()?.alpha(if (v >= MAX_LEVEL) 0.3f else 1f)?.setDuration(120)?.start()
    }
}
