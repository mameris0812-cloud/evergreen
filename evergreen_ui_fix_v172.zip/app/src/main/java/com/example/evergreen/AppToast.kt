package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.MaterialColors

/**
 * 시스템 토스트 대신 쓰는 앱 자체 알림.
 * 창 맨 위에 짧게 떴다가 사라지는 알약 모양 안내이고, 앱의 테마 색을 따른다.
 * 창(액티비티)을 못 찾을 때(서비스 등)만 시스템 토스트로 대신한다.
 */
object AppToast {
    private const val TAG = "evergreen_app_toast"
    private val main = Handler(Looper.getMainLooper())

    /** [lift] 가 0보다 크면 창 아래에서 그만큼 띄워 그린다 (아래 막대가 있을 때 그 위로 오게). 0 이면 기본 위치 */
    fun show(ctx: Context, msg: CharSequence, lift: Int = 0) {
        if (Looper.myLooper() == Looper.getMainLooper()) showNow(ctx, msg, lift) else main.post { showNow(ctx, msg, lift) }
    }

    private fun activityOf(ctx: Context): Activity? {
        var c: Context? = ctx
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return null
    }

    private fun showNow(ctx: Context, msg: CharSequence, lift: Int) {
        val act = activityOf(ctx)
        val root = act?.window?.decorView as? ViewGroup
        if (act == null || act.isFinishing || act.isDestroyed || root == null) {
            Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_SHORT).show()
            return
        }
        val d = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        // 이전 알림은 바로 치운다
        root.findViewWithTag<View>(TAG)?.let {
            it.animate().cancel()
            root.removeView(it)
        }

        val bg: Int = MaterialColors.getColor(root, com.google.android.material.R.attr.colorOnSurface, 0xFF303030.toInt())
        val fg: Int = MaterialColors.getColor(root, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val tv = TextView(act).apply {
            tag = TAG
            text = msg
            setTextColor(fg)
            textSize = 14f
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            maxWidth = (act.resources.displayMetrics.widthPixels * 0.86f).toInt().coerceAtMost(dp(480))
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = GradientDrawable().apply {
                setColor((bg and 0x00FFFFFF) or 0xF0000000.toInt())
                cornerRadius = dp(24).toFloat()
            }
            elevation = dp(8).toFloat()
        }
        val bottomInset = ViewCompat.getRootWindowInsets(root)
            ?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        root.addView(
            tv,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = if (lift > 0) lift else bottomInset + dp(88) }
        )

        val animate = Motion.enabled(act)
        val hold = (1800L + msg.length * 40L).coerceAtMost(3800L)
        if (animate) {
            tv.alpha = 0f
            tv.translationY = dp(14).toFloat()
            tv.animate().alpha(1f).translationY(0f).setDuration(180).start()
        }

        fun dismiss(dx: Float = 0f, dy: Float = dp(10).toFloat()) {
            if (tv.parent == null) return
            if (animate) {
                tv.animate().alpha(0f).translationX(dx).translationY(dy).setDuration(160)
                    .withEndAction { (tv.parent as? ViewGroup)?.removeView(tv) }.start()
            } else {
                (tv.parent as? ViewGroup)?.removeView(tv)
            }
        }
        val auto = Runnable { dismiss() }
        tv.postDelayed(auto, hold)

        // 만지고 있는 동안은 사라지지 않고, 아래나 옆으로 밀거나 톡 치면 바로 치운다
        var downX = 0f
        var downY = 0f
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    v.animate().cancel()
                    v.removeCallbacks(auto)
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    v.translationX = e.rawX - downX
                    v.translationY = (e.rawY - downY).coerceAtLeast(0f)
                    v.alpha = (1f - Math.abs(v.translationX) / (v.width * 1.2f)).coerceIn(0.3f, 1f)
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    val mx = e.rawX - downX
                    val my = e.rawY - downY
                    val tap = Math.abs(mx) < dp(8) && Math.abs(my) < dp(8)
                    when {
                        tap -> dismiss()
                        Math.abs(mx) > v.width * 0.3f -> dismiss(dx = if (mx > 0) v.width.toFloat() else -v.width.toFloat(), dy = v.translationY)
                        my > dp(36) -> dismiss(dx = v.translationX, dy = dp(60).toFloat())
                        else -> {
                            v.animate().translationX(0f).translationY(0f).alpha(1f).setDuration(140).start()
                            v.postDelayed(auto, 1500)
                        }
                    }
                    true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    v.animate().translationX(0f).translationY(0f).alpha(1f).setDuration(140).start()
                    v.postDelayed(auto, 1500)
                    true
                }
                else -> false
            }
        }
    }
}
