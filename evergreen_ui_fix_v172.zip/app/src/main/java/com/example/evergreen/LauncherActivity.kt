package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 런처 아이콘의 진입점. 보이지 않고 바로 닫힌다.
 * - 멀티윈도우·자유 창(DeX 포함)에서 이미 앱이 떠 있으면 "이미 실행 중입니다"로 막히지 않고 새 창을 하나 더 띄운다.
 * - 그 밖에는 예전처럼 떠 있는 앱을 앞으로 가져오거나(또는 새로 시작한다).
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val running = MainActivity.runningWindows().filter { !it.isFinishing && !it.isDestroyed }
        // 이미 창 모드로 떠 있는 창이 있거나, 이 진입점 자체가 창 모드(작업 표시줄·분할 화면)로 열렸으면
        // 떠 있는 창을 앞으로 가져오는 대신 새 창을 하나 더 띄운다
        val multi = running.firstOrNull { it.isInMultiWindowMode }
            ?: if (isInMultiWindowMode) running.firstOrNull() else null
        if (multi != null) {
            multi.openNewWindow()
        } else {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .setAction(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
