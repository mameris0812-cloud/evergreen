package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

/**
 * 영상이 끝났을 때 뜨는 '다음 영상' 카드 (유튜브의 끝 화면처럼).
 * - 배경은 첫 번째 영상 썸네일을 흐리게 깔아 영상 분위기를 살린다.
 * - 첫 번째 영상은 큰 카드(썸네일·제목·채널·길이)로, 나머지는 '이어서 볼 영상'으로 보여 준다.
 *   세로 화면: 카드 아래 가로 줄 / 가로 화면: 왼쪽 큰 카드 + 오른쪽 세로 목록.
 * - 자동 재생이 켜져 있으면 큰 카드 위에 카운트다운 고리가 돌고 위 알약에 남은 초가 표시된다 (취소 가능).
 * - 항목이 없는 사이트에서는 '다시 보기' / '다음 영상' 버튼만 보여 준다.
 */
class UpNextCard(ctx: Context) : FrameLayout(ctx) {

    class Item(val title: String, val author: String, val duration: String, val thumb: String)

    var onReplay: () -> Unit = {}
    var onNext: () -> Unit = {}
    var onPick: (Int) -> Unit = {}
    var onCancelAuto: () -> Unit = {}

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val accent = ctx.getColor(R.color.ev_accent)
    private val ui = Handler(Looper.getMainLooper())
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    private val bgImage = ImageView(ctx)
    private val dim = View(ctx)
    private val scroll = ScrollView(ctx)
    private val content = LinearLayout(ctx)
    private val header = TextView(ctx)
    private val ring = CountdownRing(ctx, accent)
    private var cancelChip: TextView? = null

    private var autoEndAt = 0L
    private var autoTotalMs = 0L
    private var autoCancelled = false
    private var autoShown = false
    private var sig = ""

    // 크기가 바뀌었을 때(회전·분할 화면) 다시 짜기 위해 마지막 입력을 기억한다
    private var lastItems: List<Item>? = null
    private var lastAuto = 0
    private var lastNext = false
    private var builtLand = false
    private var builtW = 0

    companion object {
        private val exec = Executors.newFixedThreadPool(3)
        private val cache = object : android.util.LruCache<String, Bitmap>(24) {}
    }

    init {
        visibility = View.GONE
        isClickable = true // 뒤쪽 영상으로 탭이 새지 않게 막는다
        setBackgroundColor(0xF0000000.toInt())

        bgImage.scaleType = ImageView.ScaleType.CENTER_CROP
        bgImage.alpha = 0f
        addView(bgImage, LayoutParams(MATCH, MATCH))

        dim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x66000000, 0xB3000000.toInt())
        )
        addView(dim, LayoutParams(MATCH, MATCH))

        scroll.isVerticalScrollBarEnabled = false
        scroll.isFillViewport = true
        scroll.overScrollMode = View.OVER_SCROLL_NEVER

        content.gravity = Gravity.CENTER
        header.apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
        }
    }

    // ───────────────────────── 작은 부품 ─────────────────────────

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun lp(w: Int, h: Int, weight: Float) = LinearLayout.LayoutParams(w, h, weight)

    private fun round(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
        if (stroke > 0) setStroke(stroke, strokeColor)
    }

    private fun chip(label: String, primary: Boolean, padH: Int = 16, onClick: () -> Unit) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 1
        setPadding(dp(padH), 0, dp(padH), 0)
        background = if (primary) round(accent, 21) else round(0x1FFFFFFF, 21, dp(1), 0x33FFFFFF)
        setOnClickListener { onClick() }
        Motion.barButton(this, "chip")
    }

    /** 누르면 살짝 작아지는 카드·줄 */
    private fun pressable(v: View, onClick: () -> Unit) {
        v.isClickable = true
        v.setOnClickListener { onClick() }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).setStartDelay(0).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(160).start()
            }
            false
        }
    }

    /** 사진을 받아 온다 (캐시에 있으면 바로) */
    private fun loadBitmap(url: String, done: (Bitmap) -> Unit) {
        if (url.isBlank()) return
        val c = cache.get(url)
        if (c != null) { done(c); return }
        exec.execute {
            val bmp = try {
                PlayerHttp.client.newCall(okhttp3.Request.Builder().url(url).build()).execute().use { r ->
                    val b = r.body
                    if (!r.isSuccessful || b == null) null else {
                        val bytes = b.bytes()
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                }
            } catch (e: Throwable) { null }
            if (bmp != null) {
                cache.put(url, bmp)
                ui.post { done(bmp) }
            }
        }
    }

    private fun thumbView(url: String, radius: Int): ImageView {
        val iv = ImageView(context)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = round(0xFF2A2A2A.toInt(), radius)
        iv.clipToOutline = true
        iv.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(radius).toFloat()) }
        }
        iv.alpha = 0f
        loadBitmap(url) { bmp ->
            iv.setImageBitmap(bmp)
            iv.animate().alpha(1f).setDuration(180).start()
        }
        if (url.isBlank()) iv.alpha = 1f
        return iv
    }

    /** 썸네일 + 오른쪽 아래 길이 표시 */
    private fun thumbWithBadge(item: Item, w: Int, h: Int, radius: Int, badgeSp: Float): FrameLayout {
        val frame = FrameLayout(context)
        frame.addView(thumbView(item.thumb, radius), FrameLayout.LayoutParams(w, h))
        if (item.duration.isNotBlank()) {
            frame.addView(label(item.duration, badgeSp, Color.WHITE, true, 1).apply {
                setPadding(dp(5), dp(1), dp(5), dp(1))
                background = round(0xCC000000.toInt(), 4)
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(6), dp(6)) })
        }
        return frame
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean, lines: Int) = TextView(context).apply {
        this.text = text
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        maxLines = lines
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun sectionLabel(text: String) = label(text, 12f, 0x99FFFFFF.toInt(), true, 1).apply { letterSpacing = 0.04f }

    private fun styleHeader(pill: Boolean, text: String) {
        header.text = text
        if (pill) {
            header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            header.setTextColor(0xFF7BE0A5.toInt())
            header.setPadding(dp(11), dp(4), dp(11), dp(4))
            header.background = round(0x2E2FA35B, 13, dp(1), 0x662FA35B)
        } else {
            header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            header.setTextColor(Color.WHITE)
            header.setPadding(0, 0, 0, 0)
            header.background = null
        }
    }

    /** 처음 나타날 때 아래에서 살짝 떠오르며 순서대로 나타난다 */
    private fun enter(v: View, delay: Long) {
        v.alpha = 0f
        v.translationY = dp(14).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(300)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    /** 첫 영상 썸네일을 작게 줄여 늘리면 흐린 배경이 된다 */
    private fun setBackdrop(url: String, forSig: String) {
        if (url.isBlank()) { bgImage.alpha = 0f; return }
        loadBitmap(url) { bmp ->
            if (sig != forSig || bmp.width <= 0 || bmp.height <= 0) return@loadBitmap
            val sw = 32
            val sh = (sw.toFloat() * bmp.height / bmp.width).toInt().coerceAtLeast(2)
            val small = try { Bitmap.createScaledBitmap(bmp, sw, sh, true) } catch (e: Throwable) { null } ?: return@loadBitmap
            bgImage.setImageBitmap(small)
            bgImage.animate().alpha(0.4f).setStartDelay(0).setDuration(400).start()
        }
    }

    // ───────────────────────── 채우기 ─────────────────────────

    /**
     * 카드를 채운다. items 가 비면 버튼만 보인다.
     * autoSec > 0 이면 첫 항목에 카운트다운을 붙인다 (페이지의 자동 재생 대기 시간과 맞춘다).
     */
    fun show(items: List<Item>, autoSec: Int, hasNext: Boolean) {
        val s = items.joinToString("|") { it.title + it.thumb } + "#" + autoSec + hasNext
        if (visibility == View.VISIBLE && s == sig) return
        val wasHidden = visibility != View.VISIBLE
        val keepAuto = !wasHidden && autoCancelled
        sig = s
        autoCancelled = keepAuto
        lastItems = items; lastAuto = autoSec; lastNext = hasNext
        ui.removeCallbacks(tickRun)

        val dm = resources.displayMetrics
        val availW = if (width > 0) width else dm.widthPixels
        val availH = if (height > 0) height else dm.heightPixels
        val land = if (width > 0 && height > 0) width > height
        else resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        builtLand = land
        builtW = availW

        // 이전 화면 정리 (고리·머리글은 재사용하니 먼저 떼어 둔다)
        (ring.parent as? ViewGroup)?.removeView(ring)
        (header.parent as? ViewGroup)?.removeView(header)
        content.removeAllViews()
        scroll.removeAllViews()
        removeView(scroll)
        removeView(content)

        val first = items.firstOrNull()
        val auto = first != null && autoSec > 0 && !autoCancelled
        autoShown = auto
        cancelChip = null
        setBackdrop(first?.thumb.orEmpty(), s)

        val animated = ArrayList<View>()

        if (land) buildLandscape(items, first, auto, hasNext, availW, availH, animated)
        else buildPortrait(items, first, auto, hasNext, availW, animated)

        if (wasHidden) {
            alpha = 0f
            visibility = View.VISIBLE
            animate().alpha(1f).setStartDelay(0).setDuration(220).start()
            animated.forEachIndexed { i, v -> enter(v, 60L + i * 60L) }
        }
        if (first != null && autoSec > 0 && !autoCancelled) {
            autoTotalMs = autoSec * 1000L
            if (autoEndAt == 0L) autoEndAt = SystemClock.uptimeMillis() + autoTotalMs
            ui.post(tickRun)
        }
    }

    /** 큰 카드: 썸네일(+고리·길이) 아래에 제목·채널. 누르면 그 영상으로 */
    private fun heroCard(first: Item, inner: Int, auto: Boolean): LinearLayout {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(10))
            background = round(0x14FFFFFF, 16, dp(1), 0x26FFFFFF)
        }
        val h = inner * 9 / 16
        val frame = thumbWithBadge(first, inner, h, 10, 11f)
        if (auto) {
            frame.addView(ring, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
            ring.visibility = View.VISIBLE
        } else ring.visibility = View.GONE
        card.addView(frame, lp(inner, h))
        card.addView(label(first.title, 16f, Color.WHITE, true, 2), lp(inner, WRAP).apply { topMargin = dp(10); marginStart = dp(2) })
        if (first.author.isNotBlank()) {
            card.addView(label(first.author, 12.5f, 0xB3FFFFFF.toInt(), false, 1), lp(inner, WRAP).apply { topMargin = dp(3); marginStart = dp(2) })
        }
        pressable(card) { cancelTimer(); onPick(0) }
        return card
    }

    private fun buttons(first: Item?, auto: Boolean, hasNext: Boolean, short: Boolean, padH: Int): LinearLayout {
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(chip("↺  다시 보기", false, padH) { cancelTimer(); onReplay() }, lp(WRAP, dp(42)))
        if (auto) {
            val c = chip("취소", false, padH) {
                autoCancelled = true; autoShown = false
                cancelTimer(); ring.visibility = View.GONE
                styleHeader(true, "다음 영상")
                cancelChip?.visibility = View.GONE
                onCancelAuto()
            }
            cancelChip = c
            row.addView(c, lp(WRAP, dp(42)).apply { marginStart = dp(8) })
        }
        if (hasNext || first != null) {
            val label = if (short) "▶  재생" else "▶  지금 재생"
            row.addView(chip(label, true, padH) { cancelTimer(); if (first != null) onPick(0) else onNext() },
                lp(0, dp(42), 1f).apply { marginStart = dp(8) })
        }
        return row
    }

    private fun buildPortrait(items: List<Item>, first: Item?, auto: Boolean, hasNext: Boolean, availW: Int, animated: ArrayList<View>) {
        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL
        content.setPadding(dp(16), dp(56), dp(16), dp(24))

        val colW = minOf(availW - dp(32), dp(400))
        if (first != null) {
            styleHeader(true, if (auto) "${autoSecs()}초 후 자동 재생" else "다음 영상")
            content.addView(header, lp(WRAP, WRAP).apply { bottomMargin = dp(10) })
            val card = heroCard(first, colW - dp(16), auto)
            content.addView(card, lp(colW, WRAP))
            animated.add(card)
        } else {
            styleHeader(false, "재생이 끝났어요")
            content.addView(header, lp(WRAP, WRAP))
        }

        val btns = buttons(first, auto, hasNext, false, 16)
        content.addView(btns, lp(colW, WRAP).apply { topMargin = dp(14) })
        animated.add(btns)

        if (items.size > 1) {
            val sec = sectionLabel("이어서 볼 영상")
            content.addView(sec, lp(colW, WRAP).apply { topMargin = dp(22); bottomMargin = dp(8) })
            val bleed = if (colW >= availW - dp(32)) dp(16) else 0
            val hs = HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(bleed, 0, bleed, 0) }
            val cw = dp(136)
            for (i in 1 until minOf(items.size, 9)) {
                row.addView(moreCard(items[i], i, cw), lp(cw, WRAP).apply { marginEnd = dp(10) })
            }
            hs.addView(row)
            content.addView(hs, lp(colW + bleed * 2, WRAP).apply { marginStart = -bleed; marginEnd = -bleed })
            animated.add(sec); animated.add(hs)
        }

        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        addView(scroll, 2, LayoutParams(MATCH, MATCH))
    }

    private fun buildLandscape(items: List<Item>, first: Item?, auto: Boolean, hasNext: Boolean, availW: Int, availH: Int, animated: ArrayList<View>) {
        content.orientation = LinearLayout.HORIZONTAL
        content.gravity = Gravity.CENTER_VERTICAL
        content.setPadding(dp(64), dp(12), dp(24), dp(12))

        // 왼쪽: 큰 카드 + 버튼. 화면 높이에 맞춰 썸네일 크기를 정한다
        val byHeight = (availH - dp(214)) * 16 / 9
        val thumbW = byHeight.coerceIn(dp(224), dp(300)).coerceAtMost(maxOf((availW * 0.42f).toInt(), dp(224)))
        val colW = thumbW + dp(16)

        val left = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        if (first != null) {
            styleHeader(true, if (auto) "${autoSecs()}초 후 자동 재생" else "다음 영상")
            left.addView(header, lp(WRAP, WRAP).apply { bottomMargin = dp(8) })
            val card = heroCard(first, thumbW, auto)
            left.addView(card, lp(colW, WRAP))
            animated.add(card)
        } else {
            styleHeader(false, "재생이 끝났어요")
            left.addView(header, lp(WRAP, WRAP))
        }
        val btns = buttons(first, auto, hasNext, colW < dp(300), 14)
        left.addView(btns, lp(colW, WRAP).apply { topMargin = dp(12) })
        animated.add(btns)
        content.addView(left, lp(colW, WRAP))

        // 오른쪽: 이어서 볼 영상 세로 목록
        if (items.size > 1) {
            val rs = ScrollView(context).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
            col.addView(sectionLabel("이어서 볼 영상"), lp(WRAP, WRAP).apply { bottomMargin = dp(8); marginStart = dp(4) })
            val tw = dp(124)
            for (i in 1 until minOf(items.size, 9)) {
                col.addView(moreRowItem(items[i], i, tw), lp(MATCH, WRAP).apply { bottomMargin = dp(8) })
            }
            rs.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
            content.addView(rs, lp(0, MATCH, 1f).apply { marginStart = dp(28) })
            animated.add(rs)
        }

        addView(content, 2, LayoutParams(MATCH, MATCH))
    }

    private fun autoSecs() = ((autoTotalMs.takeIf { it > 0 } ?: (lastAuto * 1000L)) + 999) / 1000

    /** 세로 화면용 작은 카드 */
    private fun moreCard(item: Item, idx: Int, cw: Int): View {
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val th = cw * 9 / 16
        col.addView(thumbWithBadge(item, cw, th, 10, 10f), lp(cw, th))
        col.addView(label(item.title, 12f, 0xF2FFFFFF.toInt(), false, 2), lp(cw, WRAP).apply { topMargin = dp(6) })
        if (item.author.isNotBlank()) col.addView(label(item.author, 11f, 0x99FFFFFF.toInt(), false, 1), lp(cw, WRAP).apply { topMargin = dp(2) })
        pressable(col) { cancelTimer(); onPick(idx) }
        return col
    }

    /** 가로 화면용 목록 줄 */
    private fun moreRowItem(item: Item, idx: Int, tw: Int): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(10), dp(6))
            background = round(0x12FFFFFF, 12)
        }
        val th = tw * 9 / 16
        row.addView(thumbWithBadge(item, tw, th, 8, 10f), lp(tw, th))
        val info = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        info.addView(label(item.title, 13f, Color.WHITE, true, 2))
        if (item.author.isNotBlank()) info.addView(label(item.author, 11.5f, 0x99FFFFFF.toInt(), false, 1), lp(WRAP, WRAP).apply { topMargin = dp(3) })
        row.addView(info, lp(0, WRAP, 1f).apply { marginStart = dp(10) })
        pressable(row) { cancelTimer(); onPick(idx) }
        return row
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (visibility != View.VISIBLE || autoEndAt == 0L) return
            val left = autoEndAt - SystemClock.uptimeMillis()
            ring.fraction = if (autoTotalMs > 0) (left.toFloat() / autoTotalMs).coerceIn(0f, 1f) else 0f
            if (autoShown) {
                val secs = ((left + 999) / 1000).toInt()
                val t = if (left > 0) "${secs}초 후 자동 재생" else "곧 재생돼요"
                if (header.text.toString() != t) header.text = t
            }
            if (left > 0) ui.postDelayed(this, 50)
        }
    }

    private fun cancelTimer() {
        ui.removeCallbacks(tickRun)
    }

    fun hideCard() {
        cancelTimer()
        autoEndAt = 0L
        autoCancelled = false
        autoShown = false
        sig = ""
        if (visibility == View.VISIBLE) {
            animate().cancel()
            visibility = View.GONE
        }
        bgImage.animate().cancel()
        bgImage.alpha = 0f
    }

    fun isShowing() = visibility == View.VISIBLE

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val items = lastItems ?: return
        if (visibility != View.VISIBLE || w <= 0 || h <= 0) return
        // 회전·분할 화면으로 모양이 달라졌으면 새 크기에 맞게 다시 짠다
        if ((w > h) != builtLand || Math.abs(w - builtW) > dp(24)) {
            post {
                if (visibility == View.VISIBLE) {
                    sig = ""
                    show(items, lastAuto, lastNext)
                }
            }
        }
    }

    override fun onDetachedFromWindow() {
        cancelTimer()
        super.onDetachedFromWindow()
    }

    /** 남은 시간을 보여 주는 고리 */
    private class CountdownRing(ctx: Context, private val color: Int) : View(ctx) {
        var fraction = 1f
            set(v) { field = v; invalidate() }
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = 0x99000000.toInt() }
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; this.color = 0x55FFFFFF; strokeWidth = 3.5f * resources.displayMetrics.density }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; this.color = color; strokeWidth = 3.5f * resources.displayMetrics.density; strokeCap = Paint.Cap.ROUND }
        private val tri = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = Color.WHITE }
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val p = arc.strokeWidth
            c.drawCircle(w / 2, h / 2, w / 2, bg)
            val r = RectF(p, p, w - p, h - p)
            c.drawOval(r, track)
            c.drawArc(r, -90f, 360f * fraction, false, arc)
            val path = android.graphics.Path()
            path.moveTo(w * 0.42f, h * 0.34f); path.lineTo(w * 0.42f, h * 0.66f); path.lineTo(w * 0.68f, h * 0.5f); path.close()
            c.drawPath(path, tri)
        }
    }
}
