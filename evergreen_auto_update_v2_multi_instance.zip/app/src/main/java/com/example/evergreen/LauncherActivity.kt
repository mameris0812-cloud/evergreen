package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 홈 화면/작업 표시줄의 런처 진입점.
 * 앱 아이콘으로 새 창을 요청할 때 기존 MainActivity Task에 합쳐지지 않도록
 * BrowserWindowActivity를 매번 별도 document Task로 실행한다.
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val adjacent = ((intent?.flags ?: 0) and Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT) != 0
        val launch = Intent(this, BrowserWindowActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT or
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK
            )
            if (adjacent) addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
        }

        startActivity(launch)
        finish()
    }
}
