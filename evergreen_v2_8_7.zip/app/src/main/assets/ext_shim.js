function __evxMake(ID, M, MSG, B, T) {
  var BASE = "https://ext.evergreen.invalid/" + ID + "/";
  function ev() {
    var L = [];
    return {
      addListener: function (f) { if (typeof f === "function") L.push(f); },
      removeListener: function (f) { var i = L.indexOf(f); if (i >= 0) L.splice(i, 1); },
      hasListener: function (f) { return L.indexOf(f) >= 0; },
      hasListeners: function () { return L.length > 0; },
      _a: function () { return L.slice(); },
      _d: function (a) { L.slice().forEach(function (f) { try { f.apply(null, a); } catch (e) { console.error(e); } }); }
    };
  }
  // 값을 돌려주는 함수를 콜백/프로미스 양쪽 방식으로 부를 수 있게 감싼다
  function cb(args, fn) {
    var last = args[args.length - 1];
    if (typeof last === "function") {
      var v, err = null;
      try { v = fn(); } catch (e) { err = e; }
      setTimeout(function () { if (err) console.error(err); else last(v); }, 0);
      return undefined;
    }
    try { return Promise.resolve(fn()); } catch (e) { return Promise.reject(e); }
  }
  // 지원하지 않는 API: 호출해도 오류 없이 조용히 넘어간다
  function stub() {
    var f = function () {
      var c = arguments[arguments.length - 1];
      if (typeof c === "function") { setTimeout(function () { try { c(); } catch (e) {} }, 0); return undefined; }
      return Promise.resolve();
    };
    return new Proxy(f, {
      get: function (t, k) {
        if (k === "then" || typeof k === "symbol") return undefined;
        if (k === "addListener" || k === "removeListener") return function () {};
        if (k === "hasListener" || k === "hasListeners") return function () { return false; };
        return stub();
      }
    });
  }
  function ns(o) {
    return new Proxy(o, {
      get: function (t, k) {
        if (k in t) return t[k];
        if (typeof k === "symbol" || k === "then") return undefined;
        return stub();
      }
    });
  }

  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }
  // 같은 페이지(창) 안의 여러 콘텐츠 스크립트 묶음이 리스너를 함께 쓰도록, 확장 프로그램별 이벤트를 창에 하나만 둔다
  var SH = window.__evxSh;
  if (!SH) { SH = {}; try { Object.defineProperty(window, "__evxSh", { value: SH }); } catch (e) { window.__evxSh = SH; } }
  function shared(n) { var k = ID + ":" + n; return SH[k] || (SH[k] = ev()); }
  // 이 창을 가리키는 id (저장소 변경을 다른 창에 알릴 때 자기 자신에게는 다시 안 보내려고)
  var CTX = window.__evxCtx;
  if (!CTX) { CTX = rid(); try { Object.defineProperty(window, "__evxCtx", { value: CTX }); } catch (e) { window.__evxCtx = CTX; } }
  function fire(ch, area) {
    if (!Object.keys(ch).length) return;
    shared("ch")._d([clone(ch), area]);
    shared("ch_" + area)._d([clone(ch)]);
    try { B.sbcast(ID, area, JSON.stringify(ch), CTX, T); } catch (e) { }
  }
  // 다른 창(백그라운드 · 팝업 · 탭)에서 저장소가 바뀌었다는 알림
  if (!window.__evxSc) {
    try {
      Object.defineProperty(window, "__evxSc", {
        value: function (id, area, j, src) {
          if (src === CTX) return;
          var ch = parseJ(j);
          if (!ch) return;
          var a = SH[id + ":ch"], b = SH[id + ":ch_" + area];
          if (a) a._d([clone(ch), area]);
          if (b) b._d([clone(ch)]);
        }
      });
    } catch (e) { }
  }

  // ── 네이티브와 주고받는 비동기 호출 (메시지 · fetch · 탭 메시지) ──
  var ROOT = "https://ext.evergreen.invalid/";
  var G = window.__evxPending;
  if (!G) { G = {}; try { Object.defineProperty(window, "__evxPending", { value: G }); } catch (e) { window.__evxPending = G; } }
  if (!window.__evxResp) {
    try { Object.defineProperty(window, "__evxResp", { value: function (id, j) { var f = G[id]; if (f) { delete G[id]; f(j); } } }); } catch (e) { }
  }
  function rid() { return Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function ask(start, ms) {
    return new Promise(function (res) {
      var cid = rid();
      var t = setTimeout(function () { delete G[cid]; res(""); }, ms || 30000);
      G[cid] = function (j) { clearTimeout(t); res(j); };
      try { start(cid); } catch (e) { delete G[cid]; clearTimeout(t); res(""); }
    });
  }
  function parseJ(j) { if (j === "" || j == null) return undefined; try { return JSON.parse(j); } catch (e) { return undefined; } }
  function str(m) { var j = JSON.stringify(m === undefined ? null : m); return j === undefined ? "null" : j; }
  function withCb(done, p) {
    if (typeof done === "function") { p.then(function (v) { try { done(v); } catch (e) { console.error(e); } }); return undefined; }
    return p;
  }
  function openTab(u) {
    try { u = new URL(String(u || ""), BASE).href; B.opentab(ID, u, T); } catch (e) { }
  }
  // 크롬처럼: 리스너가 true 를 돌려주면 나중에 sendResponse, 아니면 바로 닫는다 (Promise 반환은 무시)
  function dispatch(evObj, msg, sender, reply) {
    var ls = evObj ? evObj._a() : [], done = false, async = false;
    function respond(v) { if (done) return; done = true; reply(v); }
    for (var i = 0; i < ls.length && !done; i++) {
      var r;
      try { r = ls[i](clone(msg), sender, respond); } catch (e) { console.error(e); continue; }
      if (r === true) async = true;
    }
    if (!async && !done) respond(undefined);
  }
  // 알람 (백그라운드 페이지가 살아 있는 동안만 울린다)
  var onAlarm = ev(), AL = {}, ALT = {};
  function clearA(n) { if (ALT[n] != null) { clearTimeout(ALT[n]); delete ALT[n]; } var had = n in AL; delete AL[n]; return had; }
  var alarms = ns({
    create: function (name, info) {
      if (name && typeof name === "object") { info = name; name = ""; }
      info = info || {}; name = name || "";
      clearA(name);
      var d = info.when != null ? Math.max(0, info.when - Date.now()) : (info.delayInMinutes != null ? info.delayInMinutes * 60000 : (info.periodInMinutes || 0) * 60000);
      var per = info.periodInMinutes ? Math.max(info.periodInMinutes, 0.5) * 60000 : 0;
      var al = { name: name, scheduledTime: Date.now() + d };
      if (info.periodInMinutes) al.periodInMinutes = info.periodInMinutes;
      AL[name] = al;
      var fire = function () {
        if (!AL[name] || AL[name] !== al) return;
        var copy = JSON.parse(JSON.stringify(al));
        if (per) { al.scheduledTime = Date.now() + per; ALT[name] = setTimeout(fire, per); } else { delete AL[name]; delete ALT[name]; }
        onAlarm._d([copy]);
      };
      ALT[name] = setTimeout(fire, d);
      return cb(arguments, function () {});
    },
    get: function (name) { var a = arguments; return cb(a, function () { return clone(AL[typeof name === "string" ? name : ""]); }); },
    getAll: function () { return cb(arguments, function () { return Object.keys(AL).map(function (k) { return clone(AL[k]); }); }); },
    clear: function (name) { var a = arguments; return cb(a, function () { return clearA(typeof name === "string" ? name : ""); }); },
    clearAll: function () { return cb(arguments, function () { var any = Object.keys(AL).length > 0; Object.keys(AL).forEach(clearA); return any; }); },
    onAlarm: onAlarm
  });
  function area(name) {
    function load() { try { return JSON.parse(B.sget(ID, name, T) || "{}"); } catch (e) { return {}; } }
    function save(o) { B.sset(ID, name, JSON.stringify(o), T); }
    return {
      get: function (keys) {
        return cb(arguments, function () {
          var o = load();
          if (keys == null || typeof keys === "function") return o;
          var r = {};
          if (typeof keys === "string") keys = [keys];
          if (Array.isArray(keys)) keys.forEach(function (k) { if (k in o) r[k] = o[k]; });
          else if (typeof keys === "object") Object.keys(keys).forEach(function (k) { r[k] = (k in o) ? o[k] : keys[k]; });
          return r;
        });
      },
      set: function (items) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(items || {}).forEach(function (k) {
            var nv = clone(items[k]);
            ch[k] = { oldValue: o[k], newValue: nv };
            o[k] = nv;
          });
          save(o);
          fire(ch, name);
        });
      },
      remove: function (keys) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          (Array.isArray(keys) ? keys : [keys]).forEach(function (k) {
            if (typeof k === "string" && k in o) { ch[k] = { oldValue: o[k] }; delete o[k]; }
          });
          save(o);
          fire(ch, name);
        });
      },
      clear: function () {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(o).forEach(function (k) { ch[k] = { oldValue: o[k] }; });
          save({});
          fire(ch, name);
        });
      },
      getBytesInUse: function () { return cb(arguments, function () { return JSON.stringify(load()).length; }); },
      getKeys: function () { return cb(arguments, function () { return Object.keys(load()); }); },
      setAccessLevel: function () { return cb(arguments, function () { }); },
      QUOTA_BYTES: name === "sync" ? 102400 : (name === "session" ? 10485760 : 10485760),
      onChanged: shared("ch_" + name)
    };
  }

  // ── 포트 (runtime.connect / tabs.connect) ──
  // 열기·메시지·닫기를 보통 메시지로 감싸서 주고받는다 (콘텐츠 스크립트·팝업 → 백그라운드는 B.send, 백그라운드 → 열린 페이지는 B.bgbcast, 백그라운드 → 보고 있는 탭은 B.tabsend)
  var PORTS = window.__evxPorts;
  if (!PORTS) { PORTS = {}; try { Object.defineProperty(window, "__evxPorts", { value: PORTS }); } catch (e) { window.__evxPorts = PORTS; } }
  function envOf(op, pid, x) { var o = { __evxPort: 1, op: op, pid: pid }; if (x) for (var k in x) o[k] = x[k]; return o; }
  function toBg(env) { ask(function (cid) { B.send(ID, str(env), location.href, T, cid); }, 8000); }
  function toPages(env) { ask(function (cid) { B.bgbcast(ID, str(env), T, cid); }, 8000); }
  function toTab(env) { ask(function (cid) { B.tabsend(ID, str(env), T, cid); }, 8000); }
  function mkPort(pid, name, sender, out) {
    var p = { name: name || "", onMessage: ev(), onDisconnect: ev(), _c: false };
    if (sender) p.sender = sender;
    p.postMessage = function (m) {
      if (p._c) throw new Error("Attempting to use a disconnected port object");
      out(envOf("msg", pid, { data: m === undefined ? null : m }));
    };
    p.disconnect = function () {
      if (p._c) return;
      p._c = true; delete PORTS[pid + ID];
      out(envOf("close", pid));
    };
    p._in = function (op, data) {
      if (p._c) return;
      if (op === "msg") p.onMessage._d([clone(data), p]);
      else if (op === "close") { p._c = true; delete PORTS[pid + ID]; p.onDisconnect._d([p]); }
    };
    PORTS[pid + ID] = p;
    return p;
  }
  function handlePort(env, sender, out) {
    var p = PORTS[env.pid + ID];
    if (env.op === "open") {
      if (p) return;
      var oc = shared("oc");
      var np = mkPort(env.pid, env.name, sender, out);
      if (!oc.hasListeners()) { np.disconnect(); return; }
      oc._d([np]);
    } else if (p) {
      p._in(env.op, env.data);
    }
  }

  // ── 보고 있는 탭에 스크립트·스타일 넣기 (scripting / tabs.executeScript · insertCSS) ──
  function tabExec(spec) {
    return ask(function (cid) { B.tabexec(ID, str(spec), T, cid); }, 60000).then(function (j) {
      var r = parseJ(j);
      if (!r) return [];
      if (r.error) throw new Error(r.error);
      return r.results || [];
    });
  }
  function tabArgs(args) {
    var a = [].slice.call(args), done = null;
    if (typeof a[a.length - 1] === "function") done = a.pop();
    if (typeof a[0] === "number") a.shift();
    return { d: a[0] || {}, done: done };
  }
  function tabCmd(cmd, arg) { try { B.tabcmd(ID, cmd, arg || "", T); } catch (e) { } }

  // ── 쿠키 ──
  function cookieUrl(d) {
    if (d && d.url) return String(d.url);
    if (d && d.domain) return "https://" + String(d.domain).replace(/^\./, "") + "/";
    return "";
  }
  function cookieList(d) {
    var u = cookieUrl(d);
    if (!u) return [];
    var l; try { l = JSON.parse(B.cookieget(ID, u, T)); } catch (e) { return []; }
    return l.filter(function (c) { return !d.name || c.name === d.name; });
  }
  function cookieWrite(d, rm) {
    var o = clone(d || {}); if (rm) o.remove = true;
    var r = parseJ(B.cookieset(ID, JSON.stringify(o), T));
    if (!r) throw new Error("Invalid cookie");
    if (r.error) throw new Error(r.error);
    return r;
  }

  // ── declarativeNetRequest (요청 차단 규칙) ──
  function dnrGet(kind) { return parseJ(B.dnrget(ID, kind, T)) || []; }
  function dnrUpd(kind, o, args) {
    return cb(args, function () {
      var r = parseJ(B.dnrupd(ID, kind, str(o || {}), T));
      if (r && r.error) throw new Error(r.error);
    });
  }

  var runtime = ns({
    id: ID,
    getURL: function (p) { return BASE + String(p).replace(/^\//, ""); },
    getManifest: function () { return clone(M); },
    getPlatformInfo: function () { return cb(arguments, function () { return { os: "android", arch: "arm64", nacl_arch: "arm" }; }); },
    sendMessage: function () {
      var a = [].slice.call(arguments), done = null;
      if (typeof a[a.length - 1] === "function") done = a.pop();
      if (a.length >= 2 && typeof a[0] === "string" && /^[a-p]{32}$/.test(a[0])) a.shift();
      var m = a[0];
      var p = ask(function (cid) {
        if (window.__evxIsBg) B.bgbcast(ID, str(m), T, cid); else B.send(ID, str(m), location.href, T, cid);
      }).then(parseJ);
      return withCb(done, p);
    },
    connect: function () {
      var a = [].slice.call(arguments), info = {};
      if (typeof a[0] === "string") a.shift(); // 확장 프로그램 id
      if (a[0] && typeof a[0] === "object") info = a[0];
      var pid = rid(), out = window.__evxIsBg ? toPages : toBg;
      var p = mkPort(pid, info.name, undefined, out);
      out(envOf("open", pid, { name: p.name }));
      return p;
    },
    openOptionsPage: function () {
      var o = (M.options_ui && M.options_ui.page) || M.options_page;
      if (o) openTab(o);
      return cb(arguments, function () {});
    },
    reload: function () {},
    onMessage: shared("om"), onConnect: shared("oc"), onInstalled: ev(), onStartup: ev(), onSuspend: ev(), onUpdateAvailable: ev()
  });

  // ── webRequest (백그라운드 전용): 앱이 요청마다 __evxWr 로 불러 준다 ──
  var WRL = {};
  function wrEv(name) {
    var L = WRL[name] || (WRL[name] = []);
    return {
      addListener: function (f, filter, extra) {
        if (typeof f !== "function") return;
        extra = Array.isArray(extra) ? extra : [];
        var e = { f: f, lid: rid(), blocking: extra.indexOf("blocking") >= 0 || extra.indexOf("asyncBlocking") >= 0, async: extra.indexOf("asyncBlocking") >= 0 };
        L.push(e);
        try { B.wrreg(ID, name, JSON.stringify(filter || {}), e.lid, e.blocking, T); } catch (x) { }
      },
      removeListener: function (f) {
        for (var i = 0; i < L.length; i++) if (L[i].f === f) { try { B.wrunreg(ID, L[i].lid, T); } catch (x) { } L.splice(i, 1); return; }
      },
      hasListener: function (f) { return L.some(function (e) { return e.f === f; }); },
      hasListeners: function () { return L.length > 0; }
    };
  }
  var webRequest = null;
  if (window.__evxIsBg) {
    webRequest = ns({
      onBeforeRequest: wrEv("onBeforeRequest"), onBeforeSendHeaders: wrEv("onBeforeSendHeaders"), onSendHeaders: wrEv("onSendHeaders"),
      onHeadersReceived: wrEv("onHeadersReceived"), onBeforeRedirect: wrEv("onBeforeRedirect"), onResponseStarted: wrEv("onResponseStarted"),
      onCompleted: wrEv("onCompleted"), onErrorOccurred: wrEv("onErrorOccurred"), onAuthRequired: wrEv("onAuthRequired"),
      handlerBehaviorChanged: function () { return cb(arguments, function () { }); },
      MAX_HANDLER_BEHAVIOR_CHANGED_CALLS_PER_10_MINUTES: 20
    });
    window.__evxWr = function (name, dj, id, lids, wait) {
      var d = parseJ(dj) || {}, out = {}, p = Promise.resolve();
      (WRL[name] || []).filter(function (e) { return lids.indexOf(e.lid) >= 0; }).forEach(function (e) {
        p = p.then(function () {
          var r;
          try {
            if (e.async) r = new Promise(function (res) { var x = e.f(clone(d), res); if (x && typeof x === "object" && typeof x.then !== "function") res(x); });
            else r = e.f(clone(d));
          } catch (x) { console.error(x); return; }
          if (!e.blocking) return;
          return Promise.resolve(r).then(function (v) {
            if (!v || typeof v !== "object") return;
            if (v.cancel) out.cancel = true;
            if (v.redirectUrl) out.redirectUrl = v.redirectUrl;
            if (v.authCredentials) out.authCredentials = v.authCredentials;
            if (v.requestHeaders) { out.requestHeaders = v.requestHeaders; d.requestHeaders = v.requestHeaders; }
            if (v.responseHeaders) { out.responseHeaders = v.responseHeaders; d.responseHeaders = v.responseHeaders; }
          }, function () { });
        });
      });
      p.then(function () { if (wait) { try { B.wrres(ID, id, JSON.stringify(out), T); } catch (x) { } } });
    };
  }

  // ── contextMenus: 항목은 앱이 저장해 두고, 링크 · 이미지 길게 누르기 메뉴에 보여 준다 ──
  var CM = null, cmHandlers = {}, cmClick = ev();
  function cmList() { if (!CM) { CM = parseJ(B.cmget(ID, T)); if (!Array.isArray(CM)) CM = []; } return CM; }
  function cmSave() { try { B.cmset(ID, JSON.stringify(CM || []), T); } catch (x) { } }
  function cmIndex(id) { var l = cmList(); for (var i = 0; i < l.length; i++) if (String(l[i].id) === String(id)) return i; return -1; }
  var contextMenus = ns({
    create: function (p, done) {
      p = p || {};
      var id = p.id != null ? p.id : "evx_" + rid(), o = {};
      Object.keys(p).forEach(function (k) { if (typeof p[k] !== "function") o[k] = p[k]; });
      o.id = id;
      if (typeof p.onclick === "function") cmHandlers[String(id)] = p.onclick;
      var i = cmIndex(id);
      if (i >= 0) cmList()[i] = o; else cmList().push(o);
      cmSave();
      if (typeof done === "function") setTimeout(function () { try { done(); } catch (x) { } }, 0);
      return id;
    },
    update: function (id, p) {
      var a = arguments;
      return cb(a, function () {
        var i = cmIndex(id);
        if (i < 0) throw new Error("Cannot find menu item with id " + id);
        Object.keys(p || {}).forEach(function (k) { if (typeof p[k] !== "function") cmList()[i][k] = p[k]; else if (k === "onclick") cmHandlers[String(id)] = p[k]; });
        cmSave();
      });
    },
    remove: function (id) {
      var a = arguments;
      return cb(a, function () {
        var i = cmIndex(id);
        if (i < 0) throw new Error("Cannot find menu item with id " + id);
        cmList().splice(i, 1); delete cmHandlers[String(id)]; cmSave();
      });
    },
    removeAll: function () { return cb(arguments, function () { CM = []; cmHandlers = {}; cmSave(); }); },
    onClicked: cmClick, ACTION_MENU_TOP_LEVEL_LIMIT: 6,
    ContextType: { ALL: "all", PAGE: "page", FRAME: "frame", SELECTION: "selection", LINK: "link", EDITABLE: "editable", IMAGE: "image", VIDEO: "video", AUDIO: "audio", LAUNCHER: "launcher", BROWSER_ACTION: "browser_action", PAGE_ACTION: "page_action", ACTION: "action" },
    ItemType: { NORMAL: "normal", CHECKBOX: "checkbox", RADIO: "radio", SEPARATOR: "separator" }
  });
  if (window.__evxIsBg) {
    window.__evxCmClick = function (ij, tj) {
      var i = parseJ(ij), t = parseJ(tj), h = cmHandlers[String(i && i.menuItemId)];
      if (h) { try { h(i, t); } catch (x) { console.error(x); } }
      cmClick._d([i, t]);
    };
  }

  var C = {
    runtime: runtime,
    extension: ns({
      getURL: runtime.getURL, inIncognitoContext: false,
      getBackgroundPage: function () { return null; }, getViews: function () { return []; },
      isAllowedIncognitoAccess: function () { return cb(arguments, function () { return false; }); }
    }),
    storage: ns({
      local: area("local"), sync: area("sync"), session: area("session"), managed: area("managed"),
      onChanged: shared("ch")
    }),
    i18n: ns({
      getMessage: function (n, s) {
        var m = MSG[String(n).toLowerCase()];
        if (m == null) return "";
        if (s == null) s = []; else if (!Array.isArray(s)) s = [s];
        return m.replace(/\$(\d)/g, function (_, i) { var v = s[+i - 1]; return v == null ? "" : v; }).replace(/\$\$/g, "$");
      },
      getUILanguage: function () { return navigator.language; },
      getAcceptLanguages: function () { return cb(arguments, function () { return (navigator.languages || [navigator.language]).slice(); }); }
    }),
    tabs: ns({
      create: function (o) { openTab(o && o.url); return cb(arguments, function () { return { id: 2, url: o && o.url, active: true }; }); },
      query: function () {
        return cb(arguments, function () { try { return JSON.parse(B.tabinfo(ID, T)); } catch (e) { return []; } });
      },
      get: function () { return cb(arguments, function () { try { return JSON.parse(B.tabinfo(ID, T))[0]; } catch (e) { return undefined; } }); },
      getCurrent: function () { return cb(arguments, function () { return undefined; }); },
      update: function () {
        var x = tabArgs(arguments), u = x.d && x.d.url;
        if (u) tabCmd("nav", String(u));
        return cb(arguments, function () { return { id: 1, active: true, url: u || "" }; });
      },
      reload: function () { tabCmd("reload"); return cb(arguments, function () { }); },
      goBack: function () { tabCmd("back"); return cb(arguments, function () { }); },
      goForward: function () { tabCmd("forward"); return cb(arguments, function () { }); },
      connect: function (tabId, info) {
        info = info && typeof info === "object" ? info : {};
        var pid = rid(), p = mkPort(pid, info.name, undefined, toTab);
        toTab(envOf("open", pid, { name: p.name }));
        return p;
      },
      executeScript: function () {
        var x = tabArgs(arguments), d = x.d;
        var p = tabExec({ kind: "js", code: d.code || null, files: d.file ? [d.file] : null });
        return withCb(x.done, p);
      },
      insertCSS: function () {
        var x = tabArgs(arguments), d = x.d;
        var p = tabExec({ kind: "css", css: d.code || null, files: d.file ? [d.file] : null }).then(function () { });
        return withCb(x.done, p);
      },
      removeCSS: function () {
        var x = tabArgs(arguments), d = x.d;
        var p = tabExec({ kind: "rmcss", css: d.code || null, files: d.file ? [d.file] : null }).then(function () { });
        return withCb(x.done, p);
      },
      sendMessage: function () {
        var a = [].slice.call(arguments), done = null;
        if (typeof a[a.length - 1] === "function") done = a.pop();
        var m = a[1];
        var p = ask(function (cid) { B.tabsend(ID, str(m), T, cid); }).then(parseJ);
        return withCb(done, p);
      }
    }),
    alarms: alarms,
    scripting: ns({
      executeScript: function (inj) {
        inj = inj || {};
        var last = arguments[arguments.length - 1];
        var p = tabExec({
          kind: "js", files: inj.files || null, args: inj.args || [],
          func: typeof inj.func === "function" ? String(inj.func) : null
        }).then(function (arr) { return arr.map(function (v) { return { frameId: 0, documentId: "0", result: v }; }); });
        return withCb(last, p);
      },
      insertCSS: function (inj) {
        inj = inj || {};
        var p = tabExec({ kind: "css", css: inj.css || null, files: inj.files || null }).then(function () { });
        return withCb(arguments[arguments.length - 1], p);
      },
      removeCSS: function (inj) {
        inj = inj || {};
        var p = tabExec({ kind: "rmcss", css: inj.css || null, files: inj.files || null }).then(function () { });
        return withCb(arguments[arguments.length - 1], p);
      }
    }),
    windows: ns({
      getCurrent: function () { return cb(arguments, function () { return { id: 1, focused: true, type: "normal", state: "maximized", incognito: false }; }); },
      getLastFocused: function () { return cb(arguments, function () { return { id: 1, focused: true, type: "normal", state: "maximized", incognito: false }; }); },
      getAll: function () { return cb(arguments, function () { return [{ id: 1, focused: true, type: "normal", state: "maximized", incognito: false }]; }); },
      create: function (o) {
        var u = o && o.url;
        (Array.isArray(u) ? u : (u ? [u] : [])).forEach(openTab);
        return cb(arguments, function () { return { id: 2, focused: true, type: "normal", incognito: false }; });
      },
      WINDOW_ID_NONE: -1, WINDOW_ID_CURRENT: -2
    }),
    cookies: ns({
      get: function (d) { var a = arguments; return cb(a, function () { return cookieList(d)[0] || null; }); },
      getAll: function (d) { var a = arguments; return cb(a, function () { return cookieList(d || {}); }); },
      set: function (d) { var a = arguments; return cb(a, function () { return cookieWrite(d, false); }); },
      remove: function (d) { var a = arguments; return cb(a, function () { cookieWrite(d, true); return { url: d && d.url, name: d && d.name, storeId: "0" }; }); },
      getAllCookieStores: function () { return cb(arguments, function () { return [{ id: "0", tabIds: [1] }]; }); },
      onChanged: ev()
    }),
    declarativeNetRequest: ns({
      updateDynamicRules: function (o) { return dnrUpd("dynamic", o, arguments); },
      updateSessionRules: function (o) { return dnrUpd("session", o, arguments); },
      updateEnabledRulesets: function (o) { return dnrUpd("rulesets", o, arguments); },
      getDynamicRules: function () { return cb(arguments, function () { return dnrGet("dynamic"); }); },
      getSessionRules: function () { return cb(arguments, function () { return dnrGet("session"); }); },
      getEnabledRulesets: function () { return cb(arguments, function () { return dnrGet("rulesets"); }); },
      getAvailableStaticRuleCount: function () { return cb(arguments, function () { return 30000; }); },
      isRegexSupported: function () { return cb(arguments, function () { return { isSupported: true }; }); },
      getMatchedRules: function () { return cb(arguments, function () { return { rulesMatchedInfo: [] }; }); },
      MAX_NUMBER_OF_DYNAMIC_RULES: 30000, MAX_NUMBER_OF_SESSION_RULES: 5000, MAX_NUMBER_OF_ENABLED_STATIC_RULESETS: 50,
      RuleActionType: { BLOCK: "block", REDIRECT: "redirect", ALLOW: "allow", UPGRADE_SCHEME: "upgradeScheme", MODIFY_HEADERS: "modifyHeaders", ALLOW_ALL_REQUESTS: "allowAllRequests" },
      ResourceType: {
        MAIN_FRAME: "main_frame", SUB_FRAME: "sub_frame", STYLESHEET: "stylesheet", SCRIPT: "script", IMAGE: "image", FONT: "font",
        OBJECT: "object", XMLHTTPREQUEST: "xmlhttprequest", PING: "ping", CSP_REPORT: "csp_report", MEDIA: "media", WEBSOCKET: "websocket", OTHER: "other"
      },
      DomainType: { FIRST_PARTY: "firstParty", THIRD_PARTY: "thirdParty" }
    }),
    webRequest: webRequest || ns({}),
    contextMenus: contextMenus, menus: contextMenus,
    permissions: ns({
      contains: function () { return cb(arguments, function () { return true; }); },
      request: function () { return cb(arguments, function () { return true; }); },
      getAll: function () { return cb(arguments, function () { return { permissions: M.permissions || [], origins: [] }; }); }
    })
  };
  // 백그라운드 → 확장 프로그램 페이지(콘텐츠 스크립트 · 팝업) 메시지 받기 / 백그라운드가 받는 메시지 처리
  if (window.__evxIsBg) {
    window.__evxBgIn = function (cid, mj, sj) {
      var m = parseJ(mj);
      if (m && m.__evxPort === 1) { handlePort(m, parseJ(sj), toPages); B.bgresp(ID, cid, "", T); return; }
      dispatch(runtime.onMessage, m, parseJ(sj), function (v) { B.bgresp(ID, cid, v === undefined ? "" : JSON.stringify(v), T); });
    };
  } else {
    var LS = window.__evxLs;
    if (!LS) { LS = {}; try { Object.defineProperty(window, "__evxLs", { value: LS }); } catch (e) { } }
    LS[ID] = function (cid, mj, sj) {
      var m = parseJ(mj);
      if (m && m.__evxPort === 1) { handlePort(m, parseJ(sj), toBg); B.pageresp(ID, cid, "", T); return; }
      dispatch(runtime.onMessage, m, parseJ(sj), function (v) { B.pageresp(ID, cid, v === undefined ? "" : JSON.stringify(v), T); });
    };
    if (!window.__evxTabIn) {
      try {
        Object.defineProperty(window, "__evxTabIn", {
          value: function (ext, cid, mj, sj) {
            var f = window.__evxLs && window.__evxLs[ext];
            if (f) f(cid, mj, sj); else B.pageresp(ext, cid, "", T);
          }
        });
      } catch (e) { }
    }
  }

  // 백그라운드 페이지 전용: 서비스 워커 흉내 · CORS 없이 fetch · 시작 이벤트
  if (window.__evxIsBg && !window.__evxStarted) {
    window.__evxStarted = true;
    try { self.skipWaiting = function () { return Promise.resolve(); }; } catch (e) { }
    try { self.clients = { claim: function () { return Promise.resolve(); }, matchAll: function () { return Promise.resolve([]); } }; } catch (e) { }
    window.importScripts = function () {
      for (var i = 0; i < arguments.length; i++) {
        var u = new URL(arguments[i], BASE).href, x = new XMLHttpRequest();
        x.open("GET", u, false); x.send();
        if (x.status >= 200 && x.status < 300) (0, eval)(x.responseText + "\n//# sourceURL=" + u);
        else throw new Error("importScripts 실패: " + u);
      }
    };
    window.addEventListener("load", function () {
      setTimeout(function () {
        ["install", "activate"].forEach(function (n) {
          try { var e = new Event(n); e.waitUntil = function () { }; window.dispatchEvent(e); } catch (x) { }
        });
        runtime.onStartup._d([]);
        if (window.__evxInstalled) runtime.onInstalled._d([{ reason: "install" }]);
      }, 0);
    });
  }

  // 확장 프로그램 페이지(팝업 · 옵션)와 백그라운드: CORS 없이 fetch (host 권한이 있는 주소만)
  if ((window.__evxIsBg || location.href.indexOf(BASE) === 0) && !window.__evxFetchSet) {
    window.__evxFetchSet = true;
    var _fetch = window.fetch.bind(window);
    var b64 = function (buf) {
      var u = new Uint8Array(buf), s = "";
      for (var i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
      return btoa(s);
    };
    var unb64 = function (s) { var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
    window.fetch = function (input, init) {
      var req;
      try { req = new Request(input, init); } catch (e) { return _fetch(input, init); }
      var url = req.url;
      if (!/^https?:\/\//i.test(url) || url.indexOf(ROOT) === 0) return _fetch(req);
      return req.arrayBuffer().then(function (buf) {
        var h = {};
        req.headers.forEach(function (v, k) { h[k] = v; });
        if (req.credentials === "include") h["__evx_cred"] = "include";
        return ask(function (cid) { var hj = JSON.stringify(h), bd = buf.byteLength ? b64(buf) : ""; if (window.__evxIsBg) B.xfetch(ID, url, req.method, hj, bd, T, cid); else B.pfetch(ID, url, req.method, hj, bd, T, cid); }, 60000);
      }).then(function (j) {
        var r = parseJ(j);
        if (!r || r.error || r.status < 200 || r.status > 599) throw new TypeError("Failed to fetch");
        var nb = r.status === 204 || r.status === 205 || r.status === 304;
        return new Response(nb ? null : unb64(r.body || ""), { status: r.status, statusText: r.statusText || "", headers: r.headers || {} });
      });
    };
  }
  // 팝업 안에서 window.close() 를 부르면 팝업 카드를 닫는다
  if (!window.__evxIsBg && location.href.indexOf(BASE) === 0) {
    try { window.close = function () { try { B.popclose(ID, T); } catch (e) { } }; } catch (e) { }
  }

  return new Proxy(C, {
    get: function (t, k) {
      if (k in t) return t[k];
      if (typeof k === "symbol" || k === "then") return undefined;
      return ns({});
    }
  });
}
