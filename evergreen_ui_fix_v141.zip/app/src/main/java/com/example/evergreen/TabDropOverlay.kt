package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/**
 * 탭을 시스템 드래그로 끌고 있는 동안 창 위에 얹는 투명한 막.
 * 놓을 곳을 받아 주고(드래그 이벤트 수신), 화면 왼쪽/오른쪽 끝에 가까워지면
 * 분할로 열릴 자리를 반투명 미리보기로 보여 준다.
 * 좌표는 모두 '시스템 화면' 기준이다 (앱 창이 화면 일부만 차지해도 화면 끝을 기준으로 한다).
 */
class TabDropOverlay(context: Context, private val accent: Int) : View(context) {

    companion object {
        const val ZONE_NONE = 0
        const val ZONE_POPUP = 1
        const val ZONE_LEFT = 2
        const val ZONE_RIGHT = 3
    }

    /** 시스템 화면 크기 (미리보기 위치 계산용) */
    var screenW = 0
    var screenH = 0

    private var zone = ZONE_POPUP
    private var lastSplit = ZONE_LEFT
    private var shown = 0f
    private var anim: ValueAnimator? = null

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = 16f * density
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    fun setZone(z: Int) {
        if (z == zone) return
        zone = z
        val split = z == ZONE_LEFT || z == ZONE_RIGHT
        if (split) lastSplit = z
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, if (split) 1f else 0f).apply {
            duration = 140
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (shown <= 0.01f || screenW <= 0 || screenH <= 0) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val m = 8f * density
        val half = screenW / 2f
        // 화면 좌표 → 이 뷰 좌표
        if (lastSplit == ZONE_LEFT) rect.set(m, m, half - m / 2f, screenH - m)
        else rect.set(half + m / 2f, m, screenW - m, screenH - m)
        rect.offset(-loc[0].toFloat(), -loc[1].toFloat())

        val r = 20f * density
        fill.color = (accent and 0x00FFFFFF) or ((0x55 * shown).toInt() shl 24)
        stroke.color = (accent and 0x00FFFFFF) or ((0xCC * shown).toInt() shl 24)
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, stroke)
        text.alpha = (255 * shown).toInt()
        val label = if (lastSplit == ZONE_LEFT) "왼쪽 분할로 열기" else "오른쪽 분할로 열기"
        canvas.drawText(label, rect.centerX(), rect.centerY(), text)
    }
}
