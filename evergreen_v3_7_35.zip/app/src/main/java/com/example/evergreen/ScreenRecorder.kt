package com.example.evergreen

import android.annotation.SuppressLint
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.Build
import android.os.ParcelFileDescriptor
import android.view.Surface
import java.io.File

/**
 * 화면(미러링 화면 포함)을 소리와 함께 mp4 파일로 녹화한다.
 * 화면은 MediaProjection 의 가상 화면 → H.264 인코더(Surface 입력), 소리는 앱이 재생 중인 소리를 캡처(안드로이드 10+)해 AAC 로 묶는다.
 * 영상 주소를 찾는 방식이 아니라 화면에 보이는 것을 그대로 담으므로 유튜브 · DASH · blob 등 영상 종류와 상관없이 저장된다.
 * (DRM 으로 보호된 영상은 시스템이 검은 화면으로 바꿔서 담는다)
 */
class ScreenRecorder(
    private val projection: MediaProjection,
    private val screenW: Int,
    private val screenH: Int,
    private val dpi: Int,
    wantAudio: Boolean,
    /** 파일 경로로 직접 쓸 때의 파일 ([pfd] 가 있으면 쓰지 않는다) */
    val file: File?,
    /** 저장 위치(MediaStore 등)를 가리키는 파일 설명자. 있으면 녹화하는 동안 바로 여기에 써서, 끝난 뒤 따로 옮기는 시간이 없다 */
    private val pfd: ParcelFileDescriptor? = null
) {
    companion object {
        private const val VIDEO_MIME = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val FPS = 30
        private const val SAMPLE_RATE = 44100
        private const val AUDIO_BITRATE = 128_000

        // 긴 변 기준으로 큰 것부터 시도한다 (인코더가 못 받는 크기면 다음 후보로)
        private val LONG_SIDES = intArrayOf(1920, 1600, 1280, 1024, 854, 640)

        private fun nowUs() = System.nanoTime() / 1000
    }

    @Volatile private var stopping = false
    @Volatile private var failure: String? = null

    private var videoEnc: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var display: VirtualDisplay? = null
    private var audioEnc: MediaCodec? = null
    private var audioRec: AudioRecord? = null
    private var muxer: MediaMuxer? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    /** 녹화 화면 크기 (인코더가 받는 크기로 맞춘 값) */
    var outW = 0
        private set
    var outH = 0
        private set

    /** 소리까지 담는 중인지 (안드로이드 10 미만이거나 권한이 없으면 false) */
    @Volatile var hasAudio = false
        private set

    // 영상과 소리가 같은 시계(시작 시각 기준 µs)로 시간표를 쓰게 한다
    private val baseUs = nowUs()
    private var vOffset = Long.MIN_VALUE
    private var vLast = -1L
    private var aLast = -1L

    private val lock = Object()
    private var muxStarted = false
    private var videoTrack = -1
    private var audioTrack = -1
    private var wroteVideo = false
    @Volatile private var audioFormat: MediaFormat? = null
    private class Pending(val info: MediaCodec.BufferInfo, val data: ByteArray)
    private val pendingAudio = ArrayList<Pending>()

    private val wantAudioFlag = wantAudio

    /** 녹화를 시작한다. 실패하면 예외(메시지는 사용자에게 보여 줄 수 있는 말). 실패 시 만든 것은 모두 정리한다 */
    fun start() {
        try {
            muxer = if (pfd != null) MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            else MediaMuxer((file ?: throw IllegalStateException("file")).absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            setupVideo()
            setupAudio()
            val surface = inputSurface ?: throw IllegalStateException("surface")
            display = projection.createVirtualDisplay(
                "evergreen-record", outW, outH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null
            ) ?: throw IllegalStateException("display")
            videoThread = Thread({ videoLoop() }, "rec-video").also { it.start() }
            if (hasAudio) audioThread = Thread({ audioLoop() }, "rec-audio").also { it.start() }
        } catch (e: Throwable) {
            releaseAll()
            throw RuntimeException(
                if (e is IllegalStateException && e.message == "size") "이 기기에서는 화면 녹화에 쓸 수 있는 크기를 찾지 못했어요"
                else "화면 녹화를 시작하지 못했어요", e
            )
        }
    }

    /** 녹화를 끝내고 파일을 마무리한다. 문제가 있으면 안내 문구, 없으면 null */
    fun stop(): String? {
        if (stopping) return failure
        stopping = true
        try { display?.release() } catch (e: Throwable) { }
        display = null
        try { videoEnc?.signalEndOfInputStream() } catch (e: Throwable) { }
        try { videoThread?.join(4000) } catch (e: Throwable) { }
        try { audioThread?.join(4000) } catch (e: Throwable) { }
        var err = failure
        synchronized(lock) {
            try {
                if (muxStarted && wroteVideo) muxer?.stop()
                else if (err == null) err = "녹화가 너무 짧아서 저장하지 않았어요"
            } catch (e: Throwable) {
                if (err == null) err = "녹화 파일을 마무리하지 못했어요"
            }
        }
        releaseAll()
        return err
    }

    private fun releaseAll() {
        try { display?.release() } catch (e: Throwable) { }
        try { videoEnc?.stop() } catch (e: Throwable) { }
        try { videoEnc?.release() } catch (e: Throwable) { }
        try { inputSurface?.release() } catch (e: Throwable) { }
        try { audioRec?.release() } catch (e: Throwable) { }
        try { audioEnc?.stop() } catch (e: Throwable) { }
        try { audioEnc?.release() } catch (e: Throwable) { }
        try { muxer?.release() } catch (e: Throwable) { }
        try { pfd?.close() } catch (e: Throwable) { }
        display = null; videoEnc = null; inputSurface = null
        audioRec = null; audioEnc = null; muxer = null
    }

    // ───────────────────────── 영상 ─────────────────────────

    /** 인코더가 받아 주는 가장 큰 크기를 골라 설정한다 (세로 화면 크기도 후보에 그대로 쓴다) */
    private fun setupVideo() {
        val sw = screenW.coerceAtLeast(2)
        val sh = screenH.coerceAtLeast(2)
        val long = maxOf(sw, sh)
        var lastErr: Throwable? = null
        for (target in LONG_SIDES) {
            val scale = minOf(1.0, target.toDouble() / long)
            var enc: MediaCodec? = null
            try {
                enc = MediaCodec.createEncoderByType(VIDEO_MIME)
                val vc = enc.codecInfo.getCapabilitiesForType(VIDEO_MIME).videoCapabilities
                val wa = vc.widthAlignment.coerceAtLeast(2)
                val ha = vc.heightAlignment.coerceAtLeast(2)
                val w = ((sw * scale).toInt() / wa * wa).coerceAtLeast(wa)
                val h = ((sh * scale).toInt() / ha * ha).coerceAtLeast(ha)
                if (!vc.isSizeSupported(w, h)) {
                    enc.release()
                    continue
                }
                val bitrate = (w.toLong() * h * FPS / 10).toInt()
                    .coerceIn(2_000_000, 16_000_000)
                    .let { vc.bitrateRange.clamp(it) }
                val fmt = MediaFormat.createVideoFormat(VIDEO_MIME, w, h).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                    setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                    // 화면이 멈춰 있어도 일정 간격으로 같은 프레임을 다시 내보내 시간표가 끊기지 않게 한다
                    setLong("repeat-previous-frame-after", 1_000_000L / 15)
                }
                enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                inputSurface = enc.createInputSurface()
                enc.start()
                videoEnc = enc
                outW = w
                outH = h
                return
            } catch (e: Throwable) {
                lastErr = e
                try { enc?.release() } catch (x: Throwable) { }
                inputSurface = null
            }
        }
        throw IllegalStateException("size", lastErr)
    }

    private fun videoLoop() {
        val enc = videoEnc ?: return
        val info = MediaCodec.BufferInfo()
        try {
            var eos = false
            while (!eos) {
                val i = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> startMuxer(enc.outputFormat)
                    i >= 0 -> {
                        val buf = enc.getOutputBuffer(i)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && buf != null && muxStarted) {
                            if (vOffset == Long.MIN_VALUE) vOffset = info.presentationTimeUs - nowUs()
                            var t = info.presentationTimeUs - vOffset - baseUs
                            if (t <= vLast) t = vLast + 1
                            vLast = t
                            info.presentationTimeUs = t
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            synchronized(lock) {
                                muxer?.writeSampleData(videoTrack, buf, info)
                                wroteVideo = true
                            }
                        }
                        enc.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eos = true
                    }
                }
            }
        } catch (e: Throwable) {
            if (!stopping) failure = "녹화 중에 문제가 생겨 멈췄어요"
        }
    }

    /**
     * 영상 트랙을 등록하고 muxer 를 시작한다. 소리를 담는 중이면 소리 쪽 형식이 나올 때까지 잠깐(최대 1.5초) 기다리고,
     * 그래도 안 나오면 소리 없이 시작한다 (이후 소리 쪽 쓰기는 버려진다).
     */
    private fun startMuxer(videoFmt: MediaFormat) {
        synchronized(lock) {
            val m = muxer ?: return
            videoTrack = m.addTrack(videoFmt)
            if (hasAudio) {
                val deadline = System.currentTimeMillis() + 1500
                while (audioFormat == null && !stopping) {
                    val left = deadline - System.currentTimeMillis()
                    if (left <= 0) break
                    try { lock.wait(minOf(left, 50)) } catch (e: InterruptedException) { break }
                }
                val af = audioFormat
                if (af != null) audioTrack = m.addTrack(af) else hasAudio = false
            }
            m.start()
            muxStarted = true
            // 시작 전에 모인 소리 조각을 먼저 쓴다
            if (audioTrack >= 0) {
                for (p in pendingAudio) writeAudio(p.info, p.data)
            }
            pendingAudio.clear()
            lock.notifyAll()
        }
    }

    // ───────────────────────── 소리 ─────────────────────────

    @SuppressLint("MissingPermission")
    private fun setupAudio() {
        if (!wantAudioFlag || Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        var rec: AudioRecord? = null
        var enc: MediaCodec? = null
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val af = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord.Builder()
                .setAudioFormat(af)
                .setBufferSizeInBytes((min * 4).coerceAtLeast(16384))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                return
            }
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            audioRec = rec
            audioEnc = enc
            hasAudio = true
        } catch (e: Throwable) {
            // 권한이 없거나 이 기기가 소리 캡처를 못 하면 소리 없이 화면만 녹화한다
            try { rec?.release() } catch (x: Throwable) { }
            try { enc?.release() } catch (x: Throwable) { }
            hasAudio = false
        }
    }

    private fun audioLoop() {
        val rec = audioRec ?: return
        val enc = audioEnc ?: return
        val info = MediaCodec.BufferInfo()
        val buf = ByteArray(4096)
        var total = 0L
        var anchor = -1L
        try {
            rec.startRecording()
            while (!stopping) {
                // 입력 버퍼를 잡기 전에 먼저 읽어 둔다 (읽는 동안 인코더 입력 버퍼를 붙들고 있지 않게)
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                val frames = n / 4
                if (anchor < 0) anchor = nowUs() - baseUs - frames * 1_000_000L / SAMPLE_RATE
                val pts = anchor + total * 1_000_000L / SAMPLE_RATE
                total += frames
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)
                    if (ib != null) {
                        ib.clear()
                        val len = minOf(n, ib.remaining())
                        ib.put(buf, 0, len)
                        enc.queueInputBuffer(idx, 0, len, pts, 0)
                    } else {
                        enc.queueInputBuffer(idx, 0, 0, pts, 0)
                    }
                }
                drainAudio(enc, info, 0)
            }
            try { rec.stop() } catch (e: Throwable) { }
            // 끝 표시를 보내고 남은 조각을 모두 꺼낸다
            val pts = anchor.coerceAtLeast(0) + total * 1_000_000L / SAMPLE_RATE
            var queued = false
            for (k in 0 until 20) {
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    enc.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    queued = true
                    break
                }
                drainAudio(enc, info, 0)
            }
            if (queued) {
                val end = System.currentTimeMillis() + 2000
                while (System.currentTimeMillis() < end) {
                    if (drainAudio(enc, info, 10_000)) break
                }
            }
        } catch (e: Throwable) {
            // 소리만 잃고 화면 녹화는 그대로 이어 간다
            hasAudio = false
            try { rec.stop() } catch (x: Throwable) { }
        }
    }

    /** 인코더가 내놓은 소리 조각을 모두 꺼내 쓴다. 끝 표시를 만나면 true */
    private fun drainAudio(enc: MediaCodec, info: MediaCodec.BufferInfo, timeoutUs: Long): Boolean {
        while (true) {
            val i = enc.dequeueOutputBuffer(info, timeoutUs)
            when {
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    synchronized(lock) {
                        audioFormat = enc.outputFormat
                        lock.notifyAll()
                    }
                }
                i >= 0 -> {
                    val buf = enc.getOutputBuffer(i)
                    val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && info.size > 0 && buf != null) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val data = ByteArray(info.size)
                        buf.get(data)
                        val copy = MediaCodec.BufferInfo()
                        var t = info.presentationTimeUs
                        if (t <= aLast) t = aLast + 1
                        aLast = t
                        copy.set(0, data.size, t, info.flags)
                        synchronized(lock) {
                            if (!muxStarted) {
                                if (pendingAudio.size < 3000) pendingAudio.add(Pending(copy, data))
                            } else if (audioTrack >= 0) {
                                // 소리 없이 시작하기로 한 뒤(audioTrack < 0)에 나온 조각은 버린다
                                writeAudio(copy, data)
                            }
                        }
                    }
                    enc.releaseOutputBuffer(i, false)
                    if (eos) return true
                }
            }
        }
    }

    /** lock 을 잡은 채로 부른다 */
    private fun writeAudio(info: MediaCodec.BufferInfo, data: ByteArray) {
        try {
            muxer?.writeSampleData(audioTrack, java.nio.ByteBuffer.wrap(data), info)
        } catch (e: Throwable) {
            // 소리 한 조각이 안 써져도 녹화는 이어 간다
        }
    }
}
