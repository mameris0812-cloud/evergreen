package com.example.evergreen

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * 웹페이지 번역 (AI 어시스턴트 채팅과는 따로 동작한다).
 * 열려 있는 페이지의 글자를 한국어로 바꾸고, 원문으로 되돌린다.
 * 기본은 키 없는 Google 번역, 'Gemini 로 번역'을 켜 두면 Gemini 를 쓴다.
 * 메뉴의 '페이지 번역' 줄과 AI 어시스턴트의 번역 칩이 같은 인스턴스를 같이 쓴다.
 */
class PageTranslator(
    private val activity: AppCompatActivity,
    private val prefs: Prefs,
    /** 지금 보는 페이지에서 JS 를 실행한다 (페이지가 없으면 결과는 null) */
    private val runPageJs: (String, (String?) -> Unit) -> Unit
) {
    private val ui = Handler(Looper.getMainLooper())

    /** 번역·되돌리기를 시작하기 직전에 부른다 (채팅 창을 닫는 등) */
    var onStart: (() -> Unit)? = null

    private val tpool = Executors.newFixedThreadPool(TRANSLATE_WORKERS)
    private var translating = false
    @Volatile private var tCancelled = false
    @Volatile private var tError: String? = null
    private var tCancels: List<() -> Unit> = emptyList()
    private val tCard = TranslateCard(activity) { prefs.translateCard }
    private var tDone = 0
    private val tApplied = AtomicInteger(0)

    /** 이번 번역이 '항상 번역'으로 저절로 시작된 것인지 / 도중에 다른 페이지로 이동해 멈췄는지 */
    private var autoRun = false
    @Volatile private var navAborted = false

    /**
     * 지금 열려 있는 웹페이지의 글자를 한국어로 바꾼다.
     * 화면에 보이는 부분부터 먼저 번역해서 바로바로 바뀌고, 나머지는 이어서 채운다.
     */
    fun translatePage(auto: Boolean = false) {
        if (translating) return
        // 키 없이도 된다: 키가 없거나 'Gemini 로 번역'이 꺼져 있으면 Google 번역을 쓴다
        val key = prefs.geminiKey
        val model = prefs.geminiModel
        // 직접 누른 번역일 때만 채팅 창 등을 먼저 정리한다 ('항상 번역'은 하던 일을 방해하지 않는다)
        if (!auto) onStart?.invoke()
        autoRun = auto
        navAborted = false
        translating = true
        tCancelled = false
        tError = null
        tDone = 0
        tApplied.set(0)
        // '항상 번역'은 번역할 글이 있다고 확인된 뒤에야 카드를 띄운다 (번역할 게 없는 페이지에서 조용히 넘어가려고)
        if (!auto) tCard.showSearching { cancelTranslate() }

        runPageJs(COLLECT_JS) { raw ->
            var token = ""
            var items: JSONArray? = null
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    val o = JSONObject(inner)
                    token = o.optString("id")
                    items = o.optJSONArray("items")
                }
            } catch (e: Exception) {
                items = null
            }
            val list = items
            if (list == null) {
                if (auto) quietFinish() else finishTranslate("번역할 수 없어요\n번역할 수 있는 웹페이지가 열려 있지 않아요")
            } else if (list.length() == 0) {
                if (auto) quietFinish() else finishTranslate("번역할 글이 없어요\n이미 한국어이거나 글이 없는 페이지예요")
            } else {
                if (auto) tCard.showSearching { cancelTranslate() }
                runBatches(token, list, key, model)
            }
        }
    }

    private fun runBatches(token: String, items: JSONArray, key: String, model: String) {
        // 너무 크지 않게 묶어서 보낸다 (글자 약 3천 자 / 50문장 단위)
        val batches = ArrayList<JSONArray>()
        var cur = JSONArray()
        var chars = 0
        for (k in 0 until items.length()) {
            val o = items.getJSONObject(k)
            val len = o.optString("t").length
            if (cur.length() > 0 && (chars + len > 3000 || cur.length() >= 50)) {
                batches.add(cur)
                cur = JSONArray()
                chars = 0
            }
            cur.put(o)
            chars += len
        }
        if (cur.length() > 0) batches.add(cur)

        val total = batches.size
        tCard.progress(0, total)
        val next = AtomicInteger(0)
        val workersLeft = AtomicInteger(TRANSLATE_WORKERS)
        val clients = List(TRANSLATE_WORKERS) { GeminiClient() }
        val frees = List(TRANSLATE_WORKERS) { FreeTranslator() }
        tCancels = clients.map { c -> { c.cancel() } } + frees.map { f -> { f.cancel() } }

        for (w in 0 until TRANSLATE_WORKERS) {
            val c = clients[w]
            val f = frees[w]
            tpool.execute {
                while (!tCancelled && tError == null) {
                    val k = next.getAndIncrement()
                    if (k >= total) break
                    val (pairs, err) = translateBatch(c, f, key, model, batches[k])
                    if (tCancelled) break
                    if (pairs == null) {
                        if (tError == null) tError = err ?: "번역에 실패했어요"
                        break
                    }
                    tApplied.addAndGet(pairs.length())
                    ui.post { applyPairs(token, pairs, total) }
                }
                if (workersLeft.decrementAndGet() == 0) {
                    ui.post {
                        // '항상 번역' 중에 다른 페이지로 넘어간 건 오류가 아니니 조용히 끝낸다
                        if (autoRun && navAborted) {
                            quietFinish()
                            return@post
                        }
                        val err = tError
                        val n = tApplied.get()
                        finishTranslate(
                            when {
                                tCancelled && err != null -> err
                                tCancelled -> if (n > 0) "번역을 멈췄어요\n${n}개 문장은 번역됐어요" else "번역을 취소했어요"
                                err != null && n > 0 -> "일부만 번역했어요\n$err"
                                err != null -> err
                                else -> "번역 완료\n${n}개 문장을 한국어로 바꿨어요"
                            },
                            ok = !tCancelled && err == null && n > 0,
                            restorable = n > 0
                        )
                    }
                }
            }
        }
    }

    /**
     * 한 묶음을 번역한다. (번역 결과, 오류 메시지)
     * 기본은 키 없는 Google 번역. 'Gemini 로 번역'을 켜 둔 경우엔 Gemini 를 먼저 쓰고,
     * 키 없는 번역이 막히면 (키가 있을 때) Gemini 로 대신한다.
     */
    private fun translateBatch(
        c: GeminiClient, f: FreeTranslator, key: String, model: String, batch: JSONArray
    ): Pair<JSONArray?, String?> {
        val hasKey = key.isNotBlank()
        if (hasKey && prefs.translateWithGemini) return geminiBatch(c, key, model, batch)
        val (res, err) = freeBatch(f, batch)
        if (res != null || tCancelled) return Pair(res, err)
        return if (hasKey) geminiBatch(c, key, model, batch) else Pair(null, err ?: "번역에 실패했어요")
    }

    /** 키 없는 번역으로 한 묶음 번역 */
    private fun freeBatch(f: FreeTranslator, batch: JSONArray): Pair<JSONArray?, String?> {
        val idx = IntArray(batch.length())
        val texts = ArrayList<String>(batch.length())
        for (k in 0 until batch.length()) {
            val o = batch.getJSONObject(k)
            idx[k] = o.optInt("i", -1)
            texts.add(o.optString("t"))
        }
        var lastErr: String? = null
        for (attempt in 0..1) {
            if (tCancelled) return Pair(null, null)
            val (tr, err) = f.translate(texts)
            if (tCancelled) return Pair(null, null)
            if (tr != null) {
                val out = JSONArray()
                for (k in tr.indices) {
                    if (idx[k] >= 0 && tr[k].isNotBlank()) out.put(JSONArray().put(idx[k]).put(tr[k]))
                }
                return if (out.length() == 0) Pair(null, "번역 결과를 읽지 못했어요") else Pair(out, null)
            }
            lastErr = err
            if (attempt == 0) {
                try {
                    Thread.sleep(1200)
                } catch (ie: InterruptedException) {
                    return Pair(null, null)
                }
            }
        }
        return Pair(null, lastErr)
    }

    /** Gemini 로 한 묶음을 번역한다. 실패하면 한 번 더 시도한다. */
    private fun geminiBatch(c: GeminiClient, key: String, model: String, batch: JSONArray): Pair<JSONArray?, String?> {
        var lastErr: String? = null
        for (attempt in 0..1) {
            if (tCancelled) return Pair(null, null)
            val sb = StringBuilder()
            var err: String? = null
            c.stream(
                key, model, TRANSLATE_SYSTEM, listOf(ChatMsg("user", batch.toString())),
                onDelta = { sb.append(it) },
                onDone = {},
                onError = { err = it },
                json = true
            )
            if (tCancelled) return Pair(null, null)
            val e = err
            if (e == null) {
                val parsed = parsePairs(sb.toString())
                if (parsed != null) return Pair(parsed, null)
                lastErr = "번역 결과를 읽지 못했어요"
            } else {
                lastErr = e
            }
            if (attempt == 0) {
                try {
                    Thread.sleep(1200)
                } catch (ie: InterruptedException) {
                    return Pair(null, null)
                }
            }
        }
        return Pair(null, lastErr)
    }

    private fun parsePairs(textIn: String): JSONArray? {
        var t = textIn.trim()
        if (t.startsWith("```")) t = t.substringAfter('\n').substringBeforeLast("```").trim()
        return try {
            val arr = JSONArray(t)
            val out = JSONArray()
            for (k in 0 until arr.length()) {
                val o = arr.optJSONObject(k) ?: continue
                val i = o.optInt("i", -1)
                val tr = o.optString("t", "")
                if (i >= 0 && tr.isNotBlank()) out.put(JSONArray().put(i).put(tr))
            }
            if (out.length() == 0) null else out
        } catch (e: Exception) {
            null
        }
    }

    /** 번역된 글을 웹페이지에 바로 끼워 넣는다. */
    private fun applyPairs(token: String, pairs: JSONArray, total: Int) {
        if (!translating || tCancelled) return
        val js = "(function(){try{return window.__evApply?window.__evApply(" +
            JSONObject.quote(token) + ",JSON.parse(" + JSONObject.quote(pairs.toString()) + ")):-1}catch(e){return -1}})()"
        runPageJs(js) { r ->
            val n = r?.trim()?.toIntOrNull() ?: -1
            if (n < 0) {
                // 다른 페이지로 이동했거나 탭이 바뀌었다
                navAborted = true
                if (tError == null) tError = "다른 페이지로 이동해서 번역을 멈췄어요"
                tCancelled = true
                tCancels.forEach { it() }
            } else {
                tDone++
                tCard.progress(tDone, total)
            }
        }
    }

    private fun cancelTranslate() {
        tCancelled = true
        tCancels.forEach { it() }
    }

    /** 카드나 안내 없이 번역을 끝낸다 ('항상 번역'에서 번역할 게 없거나 페이지를 떠났을 때) */
    private fun quietFinish() {
        translating = false
        tCard.dismiss()
    }

    private fun finishTranslate(msg: String, ok: Boolean = false, restorable: Boolean = false) {
        translating = false
        val lines = msg.split("\n", limit = 2)
        tCard.finish(
            lines[0], lines.getOrNull(1), ok,
            if (restorable) "원문 보기" else null,
            if (restorable) ({ restorePage() }) else null
        )
    }

    /**
     * 메뉴의 '페이지 번역' 한 줄에서 부른다 (채팅 창 없이, 키 없이).
     * 번역 중이면 멈추고, 이미 번역된 페이지면 원문으로 되돌리고, 아니면 번역한다.
     */
    fun togglePageTranslation() {
        if (translating) {
            cancelTranslate()
            return
        }
        runPageJs("(function(){return window.__evT===1?1:0})()") { r ->
            if (r?.trim() == "1") restorePage() else translatePage()
        }
    }

    /**
     * 페이지 로딩이 끝났을 때 부른다. '항상 번역'이 켜져 있으면 저절로 번역한다.
     * (글이 늦게 채워지는 페이지가 많아서 잠깐 기다렸다가 시작한다)
     */
    fun onPageLoaded(url: String) {
        if (!prefs.alwaysTranslate || !url.startsWith("http")) return
        ui.postDelayed({ autoTranslate(0) }, 700)
    }

    /** '항상 번역'을 막 켰을 때: 지금 보는 페이지도 바로 번역한다 */
    fun translateCurrentIfNeeded() {
        if (prefs.alwaysTranslate) autoTranslate(0)
    }

    private fun autoTranslate(attempt: Int) {
        if (!prefs.alwaysTranslate) return
        if (translating) {
            // 이전 페이지 번역이 아직 끝나지 않았으면 멈추고 잠깐 뒤에 다시 시도한다
            if (attempt < 6) {
                cancelTranslate()
                ui.postDelayed({ autoTranslate(attempt + 1) }, 400)
            }
            return
        }
        runPageJs("(function(){return window.__evT===1?1:0})()") { r ->
            // 이미 번역된 페이지(같은 페이지 안에서 다시 로딩이 끝난 경우)는 건드리지 않는다
            if (r?.trim() != "1" && !translating) translatePage(auto = true)
        }
    }

    // ───────────────────────── 번역 설정 ─────────────────────────

    private fun dp(n: Int) = (n * activity.resources.displayMetrics.density).toInt()

    /** 번역 설정 창: 항상 번역 · Gemini 사용 · 진행 카드 */
    fun showSettings() {
        val hasKey = prefs.geminiKey.isNotBlank()
        val sub = ThemeColors.get(activity, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        fun note(text: String) = TextView(activity).apply {
            this.text = text
            textSize = 12f
            setTextColor(sub)
            setPadding(dp(4), 0, 0, dp(10))
        }
        val always = MaterialCheckBox(activity).apply {
            text = "항상 번역"
            textSize = 14f
            isChecked = prefs.alwaysTranslate
        }
        box.addView(always)
        box.addView(note("페이지를 열 때마다 저절로 한국어로 번역해요. 이미 한국어인 페이지는 그대로 둬요."))
        val gemTr = MaterialCheckBox(activity).apply {
            text = "번역에 Gemini 사용"
            textSize = 14f
            isChecked = prefs.translateWithGemini && hasKey
            isEnabled = hasKey
        }
        box.addView(gemTr)
        box.addView(note(
            if (hasKey) "끄면 키 없이 Google 번역으로 번역해요."
            else "Gemini API 키가 있어야 쓸 수 있어요 (AI 설정에서 입력). 키가 없어도 Google 번역으로 번역돼요."
        ))
        val card = MaterialCheckBox(activity).apply {
            text = "번역 진행 카드 표시"
            textSize = 14f
            isChecked = prefs.translateCard
        }
        box.addView(card)
        box.addView(note("끄면 카드 없이 번역하고, 끝났을 때 짧은 안내만 보여요. 카드는 아래로 밀거나 ⌄ 를 눌러 그때그때 숨길 수도 있어요."))

        ThemedDialogBuilder(activity)
            .setTitle("번역 설정")
            .setView(box)
            .setPositiveButton("저장") { _, _ ->
                val wasAlways = prefs.alwaysTranslate
                prefs.alwaysTranslate = always.isChecked
                prefs.translateWithGemini = gemTr.isChecked && prefs.geminiKey.isNotBlank()
                prefs.translateCard = card.isChecked
                if (always.isChecked && !wasAlways) translateCurrentIfNeeded()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    /** 번역한 글을 원래 글로 되돌린다. */
    fun restorePage() {
        onStart?.invoke()
        runPageJs("(function(){return window.__evRestore?window.__evRestore():0})()") { r ->
            val n = r?.trim()?.toIntOrNull() ?: 0
            if (n > 0) tCard.finish("원문으로 되돌렸어요", null, ok = true, actionLabel = "다시 번역", onActionClick = { translatePage() }, withBar = false)
            else tCard.finish("되돌릴 번역이 없어요", null, ok = false, withBar = false)
        }
    }

    companion object {
        private const val TRANSLATE_WORKERS = 3

        private const val TRANSLATE_SYSTEM =
            "You are a translation engine for web page text. " +
                "Input is a JSON array of {\"i\": number, \"t\": string}. " +
                "Translate every \"t\" into natural Korean. " +
                "Keep brand names, product names, code, numbers, URLs and emoji as they are. " +
                "Keep short UI labels (buttons, menus) short. Do not add explanations or notes. " +
                "If a text is already Korean or cannot be translated, return it unchanged. " +
                "Return ONLY a JSON array of the same length with the same \"i\" values: [{\"i\":0,\"t\":\"번역\"}]."

        /**
         * 페이지의 글자(본문 글, 입력창 안내문, 버튼 글)를 모아서 돌려주고,
         * 번역 결과를 끼워 넣는 함수(__evApply)와 되돌리는 함수(__evRestore)를 페이지에 심는다.
         * 화면에 보이는 글이 앞에 오도록 정렬한다.
         */
        private const val COLLECT_JS = """(function(){
try{
var id=String(Math.random()).slice(2);
var T=[],R=window.__evR=window.__evR||[];
var vh=window.innerHeight||800;
function skipText(s){
  var l=(s.match(/[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF\u0590-\u06FF\u0900-\u0DFF\u0E00-\u0E7F\u3040-\u30FF\u3400-\u9FFF\uAC00-\uD7A3]/g)||[]).length;
  if(l===0)return true;
  var h=(s.match(/[\uAC00-\uD7A3]/g)||[]).length;
  return h/l>0.4;
}
function lead(s){return s.slice(0,s.length-s.replace(/^\s+/,'').length)}
function trail(s){return s.slice(s.trimEnd().length)}
var BAD='script,style,noscript,textarea,code,pre,svg,template,iframe,[contenteditable=""],[contenteditable="true"],[translate="no"],.notranslate';
var chars=0;
var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);
var n;
while((n=w.nextNode())){
  if(T.length>=2500||chars>90000)break;
  var p=n.parentElement;if(!p)continue;
  var s=n.nodeValue;if(!s)continue;
  var t=s.trim();if(!t||skipText(t))continue;
  if(p.closest(BAD))continue;
  if(!p.getClientRects().length)continue;
  if(n.__evo===undefined){n.__evo=s;(function(nn){R.push(function(){nn.nodeValue=nn.__evo})})(n);}
  (function(nn,pp,t0,a,b){T.push({y:pp.getBoundingClientRect().top,t:t0,el:pp,set:function(v){nn.nodeValue=a+v+b}})})(n,p,t,lead(s),trail(s));
  chars+=t.length;
}
var els=document.querySelectorAll('input[placeholder],textarea[placeholder],input[type=submit],input[type=button]');
for(var k=0;k<els.length&&T.length<2600;k++){
  var el=els[k];
  var at=el.hasAttribute('placeholder')?'placeholder':'value';
  var v=el.getAttribute(at)||'';var tv=v.trim();
  if(!tv||skipText(tv)||!el.getClientRects().length)continue;
  if(el['__evo_'+at]===undefined){el['__evo_'+at]=v;(function(e,a){R.push(function(){e.setAttribute(a,e['__evo_'+a])})})(el,at);}
  (function(e,a,t0){T.push({y:e.getBoundingClientRect().top,t:t0,el:e,set:function(x){e.setAttribute(a,x)}})})(el,at,tv);
}
var order=[];for(var i=0;i<T.length;i++)order.push(i);
function vis(i){var y=T[i].y;return y>-vh*0.5&&y<vh*1.5}
order=order.filter(vis).concat(order.filter(function(i){return !vis(i)}));
window.__evId=id;
function fl(e){try{
  if(!e||e===document.body||e===document.documentElement||!e.animate)return;
  var r=e.getBoundingClientRect();if(r.bottom<0||r.top>vh)return;
  e.animate([{textShadow:'0 0 12px rgba(47,163,91,0.95), 0 0 3px rgba(47,163,91,0.8)'},{textShadow:'0 0 0 rgba(47,163,91,0)'}],{duration:1100,easing:'ease-out'});
}catch(x){}}
window.__evApply=function(tok,pairs){
  if(tok!==window.__evId)return -1;
  var c=0;
  for(var k=0;k<pairs.length;k++){var it=T[pairs[k][0]];if(it){try{it.set(pairs[k][1]);c++;fl(it.el)}catch(e){}}}
  if(c>0)window.__evT=1;
  return c;
};
window.__evRestore=function(){
  var c=0;
  for(var k=0;k<R.length;k++){try{R[k]();c++}catch(e){}}
  window.__evT=0;
  return c;
};
return JSON.stringify({id:id,items:order.map(function(i){return {i:i,t:T[i].t}})});
}catch(e){return JSON.stringify({id:'',items:null})}
})()"""
    }
}
