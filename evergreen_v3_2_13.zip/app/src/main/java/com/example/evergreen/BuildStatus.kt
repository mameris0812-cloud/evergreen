package com.example.evergreen

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * GitHub Actions 빌드 진행 창("빌드 중… 43%").
 * 저절로 뜨지 않는다. 설정 > 앱 정보 > '빌드 진행 상황'을 눌렀을 때만 [show] 로 띄운다.
 *  - 지금 진행 중인 빌드가 있으면 진행 창을 띄우고, 없으면 안내만 보여 준다.
 *  - 빌드가 끝나면 창이 닫힌다. 성공하면 바로 업데이트를 확인하고, 실패·취소는 알림만 보여 준다.
 *
 * 로그인 없이 쓰는 GitHub API 는 시간당 60번 제한이 있어서 ETag(If-None-Match)를 쓴다.
 * 바뀐 게 없으면 304 로 답하고, 304 는 제한 횟수에 들어가지 않는다. 
 * 파일 올리기에서 저장해 둔 GitHub 토큰이 있으면 그 토큰으로 묻는다 (한도가 시간당 60번 → 5000번). 없거나 안 맞으면 로그인 없이 묻는다.
 * 토큰은 api.github.com 요청 머리글로만 보내고 다른 곳에는 쓰지 않는다.
 */
object BuildStatus {
    private const val POLL_MS = 10_000L       // 진행 창이 떠 있는 동안 확인 간격 (바뀐 게 있을 때)
    private const val POLL_MAX_MS = 20_000L   // 몇 번 연속으로 그대로면 이 간격까지 천천히
    private const val HIDDEN_RECHECK_MS = 3_000L // 앱이 화면에 없을 때는 요청 없이 이 간격으로 돌아왔는지만 본다

    internal class RateLimited(val resetSec: Long) : Exception()

    internal class Snapshot(val status: String, val conclusion: String?, val done: Int, val total: Int, val startedMs: Long)

    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followSslRedirects(false)
        .build()

    private val etags = HashMap<String, String>()
    private val bodies = HashMap<String, String>()

    @Volatile private var showing = false

    /** 토큰이 거절(401)되면 true: 이후로는 토큰 없이 묻는다 */
    @Volatile private var tokenRejected = false

    private fun get(url: String, token: String?): String {
        val useToken = token != null && !tokenRejected
        // 토큰으로 받은 응답과 아닌 응답이 같은 캐시(ETag)를 쓰지 않게 키를 나눈다
        val key = if (useToken) "$url#auth" else url
        val b = Request.Builder().url(url)
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "evergreen-updater")
        if (useToken) b.header("Authorization", "Bearer $token")
        synchronized(etags) { etags[key] }?.let { b.header("If-None-Match", it) }
        client.newCall(b.build()).execute().use { resp ->
            if (resp.code == 401 && useToken) {
                tokenRejected = true
                return get(url, null)
            }
            if (resp.code == 304) {
                return synchronized(bodies) { bodies[key] } ?: throw IllegalStateException("캐시 없음")
            }
            if ((resp.code == 403 || resp.code == 429) && resp.header("x-ratelimit-remaining") == "0") throw RateLimited(resp.header("x-ratelimit-reset")?.toLongOrNull() ?: 0L)
            if (!resp.isSuccessful) throw IllegalStateException("서버 응답 오류 (${resp.code})")
            val text = resp.body?.string() ?: throw IllegalStateException("빈 응답")
            resp.header("ETag")?.let { synchronized(etags) { etags[key] = it } }
            synchronized(bodies) { bodies[key] = text }
            return text
        }
    }

    /** headSha 가 있으면 그 커밋의 빌드를, 없으면 가장 최근 빌드를 가져온다. 없으면 null. */
    internal fun fetch(headSha: String?, token: String?): Snapshot? {
        val base = "https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/actions"
        val q = if (headSha != null) "?head_sha=$headSha&per_page=1" else "?per_page=1"
        val runs = JSONObject(get("$base/runs$q", token)).optJSONArray("workflow_runs")
        if (runs == null || runs.length() == 0) return null
        val run = runs.getJSONObject(0)
        val status = run.optString("status")
        var done = 0
        var total = 0
        if (status == "in_progress") {
            val jobs = JSONObject(get("$base/runs/${run.getLong("id")}/jobs", token)).optJSONArray("jobs")
            val steps = jobs?.takeIf { it.length() > 0 }?.getJSONObject(0)?.optJSONArray("steps")
            if (steps != null) {
                total = steps.length()
                for (i in 0 until total) if (steps.getJSONObject(i).optString("status") == "completed") done++
            }
        }
        // 빌드가 시작된 시각 (UTC, 예: 2026-11-08T05:12:30Z). 못 읽으면 0
        val startedMs = parseIso(run.optString("run_started_at").ifEmpty { run.optString("created_at") })
        return Snapshot(status, run.optString("conclusion").ifEmpty { null }, done, total, startedMs)
    }

    private fun parseIso(t: String): Long = runCatching {
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        f.parse(t)?.time ?: 0L
    }.getOrDefault(0L)

    /** 경과 시간을 "2:05" / "1:02:05" 로 */
    internal fun fmtElapsed(ms: Long): String {
        val sec = (ms / 1000).coerceAtLeast(0)
        val h = sec / 3600
        val m = sec % 3600 / 60
        val ss = sec % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, ss) else String.format(java.util.Locale.US, "%d:%02d", m, ss)
    }

    /** 설정 > 앱 정보에서 눌렀을 때: 진행 중인 빌드가 있으면 진행 창을 띄운다 */
    fun show(act: Activity) {
        if (!Updater.enabled()) {
            AppToast.show(act, "GitHub Actions 로 빌드한 앱에서만 볼 수 있어요")
            return
        }
        track(act)
    }

    private fun track(act: Activity) {
        val headSha: String? = null
        if (showing) return
        showing = true
        val stopped = AtomicBoolean(false)
        val busy = AtomicBoolean(false)
        var dlg: AlertDialog? = null
        var label: TextView? = null
        var bar: ProgressBar? = null
        var timeLabel: TextView? = null
        var startedMs = 0L
        var skewMs = 0L   // 기기 시계와 서버 시각 차이는 무시하고, 처음 본 값이 음수면 0부터 시작하게만 보정

        fun updateTime() {
            val t = timeLabel ?: return
            if (startedMs <= 0L) { t.text = ""; return }
            t.text = "경과 시간 ${fmtElapsed(System.currentTimeMillis() - startedMs + skewMs)}"
        }

        fun finish() {
            stopped.set(true)
            showing = false
            runCatching { dlg?.dismiss() }
        }

        fun ensureDialog() {
            if (dlg != null) return
            // 앱이 화면 밖에 있어도 알림으로 진행률·경과 시간을 보여 주는 서비스
            BuildWatchService.start(act.applicationContext)
            val dp = act.resources.displayMetrics.density
            fun px(v: Int) = (v * dp).toInt()
            // 오류 화면처럼 맨 위에 그림 카드, 그 아래 제목·진행 상태·진행 막대 (가운데 정렬)
            val art = BuildArtView(act)
            val title = TextView(act).apply {
                text = "빌드 중"
                textSize = 16f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_text))
            }
            val l = TextView(act).apply {
                text = "대기 중…"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_muted))
            }
            val tl = TextView(act).apply {
                text = ""
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_muted))
            }
            val b = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                isIndeterminate = true
            }
            val box = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(px(16), px(18), px(16), px(2))
                addView(art, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })
                addView(l, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(4) })
                addView(tl, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(2) })
                addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })
            }
            label = l
            timeLabel = tl
            bar = b
            // 폭을 좁게 (340dp, 아래에서 창 폭을 직접 지정). 그림은 창 폭에 꽉 차게 크게 둔다
            dlg = ThemedDialogBuilder(act, R.style.ThemeOverlay_Evergreen_Dialog_Narrow)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("숨기기") { _, _ -> finish() }
                .show()
            // 테마의 고정 폭이 큰 화면·창에서 안 먹는 경우가 있어서 창 폭을 직접 지정한다 (화면이 더 좁으면 화면 폭까지만)
            dlg?.window?.let { w ->
                val maxW = act.resources.displayMetrics.widthPixels - px(32)
                w.setLayout(minOf(px(340), maxW), android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        }

        fun render(s: Snapshot) {
            val b = bar ?: return
            if (s.startedMs > 0L) {
                startedMs = s.startedMs
                // 기기 시계가 서버보다 느려 경과가 음수로 나오면 0부터 시작하게 맞춘다
                val raw = System.currentTimeMillis() - startedMs
                skewMs = if (raw < 0) -raw else 0L
            }
            updateTime()
            if (s.status == "queued" || s.total == 0) {
                b.isIndeterminate = true
                label?.text = "대기 중…"
            } else {
                val pct = s.done * 100 / s.total
                b.isIndeterminate = false
                b.progress = pct
                label?.text = "빌드 중… $pct%"
            }
        }

        // 저장된 토큰은 확인 스레드에서 처음 쓸 때 읽는다 (기기 보안 저장소를 읽느라 화면이 멈추지 않게)
        val authToken by lazy { runCatching { GitUpload.loadToken(act.applicationContext) }.getOrNull() }
        var wait = POLL_MS
        var lastSig = ""

        // GitHub 확인(10초 간격)과 별개로 경과 시간은 1초마다 갱신한다 (요청 없음)
        fun clock() {
            if (stopped.get()) return
            updateTime()
            main.postDelayed({ clock() }, 1_000L)
        }

        fun tick() {
            if (stopped.get()) return
            // 앱이 화면에 없으면(다른 앱·화면 꺼짐) GitHub 에 묻지 않는다. 돌아오면 바로 이어서 확인한다.
            if (AppForeground.current() == null) {
                main.postDelayed({ tick() }, HIDDEN_RECHECK_MS)
                return
            }
            if (!busy.compareAndSet(false, true)) return
            Thread {
                var snap: Snapshot? = null
                var rate = false
                var resetSec = 0L
                var failed = false
                try {
                    snap = fetch(headSha, authToken)
                } catch (e: RateLimited) {
                    rate = true
                    resetSec = e.resetSec
                } catch (e: Exception) {
                    failed = true
                }
                val s = snap
                main.post {
                    busy.set(false)
                    if (stopped.get()) return@post
                    if (act.isFinishing || act.isDestroyed) { finish(); return@post }
                    when {
                        rate -> {
                            finish()
                            val mins = if (resetSec > 0) ((resetSec * 1000 - System.currentTimeMillis()) / 60_000L + 1).coerceIn(1, 60) else 0
                            AppToast.show(act, if (mins > 0) "GitHub 요청 한도에 도달했어요. 약 ${mins}분 뒤에 다시 확인해 주세요" else "GitHub 요청 한도에 도달했어요. 잠시 뒤 다시 확인해 주세요")
                        }
                        failed -> {
                            // 일시적인 네트워크 오류: 창이 떠 있으면 계속 시도하고, 아니면 조용히 끝낸다
                            if (dlg != null) main.postDelayed({ tick() }, wait)
                            else { finish(); AppToast.show(act, "빌드 상태를 가져오지 못했어요") }
                        }
                        s == null -> {
                            finish()
                            AppToast.show(act, "진행 중인 빌드가 없어요")
                        }
                        s.status == "completed" -> {
                            val shown = dlg != null
                            val took = if (startedMs > 0L) " (경과 ${fmtElapsed(System.currentTimeMillis() - startedMs + skewMs)})" else ""
                            finish()
                            BuildWatchService.stop(act.applicationContext)
                            // 창이 떠 있던 빌드가 끝났으면 결과를 알린다. 처음부터 끝나 있던 빌드면 없다고만 알린다.
                            if (shown) onDone(act, s, took) else AppToast.show(act, "진행 중인 빌드가 없어요")
                        }
                        else -> {
                            ensureDialog()
                            render(s)
                            // 진행이 그대로면 점점 천천히, 바뀌면 다시 기본 간격으로
                            val sig = "${s.status}/${s.done}/${s.total}"
                            wait = if (sig == lastSig) minOf(wait + 5_000L, POLL_MAX_MS) else POLL_MS
                            lastSig = sig
                            main.postDelayed({ tick() }, wait)
                        }
                    }
                }
            }.start()
        }
        clock()
        tick()
    }

    private fun onDone(act: Activity, s: Snapshot, took: String) {
        when (s.conclusion) {
            "success" -> Updater.manualCheck(act)   // 새 버전이 있으면 '새 버전이 있어요' 창이 뜬다
            "cancelled" -> AppToast.show(act, "빌드가 취소됐어요$took")
            else -> AppToast.show(act, "빌드에 실패했어요$took")
        }
    }
}
