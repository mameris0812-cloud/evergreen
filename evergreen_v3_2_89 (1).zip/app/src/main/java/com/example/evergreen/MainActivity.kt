package com.example.evergreen

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.RectF
import android.view.ViewOutlineProvider
import android.widget.ScrollView
import android.widget.SeekBar
import androidx.core.view.doOnLayout
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Rational
import android.util.TypedValue
import android.text.Editable
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringForce
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Filter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

/** 한 프레임에서 재생 중인 미디어 정보 (영상이면 가로·세로 크기) */
class MediaFrame(val video: Boolean, val w: Int, val h: Int)

/** 메뉴의 미디어 플레이어에 보여 줄 재생 진행 상황 (pos·dur 는 초, dur<=0 이면 길이를 모름/라이브) */
class MediaProg(val pos: Double, val dur: Double, val playing: Boolean, val at: Long)

/** 페이지(mediaSession)가 알려 준 지금 곡·영상의 제목과 아티스트 */
class MediaMeta(val title: String, val artist: String, val art: String = "")

/** 메뉴의 미디어 플레이어 파형용 소리 크기 (bands: 0..1 막대 값들, unavailable: 이 페이지는 소리를 읽을 수 없음) */
class MediaWave(val bands: FloatArray?, val unavailable: Boolean, val at: Long)

/**
 * 탭을 다른 창으로 옮길 때 같이 들고 가는 상태.
 * 웹 기록(앞/뒤로 가기), 페이지 확대 비율, 스크롤 위치, 데스크톱 보기, 음소거, 재생 속도를 그대로 이어 준다.
 */
class TabHandoff(
    val url: String?,
    val title: String?,
    val desktop: Boolean,
    val incognito: Boolean,
    val pageZoom: Int?,
    val muted: Boolean,
    val rate: Float,
    val state: Bundle?,
    val scrollRatio: Float,
    val scrollX: Int,
    val scrollY: Int
)

class BrowserTab(initial: WebView? = null) {
    private var wv: WebView? = initial

    /** 복원된 탭은 실제로 열 때까지 WebView 만들기를 미룬다 (앱 시작이 빨라진다). 처음 webView 에 접근할 때 한 번 실행된다 */
    var lazyInit: (() -> Unit)? = null

    var webView: WebView
        get() {
            if (wv == null) {
                val init = lazyInit
                lazyInit = null
                init?.invoke()
            }
            return wv ?: error("WebView 가 아직 만들어지지 않았습니다")
        }
        set(v) { wv = v }

    /** 이미 만들어진 WebView (없으면 null). 모든 탭을 훑는 작업에서 WebView 를 억지로 만들지 않기 위해 쓴다 */
    val liveWebView: WebView? get() = wv

    /** 시크릿 탭: 방문 기록·탭 복원에 남지 않고, 쿠키·저장소는 별도 프로필에 담겼다가 탭을 다 닫으면 지워진다 */
    var incognito: Boolean = false

    /** HTTPS 우선: 이 탭이 https 로 올려서 연결을 시도 중인 원래 http 주소 */
    var upgradedFrom: String? = null

    /** 이번 페이지 로드에서 강제 다크(CSS) 스타일을 이미 넣었는지 */
    var darkInjected: Boolean = false

    /** 지금 재생 중인 미디어가 있는 프레임들 (키: 프레임 id). 비어 있으면 재생 중이 아님 */
    val mediaFrames = HashMap<String, MediaFrame>()

    /** 프레임별 재생 진행 상황 (메뉴의 미디어 플레이어용). 페이지를 떠나면 지워진다 */
    val mediaProg = HashMap<String, MediaProg>()

    /** 프레임별 제목·아티스트 (페이지가 mediaSession 으로 알려 준 것). 곡이 바뀌면 같이 바뀐다 */
    val mediaMeta = HashMap<String, MediaMeta>()

    /** 프레임별 영상 화면에서 직접 뜬 썸네일 (페이지가 그림 주소를 안 주거나 받기에 실패했을 때 쓴다) */
    val mediaThumb = HashMap<String, Bitmap>()

    /** 프레임별 실시간 소리 크기 (메뉴의 미디어 플레이어가 열려 있는 동안만 들어온다) */
    val mediaWave = HashMap<String, MediaWave>()

    /** 메뉴의 미디어 플레이어에서 삭제한 프레임 (키: 프레임 id, 값: 삭제한 시각). 다시 재생하기 전까지 카드에 나오지 않는다 */
    val mediaDismissed = HashMap<String, Long>()

    /** 영상 아래 '내장 플레이어로 열기' 를 누른 순간 페이지가 알려 준 영상 위치: 왼쪽·위·너비·높이(CSS px, 보이는 영역 기준)·보이는 폭(CSS px) */
    @Volatile
    var zoomRaw: DoubleArray? = null
    @Volatile
    var zoomRawAt = 0L

    /** 불러오지 못해 오류 화면을 보여 주는 중인 주소 (새로고침하면 이 주소를 다시 불러온다) */
    var errorUrl: String? = null

    /** 이 페이지에서 오간 영상/스트리밍 주소 (내장 플레이어용). 페이지가 바뀌면 비운다. */
    val sniffed: MutableSet<String> = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    /** 이 페이지에서 오간 자막 파일 주소 (.vtt/.srt/.ass/.ttml). 자바스크립트 플레이어가 따로 불러오는 자막까지 내장 플레이어에 넘기려고 모은다 */
    val sniffedSubs: MutableSet<String> = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    var progress: Int = 100
    var rate: Float = 1f

    /** 홈으로 나가면서 로딩을 중단시킨 탭: 페이지로 돌아오면 다시 불러온다 */
    var stoppedByHome: Boolean = false

    /** 마지막으로 안정돼 있던 스크롤 위치의 비율 (0~1, 모르면 -1). 창 크기·비율이 바뀌어 내용이 다시 배치돼도 같은 자리로 돌아오려고 쓴다 */
    var scrollRatio: Float = -1f

    /** 0 = 그룹 없음 */
    var groupId: Int = 0

    /** 이번 페이지 로드에서 광고 숨김 CSS를 이미 넣었는지 */
    var cosmeticInjected: Boolean = false

    /** 이 페이지가 자체 로딩 바(맨 위 가는 진행 막대)를 가지고 있다 → 브라우저 로딩 바는 숨긴다 */
    var ownProgressBar: Boolean = false
    var ownBarChecks: Int = 0

    /** 이 페이지(이번 주소 이동)에서 막은 광고 건수 — 백그라운드 스레드에서 올라간다 */
    val adBlocked = java.util.concurrent.atomic.AtomicInteger(0)

    var favicon: Bitmap? = null

    /** 탭 화면에 보여줄 페이지 미리보기 (탭을 떠날 때 / 탭 화면을 열 때 갱신) */
    var thumb: Bitmap? = null

    /** 이 탭을 연 탭 (뒤로가기로 탭을 닫으면 여기로 돌아간다) */
    var opener: BrowserTab? = null

    /** 데스크톱 사이트 요청 */
    var desktop: Boolean = false

    /** 이 페이지에 데스크톱 뷰포트를 이미 적용했는지 */
    var desktopInjected: Boolean = false

    /** 이 탭에만 적용한 페이지 확대/축소 (%). null 이면 전체 설정(prefs.pageZoom)을 따른다 */
    var pageZoom: Int? = null

    /** 이 페이지에 확대/축소를 이미 적용했는지 */
    var zoomInjected: Boolean = false

    /** 앱을 다시 켰을 때 복원된 탭: 선택하기 전까지는 불러오지 않고 주소/제목만 들고 있다 */
    var pendingUrl: String? = null
    var pendingTitle: String? = null

    /** 디스크에 저장해 둔 웹 기록 파일 이름에 쓰는 탭 고유 번호 (0 = 아직 없음) */
    var stateId: Long = 0L

    /** 다른 창에서 넘어온 탭의 웹 기록(WebView.saveState). 처음 불러올 때 주소만 여는 대신 이 상태 그대로 되살린다 */
    var pendingState: Bundle? = null

    /** 넘어온 탭이 되살아난 뒤 맞출 스크롤 위치 (비율 우선, 모르면 -1 / 픽셀 위치) */
    var pendingScrollRatio: Float = -1f
    var pendingScrollX: Int = 0
    var pendingScrollY: Int = 0
    var restoreScrollPending: Boolean = false

    /** 새 탭 홈 화면을 보여주는 중인지 (홈 화면은 웹 기록에 들어 있는 항목이라 뒤로/앞으로 가기로 오갈 수 있다) */
    var isHome: Boolean = false

    /** 홈 항목이 다 불러와지면 웹 기록을 비운다 (마지막 탭을 닫아 새 탭으로 되돌릴 때) */
    var clearAtHome: Boolean = false

    /** 탭 음소거: true 면 이 탭의 모든 소리(video/audio/WebAudio)를 끈다 */
    @Volatile var muted: Boolean = false

    /** 홈에서 다른 페이지로 넘어가는 중: 새 페이지의 첫 화면이 그려질 때까지 웹뷰(이전 페이지 잔상)를 가리고 홈을 보여 준다 */
    var awaitCommit: Boolean = false

    /** WebView 를 onPause 시켜 둔 상태인지 (홈 화면이거나 다른 탭을 보는 중) */
    var paused: Boolean = false

    /** 페이지 스크립트(window.open)가 연 팝업 탭인지: 광고 팝업 판별에 쓴다 */
    var scriptPopup: Boolean = false

    /** JS 알림창 도배 방지용: 최근 몇 번 띄웠는지 / 마지막 시각 */
    var jsDialogCount: Int = 0
    var jsDialogAt: Long = 0L

    /** 렌더러가 마지막으로 죽은 시각 (같은 페이지가 계속 죽는지 보려고) */
    var crashAt: Long = 0L

    /** 이어보기: 마지막으로 본 영상 위치(초)와 그때의 페이지 주소. 페이지가 다시 불러와져도(렌더러 종료·앱 복원) 그 지점으로 돌아간다 */
    var resumePos: Double = 0.0
    var resumeUrl: String? = null
    /** 이어보기 위치를 가볍게 저장한 마지막 시각 (uptimeMillis) */
    var resumeLightAt: Long = 0L

    /** true 면 같은 페이지가 다시 로드를 마쳤을 때 resumePos 로 한 번 이어서 재생한다 */
    var resumeApply: Boolean = false

    /** 마지막으로 뒤로가기를 한 시각 (uptimeMillis) */
    var backAt: Long = 0L

    /** 뒤로가기로 도착한 기록의 주소 / 떠나온 기록의 주소 / 그때까지 페이지를 만진 마지막 시각 (자동 이동 판단용) */
    var backTargetUrl: String? = null
    var backLeftUrl: String? = null
    var backTouchMark: Long = 0L

    /** 뒤로가기로 돌아오면 스스로 다른 곳으로 되돌려 보내는 페이지 주소 (뒤로가기 때 건너뛴다) */
    val redirectSources = HashSet<String>()

    /** 마지막으로 화면을 뗀 시각(uptimeMillis)과, 그때 누른 곳이 링크였는지 ('클릭 가로채기' 판단용) */
    @Volatile var tapAt: Long = 0L
    @Volatile var tapOnLink: Boolean = false
    /** 손가락이 처음 닿은 시각 / 웹뷰가 잰 '눌린 링크 주소' (사진 링크처럼 주소를 모르면 null) */
    @Volatile var tapDownAt: Long = 0L
    @Volatile var tapHref: String? = null
    /** 페이지 스크립트가 알려 온 '눌린 곳을 감싼 링크 주소'(없으면 빈 문자열)와 그 시각: 웹뷰가 재는 것보다 정확하고 터치 순간부터 알 수 있다 */
    @Volatile var tapJsHref: String = ""
    @Volatile var tapJsAt: Long = 0L
    /** 마지막으로 확인하고 통과시킨 메인 프레임 이동 시각: 그 뒤 곧바로 이어지는 서버 리다이렉트(링크 → 추적 주소 → 도착 주소)를 통과시키려고 */
    @Volatile var lastHopAt: Long = 0L
    /** 스크립트 팝업의 첫 요청을 이미 '클릭 가로채기'로 검사했는지 */
    @Volatile var popupVetted: Boolean = false

    /** 지금 보여 주는 페이지의 호스트 (자바스크립트 통로가 '이 페이지에 대한 요청인지' 확인할 때 쓴다) */
    @Volatile var curHost: String? = null

    /** 팝업 탭이 열릴 때 연 페이지의 주소 (팝업이 처음 가는 곳이 엉뚱한 사이트인지 보려고) */
    @Volatile var popupFromUrl: String? = null
}

open class MainActivity : AppCompatActivity() {

    /** 첫 번째 창만 탭을 저장·복원한다 (여러 창이 같은 저장소를 덮어쓰지 않게) */
    private var isPrimary = false
    private var restoreSlot = false

    /** 창 번호 (창 1, 창 2 …). 열려 있는 동안 바뀌지 않는다 */
    private var windowNo = 0

    /** 사용자가 붙인 창 이름 (없으면 "창 1", "창 2" …). 창 번호별로 저장돼서 창을 닫았다 다시 열어도 남는다 */
    private var windowName: String?
        get() = prefs.windowName(windowNo)
        set(v) = prefs.setWindowName(windowNo, v)
    private val windowLabel: String get() = windowName ?: "창 $windowNo"

    /** 새 창을 따로 띄운다 (최근 앱에 별개 항목으로 생기고, 멀티윈도우에서는 옆에 붙는다) */
    internal fun openNewWindow(
        url: String? = null,
        restoreNo: Int = 0,
        handoff: TabHandoff? = null,
        mode: Int = WIN_DEFAULT,
        dropX: Int = 0,
        dropY: Int = 0,
        inheritNo: Int = 0,
        adjacent: Boolean = true,
        bounds: Rect? = null
    ) {
        val handoffId = if (handoff != null) ++handoffSeq else 0L
        if (handoff != null) handoffs[handoffId] = handoff
        // 팝업은 '옆에 붙이기' 대신 떠 있는 창으로 열어야 해서 ADJACENT 를 빼고, 나머지는 예전처럼 옆에 붙인다
        var flags = Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
        if (mode != WIN_POPUP && adjacent) flags = flags or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
        startActivity(
            Intent(this, BrowserWindowActivity::class.java).addFlags(flags).apply {
                // 주소는 넘긴 상태를 못 찾았을 때(예: 앱 프로세스가 다시 시작됐을 때)를 위한 예비
                if (url != null) data = Uri.parse(url)
                if (handoffId != 0L) putExtra(EXTRA_HANDOFF, handoffId)
                if (restoreNo > 0) {
                    putExtra(EXTRA_WINDOW_NO, restoreNo)
                    putExtra(EXTRA_RESTORE, true)
                } else if (inheritNo > 0) {
                    // 이 창이 곧 닫히고 탭이 새 창으로 넘어가는 경우: 새 창이 이 창의 번호를 이어받는다 (번호가 2부터 시작하지 않게)
                    putExtra(EXTRA_WINDOW_NO, inheritNo)
                }
            },
            if (bounds != null) boundsLaunchOptions(bounds) else windowLaunchOptions(mode, dropX, dropY)
        )
    }

    /** 새 창이 놓일 자리를 이 창이 있던 화면 좌표 그대로 알린다 (떠 있는 창에서 쓰인다. 분할 화면에서는 시스템이 무시하고 같은 칸에 연다) */
    private fun boundsLaunchOptions(r: Rect): Bundle? {
        if (Build.VERSION.SDK_INT < 24) return null
        return try {
            android.app.ActivityOptions.makeBasic().apply { setLaunchBounds(r) }.toBundle()
        } catch (e: Throwable) {
            null
        }
    }

    /**
     * 이 창이 '떠 있는 창'(팝업·자유 창)일 때 차지하는 영역 (화면 좌표). 분할 화면의 칸이거나 알 수 없으면 null.
     * 분할 칸은 시스템이 알아서 같은 칸에 열어 주고, 칸에 영역을 따로 알리면 오히려 떠 있는 창으로 열릴 수 있어서 알리지 않는다.
     * (분할 칸은 화면의 가로나 세로를 가득 채우고, 떠 있는 창은 둘 다 채우지 않는다는 점으로 가른다)
     */
    private fun floatingWindowBounds(): Rect? {
        val v = window?.decorView ?: return null
        if (v.width <= 0 || v.height <= 0) return null
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val r = Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
        val s = screenBounds()
        val tol = dp(4)
        val fillsWidth = r.width() >= s.width() - tol
        val fillsHeight = r.height() >= s.height() - tol
        return if (fillsWidth || fillsHeight) null else r
    }

    /**
     * 새 창이 놓일 자리를 시스템에 알린다 (시스템 화면 기준).
     * 팝업: 놓은 자리 중심의 떠 있는 창(자유 창 모드).
     * 자유 창을 지원하지 않는 기기에서는 시스템이 무시하고 평소처럼 새 창으로 열린다.
     */
    private fun windowLaunchOptions(mode: Int, x: Int, y: Int): Bundle? {
        if (mode == WIN_DEFAULT || Build.VERSION.SDK_INT < 24) return null
        return try {
            val s = screenBounds()
            val rect = when (mode) {
                else -> {
                    val w = (s.width() * 0.6f).toInt().coerceIn(minOf(dp(360), s.width()), s.width())
                    val h = (s.height() * 0.7f).toInt().coerceIn(minOf(dp(420), s.height()), s.height())
                    val l = (x - w / 2).coerceIn(s.left, s.right - w)
                    val t = (y - h / 2).coerceIn(s.top, s.bottom - h)
                    Rect(l, t, l + w, t + h)
                }
            }
            val o = android.app.ActivityOptions.makeBasic()
            o.setLaunchBounds(rect)
            val b = o.toBundle() ?: Bundle()
            // 팝업은 자유 창(freeform, 5) 으로 요청한다. 지원하지 않는 기기에서는 무시된다
            if (mode == WIN_POPUP) b.putInt("android.activity.windowingMode", 5)
            b
        } catch (e: Throwable) {
            null
        }
    }

    /** 시스템 화면 전체 크기 (앱 창이 일부만 차지해도 화면 기준) */
    private fun screenBounds(): Rect {
        if (Build.VERSION.SDK_INT >= 30) return windowManager.maximumWindowMetrics.bounds
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }


    private lateinit var prefs: Prefs
    private var unwatchBookmarks: (() -> Unit)? = null
    private lateinit var adBlocker: AdBlocker

    private lateinit var urlBar: AutoCompleteTextView
    private lateinit var progressBar: LoadBarView
    private lateinit var webContainer: PullRefreshLayout
    private lateinit var pageScrollBar: WebPageScrollBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnTabs: View
    private lateinit var tabCount: TextView
    private lateinit var btnBottomTabs: View
    private lateinit var tabCountBottom: TextView
    private lateinit var stripTabCount: TextView
    private lateinit var btnMenu: ImageButton
    private lateinit var fullscreenContainer: FullscreenSwipeLayout
    private lateinit var homeTagline: TextView
    private var homeTaglineDefault: CharSequence = ""
    private lateinit var findBar: View
    private lateinit var etFind: EditText
    private lateinit var findCount: TextView
    private lateinit var browserUi: View
    private lateinit var bottomBar: View
    private val tabStripBar: View by lazy { findViewById<View>(R.id.tabStripBar) }
    private lateinit var btnFloatMenu: ImageButton
    /** 상/하단바 숨김 중에도 주소창이 필요할 때(Ctrl+L, 버튼 길게 누르기) 잠깐 바를 보여 주는 표시 */
    private var barsTempShown = false
    private var barsHiddenNow = false
    private lateinit var tabStripScroll: StripScrollView
    private lateinit var tabStrip: LinearLayout
    private lateinit var navGroup: View
    private lateinit var tbBack: ImageButton
    private lateinit var tbForward: ImageButton
    private lateinit var tbHome: ImageButton
    private lateinit var tbMenu: ImageButton
    private lateinit var tbDesktop: ImageButton
    private lateinit var tbAi: ImageButton
    private lateinit var tabletActions: View
    private lateinit var homeView: View
    private lateinit var homeContent: View
    private lateinit var tabSwitcher: View
    private lateinit var tabList: LinearLayout
    private lateinit var tabScroll: ScrollView
    private lateinit var tabsTitle: TextView
    private lateinit var tabMorph: ImageView
    private var switcherOpen = false
    private var switcherBusy = false
    private val switcherRows = HashMap<BrowserTab, View>()
    private val switcherBoxes = HashMap<Int, View>()

    /** 탭 화면의 선택 모드: 탭을 여러 개 골라 한 번에 닫는다 */
    private var switcherSelecting = false
    private val switcherSel = LinkedHashSet<BrowserTab>()
    // 선택 모드의 카드 바탕 · 체크 동그라미. 카드를 다시 만들지 않고 이 그림들의 진행도만 움직여 부드럽게 바꾼다.
    private val selCardBg = HashMap<BrowserTab, SelectCardDrawable>()
    private val selCardCheck = HashMap<BrowserTab, CheckCircleDrawable>()
    private val selGroupCheck = HashMap<Int, CheckCircleDrawable>()
    private val selHeaderMembers = HashMap<Int, List<BrowserTab>>()
    private var selEntering = false
    private var selAllCheck: CheckCircleDrawable? = null
    private var delPillAnim: android.animation.ValueAnimator? = null
    private var delPillReady: Boolean? = null
    private var delPill: GradientDrawable? = null
    private var morphRadius = 0f
    private var assistant: AssistantUi? = null

    /** 꾹 눌러서 뜨는 메뉴의 「자동 스크롤」 (처음 쓸 때 만든다) */
    private var autoScrollerInst: AutoScroller? = null
    private val autoScroller: AutoScroller
        get() = autoScrollerInst ?: AutoScroller(
            act = this,
            prefs = prefs,
            allowed = { wv ->
                current?.liveWebView === wv && !switcherOpen && customView == null && !mirrorActive &&
                    !isInPictureInPictureModeCompat()
            },
            liftProvider = { toastLift() },
            notify = { msg -> toast(msg) }
        ).also { autoScrollerInst = it }
    /** 페이지 번역 (AI 어시스턴트와 따로: 메뉴의 '페이지 번역'과 어시스턴트의 번역 칩이 같이 쓴다) */
    private var pageTranslator: PageTranslator? = null

    /** 태블릿(넓은 화면) 레이아웃 사용 중인지 */
    private var expanded = false
    private var stripRefreshQueued = false
    private var windowStripQueued = false
    private var lastStripCurrent: BrowserTab? = null
    private var baseUserAgent: String = ""
    @Volatile private var lastTouchAt = 0L
    private fun recentTouch(windowMs: Long = 5000L) = android.os.SystemClock.uptimeMillis() - lastTouchAt < windowMs

    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null

    private val groups = mutableListOf<TabGroup>()
    private var nextGroupId = 1

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    @Volatile
    private var adBlockEnabled = true
    private val trackerBlocker = TrackerBlocker()
    private var strictTrackers = false
    private var skipCaptchaTracking = false
    private var malwareWarning = true
    private var blockAutoDownload = true
    private var hijackGuard = true
    /** 웹페이지에서 마지막으로 손가락이 닿은 위치 (웹뷰 안 좌표): 꾹 눌러 뜨는 메뉴를 그 아래에 띄우는 데 쓴다 */
    @Volatile private var tapX = 0f
    @Volatile private var tapY = 0f
    /** 이번 실행 동안 '이동' 을 눌러 허락한 사이트 (등록 도메인 기준) */
    private val hijackAllowed: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()
    // 스크롤 시 바 숨김: 설정의 '스크롤해서 상/하단바 숨기기'. 고정 숨김(hideBars)이 켜져 있으면 바가 이미 없으므로 쓰지 않는다.
    private val hideBarsOnScroll: Boolean get() = prefs.hideBarsOnScroll && !prefs.hideBars
    private val scrollBars = ScrollBarsController(
        // 팝업(자유 창)에서 탭 줄이 제목줄 안에 들어가 있으면 그 줄은 시스템 창 버튼 자리이므로 숨기지 않고 주소창만 숨긴다
        topBars = { if (captionActive) listOf(toolbarView) else listOf(tabStripBar, toolbarView) },
        bottomBar = { bottomBar },
        followers = { listOf(progressBar) },
        webFrame = { webContainer.parent as? View },
        allowed = {
            hideBarsOnScroll && !switcherOpen && !urlBar.hasFocus() && findBar.visibility != View.VISIBLE &&
                customView == null && current?.isHome == false && assistant?.isSplitOpen() != true
        },
        animationsOn = { Motion.enabled(this) },
        // 제목줄(시스템 창 버튼) 인셋이 있는 창에서는 그 자리까지 페이지가 올라오지 않게 한다
        topPad = { if (::browserUi.isInitialized) (browserUi.parent as? View)?.paddingTop ?: 0 else 0 },
        statusInset = { if (capInsetTop > 0 || !::browserUi.isInitialized) 0 else (browserUi.parent as? View)?.paddingTop ?: 0 },
        onFullyHidden = { hidden -> applyStatusBarForScroll(hidden) },
        bottomInset = { navBottomInset }
    )
    /** 내비게이션 바 자리 높이 (키보드가 그보다 높게 올라와 있으면 0) */
    private var navBottomInset = 0
    private var capInsetTop = 0
    private val toolbarView by lazy { findViewById<View>(R.id.toolbar) }

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val suggestItems = mutableListOf<String>()
    private lateinit var suggestAdapter: SuggestAdapter
    private var suggestRunnable: Runnable? = null
    private var suppressWatcher = false
    private var askedNotificationPermission = false

    /**
     * 설정 > 앱 정보 > 'GitHub 에 파일 올리기': 파일(zip 포함)을 고르면 GitUpload 가 풀지 않고 그대로 저장소에 올린다.
     * 삼성 기기에서는 '내 파일' 로 바로 열고, 없거나 열 수 없으면 시스템 파일 선택(앱 고르기)으로 넘어간다.
     */
    private val gitPickLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            if (result.resultCode == RESULT_OK && uri != null) GitUpload.upload(this, uri)
        }

    // ───────────────────────── 크롬 확장 프로그램 ─────────────────────────

    private val extensions by lazy { ExtensionManager(this) }

    /** 설정 > 확장 프로그램 > 추가: zip / crx 파일을 고르면 풀어서 설치한다 */
    private val extPickLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            if (result.resultCode != RESULT_OK || uri == null) {
                showExtensions()
                return@registerForActivityResult
            }
            toast("확장 프로그램을 설치하는 중…")
            extensions.onInstallStep = { m -> ui.post { toast(m) } }
            io.execute {
                try {
                    val e = extensions.install(uri)
                    ui.post {
                        toast("'${e.name}' 설치 완료" + if (e.entries.isEmpty() && !e.hasBackground) " (웹페이지에 넣는 스크립트가 없어요)" else "")
                        applyExtensions()
                        showExtensions()
                        showOptResult(e)
                    }
                } catch (ex: Exception) {
                    ui.post {
                        toast("설치 실패: ${ex.message ?: "알 수 없는 오류"}")
                        showExtensions()
                    }
                }
            }
        }

    private fun launchExtPicker() {
        val base = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
        try {
            extPickLauncher.launch(Intent(base).setPackage("com.sec.android.app.myfiles")) // 삼성 내 파일
            return
        } catch (e: Exception) { /* 삼성 내 파일이 없으면 아래로 */ }
        try {
            extPickLauncher.launch(Intent.createChooser(base, "확장 프로그램 파일(zip · crx) 선택"))
        } catch (e: Exception) {
            toast("파일 선택 화면을 열지 못했어요")
        }
    }

    /** 설정 > 확장 프로그램 > ＋ 추가: 고르는 창 없이 크롬 웹스토어를 새 탭으로 바로 연다 */
    private fun showExtAddChooser() {
        createTab("https://chromewebstore.google.com/", opener = current)
    }

    /** 웹스토어 주소 또는 확장 프로그램 ID 를 적으면 바로 내려받아 설치한다. 지금 보는 페이지가 웹스토어 상세면 미리 채워 둔다 */
    private fun askStoreInstall() {
        val pad = dp(20)
        val box = FrameLayout(this)
        val here = current?.liveWebView?.url?.takeIf { ExtensionManager.parseStoreId(it) != null }
        val field = EditText(this).apply {
            hint = "웹스토어 주소 또는 확장 프로그램 ID"
            setText(here.orEmpty())
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        Popup.styleInput(field)
        box.setPadding(pad, dp(4), pad, 0)
        box.addView(field)
        ThemedDialogBuilder(this)
            .setTitle("크롬 웹스토어에서 추가")
            .setMessage("웹스토어에서 확장 프로그램 페이지의 주소를 복사해 붙여 넣거나, 영문 32자 ID 를 적어 주세요.")
            .setView(box)
            .setPositiveButton("설치") { _, _ -> installFromStore(field.text?.toString().orEmpty()) }
            .setNeutralButton("웹스토어 열기") { _, _ ->
                createTab("https://chromewebstore.google.com/", opener = current)
            }
            .setNegativeButton("취소") { _, _ -> showExtensions() }
            .setOnCancelListener { showExtensions() }
            .show()
    }

    /** 설치 직후: evergreen 에 맞게 최적화한 결과를 보여 준다 */
    private fun showOptResult(e: ExtensionManager.Ext) {
        val sum = extensions.optSummary(e) ?: return
        if (isFinishing || isDestroyed) return
        ThemedDialogBuilder(this)
            .setTitle("evergreen에 맞게 최적화했어요")
            .setMessage("'${e.name}'\n\n$sum")
            .setPositiveButton("확인", null)
            .show()
    }

    private fun installFromStore(input: String, onDone: ((Boolean) -> Unit)? = null) {
        if (ExtensionManager.parseStoreId(input) == null) {
            toast("웹스토어 주소나 확장 프로그램 ID 를 확인해 주세요")
            onDone?.invoke(false)
            if (onDone == null) askStoreInstall()
            return
        }
        toast("웹스토어에서 내려받는 중…")
        extensions.onInstallStep = { m -> ui.post { toast(m) } }
        io.execute {
            try {
                val e = extensions.installFromStore(input)
                ui.post {
                    toast("'${e.name}' 설치 완료" + if (e.entries.isEmpty() && !e.hasBackground) " (웹페이지에 넣는 스크립트가 없어요)" else "")
                    onDone?.invoke(true)
                    applyExtensions()
                    showExtensions()
                    showOptResult(e)
                }
            } catch (ex: Exception) {
                ui.post {
                    toast("설치 실패: ${ex.message ?: "알 수 없는 오류"}")
                    onDone?.invoke(false)
                    showExtensions()
                }
            }
        }
    }

    /**
     * 웹스토어 상세 페이지의 'Chrome에 추가' 버튼을 'evergreen에 추가'로 바꾸고 누르면 여기로 온다.
     * 페이지가 넘긴 주소는 믿지 않고, 이 탭이 지금 실제로 보는 주소가 웹스토어 상세 페이지일 때만 설치한다 (시크릿 탭 제외).
     */
    private inner class StoreJs(val tab: BrowserTab) {
        /** 이 웹스토어 주소의 확장 프로그램이 이미 evergreen 에 설치돼 있는가 (버튼을 '삭제'로 바꾸는 데 쓴다) */
        @JavascriptInterface
        fun installed(href: String): Boolean {
            val id = ExtensionManager.parseStoreId(href) ?: return false
            return extensions.installedIdForStore(id) != null
        }

        /** 'evergreen에서 삭제' 버튼: 지금 보는 웹스토어 페이지의 확장 프로그램을 지운다 */
        @JavascriptInterface
        fun remove() {
            ui.post {
                val wv = tab.liveWebView ?: return@post
                if (tab.incognito) return@post
                val real = wv.url ?: return@post
                if (!(real.startsWith("https://chromewebstore.google.com/") || real.startsWith("https://chrome.google.com/webstore/"))) return@post
                val id = ExtensionManager.parseStoreId(real) ?: return@post
                val localId = extensions.installedIdForStore(id)
                val e = localId?.let { lid -> extensions.list().find { it.id == lid } }
                if (e == null) { wv.evaluateJavascript("window.__evxState&&window.__evxState(false)", null); return@post }
                extensions.remove(e.id)
                toast("'${e.name}' 삭제했어요")
                applyExtensions()
                wv.evaluateJavascript("window.__evxState&&window.__evxState(true)", null)
            }
        }

        /** 웹스토어 페이지를 열면 호출: 설치하기 전에 evergreen 과 호환되는지 확인해, 안 되면 버튼을 회색으로 바꾼다 */
        @JavascriptInterface
        fun checkCompat(href: String) {
            val id = ExtensionManager.parseStoreId(href) ?: return
            if (extensions.installedIdForStore(id) != null) return
            io.execute {
                val reason = try { extensions.storeIncompat(href) } catch (e: Exception) { null }
                // 예전에 설치해서 웹스토어 ID 짝이 없던 확장 프로그램은, 받아 본 manifest 로 알아보고 버튼을 '삭제'로 바꾼다
                val nowInstalled = extensions.installedIdForStore(id) != null
                if (nowInstalled || reason != null) ui.post {
                    val wv = tab.liveWebView ?: return@post
                    val cur = wv.url ?: return@post
                    if (ExtensionManager.parseStoreId(cur) != id) return@post
                    if (nowInstalled) wv.evaluateJavascript("window.__evxState&&window.__evxState(true)", null)
                    else wv.evaluateJavascript("window.__evxCompat&&window.__evxCompat(" + org.json.JSONObject.quote(reason ?: "") + "," + ExtensionManager.isHardIncompat(reason ?: "") + ")", null)
                }
            }
        }

        @JavascriptInterface
        fun install() {
            ui.post {
                val wv = tab.liveWebView ?: return@post
                if (tab.incognito) return@post
                val real = wv.url ?: return@post
                if (!(real.startsWith("https://chromewebstore.google.com/") || real.startsWith("https://chrome.google.com/webstore/"))) return@post
                val sid = ExtensionManager.parseStoreId(real) ?: return@post
                val warn = extensions.cachedIncompat(sid)
                if (warn != null) {
                    if (ExtensionManager.isHardIncompat(warn)) {
                        wv.evaluateJavascript("window.__evxState&&window.__evxState(false)", null)
                        return@post
                    }
                    // 지원하지 않는 기능이 있어도 사용자가 원하면 설치한다 (그 기능만 동작하지 않는다)
                    val back = { wv.evaluateJavascript("window.__evxState&&window.__evxState(false)", null); Unit }
                    ThemedDialogBuilder(this@MainActivity)
                        .setTitle("일부 기능이 동작하지 않을 수 있어요")
                        .setMessage("$warn.\n\n그 기능만 빠지고 나머지는 쓸 수 있는 경우가 많아요. 그래도 설치할까요?")
                        .setPositiveButton("설치") { _, _ ->
                            installFromStore(real) { ok ->
                                wv.evaluateJavascript("window.__evxState&&window.__evxState(" + ok + ")", null)
                            }
                        }
                        .setNegativeButton("취소") { _, _ -> back() }
                        .setOnCancelListener { back() }
                        .show()
                    return@post
                }
                installFromStore(real) { ok ->
                    wv.evaluateJavascript("window.__evxState&&window.__evxState(" + ok + ")", null)
                }
            }
        }
    }

    /** 웹스토어 상세 페이지를 열었을 때 한 번 '설치' 알림을 띄운다 (같은 확장 프로그램은 연달아 다시 묻지 않는다) */
    private var lastStorePromptId: String? = null

    @Suppress("UNUSED_PARAMETER")
    private fun offerStoreInstall(tab: BrowserTab, url: String, title: String?) {
        // 2.9.15: 「크롬 웹스토어 확장 프로그램이에요」 알림은 더 이상 띄우지 않는다 (페이지의 「evergreen에 추가」 버튼으로 설치한다)
        if (true) return
        if (tab.incognito || tab !== current) return
        val id = ExtensionManager.parseStoreId(url) ?: return
        if (extensions.list().any { it.id == id }) return
        if (id == lastStorePromptId) return
        lastStorePromptId = id
        val name = title?.substringBefore(" - ")?.trim()?.takeIf { it.isNotEmpty() }
        AppToast.showAction(this, "크롬 웹스토어 확장 프로그램이에요", name, "설치") { installFromStore(url) }
    }

    /** 상/하단바의 확장 프로그램 버튼 (태블릿에서는 이 버튼 바로 아래에 목록이 뜬다). 설정에서 열 때는 null */
    private var extAnchorRef: java.lang.ref.WeakReference<View>? = null

    private fun showExtensions() {
        // 테마만 고를 때는 바로(지연·페이지 새로고침 없이) 적용한다
        ExtensionsUi.themeNow = { if (!isFinishing && !isDestroyed) applyExtTheme() }
        ExtensionsUi.show(
            this, extensions,
            onAdd = { showExtAddChooser() },
            onOpenPage = { url -> createTab(url, opener = current) },
            onOpenPopup = { e ->
                initExtensionHooks()
                if (extensions.popupOf(e) == null && extensions.sidePanelOf(e) != null)
                    ExtensionPopup.showSidePanel(this, extensions, e) { url -> createTab(url, opener = current) }
                else ExtensionPopup.show(this, extensions, e) { url -> createTab(url, opener = current) }
            },
            onChanged = { applyExtensionsSoon() },
            anchor = extAnchorRef?.get()
        )
    }

    private var extHooksSet = false

    /** 확장 프로그램이 지금 보는 탭을 묻거나 새 탭을 열 때 쓰는 연결 (한 번만 설정) */
    private fun initExtensionHooks() {
        if (extHooksSet) return
        extHooksSet = true
        extensions.activeWebView = { current?.takeIf { !it.incognito }?.liveWebView }
        extensions.onSidePanel = { e -> ExtensionPopup.showSidePanel(this, extensions, e) { url -> createTab(url, opener = current) } }
        extensions.openTab = { url -> createTab(url, opener = current) }
        // history · bookmarks · topSites: 앱의 기록과 북마크를 확장 프로그램에 (읽기 전용)
        extensions.dataProvider = { kind, arg ->
            val q = arg.lowercase()
            val arr = org.json.JSONArray()
            when (kind) {
                "history" -> prefs.historyItems().asSequence()
                    .filter { q.isEmpty() || it.url.lowercase().contains(q) || it.title.lowercase().contains(q) }
                    .take(1000)
                    .forEachIndexed { i, h ->
                        arr.put(
                            org.json.JSONObject().put("id", i.toString()).put("url", h.url).put("title", h.title)
                                .put("lastVisitTime", h.time.toDouble()).put("visitCount", 1).put("typedCount", 0)
                        )
                    }
                "bookmarks" -> prefs.bookmarks().forEach { b ->
                    arr.put(org.json.JSONObject().put("id", b.id.toString()).put("url", b.url).put("title", b.title))
                }
            }
            arr.toString()
        }
        // notifications.create → 앱 알림, downloads.download → 앱 다운로드
        extensions.commandHandler = { kind, arg ->
            when (kind) {
                "notify" -> try {
                    val o = org.json.JSONObject(arg)
                    val title = o.optString("title")
                    val msg = o.optString("message")
                    val text = if (title.isNotEmpty() && msg.isNotEmpty()) "$title · $msg" else title + msg
                    if (text.isNotBlank()) AppToast.show(this, text)
                } catch (e: Exception) { }
                "download" -> if (arg.startsWith("http://") || arg.startsWith("https://")) startDownload(arg, null, null, null)
            }
        }
    }

    /** 보고 있는 탭의 이동 · 로드 상태를 확장 프로그램(tabs.onUpdated · webNavigation)에 알린다. 시크릿 탭 · 홈 · 웹 주소가 아닌 것은 알리지 않는다 */
    private fun extNavEvent(tab: BrowserTab, phase: String, url: String) {
        if (tab.incognito || tab !== current || tab.isHome || url == HOME_URL) return
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        val title = try { tab.liveWebView?.title.orEmpty() } catch (e: Exception) { "" }
        extensions.dispatchEvent("nav", org.json.JSONObject().put("phase", phase).put("url", url).put("title", title).toString())
    }

    /** 탭을 바꿨을 때 tabs.onActivated 를 알린다 */
    private fun extActivatedEvent() {
        val t = current ?: return
        if (t.incognito || t.isHome) return
        extensions.dispatchEvent("activated", "{}")
    }

    /** 확장 프로그램을 켜거나 끄거나 바꾼 뒤: 열려 있는 모든 탭에 다시 연결하고, 지금 보는 페이지는 새로 불러온다 */
    private val applyExtRunnable = Runnable { if (!isFinishing && !isDestroyed) applyExtensions() }

    /** 스위치를 연달아 눌러도 한 번만 적용하도록 잠깐 모았다가 적용한다 */
    private fun applyExtensionsSoon() {
        ui.removeCallbacks(applyExtRunnable)
        ui.postDelayed(applyExtRunnable, 250)
    }

    // ── 크롬 테마(웹스토어): 탭바 · 툴바 · 하단바 · 주소창 · 탭 · 상태표시줄에 색을 입힌다 ──
    private var themeSpec: ExtensionManager.ThemeSpec? = null
    private var barFg: Int? = null          // 툴바·하단바 아이콘/글자색 (테마가 없으면 null = 기본색)
    private var stripFgSel: Int? = null     // 선택된 탭 글자색
    private var stripFgUnsel: Int? = null   // 선택 안 된 탭 글자·버튼색
    private var stripSelBg: Int? = null     // 선택된 탭 바탕(툴바와 이어지는 색)
    private var pillFg: Int? = null         // 주소창 안 글자·아이콘색
    private var pillTint: android.content.res.ColorStateList? = null
    private var pillText: android.content.res.ColorStateList? = null
    private var pillHint: android.content.res.ColorStateList? = null
    private var themedStatusIcons = false

    /** [bg] 위에서 잘 읽히는 색. 테마가 정한 색이 대비가 모자라면 흰색/검정 계열로 바꾼다 */
    private fun readableOn(bgIn: Int, want: Int?): Int {
        val bg = bgIn or 0xFF000000.toInt()   // calculateContrast 는 반투명 배경이면 예외를 낸다
        if (want != null) {
            val w = ColorUtils.setAlphaComponent(want, 255)
            if (ColorUtils.calculateContrast(w, bg) >= 3.0) return w
        }
        return if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF1F1F1F.toInt() else 0xFFF1F3F4.toInt()
    }

    /** 뷰 트리의 아이콘·글자에 [fg] 를 입힌다 ([skip] 안쪽은 건드리지 않는다). reset 이면 탭 개수 아이콘의 색 덮어쓰기도 걷어낸다 */
    private fun tintTree(v: View, fg: Int, skip: View?, reset: Boolean) {
        if (v === skip || v is android.widget.EditText || v.tag == "noTint") return
        when (v) {
            is ImageView -> v.imageTintList = android.content.res.ColorStateList.valueOf(fg)
            is TextView -> {
                // 탭 개수 버튼의 숫자는 아이콘(MorphIconDrawable)이 직접 그린다. 글자는 보이지 않아야 하니 색을 입히지 않는다
                // (입히면 글자와 아이콘의 숫자가 겹쳐 보인다)
                val bgIcon = v.background as? MorphIconDrawable
                v.setTextColor(if (bgIcon != null) android.graphics.Color.TRANSPARENT else fg)
                if (bgIcon != null) {
                    // 탭 버튼 아이콘은 reset 일 때도 지금 색을 직접 입힌다.
                    // View.setBackgroundTintList(null) 은 그림에 남은 예전 틴트를 걷어 내지 못해서,
                    // 테마를 끄거나 바꾸면 옛 테마 글자색(예: 흰색)이 그대로 남아 같은 색 바 위에서 탭 버튼이 사라졌다
                    val csl = android.content.res.ColorStateList.valueOf(fg)
                    bgIcon.setTintList(csl)
                    v.backgroundTintList = csl
                } else if (v.background != null) {
                    v.backgroundTintList = if (reset) null else android.content.res.ColorStateList.valueOf(fg)
                }
            }
            is ViewGroup -> for (i in 0 until v.childCount) tintTree(v.getChildAt(i), fg, skip, reset)
        }
    }

    private val themeBmCache = HashMap<String, android.graphics.Bitmap?>()

    /** 테마 그림 비트맵 (같은 그림은 한 번만 읽는다). 못 읽으면 null */
    private fun themeBitmap(f: java.io.File?): android.graphics.Bitmap? {
        f ?: return null
        return themeBmCache.getOrPut(f.path + ":" + f.lastModified()) {
            try { android.graphics.BitmapFactory.decodeFile(f.path) } catch (e: Throwable) { null }
        }
    }

    /**
     * 새 탭 배경 그림. 화면보다 훨씬 큰 그림(몇 MB)은 메모리·그리기 부담이 크므로 긴 변이 화면 긴 변의 2배를 넘지 않게 줄여 읽는다.
     * 한 장만 크게 깔리는(no-repeat) 배경만 줄인다 — 반복 배경은 그림 크기로 타일 크기가 정해지므로 원본 그대로.
     */
    private fun ntpBitmap(f: java.io.File?, repeat: String): android.graphics.Bitmap? {
        f ?: return null
        if (repeat != "no-repeat") return themeBitmap(f)
        return themeBmCache.getOrPut(f.path + ":" + f.lastModified() + ":ntp") {
            try {
                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeFile(f.path, o)
                val dm = resources.displayMetrics
                val limit = maxOf(dm.widthPixels, dm.heightPixels) * 2
                var sample = 1
                while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= limit) sample *= 2
                android.graphics.BitmapFactory.decodeFile(f.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
            } catch (e: Throwable) { null }
        }
    }

    /** 테마 그림(크롬 1x 기준)을 화면 밀도에 맞춰 가로로 타일처럼 까는 드로어블. 못 읽으면 null */
    private fun themeTileDrawable(f: java.io.File?, extendDown: Boolean = false, origin: ((FloatArray) -> Unit)? = null): android.graphics.drawable.Drawable? {
        f ?: return null
        return themeBitmap(f)?.let { ThemeTileDrawable(it, resources.displayMetrics.density, origin, extendDown) }
    }

    /** [v] 의 왼쪽 위가 [anc] 안에서 놓인 자리(px). 이동(translation)은 빼고 배치 자리만 센다 — 바가 밀려 숨는 동안에도 그림이 바와 함께 움직이게 */
    private fun layoutPosIn(v: View, anc: View, out: IntArray): Boolean {
        var x = 0; var y = 0
        var c: View = v
        while (c !== anc) {
            x += c.left; y += c.top
            val p = c.parent as? View ?: return false
            if (p !== anc) { x -= p.scrollX; y -= p.scrollY }
            c = p
        }
        out[0] = x; out[1] = y
        return true
    }

    private val themePosTmp = IntArray(2)
    private val themeBasePosTmp = IntArray(2)

    /**
     * 테마 그림이 시작하는 자리를 [host] 기준으로 계산해 [out] 에 넣는다.
     * 크롬은 창 맨 위(상태표시줄 자리 포함)를 기준으로 탭바 그림(theme_frame)을 깔고,
     * 툴바 그림(theme_toolbar)은 탭 줄 맨 위에서 시작해 선택된 탭 → 툴바로 끊김 없이 이어서 깐다.
     * [toolbar] 가 true 면 툴바 그림 기준(탭 줄이 보이면 탭 줄 맨 위, 없으면 창 맨 위), false 면 창 맨 위.
     */
    private fun themeOrigin(host: View, toolbar: Boolean, out: FloatArray) {
        val root = (if (::browserUi.isInitialized) browserUi.parent as? View else null) ?: return
        if (!layoutPosIn(host, root, themePosTmp)) return
        var baseY = 0
        if (toolbar && tabStripBar.visibility == View.VISIBLE && layoutPosIn(tabStripBar, root, themeBasePosTmp)) baseY = themeBasePosTmp[1]
        out[0] = -themePosTmp[0].toFloat()
        out[1] = (baseY - themePosTmp[1]).toFloat()
    }

    private var homeGlassBmp: android.graphics.Bitmap? = null   // 새 탭 배경을 흐리게 만든 작은 그림 (테마의 새 탭 배경이 있을 때)
    private var homeGlassScale = 0.1f
    private var homeGlassW = 0
    private var homeGlassH = 0

    /** 새 탭 배경(테마)을 흐리게 만들어 둔다. 버튼·카드 뒤에 유리처럼 깔린다. 배경이 없거나 화면 크기를 모르면 null */
    private fun rebuildHomeGlass() {
        val th = themeSpec
        val bgd = homeView.background as? ThemeHomeBgDrawable
        val w = homeView.width; val h = homeView.height
        if (th == null || !th.hasNtp || bgd == null) { homeGlassBmp = null; return }
        // 아직 크기가 없으면(숨겨져 있거나 배치 전) 있던 흐린 배경을 지우지 않고 그대로 둔다. 크기가 정해지면 다시 만든다
        if (w <= 0 || h <= 0) return
        if (homeGlassBmp != null && homeGlassW == w && homeGlassH == h) return
        try {
            val sc = 0.1f
            val bw = maxOf(2, (w * sc).toInt()); val bh = maxOf(2, (h * sc).toInt())
            val bmp = android.graphics.Bitmap.createBitmap(bw, bh, android.graphics.Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(bmp)
            c.scale(bw.toFloat() / w, bh.toFloat() / h)
            val ob = android.graphics.Rect(bgd.bounds)
            bgd.setBounds(0, 0, w, h); bgd.draw(c); bgd.bounds = ob
            refineHomeFg(bmp)
            homeGlassBmp = ThemeGlassDrawable.blur(bmp, 3)
            bmp.recycle()
            homeGlassScale = bw.toFloat() / w
            homeGlassW = w; homeGlassH = h
        } catch (e: Throwable) { homeGlassBmp = null }
        // 글자·위젯 갱신이 실패해도 만들어 둔 흐린 배경은 버리지 않는다
        try { styleHomeTexts(); refreshHomeWidget() } catch (e: Throwable) {}
    }

    private var homeLinkTheme: Int? = null     // 새 탭 구역 제목(개인정보) 글자색
    private var homeScrimNeeded = false        // 배경 그림이 너무 복잡해 글자색만으로는 부족할 때 (그림자·진한 유리를 더 쓴다)
    private var homeBgLumLo = 0.0              // 실제로 그려진 새 탭 배경의 어두운 쪽 밝기 (하위 12%)
    private var homeBgLumHi = 1.0              // 밝은 쪽 밝기 (상위 12%)

    private fun lumContrast(a: Double, b: Double): Double = (maxOf(a, b) + 0.05) / (minOf(a, b) + 0.05)

    /**
     * 실제로 그려진 새 탭 배경(색 + 그림)의 밝기 분포를 보고 글자색을 다시 고른다.
     * 이전에는 테마의 '배경색'만 보고 글자색을 골라서, 그림이 어둡거나 밝을 때(또는 섞여 있을 때) 글씨가 묻혔다.
     * 후보(테마 글자색 → 흰색 → 검은색) 중 배경의 가장 밝은 곳·어두운 곳 모두에서 대비 4.5 이상인 첫 색을 쓴다.
     */
    private fun refineHomeFg(src: android.graphics.Bitmap) {
        val th = themeSpec ?: return
        val w = src.width; val h = src.height
        if (w <= 0 || h <= 0) return
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val ls = DoubleArray(px.size) { ColorUtils.calculateLuminance(px[it] or 0xFF000000.toInt()) }
        ls.sort()
        val lo = ls[(ls.size * 0.12).toInt().coerceIn(0, ls.size - 1)]
        val hi = ls[(ls.size * 0.88).toInt().coerceIn(0, ls.size - 1)]
        homeBgLumLo = lo; homeBgLumHi = hi
        fun worst(c: Int): Double {
            val l = ColorUtils.calculateLuminance(c)
            if (l in lo..hi) return 1.0
            return minOf(lumContrast(l, lo), lumContrast(l, hi))
        }
        val white = 0xFFF7F8F9.toInt(); val dark = 0xFF1A1C1E.toInt()
        val fixed = if (worst(white) >= worst(dark)) white else dark
        fun pick(want: Int?): Int {
            if (want != null) {
                val c = ColorUtils.setAlphaComponent(want, 255)
                if (worst(c) >= 4.5) return c
            }
            return fixed
        }
        val fg = pick(th.ntpText)
        homeFgTheme = fg
        homeLinkTheme = pick(th.ntpLink ?: th.ntpText)
        homeScrimNeeded = worst(fg) < 4.5
    }

    private fun homeShadow(tv: TextView?) {
        tv ?: return
        val fg = homeFgTheme
        if (fg == null) { tv.setShadowLayer(0f, 0f, 0f, 0); return }
        val light = ColorUtils.calculateLuminance(fg) > 0.5
        val a = if (homeScrimNeeded) 0xB3 else 0x66
        tv.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(),
            ColorUtils.setAlphaComponent(if (light) 0xFF000000.toInt() else 0xFFFFFFFF.toInt(), a))
    }

    /** 테마 새 탭 화면의 글자(구역 제목·안내 문구)에 고른 글자색과, 그림 위에서도 읽히는 옅은 그림자를 입힌다 */
    private fun styleHomeTexts() {
        val tagline = findViewById<TextView>(R.id.homeTagline)
        val header = findViewById<TextView>(R.id.homeWidgetHeader)
        val fg = homeFgTheme
        if (fg != null) {
            tagline?.setTextColor(ColorUtils.setAlphaComponent(fg, 235))
            header?.setTextColor(homeLinkTheme ?: fg)
        }
        homeShadow(tagline); homeShadow(header)
    }

    /** 유리 배경(흐린 배경 + 옅은 색)을 [host] 에 입힌다. 흐린 그림이 없으면 null */
    private fun homeGlassFor(host: View, cornerDp: Int): android.graphics.drawable.Drawable? {
        // 테마가 새 탭 카드 색(ntp_section)을 정했으면 유리 대신 그 색(투명도 포함)으로 카드를 칠한다
        themeSpec?.takeIf { it.hasNtp }?.ntpSection?.let { sec ->
            return GradientDrawable().apply { setColor(sec); cornerRadius = dp(cornerDp).toFloat() }
        }
        val bmp = homeGlassBmp ?: return null
        val fg = homeFgTheme ?: return null
        val darkBg = ColorUtils.calculateLuminance(fg) > 0.5   // 글자가 밝으면 배경은 어둡다
        // 글자가 밝은데 배경 그림이 밝으면 진한 검정 유리로 눌러 주고, 글자가 어두운데 배경이 어두우면 하얀 유리로 받쳐 준다
        val tint = if (darkBg) {
            if (homeBgLumHi > 0.2 || homeScrimNeeded) 0x80000000.toInt() else 0x26FFFFFF
        } else {
            if (homeBgLumLo < 0.4 || homeScrimNeeded) 0xCCFFFFFF.toInt() else 0x99FFFFFF.toInt()
        }
        val d = ThemeGlassDrawable(
            bmp, homeGlassScale, host, homeView, dp(cornerDp).toFloat(),
            tint, ColorUtils.setAlphaComponent(fg, 0x33), dp(1).toFloat()
        )
        homeGlassDrawables.removeAll { it.get() == null }
        homeGlassDrawables.add(java.lang.ref.WeakReference(d))
        return d
    }

    /** 밝은 크롬 테마에서 새 탭의 바로가기·카드를 칠하는 하늘색. 그 외에는 null */
    private fun chromeSky(): Int? =
        themeSpec?.takeIf { it.chromeTabs && ColorUtils.calculateLuminance(it.frame) > 0.5 }?.let { 0xFFD3E3FD.toInt() }

    /** 새 탭의 위젯 카드 두 개: 테마 배경이 있으면 유리 모양 + 글자색, 없으면 기본 카드 */
    private fun applyHomeGlassToWidgets() {
        val fg = homeFgTheme
        var glassOn = false
        for (id in intArrayOf(R.id.homeAdCard, R.id.homeSecCard)) {
            val card = findViewById<View>(id) ?: continue
            val sky = chromeSky()
            val g = if (sky != null) null else homeGlassFor(card, 24)
            if (sky != null) card.background = GradientDrawable().apply { setColor(sky); cornerRadius = dp(24).toFloat() }
            else if (g != null) { card.background = g; glassOn = true } else card.setBackgroundResource(R.drawable.bg_home_widget)
        }
        // 유리가 깔렸을 때만 테마 글자색을 쓴다 (기본 카드 위에 밝은 글자가 얹히는 일 방지)
        // 크롬 테마(하늘색 카드)에서는 글자·아이콘이 초록(기본 강조색)이 아니라 하늘색 위에서 읽히는 테마 색을 쓴다
        val skyFg = chromeSky()?.let { readableOn(it, themeSpec?.ntpText) }
        val textFg = skyFg ?: if (glassOn && fg != null) (homeSectionFg ?: fg) else themeColor(com.google.android.material.R.attr.colorOnSurface, R.color.ev_text)
        for (id in intArrayOf(R.id.homeAdText, R.id.homeSecText)) {
            findViewById<TextView>(id)?.setTextColor(textFg)
        }
        // 광고 차단 카드와 보안 현황 카드의 아이콘은 같은 색
        val cardIconTint = android.content.res.ColorStateList.valueOf(
            skyFg ?: if (glassOn && fg != null) (homeSectionFg ?: fg) else themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)
        )
        for (id in intArrayOf(R.id.homeAdCard, R.id.homeSecCard))
            (findViewById<ViewGroup>(id)?.getChildAt(0) as? ImageView)?.imageTintList = cardIconTint
    }

    /** 새 탭 화면 크기가 정해지거나 바뀐 뒤: 흐린 배경을 다시 만들고 버튼·카드에 입힌다 */
    private fun refreshHomeGlass() {
        if (!::homeView.isInitialized || !::homeContent.isInitialized) return
        rebuildHomeGlass()
        applyHomeGlassToWidgets()
        refreshHomeShortcuts()
    }

    // 지금 새 탭 버튼·카드에 입혀진 유리들. 스크롤·떠오르는 애니메이션으로 배경 위에서 움직이면 다시 그려 배경과 맞춘다
    private val homeGlassDrawables = ArrayList<java.lang.ref.WeakReference<ThemeGlassDrawable>>()

    private var homeFgTheme: Int? = null   // 새 탭 화면 글자색 (테마에 새 탭 색·그림이 있을 때만)
    private var homeSectionFg: Int? = null // 새 탭 카드(ntp_section) 위 글자색 (카드 색이 있을 때만)

    private fun defaultHomeBg(): android.graphics.drawable.Drawable {
        // 위쪽에 연한 초록빛이 번지는 배경
        val base = ThemeColors.get(homeView, com.google.android.material.R.attr.colorSurfaceContainer)
        val tint = ThemeColors.get(homeView, com.google.android.material.R.attr.colorPrimaryContainer)
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(androidx.core.graphics.ColorUtils.blendARGB(base, tint, 0.65f), base, base)
        )
    }

    /** 테마의 새 탭 배경(색·그림)과 글자색을 새 탭 화면에 입힌다. 테마가 없거나 새 탭 설정이 없으면 기본 모양으로 */
    private fun applyHomeTheme() {
        if (!::homeView.isInitialized) return
        val th = themeSpec
        val tagline = findViewById<TextView>(R.id.homeTagline)
        val header = findViewById<TextView>(R.id.homeWidgetHeader)
        if (th == null || !th.hasNtp) {
            homeFgTheme = null; homeLinkTheme = null; homeScrimNeeded = false; homeSectionFg = null
            homeBgLumLo = 0.0; homeBgLumHi = 1.0
            homeView.background = defaultHomeBg()
            tagline?.setTextColor(themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted))
            header?.setTextColor(themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_text))
        } else {
            val bg = th.ntpBg ?: th.toolbar
            val bm = ntpBitmap(th.ntpImage, th.ntpRepeat)
            homeView.background = ThemeHomeBgDrawable(bm, bg, th.ntpAlign, th.ntpRepeat, resources.displayMetrics.density)
            // 먼저 배경색 기준으로 임시 글자색을 입히고, 화면 크기가 정해지면 실제 그림 밝기로 다시 고른다 (refineHomeFg)
            val fg = readableOn(bg, th.ntpText)
            homeFgTheme = fg
            homeLinkTheme = readableOn(bg, th.ntpLink ?: th.ntpText)
            homeScrimNeeded = false
            homeBgLumLo = 0.0; homeBgLumHi = 1.0
            // 카드 색(ntp_section)이 있으면 배경 위에 얹은 색을 기준으로 카드 글자색을 고른다
            homeSectionFg = th.ntpSection?.let { sec ->
                readableOn(ColorUtils.compositeColors(sec, ColorUtils.setAlphaComponent(bg, 255)), th.ntpSectionText ?: th.ntpText)
            }
            tagline?.setTextColor(ColorUtils.setAlphaComponent(fg, 235))
            header?.setTextColor(homeLinkTheme!!)
        }
        styleHomeTexts()
        if (::homeContent.isInitialized) { homeGlassBmp = null; refreshHomeGlass(); refreshHomeWidget() }
    }

    private fun applyExtTheme() {
        val th = try { extensions.activeTheme() } catch (e: Exception) { null }
        themeSpec = th
        // 앱을 켤 때는 prefs 가 아직 만들어지기 전에 불릴 수 있다 → 그때는 직접 읽는다 (여기서 오류가 나면 테마가 통째로 안 입혀진다)
        val themeMenus = if (::prefs.isInitialized) prefs.themeMenus else Prefs(this).themeMenus
        ThemeColors.set(if (themeMenus) th else null)   // 메뉴·팝업·목록 화면 등 앱 전체가 같은 테마 색을 쓰게 한다 (설정에서 끄면 창들은 앱 기본 색)
        themeBmCache.clear()
        if (urlTextDefault == null) { urlTextDefault = urlBar.textColors; urlHintDefault = urlBar.hintTextColors }
        val defIcon = themeColor(com.google.android.material.R.attr.colorOnSurface, R.color.ev_text)
        val defSub = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val pillBox = urlBar.parent as? View
        if (th == null) {
            barFg = null; stripFgSel = null; stripFgUnsel = null; stripSelBg = null
            pillFg = null; pillTint = null; pillText = null; pillHint = null
            toolbarView.setBackgroundResource(R.drawable.bg_toolbar)
            bottomBar.setBackgroundResource(R.drawable.bg_bottom_bar)
            tabStripBar.setBackgroundColor(themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill_high))
            tintTree(toolbarView, defIcon, pillBox, true)
            tintTree(bottomBar, defIcon, null, true)
            btnRefresh.imageTintList = android.content.res.ColorStateList.valueOf(defSub)
            findViewById<ImageView>(R.id.btnStripNewTab)?.imageTintList = android.content.res.ColorStateList.valueOf(defSub)
            findViewById<View>(R.id.btnStripTabList)?.let { tintTree(it, defIcon, null, true) }
            applyStripNewTabShape()
        } else {
            val tb = th.toolbar
            val fg = readableOn(tb, th.icon ?: th.tabText)
            barFg = fg
            val line = ColorUtils.blendARGB(tb, fg, 0.16f)
            val tbImg = themeTileDrawable(th.toolbarImage, extendDown = true) { o -> themeOrigin(toolbarView, true, o) }   // 아래 북마크바 자리까지 그림을 이어 칠한다
            toolbarView.background = android.graphics.drawable.LayerDrawable(
                (listOfNotNull<android.graphics.drawable.Drawable>(android.graphics.drawable.ColorDrawable(tb), tbImg) +
                    android.graphics.drawable.ColorDrawable(line)).toTypedArray()
            ).apply { val li = numberOfLayers - 1; setLayerHeight(li, dp(1)); setLayerGravity(li, Gravity.BOTTOM) }
            bottomBar.background = android.graphics.drawable.LayerDrawable(arrayOf(
                android.graphics.drawable.ColorDrawable(tb),
                android.graphics.drawable.ColorDrawable(line)
            )).apply { setLayerHeight(1, dp(1)); setLayerGravity(1, Gravity.TOP) }
            tintTree(toolbarView, fg, pillBox, false)
            tintTree(bottomBar, fg, null, false)

            // 주소창: 테마의 주소창 색, 없으면 툴바 색에 글자색을 살짝 섞은 색
            // 주소창 색이 없을 때: 탭 배경 그림을 쓰는 옛 크롬 테마는 크롬처럼 흰색, 그 밖에는 툴바 색에 글자색을 살짝 섞은 색
            val pill = th.omnibox ?: if (th.tabBgImage != null) 0xFFFFFFFF.toInt() else ColorUtils.blendARGB(tb, fg, 0.10f)
            val pf = readableOn(pill, th.omniboxText)
            pillFg = pf
            pillTint = android.content.res.ColorStateList.valueOf(pill)
            pillText = android.content.res.ColorStateList.valueOf(pf)
            pillHint = android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(pf, 150))
            btnRefresh.imageTintList = android.content.res.ColorStateList.valueOf(pf)

            // 탭바: 테마의 frame 색(+그림), 선택된 탭은 툴바와 같은 색으로 이어진다 (창이 비활성이면 frame_inactive)
            stripSelBg = if (th.samsungTabs) th.samsungSel else tb   // 삼성 테마: 선택된 탭은 툴바와 다른 흰색
            stripFgSel = readableOn(stripSelBg ?: tb, th.tabText)
            applyStripFrame(restyleChips = false)
        }
        // 이미 그려진 탭들에도 바뀐 색을 입힌다
        for (c in stripChips.values) styleStripChip(c)
        scheduleStripRefresh() // 크롬 테마 여부에 따라 새 탭 아이콘이 달라진다
        applyUrlPillColors(current?.incognito == true)
        current?.let { t -> updateSecurityIcon(t.liveWebView?.url, t.incognito) }
        updateStatusBarColor()
        applyHomeTheme()
        applyAppChromeColors()
        refreshBookmarkBar()
        // 웹사이트 로딩 바: 테마가 켜져 있으면 테마의 강조색, 꺼지면 앱 기본(colorPrimary)
        // 단, 크롬 · 삼성 테마는 밝은 모드든 다크 모드든 늘 파란색 (크롬 파랑 / 삼성 파랑)
        progressBar.progressTintList = android.content.res.ColorStateList.valueOf(when {
            themeSpec?.chromeTabs == true -> 0xFF1A73E8.toInt()
            themeSpec?.samsungTabs == true -> 0xFF2F7DF0.toInt()
            else -> ThemeColors.get(this, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        })
        // 인셋·창 배치가 끝난 뒤에도 한 번 더 맞춘다 (앱을 켤 때 상태표시줄 자리가 아직 정해지기 전에 불려 어둡게 남는 것 방지)
        ui.post { if (!isFinishing && !isDestroyed) updateStatusBarColor() }
    }

    /** 창이 비활성일 때(포커스를 잃었을 때) frame_inactive 를 쓴다. 테마가 정하지 않았으면 활성일 때와 같다 */
    private var winInactive = false
    private val focusFrameTask = Runnable {
        val inactive = !hasWindowFocus()
        if (inactive == winInactive) return@Runnable
        winInactive = inactive
        if (themeSpec?.hasInactiveFrame == true) { applyStripFrame(); updateStatusBarColor() }
    }

    /**
     * 탭바 색과 툴바(선택된 탭) 색이 비슷해 구분이 안 될 때(예: 둘 다 검정) 크롬처럼 선택된 탭 둘레에 그리는 윤곽선 색.
     * 그림을 쓰는 테마는 그림이 모양을 만들어 주므로 그리지 않는다. 구분이 되면 null
     */
    private fun tabOutlineColor(th: ExtensionManager.ThemeSpec?): Int? {
        th ?: return null
        if (th.toolbarImage != null || th.frameImage != null || th.tabBgImage != null || th.flareTabs || th.samsungTabs) return null
        val tb = ColorUtils.setAlphaComponent(th.toolbar, 255)
        val fr = ColorUtils.setAlphaComponent(themeFrameColor(th), 255)
        if (ColorUtils.calculateContrast(tb or 0xFF000000.toInt(), fr or 0xFF000000.toInt()) >= 1.6) return null
        return ColorUtils.blendARGB(tb, readableOn(tb, th.tabText), 0.35f)
    }

    private fun frameInactiveNow(th: ExtensionManager.ThemeSpec) = winInactive && th.hasInactiveFrame
    private fun themeFrameColor(th: ExtensionManager.ThemeSpec): Int = if (frameInactiveNow(th)) (th.frameInactive ?: th.frame) else th.frame
    /** 크롬처럼 탭바 그림이 있으면 비활성일 때도 그 그림을 쓴다 (theme_frame_inactive 가 있으면 그것). 비활성 색은 그림이 없는 테마에서만 보인다 */
    private fun themeFrameImage(th: ExtensionManager.ThemeSpec): java.io.File? =
        if (frameInactiveNow(th)) (th.frameInactiveImage ?: th.frameImage) else th.frameImage
    private fun themeFrameOverlay(th: ExtensionManager.ThemeSpec): java.io.File? =
        if (frameInactiveNow(th) && th.frameInactiveImage != null) null else th.frameOverlay

    /** 탭바 배경(frame / frame_inactive 색·그림)과 그 위 글자·버튼색, 새 탭(+) 버튼 모양을 지금 상태에 맞춘다 */
    private fun applyStripFrame(restyleChips: Boolean = true) {
        val th = themeSpec ?: return
        val fr = themeFrameColor(th)
        val outline = tabOutlineColor(th)
        val layers = listOfNotNull<android.graphics.drawable.Drawable>(
            android.graphics.drawable.ColorDrawable(fr),
            themeTileDrawable(themeFrameImage(th)) { o -> themeOrigin(tabStripBar, false, o) },
            themeTileDrawable(themeFrameOverlay(th)) { o -> themeOrigin(tabStripBar, false, o) },
            // 탭바와 툴바 사이의 얇은 구분선 (선택된 탭 아래만 탭 면이 덮어 끊긴다)
            outline?.let { android.graphics.drawable.ColorDrawable(it) }
        )
        tabStripBar.background = if (layers.size == 1) layers[0] else android.graphics.drawable.LayerDrawable(layers.toTypedArray()).apply {
            if (outline != null) { val li = numberOfLayers - 1; setLayerHeight(li, dp(1)); setLayerGravity(li, Gravity.BOTTOM) }
        }
        // 탭바 위 글자색은 그림이 있으면 그림 위에서도 보이도록 평균색(frame) 기준으로 고른다
        stripFgUnsel = readableOn(fr, th.tabBgText ?: th.tabText)
        findViewById<ImageView>(R.id.btnStripNewTab)?.imageTintList = android.content.res.ColorStateList.valueOf(stripFgUnsel!!)
        findViewById<View>(R.id.btnStripTabList)?.let { tintTree(it, stripFgUnsel!!, null, false) }
        applyStripNewTabShape()
        if (restyleChips) for (c in stripChips.values) styleStripChip(c)
    }

    /**
     * 새 탭(+) 버튼 모양. 탭 모양을 바꾼 테마(선택 안 된 탭 그림 theme_tab_background 또는 색 background_tab)면
     * 크롬처럼 선택 안 된 탭과 같은 모양·색(비스듬한 탭 모양)으로 그리고, 아니면 기본 동그란 눌림 효과 그대로.
     */
    private fun applyStripNewTabShape() {
        val btn = findViewById<ImageButton>(R.id.btnStripNewTab) ?: return
        val th = themeSpec
        val want = th != null && (th.tabBgImage != null || th.bgTab != null) && !th.pillTabs
        val lp = btn.layoutParams
        if (th?.pillTabs == true) {
            // 크롬 요즘 모양: 탭 옆의 동그란 회색 + 버튼
            val sm = resources.getDimensionPixelSize(R.dimen.ev_btn_sm)
            if (lp.width != sm || lp.height != sm) { lp.width = sm; lp.height = sm; btn.layoutParams = lp; btn.setPadding(dp(6), dp(6), dp(6), dp(6)) }
            val fillC = if (ColorUtils.calculateLuminance(ColorUtils.setAlphaComponent(th.frame, 255)) > 0.5) 0xFFE3E3E3.toInt() else 0x33FFFFFF
            val circle = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(fillC) }
            val mask = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(android.graphics.Color.WHITE) }
            btn.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(stripFgUnsel ?: 0xFF000000.toInt(), 0x33)), circle, mask)
            btn.tag = "pill"
            return
        }
        if (!want) {
            if (btn.background is ThemeTabDrawable || btn.tag == "pill") { btn.setBackgroundResource(R.drawable.bg_strip_add); btn.tag = null }
            val sm = resources.getDimensionPixelSize(R.dimen.ev_btn_sm)
            if (lp.width != sm || lp.height != sm) { lp.width = sm; lp.height = sm; btn.layoutParams = lp; btn.setPadding(dp(6), dp(6), dp(6), dp(6)) }
            return
        }
        // 크롬의 새 탭 버튼처럼 탭바 안에 떠 있는 작고 납작한 버튼 (탭 높이를 다 채우지 않는다). 모양은 탭 칩과 같다
        if (lp.width != dp(38) || lp.height != dp(26)) { lp.width = dp(38); lp.height = dp(26); btn.layoutParams = lp; btn.setPadding(dp(5), dp(4), dp(5), dp(4)) }
        val shape = getDrawable(R.drawable.bg_strip_tab_selected)?.mutate() ?: android.graphics.drawable.ColorDrawable(0)
        val d = ThemeTabDrawable(
            shape, null, themeBitmap(th!!.tabBgImage), dp(8).toFloat(), resources.displayMetrics.density,
            inactOrigin = { o -> themeOrigin(btn, false, o) },
            // 사다리꼴 탭 테마(꽉 찬 탭 그림)만 + 버튼도 기울인다. 그 밖에는 탭 칩처럼 둥근 모양
            slant = 0f,
            inactColor = th.bgTab,
            floating = true
        )
        d.alpha = 0   // 선택된 탭 쪽 면은 그리지 않는다 (선택 안 된 탭 모양만)
        btn.background = d
    }

    /** 북마크바: 주소창 아래 가로 줄. 맨 위 북마크는 칩으로, 폴더는 누르면 안의 북마크가 메뉴로 뜬다. 켜져 있고 북마크가 있을 때만 보인다 */
    private fun refreshBookmarkBar() {
        val bar = findViewById<View>(R.id.bookmarkBar) ?: return
        val list = findViewById<LinearLayout>(R.id.bookmarkBarList) ?: return
        val all = try { prefs.bookmarks() } catch (e: Exception) { emptyList() }
        val folders = try { prefs.folders(Prefs.KIND_BM) } catch (e: Exception) { emptyList() }
        val top = all.filter { it.folderId == 0L }
        if (!prefs.bookmarkBar || all.isEmpty()) {
            bar.visibility = View.GONE
            list.removeAllViews()
            return
        }
        bar.visibility = View.VISIBLE
        list.removeAllViews()
        val bmTh = themeSpec
        // 칩은 바탕색 없이 툴바 위에 바로 그리고, 칩 사이는 얇은 세로 구분선으로 나눈다 (글자색도 툴바 기준)
        val fg = barFg ?: ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurface, 0xFF202124.toInt())
        val ripple = android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(fg, 0x33))
        fun chip(label: String, iconRes: Int, url: String?, bm: Bookmark? = null, onClick: (View) -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                background = android.graphics.drawable.RippleDrawable(
                    ripple,
                    null, android.graphics.drawable.GradientDrawable().apply { setColor(android.graphics.Color.WHITE); cornerRadius = dp(14).toFloat() }   // 바탕이 없으니 눌림 물결은 마스크로 모양을 잡는다
                )
                setPadding(dp(10), 0, dp(12), 0)
                contentDescription = label
                setOnClickListener { onClick(it) }
                if (bm != null) setOnLongClickListener { v -> showBookmarkBarMenu(bm, v); true }
            }
            row.addView(ImageView(this).apply {
                setImageResource(iconRes)
                imageTintList = android.content.res.ColorStateList.valueOf(fg)
                layoutParams = LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginEnd = dp(6) }
                if (url != null) Favicons.apply(this, url)
            })
            row.addView(TextView(this).apply {
                text = label
                textSize = 13f
                maxLines = 1
                maxWidth = dp(150)
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(fg)
            })
            if (list.childCount > 0) {
                list.addView(View(this).apply { setBackgroundColor(ColorUtils.setAlphaComponent(fg, 0x44)) },
                    LinearLayout.LayoutParams(dp(1), dp(16)).apply { gravity = Gravity.CENTER_VERTICAL; marginStart = dp(2); marginEnd = dp(2) })
            }
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)))
        }
        fun title(b: Bookmark) = b.title.ifBlank { shortUrl(b.url) }
        // 폴더 (안에 북마크가 있는 것만)
        for (f in folders) {
            val inside = all.filter { it.folderId == f.id }
            if (inside.isEmpty()) continue
            chip(f.name, R.drawable.ic_folder, null) { anchor ->
                Popup.menuAnchored(
                    this, anchor, f.name,
                    items = inside.map { b ->
                        Popup.Item(R.drawable.ic_bookmark, title(b), shortUrl(b.url), compactSub = true, iconUrl = b.url) { loadFromInput(b.url) }
                    }
                )
            }
        }
        for (b in top) chip(title(b), R.drawable.ic_bookmark, b.url, b) { loadFromInput(b.url) }
    }

    /** 북마크바의 북마크를 꾹 눌렀을 때 메뉴: 새 탭·시크릿 탭에서 열기, 주소 복사·공유, 수정, 삭제 */
    private fun showBookmarkBarMenu(b: Bookmark, anchor: View) {
        window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        val name = b.title.ifBlank { shortUrl(b.url) }
        Popup.menuAnchored(
            this, anchor, name, subtitle = shortUrl(b.url), headerIcon = R.drawable.ic_bookmark,
            items = listOf(
                Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { createTab(b.url, opener = current) },
                Popup.Item(R.drawable.ic_incognito, "시크릿 탭에서 열기") { createTab(b.url, incognito = true) },
                Popup.Item(R.drawable.ic_copy, "링크 주소 복사") { copyToClipboard(b.url) },
                Popup.Item(R.drawable.ic_share, "링크 공유") { shareText(b.url) },
                Popup.Item(R.drawable.ic_edit, "북마크 수정") {
                    ListUi.showBookmarkEditor(this, prefs, b, b.url, b.title) { msg -> toast(msg) }
                },
                Popup.Item(R.drawable.ic_delete, "북마크 삭제", danger = true) {
                    prefs.removeBookmark(b.id)
                    toast("북마크를 삭제했어요")
                }
            )
        )
    }

    /** 테마 색을 탭 화면(전체 화면)과 창 바탕에도 입힌다. 테마가 없으면 원래 머티리얼 색이 그대로 나온다 */
    private fun applyAppChromeColors() {
        fun c(attr: Int, def: Int) = ThemeColors.get(this, attr, def)
        val surface = c(com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val container = c(com.google.android.material.R.attr.colorSurfaceContainer, 0xFFF7F8FA.toInt())
        val onSurface = c(com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val primary = c(com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val onPrimary = c(com.google.android.material.R.attr.colorOnPrimary, 0xFFFFFFFF.toInt())
        val secC = c(com.google.android.material.R.attr.colorSecondaryContainer, 0xFFE8F5EC.toInt())
        val onSecC = c(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFF14532D.toInt())
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(surface))
        if (!::tabSwitcher.isInitialized) return
        applySwitcherStatusExtend()
        val themedBg = switcherThemeBg()
        if (themedBg != null) tabSwitcher.background = themedBg else tabSwitcher.setBackgroundColor(container)
        val hdrFg = switcherThemeFg()
        tabSwitcher.findViewById<TextView>(R.id.tabsTitle)?.setTextColor(hdrFg ?: onSurface)
        // 뒤로·더보기는 직접 그리는 아이콘(MorphIconDrawable)이라 imageTintList 만으로는 색이 안 들어갈 수 있다 → 그림에도 직접 입힌다
        // 탭 화면 바탕(container) 위에서 대비가 모자라면 흰색/검정 계열로 바꿔 아이콘이 묻히지 않게 한다 (테마 켰을 때 더보기가 안 보이던 문제)
        val iconTint = android.content.res.ColorStateList.valueOf(hdrFg ?: ThemeColors.readableOn(container, onSurface))
        for (id in intArrayOf(R.id.btnCloseSheet, R.id.btnSwitcherMore)) {
            val b = tabSwitcher.findViewById<ImageView>(id) ?: continue
            b.imageTintList = iconTint
            b.drawable?.setTintList(iconTint)
            b.visibility = if (id == R.id.btnSwitcherMore && switcherSelecting) View.GONE else View.VISIBLE
            b.alpha = 1f
            b.scaleX = 1f; b.scaleY = 1f; b.translationX = 0f; b.translationY = 0f
            // bringToFront() 는 LinearLayout 안에서 버튼을 맨 끝으로 옮겨 이전 버튼이 더보기 옆으로 밀리므로 쓰지 않는다
        }
        tabSwitcher.findViewById<Button>(R.id.btnSelectTabs)?.setTextColor(hdrFg ?: primary)
        tabSwitcher.findViewById<Button>(R.id.btnNewIncognito)?.apply {
            backgroundTintList = android.content.res.ColorStateList.valueOf(secC); setTextColor(onSecC)
        }
        tabSwitcher.findViewById<Button>(R.id.btnNewTab)?.apply {
            backgroundTintList = android.content.res.ColorStateList.valueOf(primary); setTextColor(onPrimary)
        }
        tabSwitcher.findViewById<TextView>(R.id.selectAllText)?.setTextColor(onSurface)
        if (tabSwitcher.isShown) refreshSwitcher(false)
    }

    private val tabShapeCache = HashMap<String, Boolean>()
    /** 탭 배경 그림이 탭 모양을 직접 담고 있나 (true 면 그 모양 그대로, false 인데 그림이 있으면 옛 크롬식 사다리꼴) */
    private fun tabImageShaped(th: ExtensionManager.ThemeSpec?): Boolean {
        val f = th?.tabBgImage ?: return false
        return tabShapeCache.getOrPut(f.path + ":" + f.lastModified()) { tabImageHasShape(themeBitmap(f)) }
    }

    /** 탭 하나(칩)의 바탕·글자·닫기 버튼 색을 지금 테마에 맞춘다 */
    private fun styleStripChip(c: StripChip) {
        // 테마가 탭 모양(theme_tab_background / theme_toolbar 그림)을 바꿨으면 그 모양으로, 아니면 기본 탭 모양으로
        val th = themeSpec
        val outline = tabOutlineColor(th)
        val want = th != null && (th.toolbarImage != null || th.tabBgImage != null || th.bgTab != null || th.flareTabs || th.samsungTabs || outline != null)
        if (want || c.bg is ThemeTabDrawable) {
            val shape = getDrawable(R.drawable.bg_strip_tab_selected)?.mutate()
            val chipView = c.view
            c.bg = if (want && shape != null) ThemeTabDrawable(
                shape, themeBitmap(th!!.toolbarImage), themeBitmap(th.tabBgImage), dp(if (th.samsungTabs) 10 else if (th.flareTabs) 16 else 12).toFloat(), resources.displayMetrics.density,
                selOrigin = { o -> themeOrigin(chipView, true, o) },
                inactOrigin = { o -> themeOrigin(chipView, false, o) },
                // 탭 그림이 모양을 직접 담고 있으면 그 모양 그대로(imageShape), 꽉 찬 사각 그림이면 옛 크롬 테마처럼 비스듬한 사다리꼴, 그림이 없으면 둥근 탭
                slant = 0f,   // 사다리꼴은 앱이 짐작해서 만들지 않는다 — 탭 그림이 모양을 담고 있을 때만 그 모양대로(imageShape)
                
                inactColor = th.bgTab,
                stroke = outline, strokeW = dp(1).toFloat(),
                imageShape = tabImageShaped(th),
                flare = if (th.flareTabs) dp(10).toFloat() else 0f,
                divider = if (th.chromeTabs || th.samsungTabs) stripFgUnsel else null,
                pill = th.pillTabs,
                roundAll = th.samsungTabs
            ) else shape
            c.view.background = c.bg
        }
        // 비스듬한 사다리꼴 탭이면 아이콘·제목·닫기 버튼이 기울어진 옆면에 붙지 않게 안쪽으로 들인다 (기본 모양은 앞 12dp · 뒤 6dp)
        val slanted = want && th?.tabBgImage != null && tabImageShaped(th)
        val trapezoid = false
        ((c.view as? ViewGroup)?.getChildAt(0) as? ViewGroup)?.let { row ->
            val chrome = th?.flareTabs == true
            // 크롬 모양 탭은 양끝 10dp 가 오목하게 퍼지는 자리라, 몸통 안쪽 여백이 왼쪽 12dp · 오른쪽 12dp 가 되게 한다 (닫기 버튼 그림은 버튼 안쪽에서 8dp 들어가 있다)
            val ps = dp(if (slanted) 22 else if (th?.pillTabs == true) 24 else if (chrome) 22 else 12); val pe = dp(if (slanted) 14 else if (th?.pillTabs == true) 16 else if (chrome) 14 else 6)
            if (row.paddingStart != ps || row.paddingEnd != pe) row.setPaddingRelative(ps, row.paddingTop, pe, row.paddingBottom)
        }
        // 눌림 효과(ripple)도 사다리꼴 탭이면 사다리꼴 모양으로 자른다 (뒤로 옛 탭 모양이 비치지 않게)
        c.view.foreground = if (trapezoid) {
            val mask = ThemeTabDrawable(
                android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE), null, null,
                dp(12).toFloat(), resources.displayMetrics.density, slant = dp(10).toFloat()
            )
            android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(stripFgUnsel ?: 0xFF000000.toInt(), 0x33)), null, mask
            )
        } else if (th?.samsungTabs == true) {
            // 삼성 테마: 탭 모양(알약)대로 둥글게 눌림 효과
            val mask = ThemeTabDrawable(
                android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE), null, null,
                dp(10).toFloat(), resources.displayMetrics.density, roundAll = true
            )
            android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(stripFgUnsel ?: 0xFF000000.toInt(), 0x22)), null, mask
            )
        } else if (th?.flareTabs == true) {
            // 크롬 테마: 탭을 눌러도 물결(눌림) 효과를 내지 않는다
            null
        } else getDrawable(R.drawable.bg_strip_ripple)
        c.bg?.let { d -> if (stripSelBg != null) d.setTint(stripSelBg!!) else d.setTintList(null) }
        c.view.findViewById<ImageButton>(R.id.stripClose)?.imageTintList =
            stripFgUnsel?.let { android.content.res.ColorStateList.valueOf(it) }
        applyChipSelection(c)
    }

    private fun applyExtensions() {
        initExtensionHooks()
        applyExtTheme()
        extensions.syncBackground()
        tabs.forEach { t -> t.liveWebView?.let { extensions.attach(it, t.incognito) } }
        current?.let { if (!it.isHome) reloadTab(it) }
    }

    private fun launchGitPicker() {
        val base = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
        try {
            gitPickLauncher.launch(Intent(base).setPackage("com.sec.android.app.myfiles")) // 삼성 내 파일
            return
        } catch (e: Exception) { /* 삼성 내 파일이 없으면 아래로 */ }
        try {
            gitPickLauncher.launch(Intent.createChooser(base, "올릴 파일 선택"))
        } catch (e: Exception) {
            AppToast.show(this, "파일 선택 화면을 열지 못했어요")
        }
    }

    /** 웹페이지의 <input type="file"> 업로드: 파일 선택 화면을 띄우고 결과를 WebView 에 돌려준다. */
    private var fileChooserCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileChooserCallback
            fileChooserCallback = null
            val uris = if (result.resultCode == RESULT_OK) {
                // 파일 관리자마다 결과를 담는 방식이 달라, 표준 해석이 비면 직접 꺼내 본다
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
                    ?.takeIf { it.isNotEmpty() }
                    ?: result.data?.let { d ->
                        val cd = d.clipData
                        when {
                            cd != null && cd.itemCount > 0 ->
                                Array(cd.itemCount) { i -> cd.getItemAt(i).uri }
                            d.data != null -> arrayOf(d.data!!)
                            else -> null
                        }
                    }
            } else null
            cb?.onReceiveValue(uris)
        }

    /** 북마크 화면에서 고른 주소를 받아 현재 탭(또는 새 탭)에서 연다. */
    private val bookmarksLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            val url = data?.getStringExtra(BookmarksActivity.EXTRA_URL)
            if (data == null || url == null) {
                // 주소를 고르지 않고 뒤로 나왔다 → 이 화면을 열었던 메뉴로 돌아간다
                reopenMenuAfterList()
                return@registerForActivityResult
            }
            if (data.getBooleanExtra(BookmarksActivity.EXTRA_NEW_TAB, false)) {
                createTab(url, opener = current)
            } else {
                loadFromInput(url)
            }
        }

    // ───────────────────────── 생명주기 ─────────────────────────

    // ───────────────────────── 크래시 기록 ─────────────────────────
    // 앱이 꺼지면 원인(스택 트레이스)을 파일에 남기고, 다시 켰을 때 화면에 보여 준다.

    private val crashFile get() = java.io.File(filesDir, "last_crash.txt")

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        val file = crashFile
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = java.io.StringWriter()
                throwable.printStackTrace(java.io.PrintWriter(sw))
                file.writeText(
                    "시각: ${java.util.Date()}\n스레드: ${thread.name}\n" +
                        "기기: ${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n" +
                        sw.toString().take(6000)
                )
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    private fun showLastCrashIfAny() {
        val f = crashFile
        if (!f.exists()) return
        val text = try { f.readText() } catch (e: Exception) { return }
        f.delete()
        if (text.isBlank()) return
        ThemedDialogBuilder(this)
            .setTitle("앱이 꺼진 원인 기록")
            .setMessage(text.take(1500))
            .setPositiveButton("복사") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", text))
                toast("복사했어요. 개발자에게 붙여넣어 보내 주세요")
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    /** 이 창을 만들 때의 시스템 다크 모드 값. 바뀔 때만 창을 다시 만들기 위해 기억한다 (아래 onConfigurationChanged) */
    private var uiNightMask = 0

    /** 이 기기 화면이 HDR 을 낼 수 있는가 (낼 수 없으면 HDR 인 척 하지 않는다) */
    @Suppress("DEPRECATION")
    private fun displayIsHdr(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        return runCatching {
            val d = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display else windowManager.defaultDisplay
            if (d == null) false
            else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) d.mode.supportedHdrTypes.isNotEmpty()
            else d.hdrCapabilities?.supportedHdrTypes?.isNotEmpty() == true
        }.getOrDefault(false)
    }

    /** 매니페스트의 colorMode 는 일부 기기에서 무시되므로, HDR 화면이면 창 색 모드도 코드로 HDR 로 켠다 */
    private fun enableHdrWindow() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !displayIsHdr()) return
        runCatching { window.colorMode = android.content.pm.ActivityInfo.COLOR_MODE_HDR }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        uiNightMask = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        enableHdrWindow()
        // 시스템 미디어 플레이어(알림)를 눌러 들어왔으면, 재생 중인 탭이 있는 창으로 보내고 이 인스턴스는 닫는다
        if (savedInstanceState == null && routeToMediaTab()) return
        registerPipReceiver()
        // 확장 프로그램 백그라운드는 앱이 뜬 뒤 잠깐 있다가 시작한다 (시작 속도에 영향이 없게)
        ui.postDelayed({ if (!isDestroyed) { initExtensionHooks(); extensions.syncBackground() } }, 2000)
        // launchMode 가 standard 라서, 같은 작업(창)에 이미 이 앱이 떠 있는데 밖에서 링크·공유로 또 열리면
        // 창이 겹쳐 생긴다. 그럴 땐 새로 만들지 않고 기존 창에 넘기고 닫는다 (예전 singleTop 과 같은 효과)
        if (savedInstanceState == null && forwardToExistingWindow()) return
        instances.add(this)
        ui.post { notifyOtherWindows() }
        val wantNo = intent?.getIntExtra(EXTRA_WINDOW_NO, 0) ?: 0
        // 닫히는 중인 창은 번호를 쥐고 있지 않은 것으로 본다 (마지막 탭을 새 창으로 옮기며 닫히는 창의 번호를 이어받기 위해)
        val others = instances.filter { it !== this && !it.isFinishing }
        // 창 번호: 저장된 창을 다시 열 때는 그 번호, 첫 창은 1, 새 창은 쓰고 있지 않은 가장 작은 번호
        // (탭이 남아 있는 닫힌 창의 번호는 건너뛴다). 번호가 계속 커지지 않고, 겹치지 않는다.
        var openedSavedWindow = false
        // 다크 모드 전환·글꼴 크기 변경 등으로 시스템이 이 창을 다시 만들 때는, 원래 쓰던 번호를 그대로 이어받는다
        // (안 그러면 2번 창이 1번 창 내용으로 바뀌거나 여러 창의 번호가 서로 뒤바뀐다)
        val savedNo = savedInstanceState?.getInt(STATE_WINDOW_NO, 0) ?: 0
        windowNo = when {
            savedNo > 0 && others.none { it.windowNo == savedNo } -> savedNo
            wantNo > 0 && others.none { it.windowNo == wantNo } -> wantNo
            others.isEmpty() -> {
                // 앱을 새로 켤 때: 1번 창에 탭이 있으면 1번, 없으면 탭이 남아 있는 가장 작은 번호의 창을 먼저 연다
                // (비어 있는 1번 창 대신 이미 탭이 있는 창이 열리게)
                val p = Prefs(applicationContext)
                if (savedInstanceState != null || p.savedTabCount(1) > 0) 1
                else p.savedWindowNos().sorted().firstOrNull { it != 1 && p.savedTabCount(it) > 0 }
                    ?.also { openedSavedWindow = true } ?: 1
            }
            else -> {
                val taken = Prefs(applicationContext).savedWindowNos()
                var n = 1
                while (n in taken || others.any { it.windowNo == n }) n++
                n
            }
        }
        // 1번 창은 늘 저장분을 되살리고, 다른 창은 앱을 켤 때 저장된 창을 다시 열 때만 되살린다
        restoreSlot = windowNo == 1 || openedSavedWindow || savedInstanceState != null ||
            intent?.getBooleanExtra(EXTRA_RESTORE, false) == true
        isPrimary = primary == null
        if (isPrimary) primary = this
        installCrashLogger()
        window.decorView.post { showLastCrashIfAny() }
        setContentView(R.layout.activity_main)
        installCaptionIntegration()

        urlBar = findViewById(R.id.urlBar)
        progressBar = findViewById(R.id.progressBar)
        webContainer = findViewById(R.id.webContainer)
        webContainer.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol) onWebAreaResized()
            if ((r - l != orr - ol || b - t != ob - ot) && mirrorActive) scheduleMirrorNudge()
        }
        // WebView 위에 겹쳐지는 우측 드래그 스크롤바. 페이지 자체의 세로 스크롤과 직접 동기화한다.
        pageScrollBar = WebPageScrollBar(this)
        (webContainer.parent as? FrameLayout)?.addView(
            pageScrollBar,
            FrameLayout.LayoutParams(dp(32), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
        )
        // 손가락 움직임을 메뉴바가 먼저 받아 쓰고, 남는 만큼만 페이지가 스크롤된다 (크롬 방식)
        webContainer.onNestedStart = { scrollBars.onTouchStart() }
        webContainer.onNestedPreScrollDy = { dy -> scrollBars.onPreScroll(dy) }
        webContainer.onNestedStop = { scrollBars.onTouchEnd() }
        // 페이지가 맨 위일 때(그리고 홈 화면이 아닐 때)만 아래로 당겨 새로고침
        webContainer.canChildScrollUp = {
            val c = current
            c == null || c.isHome || c.webView.scrollY > 0
        }
        // 핀치로 확대해 둔 페이지에서는 당겨서 새로고침을 하지 않는다 (확대 후 끌어내리는 동작은 화면 이동이다)
        webContainer.isPullBlocked = {
            val c = current
            c == null || c.isHome || (c.webView as? NestedWebView)?.isZoomedIn == true
        }
        MediaBridge.onStop = { instances.toList().forEach { a -> a.ui.post { a.pauseAllMedia() } } }
        webContainer.onRefresh = {
            val c = current
            if (c == null || c.isHome) {
                webContainer.endRefresh()
            } else {
                reloadTab(c)
                // 로딩 완료 신호가 안 오더라도 표시기가 남지 않게
                webContainer.postDelayed({ webContainer.endRefresh() }, 8000)
            }
        }
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnHome = findViewById(R.id.btnHome)
        btnTabs = findViewById(R.id.btnTabs)
        tabCount = findViewById(R.id.tabCount)
        btnBottomTabs = findViewById(R.id.btnBottomTabs)
        tabCountBottom = findViewById(R.id.tabCountBottom)
        stripTabCount = findViewById(R.id.stripTabCount)
        btnMenu = findViewById(R.id.btnMenu)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        fullscreenContainer.enabledProvider = { prefs.swipeDownExit && customView != null && !isInPictureInPictureModeCompat() }
        // 웹 영상 전체화면에서도 두 손가락으로 확대 · 축소 (내장 플레이어와 같은 핀치 줌)
        fullscreenContainer.zoomEnabled = { customView != null && !isInPictureInPictureModeCompat() }
        fullscreenContainer.onZoomLabel = { AppToast.show(this, it) }
        fullscreenContainer.onDismiss = {
            // 영상이 내려가며 사라진 뒤, 브라우저 화면이 부드럽게 나타난다
            browserUi.alpha = 0f
            hideCustomView()
            browserUi.animate().cancel()
            browserUi.animate().alpha(1f).setDuration(200).start()
        }
        // 전체화면 동영상을 아래로 끌어내리면 전체화면 해제
        homeTagline = findViewById(R.id.homeTagline)
        homeTaglineDefault = homeTagline.text
        findBar = findViewById(R.id.findBar)
        etFind = findViewById(R.id.etFind)
        findCount = findViewById(R.id.findCount)
        browserUi = findViewById(R.id.browserUi)
        bottomBar = findViewById(R.id.bottomBar)
        btnFloatMenu = findViewById(R.id.btnFloatMenu)
        (btnFloatMenu as? BlurFloatButton)?.source = findViewById(R.id.browserUi)
        // 탭 줄 자체는 그림자를 만들지 않는다.
        tabStripBar.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) { outline.setEmpty() }
        }
        // 다른 창에서 끌고 온 탭을 받는다
        tabStripBar.setOnDragListener { v, e -> onStripReceiveDrag(v, e) }
        // 다른 앱에서 파일을 끌어다 이 창에 놓으면 새 탭으로 연다
        window.decorView.setOnDragListener { _, e -> onExternalDragRoot(e) }
        tabStripScroll = findViewById(R.id.tabStripScroll)
        tabStrip = findViewById(R.id.tabStrip)
        // 삼성 테마: 로딩 바를 선택된 탭 카드 바로 아래에 그린다 (매 프레임 위치를 맞춘다)
        findViewById<View>(android.R.id.content).viewTreeObserver.addOnPreDrawListener {
            try { syncStripLoadBar() } catch (_: Throwable) { }
            true
        }
        // 저장된 크롬 테마를 앱을 켤 때부터 입힌다 (예전에는 확장 프로그램을 설치·토글할 때만 입혀졌다)
        try { applyExtTheme() } catch (e: Exception) { }
        // 창이 다시 만들어진 직후(예: 블러 효과 켜고 끄기)에는 아직 화면이 자리 잡기 전에 한 번만 입혀서 테마가 빠진 채로 뜰 때가 있다
        // → 화면이 그려진 뒤와 조금 뒤에 한 번씩 더 입힌다 (탭 칩도 다시 칠한다)
        fun reapplyTheme() {
            if (isFinishing || isDestroyed) return
            try { applyExtTheme(); applyStripFrame(restyleChips = true) } catch (_: Throwable) { }
        }
        findViewById<View>(android.R.id.content).post { reapplyTheme() }
        ui.postDelayed({ reapplyTheme() }, 400)
        navGroup = findViewById(R.id.navGroup)
        tbBack = findViewById(R.id.tbBack)
        tbForward = findViewById(R.id.tbForward)
        tbHome = findViewById(R.id.tbHome)
        tbMenu = findViewById(R.id.tbMenu)
        tbDesktop = findViewById(R.id.tbDesktop)
        tbAi = findViewById(R.id.tbAi)
        tabletActions = findViewById(R.id.tabletActions)
        homeView = findViewById(R.id.homeView)
        homeContent = findViewById(R.id.homeContent)
        tabSwitcher = findViewById(R.id.tabSwitcher)
        applySwitcherCaptionInset(switcherCaptionTop)
        tabList = findViewById(R.id.tabList)
        tabScroll = findViewById(R.id.tabScroll)
        // 끄는 카드가 첫 줄 아래에서 잘리지 않도록 목록 쪽은 항상 잘라내기를 끈다
        // (스크롤 영역 가장자리는 바깥 레이아웃이 계속 잘라 주므로 스크롤된 카드가 머리글 위로 번지지 않는다)
        tabScroll.clipChildren = false
        tabList.clipChildren = false
        tabsTitle = findViewById(R.id.tabsTitle)
        tabMorph = findViewById(R.id.tabMorph)

        prefs = Prefs(this)
        unwatchBookmarks = prefs.watchBookmarks { ui.post { if (!isFinishing && !isDestroyed) refreshBookmarkBar() } }
        // 되살리는 창이 아닌 새 창이 예전에 같은 번호였던 창의 이름을 물려받지 않게 한다
        if (!restoreSlot && windowNo !in prefs.savedWindowNos()) prefs.setWindowName(windowNo, null)
        // 악성 사이트 검사(Safe Browsing)를 미리 깨워 두어 첫 페이지 이동이 느려지지 않게
        if (prefs.malwareWarning && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            WebView.startSafeBrowsing(applicationContext, null)
        }
        SecurityStats.init(applicationContext)
        SecurityStats.addListener(homeStatsListener)
        adBlocker = AdBlocker(this)
        adBlockEnabled = prefs.adBlock
        strictTrackers = prefs.strictTrackers
        skipCaptchaTracking = prefs.skipCaptchaTracking
        malwareWarning = prefs.malwareWarning
        blockAutoDownload = prefs.blockAutoDownload
        hijackGuard = prefs.blockHijackNav
        autofillEnabled = prefs.autofill
        httpsFirst = prefs.httpsFirst
        SniBypass.apply(applicationContext, prefs.sniBypass)
        darkMode = prefs.webDarkMode
        textZoom = prefs.textZoom
        val translator = PageTranslator(this, prefs) { js, cb -> runJsOnCurrentPage(js, cb) }
        pageTranslator = translator
        assistant = AssistantUi(
            activity = this,
            prefs = prefs,
            fetchPage = { withImages, cb -> fetchPageForAssistant(withImages, cb) },
            runPageJs = { js, cb -> runJsOnCurrentPage(js, cb) },
            translator = translator,
            openUrl = { url -> createTab(url, opener = current) },
            onLayoutChanged = { scheduleWebSurfaceKick() },
            fetchImage = { url, cb -> fetchImageForAssistant(url, cb) }
        )
        // 광고 목록 읽기는 수 초 걸릴 수 있다. 자동완성·기록 저장이 도는 io 스레드를 막지 않게 따로, 낮은 우선순위로 돈다
        Thread {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            adBlocker.load()
        }.apply { isDaemon = true }.start()
        autoUpdateAdBlockList()

        CookieManager.getInstance().setAcceptCookie(true)
        // 지난번에 앱이 갑자기 꺼졌다면 남아 있는 시크릿 데이터를 지운다 (다른 창이 떠 있으면 그 창의 시크릿 탭이 있을 수 있으니 건드리지 않는다)
        if (instances.size == 1) purgeIncognitoIfUnused()

        applyLayoutMode()
        setupUrlBar()
        setupControls()
        setupHome()
        setupBackHandler()
        setupTabSwitcher()

        // 화면 회전·테마 변경으로 다시 만들어질 때는 같은 인텐트를 또 처리하지 않는다
        val startUrl = if (savedInstanceState == null) launchTarget(intent) else null
        // 다른 창에서 탭이 통째로 넘어온 경우: 주소만이 아니라 웹 기록·확대·스크롤까지 이어받는다
        val handoff = if (savedInstanceState == null) {
            intent?.getLongExtra(EXTRA_HANDOFF, 0L)?.takeIf { it != 0L }?.let { handoffs.remove(it) }
        } else null

        val restored = if (restoreSlot && handoff == null) restoreTabs() else false
        // 앱을 새로 켤 때는 1번 창만 되살린다. 저장된 다른 창들을 자동으로 같이 띄우면
        // 화면이 분할로 갈라지므로, 그 창들은 탭 화면의 창 목록에서 눌러 직접 연다.
        if (handoff != null) receiveTab(handoff, select = true)
        else if (startUrl != null) createTab(startUrl)
        else if (!restored) createTab(null, home = true)
        // 런처 아이콘 길게 누르기 바로가기로 켜졌다면 그 동작을 한다 (빈 새 탭은 방금 만들어져 있을 수 있다)
        if (savedInstanceState == null) {
            intent?.let { handleAppShortcut(it, blankReady = handoff == null && startUrl == null && !restored) }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (windowNo > 0) outState.putInt(STATE_WINDOW_NO, windowNo)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // uiMode·키보드·마우스 연결 같은 설정 변경은 매니페스트에서 직접 받도록 해서 창이 다시 만들어지지 않게 했다
        // (다시 만들어지면 재생 중이던 페이지가 새로 불러와진다). 다크 모드가 실제로 바뀐 때만 테마를 다시 입히려고 창을 다시 만든다
        if (isInPictureInPictureModeCompat()) wasInPip = true
        val nightNow = newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK
        if (nightNow != uiNightMask) {
            uiNightMask = nightNow
            recreate()
            return
        }
        // 창을 끌어 크기·비율을 바꿀 때마다 불린다: 모드(폰/태블릿)가 바뀔 때만 전체를 다시 짜고, 아니면 가볍게 맞춘다
        beginResizeBurst()
        if (wideForWindow() != expanded) {
            // 폰↔태블릿 전환: 열려 있던 메뉴·설정·팝업·AI 창은 옛 모드로 만든 것이라 그대로 두면 어색하다.
            // 먼저 닫고, 새 모드로 바뀐 뒤 같은 창을 새 모양으로 다시 연다.
            val reopen = closeWindowsForModeChange()
            applyLayoutMode()
            // 폰 시트(방문 기록 등)가 뒤 화면에 걸어 둔 블러가 태블릿 UI 까지 남지 않게 푼다.
            // 폰 시트 액티비티가 늦게 정리되는 경우를 위해 한 번 더 푼다.
            if (Blur.tablet(this)) {
                Blur.clearAppBlur(this)
                ui.postDelayed({ if (!isFinishing && !isDestroyed && Blur.tablet(this)) Blur.clearAppBlur(this) }, 600)
            }
            if (reopen != null) reopenWhenSettled(reopen)
            // 폰 시트(방문 기록 등)를 열어 둔 채 태블릿으로 바뀌면, 시트가 화면을 가린다고 보고 멈춰 둔 웹뷰가
            // 태블릿 팝업 뒤에서 그대로 굳어(옛 크기로 남아) 보인다. 팝업은 뒤가 보이니 다시 깨운다.
            if (expanded && !listPopupOpen &&
                lifecycle.currentState == androidx.lifecycle.Lifecycle.State.STARTED
            ) {
                listPopupOpen = true
                tabs.forEach { it.liveWebView?.onResume(); it.paused = false }
                current?.webView?.onResume()
            }
        } else {
            onWindowResized()
            // 분할 화면 등으로 창 크기만 바뀌면 떠 있는 팝업은 옛 폭으로 남는다 → 레이아웃이 끝난 뒤 새 폭으로 맞춘다
            window.decorView.post { Popup.relayoutAll() }
            window.decorView.postDelayed({ Popup.relayoutAll() }, 150)
        }
        scheduleWebRelayout()
        scheduleWebSurfaceKick()
        // 미러링 중이면 영상도 새 창 크기에 가득 차게 (웹뷰 크기 보정이 끝난 뒤에 돈다)
        scheduleMirrorNudge()
        window.decorView.post {
            // 창 크기가 바뀐 뒤 시스템 바 여백이 옛 값으로 남지 않게 다시 받는다
            (findViewById<View>(R.id.browserUi)?.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
            reapplyStatusBarHidden()
        }
    }

    /**
     * 목록 팝업(방문 기록 등)을 상단바 메뉴 버튼 아래에 붙이려고 버튼 자리를 알려 준다.
     * [창 안 오른쪽, 창 안 아래, 화면 오른쪽, 화면 아래]. 태블릿이 아니거나 버튼이 아직 안 보이면 null.
     */
    fun listAnchorInfo(): IntArray? {
        if (!expanded || !::tbMenu.isInitialized) return null
        val v = tbMenu
        if (!v.isShown || v.width <= 0) return null
        val w = IntArray(2)
        val sc = IntArray(2)
        v.getLocationInWindow(w)
        v.getLocationOnScreen(sc)
        return intArrayOf(w[0] + v.width, w[1] + v.height, sc[0] + v.width, sc[1] + v.height)
    }

    /**
     * 폰↔태블릿 전환 직후에는 상단바 버튼 위치와 창 크기가 아직 바뀌는 중이다.
     * 그때 팝업을 열면 버튼 자리가 정해지기 전(왼쪽)에 떴다가 버튼을 따라 오른쪽으로 순간이동한다.
     * 그래서 버튼·창의 위치와 크기가 몇 프레임 동안 변하지 않을 때까지 기다렸다가 연다. (최대 1.2초)
     */
    private fun reopenWhenSettled(action: () -> Unit) {
        val start = android.os.SystemClock.uptimeMillis()
        var last: List<Int>? = null
        var stable = 0
        val tick = object : Runnable {
            override fun run() {
                if (isFinishing || isDestroyed) return
                val now = android.os.SystemClock.uptimeMillis()
                val sig = ArrayList<Int>()
                val loc = IntArray(2)
                for (v in listOf<View>(tbMenu, tbAi, toolbarView)) {
                    v.getLocationInWindow(loc)
                    sig.add(loc[0]); sig.add(loc[1]); sig.add(v.width); sig.add(v.height)
                }
                val d = window.decorView
                sig.add(d.width); sig.add(d.height)
                val ready = (!expanded || tbMenu.width > 0) && !toolbarView.isLayoutRequested
                if (ready && sig == last) stable++ else stable = 0
                last = sig
                if ((ready && stable >= 3 && now - start >= 150L) || now - start >= 1200L) action()
                else ui.postDelayed(this, 16)
            }
        }
        ui.postDelayed(tick, 16)
    }

    /** 지금 떠 있는 메뉴/설정 창 (폰↔태블릿 전환 때 같은 창을 새 모양으로 다시 열려고 기억한다) */
    private class OpenMenu(val showing: () -> Boolean, val close: () -> Unit, val settings: Boolean, val fromMenu: Boolean)
    private var openMenu: OpenMenu? = null

    /**
     * 모드가 바뀔 때 떠 있는 창들을 닫고, 새 모드에서 다시 여는 동작을 돌려준다 (열려 있던 게 없으면 null).
     * 메뉴·설정·AI 어시스턴트는 다시 열고, 그 밖의 팝업·카드 팝업은 닫기만 한다.
     */
    private fun closeWindowsForModeChange(): (() -> Unit)? {
        val m = openMenu?.takeIf { it.showing() }
        val ai = assistant?.isOpen() == true
        if (m != null) m.close() // 먼저 우리가 닫는다 (뒤로가기로 닫힌 줄 알고 다른 창으로 넘어가지 않게)
        val others = Popup.dismissAll()
        if (ai) assistant?.closeNow()
        if (m == null && !ai && !others) return null
        return {
            if (!isFinishing && !isDestroyed) {
                if (m != null) {
                    val a = if (expanded) tbMenu.takeIf { it.isShown }
                    else (if (btnFloatMenu.isShown) btnFloatMenu else btnMenu)
                    showMenu(a, m.settings, m.fromMenu)
                }
                if (ai) {
                    // 작은 창(PiP)으로 바뀌는 중이면 AI 창은 열지 않고 PiP 에서 돌아올 때 연다
                    if (isInPictureInPictureModeCompat()) aiReopenAfterPip = true
                    else assistant?.show(if (expanded && tbAi.isShown) tbAi else null)
                }
            }
        }
    }

    /**
     * 창 크기를 바꾼 뒤 웹뷰가 새 크기로 다시 그려지지 않고 옛 크기에 머물러 하단이 비는 문제를 막는다.
     * 크기 변화가 멈추면 웹뷰 높이를 1px 줄였다가 되돌려 레이아웃·렌더링 표면을 강제로 새로 잡고,
     * 페이지에도 resize 이벤트를 알린다.
     */
    private val webSurfaceKick = Runnable {
        if (isFinishing || isDestroyed || isInPictureInPictureModeCompat()) return@Runnable
        val wv = current?.liveWebView ?: return@Runnable
        if (wv.parent !== webContainer) return@Runnable
        val lp = wv.layoutParams ?: return@Runnable
        val h = webContainer.height
        if (h <= 2) return@Runnable
        lp.height = h - 1
        wv.layoutParams = lp
        wv.post {
            val lp2 = wv.layoutParams ?: return@post
            lp2.height = ViewGroup.LayoutParams.MATCH_PARENT
            wv.layoutParams = lp2
            wv.requestLayout()
            wv.invalidate()
            barsResync()
            val t = current
            if (t != null && !t.isHome && t.pendingUrl == null) {
                wv.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null)
            }
        }
    }

    /** AI 분할 보기가 열리거나 닫혔을 때: 상·하단 바를 모두 보이게 되돌리고, 스크롤 숨김 가능 여부를 다시 따진다 */
    fun onAssistantSplitChanged() {
        scrollBars.reset()
        ui.post { scrollBars.sync() }
    }

    private fun scheduleWebSurfaceKick() {
        ui.removeCallbacks(webSurfaceKick)
        ui.postDelayed(webSurfaceKick, 250)
    }

    // ── 창 크기·비율이 바뀔 때 스크롤 위치 지키기 ──

    private var resizeBurst = false
    private var resizeTouchMark = 0L

    /** 지금 스크롤 위치를 (전체 스크롤 가능 길이 대비) 비율로. 스크롤할 수 없으면 0 */
    private fun scrollRatioOf(wv: WebView?): Float {
        wv ?: return -1f
        @Suppress("DEPRECATION")
        val max = (wv.contentHeight * wv.scale).toInt() - wv.height
        return if (max > 0) (wv.scrollY.toFloat() / max).coerceIn(0f, 1f) else 0f
    }

    /**
     * 크기가 바뀌는 첫 순간부터 '안정될 때까지' 스크롤 기록을 멈춰 두고(= 바뀌기 직전 비율이 남는다),
     * 크기 변화가 끝난 뒤 그 비율로 되돌린다. 내용이 늦게 다시 배치되는 페이지를 위해 한 번 더 맞춘다.
     */
    private fun beginResizeBurst() {
        if (!resizeBurst) {
            resizeBurst = true
            resizeTouchMark = lastTouchAt
        }
        ui.removeCallbacks(resizeRestoreFirst)
        ui.removeCallbacks(resizeRestoreSecond)
        ui.postDelayed(resizeRestoreFirst, 450)
    }

    private fun restoreScrollRatio() {
        val t = current ?: return
        val wv = t.liveWebView ?: return
        val ratio = t.scrollRatio
        if (ratio < 0f || t.isHome || switcherOpen || wv.parent !== webContainer) return
        // 그 사이 사용자가 직접 만졌으면 그 위치를 존중한다
        if (lastTouchAt != resizeTouchMark) return
        @Suppress("DEPRECATION")
        val max = (wv.contentHeight * wv.scale).toInt() - wv.height
        val target = if (max > 0) (ratio * max).toInt() else 0
        if (kotlin.math.abs(wv.scrollY - target) > dp(2)) wv.scrollTo(wv.scrollX, target)
    }

    // 두 번째 복원이 끝날 때까지 스크롤 기록을 멈춰 둔다 (늦게 재배치되며 튄 위치가 '기준 비율'을 덮어쓰지 않게)
    private val resizeRestoreFirst = Runnable {
        if (isFinishing || isDestroyed) return@Runnable
        restoreScrollRatio()
        ui.removeCallbacks(resizeRestoreSecond)
        ui.postDelayed(resizeRestoreSecond, 550)
    }

    private val resizeRestoreSecond = Runnable {
        if (isFinishing || isDestroyed) return@Runnable
        restoreScrollRatio()
        resizeBurst = false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun tabKey(t: BrowserTab) = System.identityHashCode(t)

    /** 알림에서 온 인텐트면, 그 탭이 있는 (다른) 창을 앞으로 가져와 탭을 연다. 처리했으면 true */
    private fun routeToMediaTab(): Boolean {
        val id = intent?.getIntExtra(EXTRA_OPEN_TAB, 0) ?: 0
        if (id == 0) return false
        val host = instances.firstOrNull { w ->
            w !== this && !w.isFinishing && !w.isDestroyed && w.tabs.any { tabKey(it) == id }
        } ?: return false
        host.openMediaTab(id)
        finish()
        return true
    }

    /** 이 창에서 해당 탭을 열고, 이 창이 속한 작업을 앞으로 가져온다 */
    internal fun openMediaTab(id: Int) {
        val tab = tabs.firstOrNull { tabKey(it) == id } ?: return
        if (switcherOpen && !switcherBusy) closeTabSwitcher(tab)
        else if (tab !== current) selectTab(tab)
        val front = runCatching {
            getSystemService(android.app.ActivityManager::class.java)
                .appTasks.firstOrNull { it.taskInfo.taskId == taskId }?.also { it.moveToFront() } != null
        }.getOrDefault(false)
        if (!front) {
            startActivity(Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }

    /**
     * 런처에서 앱 아이콘을 길게 눌러 고른 바로가기(res/xml/shortcuts.xml)를 처리한다. 처리했으면 true.
     * [blankReady] 가 true 면 방금 빈 새 탭이 만들어져 있으므로 "새 탭"·"웹 검색"에서 또 만들지 않는다.
     */
    private fun handleAppShortcut(i: Intent, blankReady: Boolean = false): Boolean {
        when (i.action) {
            ACTION_SHORTCUT_NEW_TAB -> if (!blankReady) openNewTabAndFocus()
            ACTION_SHORTCUT_NEW_INCOGNITO -> openNewTabAndFocus(incognito = true)
            ACTION_SHORTCUT_WEB_SEARCH -> {
                if (!blankReady) openNewTabAndFocus()
                // 새 탭이 자리 잡은 뒤 주소창에 커서를 두고 키보드를 올린다
                ui.postDelayed({ if (!isFinishing && !isDestroyed) focusUrlBar() }, 350L)
            }
            ACTION_SHORTCUT_BOOKMARKS -> openBookmarks()
            else -> return false
        }
        return true
    }

    /** 밖에서 들어온 인텐트를 이 창에서 처리한다 (onNewIntent 와, 겹쳐 열린 인스턴스가 넘겨 줄 때 공통) */
    internal fun handleIncomingIntent(intent: Intent) {
        if (handleAppShortcut(intent)) return
        intent.getIntExtra(EXTRA_OPEN_TAB, 0).takeIf { it != 0 }?.let { openMediaTab(it); return }
        // 이미 켜져 있는데 시스템 작업 표시줄에서 앱 아이콘을 끌어다 놓아 런처 실행이 들어온 경우:
        // 시스템이 '새 인스턴스·옆에 붙이기' 로 요청했는데 이 창으로 전달됐다면, 새 창을 옆에 띄운다
        if (isTaskbarNewWindowLaunch(intent)) {
            openNewWindow()
            return
        }
        launchTarget(intent)?.let { createTab(it) }
    }

    /**
     * 같은 작업에 이미 떠 있는 창이 있으면 이번 인텐트를 그 창에 넘기고 이 인스턴스는 닫는다.
     * 새 창 요청(MULTIPLE_TASK / NEW_DOCUMENT)이나 추가 창(BrowserWindowActivity)은 그대로 새 창으로 둔다.
     */
    private fun forwardToExistingWindow(): Boolean {
        val i = intent ?: return false
        if (this is BrowserWindowActivity) return false
        if (i.flags and (Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_NEW_DOCUMENT) != 0) return false
        val host = instances.firstOrNull {
            it !== this && !it.isFinishing && !it.isDestroyed && it.taskId == taskId
        } ?: return false
        host.handleIncomingIntent(i)
        finish()
        return true
    }

    /**
     * 런처(작업 표시줄) 아이콘 실행인데 시스템이 새 작업 / 옆에 붙이기를 요청한 경우인지.
     * 평범한 아이콘 탭(플래그 없음)은 해당하지 않아서, 그냥 앱을 앞으로 가져오는 기존 동작이 그대로다.
     */
    private fun isTaskbarNewWindowLaunch(i: Intent): Boolean {
        if (i.action != Intent.ACTION_MAIN || !i.hasCategory(Intent.CATEGORY_LAUNCHER) || i.data != null) return false
        val asked = Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
        return i.flags and asked != 0
    }

    /**
     * 밖에서 들어온 인텐트가 열어 달라는 주소를 돌려준다.
     * - 링크(VIEW) → 그 주소
     * - 다른 앱의 공유(SEND) / 글자 선택 메뉴(PROCESS_TEXT) → 글에 주소가 있으면 그 주소, 없으면 검색 주소
     */
    private fun launchTarget(intent: Intent?): String? {
        intent ?: return null
        intent.data?.let { d ->
            // 다른 앱이 보낸 주소는 웹 주소와 'HTML 파일 열기'만 받는다 (javascript: 등은 무시)
            val sc = d.scheme?.lowercase()
            if (sc == "http" || sc == "https") return d.toString()
            if (intent.action == Intent.ACTION_VIEW && sc == "content" && isHtmlFile(d, intent.type)) {
                queryFileName(d)?.let { localFileNames[d.toString()] = it }
                return d.toString()
            }
            return null
        }
        val text = when (intent.action) {
            Intent.ACTION_SEND ->
                if (intent.type?.startsWith("text/") == true) intent.getStringExtra(Intent.EXTRA_TEXT) else null
            Intent.ACTION_PROCESS_TEXT ->
                intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }?.trim()
        if (text.isNullOrEmpty()) return null
        // "제목\n https://..." 처럼 공유된 글에서는 주소만 골라 연다
        Regex("https?://[^\\s<>\"']+").find(text)?.let { return it.value.trimEnd('.', ',', ')', ']') }
        // 그 밖의 글은 한 줄로 정리해서 검색 (너무 길면 자른다). 단축어("yt 노래" 등)는 적용하지 않는다.
        val query = text.replace(Regex("\\s+"), " ").take(300)
        return prefs.currentEngine().url(query)
    }

    /** 열어 달라고 온 파일이 HTML 문서인지: 형식이 HTML 이거나, 형식을 모르면 파일 이름이 .html/.htm 으로 끝나는 경우 */
    private fun isHtmlFile(d: Uri, mime: String?): Boolean {
        val t = (mime ?: try { contentResolver.getType(d) } catch (e: Throwable) { null })?.lowercase()
        if (t == "text/html" || t == "application/xhtml+xml") return true
        if (t != null && t != "*/*" && t != "application/octet-stream") return false
        val name = (queryFileName(d) ?: d.lastPathSegment ?: "").lowercase()
        return name.endsWith(".html") || name.endsWith(".htm") || name.endsWith(".xhtml")
    }

    /** content:// 파일의 이름 (주소창에 보여 주기 위해) */
    private fun queryFileName(d: Uri): String? = try {
        contentResolver.query(d, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Throwable) {
        null
    }

    /** 이 창이 지금 화면에 보이는 중인지 (onStart ~ onStop). 런처 진입점이 "이미 보고 있는 앱을 또 눌렀는지" 가리는 데 쓴다 */
    @Volatile
    internal var visibleNow = false

    override fun onStart() {
        super.onStart()
        visibleNow = true
        // PiP 의 헤드셋 버튼으로 잠시 켜 둔 백그라운드 재생은 앱 화면으로 돌아오면 설정값으로 되돌린다
        bgForced = false
    }

    /**
     * PiP 작은 창의 헤드셋 버튼으로 '이번만' 백그라운드 재생을 켠 상태.
     * 설정의 '백그라운드 재생' 이 꺼져 있어도 영상을 닫고 소리만 계속 듣게 하려는 임시 값이라 설정은 바꾸지 않는다.
     */
    @Volatile
    private var bgForced = false

    /** 백그라운드 재생이 켜져 있는지 (설정 또는 PiP 헤드셋 버튼으로 켠 임시 상태) */
    private fun bgAudioOn(): Boolean = prefs.backgroundAudio || bgForced

    override fun onStop() {
        super.onStop()
        PipDiag.log(this, "onStop pip=${isInPictureInPictureModeCompat()} finishing=$isFinishing")
        visibleNow = false
        if (!isChangingConfigurations) Updater.installReadyInBackground(this)   // 자동 업데이트: 받아 둔 새 버전이 있으면 화면을 떠날 때 설치
        // 플레이어가 화면을 완전히 덮었으니 확대 전환용 오버레이는 치운다
        PlayerZoom.dismiss()
        saveTabs()
        // 목록 팝업이 위에 떠 있는 동안 멈추지 않았던 탭은, 앱이 정말 화면에서 사라질 때(홈 등) 여기서 멈춘다
        if (listPopupOpen) {
            listPopupOpen = false
            pauseTabs()
        }
    }

    /** 태블릿에서 북마크·방문 기록·다운로드 팝업이 떠 있는 동안 true. 뒤 화면은 그대로 보이므로 웹페이지를 멈추지 않는다 */
    private var listPopupOpen = false

    private fun pauseTabs() {
        if (!isInPictureInPictureMode) {
            // 백그라운드 재생이 켜져 있으면 소리가 나는 탭은 멈추지 않는다
            tabs.forEach {
                if (!(bgAudioOn() && it.mediaFrames.isNotEmpty())) it.liveWebView?.onPause()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        PipDiag.log(this, "onPause pip=${isInPictureInPictureModeCompat()} finishing=$isFinishing")
        autoScrollerInst?.stop(null)
        saveTabs()
        adBlocker.flush()
        SecurityStats.flush()
        // 태블릿 목록 팝업은 반투명 창이라 뒤 화면이 계속 보인다. 이때 웹뷰를 멈추면 사이트의 로딩·애니메이션이 굳는다.
        if (!listPopupOpen) pauseTabs()
        CookieManager.getInstance().flush()
    }

    override fun onResume() {
        super.onResume()
        listPopupOpen = false
        assistant?.restoreAfterPlayer()
        refreshBookmarkBar()   // 북마크 화면에서 바뀐 것을 북마크바에 바로 반영
        reapplyStatusBarHidden()
        // 앱을 나갔다 올 때 멈춘 모든 탭을 다시 깨운다 (안 보이는 탭도 계속 돌아가야 하므로)
        tabs.forEach { it.liveWebView?.onResume(); it.paused = false }
        current?.webView?.onResume()
        if (playerOpened) {
            playerOpened = false
            // 돌아온 직후와 화면이 자리를 잡은 뒤, 두 번 다시 그리게 한다
            ui.postDelayed({ repaintPageVideos() }, 120L)
            ui.postDelayed({ repaintPageVideos() }, 600L)
        }
        autoUpdateAdBlockList()
        Updater.autoCheck(this)
        // 다른 창에 다녀왔을 때 탭 화면의 창 목록도 최신으로
        if (switcherOpen) refreshWindowStrip()
        // 북마크 / 방문 기록 / 다운로드 팝업의 ← 로 돌아왔으면 메뉴를 다시 띄운다
        if (ListUi.reopenMenu) {
            ListUi.reopenMenu = false
            val a = menuAnchorRef?.get()
            if (a != null) window.decorView.post { if (!isFinishing && a.isShown) showMenu(a) }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // 영상을 전체화면으로 보는 중에 앱을 나가면 작은 창으로 바뀐다.
        // Android 12+ 는 refreshPipParams() 의 자동 진입이 처리한다. 그 이전 버전은 여기서 직접 들어간다.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && autoPipWanted()) enterPip()
    }

    // ───────────────────────── PiP (작은 창 재생) ─────────────────────────

    private var pipKey = ""

    private fun pipWanted(): Boolean {
        if (customView != null) return true
        // 미러링 중에는 영상이 멈춰 있어도(멈추면 재생 정보 mediaFrames 가 비워진다) 작은 창으로 들어갈 수 있다
        if (mirrorActive) return true
        val t = current ?: return false
        return !t.isHome && t.mediaFrames.values.any { it.video }
    }

    /** 앱을 나갈 때 저절로 작은 창이 되는 경우: 영상을 전체화면으로 보고 있을 때, 또는 미러링(창 가득 보기) 중일 때 */
    private fun autoPipWanted(): Boolean = customView != null || mirrorActive

    private var lastPipRatio: android.util.Rational? = null

    private fun pipRatio(): android.util.Rational {
        val f = current?.mediaFrames?.values?.firstOrNull { it.video && it.w > 0 && it.h > 0 }
        // 일시정지하면 재생 정보가 사라지는데, 그때 비율이 16:9 로 튀어 작은 창 모양이 바뀌지 않게 마지막 비율을 기억한다
        if (f == null) lastPipRatio?.let { return it }
        var w = f?.w ?: 16
        var h = f?.h ?: 9
        val r = w.toFloat() / h
        if (r > 2.39f) { w = 239; h = 100 } else if (r < 0.4184f) { w = 100; h = 239 }
        return android.util.Rational(w, h).also { if (f != null) lastPipRatio = it }
    }

    /** PiP 작은 창에 시스템이 그려 주는 재생/일시정지 버튼 */
    private val pipActionName by lazy { "$packageName.PIP_TOGGLE.${System.identityHashCode(this)}" }
    private var pipReceiver: android.content.BroadcastReceiver? = null

    private fun registerPipReceiver() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val cmd = intent?.getStringExtra("cmd") ?: "toggle"
                if (cmd == "background") playInBackgroundFromPip() else handleMediaControl(cmd, 0L)
            }
        }
        try {
            ContextCompat.registerReceiver(
                this, r, android.content.IntentFilter(pipActionName), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            pipReceiver = r
        } catch (e: Exception) {
            // 무시
        }
    }

    private fun pipPlaying(): Boolean = mediaSel?.first?.mediaFrames?.isNotEmpty() == true

    private fun pipParams(auto: Boolean): PictureInPictureParams {
        val b = PictureInPictureParams.Builder().setAspectRatio(pipRatio())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playing = pipPlaying()
            fun act(code: Int, cmd: String, res: Int, label: String): android.app.RemoteAction {
                val pi = PendingIntent.getBroadcast(
                    this, code, Intent(pipActionName).setPackage(packageName).putExtra("cmd", cmd),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                return android.app.RemoteAction(
                    android.graphics.drawable.Icon.createWithResource(this, res), label, label, pi
                )
            }
            val toggle = act(0, "toggle", if (playing) R.drawable.ic_pip_pause else R.drawable.ic_pip_play, if (playing) "일시정지" else "재생")
            val bgBtn = act(3, "background", R.drawable.ic_pip_headset, "백그라운드로 재생")
            // 4개를 항상 모두 넘긴다. 작은 창에 그릴 수 있는 버튼 수는 시스템·기기가 정하므로(보통 3개 이상) 넘치면 시스템이 뒤쪽부터 자른다
            b.setActions(
                listOf(act(1, "prev", R.drawable.ic_pip_prev, "이전 영상"), toggle, act(2, "next", R.drawable.ic_pip_next, "다음 영상"), bgBtn)
            )
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) b.setAutoEnterEnabled(auto)
        return b.build()
    }

    private fun enterPip(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || isInPictureInPictureMode) return false
        PipDiag.begin(this, "enterPip ${javaClass.simpleName} task=$taskId mirror=$mirrorActive custom=${customView != null} multi=${isInMultiWindowMode} playing=${pipPlaying()}")
        return try {
            val ok = enterPictureInPictureMode(pipParams(autoPipWanted()))
            PipDiag.log(this, "enterPictureInPictureMode -> $ok")
            true
        } catch (e: Exception) {
            PipDiag.log(this, "enterPictureInPictureMode 예외 $e")
            false
        }
    }

    /** 영상 비율을 맞춰 두고, Android 12+ 에서는 홈으로 나갈 때 저절로 작은 창으로 바뀌게 한다. */
    private fun refreshPipParams() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val want = autoPipWanted()
        val r = pipRatio()
        val key = "$want $r ${pipPlaying()}"
        if (key == pipKey) return
        pipKey = key
        try {
            setPictureInPictureParams(pipParams(want))
        } catch (e: Exception) {
            // PiP 불가 시 무시
        }
    }

    /**
     * PiP 작은 창의 헤드셋 버튼: 작은 창을 닫고 소리만 백그라운드에서 계속 재생한다.
     * 멈춰 있던 영상이면 이어서 재생을 시작한다. 설정의 '백그라운드 재생' 이 꺼져 있어도 이번에는 계속 재생한다.
     */
    private fun playInBackgroundFromPip() {
        bgForced = true
        // 누른 순간의 재생 위치를 적어 두고, 이후 20초 안에 처음 부근으로 되돌아가면 그 위치로 되돌린다
        mediaSel?.let { (t, f) ->
            val p = t.mediaProg[f]
            if (p != null && p.pos > 3.0) {
                bgGuardTab = t
                bgGuardPos = p.pos
                bgGuardUntil = android.os.SystemClock.uptimeMillis() + 20_000L
                // 유튜브가 영상을 다시 불러오는(페이지 새로 로드) 경우도 같은 위치에서 이어 가게, 20초 동안만 이어보기를 켜 둔다
                val u = t.liveWebView?.url
                if (u != null && u.startsWith("http") && !t.incognito && !t.resumeApply) {
                    t.resumePos = p.pos
                    t.resumeUrl = u
                    t.resumeApply = true
                    ui.postDelayed({ if (bgGuardTab === t || t in tabs) t.resumeApply = false }, 20_000L)
                }
            }
        }
        if (mediaSel?.first?.let { it in tabs } == true && !pipPlaying()) handleMediaControl("play", 0L)
        // 백그라운드 재생 유지(서비스)를 먼저 켜 두고 앱을 뒤로 보낸다
        onMediaChanged()
        moveTaskToBack(true)
    }

    /** PiP 헤드셋 버튼 직후 재생 위치 보호: 대상 탭 / 지켜야 할 위치(초) / 보호 마감 시각 / 마지막으로 되돌린 시각 */
    private var bgGuardTab: BrowserTab? = null
    private var bgGuardPos = 0.0
    private var bgGuardUntil = 0L
    private var bgGuardAt = 0L

    private fun startPipFromMenu() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            toast("이 기기는 PiP 를 지원하지 않아요")
        } else if (!pipWanted()) {
            toast("재생 중인 동영상이 없어요")
        } else if (!enterPip()) {
            toast("PiP 를 시작할 수 없어요")
        }
    }

    private fun isInPictureInPictureModeCompat(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        PipDiag.log(this, "onPictureInPictureModeChanged pip=$isInPictureInPictureMode state=${lifecycle.currentState} finishing=$isFinishing")
        if (isInPictureInPictureMode) wasInPip = true
        tabs.forEach { applyRendererPriority(it) }
        mirrorOverlay?.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        if (isInPictureInPictureMode) {
            // 작은 창(PiP)에서는 AI 어시스턴트 창이 보이지 않게 닫아 두고, 전체 창으로 돌아오면 다시 연다
            if (assistant?.isOpen() == true) {
                assistant?.closeNow()
                aiReopenAfterPip = true
            }
        } else if (aiReopenAfterPip) {
            aiReopenAfterPip = false
            window.decorView.postDelayed({
                if (!isFinishing && !isDestroyed && !isInPictureInPictureModeCompat() && assistant?.isOpen() != true) {
                    assistant?.show(if (expanded && tbAi.isShown) tbAi else null)
                }
            }, 350L)
        }
        if (customView != null || mirrorActive) {
            // 전체화면 영상·미러링 중 PiP 에 다녀오면 시스템이 상태표시줄을 다시 보이게 하고 그 자리가 앱 면 색(흰색)으로 비칠 수 있다:
            // 뒤 배경을 다시 검정으로 칠하고 시스템 바도 다시 숨긴다
            setFullscreenBackdrop(true)
            if (!isInPictureInPictureMode) setSystemBarsVisible(false)
        }
        if (!isInPictureInPictureMode) {
            // PiP 에서 전체 창으로 돌아오면 시스템이 상태표시줄 여백(인셋)을 다시 알려 주지 않는 때가 있어, 위쪽 여백이 PiP 때 값(0)으로 남고
            // 흰 주소창이 상태표시줄 자리까지 올라와 그 영역이 하얗게 보였다. 창 크기가 자리 잡는 동안 여러 번 인셋·상태표시줄 색을 다시 받는다
            val resync = Runnable {
                if (isFinishing || isDestroyed || isInPictureInPictureModeCompat()) return@Runnable
                (findViewById<View>(R.id.browserUi)?.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
                if (customView == null && !mirrorActive) {
                    reapplyStatusBarHidden()
                    updateStatusBarColor()
                }
            }
            window.decorView.post(resync)
            window.decorView.postDelayed(resync, 150L)
            window.decorView.postDelayed(resync, 500L)
        }
        if (customView != null) return
        if (isInPictureInPictureMode) {
            // 주소창·탭바 등을 숨기고 재생 중인 동영상만 창 가득 보이게
            tabStripBar.visibility = View.GONE
            toolbarView.visibility = View.GONE
            bottomBar.visibility = View.GONE
            progressBar.visibility = View.GONE
            if (mirrorActive) {
                // 미러링 중에는 이미 영상이 창 가득 꾸며져 있다. PIP_ON 은 같은 스타일 태그를 단순한 것으로 덮어써서
                // 윗대 요소의 transform/overflow 풀이 규칙이 사라지고, 그러면 영상이 갇혀 까만 화면만 보였다.
                // 그래서 미러링 꾸미기를 그대로 두고, 작아진 창 크기에 맞춰 다시 배치만 시킨다.
                nudgeMirrorLayout()
            } else {
                current?.webView?.evaluateJavascript(MediaScripts.PIP_ON, null)
            }
        } else {
            toolbarView.visibility = View.VISIBLE
            applyLayoutMode(pip = false)
            if (mirrorActive) {
                nudgeMirrorLayout()
            } else {
                current?.webView?.evaluateJavascript(MediaScripts.PIP_OFF, null)
            }
        }
    }

    /** PiP 로 들어가며 닫아 둔 AI 어시스턴트 창을, 전체 창으로 돌아오면 다시 열려는 표시 */
    private var aiReopenAfterPip = false

    /** 미러링 중 창 크기가 바뀐(PiP 진입·복귀) 뒤 영상이 다시 창 가득 배치되게 한다: 꾸미기를 다시 입히고 resize 를 알린다 */
    private fun nudgeMirrorLayout() {
        val wv = current?.liveWebView ?: return
        // 지금 웹뷰에 실제로 보이는 영역(CSS px = 화면 px ÷ 페이지 배율): 분할·팝업으로 창이 바뀌면 페이지의 100vw/100vh 가
        // 이보다 작게 남아 영상이 창 일부만 채울 수 있어서, 이 크기를 알려 영상 칸을 그만큼 키우게 한다
        fun js(): String {
            @Suppress("DEPRECATION")
            val sc = wv.scale.takeIf { it > 0f } ?: resources.displayMetrics.density
            val w = if (wv.width > 0) Math.round(wv.width / sc) else 0
            val h = if (wv.height > 0) Math.round(wv.height / sc) else 0
            return MediaScripts.mirrorResize(w, h) + "window.dispatchEvent(new Event('resize'));"
        }
        wv.evaluateJavascript(js(), null)
        // 창 크기 변경이 끝난 뒤에도 한 번 더 (전환 애니메이션 중에는 화면 크기가 아직 옛 값일 수 있다)
        wv.postDelayed({ if (mirrorActive) wv.evaluateJavascript(js(), null) }, 400)
    }

    private val mirrorNudgeRun = Runnable {
        if (!isFinishing && !isDestroyed && mirrorActive) nudgeMirrorLayout()
    }

    /** 미러링 중 창 크기가 바뀔 때(분할 화면·팝업 창·창 끌어 크기 조절): 크기가 멎은 뒤 영상이 새 창에 가득 차게 다시 맞춘다 */
    private fun scheduleMirrorNudge() {
        if (!mirrorActive) return
        ui.removeCallbacks(mirrorNudgeRun)
        ui.postDelayed(mirrorNudgeRun, 300L)
    }

    override fun onMultiWindowModeChanged(isInMultiWindowMode: Boolean, newConfig: Configuration) {
        super.onMultiWindowModeChanged(isInMultiWindowMode, newConfig)
        scheduleMirrorNudge()
    }

    // ───────────────────────── 백그라운드 재생 ─────────────────────────

    private val stopMediaRunnable = Runnable {
        if (instances.none { a -> a.tabs.any { it.mediaFrames.isNotEmpty() } } || !bgAudioOn()) {
            mediaKey = ""
            pushKey = ""
            MediaService.stop(this)
        }
    }
    private var mediaKey = ""

    // ── 시스템 미디어 플레이어 (알림창·잠금화면 미디어 컨트롤) ──

    /** 시스템 미디어 플레이어가 조작할 (탭, 프레임) */
    private var mediaSel: Pair<BrowserTab, String>? = null
    private var pushKey = ""
    /** 메뉴·설정창이 뜨는 동안(등장 애니메이션) 이 시각까지는 시스템 미디어 플레이어 갱신을 미룬다 */
    private var menuQuietUntil = 0L
    private var mediaDeferPending = false
    private var pushPlaying = false
    private var pushPos = 0.0
    private var pushAt = 0L
    private val mediaIdleCheck = Runnable { onMediaChanged() }

    /**
     * 시스템 미디어 플레이어가 지금 붙들고 있는 영상이 실제로 재생 중인가.
     * 한 창에서 영상 여러 개가 같이 재생되면 보고(progress)마다 조작 대상이 번갈아 바뀌어
     * 알림의 제목 · 그림 · 재생 상태가 계속 깜박였다 → 붙든 영상이 재생 중인 동안은 다른 영상이 가로채지 못하게 한다.
     */
    private fun mediaSelIsPlaying(now: Long): Boolean {
        val (t, f) = mediaSel ?: return false
        if (t !in tabs || f !in t.mediaFrames) return false
        val p = t.mediaProg[f] ?: return false
        return p.playing && now - p.at < 5000L
    }

    /** 아직 살아 있는 조작 대상. 일시정지한 지 10분이 넘었거나 페이지를 떠났으면 null */
    private fun mediaSessionTarget(): Pair<BrowserTab, String>? {
        val sel = mediaSel ?: return null
        val (t, f) = sel
        if (t !in tabs) return null
        val p = t.mediaProg[f] ?: return null
        if (!p.playing && android.os.SystemClock.uptimeMillis() - p.at > 10L * 60 * 1000) return null
        return sel
    }

    private val mediaArtCache = android.util.LruCache<String, Bitmap>(4)
    private val mediaArtLoading = HashSet<String>()
    /** 받기에 실패한 주소 → 실패한 시각. 영영 포기하지 않고 20초 뒤에 다시 시도한다 */
    private val mediaArtFailed = HashMap<String, Long>()
    private fun mediaArtGivenUp(url: String): Boolean {
        val at = mediaArtFailed[url] ?: return false
        if (android.os.SystemClock.uptimeMillis() - at > 20_000L) { mediaArtFailed.remove(url); return false }
        return true
    }

    /** 썸네일 주소의 그림을 받아 와(가장 긴 쪽 512px 이하로 줄여) 미디어 플레이어를 다시 갱신한다 */
    private fun loadMediaArt(url: String, referer: String = "") {
        if (!mediaArtLoading.add(url)) return
        Thread {
            var bmp: Bitmap? = null
            try {
                val rb = okhttp3.Request.Builder().url(url)
                    .header("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
                if (referer.startsWith("http")) rb.header("Referer", referer)
                val req = rb.build()
                PlayerHttp.client.newCall(req).execute().use { r ->
                    val body = r.body
                    if (r.isSuccessful && body != null && body.contentLength() <= 6_000_000L) {
                        val bytes = body.bytes()
                        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        var sample = 1
                        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2
                        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                        val d = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                        if (d != null) {
                            val m = maxOf(d.width, d.height)
                            bmp = if (m > 512) {
                                val sc = 512f / m
                                Bitmap.createScaledBitmap(d, (d.width * sc).toInt().coerceAtLeast(1), (d.height * sc).toInt().coerceAtLeast(1), true)
                            } else d
                        }
                    }
                }
            } catch (e: Throwable) {
                // 받기 실패: 사이트 아이콘을 그대로 쓴다
            }
            val done = bmp
            ui.post {
                mediaArtLoading.remove(url)
                if (done != null) { mediaArtCache.put(url, done); mediaArtFailed.remove(url) }
                else mediaArtFailed[url] = android.os.SystemClock.uptimeMillis()
                // 받기에 실패했을 때는 화면에 달라질 게 없으니 불필요하게 다시 밀어 넣지 않는다
                updateMediaSession(force = done != null)
            }
        }.start()
    }

    /** 썸네일을 못 받았을 때 시스템 미디어 플레이어에 쓰는 은은한 초록 그라데이션 그림 */
    private val fallbackMediaArt: Bitmap by lazy {
        val sz = 512
        val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.LinearGradient(
                0f, 0f, sz.toFloat(), sz.toFloat(),
                intArrayOf(0xFF5FC48D.toInt(), 0xFF2E9E6E.toInt(), 0xFF1E8560.toInt()),
                floatArrayOf(0f, 0.55f, 1f),
                android.graphics.Shader.TileMode.CLAMP
            )
        }
        android.graphics.Canvas(bmp).drawRect(0f, 0f, sz.toFloat(), sz.toFloat(), paint)
        bmp
    }

    /** 재생 상태·곡 정보가 바뀌었거나 재생 위치가 크게 달라졌을 때만 시스템 미디어 플레이어를 갱신한다 */
    private fun updateMediaSession(force: Boolean = false) {
        if (!prefs.mediaControls) return
        // 메뉴·설정창이 뜨는 중에는 비트맵 처리·알림 갱신·서비스 호출 같은 무거운 일을 미룬다 (애니메이션이 끊기지 않게)
        val quiet = menuQuietUntil - android.os.SystemClock.uptimeMillis()
        if (quiet > 0) {
            if (!mediaDeferPending) {
                mediaDeferPending = true
                ui.postDelayed({ mediaDeferPending = false; updateMediaSession(force = true) }, quiet + 30)
            }
            return
        }
        val sel = mediaSessionTarget() ?: return
        val (t, f) = sel
        val p = t.mediaProg[f] ?: return
        val m = t.mediaMeta[f]
        val host = runCatching { Uri.parse(t.liveWebView?.url).host }.getOrNull().orEmpty()
        val pageTitle = t.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" }
        val title = m?.title?.takeIf { it.isNotBlank() } ?: pageTitle ?: host
        val artist = m?.artist.orEmpty()
        val durKey = if (p.dur > 0) p.dur.toLong() else -1L
        // 시스템 미디어 플레이어 그림: 영상/곡 그림(썸네일)을 받아 오고, 못 받으면 사이트 아이콘
        val artUrl = m?.art.orEmpty()
        val urlBmp = if (artUrl.isNotEmpty()) mediaArtCache.get(artUrl) else null
        if (artUrl.isNotEmpty() && urlBmp == null && !mediaArtGivenUp(artUrl)) loadMediaArt(artUrl, t.liveWebView?.url.orEmpty())
        // 그림 주소를 못 받았거나 주소가 없으면 영상 화면에서 직접 뜬 썸네일을 쓴다
        val artBmp = urlBmp ?: t.mediaThumb[f]
        val key = "${System.identityHashCode(t)}|$f|$title|$artist|${p.playing}|$durKey|$artUrl|${System.identityHashCode(artBmp)}"
        val now = android.os.SystemClock.uptimeMillis()
        val predicted = if (pushPlaying) pushPos + (now - pushAt) / 1000.0 else pushPos
        val drift = kotlin.math.abs(p.pos - predicted) > 2.0
        if (key == pushKey && !drift && !force) return
        pushKey = key
        pushPlaying = p.playing
        pushPos = p.pos
        pushAt = now
        MediaBridge.art = artBmp ?: fallbackMediaArt
        MediaBridge.onControl = { a, v -> ui.post { handleMediaControl(a, v) } }
        MediaBridge.openTabId = tabKey(t)
        val sent = MediaService.start(
            this, title, host, controls = true, artist = artist, playing = p.playing,
            posMs = (p.pos * 1000).toLong(), durMs = if (p.dur > 0) (p.dur * 1000).toLong() else -1L
        )
        // 서비스에 전달하지 못했으면(백그라운드 제한 등) 같은 내용이라고 건너뛰지 않고 다음 보고 때 다시 보낸다
        if (!sent) pushKey = ""
        // 일시정지 상태로 오래 두면 10분 뒤에 알림을 거둔다
        ui.removeCallbacks(mediaIdleCheck)
        if (!p.playing) ui.postDelayed(mediaIdleCheck, 10L * 60 * 1000 + 1000)
    }

    /** 시스템 미디어 플레이어에서 온 조작을 페이지의 미디어에 전한다 */
    private fun handleMediaControl(a: String, v: Long) {
        val (t, f) = mediaSel ?: return
        val p = t.mediaProg[f]
        fun send(cmd: String, value: Double = 0.0) {
            t.liveWebView?.evaluateJavascript(
                "window.postMessage({__ev:'cmd',f:${JSONObject.quote(f)},a:'$cmd',v:$value},'*');", null
            )
        }
        when (a) {
            "play" -> if (p?.playing != true) send("toggle")
            "pause" -> if (p?.playing != false) send("toggle")
            "toggle" -> send("toggle")
            "seek" -> send("seek", v / 1000.0)
            "skip" -> send("skip", v / 1000.0)
            "next" -> send("next")
            "prev" -> send("prev")
        }
    }

    /** 페이지가 재생 상태를 알려 올 때 (메인 스레드) */
    private inner class MediaJs(val tab: BrowserTab) {
        /**
         * PiP·알림의 「이전 영상」: 재생 목록 '이전' 버튼이 없는 페이지(유튜브 단일 영상 등)에서는 웹 기록에서 바로 앞 페이지가
         * 다른 영상 페이지일 때 그곳으로 돌아간다. 돌아갔으면 true, 갈 곳이 없으면 false (그러면 현재 영상을 처음부터 재생).
         */
        @JavascriptInterface
        fun prevPage(): Boolean {
            val task = java.util.concurrent.FutureTask<Boolean> {
                val wv = tab.liveWebView ?: return@FutureTask false
                val list = wv.copyBackForwardList()
                val i = list.currentIndex - 1
                if (i < 0) return@FutureTask false
                val cur = list.currentItem?.url ?: ""
                val prev = list.getItemAtIndex(i)?.url ?: ""
                val p = prev.lowercase()
                val videoLike = listOf("/watch", "/shorts/", "/video", "/embed/", "/live/", "v=").any { p.contains(it) }
                if (!videoLike || sameResumePage(prev, cur)) return@FutureTask false
                wv.goBack()
                true
            }
            runOnUiThread(task)
            return try { task.get(500, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: Exception) { false }
        }

        /**
         * 사용자가 화면을 눌렀다고 페이지 스크립트가 알려 온다 ('클릭 가로채기' 판단용, 백그라운드 스레드에서 불린다).
         * href 는 눌린 곳을 감싼 링크의 주소 (링크가 아니면 빈 문자열). 스크립트가 만든 가짜 클릭은 보고하지 않는다.
         */
        @JavascriptInterface
        fun tap(href: String?) {
            tab.tapJsHref = href ?: ""
            tab.tapJsAt = android.os.SystemClock.uptimeMillis()
        }

        /** true 면 페이지에 "숨겨지지 않았다"고 알려 스스로 멈추지 못하게 한다. 지금 안 보이는 탭도 계속 돌게 하려고 항상 true */
        @JavascriptInterface
        fun bg(): Boolean = bgAudioOn() || tab !== current

        /** 이 창이 지금 화면 밖에 있는지 (페이지가 프레임 콜백이 멈춘 걸 대신 돌려 줄지 판단) */
        @JavascriptInterface
        fun away(): Boolean = !visibleNow

        /** 이 탭이 음소거인지 (페이지 스크립트가 소리를 끌지 판단) */
        @JavascriptInterface
        fun muted(): Boolean = tab.muted

        /** 손가락이 닿은 자리가 페이지 안쪽에서 이미 스크롤되어 있다/스크롤 중이다 → 당겨서 새로고침 금지 (백그라운드 스레드에서 불린다) */
        @JavascriptInterface
        fun pullInner(v: Boolean) {
            if (tab === current) webContainer.innerScrolled = v
        }

        /** 페이지가 자체 로딩 바를 그리고 있다고 알려 올 때 (백그라운드 스레드에서 불린다) */
        @JavascriptInterface
        fun ownBar(v: Boolean) {
            if (!v) return
            ui.post {
                tab.ownProgressBar = true
                if (tab === current) {
                    progressBar.animate().cancel()
                    progressBar.visibility = View.GONE
                }
            }
        }

        /**
         * 페이지(다른 도메인의 iframe 포함)에서 재생이 시작된 영상 주소.
         * 주 프레임 스크립트는 다른 도메인의 iframe 안을 볼 수 없어서, iframe 쪽 스크립트가 직접 알려 오게 했다.
         * (백그라운드 스레드에서 불린다)
         */
        @JavascriptInterface
        fun src(url: String?) {
            if (url.isNullOrEmpty() || !(url.startsWith("http://") || url.startsWith("https://"))) return
            synchronized(tab.sniffed) {
                if (url in tab.sniffed) return
                if (tab.sniffed.size >= SNIFF_MAX) tab.sniffed.remove(tab.sniffed.first())
                tab.sniffed.add(url)
            }
        }

        @JavascriptInterface
        fun adblock(): Boolean = adBlockEnabled

        /** 이 주소가 광고인지 (페이지 스크립트의 팝업/링크 확인용) */
        @JavascriptInterface
        fun adurl(url: String?): Boolean = adBlockEnabled && adBlocker.isAdUrl(url)

        /**
         * 페이지 스크립트가 보내려는 요청(fetch/XHR/sendBeacon)이 광고·추적인지.
         * 맞으면 페이지 쪽에서 진짜 차단기처럼 '네트워크 오류'로 실패시키고 차단 건수에 센다.
         */
        @JavascriptInterface
        fun adreq(url: String?, pageHost: String?): Boolean {
            if (!adBlockEnabled || url.isNullOrEmpty()) return false
            val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return false
            val blocked = adBlocker.shouldBlock(host, pageHost, url, NetFilter.inferType(url, null, false))
            if (blocked) {
                adBlocker.record(host, AdBlocker.KIND_REQUEST)
                tab.adBlocked.incrementAndGet()
            }
            return blocked
        }

        /**
         * 페이지의 <video> 가 가리키는 주소가 광고 영상(배너)인지: 광고 서버 목록, 영상 배너 주소 모양, 예외 규칙까지 본다.
         * 영상 배너 감지 스크립트가 쓴다 (차단 건수는 실제로 가렸을 때 [adhid] 로 센다).
         */
        @JavascriptInterface
        fun advid(url: String?, pageHost: String?): Boolean = adBlockEnabled && adBlocker.isAdVideoUrl(url, pageHost)

        /** 영상 배너를 화면에서 가렸을 때: 차단 건수에 센다 */
        @JavascriptInterface
        fun adhid(pageHost: String?) {
            if (!adBlockEnabled) return
            adBlocker.record(pageHost, AdBlocker.KIND_REQUEST)
            tab.adBlocked.incrementAndGet()
        }

        /** 이 사이트에서 사용자가 직접 고른 광고의 선택자 목록 (JSON 배열 글자) */
        @JavascriptInterface
        fun aduser(host: String?): String {
            if (!adBlockEnabled) return "[]"
            val arr = org.json.JSONArray()
            for (s in adBlocker.userSelectors(host)) arr.put(s)
            return arr.toString()
        }

        /** '광고 직접 선택' 에서 '차단' 을 눌렀을 때 */
        @JavascriptInterface
        fun adpick(host: String?, selector: String?, label: String?, src: String?): Boolean {
            // 지금 보고 있는 사이트에 대한 규칙만 받는다 (다른 사이트가 남의 사이트용 규칙을 몰래 저장하지 못하게)
            val h = host?.lowercase()?.trim()?.removePrefix("www.").orEmpty()
            val ph = tab.curHost?.lowercase()?.removePrefix("www.").orEmpty()
            if (h.isEmpty() || ph.isEmpty() || !(h == ph || ph.endsWith(".$h") || h.endsWith(".$ph"))) return false
            return adBlocker.addUserRule(host, selector, label, src)
        }

        /** '광고 직접 선택' 이 끝났을 때 (blocked = 이번에 고른 개수) */
        @JavascriptInterface
        fun adpickEnd(blocked: Int) {
            ui.post {
                if (tab !in tabs) return@post
                if (blocked > 0) toast("광고 ${blocked}건을 직접 차단했어요 · 설정에서 관리할 수 있어요")
                if (tab === current) updateUi()
            }
        }

        /** 오류 화면의 '다시 시도' (오류 화면은 loadDataWithBaseURL 이라 location.replace 로는 다시 불러와지지 않는다) */
        @JavascriptInterface
        fun errRetry() {
            ui.post { if (tab in tabs && tab.errorUrl != null) reloadTab(tab) }
        }

        /** 오류 화면의 '다음 번호': 실패한 주소의 마지막 번호를 1 늘린 주소를 연다 */
        @JavascriptInterface
        fun errNext() {
            ui.post {
                if (tab !in tabs) return@post
                val cur = tab.errorUrl ?: return@post
                val next = nextNumberUrl(cur)?.first ?: return@post
                tab.errorUrl = null
                tab.webView.loadUrl(next)
            }
        }

        /** 오류 화면의 '이전으로' */
        @JavascriptInterface
        fun errBack() {
            ui.post {
                if (tab !in tabs || tab.errorUrl == null) return@post
                if (canGoBackSmart(tab)) {
                    goBackSmart(tab)
                } else {
                    // 돌아갈 페이지가 없으면 시작 화면으로
                    loadHome(tab)
                }
            }
        }

        /** 첫 화면에만 적용하는 광고 영역 숨김 CSS (내려받은 목록 기준) */
        @JavascriptInterface
        fun adcss(host: String?): String = adBlocker.topCss(host)

        /** 재생 위치·길이 보고 (백그라운드 스레드에서 불린다) */
        @JavascriptInterface
        fun progress(fid: String, pos: Double, dur: Double, playing: Boolean) {
            val now = android.os.SystemClock.uptimeMillis()
            ui.post {
                if (tab !in tabs) return@post
                // 삭제한 미디어: 멈춘 채로 오는 보고는 무시하고, 삭제 직후 늦게 온 재생 보고도 무시한다
                val dAt = tab.mediaDismissed[fid]
                if (dAt != null) {
                    if (playing && now - dAt > 2000L) tab.mediaDismissed.remove(fid) else return@post
                }
                tab.mediaProg[fid] = MediaProg(pos, dur, playing, now)
                noteResume(tab, pos, dur)
                saveTabsWhileAway(tab)
                if (tab === bgGuardTab) {
                    if (now > bgGuardUntil || pos >= bgGuardPos - 3.0) {
                        // 보호 시간이 끝났거나 위치가 제대로 유지되면 보호를 끝낸다 (이후에 사용자가 직접 앞으로 가는 건 건드리지 않는다)
                        if (now > bgGuardUntil || pos > bgGuardPos + 2.0) bgGuardTab = null
                    } else if (now - bgGuardAt > 1500L) {
                        bgGuardAt = now
                        mediaSel = tab to fid
                        handleMediaControl("seek", (bgGuardPos * 1000).toLong())
                    }
                }
                val selThis = mediaSel?.let { it.first === tab && it.second == fid } == true
                // 이미 다른 영상이 재생 중이라 붙들려 있으면 그 영상을 그대로 둔다 (번갈아 바뀌며 깜박이는 것 방지)
                if (playing && !selThis && !mediaSelIsPlaying(now)) mediaSel = tab to fid
                if (mediaSel?.let { it.first === tab && it.second == fid } == true) updateMediaSession()
            }
        }

        /** 미러링 중인 영상의 재생 상태 (덧씌운 컨트롤 막대용). 백그라운드 스레드에서 불린다 */
        @JavascriptInterface
        fun mprog(pos: Double, dur: Double, playing: Boolean, rate: Double) {
            ui.post { if (tab === current && mirrorActive) mirrorOverlay?.report(pos, dur, playing, rate) }
        }

        /** 미러링 중인 영상이 끝났을 때의 '다음 영상' 목록 (JSON, 빈 글 = 카드 걷기). 백그라운드 스레드에서 불린다 */
        @JavascriptInterface
        fun mnext(json: String?) {
            val j = json.orEmpty().take(60_000)
            ui.post { if (tab === current && mirrorActive) mirrorOverlay?.setUpNext(j) }
        }

        /** 미러링 중인 영상이 불러오는 중인지 (덧씌운 로딩 고리용). 백그라운드 스레드에서 불린다 */
        @JavascriptInterface
        fun mload(loading: Boolean) {
            ui.post { if (tab === current && mirrorActive) mirrorOverlay?.setLoading(loading) }
        }

        /** 미러링 중인 영상의 자막 트랙 목록 (JSON). 백그라운드 스레드에서 불린다 */
        @JavascriptInterface
        fun msubs(json: String?) {
            val j = json.orEmpty()
            ui.post { if (tab === current && mirrorActive) mirrorOverlay?.setPageTracks(j) }
        }

        /** 미러링 중인 영상의 화질 목록 (JSON: {k, sel, l:[{id, n}]}, 빈 글 = 화질을 고를 수 없음). 백그라운드 스레드에서 불린다 */
        @JavascriptInterface
        fun mquals(json: String?) {
            val j = json.orEmpty()
            ui.post { if (tab === current && mirrorActive) mirrorOverlay?.setQualities(j) }
        }

        /** 미러링 중인 영상에서 고른 자막 트랙의 지금 글 (빈 글 = 자막 없음). 백그라운드 스레드에서 불린다 */
        @JavascriptInterface
        fun mcue(text: String?) {
            val t = text.orEmpty()
            ui.post { if (tab === current && mirrorActive) mirrorOverlay?.onPageCue(t) }
        }

        /** 영상 화면에서 직접 뜬 썸네일 (data:image/jpeg;base64,...). 백그라운드 스레드에서 불린다 */
        @JavascriptInterface
        fun thumb(fid: String, dataUrl: String?) {
            val raw = dataUrl.orEmpty()
            val i = raw.indexOf("base64,")
            if (i < 0 || raw.length > 600_000) return
            val bmp = try {
                val bytes = android.util.Base64.decode(raw.substring(i + 7), android.util.Base64.DEFAULT)
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Throwable) { null } ?: return
            ui.post {
                if (tab !in tabs) return@post
                tab.mediaThumb[fid] = bmp
                if (mediaSel?.second == fid) updateMediaSession(force = true)
            }
        }

        /** 곡·영상 제목/아티스트 보고 (곡이 바뀔 때마다 온다) */
        @JavascriptInterface
        fun meta(fid: String, title: String?, artist: String?, art: String?) {
            val t = title.orEmpty().trim().take(200)
            val a = artist.orEmpty().trim().take(200)
            val im = art.orEmpty().trim().take(2000)
            ui.post {
                if (tab !in tabs) return@post
                if (t.isEmpty() && a.isEmpty() && im.isEmpty()) tab.mediaMeta.remove(fid) else tab.mediaMeta[fid] = MediaMeta(t, a, im)
                if (mediaSel?.second == fid) updateMediaSession()
                refreshMirrorTitle(tab)
            }
        }

        /** 파형용 소리 크기 보고: 막대 값을 쉼표로 이은 글자, 빈 글자 = 값 없음, 'x' = 읽을 수 없는 페이지 */
        @JavascriptInterface
        fun wave(fid: String, csv: String) {
            val now = android.os.SystemClock.uptimeMillis()
            val w = when {
                csv.isEmpty() -> null
                csv == "x" -> MediaWave(null, true, now)
                else -> MediaWave(
                    csv.split(',').map { (it.toIntOrNull() ?: 0) / 99f }.toFloatArray(), false, now
                )
            }
            ui.post {
                if (tab !in tabs) return@post
                if (w == null) tab.mediaWave.remove(fid) else tab.mediaWave[fid] = w
            }
        }

        /** 이 프레임의 페이지가 닫혔다: 진행 상황을 지운다 */
        @JavascriptInterface
        fun gone(fid: String) {
            ui.post {
                tab.mediaProg.remove(fid); tab.mediaWave.remove(fid); tab.mediaMeta.remove(fid); tab.mediaDismissed.remove(fid)
                tab.mediaThumb.remove(fid)
                // 시스템 미디어 플레이어가 조작하던 페이지를 떠났으면 알림을 거둔다
                if (mediaSel?.second == fid) onMediaChanged()
            }
        }

        /**
         * 영상 아래 버튼을 누른 영상이 화면의 어디에 있는지 (openPlayer 직전에 불린다).
         * 앱이 그 자리에서 화면 가득 커지는 전환을 보여 주려고 기억해 둔다. vw 는 지금 보이는 영역의 폭(CSS px)
         */
        @JavascriptInterface
        fun zoomRect(l: Double, t: Double, w: Double, h: Double, vw: Double) {
            if (!recentTouch(4000L)) return
            if (!(vw > 0.0) || !(w > 0.0) || !(h > 0.0)) return
            tab.zoomRaw = doubleArrayOf(l, t, w, h, vw)
            tab.zoomRawAt = android.os.SystemClock.uptimeMillis()
        }

        /** 영상 아래 '내장 플레이어로 열기' 버튼. url 은 그 영상의 주소(http/https, 없으면 빈 문자열), pos 는 초 */
        @JavascriptInterface
        fun openPlayer(url: String?, pos: Double, fromVideoButton: Boolean) {
            // 영상 아래 버튼을 눌렀을 때만 (페이지가 혼자 부르는 것은 무시)
            if (!recentTouch(4000L)) return
            ui.post {
                if (tab === current) openInternalPlayer(
                    url?.takeIf { it.isNotBlank() }, (pos * 1000).toLong(), fromVideoButton
                )
            }
        }

        /** 영상 아래 버튼('내장 플레이어로 열기' / 'PiP로 보기')을 보여 줄지 (설정에서 끌 수 있다) */
        @JavascriptInterface
        fun buttons(): Boolean = prefs.videoButtons

        /** 유튜브 광고 차단(광고 칸 숨김 + 광고 영상 넘기기)을 쓸지 (일반 광고 차단과 별개) */
        @JavascriptInterface
        fun ytAdBlock(): Boolean = prefs.ytAdBlock

        /** 유튜브 광고의 '건너뛰기' 버튼을 자동으로 누를지 */
        @JavascriptInterface
        fun ytAutoSkip(): Boolean = prefs.ytAutoSkip

        /** 유튜브 영상 정보에서 광고 목록을 미리 지울지 (유튜브 광고 차단이 켜져 있을 때만) */
        @JavascriptInterface
        fun ytAdPrune(): Boolean = prefs.ytAdBlock && prefs.ytAdPrune

        /**
         * 유튜브 광고 '건너뛰기' 버튼 자리를 진짜 터치로 누른다. 유튜브는 스크립트가 보낸 클릭(isTrusted=false)을 무시하는 때가 있어서,
         * 페이지가 알려 준 자리(보이는 화면 기준 CSS 좌표 x·y, 보이는 화면 너비 vw)를 웹뷰 픽셀로 바꿔 손가락 터치처럼 보낸다.
         */
        @JavascriptInterface
        fun ytSkipTap(x: Double, y: Double, vw: Double) {
            if (!prefs.ytAdBlock && !prefs.ytAutoSkip) return
            ui.post {
                val wv = tab.liveWebView ?: return@post
                if (tab !in tabs || !wv.isAttachedToWindow || wv.width <= 0 || vw <= 0.0) return@post
                if (!wv.isShown && !mirrorActive) return@post
                val s = wv.width / vw
                val px = (x * s).toFloat()
                val py = (y * s).toFloat()
                if (px < 0f || py < 0f || px > wv.width || py > wv.height) return@post
                val t0 = android.os.SystemClock.uptimeMillis()
                val down = MotionEvent.obtain(t0, t0, MotionEvent.ACTION_DOWN, px, py, 0)
                down.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
                wv.dispatchTouchEvent(down)
                down.recycle()
                ui.postDelayed({
                    val up = MotionEvent.obtain(t0, android.os.SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, px, py, 0)
                    up.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
                    wv.dispatchTouchEvent(up)
                    up.recycle()
                }, 60L)
            }
        }

        /** 영상 아래 'PiP로 보기' 버튼 */
        @JavascriptInterface
        fun pip() {
            if (!recentTouch(4000L)) return
            ui.post { if (tab === current) startPipFromMenu() }
        }

        @JavascriptInterface
        fun state(fid: String, playing: Boolean, video: Boolean, w: Int, h: Int) {
            ui.post {
                if (tab !in tabs) return@post
                if (playing) {
                    val dAt = tab.mediaDismissed[fid]
                    if (dAt != null) {
                        if (android.os.SystemClock.uptimeMillis() - dAt > 2000L) tab.mediaDismissed.remove(fid)
                        else return@post
                    }
                    val wasPlaying = fid in tab.mediaFrames
                    tab.mediaFrames[fid] = MediaFrame(video, w, h)
                    // 새로 재생을 시작한 영상이 미디어 플레이어를 가져간다. 이미 재생 중이던 영상의 상태 보고는 대상을 바꾸지 않는다
                    val selThis = mediaSel?.let { it.first === tab && it.second == fid } == true
                    if (!wasPlaying || (!selThis && !mediaSelIsPlaying(android.os.SystemClock.uptimeMillis()))) mediaSel = tab to fid
                } else {
                    tab.mediaFrames.remove(fid)
                    // 붙들고 있던 영상이 멈췄는데 다른 영상이 아직 재생 중이면 그쪽으로 넘긴다
                    if (mediaSel?.let { it.first === tab && it.second == fid } == true) {
                        tabs.forEach { t ->
                            t.mediaFrames.keys.firstOrNull { !(t === tab && it == fid) }?.let { other ->
                                if (mediaSel?.let { s -> s.first === tab && s.second == fid } == true) mediaSel = t to other
                            }
                        }
                    }
                }
                onMediaChanged()
            }
        }
    }

    // ── 보고 있지 않은 탭이 소리·영상을 계속 내도록, 화면 뒤 1px 칸에 붙여 둔다 ──

    private var parkHost: FrameLayout? = null

    private fun parkHost(): FrameLayout? {
        parkHost?.let { return it }
        val area = webContainer.parent as? FrameLayout ?: return null
        val h = FrameLayout(this).apply {
            clipChildren = true
            alpha = 0.01f
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
        area.addView(h, 0, FrameLayout.LayoutParams(1, 1))
        parkHost = h
        return h
    }

    private fun parkIfPlaying(tab: BrowserTab) {
        val wv = tab.liveWebView ?: return
        if (tab.mediaFrames.isEmpty() || wv.parent != null) return
        val host = parkHost() ?: return
        // 웹뷰 크기는 화면과 똑같이 유지해서 페이지 배치가 바뀌지 않게 한다
        val w = webContainer.width.coerceAtLeast(dp(320))
        val h = webContainer.height.coerceAtLeast(dp(480))
        wv.layoutParams = FrameLayout.LayoutParams(w, h)
        host.addView(wv)
    }

    /** 다시 화면에 올리기 전에 보이지 않는 칸에서 떼고, 크기를 화면에 맞게 되돌린다 */
    private fun unparkWebView(tab: BrowserTab) {
        val wv = tab.liveWebView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    /** 더 이상 소리가 나지 않는 탭은 보이지 않는 칸에서 내려 자원을 아낀다 */
    private val sweepParked = Runnable {
        val host = parkHost ?: return@Runnable
        tabs.forEach { t ->
            val wv = t.liveWebView ?: return@forEach
            if (wv.parent === host && t.mediaFrames.isEmpty()) host.removeView(wv)
        }
    }

    private fun onMediaChanged() {
        // 보고 있지 않은 탭에서 재생이 시작됐다면 그 탭도 붙여 둔다
        tabs.forEach { applyRendererPriority(it) }
        tabs.forEach { if (it !== current) parkIfPlaying(it) }
        ui.removeCallbacks(sweepParked)
        ui.postDelayed(sweepParked, 4000)
        val playing = tabs.filter { it.mediaFrames.isNotEmpty() }
        val sessionTarget = if (prefs.mediaControls) mediaSessionTarget() else null
        if (sessionTarget != null) {
            // 시스템 미디어 플레이어에 보여 주는 동안(일시정지 포함)은 서비스를 유지한다
            ui.removeCallbacks(stopMediaRunnable)
            updateMediaSession()
        } else if (playing.isEmpty() || !bgAudioOn()) {
            // 버퍼링이나 다음 영상으로 넘어가는 짧은 끊김에는 알림을 유지한다
            ui.removeCallbacks(stopMediaRunnable)
            ui.postDelayed(stopMediaRunnable, 2500)
        } else {
            ui.removeCallbacks(stopMediaRunnable)
            val t = playing.firstOrNull { it === current } ?: playing.first()
            val host = runCatching { Uri.parse(t.liveWebView?.url).host }.getOrNull().orEmpty()
            val title = t.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" } ?: host
            val key = "${System.identityHashCode(t)}|$title"
            if (key != mediaKey) {
                mediaKey = key
                // 알림 권한을 따로 요청하지 않는다 (재생 알림을 띄우지 않기 위해)
                MediaBridge.openTabId = tabKey(t)
                MediaService.start(this, title, host)
            }
        }
        refreshPipParams()
    }

    /** 내장 플레이어를 열었다가 돌아오면 페이지의 영상이 비어 보이지 않게 다시 그리게 하려는 표시 */
    private var playerOpened = false

    private fun repaintPageVideos() {
        tabs.forEach { it.liveWebView?.evaluateJavascript(MediaScripts.REPAINT, null) }
    }

    private fun pauseAllMedia() {
        tabs.forEach { it.liveWebView?.evaluateJavascript(MediaScripts.PAUSE_ALL, null) }
    }

    override fun finish() {
        PipDiag.log(this, "finish() 호출: ${PipDiag.caller()}")
        super.finish()
    }

    override fun finishAndRemoveTask() {
        PipDiag.log(this, "finishAndRemoveTask() 호출: ${PipDiag.caller()}")
        super.finishAndRemoveTask()
    }

    override fun onDestroy() {
        unwatchBookmarks?.invoke(); unwatchBookmarks = null
        PipDiag.log(this, "DESTROY ${javaClass.simpleName} finishing=$isFinishing changingConfig=$isChangingConfigurations pip=${isInPictureInPictureModeCompat()}")
        autoScrollerInst?.stop(null)
        PlayerZoom.dismiss()
        SecurityStats.removeListener(homeStatsListener)
        runCatching { extensions.destroyBackground() }
        extDropPerms.forEach { runCatching { it.release() } }
        extDropPerms.clear()
        pipReceiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        pipReceiver = null
        downloadCard.destroy()
        spareWebView?.destroy()
        spareWebView = null
        instances.remove(this)
        notifyOtherWindows()
        // 창을 닫아도 탭은 남는다 (탭 화면의 창 목록에서 다시 열 수 있다). 앱을 켤 때 자동으로 열리지만 않게 한다
        if (isFinishing && ::prefs.isInitialized) prefs.markWindowClosed(windowNo)
        if (primary === this) {
            primary = null
            // 대표 창이 닫히면 남은 창 하나가 탭 저장을 이어받는다 (사용자가 닫은 경우에만)
            if (isFinishing) instances.firstOrNull()?.let { it.isPrimary = true; primary = it }
        }
        ui.removeCallbacks(stopMediaRunnable)
        ui.removeCallbacks(sweepParked)
        if (instances.isEmpty()) {
            MediaBridge.onStop = null
            MediaService.stop(this)
        }
        tabs.forEach {
            val w = it.liveWebView ?: return@forEach
            w.stopLoading()
            (w.parent as? ViewGroup)?.removeView(w)
            w.destroy()
        }
        tabs.clear()
        if (instances.isEmpty()) purgeIncognitoIfUnused(false)
        io.shutdown()
        super.onDestroy()
    }

    // ───────────────────────── 탭 ─────────────────────────

    // ───────────────────────── 탭 저장 / 복원 ─────────────────────────

    /** 열려 있는 탭(주소·그룹·데스크톱 여부·선택한 탭)을 저장한다. 앱을 껐다 켜도 그대로 남는다. */
    private fun saveTabs() {
        try {
            // 시크릿 탭은 저장하지 않는다 (앱을 다시 켜면 사라진다)
            val saved = tabs.filter { !it.incognito }
            if (tabs.isEmpty()) return
            // 1번이 아닌 창에 열린 페이지가 하나도 없으면 저장할 게 없다 (저장분이 있었다면 지운다)
            if (windowNo != 1 && saved.all { it.isHome }) {
                prefs.clearSavedTabsFor(windowNo)
                tabStateDir().deleteRecursively()
                return
            }
            val arr = JSONArray()
            val keep = HashSet<String>()
            // 이어보기 위치는 아래 전체 저장에 같이 들어가므로, 가볍게 따로 적어 둔 이 창의 값은 비운다
            resumeSp.edit().apply { resumeSp.all.keys.filter { it.startsWith("r_${windowNo}_") }.forEach { remove(it) } }.apply()
            for (t in saved) {
                val lw = t.liveWebView
                val live = pageUrlOf(t, lw)?.takeIf { (it.startsWith("http://") || it.startsWith("https://")) && !it.startsWith(LOCAL_BASE) }
                val url = if (t.isHome) null else (live ?: t.pendingUrl?.takeIf { !it.startsWith(LOCAL_BASE) && !it.startsWith("content://") })
                val title = (if (live != null) lw?.title else t.pendingTitle).orEmpty()
                val o = JSONObject()
                    .put("url", url ?: "")
                    .put("title", title)
                    .put("home", url == null)
                    .put("desktop", t.desktop)
                    .put("group", t.groupId)
                    .apply { if (url != null && t.resumePos > 0.0 && sameResumePage(url, t.resumeUrl)) put("rp", t.resumePos).put("ru", t.resumeUrl) }
                // 새 탭(홈) 화면이어도 뒤/앞으로 갈 기록이 있으면 그 기록을 남긴다 (뒤로 가서 홈에 있을 때 '앞으로' 기록이 사라지지 않게)
                val homeHist = url == null && t.isHome && (
                    (lw != null && lw.copyBackForwardList().size > 1) ||
                    (lw == null && t.stateId != 0L && t.pendingState != null)
                )
                if (url != null || homeHist) {
                    if (t.stateId == 0L) t.stateId = nextStateId()
                    o.put("sid", t.stateId)
                    keep.add("${t.stateId}.bin")
                    // 불러온 탭은 지금의 앞/뒤로가기 기록을 파일로 남긴다. 아직 안 불러온 탭은 이미 있는 파일을 그대로 둔다
                    if (lw != null && (live != null || homeHist)) writeTabState(t.stateId, lw)
                }
                arr.put(o)
            }
            pruneTabStates(keep)
            val gs = JSONArray()
            for (g in groups) {
                gs.put(
                    JSONObject().put("id", g.id).put("name", g.name)
                        .put("color", g.color).put("collapsed", g.collapsed)
                )
            }
            val root = JSONObject()
                .put("tabs", arr)
                .put("groups", gs)
                .put("cur", (current?.let { saved.indexOf(it) } ?: 0).coerceAtLeast(0))
                .put("nextGid", nextGroupId)
            prefs.setSavedTabsFor(windowNo, root.toString())
        } catch (e: Exception) {
            // 저장 실패는 무시
        }
    }

    // 탭별 웹 기록(WebView.saveState)을 파일로 저장한다. 앱을 껐다 켜도 앞/뒤로가기 기록이 남는다.
    private fun tabStateDir() = java.io.File(filesDir, "tabstate/w$windowNo")

    private var stateIdSeq = 0L
    private fun nextStateId(): Long = System.currentTimeMillis() * 1000L + (stateIdSeq++ % 1000L)

    private fun writeTabState(id: Long, wv: WebView) {
        try {
            if (wv.copyBackForwardList().size == 0) return
            val b = Bundle()
            if (wv.saveState(b) == null) return
            val p = android.os.Parcel.obtain()
            val bytes = try { p.writeBundle(b); p.marshall() } finally { p.recycle() }
            val dir = tabStateDir()
            // 파일 쓰기는 백그라운드에서 (탭이 많을 때 화면이 멈추지 않게)
            io.execute {
                try {
                    dir.mkdirs()
                    val tmp = java.io.File(dir, "$id.tmp")
                    tmp.writeBytes(bytes)
                    if (!tmp.renameTo(java.io.File(dir, "$id.bin"))) tmp.delete()
                } catch (e: Exception) { }
            }
        } catch (e: Exception) {
            // 저장 실패는 무시 (주소만으로 되살린다)
        }
    }

    private fun readTabState(id: Long): Bundle? {
        val f = java.io.File(tabStateDir(), "$id.bin")
        if (!f.isFile) return null
        return try {
            val bytes = f.readBytes()
            val p = android.os.Parcel.obtain()
            try {
                p.unmarshall(bytes, 0, bytes.size)
                p.setDataPosition(0)
                p.readBundle(javaClass.classLoader)
            } finally { p.recycle() }
        } catch (e: Exception) { null }
    }

    /** 더는 쓰지 않는 탭의 기록 파일을 지운다 */
    private fun pruneTabStates(keep: Set<String>) {
        val dir = tabStateDir()
        if (!dir.isDirectory) return
        try {
            io.execute {
                try {
                    dir.listFiles()?.forEach { f -> if (f.name.endsWith(".bin") && f.name !in keep) f.delete() }
                } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }

    /** 저장된 탭을 되살린다. 선택한 탭만 바로 불러오고 나머지는 선택할 때 불러온다. 복원한 탭이 있으면 true. */
    private fun restoreTabs(): Boolean {
        val raw = prefs.savedTabsFor(windowNo) ?: return false
        return try {
            val root = JSONObject(raw)
            val arr = root.getJSONArray("tabs")
            if (arr.length() == 0) return false
            val gs = root.optJSONArray("groups")
            if (gs != null) {
                for (i in 0 until gs.length()) {
                    val g = gs.getJSONObject(i)
                    groups.add(TabGroup(g.getInt("id"), g.getString("name"), g.getInt("color"), g.optBoolean("collapsed", false)))
                }
            }
            nextGroupId = maxOf(root.optInt("nextGid", 1), (groups.maxOfOrNull { it.id } ?: 0) + 1)
            for (i in 0 until minOf(arr.length(), 40)) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url").takeIf { it.isNotEmpty() }
                val home = o.optBoolean("home", false) || url == null
                val tab = createTab(null, select = false, home = home, lazy = true)
                val gid = o.optInt("group", 0)
                tab.groupId = if (groups.any { it.id == gid }) gid else 0
                if (!home) {
                    tab.pendingUrl = url
                    tab.pendingTitle = o.optString("title").takeIf { it.isNotBlank() }
                    // 앱을 껐다 켜도 탭 아이콘이 남도록, 저장해 둔 사이트 아이콘을 바로 입힌다
                    tab.favicon = Favicons.cached(this, url)
                    val rp = o.optDouble("rp", 0.0)
                    if (rp > 0.0) { tab.resumePos = rp; tab.resumeUrl = o.optString("ru").takeIf { it.isNotEmpty() }; tab.resumeApply = true }
                    // 저장해 둔 웹 기록이 있으면 선택할 때 주소만 여는 대신 기록째 되살린다
                    val sid = o.optLong("sid", 0L)
                    // 탭 전체 저장 뒤에 가볍게 적어 둔 재생 위치가 있고 같은 영상이면 그 값이 더 최근이다
                    if (sid != 0L) {
                        val parts = resumeSp.getString(resumeKey(sid), null)?.split('\n', limit = 2)
                        val lp = parts?.getOrNull(0)?.toDoubleOrNull() ?: 0.0
                        val lu = parts?.getOrNull(1)
                        if (lp > 0.0 && lu != null && sameResumePage(url, lu)) {
                            tab.resumePos = lp; tab.resumeUrl = lu; tab.resumeApply = true
                        }
                    }
                    if (sid != 0L) {
                        tab.stateId = sid
                        tab.pendingState = readTabState(sid)
                    }
                } else {
                    // 홈 화면에 있던 탭: 앞뒤 기록이 저장돼 있으면 처음 만들 때 그 기록째 되살린다
                    val sid = o.optLong("sid", 0L)
                    if (sid != 0L) {
                        tab.stateId = sid
                        tab.pendingState = readTabState(sid)
                    }
                }
            }
            val idx = root.optInt("cur", 0).coerceIn(0, tabs.size - 1)
            selectTab(tabs[idx])
            pruneEmptyGroups()
            true
        } catch (e: Exception) {
            // 일부만 만들어졌더라도 있는 탭으로 시작
            if (tabs.isNotEmpty()) {
                if (current == null) selectTab(tabs[0])
                true
            } else false
        }
    }

    /** 탭 제목: 불러온 페이지 제목 → (복원만 된 탭이면) 저장해 둔 제목/주소 → "새 탭" */
    private fun tabTitle(tab: BrowserTab): String {
        // 홈(새 탭)이거나 빈 페이지면 WebView 가 돌려주는 "about:blank" 제목을 쓰지 않는다
        if (tab.isHome) return if (tab.incognito) "시크릿 탭" else "새 탭"
        val lw = tab.liveWebView
        val blank = lw?.url == "about:blank" || lw?.url == HOME_URL
        return lw?.title?.takeIf { it.isNotBlank() && !blank && it != "about:blank" && it != HOME_URL }
            ?: tab.pendingTitle
            ?: tab.pendingUrl?.let { runCatching { Uri.parse(it).host }.getOrNull() }
            ?: "새 탭"
    }

    private fun homeUrl(): String = prefs.currentEngine().homeUrl

    // ───────────────────────── 로딩 속도 ─────────────────────────

    private val docStartScripts: Boolean by lazy {
        WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
    }

    /** 새 탭을 바로 열 수 있도록 미리 만들어 둔 빈 웹뷰 한 개 (화면이 한가할 때 만든다) */
    private var spareWebView: WebView? = null

    private fun prepareSpareWebView() {
        if (spareWebView != null) return
        Looper.myQueue().addIdleHandler {
            if (spareWebView == null && !isFinishing && !isDestroyed) {
                spareWebView = NestedWebView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            }
            false
        }
    }

    private val dnsWarm: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** 곧 열 가능성이 높은 주소(입력한 주소, 첫 자동완성 등)의 도메인 조회를 미리 해 둔다 */
    private fun prefetchDns(url: String?) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return
        val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return
        if (dnsWarm.size > 300) dnsWarm.clear()
        if (!dnsWarm.add(host)) return
        // 조회가 오래 걸려도 다른 백그라운드 작업(기록 저장, 자동완성)을 막지 않게 별도 스레드에서
        Thread {
            try {
                java.net.InetAddress.getAllByName(host)
            } catch (e: Exception) {
                dnsWarm.remove(host)
            }
        }.apply { isDaemon = true }.start()
    }

    // ───────────────────────── 시크릿 탭 ─────────────────────────

    private val incognitoProfileName = "incognito"
    private var incognitoWarned = false

    private val profilesSupported: Boolean by lazy {
        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
    }

    /** 시크릿 전용 프로필에 붙은 웹뷰. 프로필이 쿠키·캐시·저장소를 따로 들고 있다. 지원하지 않는 기기면 기록만 남기지 않는다. */
    private fun newIncognitoWebView(): WebView {
        val wv = NestedWebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        if (profilesSupported) {
            try {
                androidx.webkit.WebViewCompat.setProfile(wv, incognitoProfileName)
            } catch (e: Exception) {
                warnNoIsolation()
            }
        } else {
            warnNoIsolation()
        }
        return wv
    }

    private fun warnNoIsolation() {
        if (incognitoWarned) return
        incognitoWarned = true
        toast("이 기기의 WebView는 쿠키 분리를 지원하지 않아 방문 기록만 남기지 않습니다")
    }

    /** 이 탭이 쓰는 쿠키 저장소 (시크릿이면 시크릿 프로필 것) */
    private fun cookieManagerFor(tab: BrowserTab?): CookieManager {
        if (tab?.incognito == true && profilesSupported) {
            try {
                return androidx.webkit.ProfileStore.getInstance()
                    .getOrCreateProfile(incognitoProfileName).cookieManager
            } catch (e: Exception) {
                // 아래 기본값
            }
        }
        return CookieManager.getInstance()
    }

    /** 시크릿 탭이 하나도 없으면 시크릿 프로필(쿠키·캐시·저장소)을 통째로 지운다. */
    private fun purgeIncognitoIfUnused(retry: Boolean = true) {
        if (!profilesSupported || tabs.any { it.incognito }) return
        try {
            androidx.webkit.ProfileStore.getInstance().deleteProfile(incognitoProfileName)
        } catch (e: Exception) {
            // 웹뷰가 아직 정리되는 중이면 잠시 뒤 한 번 더 시도한다
            if (retry) ui.postDelayed({ purgeIncognitoIfUnused(false) }, 800)
        }
    }

    /** 시크릿 탭이 보이는 동안에는 스크린샷·최근 앱 미리보기를 막는다 */
    private fun updateSecureFlag() {
        val secure = current?.incognito == true || (switcherOpen && tabs.any { it.incognito })
        if (secure) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }

    private var urlTextDefault: android.content.res.ColorStateList? = null
    private var urlHintDefault: android.content.res.ColorStateList? = null
    private val incognitoBarColor = 0xFF3C4043.toInt()
    private val incognitoTextColor = 0xFFE8EAED.toInt()

    /** 주소창 바탕·글자색: 시크릿이면 어둡게, 아니면 테마(없으면 기본) 색 */
    private var urlBarSamsungShape: Boolean? = null
    private fun applyUrlPillColors(on: Boolean) {
        // 삼성 테마: 주소창 모서리를 탭처럼 덜 둥글게 (기본 15dp → 10dp)
        val sam = themeSpec?.samsungTabs == true
        if (urlBarSamsungShape != sam) {
            urlBarSamsungShape = sam
            if (sam) urlBar.background = GradientDrawable().apply { setColor(android.graphics.Color.WHITE); cornerRadius = dp(10).toFloat() }
            else urlBar.setBackgroundResource(R.drawable.bg_url_bar)
        }
        urlBar.backgroundTintList = if (on) android.content.res.ColorStateList.valueOf(incognitoBarColor) else pillTint
        urlBar.setTextColor(if (on) android.content.res.ColorStateList.valueOf(incognitoTextColor) else pillText ?: urlTextDefault)
        urlBar.setHintTextColor(if (on) android.content.res.ColorStateList.valueOf(0xFF9AA0A6.toInt()) else pillHint ?: urlHintDefault)
    }

    /** 시크릿 탭이면 주소창을 어둡게, 아니면 원래대로 */
    private fun applyIncognitoUi(on: Boolean) {
        if (urlTextDefault == null) {
            urlTextDefault = urlBar.textColors
            urlHintDefault = urlBar.hintTextColors
        }
        applyUrlPillColors(on)
        homeTagline.text = if (on) "시크릿 탭 · 방문 기록과 쿠키가 저장되지 않아요" else homeTaglineDefault
        // 평소에는 문구를 숨기고, 시크릿 탭일 때만 안내 문구를 보여 준다
        homeTagline.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun createTab(
        url: String?,
        select: Boolean = true,
        opener: BrowserTab? = null,
        home: Boolean = false,
        incognito: Boolean = false,
        lazy: Boolean = false
    ): BrowserTab {
        // 시크릿 탭에서 연 링크·팝업도 시크릿으로 이어진다
        val incog = incognito || opener?.incognito == true
        val tab = BrowserTab()
        tab.incognito = incog
        tab.isHome = home
        if ((prefs.desktopSite && !autoMobile) || (opener?.desktop == true && !autoMobile)) tab.desktop = true
        tab.lazyInit = {
            tab.webView = if (incog) newIncognitoWebView()
            else spareWebView?.also { spareWebView = null } ?: NestedWebView(this)
            tab.webView.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            configure(tab)
            if (tab.desktop) applyUserAgent(tab.webView, true)
            // 새 탭은 홈 화면을 웹 기록의 첫 항목으로 가진다 → 첫 페이지에서 뒤로가기를 하면 홈으로 돌아온다
            if (home) {
                // 저장해 둔 웹 기록이 있으면 홈 화면만 새로 열지 않고 기록째 되살린다 (앞으로 가기 기록 유지)
                val st = tab.pendingState
                tab.pendingState = null
                val ok = st != null && runCatching { tab.webView.restoreState(st) != null }.getOrDefault(false)
                if (!ok) tab.webView.loadDataWithBaseURL(HOME_URL, HOME_HTML, "text/html", "utf-8", HOME_URL)
            }
        }
        if (!lazy) tab.webView
        // 링크/팝업으로 열린 탭은 연 탭 바로 옆에 두고, 같은 그룹에 넣는다.
        tab.opener = opener
        val at = if (opener != null) tabs.indexOf(opener) else -1
        if (opener != null && at >= 0) {
            if (!incog) tab.groupId = opener.groupId
            tabs.add(at + 1, tab)
        } else {
            tabs.add(tab)
        }
        // 첫 탭이 아니라 "새로 추가한" 탭이 보이게 될 때만 전용 등장 애니메이션을 쓴다
        if (select && tabs.size > 1) newTabAnimFor = tab
        if (select) selectTab(tab)
        if (url != null) {
            if (url.startsWith("content://")) {
                // 기기에 있는 HTML 파일: 내용을 직접 읽어 불러온다 (형식 정보가 없거나 권한이 사라져도 열리게)
                loadLocalHtml(tab, url)
            } else {
                prefetchDns(url)
                tab.webView.loadUrl(url)
            }
        }
        updateTabCount()
        prepareSpareWebView()
        return tab
    }

    /**
     * 기기의 HTML 파일(content://)을 탭에 연다.
     * 파일 내용을 읽어 가짜 https 주소(LOCAL_BASE)를 기준으로 불러오므로,
     * 파일 형식(MIME)이 text/plain 이어도 문서로 열리고, localStorage 같은 웹 저장소도 동작한다.
     */
    private fun loadLocalHtml(tab: BrowserTab, uriStr: String, mime: String = "text/html") {
        val uri = Uri.parse(uriStr)
        val name = localFileNames[uriStr] ?: queryFileName(uri) ?: uri.lastPathSegment ?: "file.html"
        localFileNames[uriStr] = name
        val wv = tab.webView
        Thread {
            val bytes = try {
                contentResolver.openInputStream(uri)?.use { it.readBytes() }
            } catch (e: Throwable) {
                null
            }
            ui.post {
                if (isFinishing || isDestroyed) return@post
                if (bytes == null || bytes.size > 40 * 1024 * 1024) {
                    toast(if (bytes == null) "파일을 열 수 없습니다" else "파일이 너무 커서 열 수 없습니다")
                    // 아무것도 못 불러온 빈 탭이 남지 않게 닫는다
                    if (tab in tabs && tab.webView.url.isNullOrEmpty() && tabs.size > 1) closeTab(tab)
                    return@post
                }
                // 기록용 주소(historyUrl)도 같게 줘야 일반 탭처럼 주소창·제목·새로고침·뒤로가기가 정상 동작한다
                val pageUrl = LOCAL_BASE + Uri.encode(name)
                wv.loadDataWithBaseURL(pageUrl, decodeHtmlBytes(bytes), mime, "UTF-8", pageUrl)
            }
        }.apply { isDaemon = true }.start()
    }

    /** HTML 바이트를 글자로 바꾼다: BOM → <meta charset> → UTF-8 순으로 인코딩을 정한다 */
    private fun decodeHtmlBytes(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        val head = String(b, 0, minOf(b.size, 2048), Charsets.ISO_8859_1)
        val cs = Regex("charset\\s*=\\s*[\"']?([A-Za-z0-9_\\-]+)", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        val charset = try { if (cs != null) java.nio.charset.Charset.forName(cs) else Charsets.UTF_8 } catch (e: Throwable) { Charsets.UTF_8 }
        return String(b, charset)
    }

    // ── 새 탭 추가 전용 애니메이션 ──
    // 탭을 바꿀 때의 은은한 페이드와 달리, 새 탭은 아래에서 살짝 떠올라 자리 잡는다 (약간 튕기는 스프링).
    private var newTabAnimFor: BrowserTab? = null

    private fun playNewTabEnter(v: View) {
        Motion.cancel(v)
        v.alpha = 0f
        v.translationY = dp(36).toFloat()
        v.scaleX = 0.94f
        v.scaleY = 0.94f
        Motion.spring(v, DynamicAnimation.ALPHA, 1f, 320f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        Motion.spring(v, DynamicAnimation.TRANSLATION_Y, 0f, 300f, 0.68f)
        Motion.spring(v, DynamicAnimation.SCALE_X, 1f, 280f, 0.7f)
        Motion.spring(v, DynamicAnimation.SCALE_Y, 1f, 280f, 0.7f)
    }

    /** 지금 보는 탭이 새 탭(홈) 화면인지 — AI 어시스턴트의 '바로 물어보기' 칩을 끌 때 쓴다 */
    internal fun isOnHomeTab(): Boolean = current?.isHome == true

    private fun selectTab(tab: BrowserTab) {
        if (mirrorActive) stopMirror()
        val alreadyCurrent = current === tab
        if (!alreadyCurrent) autoScrollerInst?.stop(null)
        if (!alreadyCurrent) ui.post { extActivatedEvent() }
        if (!alreadyCurrent) closeFind()
        current?.let {
            // 탭 화면의 카드에 보여줄 미리보기를 남겨 둔다 (탭 화면이 열려 있을 땐 이미 찍어 둠)
            if (it !== tab && !switcherOpen) it.thumb = captureContent()
            webContainer.removeView(it.webView)
            // 다른 탭으로 옮겨도 이전 탭을 멈추지 않는다 (영상·소리·스크립트가 계속 동작)
            // 소리·영상이 나오는 중이면 화면 뒤의 보이지 않는 칸에 계속 붙여 둔다 (떼어 놓으면 멈추는 경우가 있다)
            if (it !== tab) parkIfPlaying(it)
        }
        current = tab
        assistant?.refreshChips()
        webContainer.reset()
        scrollBars.reset()
        ui.post { scrollBars.sync() }
        groupOf(tab)?.collapsed = false
        unparkWebView(tab)
        webContainer.addView(tab.webView)
        pageScrollBar.bind(if (tab.isHome) null else tab.webView)
        Motion.cancel(tab.webView)
        tab.webView.translationY = 0f
        if (newTabAnimFor === tab && !tab.isHome && !switcherOpen && !alreadyCurrent && Motion.enabled(this)) {
            newTabAnimFor = null
            playNewTabEnter(tab.webView)
        } else if (switcherOpen || alreadyCurrent) {
            // 탭 화면에서 고른 경우: 카드가 펼쳐지는 전환이 대신 보여주므로 여기선 바로 표시
            // 이미 보고 있는 탭을 다시 고른 경우: 페이드 없이 그대로 둔다
            tab.webView.alpha = 1f
            tab.webView.scaleX = 1f
            tab.webView.scaleY = 1f
        } else {
            tab.webView.alpha = 0f
            tab.webView.scaleX = 0.97f
            tab.webView.scaleY = 0.97f
            Motion.spring(tab.webView, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_X, 1f, 260f, 0.8f)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_Y, 1f, 260f, 0.8f)
        }
        tab.pendingUrl?.let { u ->
            tab.pendingUrl = null
            tab.isHome = false
            assistant?.refreshChips()
            tab.stoppedByHome = false
            // 다른 창에서 넘어온 탭은 웹 기록·스크롤·확대를 담은 상태로 되살린다 (실패하면 주소만 연다)
            val st = tab.pendingState
            tab.pendingState = null
            val restored = st != null && runCatching { tab.webView.restoreState(st) != null }.getOrDefault(false)
            if (restored) {
                tab.restoreScrollPending = tab.pendingScrollRatio >= 0f ||
                    tab.pendingScrollX != 0 || tab.pendingScrollY != 0
                // 오류 화면(연결할 수 없어요 등)을 보던 탭: 오류 화면 항목은 되살리면 주소가 data:text/html... 로 바뀌고 내용도 비어 버린다.
                // 그래서 원래 주소를 다시 불러온다 (또 실패하면 그 주소로 오류 화면이 새로 뜬다)
                val cur = tab.webView.copyBackForwardList().currentItem
                if (cur != null && cur.url.startsWith("data:") && historyUrl(cur) != HOME_URL) {
                    tab.restoreScrollPending = false
                    tab.errorUrl = u
                    reloadTab(tab)
                }
            } else {
                tab.restoreScrollPending = false
                tab.webView.loadUrl(u)
            }
        }
        tab.webView.onResume()
        tab.paused = false
        tab.webView.requestFocus()
        updateUi()
    }

    /**
     * @param quitIfLast 사용자가 직접 마지막 탭을 닫은 경우 true: 탭을 비운 뒤 앱을 끈다.
     *   (페이지 스크립트가 닫는 경우 등은 false 로 두어 앱이 갑자기 꺼지지 않게 한다)
     */
    // ── 닫은 탭 다시 열기 ──
    // 사용자가 직접 닫은 탭(새 탭·시크릿 탭 포함)의 주소를 최근 50개까지 기억한다. 메모리에만 있다.
    /** url 이 null 이면 새 탭(홈) */
    private class ClosedTab(val url: String?, val title: String, val batch: Int, val incognito: Boolean)
    private val recentlyClosed = ArrayDeque<ClosedTab>()

    // 한 번에 닫힌 탭들(모두 닫기·그룹 닫기·선택 닫기)은 같은 묶음 번호를 갖고, 되돌릴 때 한꺼번에 돌아온다
    private var closedBatch = 0

    private fun rememberClosed(tab: BrowserTab, batch: Int = ++closedBatch): Boolean {
        val url = tabBookmarkUrl(tab)
        if (url == null && !tab.isHome) return false   // 주소도 없고 새 탭도 아닌 빈 탭은 기억할 게 없다
        // 시크릿 탭은 제목을 남기지 않는다 (메뉴·알림에 보이지 않게). 목록은 메모리에만 있고 앱이 꺼지면 사라진다
        recentlyClosed.addLast(ClosedTab(url, if (tab.incognito) "시크릿 탭" else tabTitle(tab), batch, tab.incognito))
        while (recentlyClosed.size > 50) recentlyClosed.removeFirst()
        return true
    }

    private fun reopenClosedTab() {
        val last = recentlyClosed.removeLastOrNull()
        if (last == null) { toast("다시 열 탭이 없어요"); return }
        // 같은 묶음으로 닫힌 탭은 모두 꺼내 원래 순서대로 연다
        val group = arrayListOf(last)
        while (recentlyClosed.lastOrNull()?.batch == last.batch) group.add(recentlyClosed.removeLast())
        group.reverse()
        // 한 개면 그 탭으로 이동, 여러 개면 첫 탭으로 이동하고 나머지는 뒤에 열어 둔다
        group.forEachIndexed { i, c -> createTab(c.url, select = i == 0, home = c.url == null, incognito = c.incognito) }
        if (group.size > 1) toast("탭 ${group.size}개를 다시 열었어요")
        if (tabSwitcher.isShown) refreshSwitcher(false)
    }

    /** 여러 탭을 한꺼번에 닫는 곳에서 쓴다: 닫기 전에 모두 기억해 두고, 닫은 뒤 "되돌리기" 알림 하나를 띄운다 */
    private fun closeTabsUndoable(targets: List<BrowserTab>, close: () -> Unit) {
        val batch = ++closedBatch
        // 탭이 새 탭 하나뿐일 때 닫는 건 아무것도 닫는 게 아니므로 기억하지 않는다
        val onlyBlank = targets.size == 1 && tabs.size == 1 && targets[0].isHome && !targets[0].incognito
        val saved = if (onlyBlank) 0 else targets.count { rememberClosed(it, batch) }
        close()
        if (saved > 0 && prefs.notifyTabUndo) {
            AppToast.showAction(this, "탭 ${saved}개를 닫았어요", null, "되돌리기") { reopenClosedTab() }
        }
    }

    /** 사용자가 직접 탭을 닫는 곳에서 쓴다: 닫기 + 기억 + "되돌리기" 알림 */
    private fun closeTabUndoable(tab: BrowserTab, quitIfLast: Boolean = false) {
        val wasLast = tabs.size == 1
        val saved = !(wasLast && tab.isHome && !tab.incognito) && rememberClosed(tab)
        val title = if (tab.incognito) null else tabTitle(tab)
        closeTab(tab, quitIfLast)
        if (saved && !(quitIfLast && wasLast) && prefs.notifyTabUndo) {
            AppToast.showAction(this, "탭을 닫았어요", title, "되돌리기") { reopenClosedTab() }
        }
    }

    private fun closeTab(tab: BrowserTab, quitIfLast: Boolean = false) {
        val wasLast = tabs.size == 1
        // 마지막 탭이 시크릿이면 일반 새 탭을 하나 만들어 두고 시크릿 탭을 닫는다
        if (tabs.size == 1 && tab.incognito) createTab(null, select = false, home = true)
        if (tabs.size == 1) {
            tab.groupId = 0
            pruneEmptyGroups()
            tab.isHome = true
            assistant?.refreshChips()
            if (tab === current) pageScrollBar.bind(null)
            tab.redirectSources.clear()
            tab.thumb = null
            tab.mediaFrames.clear()
            onMediaChanged()
            tab.webView.stopLoading()
            tab.favicon = null
            tab.pendingUrl = null
            tab.pendingTitle = null
            // 이미 홈 항목이면 기록만 비운다. 아니면 홈을 불러오고, 다 불러와지면 기록을 비운다
            if (tab.webView.url == HOME_URL) tab.webView.clearHistory()
            else loadHome(tab, clear = true)
            updateUi()
            scheduleStripRefresh()
            if (quitIfLast && wasLast) finishAndRemoveTask()
            return
        }
        val index = tabs.indexOf(tab)
        tabs.remove(tab)
        tabs.forEach { if (it.opener === tab) it.opener = null }
        if (tab === current) {
            webContainer.removeView(tab.webView)
            current = null
            // 링크로 열린 탭을 닫으면 그 탭을 연 탭으로 돌아간다.
            val next = tab.opener?.takeIf { it in tabs } ?: tabs[minOf(index, tabs.size - 1)]
            selectTab(next)
        }
        tab.mediaFrames.clear()
        tab.lazyInit = null
        tab.liveWebView?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading(); it.destroy()
        }
        if (tab.incognito) purgeIncognitoIfUnused()
        pruneEmptyGroups()
        updateTabCount()
        onMediaChanged()
        if (quitIfLast && wasLast) finishAndRemoveTask()
    }

    private fun updateTabCount() {
        val n = tabs.size
        val text = if (n > 99) "99+" else n.toString()
        for (tv in listOf(tabCount, tabCountBottom, stripTabCount)) {
            if (tv.text.toString() != text) {
                val old = tv.text.toString().removeSuffix("+").toIntOrNull() ?: n
                tv.text = text
                // 자리수가 늘어나도 상자 안에 딱 맞도록 글자 크기 조절
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (n > 99) 8f else if (n >= 10) 10f else 12f)
                val icon = tv.background as? MorphIconDrawable
                if (icon != null) {
                    tv.setTextColor(android.graphics.Color.TRANSPARENT)   // 숫자는 아이콘이 그린다 (글자가 보이면 겹친다)
                    // 숫자는 카드를 그리는 아이콘이 직접 그린다: 숫자가 위/아래로 굴러 바뀌고 카드가 한 번 출렁인다
                    icon.setLabel(text, animate = tv.isShown && Motion.enabled(this), dir = if (n >= old) 1 else -1)
                } else {
                    Motion.pop(tv)
                }
            }
        }
        scheduleStripRefresh()
    }

    // ───────────────────────── 탭 그룹 ─────────────────────────

    private fun groupOf(tab: BrowserTab): TabGroup? =
        if (tab.groupId == 0) null else groups.firstOrNull { it.id == tab.groupId }

    private fun nextGroupColor(): Int = TabGroup.COLORS[groups.size % TabGroup.COLORS.size]

    private fun defaultGroupName(): String = "그룹 $nextGroupId"

    private fun createGroup(name: String, color: Int): TabGroup {
        val g = TabGroup(nextGroupId++, name, color)
        groups.add(g)
        return g
    }

    /** 탭이 하나도 없는 그룹은 자동으로 사라진다. */
    private fun pruneEmptyGroups() {
        groups.removeAll { g -> tabs.none { it.groupId == g.id } }
    }

    /** group == null 이면 그룹에서 빼낸다. 그룹으로 넣을 때는 그 그룹의 마지막 탭 바로 뒤로 옮겨 붙어 있게 한다. */
    private fun moveToGroup(tab: BrowserTab, group: TabGroup?) {
        if (tab.incognito && group != null) {
            toast("시크릿 탭은 그룹에 넣을 수 없어요")
            return
        }
        if (group == null) {
            tab.groupId = 0
        } else {
            val old = tabs.indexOf(tab)
            tabs.remove(tab)
            val last = tabs.indexOfLast { it.groupId == group.id }
            tab.groupId = group.id
            if (last >= 0) tabs.add(last + 1, tab) else tabs.add(old.coerceIn(0, tabs.size), tab)
        }
        pruneEmptyGroups()
    }

    private fun ungroup(group: TabGroup) {
        tabs.filter { it.groupId == group.id }.forEach { it.groupId = 0 }
        groups.remove(group)
    }

    private fun closeGroup(group: TabGroup) {
        val targets = tabs.filter { it.groupId == group.id }
        closeTabsUndoable(targets) { targets.forEach { closeTab(it) } }
        pruneEmptyGroups()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** 그룹 만들기 / 편집 대화상자 (이름 + 색상). 위쪽 미리보기로 탭 줄에 보일 모습을 바로 확인한다. */
    private fun showGroupEditor(existing: TabGroup?, onSave: (String, Int) -> Unit) {
        val view = layoutInflater.inflate(R.layout.dialog_group, null)
        val et = view.findViewById<EditText>(R.id.etGroupName)
        val grid = view.findViewById<GridLayout>(R.id.colorGrid)
        val preview = view.findViewById<TextView>(R.id.groupPreview)
        var selected = existing?.color ?: nextGroupColor()
        et.setText(existing?.name ?: defaultGroupName())
        et.setSelection(et.text.length)

        fun updatePreview() {
            preview.text = et.text.toString().trim().ifEmpty { existing?.name ?: defaultGroupName() }
            preview.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(selected)
            }
        }

        fun renderColors(popColor: Int? = null) {
            grid.removeAllViews()
            TabGroup.COLORS.forEach { c ->
                val swatch = TextView(this)
                swatch.gravity = android.view.Gravity.CENTER
                swatch.textSize = 16f
                swatch.setTextColor(0xFFFFFFFF.toInt())
                swatch.contentDescription = "색상 선택"
                swatch.text = if (c == selected) "✓" else ""
                swatch.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                }
                swatch.layoutParams = GridLayout.LayoutParams().apply {
                    width = dp(40)
                    height = dp(40)
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                }
                swatch.setOnClickListener {
                    selected = c
                    renderColors(c)
                    updatePreview()
                }
                grid.addView(swatch)
                if (c == popColor) Motion.pop(swatch, 0.7f)
            }
        }
        renderColors()
        updatePreview()
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updatePreview() }
            override fun afterTextChanged(s: Editable?) {}
        })

        ThemedDialogBuilder(this)
            .setTitle(if (existing == null) "새 그룹" else "그룹 편집")
            .setView(view)
            .setNegativeButton("취소", null)
            .setPositiveButton(if (existing == null) "만들기" else "저장") { _, _ ->
                val name = et.text.toString().trim().ifEmpty { existing?.name ?: defaultGroupName() }
                onSave(name, selected)
            }
            .show()
    }

    /** 북마크할 수 있는 탭의 웹 주소 (홈 화면이거나 웹페이지가 아니면 null). 아직 불러오지 않은 복원 탭은 저장된 주소를 쓴다. */
    private fun tabBookmarkUrl(tab: BrowserTab): String? {
        if (tab.isHome) return null
        val u = pageUrlOf(tab) ?: tab.pendingUrl
        return u?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    /**
     * 화면에 보이는 순서대로 한 덩어리씩 센다: 그룹에 속하지 않은 탭 하나, 또는 그룹 하나(안의 탭들).
     * 그룹에 속한 탭은 그룹 안에서만, 그룹 밖의 탭은 덩어리(탭/그룹 상자) 단위로 움직인다.
     */
    private fun tabUnits(): List<List<BrowserTab>> {
        val units = ArrayList<List<BrowserTab>>()
        val seen = HashSet<Int>()
        for (t in tabs) {
            val g = groupOf(t)
            if (g == null) units.add(listOf(t))
            else if (seen.add(g.id)) units.add(tabs.filter { it.groupId == g.id })
        }
        return units
    }

    /** 탭을 앞(-1)/뒤(+1)로 한 칸 옮긴다 (데이터만). 그룹 안의 탭은 그룹 안에서, 그룹에 없는 탭은 그룹 덩어리를 통째로 건너뛴다. */
    private fun reorderTab(tab: BrowserTab, dir: Int) {
        val g = groupOf(tab)
        if (g != null) {
            val m = tabs.filter { it.groupId == g.id }
            val other = m.getOrNull(m.indexOf(tab) + dir) ?: return
            val i = tabs.indexOf(tab)
            val j = tabs.indexOf(other)
            tabs[i] = other
            tabs[j] = tab
        } else {
            val units = tabUnits()
            val u = units.indexOfFirst { it.size == 1 && it[0] === tab && groupOf(it[0]) == null }
            if (u < 0) return
            val neighbor = units.getOrNull(u + dir) ?: return
            tabs.remove(tab)
            if (dir < 0) tabs.add(tabs.indexOf(neighbor.first()), tab)
            else tabs.add(tabs.indexOf(neighbor.last()) + 1, tab)
        }
    }

    // ───────────────────────── 끌어서 탭 순서 바꾸기 ─────────────────────────

    /**
     * 길게 눌러 끌기 공통 터치 처리.
     * 길게 누르면 끌기가 시작되고(onStart 가 true), 손가락을 움직이는 동안 onMove, 떼면 onEnd 가 불린다.
     * 끌지 않고 그냥 뗐으면 onEnd 의 moved 가 false 라서 호출한 쪽이 메뉴를 띄우면 된다.
     * pressedScale 이 있으면 누르는 동안 카드가 쏙 들어가는 효과도 같이 준다.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun bindDragGesture(
        v: View,
        pressedScale: Float?,
        onStart: (rawX: Float, rawY: Float) -> Boolean,
        onMove: (rawX: Float, rawY: Float) -> Unit,
        onEnd: (moved: Boolean, canceled: Boolean) -> Unit,
        // 옆으로 밀어서 치우는 동작 (주면 켜진다). 충분히 밀거나 빠르게 튕기면 불리고, 아니면 제자리로 돌아온다.
        onSwipeDismiss: (() -> Unit)? = null,
        canSwipe: () -> Boolean = { true }
    ) {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        var dragging = false
        var moved = false
        var swiping = false
        var crossed = false
        var vt: android.view.VelocityTracker? = null
        var downX = 0f
        var downY = 0f
        var lastX = 0f
        var lastY = 0f

        fun releaseTracker() {
            vt?.recycle()
            vt = null
        }
        // 놓았을 때 제자리로: 손가락 속도를 이어받아 살짝 튕기며 돌아온다
        fun springBack(view: View, vx: Float = 0f) {
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.7f)
                .setStartVelocity(vx)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, 0f, 420f, 0.7f)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 500f, 1f)
        }
        // 놓았을 때 치우기: 손가락이 움직이던 속도 그대로 날아가며 투명해지고, 거의 사라지면 목록을 다시 그려 빈자리를 메운다
        fun flyOff(view: View, dir: Float, vx: Float) {
            val w = view.width.toFloat().coerceAtLeast(1f)
            if (!Motion.enabled(view.context)) {
                onSwipeDismiss?.invoke()
                return
            }
            var fired = false
            fun fire() {
                if (fired) return
                fired = true
                onSwipeDismiss?.invoke()
            }
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, dir * w * 1.5f, 320f, 1f) { fire() }
                .setStartVelocity(vx)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, dir * 12f, 260f, 1f)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 0f, 520f, 1f) { fire() }
        }
        fun finishSwipe(view: View, dx: Float, vx: Float) {
            val w = view.width.toFloat().coerceAtLeast(1f)
            val sameDir = vx * dx > 0f
            val flung = sameDir && Math.abs(vx) > 1200f && Math.abs(dx) > w * 0.1f
            if (Math.abs(dx) > w * 0.4f || flung) {
                flyOff(view, if (dx > 0) 1f else -1f, vx)
            } else {
                springBack(view, vx)
            }
        }

        val handler: (View, MotionEvent) -> Boolean = { view, e ->
            lastX = e.rawX
            lastY = e.rawY
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    moved = false
                    swiping = false
                    crossed = false
                    downX = e.rawX
                    downY = e.rawY
                    if (onSwipeDismiss != null) {
                        releaseTracker()
                        vt = android.view.VelocityTracker.obtain().also { it.addMovement(e) }
                    }
                    false
                }
                MotionEvent.ACTION_MOVE -> when {
                    dragging -> {
                        if (!moved && Math.hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > slop) moved = true
                        onMove(e.rawX, e.rawY)
                        true
                    }
                    onSwipeDismiss != null -> {
                        vt?.addMovement(e)
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        // 가로로 뚜렷하게 움직일 때만 밀기로 본다 (세로 스크롤과 구분)
                        if (!swiping && canSwipe() && Math.abs(dx) > slop * 2 && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            swiping = true
                            view.cancelLongPress()
                            view.isPressed = false
                            view.parent?.requestDisallowInterceptTouchEvent(true)
                            // 이전에 돌던 이동/투명도 스프링을 멈추고 손가락이 직접 움직이게 한다 (크기는 눌린 상태 유지)
                            Motion.cancel(view)
                            view.scaleX = pressedScale ?: 1f
                            view.scaleY = pressedScale ?: 1f
                        }
                        if (swiping) {
                            val w = view.width.toFloat().coerceAtLeast(1f)
                            view.translationX = dx
                            // 밀수록 살짝 기울고 옅어진다
                            view.rotation = (dx / w * 10f).coerceIn(-12f, 12f)
                            view.alpha = (1f - Math.abs(dx) / (w * 1.2f)).coerceIn(0.2f, 1f)
                            val past = Math.abs(dx) > view.width * 0.4f
                            if (past != crossed) {
                                crossed = past
                                view.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                            }
                            true
                        } else false
                    }
                    else -> false
                }
                MotionEvent.ACTION_UP -> when {
                    dragging -> {
                        dragging = false
                        view.isPressed = false
                        onEnd(moved, false)
                        true
                    }
                    swiping -> {
                        swiping = false
                        vt?.let {
                            it.addMovement(e)
                            it.computeCurrentVelocity(1000)
                            finishSwipe(view, e.rawX - downX, it.xVelocity)
                        } ?: springBack(view)
                        releaseTracker()
                        true
                    }
                    else -> {
                        releaseTracker()
                        false
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        onEnd(moved, true)
                    }
                    if (swiping) {
                        swiping = false
                        springBack(view)
                    }
                    releaseTracker()
                    false
                }
                else -> false
            }
        }
        v.setOnLongClickListener { view ->
            dragging = onStart(lastX, lastY)
            if (dragging) {
                view.isPressed = false
                // 끄는 동안 스크롤 뷰가 터치를 가로채지 않게 한다
                view.parent?.requestDisallowInterceptTouchEvent(true)
            }
            true
        }
        if (pressedScale != null) Motion.pressable(v, pressedScale, handler)
        else v.setOnTouchListener { view, e -> handler(view, e) }
    }

    // ── 상단 탭 줄 (가로) ──

    private var stripDrag: StripChip? = null
    private var stripGrab = 0f
    private var stripRawX = 0f
    private var stripSwapped = false

    // 탭을 탭 줄 밖(위/아래)으로 끌어내면 새 창으로 열린다
    private var stripRawY = 0f
    private var stripCanDetach = false
    private var stripDetached = false
    private var stripGhost: View? = null

    /** 끌고 있는 탭이 줄의 양 끝에 가까워지면 탭 줄이 알아서 그쪽으로 스크롤된다 */
    private val stripAutoScroll = object : Runnable {
        override fun run() {
            if (stripDrag == null) return
            val loc = IntArray(2)
            tabStripScroll.getLocationOnScreen(loc)
            val rel = stripRawX - loc[0]
            val edge = dp(56).toFloat()
            val w = tabStripScroll.width
            val dx = when {
                rel < edge -> -(edge - rel) / edge * dp(14)
                rel > w - edge -> (rel - (w - edge)) / edge * dp(14)
                else -> 0f
            }
            if (dx != 0f) {
                val step = if (dx > 0) maxOf(1, dx.toInt()) else minOf(-1, dx.toInt())
                val before = tabStripScroll.scrollX
                tabStripScroll.scrollBy(step, 0)
                if (tabStripScroll.scrollX != before) updateStripDrag()
            }
            tabStripScroll.postOnAnimation(this)
        }
    }

    private val stripClipSaved = ArrayList<Pair<ViewGroup, Boolean>>()

    /** 끄는 동안 탭 줄과 그 바깥 레이아웃의 '자식 영역 밖 잘라내기'를 풀어, 끄는 탭이 가장자리에서 잘리지 않게 한다 */
    private fun setStripUnclipped(unclipped: Boolean) {
        if (unclipped) {
            var p: android.view.ViewParent? = tabStrip
            while (p is ViewGroup) {
                stripClipSaved.add(p to p.clipChildren)
                p.clipChildren = false
                p = p.parent
            }
        } else {
            stripClipSaved.forEach { (g, old) -> g.clipChildren = old }
            stripClipSaved.clear()
        }
    }

    private fun startStripDrag(tab: BrowserTab, rawX: Float, rawY: Float): Boolean {
        val c = stripChips[tab] ?: return false
        if (stripDrag != null) return false
        stripDrag = c
        stripSwapped = false
        stripRawX = rawX
        stripRawY = rawY
        // 설정에서 껐거나 시크릿 탭이면 새 창으로 끌어낼 수 없다 (새 탭 화면은 새 탭 화면 그대로 새 창으로 간다)
        stripCanDetach = prefs.dragTabToWindow && !tab.incognito
        stripDetached = false
        val loc = IntArray(2)
        tabStrip.getLocationOnScreen(loc)
        stripGrab = rawX - loc[0] - c.view.left
        c.view.translationZ = dp(5).toFloat()
        // 탭 줄을 올리지 않는다: 툴바가 탭 줄 위에 그려져서 끄는 탭의 그림자가 탭 줄 아래(툴바 쪽)로 번지지 않는다
        c.bg?.alpha = 255 // 선택되지 않은 탭도 끄는 동안은 카드처럼 보이게
        setStripUnclipped(true)
        tabStripScroll.postOnAnimation(stripAutoScroll)
        return true
    }

    /** 끌고 있는 탭이 손가락을 따라가는 위치 (탭 줄 안쪽으로 제한) */
    private fun stripDragWant(c: StripChip): Float {
        val maxLeft = (tabStrip.width - c.view.width).coerceAtLeast(0)
        return stripDragRaw().coerceIn(0f, maxLeft.toFloat())
    }

    /** 손가락 위치만으로 계산한 탭의 왼쪽 위치 (탭 줄 밖으로 나가도 제한하지 않음) */
    private fun stripDragRaw(): Float {
        val loc = IntArray(2)
        tabStrip.getLocationOnScreen(loc)
        return stripRawX - loc[0] - stripGrab
    }

    /** dir 쪽으로 이웃한 덩어리(탭 하나, 또는 그룹 알약 + 그 탭들)의 뷰들 */
    private fun stripNeighbor(tab: BrowserTab, dir: Int): List<View>? {
        val g = groupOf(tab)
        if (g != null) {
            val m = tabs.filter { it.groupId == g.id }
            val n = m.getOrNull(m.indexOf(tab) + dir) ?: return null
            return stripChips[n]?.view?.let { listOf(it) }
        }
        val units = tabUnits()
        val u = units.indexOfFirst { it.size == 1 && it[0] === tab && groupOf(it[0]) == null }
        if (u < 0) return null
        val unit = units.getOrNull(u + dir) ?: return null
        val g2 = groupOf(unit[0])
        val views = ArrayList<View>()
        if (g2 != null) stripPills[g2.id]?.let { views.add(it) }
        if (g2 == null || !g2.collapsed) unit.forEach { t -> stripChips[t]?.view?.let { views.add(it) } }
        return views.takeIf { it.isNotEmpty() }
    }

    private fun stripDesiredOrder(): List<View> {
        val out = ArrayList<View>()
        val seen = HashSet<Int>()
        for (t in tabs) {
            val g = groupOf(t)
            if (g != null && seen.add(g.id)) stripPills[g.id]?.let { out.add(it) }
            if (g != null && g.collapsed) continue
            stripChips[t]?.view?.let { out.add(it) }
        }
        return out
    }

    private fun updateStripDrag() {
        val c = stripDrag ?: return
        if (stripChips[c.tab] !== c || c.view.parent == null) {
            stripDrag = null
            return
        }
        val v = c.view
        val want = stripDragWant(c)
        v.translationX = want - v.left
        // 탭 줄에서 충분히 벗어나면 "새 창으로 열기" 상태: 순서 바꾸기는 멈추고 손가락을 따라다니는 미리보기를 보여 준다
        if (stripCanDetach) {
            val sl = IntArray(2)
            tabStripScroll.getLocationOnScreen(sl)
            val m = dp(40)
            // 세로로 탭 줄을 벗어났거나, 창이 좌우로 나란히 있을 때 손가락이 이 창의 옆 가장자리를 넘어
            // 다른 창으로 넘어갔으면 "밖"이다. (옆 창의 탭 줄은 같은 높이라 세로만 보면 영영 안 벗어난다)
            val dl = IntArray(2)
            window.decorView.getLocationOnScreen(dl)
            val sideM = dp(12)
            val outsideSide = stripRawX < dl[0] - sideM || stripRawX > dl[0] + window.decorView.width + sideM
            // 주소창 위로 올라오면 탭 줄과 가까워도 바로 '밖'으로 본다 (주소창에 놓을 수 있게)
            var overAddr = false
            if (urlBar.isShown) {
                val ul = IntArray(2)
                urlBar.getLocationOnScreen(ul)
                overAddr = stripRawX >= ul[0] && stripRawX <= ul[0] + urlBar.width &&
                    stripRawY >= ul[1] && stripRawY <= ul[1] + urlBar.height
            }
            val outside = outsideSide || overAddr || stripRawY > sl[1] + tabStripScroll.height + m || stripRawY < sl[1] - m
            if (outside != stripDetached) {
                stripDetached = outside
                v.performHapticFeedback(
                    if (outside && Build.VERSION.SDK_INT >= 23) android.view.HapticFeedbackConstants.CONTEXT_CLICK
                    else android.view.HapticFeedbackConstants.CLOCK_TICK
                )
                // 원래 탭은 빈 자리처럼 흐려지고 조금 작아진다
                val sc = if (outside) 0.9f else 1f
                v.animate().alpha(if (outside) 0.3f else 1f).scaleX(sc).scaleY(sc).setDuration(160).start()
                if (outside) {
                    // 시스템 드래그로 바꿔 카드가 앱 밖에서도 보이게 한다. 안 되는 기기에서는 예전처럼 창 안 카드
                    if (!beginSystemDrag(c)) showStripGhost(c.tab, c.icon.drawable)
                } else removeStripGhost()
            }
            if (stripDetached) {
                moveStripGhost()
                return
            }
        }
        // 순서를 바꿀지는 제한하기 전의 손가락 위치로 판단한다.
        // (제한한 위치로 보면 맨 앞/맨 뒤 탭과는 중심이 절대 넘어가지 못해 첫 번째 자리로 옮길 수 없었다)
        val cx = stripDragRaw() + v.width / 2f
        var dir = 0
        stripNeighbor(c.tab, 1)?.last()?.let { e ->
            if (e.parent != null && cx > e.left + e.width / 2f) dir = 1
        }
        if (dir == 0) {
            stripNeighbor(c.tab, -1)?.first()?.let { e ->
                if (e.parent != null && cx < e.left + e.width / 2f) dir = -1
            }
        }
        if (dir != 0) swapStripDrag(c, dir)
    }

    /** 데이터 순서를 바꾸고, 끌고 있는 뷰는 그대로 둔 채 나머지 뷰들만 새 순서로 다시 끼운다 (이웃 탭은 미끄러지듯 자리를 옮긴다) */
    private fun swapStripDrag(c: StripChip, dir: Int) {
        val v = c.view
        val oldLeft = HashMap<View, Int>()
        for (i in 0 until tabStrip.childCount) {
            val ch = tabStrip.getChildAt(i)
            if (ch !== v) oldLeft[ch] = ch.left
        }
        reorderTab(c.tab, dir)
        stripSwapped = true
        val desired = stripDesiredOrder()
        val di = desired.indexOf(v)
        if (di < 0) return
        val others = desired.filter { it !== v }
        others.forEach { tabStrip.removeView(it) }
        var at = tabStrip.indexOfChild(v)
        for (i in 0 until di) {
            tabStrip.addView(desired[i], at)
            at++
        }
        var after = at + 1
        for (i in di + 1 until desired.size) {
            tabStrip.addView(desired[i], after)
            after++
        }
        tabStrip.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                tabStrip.viewTreeObserver.removeOnPreDrawListener(this)
                others.forEach { ov ->
                    val o = oldLeft[ov] ?: return@forEach
                    val dx = o - ov.left
                    if (dx != 0) {
                        ov.animate().cancel()
                        ov.translationX = dx + ov.translationX
                        ov.animate().translationX(0f).setDuration(180).setInterpolator(stripEase).start()
                    }
                }
                if (stripDrag === c) v.translationX = stripDragWant(c) - v.left
                return true
            }
        })
    }

    /**
     * 끄는 탭을 따라다니는 카드 (창 맨 위에 그려서 탭 줄 밖에서도 보인다).
     * 파비콘 + 제목 + "놓으면 새 창으로 열려요" 안내. 나타날 때 통통 튀며 커지고, 움직이는 방향으로 살짝 기운다.
     */
    private fun showStripGhost(tab: BrowserTab, favicon: android.graphics.drawable.Drawable?) {
        removeStripGhost(animate = false)
        val g = buildStripGhostView(tab, favicon)
        stripGhostLastX = stripRawX
        (window.decorView as ViewGroup).addView(g, FrameLayout.LayoutParams(stripGhostW, stripGhostH))
        stripGhost = g
        moveStripGhost()
        // 나타나기: 작게 시작해 통통 튀며 커진다
        if (Motion.enabled(this)) {
            g.alpha = 0f
            g.scaleX = 0.7f
            g.scaleY = 0.7f
            Motion.spring(g, DynamicAnimation.SCALE_X, 1f, 520f, 0.55f)
            Motion.spring(g, DynamicAnimation.SCALE_Y, 1f, 520f, 0.55f)
            Motion.spring(g, DynamicAnimation.ALPHA, 1f, 700f, 1f)
        }
    }

    /**
     * 끄는 카드 모양을 만들어 크기를 재 둔다. 창 안 카드와 시스템 드래그 카드가 같이 쓴다.
     * 위: 파비콘 + 제목 / 가운데: 페이지 미리보기 / 아래: "팝업 창으로 열기" 안내 알약.
     * 시스템 드래그 그림자는 비트맵이라 elevation 그림자가 안 그려지므로, 바깥 여백에 그림자를 직접 그린다.
     */
    private fun buildStripGhostView(tab: BrowserTab, favicon: android.graphics.drawable.Drawable?): View {
        val title = (tab.liveWebView?.title?.takeIf { it.isNotBlank() && it != HOME_URL } ?: tab.pendingTitle?.takeIf { it.isNotBlank() }
            ?: tabBookmarkUrl(tab)?.let { runCatching { Uri.parse(it).host }.getOrNull() }).orEmpty()
            .ifBlank { if (tab.isHome) "새 탭" else "" }
        fun attr(a: Int, def: Int) = ThemeColors.get(tabStrip, a, def)
        val surface = attr(com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFF202124.toInt())
        val accent = attr(com.google.android.material.R.attr.colorPrimary, 0xFF1A73E8.toInt())
        val onAccent = attr(com.google.android.material.R.attr.colorOnPrimary, 0xFFFFFFFF.toInt())
        val thumbBg = attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFFEDEDED.toInt())
        val outline = attr(com.google.android.material.R.attr.colorOutlineVariant, 0x33000000)

        val cardW = dp(208)
        val thumbH = dp(112)
        val pad = dp(10)
        val shadowPad = dp(22) // 그림자·기울임이 잘리지 않게 카드 바깥에 둔 여백
        stripGhostPad = shadowPad
        stripGhostSurface = surface

        val icon = ImageView(this).apply {
            val d = favicon?.constantState?.newDrawable()?.mutate()
            if (d != null) setImageDrawable(d) else {
                setImageResource(R.drawable.ic_tab)
                setColorFilter(onSurface)
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            background = GradientDrawable().apply { cornerRadius = dp(5).toFloat(); setColor(0x00000000) }
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        val titleTv = TextView(this).apply {
            text = title
            setTextColor(onSurface)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(icon, LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) })
            addView(titleTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        // 페이지 미리보기 (위쪽 기준으로 꽉 채움). 없으면 파비콘을 크게
        val shot: Bitmap? = (if (current === tab) captureContent() else null) ?: tab.thumb
        val thumbRadius = dp(10).toFloat()
        val thumb = ImageView(this).apply {
            background = GradientDrawable().apply { cornerRadius = thumbRadius; setColor(thumbBg) }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            if (shot != null) {
                scaleType = ImageView.ScaleType.MATRIX
                setImageBitmap(shot)
                imageMatrix = topCropMatrix(shot, cardW - pad * 2, thumbH)
            } else {
                scaleType = ImageView.ScaleType.CENTER
                val d = favicon?.constantState?.newDrawable()?.mutate()
                if (d != null) setImageDrawable(d) else {
                    setImageResource(R.drawable.ic_tab)
                    setColorFilter(onSurface and 0x00FFFFFF or 0x66000000)
                }
            }
        }

        val hintTv = TextView(this).apply {
            text = "놓으면 새 창으로 열려요"
            setTextColor(onAccent)
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(accent) }
        }

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(header, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(22)))
            addView(thumb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, thumbH).apply { topMargin = dp(8) })
            addView(hintTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10); gravity = Gravity.CENTER_HORIZONTAL
            })
            background = GradientDrawable().apply {
                setColor(surface)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), outline)
            }
        }

        val g = object : FrameLayout(this) {
            private val sp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = surface
                setShadowLayer(dp(14).toFloat(), 0f, dp(6).toFloat(), 0x55000000)
            }
            private val r = RectF()

            override fun dispatchDraw(canvas: Canvas) {
                r.set(shadowPad.toFloat(), shadowPad.toFloat(), (width - shadowPad).toFloat(), (height - shadowPad).toFloat())
                canvas.drawRoundRect(r, dp(18).toFloat(), dp(18).toFloat(), sp)
                super.dispatchDraw(canvas)
            }
        }.apply {
            setWillNotDraw(false)
            setLayerType(View.LAYER_TYPE_SOFTWARE, null) // setShadowLayer 는 소프트웨어 그리기에서 확실히 동작
            setPadding(shadowPad, shadowPad, shadowPad, shadowPad)
            addView(body, FrameLayout.LayoutParams(cardW, FrameLayout.LayoutParams.WRAP_CONTENT))
        }
        g.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        stripGhostW = g.measuredWidth
        stripGhostH = g.measuredHeight
        return g
    }

    private var stripGhostPad = 0
    private var stripGhostSurface = 0xFFFFFFFF.toInt()
    private var stripGhostW = 0
    private var stripGhostH = 0
    private var stripGhostLastX = 0f

    private fun moveStripGhost() {
        val g = stripGhost ?: return
        val dl = IntArray(2)
        window.decorView.getLocationOnScreen(dl)
        // 손가락 바로 위에 띄운다 (손가락에 가리지 않게)
        g.x = stripRawX - dl[0] - stripGhostW / 2f
        g.y = stripRawY - dl[1] - stripGhostH - dp(28)
        // 움직인 방향으로 살짝 기울고, 멈추면 천천히 바로 선다
        val dx = stripRawX - stripGhostLastX
        stripGhostLastX = stripRawX
        val target = (dx * 0.8f).coerceIn(-9f, 9f)
        g.rotation = g.rotation * 0.75f + target * 0.25f
    }

    /**
     * 카드를 치운다. [commit] 이면 새 창으로 열리는 중이라 커지며 사라지고,
     * 아니면(탭 줄로 돌아옴) 작아지며 사라진다.
     */
    private fun removeStripGhost(commit: Boolean = false, animate: Boolean = true) {
        val g = stripGhost ?: return
        stripGhost = null
        val parent = g.parent as? ViewGroup
        if (!animate || !Motion.enabled(this)) {
            parent?.removeView(g)
            return
        }
        Motion.cancel(g)
        val to = if (commit) 1.25f else 0.8f
        g.animate().alpha(0f).scaleX(to).scaleY(to).rotation(0f)
            .setDuration(if (commit) 240 else 150)
            .withEndAction { parent?.removeView(g) }
            .start()
    }

    private fun endStripDrag(moved: Boolean, canceled: Boolean) {
        // 시스템 드래그로 넘어가면 손가락 이벤트가 취소로 끝난다. 마무리는 드래그가 끝날 때 한다
        if (sysDragActive) return
        val c = stripDrag ?: return
        stripDrag = null
        val detach = stripDetached && !canceled
        stripDetached = false
        stripCanDetach = false
        removeStripGhost(commit = detach)
        tabStripScroll.removeCallbacks(stripAutoScroll)
        val v = c.view
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
        v.animate().translationX(0f).setDuration(160).setInterpolator(stripEase)
            .withEndAction {
                v.translationZ = 0f
                if (stripDrag == null) {
                    setStripUnclipped(false)
                }
            }.start()
        applyChipSelection(c)
        if (stripSwapped) saveTabs()
        scheduleStripRefresh()
        // 끌지 않고 그냥 뗐으면 예전처럼 탭 메뉴
        if (!canceled && !moved && !stripSwapped) showTabMenu(c.tab, c.view) { scheduleStripRefresh() }
        // 탭 줄 밖에서 놓았으면 이 탭을 새 창으로 옮긴다 (웹 기록·확대·스크롤이 따라간다)
        if (detach && moveTabToWindow(c.tab, null, closeEmptyWindow = true)) scheduleStripRefresh()
    }

    // ── 탭을 시스템 드래그로 끌어내기 (카드가 앱 밖에서도 보이고, 놓으면 팝업) ──

    private var sysDragActive = false
    private var sysDragOverlay: TabDropOverlay? = null
    private var sysDragZone = TabDropOverlay.ZONE_POPUP
    private var sysDragX = 0
    private var sysDragY = 0
    private var sysDropHandled = false
    private var sysDragMorph: SpringAnimation? = null
    private var sysDragMorphValue = 1f
    private var sysDragTilt = 0f
    private var sysDragShadow: View.DragShadowBuilder? = null
    private var sysDragLastX = Int.MIN_VALUE
    private var sysDragViewRef: View? = null

    private fun updateSysDragShadow(v: View) {
        val sh = sysDragShadow ?: return
        if (!sysDragActive || !v.isAttachedToWindow) {
            sysDragMorph?.cancel()
            return
        }
        try { v.updateDragShadow(sh) } catch (_: Throwable) { sysDragMorph?.cancel() }
    }

    /** 다른 창의 탭 줄에 놓였으면 그 창 (놓은 창이 알려 준다. 드래그가 끝날 때 이 창이 옮긴다) */
    private var sysDragTarget: MainActivity? = null
    /** 다른 창의 탭 줄이 아니라 주소창에 놓았는지 (true 면 그 창의 현재 탭을 이 탭의 주소로 연다) */
    private var sysDragAddrTarget = false

    /**
     * 탭 줄 밖으로 나간 탭을 시스템 드래그로 넘긴다. 시스템이 카드를 그려서 앱 창 밖에서도 보인다.
     * 드래그가 시작되면 이 창에는 놓을 곳을 알려 주는 투명 막을 얹는다. 시작하지 못하면 false (예전 방식으로 대신한다).
     */
    private fun beginSystemDrag(c: StripChip): Boolean {
        if (Build.VERSION.SDK_INT < 24 || sysDragActive) return false
        val url = tabBookmarkUrl(c.tab) ?: "새 탭"
        val card = buildStripGhostView(c.tab, c.icon.drawable)
        val w = card.measuredWidth
        val h = card.measuredHeight
        if (w <= 0 || h <= 0) return false
        card.layout(0, 0, w, h)
        val overlay = TabDropOverlay(this)
        val root = window.decorView as ViewGroup
        root.addView(
            overlay,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        overlay.setOnDragListener { v, e -> onStripSysDrag(v, e) }
        sysDragOverlay = overlay
        sysDragActive = true
        sysDropHandled = false
        sysDragZone = TabDropOverlay.ZONE_POPUP
        sysDragX = stripRawX.toInt()
        sysDragY = stripRawY.toInt()
        val lift = dp(28)
        val animate = Motion.enabled(this)
        val sp = stripGhostPad
        val chipW = c.view.width.coerceAtLeast(dp(96)).toFloat()
        val chipH = c.view.height.coerceAtLeast(dp(32)).toFloat()
        val innerW = (w - sp * 2).toFloat()
        val innerH = (h - sp * 2).toFloat()
        sysDragMorphValue = if (animate) 0f else 1f
        sysDragTilt = 0f
        val clipPath = android.graphics.Path()
        val clipRect = RectF()
        val shadowPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = stripGhostSurface }
        val shadow = object : View.DragShadowBuilder(card) {
            private fun m() = sysDragMorphValue
            private fun clipH() = chipH + (innerH - chipH) * m().coerceIn(0f, 1f)

            override fun onProvideShadowMetrics(outSize: android.graphics.Point, outTouch: android.graphics.Point) {
                outSize.set(w, h)
                // 처음엔 칩 한가운데가 손가락, 끝나면 손가락 바로 위에 카드가 뜬다 (손가락에 가리지 않게)
                val m = m()
                outTouch.set(w / 2, (sp + clipH() / 2 + (h / 2f + lift) * m).toInt())
            }

            override fun onDrawShadow(canvas: Canvas) {
                val m = m()
                val t = m.coerceIn(0f, 1f)
                val cw = chipW + (innerW - chipW) * t
                val ch = clipH()
                val cx = w / 2f
                val top = sp.toFloat()
                // 칩 모양 틀이 카드 크기로 펼쳐지며 내용이 드러난다 (모서리도 칩 → 카드로 부드럽게)
                clipRect.set(cx - cw / 2, top, cx + cw / 2, top + ch)
                val radius = dp(10) + (dp(18) - dp(10)) * t
                clipPath.reset()
                clipPath.addRoundRect(clipRect, radius.toFloat(), radius.toFloat(), android.graphics.Path.Direction.CW)
                // 스프링이 목표를 살짝 넘을 때는 전체가 아주 조금 커졌다 돌아온다
                val over = 1f + (m - 1f).coerceIn(0f, 0.25f) * 0.4f
                val px = cx
                val py = top + ch / 2
                canvas.save()
                canvas.rotate(sysDragTilt, w / 2f, h.toFloat())
                canvas.scale(over, over, px, py)
                // 그림자: 틀이 커지는 만큼 같이 커진다
                shadowPaint.setShadowLayer(dp(14) * (0.4f + 0.6f * t), 0f, dp(6) * (0.4f + 0.6f * t), (0x55 * (0.5f + 0.5f * t)).toInt() shl 24)
                canvas.drawRoundRect(clipRect, radius.toFloat(), radius.toFloat(), shadowPaint)
                canvas.clipPath(clipPath)
                // 카드 내용: 윗줄(파비콘+제목)은 처음부터 보이고, 미리보기·안내는 틀이 커지면서 드러난다
                canvas.save()
                card.draw(canvas)
                canvas.restore()
                canvas.restore()
            }
        }
        sysDragSource = this
        sysDragTarget = null
        // GLOBAL 이 없으면 시스템이 드래그 이벤트를 출발한 창에게만 주어서, 다른 창의 탭 줄은 아무것도 받지 못한다.
        // 그래서 다른 창이 떠 있을 때만 GLOBAL 을 켠다. (창이 하나뿐이면 예전처럼 켜지 않아,
        // 런처·멀티태스킹 UI 가 화면 가장자리에서 끼어들지 않는다)
        val hasOtherWindow = instances.any { it !== this && !it.isFinishing && !it.isDestroyed }
        val dragFlags = if (hasOtherWindow) View.DRAG_FLAG_OPAQUE or View.DRAG_FLAG_GLOBAL else View.DRAG_FLAG_OPAQUE
        val started = try {
            c.view.startDragAndDrop(
                stripDragClip(url),
                shadow,
                null,
                dragFlags
            )
        } catch (e: Throwable) {
            false
        }
        if (!started) {
            root.removeView(overlay)
            sysDragOverlay = null
            sysDragActive = false
            if (sysDragSource === this) sysDragSource = null
            return false
        }
        sysDragShadow = shadow
        sysDragViewRef = c.view
        if (animate) {
            sysDragMorph?.cancel()
            // 고정 시간 대신 스프링: 손가락으로 집어 올리는 것처럼 살짝 넘쳤다가 자리를 잡는다
            sysDragMorph = SpringAnimation(FloatValueHolder(0f)).apply {
                spring = SpringForce(1f).apply {
                    stiffness = 260f
                    dampingRatio = 0.58f
                }
                setStartVelocity(2.2f)
                setMinimumVisibleChange(0.002f)
                addUpdateListener { _, value, _ ->
                    sysDragMorphValue = value
                    updateSysDragShadow(c.view)
                }
                start()
            }
        }
        tabStripScroll.removeCallbacks(stripAutoScroll)
        return true
    }

    /**
     * 탭 끌기용 클립. 주소를 글자(text/plain)로 실어 보내면 삼성 분할 화면 UI 가 '링크'로 보고
     * 기본 브라우저(삼성 인터넷)로 열어 버린다 (새 탭 화면은 "새 탭" 글자가 그대로 열렸다).
     * 그래서 글자는 싣지 않고, 이 앱(MainActivity)을 새 창으로 여는 명시적 인텐트만 싣는다.
     * 라벨 "evergreen-tab" 은 다른 창의 탭 줄이 우리 드래그인지 알아볼 때 쓴다.
     */
    private fun stripDragClip(url: String): ClipData {
        val web = url.startsWith("http://") || url.startsWith("https://")
        val launch = Intent(this, MainActivity::class.java).apply {
            if (web) {
                action = Intent.ACTION_VIEW
                data = Uri.parse(url)
            }
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                    Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
            )
        }
        return ClipData(
            android.content.ClipDescription("evergreen-tab", arrayOf(android.content.ClipDescription.MIMETYPE_TEXT_INTENT)),
            ClipData.Item(launch)
        )
    }

    private fun onStripSysDrag(v: View, e: DragEvent): Boolean {
        if (!sysDragActive) return false
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED, DragEvent.ACTION_DRAG_ENTERED -> return true
            DragEvent.ACTION_DRAG_LOCATION -> {
                trackSysDrag(v, e)
                return true
            }
            DragEvent.ACTION_DRAG_EXITED -> {
                // 이 창 밖으로 나가면 (다른 앱/화면 위) 놓았을 때 팝업이다
                sysDragZone = TabDropOverlay.ZONE_POPUP
                sysDragOverlay?.setZone(TabDropOverlay.ZONE_POPUP)
                updateAddressDropHighlight()
                return true
            }
            DragEvent.ACTION_DROP -> {
                trackSysDrag(v, e)
                sysDropHandled = true
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                // 이 창에서 놓았으면 그 구역대로 / 다른 앱이 받아 갔으면 그대로 두고 / 아무도 안 받았으면 팝업
                val zone = when {
                    sysDropHandled -> sysDragZone
                    e.result -> TabDropOverlay.ZONE_NONE
                    else -> TabDropOverlay.ZONE_POPUP
                }
                val x = sysDragX
                val y = sysDragY
                val tgt = sysDragTarget
                sysDragTarget = null
                // 이벤트를 나눠 주는 도중에는 뷰를 떼지 않는다
                window.decorView.post { endStripSysDrag(zone, x, y, tgt) }
                return true
            }
        }
        return false
    }

    /** 놓을 곳 추적: 시스템 화면 좌표로 바꿔 어느 구역인지 정한다 */
    private fun trackSysDrag(v: View, e: DragEvent) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val sx = loc[0] + e.x.toInt()
        val sy = loc[1] + e.y.toInt()
        // 움직인 방향으로 카드가 살짝 기울고, 멈추면 천천히 바로 선다
        if (Motion.enabled(this)) {
            val dx = if (sysDragLastX == Int.MIN_VALUE) 0 else sx - sysDragLastX
            val target = (dx * 0.6f).coerceIn(-5f, 5f)
            val next = sysDragTilt * 0.8f + target * 0.2f
            if (Math.abs(next - sysDragTilt) > 0.05f || Math.abs(next) > 0.05f) {
                sysDragTilt = next
                if (sysDragMorph?.isRunning != true) sysDragViewRef?.let { updateSysDragShadow(it) }
            }
        }
        sysDragLastX = sx
        sysDragX = sx
        sysDragY = sy
        val z = sysZoneAt(sx, sy)
        if (z != sysDragZone) {
            sysDragZone = z
            sysDragOverlay?.setZone(z)
            updateAddressDropHighlight()
            v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    /** 탭을 주소창 위로 끌어 왔을 때 주소창이 살짝 흐려져 \"여기에 놓으면 된다\"고 알려 준다 */
    private fun updateAddressDropHighlight() {
        val on = sysDragActive && sysDragZone == TabDropOverlay.ZONE_ADDRESS
        val v = (urlBar.parent as? View) ?: urlBar
        v.animate().alpha(if (on) 0.55f else 1f).setDuration(120).start()
    }

    /** 탭을 주소창에 놓았다: 지금 보는 탭을 그 탭의 주소로 열고, 끌어 온 탭은 닫는다 (주소를 옮겨 온 셈) */
    private fun dropTabOnAddressBar(tab: BrowserTab) {
        if (tab === current) return
        val url = tabBookmarkUrl(tab)
        if (url == null) {
            toast("이 탭은 열 주소가 없어요")
            return
        }
        loadFromInput(url)
        closeTab(tab)
    }

    /** 다른 창의 주소창에 놓았다: 그 창의 현재 탭을 이 탭의 주소로 열고, 끌어 온 탭은 닫는다 (창에 탭이 하나뿐이면 창도 닫힌다) */
    private fun dropTabOnOtherAddressBar(tab: BrowserTab, target: MainActivity) {
        if (target.isFinishing || target.isDestroyed) return
        val url = tabBookmarkUrl(tab)
        if (url == null) {
            toast("이 탭은 열 주소가 없어요")
            return
        }
        val closeWindow = tabs.size == 1
        target.loadFromInput(url)
        closeTab(tab, quitIfLast = closeWindow)
        scheduleStripRefresh()
    }

    /** 다른 창에서 끌고 온 탭을 이 창의 주소창이 받는다. 우리 탭 끌기가 아니면 false 를 돌려 기본 동작(글자 붙여넣기)을 그대로 둔다 */
    private fun onAddressReceiveDrag(v: View, e: DragEvent): Boolean {
        val src = sysDragSource
        val mine = src != null && src !== this && !isFinishing && !isDestroyed &&
            e.clipDescription?.label?.toString() == "evergreen-tab"
        if (!mine) return false
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED, DragEvent.ACTION_DRAG_LOCATION -> return true
            DragEvent.ACTION_DRAG_ENTERED -> {
                (v.parent as? View ?: v).animate().alpha(0.55f).setDuration(120).start()
                v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                return true
            }
            DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                (v.parent as? View ?: v).animate().alpha(1f).setDuration(120).start()
                return true
            }
            DragEvent.ACTION_DROP -> {
                (v.parent as? View ?: v).animate().alpha(1f).setDuration(120).start()
                src!!.sysDragTarget = this
                src.sysDragAddrTarget = true
                return true
            }
        }
        return false
    }

    /** 탭 줄 위: 취소(제자리) / 그 밖: 팝업 */
    private fun sysZoneAt(sx: Int, sy: Int): Int {
        // 주소창 위에 있으면 (탭 줄 여유 범위와 겹쳐도) 주소창이 우선
        if (urlBar.isShown) {
            val ul = IntArray(2)
            urlBar.getLocationOnScreen(ul)
            val um = dp(6)
            if (sx >= ul[0] - um && sx <= ul[0] + urlBar.width + um &&
                sy >= ul[1] - um && sy <= ul[1] + urlBar.height + um) {
                return TabDropOverlay.ZONE_ADDRESS
            }
        }
        val sl = IntArray(2)
        tabStripScroll.getLocationOnScreen(sl)
        val m = dp(20)
        if (tabStripScroll.isShown && sy >= sl[1] - m && sy <= sl[1] + tabStripScroll.height + m) {
            return TabDropOverlay.ZONE_NONE
        }
        return TabDropOverlay.ZONE_POPUP
    }

    private fun endStripSysDrag(zone: Int, x: Int, y: Int, target: MainActivity? = null) {
        if (!sysDragActive) return
        sysDragActive = false
        sysDragMorph?.cancel()
        sysDragMorph = null
        sysDragShadow = null
        sysDragViewRef = null
        sysDragLastX = Int.MIN_VALUE
        if (sysDragSource === this) sysDragSource = null
        sysDropHandled = false
        val toAddress = sysDragAddrTarget
        sysDragAddrTarget = false
        sysDragOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        sysDragOverlay = null
        updateAddressDropHighlight()
        val c = stripDrag
        stripDrag = null
        stripDetached = false
        stripCanDetach = false
        tabStripScroll.removeCallbacks(stripAutoScroll)
        if (c != null) {
            val v = c.view
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
            v.animate().translationX(0f).setDuration(160).setInterpolator(stripEase)
                .withEndAction {
                    v.translationZ = 0f
                    if (stripDrag == null) setStripUnclipped(false)
                }.start()
            applyChipSelection(c)
        }
        if (stripSwapped) saveTabs()
        scheduleStripRefresh()
        if (c == null) return
        // 주소창에 놓았으면 지금 보는 탭이 그 탭의 주소로 바뀐다
        if (zone == TabDropOverlay.ZONE_ADDRESS && target == null) {
            dropTabOnAddressBar(c.tab)
            return
        }
        // 다른 창의 탭 줄에 놓았으면 그 창으로 옮긴다 (옮긴 탭은 그 창에서 바로 열린다)
        if (target != null) {
            if (toAddress) {
                dropTabOnOtherAddressBar(c.tab, target)
            } else if (moveTabToWindow(c.tab, target, selectInTarget = true)) scheduleStripRefresh()
            return
        }
        if (zone == TabDropOverlay.ZONE_NONE) return
        if (moveTabToWindow(c.tab, null, WIN_POPUP, x, y, closeEmptyWindow = true)) scheduleStripRefresh()
    }

    /** 다른 창에서 끌고 온 탭을 이 창의 탭 줄이 받는다 */
    private fun onStripReceiveDrag(v: View, e: DragEvent): Boolean {
        val src = sysDragSource
        val mine = src != null && src !== this && !isFinishing && !isDestroyed &&
            e.clipDescription?.label?.toString() == "evergreen-tab"
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED, DragEvent.ACTION_DRAG_LOCATION -> return mine
            DragEvent.ACTION_DRAG_ENTERED -> {
                if (mine) {
                    v.animate().alpha(0.7f).setDuration(120).start()
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                }
                return mine
            }
            DragEvent.ACTION_DRAG_EXITED -> {
                v.animate().alpha(1f).setDuration(120).start()
                return mine
            }
            DragEvent.ACTION_DROP -> {
                v.animate().alpha(1f).setDuration(120).start()
                if (!mine || src == null) return false
                src.sysDragTarget = this
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                v.animate().alpha(1f).setDuration(120).start()
                return true
            }
        }
        return false
    }

    // ── 다른 앱에서 끌어온 파일 → 새 탭 ──

    private var extDropOverlay: TabDropOverlay? = null
    /** 끌어 놓은 파일을 읽을 권한. 탭에서 파일을 읽는 동안(창이 닫힐 때까지) 붙들어 둔다 */
    private val extDropPerms = ArrayList<androidx.core.view.DragAndDropPermissionsCompat>()

    /**
     * 다른 앱이 끌고 온 '파일'인지. 시작할 때는 형식(MIME)만 보이므로, 일반 글자·링크(text/plain, text/html)와
     * 앱 실행용 드래그만 있는 경우는 제외한다. (이 창이 막으로 덮이면 웹페이지 입력칸에 글자를 끌어다 놓는 것이 안 되기 때문)
     */
    private fun acceptsExternalDrop(e: DragEvent): Boolean {
        if (sysDragActive) return false
        val d = e.clipDescription ?: return false
        if (d.label?.toString() == "evergreen-tab") return false
        for (i in 0 until d.mimeTypeCount) {
            val m = d.getMimeType(i).lowercase()
            if (m == "text/plain" || m == "text/html" || m == "text/uri-list" ||
                m.startsWith("text/vnd.android") || m.startsWith("application/vnd.android.")) continue
            return true
        }
        return false
    }

    private fun onExternalDragRoot(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                if (!acceptsExternalDrop(e)) return false
                showExtDropOverlay()
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                window.decorView.post { hideExtDropOverlay() }
                return false
            }
        }
        return false
    }

    /** 웹뷰가 드롭을 가로채지 못하게, 끌고 오는 동안만 창 전체에 투명한 막을 얹는다 */
    private fun showExtDropOverlay() {
        if (extDropOverlay != null || isFinishing || isDestroyed) return
        val ov = TabDropOverlay(this)
        ov.setOnDragListener { _, e -> onExternalFileDrag(e) }
        (window.decorView as ViewGroup).addView(
            ov, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        extDropOverlay = ov
    }

    private fun hideExtDropOverlay() {
        val ov = extDropOverlay ?: return
        extDropOverlay = null
        (ov.parent as? ViewGroup)?.removeView(ov)
    }

    private fun onExternalFileDrag(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED, DragEvent.ACTION_DRAG_ENTERED,
            DragEvent.ACTION_DRAG_LOCATION, DragEvent.ACTION_DRAG_EXITED -> return true
            DragEvent.ACTION_DROP -> {
                val cd = e.clipData ?: return false
                val uris = ArrayList<Pair<Uri, String?>>()
                for (i in 0 until cd.itemCount) {
                    val u = cd.getItemAt(i).uri ?: continue
                    val hint = if (i < cd.description.mimeTypeCount) cd.description.getMimeType(i) else null
                    uris.add(u to hint)
                }
                if (uris.isEmpty()) return false
                // 다른 앱의 파일을 읽으려면 놓는 순간에 권한을 받아 둬야 한다
                try {
                    androidx.core.app.ActivityCompat.requestDragAndDropPermissions(this, e)?.let { extDropPerms.add(it) }
                } catch (_: Throwable) {
                }
                attachDropped(uris.take(10), e.x, e.y)
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                window.decorView.post { hideExtDropOverlay() }
                return true
            }
        }
        return false
    }

    // ── 끌어 온 파일을 웹페이지의 파일 첨부 칸에 넣기 ──

    private class DropFile(val uri: Uri, val name: String, val mime: String, val size: Long)

    /** 이번에 끌어 온 파일들 (임의의 id → 파일). 페이지 스크립트가 id 로만 읽을 수 있고, 처리가 끝나면 지운다 */
    private val dropFiles = java.util.concurrent.ConcurrentHashMap<String, DropFile>()

    /** 페이지 스크립트가 끌어 온 파일 내용을 조각(base64)으로 읽어 가는 통로 */
    private inner class DropJs {
        @JavascriptInterface
        fun read(id: String, offset: Double, length: Int): String {
            val f = dropFiles[id] ?: return ""
            return try {
                contentResolver.openFileDescriptor(f.uri, "r")?.use { pfd ->
                    java.io.FileInputStream(pfd.fileDescriptor).use { ins ->
                        ins.channel.position(offset.toLong())
                        val buf = ByteArray(length)
                        var n = 0
                        while (n < length) {
                            val r = ins.read(buf, n, length - n)
                            if (r < 0) break
                            n += r
                        }
                        android.util.Base64.encodeToString(buf, 0, n, android.util.Base64.NO_WRAP)
                    }
                } ?: ""
            } catch (_: Throwable) { "" }
        }
    }

    /**
     * 웹페이지 위에 놓은 파일을 그 페이지에 첨부한다.
     * 놓은 자리에 끌어놓기 칸이 있으면 거기에 '놓기' 를 보내고, 아니면 파일 선택 칸(<input type=file>)에 직접 넣는다.
     * 페이지에 첨부할 곳이 없거나 웹페이지 밖에 놓았으면 예전처럼 새 탭으로 연다.
     */
    private fun attachDropped(list: List<Pair<Uri, String?>>, ex: Float, ey: Float) {
        fun fallback() { list.forEach { (u, h) -> openDroppedFile(u, h) } }
        val tab = current
        val wv = tab?.webView
        val ov = extDropOverlay
        if (tab == null || wv == null || ov == null || tab.isHome || list.any { it.first.scheme?.lowercase() != "content" }) {
            fallback(); return
        }
        // 놓은 자리를 웹뷰 안 좌표로
        val ol = IntArray(2); val wl = IntArray(2)
        ov.getLocationInWindow(ol); wv.getLocationInWindow(wl)
        val x = ex + ol[0] - wl[0]
        val y = ey + ol[1] - wl[1]
        if (x < 0 || y < 0 || x > wv.width || y > wv.height) { fallback(); return }

        val maxBytes = 50L * 1024 * 1024
        val files = ArrayList<DropFile>()
        for ((u, hint) in list) {
            val name = queryFileName(u) ?: u.lastPathSegment ?: "file"
            val size = try { contentResolver.openFileDescriptor(u, "r")?.use { it.statSize } ?: -1L } catch (_: Throwable) { -1L }
            if (size < 0 || size > maxBytes) { toast("파일이 너무 커서 첨부할 수 없어요 (최대 50MB): $name"); fallback(); return }
            val typeRaw: String? = try { contentResolver.getType(u) } catch (_: Throwable) { null }
            val given = (typeRaw ?: hint)?.lowercase()
            val mime = if (given.isNullOrBlank() || given == "*/*") {
                android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
                    ?: "application/octet-stream"
            } else given
            files.add(DropFile(u, name, mime, size))
        }
        val ids = files.map { java.util.UUID.randomUUID().toString() }
        files.forEachIndexed { i, f -> dropFiles[ids[i]] = f }

        val items = org.json.JSONArray()
        files.forEachIndexed { i, f ->
            items.put(org.json.JSONObject().put("id", ids[i]).put("name", f.name).put("type", f.mime).put("size", f.size))
        }
        val js = DROP_JS.replace("__ITEMS__", items.toString()).replace("__X__", x.toString()).replace("__Y__", y.toString())
        wv.evaluateJavascript(js) { r ->
            ids.forEach { dropFiles.remove(it) }
            if (r?.trim('"') == "ok") toast(if (files.size == 1) "파일을 첨부했어요: ${files[0].name}" else "파일 ${files.size}개를 첨부했어요")
            else fallback()
        }
    }

    /** 끌어 온 파일 하나를 새 탭으로 연다. 웹뷰가 보여 줄 수 있는 형식만 연다 */
    private fun openDroppedFile(uri: Uri, hint: String?) {
        val s = uri.toString()
        val sc = uri.scheme?.lowercase()
        if (sc == "http" || sc == "https") { createTab(s); return }
        if (sc != "content") return
        val name = queryFileName(uri) ?: uri.lastPathSegment ?: "파일"
        localFileNames[s] = name
        val typeRaw: String? = try { contentResolver.getType(uri) } catch (_: Throwable) { null }
        val given = (typeRaw ?: hint)?.lowercase()
        val mime: String = if (given.isNullOrBlank() || given == "application/octet-stream" || given == "*/*") {
            val ext = name.substringAfterLast('.', "").lowercase()
            android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        } else given
        when {
            mime == "text/html" || mime == "application/xhtml+xml" -> createTab(s)
            mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/") -> {
                // 웹뷰가 content:// 주소를 직접 불러와 그림·영상·소리로 보여 준다
                val tab = createTab(null)
                tab.webView.loadUrl(s)
            }
            mime.startsWith("text/") || mime == "application/json" || mime == "application/xml" ||
                mime == "application/javascript" -> {
                val tab = createTab(null)
                loadLocalHtml(tab, s, "text/plain")
            }
            else -> toast("이 형식은 탭으로 열 수 없어요: $name")
        }
    }

    // ── 탭 화면 (카드 격자) ──

    private class SwitcherDrag(
        val tab: BrowserTab,
        val view: View,
        val scope: List<BrowserTab>,
        val from: Int,
        val slots: List<Rect>,   // 스크롤 내용 기준 좌표의 각 카드 자리
        val grabX: Float,        // 카드 왼쪽 위 모서리에서 손가락까지의 거리
        val grabY: Float,
        val boxes: Map<Int, Rect>  // 이 탭을 넣을 수 있는 그룹 상자들의 자리
    ) {
        var targetGroup = 0
        var to = from
        /** 손가락이 올라가 있는 창 칩 (null 이면 없음) / 그 칩이 가리키는 창 (null 이면 "＋ 새 창") */
        var winChip: View? = null
        var winTarget: MainActivity? = null
        var rawX = 0f
        var rawY = 0f
    }

    private var swDrag: SwitcherDrag? = null

    private val swAutoScroll = object : Runnable {
        override fun run() {
            val d = swDrag ?: return
            val loc = IntArray(2)
            tabScroll.getLocationOnScreen(loc)
            val top = loc[1]
            val bottom = top + tabScroll.height
            val edge = dp(80).toFloat()
            val dy = when {
                d.rawY < top + edge -> -(top + edge - d.rawY) / edge * dp(18)
                d.rawY > bottom - edge -> (d.rawY - (bottom - edge)) / edge * dp(18)
                else -> 0f
            }
            if (dy != 0f) {
                val step = if (dy > 0) maxOf(1, dy.toInt()) else minOf(-1, dy.toInt())
                val before = tabScroll.scrollY
                tabScroll.scrollBy(0, step)
                if (tabScroll.scrollY != before) updateSwitcherDrag()
            }
            tabScroll.postOnAnimation(this)
        }
    }

    /** 끄는 카드가 이웃 줄·상자 위에 그려지도록 위로 띄운다 */
    private fun liftCard(v: View, lift: Boolean) {
        v.translationZ = if (lift) dp(10).toFloat() else 0f
        var p = v.parent
        while (p is ViewGroup && p !== tabScroll) {
            // 카드 줄과 목록은 평소에도 잘라내기를 끈 상태로 둔다
            p.clipChildren = if (lift) false else !(p === tabList || p.tag == CARD_ROW_TAG)
            if (p !== tabList) {
                // 그룹 상자(배경 있음)는 둥근 모서리 클립을 잠깐 풀어 카드가 상자 밖으로 나갈 수 있게 한다
                if (p.background != null) p.clipToOutline = !lift
                p.translationZ = if (lift) dp(10).toFloat() else 0f
            }
            p = p.parent
        }
        // 스크롤 뷰도 자식(tabList)의 영역 밖은 잘라 버리므로 같이 풀어 준다 (안 그러면 카드가 첫 줄 아래에서 잘린다)
        tabScroll.clipChildren = false
    }

    /** 스크롤 내용 기준 좌표에서의 뷰 자리 */
    private fun contentRect(v: View): Rect {
        var x = 0
        var y = 0
        var c: View = v
        while (c !== tabScroll) {
            x += c.left
            y += c.top
            c = c.parent as? View ?: break
        }
        return Rect(x, y, x + v.width, y + v.height)
    }

    private fun setBoxHighlight(groupId: Int, on: Boolean) {
        if (groupId == 0) return
        val s = if (on) 1.03f else 1f
        switcherBoxes[groupId]?.animate()?.scaleX(s)?.scaleY(s)?.setDuration(140)?.start()
    }

    private fun startSwitcherDrag(tab: BrowserTab, rawX: Float, rawY: Float): Boolean {
        if (switcherBusy || groupToggling || swDrag != null) return false
        val g = groupOf(tab)
        // 같은 그룹 안에서, 또는 그룹에 속하지 않은 탭끼리 순서를 바꾼다
        val scope = tabs.filter { groupOf(it)?.id == g?.id && switcherRows.containsKey(it) }
        val from = scope.indexOf(tab)
        val view = switcherRows[tab]
        if (from < 0 || view == null) return false
        val slots = scope.map { t -> contentRect(switcherRows[t]!!) }
        // 시크릿 탭은 그룹에 넣을 수 없다. 자기 그룹 상자는 제외.
        val boxes = if (tab.incognito) emptyMap() else
            switcherBoxes.filter { it.key != tab.groupId }.mapValues { contentRect(it.value) }
        val loc = IntArray(2)
        tabScroll.getLocationOnScreen(loc)
        val fx = rawX - loc[0]
        val fy = rawY - loc[1] + tabScroll.scrollY
        val s = slots[from]
        swDrag = SwitcherDrag(tab, view, scope, from, slots, fx - s.left, fy - s.top, boxes).also {
            it.rawX = rawX
            it.rawY = rawY
        }
        liftCard(view, true)
        Motion.spring(view, DynamicAnimation.SCALE_X, 1.06f, 600f, 0.7f)
        Motion.spring(view, DynamicAnimation.SCALE_Y, 1.06f, 600f, 0.7f)
        tabScroll.postOnAnimation(swAutoScroll)
        return true
    }

    private fun updateSwitcherDrag() {
        val d = swDrag ?: return
        if (switcherRows[d.tab] !== d.view || d.view.parent == null) {
            swDrag = null
            return
        }
        val loc = IntArray(2)
        tabScroll.getLocationOnScreen(loc)
        val fx = d.rawX - loc[0]
        val fy = d.rawY - loc[1] + tabScroll.scrollY
        val s = d.slots[d.from]
        val left = fx - d.grabX
        val top = fy - d.grabY
        d.view.translationX = left - s.left
        d.view.translationY = top - s.top
        val cx = (left + s.width() / 2f).toInt()
        val cy = (top + s.height() / 2f).toInt()
        // 손가락이 창 칩 위에 있으면 '그 창으로 옮기기' 대상이 된다 (칩이 커지며 강조)
        val hit = windowChipAt(d.rawX, d.rawY)
        if (hit?.first !== d.winChip) {
            if ((hit == null) != (d.winChip == null)) {
                val k = if (hit != null) 0.62f else 1.06f
                Motion.spring(d.view, DynamicAnimation.SCALE_X, k, 520f, 0.65f)
                Motion.spring(d.view, DynamicAnimation.SCALE_Y, k, 520f, 0.65f)
                Motion.spring(d.view, DynamicAnimation.ALPHA, if (hit != null) 0.85f else 1f, 400f, 1f)
            }
            d.winChip?.let { setWinHighlight(it, false) }
            d.winChip = hit?.first
            d.winTarget = hit?.second
            if (hit != null) {
                setWinHighlight(hit.first, true)
                hit.first.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                setBoxHighlight(d.targetGroup, false)
                d.targetGroup = 0
                if (d.to != d.from) {
                    d.to = d.from
                    previewSwitcherOrder(d)
                }
            }
        }
        if (d.winChip != null) return
        // 다른 그룹 상자 위로 가져가면 '그룹에 넣기' 대상이 되어 상자가 커지며 강조된다
        val gid = d.boxes.entries.firstOrNull { it.value.contains(cx, cy) }?.key ?: 0
        if (gid != d.targetGroup) {
            setBoxHighlight(d.targetGroup, false)
            d.targetGroup = gid
            setBoxHighlight(gid, true)
            if (gid != 0 && d.to != d.from) {
                d.to = d.from
                previewSwitcherOrder(d)
            }
        }
        if (gid != 0) return
        val j = d.slots.indexOfFirst { it.contains(cx, cy) }
        if (j >= 0 && j != d.to) {
            d.to = j
            previewSwitcherOrder(d)
        }
    }

    private fun switcherOrder(d: SwitcherDrag): List<BrowserTab> =
        d.scope.toMutableList().also { it.add(d.to, it.removeAt(d.from)) }

    /** 놓으면 이렇게 된다는 걸 미리 보여 주기: 나머지 카드들이 새 자리로 비켜 준다 */
    private fun previewSwitcherOrder(d: SwitcherDrag) {
        val order = switcherOrder(d)
        d.scope.forEachIndexed { k, t ->
            if (k == d.from) return@forEachIndexed
            val a = d.slots[k]
            val b = d.slots[order.indexOf(t)]
            switcherRows[t]?.animate()
                ?.translationX((b.left - a.left).toFloat())
                ?.translationY((b.top - a.top).toFloat())
                ?.setDuration(180)?.start()
        }
    }

    private fun endSwitcherDrag(moved: Boolean, canceled: Boolean) {
        val d = swDrag ?: return
        swDrag = null
        tabScroll.removeCallbacks(swAutoScroll)
        val v = d.view
        setBoxHighlight(d.targetGroup, false)
        val wc = d.winChip
        wc?.let { setWinHighlight(it, false) }
        if (!canceled && wc != null && switcherRows[d.tab] === v && v.parent != null) {
            // 카드가 지금 있는 자리와 칩의 중심 (옮기고 나면 칩이 다시 그려질 수 있어 미리 잰다)
            val cl = IntArray(2)
            val chl = IntArray(2)
            v.getLocationOnScreen(cl)
            wc.getLocationOnScreen(chl)
            val dx = (chl[0] + wc.width / 2f) - (cl[0] + v.width * v.scaleX / 2f)
            val dy = (chl[1] + wc.height / 2f) - (cl[1] + v.height * v.scaleY / 2f)
            if (moveTabToWindow(d.tab, d.winTarget)) {
                // 나머지 카드는 제자리로, 끌던 카드는 칩 쪽으로 빨려 들어가며 작아지고 사라진다
                d.scope.forEach { t -> if (t !== d.tab) switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(160)?.start() }
                Motion.cancel(v)
                Motion.spring(v, DynamicAnimation.TRANSLATION_X, v.translationX + dx, 420f, 0.9f)
                Motion.spring(v, DynamicAnimation.TRANSLATION_Y, v.translationY + dy, 420f, 0.9f)
                Motion.spring(v, DynamicAnimation.SCALE_X, 0.08f, 380f, 1f)
                Motion.spring(v, DynamicAnimation.SCALE_Y, 0.08f, 380f, 1f)
                v.animate().alpha(0f).setStartDelay(120).setDuration(160).start()
                // 도착하면 칩이 톡 튀며 받았다고 알려 준다
                ui.postDelayed({ if (wc.isAttachedToWindow) Motion.pop(wc, 0.88f) }, 200)
                ui.postDelayed({
                    if (switcherOpen) {
                        liftCard(v, false)
                        refreshSwitcher(false)
                    }
                }, 330)
                return
            }
        }
        if (!canceled && d.targetGroup != 0 && switcherRows[d.tab] === v && v.parent != null) {
            val g = groups.firstOrNull { it.id == d.targetGroup }
            if (g != null) {
                moveToGroup(d.tab, g)
                saveTabs()
                d.scope.forEach { t -> if (t !== d.tab) switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(120)?.start() }
                v.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setDuration(140).start()
                ui.postDelayed({
                    if (switcherOpen) {
                        liftCard(v, false)
                        refreshSwitcher(false)
                    }
                }, 150)
                return
            }
        }
        Motion.spring(v, DynamicAnimation.SCALE_X, 1f, 480f, 0.6f)
        Motion.spring(v, DynamicAnimation.SCALE_Y, 1f, 480f, 0.6f)
        val live = switcherRows[d.tab] === v && v.parent != null
        if (canceled || !live || d.to == d.from) {
            d.scope.forEach { t ->
                switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(180)?.start()
            }
            v.postDelayed({ liftCard(v, false) }, 220)
            // 끌지 않고 그냥 뗐으면 예전처럼 탭 메뉴
            if (!canceled && live && !moved) showTabMenu(d.tab) { refreshSwitcher(false) }
            return
        }
        // 새 순서를 저장: 이 범위의 탭들이 차지하던 자리에 새 순서대로 다시 넣는다 (다른 탭·그룹은 그대로)
        val order = switcherOrder(d)
        val idx = tabs.indices.filter { tabs[it] in d.scope }
        idx.forEachIndexed { n, i -> tabs[i] = order[n] }
        saveTabs()
        val a = d.slots[d.from]
        val b = d.slots[d.to]
        v.animate().translationX((b.left - a.left).toFloat()).translationY((b.top - a.top).toFloat())
            .setDuration(180).start()
        ui.postDelayed({
            if (switcherOpen) {
                liftCard(v, false)
                refreshSwitcher(false)
            }
        }, 200)
    }

    /** anchor 가 있으면(상단 탭 줄) 그 탭 바로 아래에 붙여 띄우고, 없으면 화면 가운데 팝업 */
    private fun showTabMenu(tab: BrowserTab, anchor: View? = null, onChanged: () -> Unit) {
        val items = mutableListOf<Popup.Item>()
        val own = groupOf(tab)

        // 탭 음소거: 꾹 누른 그 탭의 소리만 끄고 켠다 (다른 탭에서 계속 재생되는 탭도 포함)
        items.add(
            Popup.Item(
                if (tab.muted) R.drawable.ic_volume_up else R.drawable.ic_volume_off,
                if (tab.muted) "탭 음소거 해제" else "탭 음소거",
                if (tab.muted) "이 탭의 소리를 다시 켭니다" else "이 탭의 소리를 끕니다"
            ) {
                setTabMuted(tab, !tab.muted)
                onChanged()
            }
        )

        // 꾹 누른 그 탭의 페이지를 북마크에 추가(이미 있으면 수정). 현재 보는 탭이 아니어도 된다.
        tabBookmarkUrl(tab)?.let { url ->
            val saved = prefs.findBookmark(url)
            val title = tab.liveWebView?.title?.takeIf { it.isNotBlank() } ?: tab.pendingTitle.orEmpty()
            items.add(
                Popup.Item(
                    if (saved != null) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border,
                    if (saved != null) "북마크 수정" else "북마크에 추가",
                    Uri.parse(url).host?.removePrefix("www.")
                ) {
                    ListUi.showBookmarkEditor(this, prefs, saved, url, title) { msg -> toast(msg) }
                }
            )
        }
        // 크롬의 "탭을 다른 창으로 이동": 열려 있는 다른 창이 있을 때만 보이고, 어느 창으로 갈지 고른다 (새 창도 고를 수 있다).
        // 다른 창이 하나도 없으면 이 메뉴는 아예 보이지 않는다 (새 창으로 빼기는 탭을 끌어내는 동작으로)
        // 탭은 이 창에서 닫히고, 웹 기록·확대 비율·스크롤 위치가 그대로 따라간다 (시크릿 탭은 일반 새 창으로 새지 않게 제외)
        val otherWindows = instances.filter { it !== this && !it.isFinishing && !it.isDestroyed }
        val canNewWindow = !tab.incognito
        if (otherWindows.isNotEmpty()) {
            items.add(Popup.Item(R.drawable.ic_tab, "탭을 다른 창으로 이동", "이 탭을 지금 상태 그대로 다른 창으로 옮깁니다") {
                // 다른 창이 딱 하나면 고르는 창 없이 바로 그 창으로 옮긴다
                if (otherWindows.size == 1) {
                    if (moveTabToWindow(tab, otherWindows[0])) onChanged()
                } else {
                    showMoveTabChooser(tab, otherWindows, false, onChanged)
                }
            })
        }
        // 새 창으로 이동은 따로 둔다. 이 창에는 새 탭이 남는다 (마지막 탭이었다면 홈 탭으로 바뀐다)
        if (canNewWindow) {
            items.add(Popup.Item(R.drawable.ic_window_new, "탭을 새 창으로 이동", "이 탭을 지금 상태 그대로 새 창으로 옮깁니다") {
                if (moveTabToWindow(tab, null)) onChanged()
            })
        }
        // 탭 위치는 메뉴가 아니라 탭을 길게 누른 채 끌어서 바꾼다
        items.add(Popup.Item(R.drawable.ic_add, "새 그룹 만들기", "이 탭을 새 그룹에 담습니다") {
            showGroupEditor(null) { name, color ->
                val g = createGroup(name, color)
                moveToGroup(tab, g)
                onChanged()
            }
        })
        groups.filter { it.id != tab.groupId }.forEach { g ->
            val n = tabs.count { it.groupId == g.id }
            items.add(Popup.Item(R.drawable.ic_tab, "'${g.name}' 그룹에 추가", "탭 ${n}개", dotColor = g.color) {
                moveToGroup(tab, g)
                onChanged()
            })
        }
        if (own != null) {
            items.add(Popup.Item(R.drawable.ic_close, "'${own.name}' 그룹에서 빼기", "탭은 그대로 남습니다") {
                moveToGroup(tab, null)
                onChanged()
            })
        }

        val subtitle = (if (own != null) "그룹: ${own.name}" else "그룹에 속해 있지 않음") +
            if (tab.muted) " · 음소거 중" else ""
        if (anchor != null && anchor.isAttachedToWindow) {
            Popup.menuAnchored(
                this, anchor,
                title = tabTitle(tab),
                subtitle = subtitle,
                headerIcon = R.drawable.ic_tab,
                headerColor = own?.color,
                items = items
            )
        } else {
            Popup.menu(
                this,
                title = tabTitle(tab),
                subtitle = subtitle,
                headerColor = own?.color,
                headerIcon = R.drawable.ic_tab,
                items = items
            )
        }
    }

    /** 탭을 음소거하거나 해제한다. 보고 있지 않은 탭, 화면 뒤에 붙여 둔 탭, iframe 안의 영상까지 모두 적용된다 */
    private fun setTabMuted(tab: BrowserTab, mute: Boolean) {
        tab.muted = mute
        tab.liveWebView?.evaluateJavascript(MediaScripts.MUTE_SYNC, null)
        toast(if (mute) "탭을 음소거했어요" else "탭 음소거를 해제했어요")
    }

    private fun showGroupMenu(group: TabGroup, inSwitcher: Boolean, onChanged: () -> Unit) {
        val n = tabs.count { it.groupId == group.id }
        val items = listOf(
            Popup.Item(R.drawable.ic_add, "이 그룹에 새 탭") {
                openNewTabAndFocus(tabs.lastOrNull { it.groupId == group.id })
                if (inSwitcher) closeTabSwitcher()
            },
            Popup.Item(
                R.drawable.ic_expand_more,
                if (group.collapsed) "그룹 펼치기" else "그룹 접기",
                if (group.collapsed) "숨겨 둔 탭을 다시 보여줍니다" else "탭을 한 줄로 접어 둡니다"
            ) {
                group.collapsed = !group.collapsed
                onChanged()
            },
            Popup.Item(R.drawable.ic_edit, "이름·색상 변경") {
                showGroupEditor(group) { name, color ->
                    group.name = name
                    group.color = color
                    onChanged()
                }
            },
            Popup.Item(R.drawable.ic_folder, "그룹 해제", "탭은 닫지 않고 그룹만 없앱니다") {
                ungroup(group)
                onChanged()
            },
            Popup.Item(R.drawable.ic_delete, "그룹의 탭 모두 닫기", "탭 ${n}개가 닫힙니다", danger = true) {
                Popup.confirm(
                    this, "탭 ${n}개를 닫을까요?",
                    "'${group.name}' 그룹의 탭이 모두 닫힙니다.", "모두 닫기", danger = true
                ) {
                    closeGroup(group)
                    onChanged()
                }
            }
        )
        Popup.menu(
            this,
            title = group.name,
            subtitle = "탭 ${n}개" + if (group.collapsed) " · 접힘" else "",
            headerColor = group.color,
            items = items
        )
    }

    // ───────────────────────── 태블릿 레이아웃 / 탭 스트립 ─────────────────────────

    /**
     * 창의 현재 폭이 600dp 이상이면 넓은(태블릿) 레이아웃. 짧은 변이 아니라 지금 폭으로 정해서,
     * 창을 가로로 길게 늘리면 넓은 화면으로, 좁게 줄이면 폰 화면으로 바뀐다.
     * 경계(600dp)에서 창을 끌 때 계속 깜빡이지 않도록, 이미 넓은 상태면 560dp 밑으로 내려가야 좁은 화면으로 돌아간다.
     */
    private fun wideForWindow(): Boolean {
        val w = resources.configuration.screenWidthDp
        return if (expanded) w >= 560 else w >= 600
    }

    private var lastCols = 0

    /**
     * 웹페이지를 새 창 크기에 맞춘다. 모바일 사이트는 웹뷰가 알아서 다시 배치되지만,
     * 데스크톱 사이트 보기와 페이지 확대/축소는 "페이지를 불러올 때의 폭"으로 뷰포트를 한 번 덮어쓴 것이라
     * 창 크기를 바꾸면 옛 폭이 남는다. 크기 변화가 멈추면(끄는 중에는 잠깐 기다림) 새 폭으로 다시 덮어쓴다.
     */
    private val webRelayout = Runnable {
        if (isFinishing || isDestroyed || isInPictureInPictureModeCompat()) return@Runnable
        for (t in tabs) {
            val wv = t.liveWebView ?: continue
            if (t.isHome || t.pendingUrl != null) continue
            if (t.desktop) wv.evaluateJavascript(desktopViewportJs(), null)
            else if (effectiveZoom(t) == 100) wv.evaluateJavascript(REFIT_VIEWPORT_JS, null)
            if (effectiveZoom(t) != 100) wv.evaluateJavascript(pageZoomJs(t), null)
        }
    }

    /**
     * 창 폭이 바뀐 뒤 페이지 배율이 옛 폭 기준으로 남아 내용이 커 보이는 것을 막는다.
     * viewport 메타를 한 번 건드려(값을 바꿨다가 되돌려) 웹뷰가 새 폭 기준으로 처음 배율을 다시 계산하게 한다.
     */
    private val REFIT_VIEWPORT_JS =
        "(function(){var m=document.querySelector('meta[name=viewport]');if(!m)return;" +
            "var c=m.getAttribute('content')||'';m.setAttribute('content',c+',');" +
            "requestAnimationFrame(function(){m.setAttribute('content',c);});})();"

    /** 웹 영역의 실제 너비(dp). AI 분할 패널이 영역을 좁히면 창 너비보다 작다 */
    private fun webAreaWidthDp(): Int {
        val w = if (::webContainer.isInitialized) webContainer.width else 0
        return if (w > 0) (w / resources.displayMetrics.density).toInt() else resources.configuration.screenWidthDp
    }

    /** 모바일/데스크톱 사이트 판단용 '넓은 화면' 여부: AI 분할 중에는 웹 영역 너비로, 아니면 창 너비로 (경계에서 깜빡이지 않게 히스테리시스) */
    private fun siteWideNow(windowWide: Boolean): Boolean {
        if (assistant?.isSplitOpen() != true || !::webContainer.isInitialized || webContainer.width <= 0) return windowWide
        val w = webAreaWidthDp()
        return if (siteModeWide == true) w >= 560 else w >= 600
    }

    private var lastWebAreaW = 0
    private val siteModeSync = Runnable {
        if (isFinishing || isDestroyed || mirrorActive || isInPictureInPictureModeCompat()) return@Runnable
        syncSiteModeWithLayout(siteWideNow(wideForWindow()))
    }
    private var fastRelayoutPosted = false

    /** 웹 영역 너비가 바뀔 때(AI 분할 패널 끌기·열기·닫기): 페이지 폭을 실시간으로 맞추고, 모바일↔데스크톱 전환을 잠깐 뒤에 따진다 */
    private fun onWebAreaResized() {
        val w = webContainer.width
        if (w <= 0 || w == lastWebAreaW) return
        lastWebAreaW = w
        if (!fastRelayoutPosted) {
            fastRelayoutPosted = true
            ui.postDelayed({ fastRelayoutPosted = false; webRelayout.run() }, 70)
        }
        ui.removeCallbacks(siteModeSync)
        ui.postDelayed(siteModeSync, 300)
    }

    private fun scheduleWebRelayout() {
        ui.removeCallbacks(webRelayout)
        ui.postDelayed(webRelayout, 160)
    }

    /** 탭 화면의 카드 열 수: 폭이 넓을수록 늘어난다 */
    private fun switcherCols(): Int = (resources.configuration.screenWidthDp / 170).coerceIn(2, 5)

    /** 레이아웃 모드는 그대로인 크기·비율 변화: 필요한 곳만 새 크기에 맞춰 다시 계산한다 */
    private fun onWindowResized() {
        if (isInPictureInPictureModeCompat()) return
        // 탭 화면 전환 애니메이션이 움직이는 중에 창 크기·비율이 바뀌면, 정해 둔 시작·끝 위치가 낡아 크기가 이상해진다.
        // 그 자리에서 곧바로 끝 상태로 마무리해서 새 크기의 실제 화면으로 이어지게 한다.
        morphAnim?.let { if (it.isRunning && it.canSkipToEnd()) it.skipToEnd() }
        if (switcherOpen && switcherCols() != lastCols) {
            lastCols = switcherCols()
            refreshSwitcher(false)
        }
        if (expanded) {
            tabStripScroll.doOnLayout {
                lastStripViewportW = tabStripScroll.width
                refreshTabStrip()
                updateStripPlus()
            }
        }
        if (switcherOpen) refreshWindowStrip()
        browserUi.post { scrollBars.reapply() }
    }

    /**
     * "상/하단바 숨기기" 옵션: 켜져 있으면 웹 페이지를 보는 동안 상단(탭 줄·주소창)과 하단 바를 없애고
     * 대신 작은 메뉴 버튼만 띄운다. 홈(새 탭) 화면에서도 숨기고, 주소 입력 중에만 바를 보여 준다.
     * 폰/태블릿 전환, 탭 전환, 페이지 이동 때 호출된다.
     */
    private var barsAnimToken = 0

    private fun applyHideBars(animate: Boolean = true) {
        if (!::bottomBar.isInitialized || !::btnFloatMenu.isInitialized) return
        // PiP·동영상 전체화면에서는 각자 바를 따로 다룬다
        if (customView != null || mirrorActive || isInPictureInPictureModeCompat()) return
        val t = current
        val hide = prefs.hideBars && !barsTempShown && t != null && !t.awaitCommit &&
            !urlBar.hasFocus()
        val wide = expanded
        val changed = hide != barsHiddenNow
        barsHiddenNow = hide
        if (hide) {
            // 메뉴 팝업이 버튼 아래로 열리므로 태블릿은 오른쪽 위, 폰(아래 시트)은 오른쪽 아래
            (btnFloatMenu.layoutParams as? FrameLayout.LayoutParams)?.let {
                val g = (if (wide) Gravity.TOP else Gravity.BOTTOM) or Gravity.END
                if (it.gravity != g) { it.gravity = g; btnFloatMenu.layoutParams = it }
            }
        }
        val bars = listOf(tabStripBar to (wide && !hide), toolbarView to !hide, bottomBar to (!wide && !hide))
        val floatAlpha = 1f
        val token = ++barsAnimToken
        for ((v, _) in bars) v.animate().cancel()
        btnFloatMenu.animate().cancel()
        fun settle(v: View, visible: Boolean, alpha: Float) {
            v.visibility = if (visible) View.VISIBLE else View.GONE
            v.translationY = 0f; v.alpha = alpha; v.scaleX = 1f; v.scaleY = 1f
        }

        val doAnim = changed && animate && Motion.enabled(this) && browserUi.isLaidOut
        if (!doAnim) {
            for ((v, w) in bars) settle(v, w, 1f)
            settle(btnFloatMenu, hide, floatAlpha)
        } else {
            val d = 220L
            val ip = android.view.animation.PathInterpolator(0.4f, 0f, 0.2f, 1f)
            for ((v, want) in bars) {
                val dir = if (v === bottomBar) 1f else -1f   // 위 바는 위로, 아래 바는 아래로
                if (want) {
                    // 보이기: 바가 제자리를 차지한 채 살짝 밀려 내려오며 나타난다
                    if (v.visibility != View.VISIBLE) {
                        v.visibility = View.VISIBLE
                        v.alpha = 0f
                        v.translationY = dir * dp(24)
                    }
                    v.animate().alpha(1f).translationY(0f).setDuration(d).setInterpolator(ip).start()
                } else if (v.visibility == View.VISIBLE) {
                    // 숨기기: 밀려 나가며 사라진 뒤에 자리를 비운다 (웹 영역 크기는 끝에 한 번만 바뀐다)
                    v.animate().alpha(0f).translationY(dir * maxOf(v.height, dp(24)).toFloat())
                        .setDuration(d).setInterpolator(ip)
                        .withEndAction { if (barsAnimToken == token) settle(v, false, 1f) }
                        .start()
                }
            }
            if (hide) {
                if (btnFloatMenu.visibility != View.VISIBLE) {
                    btnFloatMenu.visibility = View.VISIBLE
                    btnFloatMenu.alpha = 0f
                    btnFloatMenu.scaleX = 0.7f; btnFloatMenu.scaleY = 0.7f
                }
                btnFloatMenu.animate().alpha(floatAlpha).scaleX(1f).scaleY(1f)
                    .setStartDelay(d / 2).setDuration(d).setInterpolator(ip).start()
            } else if (btnFloatMenu.visibility == View.VISIBLE) {
                btnFloatMenu.animate().alpha(0f).scaleX(0.7f).scaleY(0.7f)
                    .setStartDelay(0).setDuration(d / 2).setInterpolator(ip)
                    .withEndAction { if (barsAnimToken == token) settle(btnFloatMenu, false, floatAlpha) }
                    .start()
            }
        }
        // 바를 숨기는 동안에는 상태표시줄도 같이 숨긴다 (위로 쓸어내리면 잠깐 보인다)
        applyStatusBarForHideBars(hide)
        if (changed) {
            browserUi.post { updateStatusBarColor() }
            val delay = if (doAnim) 260L else 0L
            webContainer.postDelayed({ if (barsAnimToken == token) barsResync() }, delay)
        }
    }

    private var statusBarHiddenByHideBars = false

    /**
     * 팝업·데스크톱 창처럼 시스템 제목줄(창 버튼)이 있는 창인가.
     * 이런 창에서 상태표시줄 숨김을 요청하면 시스템이 제목줄 인셋까지 0 으로 보내서,
     * 앱이 제목줄 자리까지 올라가 시스템 버튼(…, 최소화, 최대화, 닫기)을 가려 버린다. 그래서 이 창에서는 시스템 바를 숨기지 않는다.
     */
    private fun windowHasCaption(): Boolean = capInsetTop > 0 || captionActive || isNotFullscreenWindow()

    /** 창이 화면 전체가 아니면(팝업·자유 창·분할 화면) true */
    private fun isNotFullscreenWindow(): Boolean {
        if (isInMultiWindowMode) return true
        if (Build.VERSION.SDK_INT < 30) return false
        return try {
            val cur = windowManager.currentWindowMetrics.bounds
            val max = windowManager.maximumWindowMetrics.bounds
            cur.width() < max.width() || cur.height() < max.height()
        } catch (_: Throwable) { false }
    }

    private fun applyStatusBarForHideBars(hide: Boolean) {
        if (customView != null) return
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (hide && windowHasCaption()) {
            if (statusBarHiddenByHideBars) {
                statusBarHiddenByHideBars = false
                controller.show(WindowInsetsCompat.Type.statusBars())
                (browserUi.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
            }
            return
        }
        if (hide) {
            // 이미 숨겼다고 기록돼 있어도 그냥 return 하지 않는다:
            // 앱을 나갔다 오거나 창 포커스·회전·PiP 복귀로 시스템이 상태표시줄을 다시 보이게 했을 수 있어서
            // 매번 다시 숨긴다 (이미 숨겨져 있으면 아무 일도 없다)
            statusBarHiddenByHideBars = true
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.statusBars())
        } else if (statusBarHiddenByHideBars) {
            statusBarHiddenByHideBars = false
            controller.show(WindowInsetsCompat.Type.statusBars())
        }
        if (captionEdgeToEdge) (browserUi.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
    }

    // 스크롤로 바가 모두 숨으면 시스템 상태표시줄도 숨긴다. 숨기는 동안 루트 위 여백은 그대로 두어(frozen) 레이아웃이 튀지 않게 한다.
    private var statusBarHiddenByScroll = false
    private var frozenTopInset = 0

    private fun applyStatusBarForScroll(hide: Boolean) {
        if (!::browserUi.isInitialized || customView != null || mirrorActive || isInPictureInPictureModeCompat()) return
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (hide && windowHasCaption()) {
            if (statusBarHiddenByScroll) {
                statusBarHiddenByScroll = false
                controller.show(WindowInsetsCompat.Type.statusBars())
                (browserUi.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
            }
            return
        }
        if (hide) {
            if (!statusBarHiddenByScroll) {
                frozenTopInset = (browserUi.parent as? View)?.paddingTop ?: 0
                statusBarHiddenByScroll = true
            }
            // 이미 숨겨져 있어도 다시 호출한다 (포커스 복귀 등으로 시스템이 다시 보였을 수 있음)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.statusBars())
        } else if (statusBarHiddenByScroll) {
            statusBarHiddenByScroll = false
            controller.show(WindowInsetsCompat.Type.statusBars())
            (browserUi.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
        }
    }

    /** 창이 다시 포커스를 받거나 화면 구성이 바뀐 뒤, 바 숨김 중이면 상태표시줄도 다시 숨긴다 */
    private fun reapplyStatusBarHidden() {
        if (scrollBars.fraction > 0.02f) applyStatusBarForScroll(true)
        if (barsHiddenNow && customView == null && !mirrorActive && !isInPictureInPictureModeCompat()) {
            applyStatusBarForHideBars(true)
        }
    }

    // ───────────────────────── 상단바 버튼 편집 ─────────────────────────

    /** 설정에서 고를 수 있는 추가 버튼(새 탭·북마크·방문 기록 등). 처음 쓸 때 만들어 두고 계속 재사용한다. */
    private val topBarExtraViews = HashMap<String, ImageButton>()

    private fun borderlessBgRes(): Int {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        return tv.resourceId
    }

    private fun topBarExtra(id: String): View = topBarExtraViews.getOrPut(id) {
        val item = TopBarConfig.byId(id)!!
        val size = resources.getDimensionPixelSize(R.dimen.ev_btn)
        ImageButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            setBackgroundResource(borderlessBgRes())
            setImageResource(item.icon)
            imageTintList = android.content.res.ColorStateList.valueOf(
                barFg ?: ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurface)
            )
            contentDescription = item.label
            setOnClickListener { v -> topBarAction(id, v) }
            addPressAnim(this, id)
        }
    }

    /** 메뉴를 거치지 않고 열린 목록(상단바 버튼)은 닫을 때 메뉴를 다시 띄우지 않는다. */
    private var suppressMenuReopen = false

    /**
     * @param anchor 눌린 상단바 버튼. 주면 목록 팝업이 가운데가 아니라 그 버튼 바로 아래(오른쪽 끝 맞춤)에 뜬다.
     */
    private fun forgetMenuForList(anchor: View? = null) {
        suppressMenuReopen = true
        menuReopenAnchor = null
        menuAnchorRef = null
        menuAnchorRight = -1
        menuAnchorBottom = -1
        menuAnchorWinRight = -1
        menuAnchorWinBottom = -1
        if (anchor != null && anchor.width > 0 && anchor.height > 0) {
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val locScreen = IntArray(2)
            anchor.getLocationOnScreen(locScreen)
            menuAnchorRight = locScreen[0] + anchor.width
            menuAnchorBottom = locScreen[1] + anchor.height
            menuAnchorWinRight = loc[0] + anchor.width
            menuAnchorWinBottom = loc[1] + anchor.height
        }
    }

    private fun topBarAction(id: String, anchor: View) {
        when (id) {
            "newtab" -> openNewTabAndFocus()
            "bookmark" -> bookmarkCurrent()
            "bookmarks" -> { forgetMenuForList(anchor); openBookmarks() }
            "history" -> { forgetMenuForList(anchor); openHistory() }
            "downloads" -> { forgetMenuForList(anchor); openDownloads() }
            "find" -> openFind()
            "refresh" -> { reloadOrStop(); refreshTapFeedback(anchor) }
            "settings" -> showMenu(anchor, settings = true, fromMenu = false)
            "desktop" -> toggleDesktopSite()
            "ai" -> assistant?.show(anchor)
            "hidebars" -> toggleHideBars()
            "player" -> openInternalPlayer()
            "extensions" -> { forgetMenuForList(anchor); extAnchorRef = java.lang.ref.WeakReference(anchor); showExtensions() }
        }
    }

    /**
     * 설정에 저장된 목록대로 상단바 버튼을 보이고 숨기고 순서를 맞춘다.
     * 뒤로/앞으로 = 주소창 왼쪽 묶음, 새로고침 = 주소창 안쪽, 나머지 = 주소창 오른쪽 묶음.
     * (메뉴 버튼은 넓은 화면에서 항상 맨 오른쪽에 남는다)
     */
    /** 주소창 칸의 왼쪽 여백(dp). 상단바 왼쪽 묶음(뒤로/앞으로)과 주소창 사이 간격. */
    private fun setUrlFrameStartGap(dpValue: Int) {
        val frame = urlBar.parent as? View ?: return
        val lp = frame.layoutParams as? ViewGroup.MarginLayoutParams ?: return
        val px = dp(dpValue)
        if (lp.marginStart != px) {
            lp.marginStart = px
            frame.layoutParams = lp
        }
    }

    private fun applyTopBarButtons(wide: Boolean) {
        val ids = TopBarConfig.enabled(prefs, wide)
        val lay = TopBarConfig.layout(prefs, wide)
        if (!wide) {
            // 폰: 상단바는 주소창 + 새로고침만, 편집하는 버튼들은 하단바에 놓인다
            navGroup.visibility = View.GONE
            tabletActions.visibility = View.GONE
            btnTabs.visibility = View.GONE
            // 새로고침은 태블릿과 같이 목록에 있을 때만 주소창 안쪽에 보인다
            val phoneRefresh = lay.refreshInline
            btnRefresh.visibility = if (phoneRefresh) View.VISIBLE else View.GONE
            urlBar.setPaddingRelative(urlBar.paddingStart, urlBar.paddingTop, dp(if (phoneRefresh) 44 else 16), urlBar.paddingBottom)
            applyBottomBarButtons(lay.left + lay.right)
            setUrlFrameStartGap(0)
            return
        }
        fun viewFor(id: String): View? = when (id) {
            "back" -> tbBack
            "forward" -> tbForward
            "desktop" -> tbDesktop
            "home" -> tbHome
            "ai" -> tbAi
            "tabs" -> btnTabs
            "refresh" -> topBarExtra("refresh")
            else -> topBarExtra(id)
        }
        // 기본 버튼 중 빠진 것은 먼저 숨긴다 (btnTabs 처럼 묶음 밖에 있던 버튼이 남지 않게)
        for (id in listOf("back", "forward", "desktop", "home", "ai", "tabs")) {
            if (id !in ids) viewFor(id)?.visibility = View.GONE
        }
        val leftIds = lay.left
        val rightIds = lay.right
        fun place(group: LinearLayout, side: Int) {
            val views = (if (side == TopBarConfig.LEFT) leftIds else rightIds).mapNotNull { viewFor(it) }
            group.removeAllViews()
            for (v in views) {
                (v.parent as? ViewGroup)?.removeView(v)
                group.addView(v)
                v.visibility = View.VISIBLE
            }
            group.visibility = if (views.isEmpty()) View.GONE else View.VISIBLE
        }
        place(navGroup as LinearLayout, TopBarConfig.LEFT)
        place(tabletActions as LinearLayout, TopBarConfig.RIGHT)
        // 앞으로 가기 버튼 아이콘은 버튼 안쪽 가운데라 주소창과 붙어 보인다 → 왼쪽 묶음이 있을 때만 주소창을 조금 띄운다
        setUrlFrameStartGap(if (navGroup.visibility == View.VISIBLE) 6 else 0)
        val showRefresh = lay.refreshInline
        btnRefresh.visibility = if (showRefresh) View.VISIBLE else View.GONE
        // 새로고침 버튼이 주소창 안쪽 오른쪽에 있으므로, 숨기면 글자가 그 자리까지 쓰이게 여백을 줄인다
        urlBar.setPaddingRelative(urlBar.paddingStart, urlBar.paddingTop, dp(if (showRefresh) 44 else 16), urlBar.paddingBottom)
        if (loadingIcon) topBarExtraViews["refresh"]?.setImageResource(R.drawable.ic_close)
    }

    private val bottomExtraViews = HashMap<String, ImageButton>()

    /** 폰 하단바에 올리는 버튼 (모두 같은 너비로 나눠 쓴다) */
    private fun bottomExtra(id: String): View = bottomExtraViews.getOrPut(id) {
        val item = TopBarConfig.byId(id)!!
        ImageButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            setBackgroundResource(borderlessBgRes())
            setImageResource(item.icon)
            imageTintList = android.content.res.ColorStateList.valueOf(
                barFg ?: ThemeColors.get(this, com.google.android.material.R.attr.colorOnSurface)
            )
            contentDescription = item.label
            setOnClickListener { v -> topBarAction(id, v) }
            addPressAnim(this, id)
        }
    }

    /** 폰 하단바: 고른 버튼을 순서대로, 메뉴 버튼은 항상 맨 오른쪽 */
    private fun applyBottomBarButtons(ids: List<String>) {
        val bar = bottomBar as LinearLayout
        val views: List<View> = ids.mapNotNull { id ->
            when (id) {
                "back" -> btnBack
                "forward" -> btnForward
                "home" -> btnHome
                "tabs" -> btnBottomTabs
                else -> bottomExtra(id)
            }
        }
        bar.removeAllViews()
        for (v in views + btnMenu) {
            (v.parent as? ViewGroup)?.removeView(v)
            bar.addView(v)
            v.visibility = View.VISIBLE
        }
        updateDesktopButton()
        if (loadingIcon) bottomExtraViews["refresh"]?.setImageResource(R.drawable.ic_close)
    }

    /** 열려 있는 모든 창의 상/하단바에 바뀐 설정을 바로 적용한다 */
    private fun refreshTopBarButtons() {
        ui.post { instances.toList().forEach { a -> if (!a.isFinishing) a.applyTopBarButtons(a.expanded) } }
    }

    private fun showTopBarEditor() {
        val wide = expanded
        val saved = TopBarConfig.enabled(prefs, wide)
        val savedLay = TopBarConfig.layout(prefs, wide)
        val left = savedLay.left.toMutableList()
        val right = savedLay.right.toMutableList()
        // 태블릿 상단바와 폰 하단바는 같은 목록을 쓴다 (폰 하단바에는 왼쪽 묶음 → 오른쪽 묶음 순서로 놓이고, 새로고침은 주소창 안쪽)
        // refresh = 새로고침이 주소창 안쪽에 있다 (왼쪽/오른쪽 묶음에 있으면 false, 그때는 목록 안에 "refresh" 가 들어 있다)
        var refresh = savedLay.refreshInline

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(8))
        }
        val scroll = android.widget.ScrollView(this).apply { addView(root) }
        val attr = com.google.android.material.R.attr.colorOnSurface
        val onSurface = ThemeColors.get(root, attr)
        val onVar = ThemeColors.get(root, com.google.android.material.R.attr.colorOnSurfaceVariant)
        val surfaceC = ThemeColors.get(root, com.google.android.material.R.attr.colorSurface)
        val containerC = ThemeColors.get(root, com.google.android.material.R.attr.colorSurfaceContainerHighest)

        fun tint(c: Int) = android.content.res.ColorStateList.valueOf(c)
        // 편집 화면의 버튼 아이콘: 탭 버튼은 실제 버튼처럼 "네모 + 열린 탭 개수"로 그린다
        fun showIcon(iv: ImageView, item: TopBarItem, color: Int) {
            if (item.id == "tabs") {
                iv.setImageDrawable(TabCountDrawable(color, tabs.size))
                iv.imageTintList = null
            } else {
                iv.setImageResource(item.icon)
                iv.imageTintList = tint(color)
            }
        }
        fun rounded(color: Int, r: Int) = GradientDrawable().apply {
            cornerRadius = dp(r).toFloat()
            setColor(color)
        }
        fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

        // ── 드래그로만 편집: 버튼을 꾹 눌러 끌어서 순서를 바꾸고, 아래 칸에서 끌어 올려 추가하고, 아래 칸으로 끌어 내려 뺀다 ──
        // 미리보기의 주소창 칸: 손가락이 이 칸보다 왼쪽이면 왼쪽 묶음, 오른쪽이면 오른쪽 묶음에 놓는다 (태블릿)
        var pillRef: View? = null
        fun detach(id: String) {
            left.remove(id)
            right.remove(id)
            if (id == "refresh") refresh = false
        }
        val animOn = Motion.enabled(this)
        val smooth = android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)

        // 놓은 자리(손가락 위치, 창 좌표): 다시 그릴 때 버튼이 그 자리에서 제자리로 내려앉듯 들어간다
        var dropId: String? = null
        var dropAt: FloatArray? = null
        fun noteDrop(target: View, e: DragEvent, id: String) {
            val loc = IntArray(2)
            target.getLocationInWindow(loc)
            dropId = id
            dropAt = floatArrayOf(loc[0] + e.x, loc[1] + e.y)
        }

        // 다시 그릴 때 버튼들이 제자리로 미끄러지듯 움직이게 하려고, 그리기 전 위치를 기억해 둔다
        val iconViews = HashMap<String, View>()
        var renderPending = false
        var renderFn: (() -> Unit)? = null
        fun scheduleRender() {
            if (renderPending) return
            renderPending = true
            root.post { renderPending = false; renderFn?.invoke() }
        }

        // ── 끌기 상태 ──
        // 끄는 동안 목록(left/right/refresh)을 실시간으로 바꿔서, 손가락이 가는 자리에 맞춰 다른 버튼들이 밀려나며 놓을 자리가 열린다.
        // 끌고 있는 버튼의 자리는 '빈 칸(점선 느낌의 표시)'으로 남고, 놓으면 그 칸으로 내려앉는다. 엉뚱한 곳에 놓으면 원래 자리로 돌아간다.
        var dragId: String? = null
        var dropped = false
        var snapLeft = listOf<String>()
        var snapRight = listOf<String>()
        var snapRefresh = false
        var lastFinger: FloatArray? = null
        val primaryC = ThemeColors.get(root, com.google.android.material.R.attr.colorPrimary)
        fun placeholderBg() = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(androidx.core.graphics.ColorUtils.setAlphaComponent(primaryC, 0x22))
            setStroke(dp(1), androidx.core.graphics.ColorUtils.setAlphaComponent(primaryC, 0x99))
        }

        fun beginDrag(id: String) {
            dragId = id
            dropped = false
            snapLeft = left.toList(); snapRight = right.toList(); snapRefresh = refresh
            scheduleRender()
        }

        val hoverLoc = IntArray(2)

        /** 손가락이 바 위에 있다: 같은 자리 묶음 안에서 손가락 앞에 올 버튼 수만큼 앞으로 놓는다 */
        fun hoverBar(id: String, bar: View, e: DragEvent, force: Boolean) {
            if (renderPending && !force) return
            val item = TopBarConfig.byId(id) ?: return
            bar.getLocationInWindow(hoverLoc)
            val fx = hoverLoc[0] + e.x
            var changed = false
            // 새로고침은 주소창 칸 위에 놓으면 주소창 안쪽, 그 밖(바)에 놓으면 다른 버튼처럼 왼쪽/오른쪽 묶음에 놓인다
            val fy = hoverLoc[1] + e.y
            val pillV = pillRef
            val overPill = id == "refresh" && pillV != null && pillV.isAttachedToWindow && run {
                val pl = IntArray(2)
                pillV.getLocationInWindow(pl)
                fx >= pl[0] && fx <= pl[0] + pillV.width &&
                    (wide || (fy >= pl[1] && fy <= pl[1] + pillV.height))
            }
            if (overPill) {
                if (!refresh || id in left || id in right) {
                    refresh = true
                    left.remove(id); right.remove(id)
                    changed = true
                }
            } else {
                if (id == "refresh" && refresh) { refresh = false; changed = true }
                // 어느 묶음에 놓을지: 태블릿은 주소창 칸 기준 왼쪽/오른쪽, 폰 하단바는 한 줄이라 지금 있는 묶음을 따른다
                val pill = pillRef
                val toLeft: Boolean = if (wide && pill != null && pill.isAttachedToWindow) {
                    pill.getLocationInWindow(hoverLoc)
                    val pl = hoverLoc[0]
                    val pr = pl + pill.width
                    when {
                        fx < pl -> true
                        fx > pr -> false
                        else -> id in left
                    }
                } else if (!wide) {
                    // 폰: (왼쪽 + 오른쪽) 한 줄에서의 순서로 놓고, 경계 위치면 왼쪽 묶음 끝으로 본다
                    var idx = 0
                    for (oid in left + right) {
                        if (oid == id) continue
                        val ov = iconViews[oid] ?: continue
                        ov.getLocationInWindow(hoverLoc)
                        if (hoverLoc[0] - ov.translationX + ov.width / 2f < fx) idx++
                    }
                    val leftCount = left.count { it != id }
                    val wasLeft = id in left
                    val wasRight = id in right
                    val newLeft = idx <= leftCount && !(idx == leftCount && wasRight)
                    val curIdx = if (wasLeft) left.indexOf(id) else if (wasRight) left.size + right.indexOf(id) else -1
                    if (curIdx != idx || wasLeft != newLeft) {
                        left.remove(id); right.remove(id)
                        if (newLeft) left.add(idx.coerceAtMost(left.size), id)
                        else right.add((idx - left.size).coerceIn(0, right.size), id)
                        changed = true
                    }
                    if (changed) {
                        root.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                        scheduleRender()
                    }
                    return
                } else id in left
                val list = if (toLeft) left else right
                val other = if (toLeft) right else left
                var idx = 0
                for (oid in list) {
                    if (oid == id) continue
                    val ov = iconViews[oid] ?: continue
                    ov.getLocationInWindow(hoverLoc)
                    // 움직이는 중인 위치가 아니라 자리 잡힌 위치로 비교해야 앞뒤로 덜덜 떨지 않는다
                    if (hoverLoc[0] - ov.translationX + ov.width / 2f < fx) idx++
                }
                if (other.remove(id)) changed = true
                if (list.indexOf(id) != idx) {
                    list.remove(id)
                    list.add(idx.coerceAtMost(list.size), id)
                    changed = true
                }
            }
            if (changed) {
                root.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                scheduleRender()
            }
        }

        /** 손가락이 아래 칸 위에 있다: 바에 있던 버튼이면 바에서 빠지고, 바가 그 자리를 메운다 */
        fun hoverTray(id: String, force: Boolean) {
            if (renderPending && !force) return
            if (id in left || id in right || (id == "refresh" && refresh)) {
                detach(id)
                root.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                scheduleRender()
            }
        }

        /** 바(미리보기)와 아래 칸이 쓰는 끌기 수신기. 안쪽 버튼에는 수신기를 달지 않아서 이벤트가 여기로 모인다 */
        fun dragListener(isTray: Boolean) = View.OnDragListener { v, e ->
            val id = e.localState as? String
            when (e.action) {
                DragEvent.ACTION_DRAG_STARTED -> return@OnDragListener id != null
                DragEvent.ACTION_DRAG_ENTERED -> if (isTray) v.background = rounded(containerC, 14)
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> if (isTray) v.background = null
                DragEvent.ACTION_DRAG_LOCATION -> if (id != null) {
                    v.getLocationInWindow(hoverLoc)
                    lastFinger = floatArrayOf(hoverLoc[0] + e.x, hoverLoc[1] + e.y)
                    if (isTray) hoverTray(id, false) else hoverBar(id, v, e, false)
                }
                DragEvent.ACTION_DROP -> if (id != null) {
                    if (isTray) hoverTray(id, true) else hoverBar(id, v, e, true)
                    noteDrop(v, e, id)
                    dropped = true
                    dragId = null
                    scheduleRender()
                }
            }
            true
        }

        val dragSlop = android.view.ViewConfiguration.get(this).scaledTouchSlop

        /**
         * 버튼에 손가락을 대고 끌기 시작하면(조금만 움직이면) 바로 들려서 따라온다. 누르고 있기만 해도 들린다.
         * 누르는 동안은 살짝 눌리고, 들리면 그 자리는 빈 칸 표시로 바뀐다. 눌러서 고르거나 추가하는 동작은 없다.
         * [shadowSrc]: 손가락 밑에 따라올 그림으로 쓸 뷰 (기본은 버튼 자신)
         */
        fun armDrag(v: View, id: String, shadowSrc: View = v) {
            v.isClickable = true
            var started = false
            var downX = 0f
            var downY = 0f
            val lift = Runnable {
                if (started) return@Runnable
                started = true
                v.parent?.requestDisallowInterceptTouchEvent(true)
                val plate = ThemeColors.get(v, com.google.android.material.R.attr.colorSurfaceContainerHighest)
                val ok = v.startDragAndDrop(
                    ClipData.newPlainText("id", id),
                    LiftShadow(shadowSrc, androidx.core.graphics.ColorUtils.setAlphaComponent(plate, 0xF2)),
                    id, 0
                )
                if (ok) {
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    beginDrag(id)
                } else {
                    started = false
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
            }
            v.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        started = false
                        downX = e.rawX; downY = e.rawY
                        // 아이콘 위에서 시작한 손가락은 스크롤이 아니라 끌기로 쓴다
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        v.postDelayed(lift, 380)
                        if (animOn) v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        if (!started && Math.hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > dragSlop) {
                            v.removeCallbacks(lift)
                            lift.run()
                        }
                    }
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                        v.removeCallbacks(lift)
                        if (!started && animOn) v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                    }
                }
                false
            }
        }

        // ── 창이 버튼 줄 수에 맞춰 유기적으로 변하게: 높이는 부드럽게 늘고 줄며, 아래 칸의 한 줄 버튼 수는 창 너비를 따른다 ──
        var heightAnim: android.animation.ValueAnimator? = null
        var origScrollH: Int? = null
        var curCols = 4
        var lastScrollW = 0
        fun trayCols(): Int {
            val dm = resources.displayMetrics
            val w = scroll.width.takeIf { it > 0 }
                ?: (minOf((window.decorView.width.takeIf { it > 0 } ?: dm.widthPixels) - dp(48), dp(560)) - dp(48))
            // 안쪽 여백(편집 영역 16dp×2 + 아래 칸 4dp×2)을 뺀 폭을 버튼 한 칸(약 78dp)으로 나눈다
            return ((w - dp(40)) / dp(78)).coerceIn(3, 6)
        }
        fun animateWindowHeight(oldH: Int) {
            if (!animOn || oldH <= 0 || scroll.width <= 0 || !scroll.isAttachedToWindow) return
            root.measure(
                View.MeasureSpec.makeMeasureSpec(scroll.width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val maxH = (window.decorView.height - dp(250)).coerceAtLeast(dp(200))
            val newH = minOf(root.measuredHeight, maxH)
            if (Math.abs(newH - oldH) <= dp(2)) return
            val lp = scroll.layoutParams ?: return
            if (origScrollH == null) origScrollH = lp.height
            var cancelled = false
            heightAnim = android.animation.ValueAnimator.ofInt(oldH, newH).apply {
                duration = 280
                interpolator = smooth
                addUpdateListener {
                    lp.height = it.animatedValue as Int
                    scroll.layoutParams = lp
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                    override fun onAnimationEnd(a: android.animation.Animator) {
                        if (cancelled) return
                        lp.height = origScrollH ?: ViewGroup.LayoutParams.MATCH_PARENT
                        scroll.layoutParams = lp
                        heightAnim = null
                    }
                })
            }
            // 다시 그려지는 순간 이전 높이로 먼저 붙잡아 둔다 (높이가 한 번에 튀지 않게)
            lp.height = oldH
            scroll.layoutParams = lp
            heightAnim?.start()
        }

        fun render() {
            val oldH = if (scroll.isAttachedToWindow) scroll.height else 0
            heightAnim?.cancel()
            val before = HashMap<String, IntArray>()
            for ((id, v) in iconViews) if (v.isAttachedToWindow) before[id] = IntArray(2).also { v.getLocationInWindow(it) }
            iconViews.clear()
            root.removeAllViews()

            root.addView(TextView(this).apply {
                text = if (wide)
                    "태블릿 상단바 미리보기예요. 버튼을 끌어서 편집하세요.\n" +
                        "주소창 왼쪽·오른쪽 어디든 끌어 놓을 수 있어요(새로고침은 주소창 안쪽도 가능). 아래 칸에서 위로 끌어 올리면 추가, 아래 칸으로 끌어 내리면 빠져요."
                else
                    "폰 화면 미리보기예요. 버튼을 끌어서 편집하세요.\n" +
                        "아래 바에서 끌어 순서를 바꾸고, 아래 칸에서 위로 끌어 올리면 추가, 아래 칸으로 끌어 내리면 빠져요. " +
                        "새로고침은 주소창 안쪽이나 아래 바 어디든 놓을 수 있어요."
                textSize = 12.5f
                setTextColor(onVar)
                setPadding(dp(2), 0, dp(2), dp(10))
            })

            // 상단바 미리보기: 실제 상단바와 같은 배치 (왼쪽 버튼 · 주소창 · 오른쪽 버튼 · 메뉴)
            fun previewIcon(bid: String): View {
                val item = TopBarConfig.byId(bid)!!
                return ImageView(this).apply {
                    showIcon(this, item, onSurface)
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                    layoutParams = if (wide) lp(dp(40), dp(40)) else lp(0, dp(44), 1f)
                    contentDescription = item.label
                    armDrag(this, bid)
                    // 끌고 있는 버튼의 자리는 빈 칸 표시로 남긴다
                    if (bid == dragId) {
                        background = placeholderBg()
                        imageAlpha = 70
                    }
                    iconViews[bid] = this
                }
            }
            if (wide) {
            val bar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(containerC, 16)
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            // 버튼 사이가 아닌 곳에 놓으면 그 버튼이 속한 자리의 맨 끝에 붙는다
            bar.setOnDragListener(dragListener(false))
            left.forEach { bar.addView(previewIcon(it)) }
            val pill = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(surfaceC, 20)
                minimumWidth = dp(110)
                layoutParams = lp(0, dp(40), 1f).apply { marginStart = dp(4); marginEnd = dp(4) }
            }
            pill.addView(TextView(this).apply {
                text = "주소창"
                textSize = 13f
                setTextColor(onVar)
                setPadding(dp(14), 0, 0, 0)
                layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            if (refresh) pill.addView(previewIcon("refresh"))
            bar.addView(pill)
            pillRef = pill
            right.forEach { bar.addView(previewIcon(it)) }
            run {
                // 메뉴 버튼은 항상 남는다
                bar.addView(ImageView(this).apply {
                    setImageResource(R.drawable.ic_more)
                    imageTintList = tint(onSurface)
                    alpha = 0.35f
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                    layoutParams = lp(dp(40), dp(40))
                    contentDescription = "메뉴 (항상 표시)"
                })
            }
            val hs = android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                addView(bar, android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ))
            }
            root.addView(hs)
            } else {
            // 폰 화면 미리보기: 위에 주소창(새로고침은 안쪽), 가운데 페이지, 아래에 하단바(버튼을 같은 너비로 나눠 가짐, 메뉴는 맨 오른쪽)
            val phoneMock = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(22).toFloat()
                    setColor(surfaceC)
                    setStroke(dp(2), containerC)
                }
                setPadding(dp(8), dp(10), dp(8), dp(6))
            }
            phoneMock.setOnDragListener(dragListener(false))
            val pill = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(containerC, 20)
                layoutParams = lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40))
            }
            pill.addView(TextView(this).apply {
                text = "주소창"
                textSize = 13f
                setTextColor(onVar)
                setPadding(dp(14), 0, 0, 0)
                layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            pillRef = pill
            if (refresh) pill.addView(previewIcon("refresh").apply { layoutParams = lp(dp(40), dp(40)) })
            phoneMock.addView(pill)
            phoneMock.addView(TextView(this).apply {
                text = "웹페이지"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(onVar)
                alpha = 0.6f
                layoutParams = lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
            })
            val bottom = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(containerC, 18)
                setPadding(dp(4), dp(2), dp(4), dp(2))
            }
            // 실제 하단바와 같은 순서: 왼쪽 묶음 → 오른쪽 묶음 → 메뉴
            (left + right).forEach { bottom.addView(previewIcon(it)) }
            bottom.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_more)
                imageTintList = tint(onSurface)
                alpha = 0.35f
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = lp(0, dp(44), 1f)
                contentDescription = "메뉴 (항상 표시)"
            })
            phoneMock.addView(bottom)
            root.addView(phoneMock)
            }

            // 사용법 안내 (눌러서 고르거나 빼는 동작은 없다. 끌어서만 편집한다)
            root.addView(TextView(this).apply {
                text = "버튼을 끌어서 옮기거나, 아래 칸으로 끌어 내려 빼세요"
                textSize = 12.5f
                setTextColor(onVar)
                setPadding(dp(4), dp(8), dp(4), 0)
            })

            // 추가할 수 있는 버튼: 끌어서 위로 올리고, 상단바 버튼을 이 칸으로 끌어 놓으면 뺀다
            val trayBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(10), dp(4), dp(8))
            }
            trayBox.setOnDragListener(dragListener(true))
            trayBox.addView(TextView(this).apply {
                text = "추가할 수 있는 버튼 · 끌어서 추가"
                textSize = 13f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(onVar)
                setPadding(dp(2), dp(8), 0, dp(8))
            })
            val available = TopBarConfig.pool(wide).filter {
                it.id !in left && it.id !in right && !(it.id == "refresh" && refresh)
            }
            if (available.isEmpty()) {
                trayBox.addView(TextView(this).apply {
                    text = "모든 버튼이 상단바에 올라가 있어요"
                    textSize = 13f
                    setTextColor(onVar)
                })
            }
            curCols = trayCols()
            for (chunk in available.chunked(curCols)) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, 0, 0, dp(10))
                }
                for (item in chunk) {
                    val cell = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER_HORIZONTAL
                        layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val trayIcon = ImageView(this@MainActivity).apply {
                        showIcon(this, item, onSurface)
                        setPadding(dp(10), dp(10), dp(10), dp(10))
                        background = rounded(containerC, 14)
                        layoutParams = lp(dp(46), dp(46))
                    }
                    if (item.id == dragId) {
                        trayIcon.background = placeholderBg()
                        trayIcon.imageAlpha = 70
                    }
                    // 손가락 밑에는 아이콘만 따라온다 (이름 글씨는 따라오지 않는다)
                    armDrag(cell, item.id, trayIcon)
                    cell.addView(trayIcon)
                    cell.addView(TextView(this).apply {
                        text = item.label
                        textSize = 11f
                        gravity = Gravity.CENTER
                        maxLines = 2
                        setTextColor(onVar)
                        setPadding(dp(2), dp(4), dp(2), 0)
                    })
                    iconViews[item.id] = cell
                    row.addView(cell)
                }
                for (k in chunk.size until curCols) row.addView(View(this), lp(0, 1, 1f))
                trayBox.addView(row)
            }
            root.addView(trayBox)

            animateWindowHeight(oldH)

            // 그리기 전과 달라진 자리로 버튼들이 미끄러지듯 옮겨 간다 (바 ↔ 아래 칸으로 이동할 때도 날아가듯)
            if (animOn && before.isNotEmpty()) {
                root.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        root.viewTreeObserver.removeOnPreDrawListener(this)
                        val loc = IntArray(2)
                        for ((id, v) in iconViews) {
                            v.getLocationInWindow(loc)
                            var old = before[id]
                            val dAt = dropAt
                            var liftScale = 1f
                            if (id == dropId && dAt != null) {
                                // 놓은 손가락 자리에서 제자리로 내려앉는다 (끌 때 키운 크기에서 원래 크기로)
                                val cy = if (v is LinearLayout) dp(25).toFloat() else v.height / 2f
                                old = intArrayOf((dAt[0] - v.width / 2f).toInt(), (dAt[1] - cy).toInt())
                                liftScale = 1.18f
                            }
                            if (old == null) {
                                v.scaleX = 0.6f; v.scaleY = 0.6f; v.alpha = 0f
                                v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220).setInterpolator(smooth).start()
                            } else {
                                val dx = (old[0] - loc[0]).toFloat()
                                val dy = (old[1] - loc[1]).toFloat()
                                if (dx != 0f || dy != 0f) {
                                    v.translationX = dx
                                    v.translationY = dy
                                    if (liftScale != 1f) {
                                        v.scaleX = liftScale; v.scaleY = liftScale
                                        v.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
                                            .setDuration(340).setInterpolator(android.view.animation.OvershootInterpolator(1.1f)).start()
                                    } else {
                                        v.animate().translationX(0f).translationY(0f).setDuration(300).setInterpolator(smooth).start()
                                    }
                                }
                            }
                        }
                        dropId = null; dropAt = null
                        return true
                    }
                })
            } else { dropId = null; dropAt = null }
        }
        renderFn = { render() }
        // 끌기가 끝나면(놓았든 취소했든) 흐려진 버튼 모양을 되돌리려고 한 번 더 그린다
        root.setOnDragListener { _, e ->
            if (e.action == DragEvent.ACTION_DRAG_ENDED) {
                val did = dragId
                if (!dropped && did != null) {
                    // 엉뚱한 곳에 놓았거나 취소했다: 끌기 전 배치로 되돌리고, 마지막 손가락 자리에서 제자리로 내려앉는다
                    left.clear(); left.addAll(snapLeft)
                    right.clear(); right.addAll(snapRight)
                    refresh = snapRefresh
                    dropId = did
                    dropAt = lastFinger
                }
                dragId = null
                dropped = false
                scheduleRender()
            }
            true
        }
        // 창 너비가 바뀌면(회전·분할 화면) 아래 칸 한 줄에 들어가는 버튼 수가 달라지므로 줄을 다시 나눈다
        scroll.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            if (r - l != lastScrollW) {
                lastScrollW = r - l
                if (trayCols() != curCols) scheduleRender()
            }
        }
        render()

        val dlg = ThemedDialogBuilder(this)
            .setTitle("상/하단바 버튼 편집")
            .setView(scroll)
            .setNegativeButton("취소", null)
            .setNeutralButton("기본값", null)
            .setPositiveButton("저장") { _, _ ->
                val out = mutableListOf<String>()
                out.addAll(left)
                if (refresh) out.add(TopBarConfig.INLINE_TOKEN)
                out.add(TopBarConfig.SEP)
                out.addAll(right)
                prefs.setTopBarIds(wide, out)
                refreshTopBarButtons()
                toast("상/하단바 버튼을 저장했어요")
            }
            .create()
        dlg.show()
        // '기본값' 은 창을 닫지 않고 미리보기만 기본 배치로 되돌린다 (저장을 눌러야 적용)
        dlg.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val defs = TopBarConfig.defaults(wide)
            val dl = TopBarConfig.splitIds(defs)
            left.clear(); left.addAll(dl.left)
            right.clear(); right.addAll(dl.right)
            refresh = dl.refreshInline
            dropId = null; dropAt = null
            render()
            toast("기본 배치로 되돌렸어요 · 저장을 눌러야 적용돼요")
        }
    }

    /** 넓은(태블릿) 레이아웃이면 상단 탭 스트립 + 툴바에 내비게이션, 아니면 폰 레이아웃(하단 바) */
    /** 폰 화면(좁은 창)이라 데스크톱 사이트 대신 모바일 사이트를 쓰는 중인지. 넓은 화면으로 돌아오면 원래 설정으로 복귀한다 */
    private var autoMobile = false
    private var siteModeWide: Boolean? = null

    /** 앱 화면이 폰 모양이 되면 모바일 사이트로, 넓은 모양이 되면 데스크톱 사이트로 */
    /** PiP 에 들어가 있었는지 (나올 때를 알아채려고) */
    private var wasInPip = false
    /** PiP 에서 막 나온 뒤 창 크기가 자리 잡을 때까지(이 시각 전까지) 모바일↔데스크톱 자동 전환을 미룬다 */
    private var pipSettleUntil = 0L

    /**
     * PiP 이거나 방금 나온 직후인지. PiP 에서 전체 화면으로 돌아오는 순간에는 시스템이 'PiP 아님' 을 먼저 알리고
     * 창 폭(screenWidthDp)은 아직 PiP 때의 작은 값으로 읽힐 때가 있다. 그 값으로 '폰 화면 → 모바일 사이트' 로 판단하면
     * 사이트가 모바일로 바뀌며 페이지가 새로 불러와지고, 폭이 제대로 오면 다시 데스크톱으로 바뀌며 또 불러와졌다.
     */
    private fun pipSettling(): Boolean {
        val now = android.os.SystemClock.uptimeMillis()
        if (isInPictureInPictureModeCompat()) { wasInPip = true; return true }
        if (wasInPip) { wasInPip = false; pipSettleUntil = now + 1500L }
        return now < pipSettleUntil
    }

    /** PiP 에서 나온 뒤 창 크기가 자리 잡은 다음, 그때의 실제 폭으로 한 번만 다시 판단한다 (폭이 그대로면 아무것도 안 바뀐다) */
    private val siteModeSettle = Runnable {
        if (isFinishing || isDestroyed || mirrorActive || isInPictureInPictureModeCompat()) return@Runnable
        syncSiteModeWithLayout(siteWideNow(wideForWindow()))
    }

    private fun syncSiteModeWithLayout(wide: Boolean) {
        // 설정에서 자동 전환을 끄면 창 크기가 바뀌어도 사이트 모드는 그대로 둔다 (직접 고른 모드 유지)
        if (!prefs.autoSiteMode) return
        if (pipSettling()) {
            // PiP 중이면 나올 때 처리하고, 방금 나왔으면 크기가 자리 잡은 뒤 다시 판단한다
            if (!isInPictureInPictureModeCompat()) {
                ui.removeCallbacks(siteModeSettle)
                ui.postDelayed(siteModeSettle, 1700L)
            }
            return
        }
        if (siteModeWide == wide) return
        siteModeWide = wide
        // 화면 모양이 바뀔 때마다 자동으로: 넓은 화면 = 데스크톱 사이트, 폰 화면 = 모바일 사이트.
        // (그 뒤에 직접 데스크톱/모바일 버튼을 누르면 다음에 모양이 바뀔 때까지 그 선택이 우선한다)
        autoMobile = false
        val want = wide
        prefs.desktopSite = want
        for (t in tabs) {
            if (t.desktop == want) continue
            t.desktop = want
            t.desktopInjected = false
            t.liveWebView?.let { applyUserAgent(it, want) }
            if (t === current && !t.isHome && t.pendingUrl == null) {
                val url = t.liveWebView?.url
                if (url != null && url != "about:blank" && url != HOME_URL) {
                    val target = if (want && url.startsWith("http")) toDesktopUrl(url) else url
                    carryPlaybackPosition(t, target)
                    if (target != url) t.webView.loadUrl(target) else reloadTab(t)
                }
            }
        }
        if (::tbDesktop.isInitialized) updateDesktopButton()
    }

    private fun applyLayoutMode(pip: Boolean = isInPictureInPictureModeCompat()) {
        val wide = wideForWindow()
        expanded = wide
        if (!pip && !mirrorActive) syncSiteModeWithLayout(siteWideNow(wide))
        lastCols = switcherCols()
        // 미러링(영상 창 가득 보기) 중에도 바를 다시 보이게 하면 안 된다
        if (mirrorActive) {
            tabStripBar.visibility = View.GONE
            toolbarView.visibility = View.GONE
            bottomBar.visibility = View.GONE
            progressBar.visibility = View.GONE
            return
        }
        // PiP 로 들어가면 화면 크기 변경 알림이 와서 이 함수가 불리는데, 그때 바를 다시 보이게 하면 안 된다
        if (pip && customView == null) {
            tabStripBar.visibility = View.GONE
            toolbarView.visibility = View.GONE
            bottomBar.visibility = View.GONE
            progressBar.visibility = View.GONE
            return
        }
        tabStripBar.visibility = if (wide) View.VISIBLE else View.GONE
        tbMenu.visibility = if (wide) View.VISIBLE else View.GONE
        // 상단바 버튼(뒤로·앞으로·새로고침·홈·탭 등)은 설정 > 상단바 버튼 편집에서 고른 대로 보인다
        applyTopBarButtons(wide)
        bottomBar.visibility = if (wide) View.GONE else View.VISIBLE
        urlBar.layoutParams = urlBar.layoutParams.apply { height = dp(if (wide) 40 else 44) }
        urlBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (wide) 16f else 15f)
        // 폰 → 태블릿: 탭 줄이 방금 보이게 돼서 아직 배치 전(폭 0)이다. 배치가 끝난 뒤 실제 폭으로 탭 크기를 다시 계산한다.
        if (wide) {
            tabStripScroll.doOnLayout {
                lastStripViewportW = tabStripScroll.width
                refreshTabStrip()
                updateStripPlus()
            }
        }
        // 탭 전환 화면이 열려 있으면 새 화면 폭에 맞춰 열 수·카드 크기를 다시 계산한다
        if (switcherOpen) refreshSwitcher(false)
        // 폰 ↔ 태블릿 전환 시 스크롤로 숨겨 둔 바를 모두 되돌린다 (남은 마진 때문에 바가 잘리는 것 방지)
        scrollBars.reset()
        ui.post { scrollBars.sync() }
        homeView.setPadding(0, 0, 0, 0)
        applyHideBars(animate = false)
        updateStatusBarColor()
        // 제목줄 통합 중이면 탭 줄이 보이는지에 따라 위 여백이 달라지므로 인셋을 다시 적용
        if (captionEdgeToEdge) (browserUi.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
    }

    // ───────────────────── 창 모드(프리폼) 제목줄 통합 ─────────────────────

    /**
     * 데스크톱/프리폼 창에서는 시스템이 제목줄(캡션 바)을 앱 위에 따로 그려서,
     * 탭 줄이 제목줄 아래 한 줄을 더 차지한다. 크롬처럼 탭 줄을 그 제목줄 자리에 그리도록
     * 캡션 바 인셋이 있을 때만 가장자리까지 그리기로 바꾼다. (폰·전체 화면에서는 아무것도 바뀌지 않는다)
     */
    private var captionEdgeToEdge = false
    private var captionActive = false
    private var captionTopApplied = -1
    private var captionStartApplied = -1
    private var captionEndApplied = -1

    /** 시스템 하단 내비게이션 영역을 투명하게: 색을 투명으로 하고, 시스템이 3버튼 내비게이션 뒤에 깔아 주는 반투명 막(대비 보정)도 끈다 */
    private fun makeNavBarTransparent() {
        try {
            @Suppress("DEPRECATION")
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= 29) {
                window.isNavigationBarContrastEnforced = false
                @Suppress("DEPRECATION")
                window.navigationBarDividerColor = android.graphics.Color.TRANSPARENT
            }
        } catch (_: Throwable) {}
    }

    private fun installCaptionIntegration() {
        makeNavBarTransparent()
        if (Build.VERSION.SDK_INT < 30) return
        // 카메라 구멍(컷아웃) 자리까지 화면을 쓸 수 있게 한다 (상태표시줄을 숨길 때 위쪽에 띠가 남지 않게)
        try {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        } catch (_: Throwable) {}
        // Android 15+ (targetSdk 35): 가장자리까지 그리기가 기본이라 처음부터 인셋을 직접 처리한다
        // Android 12~14 도 상태표시줄 자리에 블러를 깔려면 앱이 그 자리를 직접 그려야 하므로 같은 경로를 쓴다
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            captionEdgeToEdge = true
            enableCaptionEdgeToEdge()
            return
        }
        val decor = window.decorView
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(decor) { v, insets ->
            if (!captionEdgeToEdge &&
                insets.getInsets(WindowInsetsCompat.Type.captionBar()).top > 0
            ) {
                captionEdgeToEdge = true
                v.post { enableCaptionEdgeToEdge() }
            }
            androidx.core.view.ViewCompat.onApplyWindowInsets(v, insets)
        }
    }

    private fun enableCaptionEdgeToEdge() {
        val decor = window.decorView
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(decor, null)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        makeNavBarTransparent()
        // 데스크톱 창 제목줄을 투명하게 만들어야(APPEARANCE_TRANSPARENT_CAPTION_BAR_BACKGROUND = 1 shl 7, Android 15+)
        // 앱이 제목줄 자리에 그릴 수 있고 캡션 바 인셋도 들어온다. 탭 줄 배경이 밝으면 시스템 버튼은 어두운 색
        // (APPEARANCE_LIGHT_CAPTION_BARS = 1 shl 8).
        try {
            val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
            val transparent = 1 shl 7
            val light = 1 shl 8
            window.insetsController?.setSystemBarsAppearance(
                transparent or (if (night) 0 else light), transparent or light
            )
        } catch (_: Throwable) {}

        val root = findViewById<View>(R.id.browserUi)?.parent as? View ?: return
        // 루트의 위/아래 여백(상태표시줄·내비게이션 바 자리)에 걸쳐 있는 자식도 그려지게 한다.
        // 기본값(clipToPadding)이면 스크롤로 올라온 웹 영역이 상태표시줄 자리에서 잘려 그 자리가 계속 남는다.
        (root as? android.view.ViewGroup)?.let { it.clipToPadding = false; it.clipChildren = false }
        (findViewById<View>(R.id.browserUi) as? android.view.ViewGroup)?.clipChildren = false
        statusBand = StatusBandDrawable(getColor(R.color.ev_surface), getColor(R.color.ev_surface)).also { root.background = it }
        // Android 14 이하에서는 시스템이 칠하는 불투명 상태표시줄이 블러를 가리므로 투명하게 한다 (35+ 는 원래 무시됨)
        @Suppress("DEPRECATION")
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        updateStatusBarColor()
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val cap = insets.getInsets(WindowInsetsCompat.Type.captionBar())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // 제목줄이 있으면 위 여백은 0: 탭 줄이 그 자리를 쓴다. 없으면(전체 화면 등) 보통 시스템 바 여백.
            val stripInCaption = cap.top > 0 && captionHasWindowControls(insets, v.width, cap.top) &&
                tabStripBar.visibility == View.VISIBLE
            // 바 숨김으로 상태표시줄을 숨긴 동안에는 위쪽은 시스템 바 여백(0)만 쓴다.
            // 컷아웃 여백까지 더하면 상태표시줄이 사라진 자리에 빈 띠가 남는다.
            val topInset = if (statusBarHiddenByHideBars && barsHiddenNow)
                maxOf(insets.getInsets(WindowInsetsCompat.Type.systemBars()).top, cap.top)
            // 스크롤로 상태표시줄을 숨기고 보이는 동안에는 '보일 때의 높이'를 계속 쓴다. 시스템이 숨김/표시 도중에
            // 인셋을 0 이나 중간값으로 보내면 위 여백이 바뀌어 레이아웃이 밀리고 페이지가 저절로 스크롤된다.
            else if ((statusBarHiddenByScroll || scrollBars.fraction > 0f) && customView == null)
                maxOf(
                    insets.getInsetsIgnoringVisibility(WindowInsetsCompat.Type.systemBars()).top,
                    insets.getInsets(WindowInsetsCompat.Type.displayCutout()).top,
                    // 제목줄(창 버튼) 높이는 '숨겨도 그대로'이므로 지금 알려 온 값 아래로 내려가지 않게 한다
                    sys.top,
                    cap.top
                )
            else sys.top
            val top = if (stripInCaption) 0 else topInset
            // 유튜브: 키보드가 올라와도 웹 영역 크기를 줄이지 않는다.
            // 줄이면 페이지가 '화면 높이가 바뀌었다'고 보고 사이트·영상 비율을 다시 짜기 때문이다.
            // 대신 키보드는 페이지 위에 겹치게 두고, 입력칸이 가려질 때만 웹 영역을 위로 살짝 민다.
            val imeFrozen = ime.bottom > 0 && isYouTubeUrl(current?.liveWebView?.url)
            navBottomInset = if (ime.bottom > sys.bottom) 0 else sys.bottom
            capInsetTop = cap.top
            // 미러링(영상 창 가득 보기): 영상이 카메라(노치) 자리까지 가득 차도록 창 여백을 두지 않는다
            // (화면 비율을 '채우기'·'늘리기'로 바꿨을 때 카메라 자리만 검은 띠로 남던 것을 막는다).
            // 제목줄(창 버튼)이 있는 팝업 창만 그 높이를 비워 두고, 컨트롤은 카메라 자리를 직접 피해 놓는다.
            if (mirrorActive) {
                v.setPadding(0, cap.top, 0, 0)
                updateImePan(0)
                statusBand?.h = cap.top
                mirrorOverlay?.setInsets(
                    sys.left, if (cap.top > 0) 0 else sys.top, sys.right, sys.bottom
                )
                return@setOnApplyWindowInsetsListener WindowInsetsCompat.CONSUMED
            }
            v.setPadding(sys.left, top, sys.right, if (imeFrozen) sys.bottom else maxOf(sys.bottom, ime.bottom))
            updateImePan(if (imeFrozen) ime.bottom else 0)
            statusBand?.h = top
            switcherStatusTop = top
            applySwitcherStatusExtend()
            applyCaptionToStrip(if (stripInCaption) cap.top else 0)
            // 탭 목록 화면은 제목줄(시스템 버튼) 아래에서 시작하도록 그 높이만큼 위 여백을 준다
            applySwitcherCaptionInset(if (stripInCaption) cap.top else 0)
            WindowInsetsCompat.CONSUMED
        }
        androidx.core.view.ViewCompat.requestApplyInsets(root)
    }

    private var switcherStatusTop = 0

    /**
     * 테마 그림이 깔린 탭 화면은 바탕(새 탭 배경·탭바 그림)이 상태표시줄 자리까지 이어지게 위로 그만큼 넓히고 안쪽 여백으로 내용을 되돌린다.
     * (예전에는 상태표시줄 자리만 단색 띠로 따로 칠해져 탭 화면 바탕과 끊겨 가려진 것처럼 보였다)
     */
    private fun applySwitcherStatusExtend() {
        if (!::tabSwitcher.isInitialized) return
        val ext = if (switcherThemed() && !switcherCaptionOn) switcherStatusTop else 0
        val lp = tabSwitcher.layoutParams as? FrameLayout.LayoutParams ?: return
        if (lp.topMargin != -ext || tabSwitcher.paddingTop != ext) {
            lp.topMargin = -ext
            tabSwitcher.setPadding(tabSwitcher.paddingLeft, ext, tabSwitcher.paddingRight, tabSwitcher.paddingBottom)
            tabSwitcher.layoutParams = lp
        }
    }

    private var imePanH = 0

    /**
     * 키보드(높이 imeH)가 웹 영역 크기를 바꾸지 않고 위에 겹쳐 있을 때, 포커스된 입력칸이 키보드에 가려지면
     * 웹 영역을 가려진 만큼(최대 키보드 높이) 위로 민다. imeH 가 0 이면 원래 자리로 되돌린다.
     */
    private fun updateImePan(imeH: Int) {
        if (imeH == imePanH) return
        imePanH = imeH
        if (imeH <= 0) {
            webContainer.animate().translationY(0f).setDuration(150).start()
            return
        }
        val web = current?.liveWebView ?: return
        val js = "(function(){var e=document.activeElement;if(!e||e===document.body||e===document.documentElement)return -1;" +
            "var r=e.getBoundingClientRect();return r.bottom/window.innerHeight;})()"
        fun measure() {
            if (imePanH != imeH) return
            web.evaluateJavascript(js) { raw ->
                if (imePanH != imeH) return@evaluateJavascript
                val frac = raw?.trim('"')?.toFloatOrNull() ?: return@evaluateJavascript
                if (frac < 0f) return@evaluateJavascript
                val loc = IntArray(2)
                web.getLocationOnScreen(loc)
                val elemBottom = loc[1] - webContainer.translationY + frac * web.height
                val kbTop = web.rootView.height - imeH
                val margin = 16f * resources.displayMetrics.density
                val need = (elemBottom + margin - kbTop).coerceIn(0f, imeH.toFloat())
                webContainer.animate().translationY(-need).setDuration(150).start()
            }
        }
        web.postDelayed({ measure() }, 150)
        web.postDelayed({ measure() }, 450)
    }

    /**
     * 팝업 창의 제목줄 방식: 창 버튼(최소화·최대화·닫기)이 있는 일반 제목줄이면 true, 가운데 손잡이만 있는 얇은 방식이면 false.
     * 삼성 인터넷처럼 일반 제목줄일 때만 탭을 제목줄 안에 넣고, 손잡이 방식이면 탭 줄을 그 아래에 보통대로 둔다.
     * 시스템이 알려주는 시스템 요소 위치(getBoundingRects)에 오른쪽 요소가 있으면 일반 제목줄,
     * 알려주지 않으면 제목줄 높이(32dp 이상)로 판단한다.
     */
    private fun captionHasWindowControls(insets: WindowInsetsCompat, width: Int, capTop: Int): Boolean {
        val byHeight = capTop >= dp(32)
        if (Build.VERSION.SDK_INT < 30 || width <= 0) return byHeight
        return try {
            val wi = insets.toWindowInsets() ?: return byHeight
            val m = android.view.WindowInsets::class.java.getMethod("getBoundingRects", Int::class.javaPrimitiveType)
            val rects = (m.invoke(wi, android.view.WindowInsets.Type.captionBar()) as? List<*>)
                ?.filterIsInstance<Rect>()?.filter { it.width() > 0 } ?: return byHeight
            if (rects.isEmpty()) byHeight else rects.any { it.centerX() > width * 0.6f }
        } catch (_: Throwable) { byHeight }
    }

    private var switcherCaptionOn = false
    private var switcherCaptionTop = 0

    /**
     * 팝업/데스크톱 창에서 탭 목록 헤더("모두 닫기")가 오른쪽 시스템 창 버튼(…, 최소화, 최대화, 닫기)과 겹치지 않게 한다.
     * 화면 전체를 아래로 밀면 카드 자리가 바뀌어 열고 닫는 전환이 어색해지므로, 세로 위치는 그대로 두고
     * 헤더의 오른쪽 여백만 시스템 버튼 폭만큼 늘린다.
     */
    private fun applySwitcherCaptionInset(top: Int) {
        switcherCaptionOn = top > 0
        switcherCaptionTop = top
        if (!::tabSwitcher.isInitialized) return
        val header = tabSwitcher.findViewById<View>(R.id.switcherHeader) ?: return
        // 팝업/데스크톱 창: 이전 버튼·"탭"·"모두 닫기"가 시스템 버튼(…, 최소화, 최대화, 닫기) 줄에 겹치지 않게
        // 제목줄 높이만큼 헤더를 아래로 내린다. 오른쪽 여백은 겹칠 일이 없으니 기본값.
        val pt = if (switcherCaptionOn) top else 0
        val lp = header.layoutParams
        val h = dp(56) + pt
        if (header.paddingTop != pt || header.paddingEnd != dp(8) || lp.height != h) {
            header.setPadding(header.paddingLeft, pt, dp(8), header.paddingBottom)
            lp.height = h
            header.layoutParams = lp
        }
    }

    private var captionTouchInstalled = false

    /**
     * 제목줄 영역의 터치는 기본적으로 시스템이 창 이동용으로 가져간다. 탭·+ 버튼이 있는 부분만
     * setSystemGestureExclusionRects 로 앱이 터치(탭 선택·스크롤)를 받게 하고, 나머지 빈 곳은 창 끌기용으로 남긴다.
     */
    private fun installCaptionTouchRegion() {
        if (captionTouchInstalled) return
        captionTouchInstalled = true
        val l = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateCaptionTouchRegion() }
        tabStripBar.addOnLayoutChangeListener(l)
        tabStrip.addOnLayoutChangeListener(l)
        tabStripScroll.addOnLayoutChangeListener(l)
        findViewById<View>(R.id.btnStripTabList)?.addOnLayoutChangeListener(l)
    }

    /**
     * 제목줄 안에서 앱이 터치를 받아야 하는 곳(탭 줄·새 탭(+)·탭 목록 버튼)을 시스템에 알린다.
     * 예전에는 탭 줄만 알려서 오른쪽 탭 목록 버튼이 시스템에 먹혔다. 이제 보이는 버튼마다 따로 알리고,
     * 창을 옮기거나 크기를 바꾼 뒤에도 시스템이 값을 잃지 않도록 다시 걸어 준다.
     */
    private fun updateCaptionTouchRegion(force: Boolean = false) {
        if (Build.VERSION.SDK_INT < 29) return
        val rects = ArrayList<Rect>()
        if (captionActive && tabStripBar.height > 0 && tabStripScroll.width > 0) {
            val h = tabStripBar.height
            // 좌표는 모두 tabStripBar 기준. (제목줄 안에서는 바 왼쪽에 시스템 아이콘 자리 padding 이 있어서
            // 스크롤 뷰의 left 만 쓰면 영역이 그만큼 왼쪽으로 밀려 + 버튼이 시스템에 먹힌다)
            fun rectOf(v: View, pad: Int): Rect {
                var x = v.left + v.translationX.toInt()
                var p = v.parent as? View
                while (p != null && p !== tabStripBar) { x += p.left; p = p.parent as? View }
                return Rect(x - pad, 0, x + v.width + pad, h)
            }
            val scrollRect = rectOf(tabStripScroll, 0)
            val contentW = tabStripScroll.paddingStart + tabStrip.width
            rects.add(Rect(scrollRect.left, 0, scrollRect.left + minOf(contentW, tabStripScroll.width), h))
            // 새 탭(+) 버튼: 마지막 탭 옆을 따라 움직이므로 지금 실제 위치로 알린다
            findViewById<View>(R.id.stripPlusHolder)?.takeIf { it.width > 0 }?.let { rects.add(rectOf(it, dp(2))) }
            findViewById<View>(R.id.btnStripTabList)?.takeIf { it.visibility == View.VISIBLE && it.width > 0 }?.let {
                rects.add(rectOf(it, dp(4)))
            }
        }
        if (force || tabStripBar.systemGestureExclusionRects != rects) tabStripBar.systemGestureExclusionRects = rects
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) reapplyStatusBarHidden()
        // 창이 비활성이 되면 테마의 frame_inactive 로 탭바를 바꾼다. 대화상자가 잠깐 포커스를 가져가는 깜박임은 걸러 내려고 잠시 뒤에 확인한다
        if (themeSpec?.hasInactiveFrame == true || winInactive) {
            ui.removeCallbacks(focusFrameTask)
            ui.postDelayed(focusFrameTask, if (hasFocus) 0L else 250L)
        }
        // 팝업 창을 끌거나 크기를 바꾸면 시스템이 제목줄 터치 영역을 비울 수 있어서 다시 알린다
        if (captionActive) tabStripBar.post { updateCaptionTouchRegion(force = true) }
    }

    /**
     * 캡션 높이(px)에 맞춰 탭 줄 높이·탭 위치·좌우 비움 폭을 정한다. capTop = 0 이면 원래 모양으로 되돌린다.
     * 탭 줄 높이는 제목줄 높이와 똑같이 해서 탭의 세로 가운데가 시스템 버튼의 가운데와 같게 한다.
     * 좌우 비움 폭은 시스템 아이콘·메뉴(왼쪽)와 최소화·최대화·닫기 버튼(오른쪽)이 실제로 차지하는 폭에 맞춘 값이다.
     */
    private fun applyCaptionToStrip(capTop: Int) {
        val inCaption = capTop > 0
        val h = if (inCaption) maxOf(capTop, dp(32)) else dp(44)
        // 탭 위쪽 여백: 기본 6dp, 제목줄 안에서는 2dp (탭 높이는 최대 42dp)
        val pt = if (inCaption) maxOf(dp(2), h - dp(42)) else dp(6)
        val start = if (inCaption) dp(68) else 0
        // 오른쪽 비움: 시스템 버튼(메뉴·최소화·최대화·닫기)이 실제로 차지하는 폭 + 여유.
        // 여유가 모자라면 오른쪽 끝에 멈춘 + 버튼이 시스템 버튼의 터치 영역과 겹쳐 눌리지 않았다
        val end = if (inCaption) dp(208) else 0
        if (h == captionTopApplied && start == captionStartApplied && end == captionEndApplied) return
        captionTopApplied = h; captionStartApplied = start; captionEndApplied = end
        val captionChanged = captionActive != inCaption
        captionActive = inCaption
        // 숨길 바 목록이 바뀌므로 이미 올라가 있던 바를 되돌린다
        if (captionChanged && ::webContainer.isInitialized) {
            scrollBars.reset()
            ui.post { scrollBars.sync() }
        }

        // 제목줄 안의 탭 줄은 주소창보다 위에 그린다: 스크롤로 주소창이 위로 숨을 때 탭 줄(=시스템 버튼 자리)을 덮지 않고 그 뒤로 들어가게
        tabStripBar.translationZ = if (inCaption) 1f else 0f
        tabStripBar.layoutParams = tabStripBar.layoutParams.apply { height = h }
        tabStripBar.setPadding(start, 0, end, 0)
        tabStripScroll.setPadding(tabStripScroll.paddingLeft, pt, tabStripScroll.paddingRight, 0)
        // + 버튼·탭 목록 버튼은 탭과 같은 세로 가운데. center_vertical 에 위 여백 m 을 주면 중심이 (바 높이 + m)/2 라서,
        // 탭 영역(위 여백 pt 를 뺀 나머지)의 중심 (바 높이 + pt)/2 와 맞추려면 m = pt (기본 6dp)
        // 풀스크린(기본 모양)은 예전 값(pt - 3dp)을 그대로 두고, 제목줄 안에 들어간 팝업 창에서만 pt 로 맞춘다
        val plusTop = if (inCaption) pt else pt - dp(3)
        for (id in intArrayOf(R.id.btnStripNewTab, R.id.btnStripTabList)) {
            val v = findViewById<View>(id) ?: continue
            (v.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.topMargin = plusTop; v.layoutParams = it }
        }
        installCaptionTouchRegion()
        updateCaptionTouchRegion()
        browserUi.post {
            if (expanded) {
                tabStripScroll.doOnLayout {
                    lastStripViewportW = tabStripScroll.width
                    refreshTabStrip()
                    updateStripPlus()
                }
            }
            scrollBars.reapply()
        }
    }

    private var statusBarAnim: android.animation.ValueAnimator? = null

    private var bandAnim: android.animation.ValueAnimator? = null
    private var statusBand: StatusBandDrawable? = null

    /** 바탕색으로 채우고, 맨 위 h px 만 band 색으로 덮는 배경 (상태표시줄 자리를 탭 줄/주소창 색과 맞추기 위해) */
    private class StatusBandDrawable(var base: Int, var band: Int) : android.graphics.drawable.Drawable() {
        /** 테마 그림(탭바/툴바 배경 그림)을 상태표시줄 자리에도 이어서 깐다 */
        var overlay: android.graphics.drawable.Drawable? = null
        var h = 0
            set(v) { if (field != v) { field = v; invalidateSelf() } }
        private val paint = android.graphics.Paint()
        override fun draw(canvas: android.graphics.Canvas) {
            val b = bounds
            paint.color = base
            canvas.drawRect(b, paint)
            if (h > 0) {
                paint.color = band
                canvas.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), (b.top + h).toFloat(), paint)
                overlay?.let { o ->
                    val n = canvas.save()
                    canvas.clipRect(b.left, b.top, b.right, b.top + h)
                    o.setBounds(b.left, b.top, b.right, b.top + h)
                    o.draw(canvas)
                    canvas.restoreToCount(n)
                }
            }
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = android.graphics.PixelFormat.OPAQUE
    }

    /** 상태표시줄을 화면 맨 위에 있는 영역(탭바 / 주소창 / 탭 목록)의 배경색과 똑같이 맞춘다. */
    private fun updateStatusBarColor(switcher: Boolean = switcherOpen) {
        // 전체화면 영상·미러링 중에는 상태표시줄 자리도 검정으로 둔다 (PiP 에서 돌아올 때 화면 크기 변경 알림으로 이 함수가 불려도 하얗게 바뀌지 않게)
        val videoFull = customView != null || mirrorActive
        val th = themeSpec
        // 테마 그림(새 탭 배경·탭바 그림)이 깔린 탭 화면은 상태표시줄 자리도 그 바탕과 같은 색이어야 한다 (탭 화면 바탕이 상태표시줄 아래까지 이어진다)
        val swThemed = switcher && switcherThemed()
        // 색만 바꾼 테마이고 블러가 꺼진 탭 화면: 바탕은 테마가 입힌 표면색이므로 상태표시줄 자리도 그 색으로 맞춘다
        val plainSw = th != null && switcher && !switcherGlass() && !switcherThemed() && ::tabSwitcher.isInitialized
        val themedTop = if (th != null && !videoFull && !barsHiddenNow)
            (if (swThemed) ColorUtils.setAlphaComponent(if (th.hasNtp) (th.ntpBg ?: th.toolbar) else th.frame, 255)
             else if (plainSw) ColorUtils.setAlphaComponent(ThemeColors.get(tabSwitcher, com.google.android.material.R.attr.colorSurfaceContainer, 0xFFF7F8FA.toInt()), 255)
             else if (expanded) themeFrameColor(th) else th.toolbar) else null
        val target = if (videoFull) android.graphics.Color.BLACK else themedTop ?: getColor(
            when {
                // 탭 목록 화면 배경. 단 블러가 켜져 있으면 바로 아래에 흐려진 페이지(탭 줄/주소창)가 보이므로,
                // 상태표시줄 자리도 그 색을 그대로 둬야 흰 띠로 튀지 않고 이어져 보인다.
                switcher && !switcherGlass() -> R.color.ev_bg
                barsHiddenNow -> R.color.ev_surface   // 바를 숨기면 페이지 위가 곧 상태표시줄 자리
                expanded -> R.color.ev_pill_high   // 태블릿 상단 탭바 배경
                else -> R.color.ev_surface         // 폰 상단 주소창 배경
            }
        )
        // 테마 색 위에서도 상태표시줄 아이콘(시계·배터리)이 보이게 밝기에 맞춘다
        if (themedTop != null) {
            themedStatusIcons = true
            try { WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = ColorUtils.calculateLuminance(themedTop) > 0.5 } catch (e: Exception) { }
        } else if (themedStatusIcons && !videoFull) {
            themedStatusIcons = false
            try { WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = !systemNight() } catch (e: Exception) { }
        }
        // targetSdk 35 에서는 window.statusBarColor 가 무시되므로, 상태표시줄 자리는 루트 배경의 윗부분을 직접 칠한다
        statusBand?.let { b ->
            // 테마 그림이 있으면 상태표시줄 자리에도 같은 그림을 깐다 (탭바는 그림인데 위만 색 하나로 보이지 않게)
            val ov: android.graphics.drawable.Drawable? = if (themedTop == null || swThemed || plainSw) null else if (expanded) {
                val layers = listOfNotNull(themeTileDrawable(th?.let { themeFrameImage(it) }), themeTileDrawable(th?.let { themeFrameOverlay(it) }))
                when (layers.size) { 0 -> null; 1 -> layers[0]; else -> android.graphics.drawable.LayerDrawable(layers.toTypedArray()) }
            } else themeTileDrawable(th?.toolbarImage)
            if (b.overlay != null || ov != null) { b.overlay = ov; b.invalidateSelf() }
            if (themedTop != null) {
                // 테마 색은 애니메이션 없이 바로 맞춘다 (중간 색에서 멈춰 어둡게 남는 일이 없게)
                bandAnim?.cancel()
                if (b.band != target) { b.band = target; b.invalidateSelf() }
            } else if (b.band != target) {
                bandAnim?.cancel()
                bandAnim = android.animation.ValueAnimator.ofArgb(b.band, target).apply {
                    duration = 180
                    addUpdateListener { b.band = it.animatedValue as Int; b.invalidateSelf() }
                    start()
                }
            }
        }
        if (statusBand != null) return   // 밴드가 상태표시줄 자리를 그리므로 시스템 색은 투명 그대로 둔다
        if (window.statusBarColor == target) return
        statusBarAnim?.cancel()
        statusBarAnim = android.animation.ValueAnimator.ofArgb(window.statusBarColor, target).apply {
            duration = 180
            addUpdateListener { window.statusBarColor = it.animatedValue as Int }
            start()
        }
    }

    /**
     * 이 창의 탭 개수·제목 등이 바뀌었을 때, 탭 화면을 열어 둔 다른 창들의 '창 목록'도 다시 그리게 한다.
     * (예전에는 onResume 에서만 갱신해서, 분할 화면·프리폼처럼 여러 창이 동시에 보일 때 반영되지 않았다)
     */
    private fun notifyOtherWindows() {
        instances.toList().forEach { a -> if (a !== this) a.queueWindowStripRefresh() }
    }

    /** 탭 화면이 열려 있으면 창 목록을 (한 번에 몰아서) 다시 그린다. 카드를 끄는 중이면 끝난 뒤로 미룬다 */
    private fun queueWindowStripRefresh() {
        if (windowStripQueued || !switcherOpen || isFinishing || isDestroyed) return
        windowStripQueued = true
        ui.postDelayed(object : Runnable {
            override fun run() {
                if (!switcherOpen || isFinishing || isDestroyed) { windowStripQueued = false; return }
                if (swDrag != null || wsDragView != null) { ui.postDelayed(this, 300); return }
                windowStripQueued = false
                refreshWindowStrip()
            }
        }, 80)
    }

    private fun scheduleStripRefresh() {
        notifyOtherWindows()
        if (!expanded || stripRefreshQueued) return
        stripRefreshQueued = true
        ui.post {
            stripRefreshQueued = false
            refreshTabStrip()
        }
    }

    /** 상단 탭바의 탭 하나 (뷰를 재사용하면서 제목·아이콘·선택 상태만 바꾼다) */
    private class StripChip(val view: View, val tab: BrowserTab) {
        val title: TextView = view.findViewById(R.id.stripTitle)
        val icon: ImageView = view.findViewById(R.id.stripIcon)
        val bar: View = view.findViewById(R.id.stripGroupBar)
        var bg: android.graphics.drawable.Drawable? = null
        var width = 0
        var selected = false
        var selFraction = 0f
        var iconKey: Any? = null
        var iconKind: String? = null   // 아이콘 종류가 바뀔 때만 살짝 페이드 (같은 종류의 파비콘 교체는 조용히)
        var following = false
        var widthAnim: android.animation.ValueAnimator? = null
        var selAnim: android.animation.ValueAnimator? = null
    }

    private val stripChips = HashMap<BrowserTab, StripChip>()
    private val stripPills = HashMap<Int, TextView>()
    private var stripReady = false
    private val stripEase by lazy { android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f) }

    private fun setViewWidth(v: View, w: Int) {
        val lp = v.layoutParams ?: return
        if (lp.width != w) {
            lp.width = w
            v.layoutParams = lp
        }
    }

    private fun animateChipWidth(c: StripChip, to: Int, animate: Boolean) {
        c.widthAnim?.cancel()
        c.width = to
        val from = c.view.layoutParams.width
        if (!animate || from == to) {
            setViewWidth(c.view, to)
            c.following = false
            return
        }
        c.widthAnim = android.animation.ValueAnimator.ofInt(from, to).apply {
            duration = 280
            interpolator = stripEase
            addUpdateListener {
                setViewWidth(c.view, it.animatedValue as Int)
                if (c.following) ensureStripVisible(c, false)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    c.following = false
                }
            })
            start()
        }
    }

    private fun applyChipSelection(c: StripChip) {
        c.bg?.alpha = (255 * c.selFraction).toInt()
        c.title.setTextColor(
            androidx.core.graphics.ColorUtils.blendARGB(
                stripFgUnsel ?: getColor(R.color.ev_muted), stripFgSel ?: getColor(R.color.ev_text), c.selFraction
            )
        )
        updateStripDividers()
    }

    /** 활성 탭 바로 왼쪽 탭의 오른쪽 구분선을 지운다 (선택 애니메이션에 맞춰 서서히) */
    private fun updateStripDividers() {
        if (!::tabStrip.isInitialized) return
        val byView = HashMap<View, StripChip>()
        for (ch in stripChips.values) byView[ch.view] = ch
        for (i in 0 until tabStrip.childCount) {
            val me = byView[tabStrip.getChildAt(i)] ?: continue
            // 크롬 테마: 활성 탭의 오목하게 퍼진 양끝 때문에 이웃 탭과 멀어 보이지 않게, 탭들을 서로 살짝 겹쳐 붙인다.
            // 모든 탭에 똑같이 줘야 탭을 바꿀 때 밀려 움직이지 않는다. 맨 앞 탭은 왼쪽 꼬리가 잘리지 않게 왼쪽은 겹치지 않는다
            (me.view.layoutParams as? ViewGroup.MarginLayoutParams)?.let { lp ->
                val ov = if (themeSpec?.chromeTabs == true) dp(8) else 0
                val startM = if (i == 0) 0 else -ov
                val endM = dp(2) - ov
                if (lp.marginStart != startM || lp.marginEnd != endM) {
                    lp.marginStart = startM; lp.marginEnd = endM
                    me.view.layoutParams = lp
                }
            }
            val next = if (i + 1 < tabStrip.childCount) byView[tabStrip.getChildAt(i + 1)] else null
            (me.bg as? ThemeTabDrawable)?.dividerFade = 1f - (next?.selFraction ?: 0f)
        }
    }

    private fun animateChipSelection(c: StripChip, selected: Boolean, animate: Boolean) {
        c.selAnim?.cancel()
        c.selected = selected
        val to = if (selected) 1f else 0f
        if (!animate) {
            c.selFraction = to
            applyChipSelection(c)
            return
        }
        c.selAnim = android.animation.ValueAnimator.ofFloat(c.selFraction, to).apply {
            duration = 220
            interpolator = stripEase
            addUpdateListener {
                c.selFraction = it.animatedValue as Float
                applyChipSelection(c)
            }
            start()
        }
    }

    /** 탭(또는 그룹 알약)을 폭을 줄이며 사라지게 한 뒤 떼어낸다. 오른쪽 탭들이 부드럽게 왼쪽으로 당겨진다. */
    private fun retireStripView(v: View, c: StripChip?, animate: Boolean) {
        c?.widthAnim?.cancel()
        c?.selAnim?.cancel()
        c?.following = false
        if (!animate || v.parent == null || v.width == 0) {
            tabStrip.removeView(v)
            return
        }
        v.isEnabled = false
        v.isClickable = false
        v.isLongClickable = false
        v.animate().alpha(0f).setDuration(170).start()
        setViewWidth(v, v.width)
        android.animation.ValueAnimator.ofInt(v.width, 0).apply {
            duration = 260
            interpolator = stripEase
            addUpdateListener { setViewWidth(v, it.animatedValue as Int) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    tabStrip.removeView(v)
                }
            })
            start()
        }
    }

    /** 탭이 가려지지 않게 스크롤 (이미 다 보이면 가만히 둔다) */
    private fun ensureStripVisible(c: StripChip, smooth: Boolean) {
        val vw = tabStripScroll.width
        if (vw <= 0) return
        val sx = tabStripScroll.scrollX
        val left = c.view.left
        val right = left + maxOf(c.width, c.view.width)
        val pad = dp(28)
        val target = when {
            left - pad < sx -> left - pad
            right + pad > sx + vw -> right + pad - vw
            else -> return
        }.coerceAtLeast(0)
        if (smooth) tabStripScroll.smoothScrollTo(target, 0) else tabStripScroll.scrollTo(target, 0)
    }

    private fun bindStripChip(tab: BrowserTab, group: TabGroup?, width: Int, animate: Boolean): View {
        var c = stripChips[tab]
        val isNew = c == null
        if (c == null) {
            val v = layoutInflater.inflate(R.layout.item_strip_tab, tabStrip, false)
            c = StripChip(v, tab)
            stripChips[tab] = c
            // 파비콘 모서리를 살짝 둥글게
            c.icon.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(4).toFloat())
                }
            }
            c.icon.clipToOutline = true
            c.bg = getDrawable(R.drawable.bg_strip_tab_selected)?.mutate()?.also { it.alpha = 0 }
            styleStripChip(c)
            v.background = c.bg
            v.setOnClickListener { if (tab !== current) selectTab(tab) }
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 탭 메뉴
            bindDragGesture(
                v, null,
                onStart = { x, y -> startStripDrag(tab, x, y) },
                onMove = { x, y -> stripRawX = x; stripRawY = y; updateStripDrag() },
                onEnd = { moved, canceled -> endStripDrag(moved, canceled) }
            )
            c.view.findViewById<ImageButton>(R.id.stripClose).setOnClickListener { closeTabUndoable(tab, quitIfLast = true) }
        }
        val chip = c

        // 제목: 홈(새 탭)이면 항상 "새 탭" — 이전 페이지 제목이 남아 있어도 쓰지 않는다
        val title = if (tab.isHome) "새 탭"
            else tab.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" && it != HOME_URL }
                ?: tab.liveWebView?.url?.takeIf { it != "about:blank" && it != HOME_URL }?.let { Uri.parse(it).host }
                ?: tabTitle(tab)
        if (chip.title.text.toString() != title) {
            chip.title.text = title
            if (animate && !isNew) {
                chip.title.alpha = 0.25f
                chip.title.animate().alpha(1f).setDuration(220).start()
            }
        }

        // 아이콘: 홈이면 잎사귀, 페이지면 파비콘(없으면 지구본)
        val fav = if (tab.isHome) null else tab.favicon
        val chromeHome = tab.isHome && !tab.incognito && themeSpec?.chromeTabs == true
        val samsungHome = tab.isHome && !tab.incognito && themeSpec?.samsungTabs == true
        val key: Any = if (tab.incognito) "incognito" else fav ?: if (chromeHome) "home_chrome" else if (samsungHome) "home_samsung" else if (tab.isHome) "home" else "globe"
        val kind = when {
            tab.incognito -> "incognito"
            fav != null -> "fav"
            chromeHome -> "home_chrome"
            samsungHome -> "home_samsung"
            tab.isHome -> "home"
            else -> "globe"
        }
        if (chip.iconKey != key) {
            val kindChanged = chip.iconKind != kind
            chip.iconKind = kind
            chip.iconKey = key
            chip.icon.imageTintList = if (tab.incognito)
                ThemeColors.get(chip.icon, com.google.android.material.R.attr.colorOnSurface)
                    .let { android.content.res.ColorStateList.valueOf(it) }
            else null
            when {
                tab.incognito -> chip.icon.setImageResource(R.drawable.ic_incognito)
                fav != null -> chip.icon.setImageBitmap(fav)
                chromeHome -> { chip.icon.setImageResource(R.drawable.ic_chrome_mono); chip.icon.imageTintList = homeIconTint() } // 크롬 테마: 크롬 모양 새 탭 아이콘
                samsungHome -> { chip.icon.setImageResource(R.drawable.ic_samsung_mono); chip.icon.imageTintList = homeIconTint() } // 삼성 테마: 행성 모양 새 탭 아이콘
                tab.isHome -> chip.icon.setImageResource(homeIconRes())
                else -> chip.icon.setImageResource(R.drawable.ic_globe)
            }
            // 사이트가 파비콘을 여러 번 보내도 통통 튀지 않게: 크기 변화·오버슛은 쓰지 않고,
            // 아이콘 종류가 바뀔 때(지구본 → 파비콘 등)만 부드럽게 페이드한다.
            chip.icon.animate().cancel()
            chip.icon.scaleX = 1f; chip.icon.scaleY = 1f
            if (animate && !isNew && kindChanged) {
                chip.icon.alpha = 0f
                chip.icon.animate().alpha(1f).setDuration(180).start()
            } else {
                chip.icon.alpha = 1f
            }
        }

        if (group != null) {
            chip.bar.visibility = View.VISIBLE
            chip.bar.background.mutate().setTint(group.color)
        } else {
            chip.bar.visibility = View.INVISIBLE
        }

        val sel = tab === current
        if (isNew) {
            chip.selected = sel
            chip.selFraction = if (sel) 1f else 0f
            applyChipSelection(chip)
        } else if (chip.selected != sel) {
            animateChipSelection(chip, sel, animate)
        }

        if (isNew) {
            chip.width = width
            if (animate) {
                chip.view.layoutParams.width = 0
                chip.view.alpha = 0f
                chip.following = sel
                chip.view.animate().alpha(1f).setStartDelay(50).setDuration(220).start()
                // 실제 너비 애니메이션은 뷰가 붙은 뒤 시작 (아래 refreshTabStrip 에서)
                chip.view.tag = width
            } else {
                chip.view.layoutParams.width = width
            }
        } else if (chip.width != width) {
            animateChipWidth(chip, width, animate)
        }
        return chip.view
    }

    private fun bindStripPill(group: TabGroup, animate: Boolean): View {
        var pill = stripPills[group.id]
        val isNew = pill == null
        if (pill == null) {
            pill = layoutInflater.inflate(R.layout.item_strip_group, tabStrip, false) as TextView
            stripPills[group.id] = pill
            pill.setOnClickListener {
                group.collapsed = !group.collapsed
                scheduleStripRefresh()
            }
            pill.setOnLongClickListener {
                showGroupMenu(group, false) { scheduleStripRefresh() }
                true
            }
            Motion.pressable(pill, 0.92f)
            if (animate) pill.alpha = 0f
        }
        val n = tabs.count { it.groupId == group.id }
        pill.text = if (group.collapsed) "${group.name} ($n)" else group.name
        pill.background.mutate().setTint(group.color)
        // 접힘/펼침이 바뀌면 알약이 톡 튀어 변화를 알려 준다
        val wasCollapsed = pill.tag as? Boolean
        if (wasCollapsed != null && wasCollapsed != group.collapsed && animate) Motion.pop(pill, 0.8f)
        pill.tag = group.collapsed
        if (isNew && animate) {
            pill.animate().alpha(1f).setDuration(220).start()
            Motion.pop(pill, 0.7f)
        }
        return pill
    }

    private var lastStripViewportW = 0

    private fun refreshTabStrip() {
        if (!expanded) return
        // 아직 배치 전이면 폭을 알 수 없다 (임의의 폭으로 만들면 비율이 틀어진다). 배치되면 레이아웃 리스너가 다시 부른다.
        if (tabStripScroll.width <= 0) return
        val animate = stripReady && tabStripScroll.width > 0 && Motion.enabled(this)

        val visible = tabs.count { val g = groupOf(it); g == null || !g.collapsed }

        // 탭 너비는 고정 범위(124~220dp)로 계산해서 지정 → 탭이 한없이 길어지지 않게 함.
        // 탭이 많으면 최소 너비로 줄고 스크롤, 적으면 최대 너비에서 멈춤.
        val avail = tabStripScroll.width - dp(60)
        val chipWidth = if (avail > 0) {
            (avail / maxOf(1, visible)).coerceIn(dp(124), dp(220))
        } else dp(180)

        val desired = ArrayList<View>()
        val keepTabs = HashSet<BrowserTab>()
        val keepPills = HashSet<Int>()
        tabs.toList().forEach { tab ->
            val group = groupOf(tab)
            if (group != null && keepPills.add(group.id)) desired.add(bindStripPill(group, animate))
            if (group != null && group.collapsed) return@forEach
            desired.add(bindStripChip(tab, group, chipWidth, animate))
            keepTabs.add(tab)
        }

        // 없어진 탭/그룹은 폭을 줄이며 사라지게
        stripChips.entries.toList().forEach { (t, c) ->
            if (t !in keepTabs) {
                stripChips.remove(t)
                retireStripView(c.view, c, animate)
            }
        }
        stripPills.entries.toList().forEach { (id, p) ->
            if (id !in keepPills) {
                stripPills.remove(id)
                retireStripView(p, null, animate)
            }
        }

        // 순서대로 배치 (새 뷰는 이전 뷰 바로 뒤에 끼우고, 순서가 어긋난 뷰만 옮긴다)
        var prev: View? = null
        for (v in desired) {
            if (v.parent == null) {
                tabStrip.addView(v, prev?.let { tabStrip.indexOfChild(it) + 1 } ?: 0)
            } else if (prev != null && tabStrip.indexOfChild(v) < tabStrip.indexOfChild(prev)) {
                tabStrip.removeView(v)
                tabStrip.addView(v, tabStrip.indexOfChild(prev) + 1)
            }
            prev = v
        }

        // 새로 생긴 탭: 폭 0 에서 목표 폭까지 자라나게
        stripChips.values.forEach { c ->
            val target = c.view.tag as? Int ?: return@forEach
            c.view.tag = null
            animateChipWidth(c, target, true)
        }

        // 선택한 탭이 바뀌었거나 새로 생겼을 때만 그 탭이 보이도록 스크롤 (직접 스크롤 중에는 건드리지 않음)
        val cur = current?.let { stripChips[it] }
        if (cur != null && lastStripCurrent !== current) {
            lastStripCurrent = current
            if (!cur.following) tabStripScroll.post { ensureStripVisible(cur, true) }
        }

        updateStripDividers()
        if (tabStripScroll.width > 0) stripReady = true
    }

    // ───────────────────────── 키보드 단축키 (태블릿 + 키보드) ─────────────────────────

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && handleShortcut(event)) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun handleShortcut(e: KeyEvent): Boolean {
        if (e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_T -> openNewTabAndFocus()
                KeyEvent.KEYCODE_W -> current?.let { closeTabUndoable(it, quitIfLast = true) }
                KeyEvent.KEYCODE_L -> focusUrlBar()
                KeyEvent.KEYCODE_F -> openFind()
                KeyEvent.KEYCODE_R -> current?.let { reloadTab(it) }
                KeyEvent.KEYCODE_D -> bookmarkCurrent()
                KeyEvent.KEYCODE_TAB -> cycleTab(if (e.isShiftPressed) -1 else 1)
                in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9 -> {
                    val target = if (e.keyCode == KeyEvent.KEYCODE_9) {
                        tabs.lastOrNull()
                    } else {
                        tabs.getOrNull(e.keyCode - KeyEvent.KEYCODE_1)
                    }
                    if (target != null) selectTab(target)
                }
                else -> return false
            }
            return true
        }
        if (e.isAltPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> navBack()
                KeyEvent.KEYCODE_DPAD_RIGHT -> navForward()
                else -> return false
            }
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_F5) {
            current?.let { reloadTab(it) }
            return true
        }
        return false
    }

    /** 주소창 입력 중 다른 화면 영역을 누르면 키보드와 입력 포커스를 함께 닫는다. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // 자동 스크롤 중 화면을 만지면 (설정에 따라) 잠깐 멈추거나 완전히 멈춘다
        autoScrollerInst?.onTouch(ev)
        // 메뉴·설정 팝업 옆 빈 영역을 누른 손가락은 끝까지 무시한다
        val dz = menuDeadZone
        val dzPopup = menuDeadZonePopup?.get()
        if (dz != null && dzPopup != null && dzPopup.isShowing) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                swallowingDeadZoneTouch = dz.contains(ev.rawX.toInt(), ev.rawY.toInt())
            }
            if (swallowingDeadZoneTouch) {
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                    swallowingDeadZoneTouch = false
                }
                return true
            }
        } else {
            swallowingDeadZoneTouch = false
        }
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && ::urlBar.isInitialized && urlBar.hasFocus()) {
            val rect = Rect()
            urlBar.getGlobalVisibleRect(rect)
            val outsideAddressBar = !rect.contains(ev.rawX.toInt(), ev.rawY.toInt())
            if (outsideAddressBar) hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun cycleTab(delta: Int) {
        if (tabs.size < 2) return
        val i = tabs.indexOf(current).coerceAtLeast(0)
        selectTab(tabs[(i + delta + tabs.size) % tabs.size])
    }

    /** 키보드를 내리고 입력창에서 포커스를 뺀다. (홈 화면에서 키보드가 저절로 뜨지 않게) */
    private fun hideKeyboard() {
        urlBar.dismissDropDown()
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    private fun focusUrlBar() {
        // 바를 숨겨 둔 상태면 주소창이 GONE 이라 포커스를 받지 못한다 → 입력이 끝날 때까지 바를 보여 준다
        if (barsHiddenNow) {
            barsTempShown = true
            applyHideBars()
        }
        urlBar.requestFocus()
        urlBar.selectAll()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(urlBar, InputMethodManager.SHOW_IMPLICIT)
    }

    // ───────────────────────── 탭 전환 화면 (전체 화면) ─────────────────────────

    private val thumbScale = 0.6f

    /**
     * 지금 보이는 페이지 영역을 **화면에 이미 그려진 픽셀 그대로** 복사해 온다 (PixelCopy).
     * 웹뷰를 소프트웨어 캔버스에 다시 그리면(아래 captureContent 의 draw) 사진이 찌그러지고 배치가 실제 화면과 조금 달라질 수 있다.
     * 탭 화면이 떠 있거나(그 위가 찍힘) 시크릿(FLAG_SECURE)처럼 복사가 안 되는 때는 null 을 돌려주고, 부른 쪽이 예전 방식으로 대신한다.
     * 복사가 끝날 때까지 잠깐(보통 수십 ms) 기다린다.
     */
    private fun capturePixels(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || switcherOpen) return null
        val area = webContainer.parent as? View ?: return null
        val w = area.width
        val h = area.height
        if (w <= 0 || h <= 0 || !area.isShown) return null
        var thread: android.os.HandlerThread? = null
        return try {
            val loc = IntArray(2)
            area.getLocationInWindow(loc)
            val src = Rect(loc[0], loc[1], loc[0] + w, loc[1] + h)
            val deco = window.decorView
            // 영역이 창 밖으로 걸쳐 있으면 일부만 찍히니 쓰지 않는다
            if (!src.intersect(0, 0, deco.width, deco.height) || src.width() != w || src.height() != h) return null
            val full = Bitmap.createBitmap(
                (w * thumbScale).toInt().coerceAtLeast(1),
                (h * thumbScale).toInt().coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            val latch = java.util.concurrent.CountDownLatch(1)
            val ok = java.util.concurrent.atomic.AtomicBoolean(false)
            val t = android.os.HandlerThread("ev-capture")
            t.start()
            thread = t
            android.view.PixelCopy.request(window, src, full, { result ->
                ok.set(result == android.view.PixelCopy.SUCCESS)
                latch.countDown()
            }, Handler(t.looper))
            latch.await(250, java.util.concurrent.TimeUnit.MILLISECONDS)
            if (!ok.get()) { full.recycle(); return null }
            // 탭마다 하나씩 들고 있으니 메모리를 아끼려고 예전과 같은 RGB_565 로 줄인다
            val small = full.copy(Bitmap.Config.RGB_565, false)
            full.recycle()
            small
        } catch (e: Throwable) {
            null
        } finally {
            thread?.quitSafely()
        }
    }

    /** 지금 보이는 페이지 영역(웹뷰 + 홈 화면)을 비트맵으로 찍는다. [pixels] 가 true 면 먼저 화면 픽셀 그대로 복사해 본다. */
    private fun captureContent(pixels: Boolean = false): Bitmap? {
        if (pixels) capturePixels()?.let { return it }
        val area = webContainer.parent as? View ?: return null
        val w = area.width
        val h = area.height
        if (w <= 0 || h <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(
                (w * thumbScale).toInt().coerceAtLeast(1),
                (h * thumbScale).toInt().coerceAtLeast(1),
                Bitmap.Config.RGB_565
            )
            val c = Canvas(bmp)
            c.drawColor(ThemeColors.get(area, com.google.android.material.R.attr.colorSurface))
            c.scale(thumbScale, thumbScale)
            area.draw(c)
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    /**
     * 메뉴 공유 카드용 미리보기. 웹뷰를 한 번 더 그리지 않고, 이미 화면에 그려진 픽셀을 PixelCopy 로 복사해 온다
     * (웹뷰를 직접 다시 그리면 메뉴가 뜰 때 페이지가 버벅인다). 복사가 안 되는 기기·상황에서만 예전 방식으로 대신한다.
     */
    private fun captureContentAsync(done: (Bitmap?) -> Unit) {
        val area = webContainer.parent as? View
        if (area == null || area.width <= 0 || area.height <= 0) { done(null); return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !area.isShown) { done(captureContent()); return }
        try {
            val loc = IntArray(2)
            area.getLocationInWindow(loc)
            val src = Rect(loc[0], loc[1], loc[0] + area.width, loc[1] + area.height)
            val deco = window.decorView
            if (!src.intersect(0, 0, deco.width, deco.height) || src.isEmpty) { done(captureContent()); return }
            // 공유 카드의 작은 미리보기용이라 더 작게(0.3배) 복사한다 — 복사량이 줄어 영상이 덜 끊긴다
            val sc = thumbScale * 0.5f
            val bmp = Bitmap.createBitmap(
                (src.width() * sc).toInt().coerceAtLeast(1),
                (src.height() * sc).toInt().coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            android.view.PixelCopy.request(window, src, bmp, { result ->
                if (isFinishing || isDestroyed) return@request
                done(if (result == android.view.PixelCopy.SUCCESS) bmp else captureContent())
            }, ui)
        } catch (e: Throwable) {
            done(captureContent())
        }
    }

    /** 이미지를 위쪽 기준으로 꽉 채워 보여주는 행렬 (페이지의 윗부분이 보이도록) */
    private fun topCropMatrix(bmp: Bitmap, w: Int, h: Int): Matrix {
        val s = maxOf(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        return Matrix().apply {
            setScale(s, s)
            postTranslate((w - bmp.width * s) / 2f, 0f)
        }
    }

    /** 새 탭(홈) 아이콘: 크롬 테마면 크롬 로고, 삼성 테마면 행성 모양, 그 밖에는 잎사귀 (탭바 · 탭 화면에서 같이 쓴다) */
    private fun homeIconRes(): Int = when {
        themeSpec?.chromeTabs == true -> R.drawable.ic_chrome_mono
        themeSpec?.samsungTabs == true -> R.drawable.ic_samsung_mono
        else -> R.drawable.ic_leaf_pixel
    }

    /** 크롬·삼성 새 탭 아이콘은 흰 부분이 투명해서, 어두운 테마(다크 모드)에서는 짙은 아이콘색이 묻히지 않게 밝은 색으로 칠한다 */
    private fun homeIconTint(): android.content.res.ColorStateList? {
        val th = themeSpec ?: return null
        if (!th.chromeTabs && !th.samsungTabs) return null
        return if (ColorUtils.calculateLuminance(th.toolbar) < 0.5) android.content.res.ColorStateList.valueOf(0xFFC4C7C5.toInt()) else null
    }

    private fun setThumb(iv: ImageView, bmp: Bitmap?) {
        if (bmp == null) {
            iv.scaleType = ImageView.ScaleType.CENTER
            iv.alpha = 1f
            iv.setImageResource(homeIconRes())
            iv.imageTintList = homeIconTint()
            return
        }
        iv.imageTintList = null
        iv.scaleType = ImageView.ScaleType.MATRIX
        iv.setImageBitmap(bmp)
        fun apply() {
            if (iv.width > 0 && iv.height > 0) iv.imageMatrix = topCropMatrix(bmp, iv.width, iv.height)
        }
        iv.addOnLayoutChangeListener { _, l, tp, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - tp != ob - ot) apply()
        }
        apply()
    }

    private fun rectInRoot(v: View): RectF {
        val root = IntArray(2)
        val loc = IntArray(2)
        val rootView = tabMorph.parent as View
        rootView.getLocationOnScreen(root)
        // FrameLayout 의 margin 은 padding 안쪽 기준이다. 풀스크린에서는 루트에 상태표시줄만큼 위 여백이 있어서,
        // 이걸 빼지 않으면 전환 그림과 흐린 배경이 그 높이만큼 아래로 내려간다 (팝업 창은 여백이 0 이라 멀쩡했다)
        root[0] += rootView.paddingLeft
        root[1] += rootView.paddingTop
        v.getLocationOnScreen(loc)
        return RectF(
            (loc[0] - root[0]).toFloat(), (loc[1] - root[1]).toFloat(),
            (loc[0] - root[0] + v.width).toFloat(), (loc[1] - root[1] + v.height).toFloat()
        )
    }

    private fun lerp(a: Float, b: Float, p: Float) = a + (b - a) * p

    /**
     * 스냅샷이 from 영역에서 to 영역으로 스프링으로 늘어나거나 줄어든다. (모서리 둥글기도 함께 변함)
     * 페이지 → 탭 카드, 탭 카드 → 페이지 전환에 모두 쓴다.
     */
    private fun runMorph(bmp: Bitmap, from: RectF, to: RectF, r0: Float, r1: Float, onEnd: () -> Unit) {
        tabMorph.scaleType = ImageView.ScaleType.MATRIX
        tabMorph.setImageBitmap(bmp)
        tabMorph.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, morphRadius)
            }
        }
        tabMorph.clipToOutline = true
        Motion.cancel(tabMorph)
        tabMorph.alpha = 1f
        tabMorph.visibility = View.VISIBLE
        val lp = FrameLayout.LayoutParams(1, 1)

        fun apply(p: Float) {
            val l = lerp(from.left, to.left, p)
            val tp = lerp(from.top, to.top, p)
            val w = maxOf(1f, lerp(from.width(), to.width(), p))
            val h = maxOf(1f, lerp(from.height(), to.height(), p))
            lp.leftMargin = l.toInt()
            lp.topMargin = tp.toInt()
            lp.width = w.toInt()
            lp.height = h.toInt()
            tabMorph.layoutParams = lp
            morphRadius = lerp(r0, r1, p.coerceIn(0f, 1f))
            tabMorph.imageMatrix = topCropMatrix(bmp, w.toInt(), h.toInt())
            tabMorph.invalidateOutline()
        }
        apply(0f)

        morphAnim?.cancel()
        morphAnim = SpringAnimation(FloatValueHolder(0f))
            .setSpring(SpringForce(1f).setStiffness(320f).setDampingRatio(0.82f))
            .setMinimumVisibleChange(0.002f)
            .addUpdateListener { _, value, _ -> apply(value) }
            .addEndListener { _, canceled, _, _ ->
                if (canceled) return@addEndListener
                apply(1f)
                onEnd()
            }
        morphAnim?.start()
    }

    /** 탭 카드 ↔ 페이지 전환 애니메이션 (창 크기가 바뀌면 시작·끝 사각형이 낡아서 바로 마무리한다) */
    private var morphAnim: SpringAnimation? = null

    private fun hideMorph(fade: Boolean) {
        if (fade && Motion.enabled(this)) {
            Motion.spring(tabMorph, DynamicAnimation.ALPHA, 0f, 700f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                tabMorph.visibility = View.GONE
                tabMorph.alpha = 1f
                tabMorph.setImageDrawable(null)
            }
        } else {
            Motion.cancel(tabMorph)
            tabMorph.visibility = View.GONE
            tabMorph.alpha = 1f
            tabMorph.setImageDrawable(null)
        }
    }

    private fun setupTabSwitcher() {
        // 뒤로 가기 화살표: 선택 모드면 선택 모드부터 끈다 (시스템 뒤로 가기와 같다)
        tabSwitcher.findViewById<View>(R.id.btnCloseSheet).setOnClickListener {
            if (switcherSelecting) exitSelectMode() else closeTabSwitcher()
        }
        tabSwitcher.findViewById<View>(R.id.btnSwitcherMore).setOnClickListener { anchor ->
            if (switcherBusy) return@setOnClickListener
            val last = recentlyClosed.lastOrNull()
            val n = if (last == null) 0 else recentlyClosed.count { it.batch == last.batch }
            // 더보기 버튼 바로 아래에 붙어서 뜬다
            Popup.menuAnchored(
                this, anchor, "탭",
                compact = true,
                items = listOf(
                    Popup.Item(R.drawable.ic_history,
                        if (n > 1) "닫은 탭 ${n}개 다시 열기" else "닫은 탭 다시 열기",
                        last?.title ?: "다시 열 탭이 없어요",
                        compactSub = true
                    ) { reopenClosedTab() },
                    Popup.Item(R.drawable.ic_delete, "모두 닫기", "모든 탭을 닫습니다", danger = true) {
                        // 실수로 눌러도 탭이 한꺼번에 사라지지 않게 한 번 더 묻는다
                        Popup.confirm(
                            this, "탭 ${tabs.size}개를 모두 닫을까요?",
                            "열려 있는 모든 탭이 닫히고 빈 새 탭 하나만 남습니다.", "모두 닫기", danger = true
                        ) {
                            closeAllTabs()
                            closeTabSwitcher()
                        }
                    }
                )
            )
        }
        tabSwitcher.findViewById<Button>(R.id.btnSelectTabs).setOnClickListener {
            if (switcherBusy || groupToggling || swDrag != null) return@setOnClickListener
            if (switcherSelecting) exitSelectMode() else enterSelectMode()
        }
        setupSelectBar()
        tabSwitcher.findViewById<Button>(R.id.btnNewIncognito).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            openNewTabAndFocus(incognito = true)
            closeTabSwitcher()
        }
        tabSwitcher.findViewById<Button>(R.id.btnNewTab).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            openNewTabAndFocus()
            closeTabSwitcher()
        }
        // 탭 화면의 위·아래 버튼도 메인 브라우저 바 버튼과 같은 눌림 + 아이콘 모양 변화:
        // 뒤로 = 화살촉이 왼쪽으로 쏘고, 더보기 = 세 점이 모였다 퍼진다. 글자 버튼은 눌림만 (넓어서 덜 줄어든다)
        Motion.barButton(tabSwitcher.findViewById(R.id.btnCloseSheet), "back")
        Motion.barButton(tabSwitcher.findViewById(R.id.btnSwitcherMore), "menu")
        Motion.barButton(tabSwitcher.findViewById(R.id.btnSelectTabs), "wide")
        Motion.barButton(tabSwitcher.findViewById(R.id.btnNewIncognito), "wide")
        Motion.barButton(tabSwitcher.findViewById(R.id.btnNewTab), "wide")
        Motion.barButton(tabSwitcher.findViewById(R.id.selectAll), "wide")
        // 위에서 아이콘 그림을 새로 끼웠으니 테마 색을 다시 입힌다
        applyAppChromeColors()
    }

    // ───────────────────────── 탭 화면 배경 블러 ─────────────────────────

    private val SWITCHER_BLUR_DP = 40
    private var switcherBlurAnim: android.animation.ValueAnimator? = null
    private var switcherBlurRadius = 0f

    /** 탭 화면 뒤의 웹 페이지를 흐리게(유리 느낌) 할 수 있는지. 안 되는 기기는 예전처럼 불투명 배경. */
    // 앱 안에서 그림을 흐리는 RenderEffect 는 창 블러(isCrossWindowBlurEnabled)와 상관없이 Android 12+ 이면 된다.
    // 예전에는 창 블러 허용 여부까지 따졌는데, 팝업(프리폼) 창 등에서 그 값이 false 라 블러가 통째로 꺼졌다.
    private fun switcherGlass() = Blur.active() && !switcherThemed()

    /**
     * 테마에 새 탭 배경 그림이나 탭바 그림이 있고 블러를 쓸 수 없을 때만 탭 화면을 그 그림 위에 놓는다.
     * 색만 바꾼 테마는 그림이 없으므로 여기에 해당하지 않아, 블러가 켜져 있으면 탭 화면 뒤를 흐리게 한다
     */
    private fun switcherThemed(): Boolean {
        val th = themeSpec ?: return false
        // 블러가 켜져 있으면(되는 기기면) 테마 그림이 있어도 탭 화면 뒤 페이지를 흐리게 비춘다. 블러를 쓸 수 없을 때만 테마 그림 위에 놓는다
        if (Blur.active()) return false
        return th.ntpImage != null || th.frameImage != null
    }

    /** 탭 화면 바탕: 새 탭 배경이 있으면 그것(새 탭 화면과 같은 모양), 없으면 탭바 색 + 탭바 그림. 테마 그림이 없으면 null */
    private fun switcherThemeBg(): android.graphics.drawable.Drawable? {
        val th = themeSpec ?: return null
        if (!switcherThemed()) return null
        if (th.hasNtp) {
            val bg = th.ntpBg ?: th.toolbar
            return ThemeHomeBgDrawable(ntpBitmap(th.ntpImage, th.ntpRepeat), bg, th.ntpAlign, th.ntpRepeat, resources.displayMetrics.density)
        }
        if (th.frameImage != null) {
            val layers = listOfNotNull<android.graphics.drawable.Drawable>(
                android.graphics.drawable.ColorDrawable(th.frame), themeTileDrawable(th.frameImage), themeTileDrawable(th.frameOverlay)
            )
            return android.graphics.drawable.LayerDrawable(layers.toTypedArray())
        }
        return null
    }

    /** 탭 화면 머리줄(제목·아이콘·버튼) 글자색: 테마 그림 위에서도 읽히도록 바탕에 맞춘다. 그림이 없으면 null */
    private fun switcherThemeFg(): Int? {
        val th = themeSpec ?: return null
        if (!switcherThemed()) {
            // 블러 탭 화면(그림 테마): 뒤쪽이 테마 색을 따라 어두울 수 있어 머리줄(뒤로·제목·더보기)을 테마 바탕에 맞춰 읽히게 한다
            if (Blur.active() && (th.ntpImage != null || th.frameImage != null))
                return readableOn(th.frame, th.tabBgText ?: th.tabText)
            return null
        }
        if (th.hasNtp) return homeFgTheme ?: readableOn(th.ntpBg ?: th.toolbar, th.ntpText)
        if (th.frameImage != null) return readableOn(th.frame, th.tabBgText ?: th.tabText)
        return null
    }

    /** 뒤쪽 페이지의 블러 반경을 부드럽게 바꾼다 (0 이면 끄기) */
    private fun animateSwitcherBlur(toDp: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val to = Blur.dp(this, toDp).toFloat()
        switcherBlurAnim?.cancel()
        if (!Motion.enabled(this)) {
            switcherBlurRadius = to
            Blur.blurView(browserUi, to)
            return
        }
        switcherBlurAnim = android.animation.ValueAnimator.ofFloat(switcherBlurRadius, to).apply {
            duration = 240
            addUpdateListener {
                switcherBlurRadius = it.animatedValue as Float
                Blur.blurView(browserUi, switcherBlurRadius)
            }
            start()
        }
    }

    private fun clearSwitcherBlur() {
        switcherBlurAnim?.cancel()
        switcherBlurRadius = 0f
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Blur.blurView(browserUi, 0f)
        removeSwitcherBackdrop()
    }

    /**
     * 탭 화면 뒤 배경: 예전에는 웹페이지(WebView) 전체에 실시간 블러를 걸고 반경을 매 프레임 바꿨는데,
     * 전체화면처럼 큰 창에서는 그게 너무 무거워서 전환이 뚝뚝 끊겼다. 이제 페이지를 작게 한 장 찍어
     * 한 번만 흐려 두고, 그 그림의 투명도만 바꿔서 서서히 보이게 한다 (움직이는 동안 블러를 다시 계산하지 않는다).
     */
    private var switcherBackdrop: ImageView? = null

    private fun showSwitcherBackdrop() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        removeSwitcherBackdrop()
        val parent = tabSwitcher.parent as? FrameLayout ?: return
        val w = browserUi.width
        val h = browserUi.height
        if (w <= 0 || h <= 0) return
        val sc = 0.3f
        val bmp = try {
            Bitmap.createBitmap((w * sc).toInt().coerceAtLeast(1), (h * sc).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        } catch (e: Throwable) { return }
        try {
            val c = Canvas(bmp)
            c.drawColor(ThemeColors.get(browserUi, com.google.android.material.R.attr.colorSurface))
            c.scale(sc, sc)
            browserUi.draw(c)
        } catch (e: Throwable) { return }
        val r = rectInRoot(browserUi)
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
            alpha = 0f
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            val blur = Blur.dp(this@MainActivity, 56) * sc
            try {
                if (Blur.active()) setRenderEffect(android.graphics.RenderEffect.createBlurEffect(blur, blur, android.graphics.Shader.TileMode.CLAMP))
            } catch (_: Throwable) {}
        }
        parent.addView(
            iv, parent.indexOfChild(tabSwitcher),
            FrameLayout.LayoutParams(w, h).apply { leftMargin = r.left.toInt(); topMargin = r.top.toInt() }
        )
        switcherBackdrop = iv
        if (Motion.enabled(this)) iv.animate().alpha(1f).setDuration(240).start() else iv.alpha = 1f
    }

    private fun fadeOutSwitcherBackdrop() {
        val iv = switcherBackdrop ?: return
        if (Motion.enabled(this)) iv.animate().alpha(0f).setDuration(260).start() else iv.alpha = 0f
    }

    private fun removeSwitcherBackdrop() {
        val iv = switcherBackdrop ?: return
        switcherBackdrop = null
        iv.animate().cancel()
        (iv.parent as? ViewGroup)?.removeView(iv)
        iv.setImageDrawable(null)
    }

    /**
     * 탭 화면 바탕의 반투명 면(흰 막). 전환(카드가 날아가는 동안)에는 없애 두고, 다 열린 뒤에 서서히 입힌다.
     * 예전에는 전환 내내 페이지 위에 반투명 흰 막이 덮여 있어 뿌옇게 보였다.
     */
    private var switcherTintAnim: android.animation.ValueAnimator? = null
    // 0 = 흰 막을 아예 입히지 않는다 (블러만 보임). 막을 다시 쓰려면 0xA0 쯤으로
    private val switcherTintAlpha = 0

    private fun animateSwitcherTint(toAlpha: Int, durationMs: Long) {
        switcherTintAnim?.cancel()
        val base = ThemeColors.get(tabSwitcher, com.google.android.material.R.attr.colorSurfaceContainer)
        fun set(a: Int) = tabSwitcher.setBackgroundColor(androidx.core.graphics.ColorUtils.setAlphaComponent(base, a.coerceIn(0, 255)))
        val from = ((tabSwitcher.background as? android.graphics.drawable.ColorDrawable)?.color ?: 0).ushr(24)
        if (!Motion.enabled(this) || durationMs <= 0 || from == toAlpha) { set(toAlpha); return }
        switcherTintAnim = android.animation.ValueAnimator.ofInt(from, toAlpha).apply {
            duration = durationMs
            addUpdateListener { set(it.animatedValue as Int) }
            start()
        }
    }

    /**
     * 탭 화면이 열릴 때 탭 버튼(폰 하단 · 태블릿 상단 · 태블릿 탭 줄 오른쪽)에 남는 눌림/호버/포커스 표시를 지운다.
     * 탭 화면이 버튼을 덮으면 손가락·포인터가 떨어졌다는 신호를 버튼이 못 받아서, 둥근 사각형 리플이
     * 끝나지 않은 채 흐려진 뒤쪽 화면에 "이상한 박스"로 남았다.
     */
    private fun clearTabButtonStates() {
        listOf(btnTabs, btnBottomTabs, findViewById<View>(R.id.btnStripTabList)).forEach { b ->
            if (b == null) return@forEach
            b.isPressed = false
            b.isHovered = false
            b.clearFocus()
            b.jumpDrawablesToCurrentState()
            b.background?.let { bg ->
                bg.state = intArrayOf()
                bg.jumpToCurrentState()
            }
        }
    }

    private fun openTabSwitcher() {
        ui.post { scrollBars.sync() }
        if (switcherOpen || switcherBusy) return
        val cur = current ?: return
        urlBar.clearFocus()
        clearTabButtonStates()
        // 클릭 처리와 같은 프레임에 리플이 다시 시작되는 경우를 위해 한 번 더 (전환이 시작된 뒤)
        ui.post { clearTabButtonStates() }
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)

        val area = webContainer.parent as View
        // 화면에 그려진 픽셀 그대로 (웹뷰를 다시 그리면 사진이 찌그러지고 배치가 달라져 보였다)
        val shot = captureContent(pixels = true)
        cur.thumb = shot
        val from = rectInRoot(area)

        switcherOpen = true
        updateSecureFlag()
        switcherBusy = true
        updateStatusBarColor()
        applyAppChromeColors()   // 탭 화면 머리줄 아이콘(뒤로·더보기) 색·상태를 열 때마다 다시 맞춘다
        exitSelectMode(redraw = false)
        refreshSwitcher(animateIn = true, skipEnter = cur)
        tabSwitcher.alpha = 0f
        val glass = switcherGlass()
        switcherTintAnim?.cancel()
        val themedSwitcherBg = switcherThemeBg()
        if (themedSwitcherBg != null) tabSwitcher.background = themedSwitcherBg
        else tabSwitcher.setBackgroundColor(
            if (glass) androidx.core.graphics.ColorUtils.setAlphaComponent(
                ThemeColors.get(tabSwitcher, com.google.android.material.R.attr.colorSurfaceContainer), 0)
            else Blur.surface(this, com.google.android.material.R.attr.colorSurfaceContainer, false)
        )
        tabSwitcher.visibility = View.VISIBLE

        tabSwitcher.doOnLayout {
            // 실시간 블러: 진짜 페이지 화면에 직접 흐림 효과를 걸고 반경을 키운다 (사진을 찍어 두는 방식 아님)
            if (glass) animateSwitcherBlur(SWITCHER_BLUR_DP)
            val card = switcherRows[cur]
            val thumb = card?.findViewById<ImageView>(R.id.tabThumb)
            if (card != null) {
                val r = Rect()
                card.getDrawingRect(r)
                tabScroll.offsetDescendantRectToMyCoords(card, r)
                tabScroll.scrollTo(0, maxOf(0, r.top - dp(12)))
            }
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 1f, 240f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            if (shot == null || thumb == null || !Motion.enabled(this) || resizeBurst) {
                tabSwitcher.alpha = 1f
                if (glass) animateSwitcherTint(switcherTintAlpha, 160) else browserUi.visibility = View.INVISIBLE
                switcherBusy = false
                clearTabButtonStates()
                return@doOnLayout
            }
            val to = rectInRoot(thumb)
            thumb.alpha = 0f
            // 움직이는 동안 진짜 페이지는 숨겨서, 찍어 둔 그림과 겹쳐 두 겹으로 보이는 일이 없게 한다
            if (!glass) (webContainer.parent as? View)?.alpha = 0f
            runMorph(shot, from, to, 0f, dp(10).toFloat()) {
                thumb.alpha = 1f
                hideMorph(false)
                if (glass) animateSwitcherTint(switcherTintAlpha, 160) else browserUi.visibility = View.INVISIBLE
                switcherBusy = false
                clearTabButtonStates()
            }
        }
    }

    /** 탭 화면을 닫는다. target 탭의 카드가 있으면 카드가 펼쳐지며 페이지가 되고, 없으면 부드럽게 사라진다. */
    private fun closeTabSwitcher(target: BrowserTab? = null) {
        ui.post { scrollBars.sync() }
        if (!switcherOpen || switcherBusy) return
        switcherBusy = true
        updateStatusBarColor(switcher = false)

        val tab = target ?: current ?: tabs.firstOrNull()
        val thumbView = tab?.let { switcherRows[it] }?.findViewById<ImageView>(R.id.tabThumb)
        val bmp = tab?.thumb
        val vis = Rect()
        val canMorph = tab != null && thumbView != null && bmp != null &&
            thumbView.getGlobalVisibleRect(vis) && Motion.enabled(this) &&
            // 창 크기를 바꾸는 중에는 카드·페이지 위치가 계속 달라져서 전환이 어긋난다 → 부드럽게 사라지는 방식으로
            !resizeBurst
        val from = if (canMorph) rectInRoot(thumbView!!) else null

        if (switcherGlass()) animateSwitcherTint(0, 120)
        val sameTab = tab != null && tab === current
        if (tab != null && tab !== current) selectTab(tab)
        browserUi.visibility = View.VISIBLE
        fadeOutSwitcherBackdrop()
        browserUi.animate().cancel()
        browserUi.alpha = 1f
        // 실시간 블러를 서서히 푼다
        if (switcherGlass()) animateSwitcherBlur(0)
        // 탭 카드를 찍어 둔 뒤 창 크기·여백이 달라졌을 수 있어서, 현재 탭이면 지금 페이지를 새로 찍어
        // 끝 그림이 실제 페이지와 정확히 겹치게 한다 (예전에는 낡은 그림이 어긋난 채 겹쳐 글자가 두 겹으로 보였다)
        // 다만 탭 화면을 열 때 찍어 둔 그림이 지금 페이지 영역과 같은 비율이면 그걸 그대로 쓴다
        // (지금은 탭 화면이 위에 떠 있어 화면 픽셀을 다시 복사할 수 없고, 웹뷰를 다시 그리면 사진이 찌그러지기 때문)
        val areaNow = webContainer.parent as? View
        val sameShape = bmp != null && areaNow != null && areaNow.width > 0 && areaNow.height > 0 &&
            Math.abs(bmp.width.toFloat() / bmp.height - areaNow.width.toFloat() / areaNow.height) <
            0.015f * (areaNow.width.toFloat() / areaNow.height)
        val endBmp = if (canMorph && sameTab) (if (sameShape) bmp else (captureContent() ?: bmp)) else bmp

        val pageArea = webContainer.parent as? View
        fun finish() {
            pageArea?.alpha = 1f
            browserUi.animate().cancel()
            browserUi.alpha = 1f
            clearSwitcherBlur()
            tabSwitcher.visibility = View.GONE
            tabSwitcher.alpha = 1f
            tabList.removeAllViews()
            switcherRows.clear()
            switcherOpen = false
            exitSelectMode(redraw = false)
            updateSecureFlag()
            switcherBusy = false
        }

        if (canMorph && from != null) {
            val to = rectInRoot(webContainer.parent as View)
            thumbView!!.alpha = 0f
            // 카드 전체(제목줄·테두리 포함)를 바로 숨긴다. 그림만 숨기면 카드 틀이 상단바 자리에 남아 서서히 사라지는 게 보인다
            tab?.let { switcherRows[it] }?.alpha = 0f
            // 탭 화면은 빠르게 걷어 낸다 (느리게 사라지면 다른 카드들이 상단바 위로 비쳐 보인다)
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 900f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            if (!switcherGlass()) pageArea?.alpha = 0f
            runMorph(endBmp!!, from, to, dp(10).toFloat(), 0f) {
                // 그림을 서서히 지우면 진짜 페이지와 겹쳐 두 겹으로 보이므로, 한 프레임에 바로 바꿔 끼운다
                finish()
                hideMorph(false)
            }
        } else {
            // 카드가 없거나 화면 밖: 페이지가 살짝 커지며 나타나고 탭 화면은 사라진다.
            val chrome = browserUi
            if (Motion.enabled(this)) {
                Motion.cancel(chrome)
                chrome.alpha = 0f
                chrome.scaleX = 0.95f
                chrome.scaleY = 0.95f
                Motion.spring(chrome, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                Motion.spring(chrome, DynamicAnimation.SCALE_X, 1f, 260f, 0.78f)
                Motion.spring(chrome, DynamicAnimation.SCALE_Y, 1f, 260f, 0.78f)
                Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                    finish()
                }
            } else {
                finish()
            }
        }
    }

    /** 탭 화면에서 마지막으로 그린 그룹별 접힘 상태 (화살표가 돌아가는 방향을 정하려고) */
    private val groupRendered = HashMap<Int, Boolean>()
    private var groupToggling = false

    // ───────────────────────── 탭 화면의 창 관리 ─────────────────────────

    /**
     * 탭 화면 위쪽에 열려 있는 창들을 가로로 보여 준다 (창이 2개 이상일 때만).
     * 창을 누르면 그 창으로 가고, 창의 X 를 누르면 그 창을 닫는다. 맨 끝의 "＋ 새 창"으로 창을 더 연다.
     */
    private var swGlassBmp: android.graphics.Bitmap? = null
    private var swGlassScale = 0.1f
    private var swGlassW = 0
    private var swGlassH = 0
    private var swGlassBgd: android.graphics.drawable.Drawable? = null

    /** 탭 화면 배경(테마의 새 탭 배경)을 흐리게 비추는 유리 바탕을 [host] 에 입힌다. 새 탭 버튼과 같은 모양. 테마 새 탭 배경이 없으면 null */
    private fun switcherGlassFor(host: View, cornerDp: Int): android.graphics.drawable.Drawable? {
        val th = themeSpec ?: return null
        if (!th.hasNtp) return null
        val bgd = tabSwitcher.background as? ThemeHomeBgDrawable ?: return null
        val w = tabSwitcher.width.takeIf { it > 0 } ?: browserUi.width
        val h = tabSwitcher.height.takeIf { it > 0 } ?: browserUi.height
        if (w <= 0 || h <= 0) return null
        if (swGlassBmp == null || swGlassW != w || swGlassH != h || swGlassBgd !== bgd) {
            try {
                val sc = 0.1f
                val bw = maxOf(2, (w * sc).toInt()); val bh = maxOf(2, (h * sc).toInt())
                val bmp = android.graphics.Bitmap.createBitmap(bw, bh, android.graphics.Bitmap.Config.ARGB_8888)
                val c = android.graphics.Canvas(bmp)
                c.scale(bw.toFloat() / w, bh.toFloat() / h)
                val ob = android.graphics.Rect(bgd.bounds)
                bgd.setBounds(0, 0, w, h); bgd.draw(c); bgd.bounds = ob
                swGlassBmp = ThemeGlassDrawable.blur(bmp, 3)
                bmp.recycle()
                swGlassScale = bw.toFloat() / w
                swGlassW = w; swGlassH = h; swGlassBgd = bgd
            } catch (e: Throwable) { swGlassBmp = null; return null }
        }
        val bmp = swGlassBmp ?: return null
        val fg = switcherThemeFg() ?: return null
        val darkBg = ColorUtils.calculateLuminance(fg) > 0.5   // 글자가 밝으면 바탕은 어둡다
        val tint = if (darkBg) 0x66000000 else 0x99FFFFFF.toInt()
        return ThemeGlassDrawable(
            bmp, swGlassScale, host, tabSwitcher, dp(cornerDp).toFloat(),
            tint, ColorUtils.setAlphaComponent(fg, 0x33), dp(1).toFloat()
        )
    }

    private fun refreshWindowStrip(skip: MainActivity? = null) {
        // 칩을 끄는 중에는 다시 그리지 않는다 (끝나면 endWindowDrag 가 다시 그린다)
        if (wsDragView != null) return
        val strip = tabSwitcher.findViewById<View>(R.id.windowStrip)
        val box = tabSwitcher.findViewById<LinearLayout>(R.id.windowStripList)
        // 다시 그리기 전 칩들의 자리를 기억해 두었다가, 남은 칩은 미끄러지고 새 칩은 톡 나타나게 한다
        val animateChips = strip.visibility == View.VISIBLE && Motion.enabled(this)
        val oldLefts = HashMap<Int, Int>()
        if (animateChips) {
            windowDragChips.forEach { oldLefts[it.second] = it.first.left }
            windowAddChip?.let { oldLefts[-1] = it.left }
        }
        box.removeAllViews()
        windowChips.clear()
        val wins = instances.filter { it !== skip && !it.isFinishing && !it.isDestroyed }
        // 닫았지만 탭이 남아 있는 창들: 눌러서 다시 연다
        val closed = prefs.savedWindowNos().filter { n -> wins.none { it.windowNo == n } && prefs.savedTabCount(n) > 0 }.sorted()
        if (wins.size + closed.size < 2) {
            strip.visibility = View.GONE
            return
        }
        strip.visibility = View.VISIBLE

        val attrSurface = com.google.android.material.R.attr.colorSurface
        val surface = ThemeColors.get(box, attrSurface, 0)
        val activeBg = ThemeColors.get(box, com.google.android.material.R.attr.colorPrimaryContainer, 0)
        val activeFg = ThemeColors.get(box, com.google.android.material.R.attr.colorOnPrimaryContainer, 0)
        val textMain = ThemeColors.get(box, com.google.android.material.R.attr.colorOnSurface, 0)
        val textSub = ThemeColors.get(box, com.google.android.material.R.attr.colorOnSurfaceVariant, 0)

        fun styled(chip: View, bg: Int) {
            val shape = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(bg) }
            val mask = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFFFFFFFF.toInt()) }
            chip.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x22000000), shape, mask
            )
        }

        windowDragChips.clear()
        windowAddChip = null
        // 유리 바탕 칩들: 목록이 옆으로 스크롤되면 배경과 다시 맞추도록 다시 그린다
        val glassChips = ArrayList<View>()
        (strip as? android.widget.HorizontalScrollView)?.setOnScrollChangeListener { _, _, _, _, _ ->
            for (g in glassChips) g.invalidate()
        }
        fun addWinChip(w: MainActivity) {
            val chip = layoutInflater.inflate(R.layout.item_window_chip, box, false)
            val me = w === this
            val fg = if (me) activeFg else textMain
            val sub = if (me) activeFg else textSub
            styled(chip, if (me) activeBg else surface)
            chip.findViewById<TextView>(R.id.windowTitle).apply {
                text = if (me) "${w.windowLabel} · 현재" else w.windowLabel
                setTextColor(fg)
            }
            // 다른 창의 시크릿 탭 제목은 보여 주지 않는다
            val cur = w.current
            val pageName = when {
                cur == null || cur.isHome -> "새 탭"
                cur.incognito -> "시크릿 탭"
                else -> w.tabTitle(cur)
            }
            chip.findViewById<TextView>(R.id.windowSub).apply {
                text = "탭 ${w.tabs.size}개 · $pageName"
                setTextColor(sub)
            }
            val close = chip.findViewById<ImageButton>(R.id.windowClose)
            close.imageTintList = android.content.res.ColorStateList.valueOf(sub)
            if (me) {
                // 지금 보고 있는 창은 여기서 닫지 않는다
                close.visibility = View.GONE
                chip.setPadding(chip.paddingLeft, 0, dp(14), 0)
            } else {
                chip.setOnClickListener { switchToWindow(w) }
                close.setOnClickListener { confirmCloseWindow(w) }
                windowChips.add(chip to w)
            }
            box.addView(chip)
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 이름 바꾸기
            bindWindowDrag(chip, w.windowNo)
            windowDragChips.add(chip to w.windowNo)
        }

        fun addClosedChip(n: Int) {
            val chip = layoutInflater.inflate(R.layout.item_window_chip, box, false)
            styled(chip, surface)
            // 테마 새 탭 배경이 있으면 반투명 대신 새 탭 버튼처럼 배경을 흐리게 비추는 유리 바탕
            val glass = switcherGlassFor(chip, 16)
            val gfg = if (glass != null) switcherThemeFg() else null
            if (glass != null && gfg != null) {
                chip.background = android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(0x22000000), glass,
                    GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFFFFFFFF.toInt()) }
                )
                glassChips.add(chip)
            } else chip.alpha = 0.7f
            chip.findViewById<TextView>(R.id.windowTitle).apply { text = prefs.windowName(n) ?: "창 $n"; setTextColor(gfg ?: textMain) }
            chip.findViewById<TextView>(R.id.windowSub).apply {
                text = "탭 ${prefs.savedTabCount(n)}개 · 닫힌 창"
                setTextColor(if (gfg != null) ColorUtils.setAlphaComponent(gfg, 0xCC) else textSub)
            }
            chip.findViewById<View>(R.id.windowClose).visibility = View.GONE
            chip.setPadding(chip.paddingLeft, 0, dp(14), 0)
            chip.setOnClickListener {
                // 분할로 열지 않고, 지금 창을 닫으면서 그 창으로 전환한다 (지금 창이 멀티윈도우였다면 그 자리를 이어받는다)
                openInPlaceOfThisWindow(n)
            }
            box.addView(chip)
            bindWindowDrag(chip, n)
            windowDragChips.add(chip to n)
        }

        // 저장된 순서대로 (순서가 없는 창은 원래 순서 그대로 뒤에)
        val order = prefs.windowOrder()
        val entries = ArrayList<Pair<Int, MainActivity?>>()
        wins.forEach { entries.add(it.windowNo to it) }
        closed.forEach { entries.add(it to null) }
        entries.sortedBy { e -> order.indexOf(e.first).let { if (it < 0) Int.MAX_VALUE else it } }
            .forEach { (n, w) -> if (w != null) addWinChip(w) else addClosedChip(n) }

        // 맨 끝: 새 창
        val add = layoutInflater.inflate(R.layout.item_window_chip, box, false)
        styled(add, surface)
        add.findViewById<TextView>(R.id.windowTitle).apply { text = "＋ 새 창"; setTextColor(textMain) }
        add.findViewById<View>(R.id.windowSub).visibility = View.GONE
        add.findViewById<View>(R.id.windowClose).visibility = View.GONE
        add.setPadding(dp(16), 0, dp(16), 0)
        add.setOnClickListener { openNewWindow() }
        windowChips.add(add to null)
        box.addView(add)
        windowAddChip = add

        if (animateChips) {
            val fresh = ArrayList<Pair<View, Int>>(windowDragChips)
            fresh.add(Pair(add, -1))
            box.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    box.viewTreeObserver.removeOnPreDrawListener(this)
                    fresh.forEach { (v, no) ->
                        val old = oldLefts[no]
                        if (old == null) {
                            // 새로 생긴 창
                            if (no != -1) Motion.pop(v, 0.8f)
                        } else if (old != v.left) {
                            v.translationX = (old - v.left).toFloat()
                            Motion.spring(v, DynamicAnimation.TRANSLATION_X, 0f, 380f, 0.8f)
                        }
                    }
                    return true
                }
            })
        }
    }

    // ── 탭 화면의 창 칩 끌어서 순서 바꾸기 (상단 탭 줄과 같은 방식) ──

    /** 지금 그려진 창 칩들 (화면 순서대로, "＋ 새 창"은 제외) */
    private val windowDragChips = ArrayList<Pair<View, Int>>()
    private var windowAddChip: View? = null
    private var wsDragView: View? = null
    private var wsDragNo = 0
    private var wsGrab = 0f
    private var wsRawX = 0f
    private var wsSwapped = false

    private fun bindWindowDrag(chip: View, no: Int) {
        bindDragGesture(
            chip, null,
            onStart = { x, _ -> startWindowDrag(chip, no, x) },
            onMove = { x, _ -> wsRawX = x; updateWindowDrag() },
            onEnd = { moved, canceled -> endWindowDrag(moved, canceled) }
        )
    }

    /** 끌고 있는 칩이 창 목록의 양 끝에 가까워지면 목록이 그쪽으로 스크롤된다 */
    private val wsAutoScroll = object : Runnable {
        override fun run() {
            if (wsDragView == null) return
            val strip = tabSwitcher.findViewById<android.widget.HorizontalScrollView>(R.id.windowStrip)
            val loc = IntArray(2)
            strip.getLocationOnScreen(loc)
            val rel = wsRawX - loc[0]
            val edge = dp(56).toFloat()
            val w = strip.width
            val dx = when {
                rel < edge -> -(edge - rel) / edge * dp(14)
                rel > w - edge -> (rel - (w - edge)) / edge * dp(14)
                else -> 0f
            }
            if (dx != 0f) {
                val step = if (dx > 0) maxOf(1, dx.toInt()) else minOf(-1, dx.toInt())
                val before = strip.scrollX
                strip.scrollBy(step, 0)
                if (strip.scrollX != before) updateWindowDrag()
            }
            strip.postOnAnimation(this)
        }
    }

    private fun windowBox() = tabSwitcher.findViewById<LinearLayout>(R.id.windowStripList)

    private fun startWindowDrag(chip: View, no: Int, rawX: Float): Boolean {
        if (wsDragView != null || swDrag != null || switcherBusy) return false
        if (windowDragChips.none { it.first === chip }) return false
        val box = windowBox()
        wsDragView = chip
        wsDragNo = no
        wsSwapped = false
        wsRawX = rawX
        val loc = IntArray(2)
        box.getLocationOnScreen(loc)
        wsGrab = rawX - loc[0] - chip.left
        chip.translationZ = dp(8).toFloat()
        chip.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        // 집어 올리면 살짝 커지며 떠오른다
        Motion.spring(chip, DynamicAnimation.SCALE_X, 1.07f, 620f, 0.6f)
        Motion.spring(chip, DynamicAnimation.SCALE_Y, 1.07f, 620f, 0.6f)
        // 끄는 칩이 가장자리에서 잘리지 않게
        box.clipChildren = false
        tabSwitcher.findViewById<View>(R.id.windowStrip).postOnAnimation(wsAutoScroll)
        return true
    }

    /** 손가락 위치만으로 계산한 칩의 왼쪽 (목록 안쪽 좌표) */
    private fun wsDragRaw(): Float {
        val loc = IntArray(2)
        windowBox().getLocationOnScreen(loc)
        return wsRawX - loc[0] - wsGrab
    }

    private fun updateWindowDrag() {
        val v = wsDragView ?: return
        if (v.parent == null) { wsDragView = null; return }
        // "＋ 새 창" 칩 앞까지만 움직일 수 있다
        val maxLeft = ((windowAddChip?.left ?: windowBox().width) - v.width).coerceAtLeast(0)
        val want = wsDragRaw().coerceIn(0f, maxLeft.toFloat())
        v.translationX = want - v.left
        // 순서를 바꿀지는 제한하기 전의 손가락 위치로 판단한다 (맨 앞/맨 뒤 칩과도 자리를 바꿀 수 있게)
        val cx = wsDragRaw() + v.width / 2f
        val i = windowDragChips.indexOfFirst { it.first === v }
        if (i < 0) return
        val next = windowDragChips.getOrNull(i + 1)?.first
        val prev = windowDragChips.getOrNull(i - 1)?.first
        when {
            next != null && cx > next.left + next.width / 2f -> swapWindowChip(i, 1)
            prev != null && cx < prev.left + prev.width / 2f -> swapWindowChip(i, -1)
        }
    }

    /** 끌고 있는 칩은 그대로 두고, 이웃 칩만 반대편으로 옮긴다 (미끄러지듯 자리를 옮긴다) */
    private fun swapWindowChip(i: Int, dir: Int) {
        val box = windowBox()
        val v = windowDragChips[i].first
        val nbPair = windowDragChips[i + dir]
        val nb = nbPair.first
        val oldLeft = nb.left
        windowDragChips[i + dir] = windowDragChips[i]
        windowDragChips[i] = nbPair
        wsSwapped = true
        box.removeView(nb)
        box.addView(nb, if (dir > 0) box.indexOfChild(v) else box.indexOfChild(v) + 1)
        box.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                box.viewTreeObserver.removeOnPreDrawListener(this)
                val dx = oldLeft - nb.left
                if (dx != 0) {
                    nb.translationX = dx + nb.translationX
                    Motion.spring(nb, DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.8f)
                }
                if (wsDragView === v) {
                    val maxLeft = ((windowAddChip?.left ?: box.width) - v.width).coerceAtLeast(0)
                    v.translationX = wsDragRaw().coerceIn(0f, maxLeft.toFloat()) - v.left
                }
                return true
            }
        })
    }

    private fun endWindowDrag(moved: Boolean, canceled: Boolean) {
        val v = wsDragView ?: return
        val no = wsDragNo
        wsDragView = null
        val strip = tabSwitcher.findViewById<View>(R.id.windowStrip)
        strip.removeCallbacks(wsAutoScroll)
        // 놓으면 제자리로 탄성 있게 안착한다
        Motion.spring(v, DynamicAnimation.TRANSLATION_X, 0f, 460f, 0.78f)
        Motion.spring(v, DynamicAnimation.SCALE_X, 1f, 520f, 0.6f)
        Motion.spring(v, DynamicAnimation.SCALE_Y, 1f, 520f, 0.6f) { v.translationZ = 0f }
        if (wsSwapped) {
            // 새 순서를 저장하고, 탭 화면이 열려 있는 다른 창들도 같은 순서로 다시 그린다
            prefs.setWindowOrder(windowDragChips.map { it.second })
            notifyOtherWindows()
        }
        // 안착하는 동안은 그대로 두고, 끝난 뒤 목록을 새로 그린다 (바로 그리면 안착 모션이 끊긴다)
        ui.postDelayed({ if (switcherOpen && wsDragView == null) refreshWindowStrip() }, 320)
        // 끌지 않고 그냥 뗐으면 예전처럼 이름 바꾸기
        if (!canceled && !moved && !wsSwapped) showRenameWindow(no)
    }

    /** 창 이름 바꾸기. 비워 두고 저장하면 기본 이름("창 N")으로 돌아간다 */
    private fun showRenameWindow(no: Int) {
        val et = EditText(this).apply {
            setText(prefs.windowName(no) ?: "")
            hint = "창 $no"
            setSingleLine()
            filters = arrayOf(android.text.InputFilter.LengthFilter(20))
            setSelection(text.length)
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun save() {
            prefs.setWindowName(no, et.text.toString().trim().ifEmpty { null })
            if (switcherOpen) refreshWindowStrip()
            notifyOtherWindows()
        }
        val dlg = ThemedDialogBuilder(this)
            .setTitle("창 이름 바꾸기")
            .setView(box)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ -> save() }
            .create()
        et.setOnEditorActionListener { _, _, _ -> save(); dlg.dismiss(); true }
        dlg.show()
        et.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** 탭 화면의 창 칩들: 탭 카드를 끌어다 놓을 수 있는 자리 (창 = 그 창으로, null = 새 창) */
    private val windowChips = ArrayList<Pair<View, MainActivity?>>()

    private fun windowChipAt(x: Float, y: Float): Pair<View, MainActivity?>? {
        // x, y 는 화면 전체 기준(rawX/rawY)이다. getGlobalVisibleRect 는 '창 안' 좌표라서
        // 분할 화면·프리폼처럼 창이 화면 모서리에 붙어 있지 않으면 어긋난다 → 화면 좌표로 맞춰서 비교한다.
        val strip = tabSwitcher.findViewById<View>(R.id.windowStrip)
        val sl = IntArray(2)
        strip.getLocationOnScreen(sl)
        val stripRect = Rect(sl[0], sl[1], sl[0] + strip.width, sl[1] + strip.height)
        val loc = IntArray(2)
        val r = Rect()
        val m = dp(6)
        for (p in windowChips) {
            val c = p.first
            if (!c.isShown) continue
            c.getLocationOnScreen(loc)
            r.set(loc[0], loc[1], loc[0] + c.width, loc[1] + c.height)
            // 가로로 스크롤돼 가려진 칩은 제외
            if (!r.intersect(stripRect)) continue
            r.inset(-m, -m)
            if (r.contains(x.toInt(), y.toInt())) return p
        }
        return null
    }

    private fun setWinHighlight(chip: View, on: Boolean) {
        val s = if (on) 1.08f else 1f
        chip.animate().scaleX(s).scaleY(s).setDuration(140).start()
    }

    /**
     * 다른 창(또는 새 창)에서 넘어온 탭을 이 창에 만든다.
     * 웹 기록·확대 비율·스크롤 위치를 그대로 이어받는다. [select] 가 false 면 보고 있던 탭은 그대로 두고, 고르면 그때 불러온다.
     */
    private fun receiveTab(h: TabHandoff, select: Boolean = false) {
        val t = createTab(null, select = false, home = h.url == null, incognito = h.incognito, lazy = !select)
        t.desktop = h.desktop && !autoMobile
        t.pageZoom = h.pageZoom
        t.muted = h.muted
        t.rate = h.rate
        if (h.url != null) {
            t.pendingUrl = h.url
            t.pendingTitle = h.title
            t.pendingState = h.state
            t.pendingScrollRatio = h.scrollRatio
            t.pendingScrollX = h.scrollX
            t.pendingScrollY = h.scrollY
        }
        if (select) selectTab(t)
        saveTabs()
        if (switcherOpen) refreshSwitcher(false)
    }

    /**
     * 되살아난 탭의 스크롤을 맞춘다. 창 크기가 달라졌거나 확대 비율을 다시 적용해 내용이 다시 배치되어도
     * 같은 자리를 보도록, 페이지가 다 불러와진 뒤 비율로 두 번 맞춘다. 그 사이 사용자가 만지면 멈춘다.
     */
    private fun restoreHandoffScroll(tab: BrowserTab, wv: WebView) {
        if (!tab.restoreScrollPending) return
        tab.restoreScrollPending = false
        val ratio = tab.pendingScrollRatio
        val sx = tab.pendingScrollX
        val sy = tab.pendingScrollY
        tab.pendingScrollRatio = -1f
        tab.pendingScrollX = 0
        tab.pendingScrollY = 0
        val touchMark = lastTouchAt
        fun apply() {
            if (isFinishing || isDestroyed || tab.liveWebView !== wv || lastTouchAt != touchMark) return
            if (ratio >= 0f) {
                @Suppress("DEPRECATION")
                val max = (wv.contentHeight * wv.scale).toInt() - wv.height
                val y = if (max > 0) (ratio * max).toInt() else 0
                if (kotlin.math.abs(wv.scrollY - y) > dp(2)) wv.scrollTo(sx, y)
            } else if (wv.scrollX != sx || wv.scrollY != sy) {
                wv.scrollTo(sx, sy)
            }
            if (tab === current) pageScrollBar.refresh()
        }
        // 확대 비율 스크립트가 들어가 다시 배치된 뒤에 맞춘다
        wv.postDelayed({ apply() }, 250)
        wv.postDelayed({ apply() }, 800)
        wv.postDelayed({ apply() }, 1600)
    }

    /** 이 탭의 현재 상태(웹 기록·확대·스크롤 등)를 다른 창으로 들고 갈 수 있게 담는다. 탭을 닫기 전에 불러야 한다 */
    private fun captureHandoff(tab: BrowserTab): TabHandoff {
        val lw = tab.liveWebView
        val live = lw?.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        val url = if (tab.isHome) null else (live ?: tab.pendingUrl)
        val title = (if (live != null) lw?.title else tab.pendingTitle)?.takeIf { it.isNotBlank() }
        var state: Bundle? = null
        var ratio = -1f
        var sx = 0
        var sy = 0
        if (url != null) {
            if (live != null && lw != null) {
                val b = Bundle()
                if (runCatching { lw.saveState(b) }.getOrNull() != null) state = b
                sx = lw.scrollX
                sy = lw.scrollY
                // 화면에 붙어 있을 때만 현재 비율을 믿을 수 있다 (떼어 둔 웹뷰는 높이가 0)
                ratio = if (lw.height > 0) scrollRatioOf(lw) else tab.scrollRatio
            } else {
                // 아직 불러오지 않은 채 넘겨받아 두었던 탭이면 받은 상태를 그대로 다시 넘긴다
                state = tab.pendingState
                ratio = tab.pendingScrollRatio
                sx = tab.pendingScrollX
                sy = tab.pendingScrollY
            }
        }
        return TabHandoff(
            url = url, title = title, desktop = tab.desktop, incognito = tab.incognito,
            pageZoom = tab.pageZoom, muted = tab.muted, rate = tab.rate,
            state = state, scrollRatio = ratio, scrollX = sx, scrollY = sy
        )
    }

    /** [target] 창으로 탭을 옮긴다 (null 이면 새 창을 열어 거기로). 이 창에서는 탭이 닫힌다. 옮겼으면 true */
    private fun moveTabToWindow(
        tab: BrowserTab,
        target: MainActivity?,
        mode: Int = WIN_DEFAULT,
        dropX: Int = 0,
        dropY: Int = 0,
        closeEmptyWindow: Boolean = false,
        selectInTarget: Boolean = false
    ): Boolean {
        if (target == null && tab.incognito) {
            toast("시크릿 탭은 새 창으로 옮길 수 없어요")
            return false
        }
        if (target != null && (target.isFinishing || target.isDestroyed)) return false
        // 탭을 닫기 전에 상태를 먼저 담는다
        val h = captureHandoff(tab)
        val closeWindow = tabs.size == 1 && (target != null || closeEmptyWindow)
        if (target == null) {
            openNewWindow(
                h.url, handoff = h, mode = mode, dropX = dropX, dropY = dropY,
                inheritNo = if (closeWindow) windowNo else 0
            )
        } else target.receiveTab(h, select = selectInTarget)
        // 다른 창으로 옮기다 이 창이 비면 창도 닫는다. 메뉴로 새 창에 옮길 때는 이 창에 새(홈) 탭을 남기고,
        // 탭을 끌어서 새 창으로 뺄 때는 closeEmptyWindow 로 빈 창을 같이 닫는다
        closeTab(tab, quitIfLast = closeWindow)
        if (closeWindow) return true
        toast(
            when {
                target != null -> "탭을 ${target.windowLabel}(으)로 옮겼어요"
                mode == WIN_POPUP -> "팝업 창으로 옮겼어요"
                else -> "새 창으로 옮겼어요"
            }
        )
        return true
    }

    /** 탭을 옮길 창을 고른다: 열려 있는 다른 창들을 앱 공통 팝업(메뉴와 같은 모양)으로 보여 준다 */
    private fun showMoveTabChooser(
        tab: BrowserTab,
        windows: List<MainActivity>,
        canNewWindow: Boolean,
        onChanged: () -> Unit
    ) {
        fun move(target: MainActivity?) {
            // 고르는 사이 대상 창이 닫혔을 수 있다
            if (target != null && (target.isFinishing || target.isDestroyed)) {
                toast("그 창은 이미 닫혔어요")
                return
            }
            if (moveTabToWindow(tab, target)) onChanged()
        }
        val items = ArrayList<Popup.Item>()
        windows.forEach { w ->
            items.add(Popup.Item(R.drawable.ic_tab, w.windowLabel, "탭 ${w.tabs.size}개") { move(w) })
        }
        if (canNewWindow) {
            items.add(Popup.Item(R.drawable.ic_add, "새 창", "이 탭만 담은 새 창을 엽니다") { move(null) })
        }
        Popup.menu(
            this,
            title = "탭을 다른 창으로 이동",
            subtitle = tabTitle(tab),
            headerIcon = R.drawable.ic_tab,
            items = items
        )
    }

    /** 창 전환: 분할로 나란히 열지 않고, 선택한 창을 앞으로 가져온 뒤 지금 창은 닫는다 (탭은 남아 창 목록에서 다시 열 수 있다) */
    private fun switchToWindow(w: MainActivity) {
        // 지금 창이 멀티윈도우(분할 화면·떠 있는 창)였다면, 선택한 창을 그냥 앞으로 가져오면 분할이 깨지고 전체 화면으로 뜬다.
        // 그래서 선택한 창의 탭을 저장한 뒤 닫고, 지금 창이 있던 자리에 같은 창 번호로 다시 연다 (페이지 기록·스크롤은 저장분으로 이어진다).
        // 다음 경우는 예전처럼 앞으로 가져온다: 시크릿 탭이 있어서(저장되지 않아 사라짐) / 선택한 창이 이미 옆 칸에 보이고 있어서
        if (isInMultiWindowMode && !isInPictureInPictureMode && !w.visibleNow && w.tabs.none { it.incognito }) {
            val no = w.windowNo
            w.saveTabs()
            w.finishAndRemoveTask()
            openInPlaceOfThisWindow(no)
            return
        }
        bringWindowToFront(w)
        finishAndRemoveTask()
    }

    /** 저장된 창 [no] 를 새로 열고 지금 창은 닫는다. 지금 창이 멀티윈도우였다면 새 창이 같은 자리(분할 칸·떠 있는 창 위치)를 이어받는다 */
    private fun openInPlaceOfThisWindow(no: Int) {
        val multi = isInMultiWindowMode && !isInPictureInPictureMode
        openNewWindow(restoreNo = no, adjacent = false, bounds = if (multi) floatingWindowBounds() else null)
        finishAndRemoveTask()
    }

    /** 다른 창을 맨 앞으로 가져온다 */
    @Suppress("DEPRECATION")
    private fun bringWindowToFront(w: MainActivity) {
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
            val target = am.appTasks.firstOrNull { t ->
                val info = t.taskInfo
                val id = if (Build.VERSION.SDK_INT >= 29) info.taskId else info.id
                id == w.taskId
            }
            if (target != null) target.moveToFront() else toast("창을 찾지 못했어요")
        } catch (e: Throwable) {
            toast("창을 전환하지 못했어요")
        }
    }

    /** 창 닫기: 안에 열린 페이지가 있으면 한 번 물어본다 */
    private fun confirmCloseWindow(w: MainActivity) {
        val pages = w.tabs.count { !it.isHome }
        fun doClose() {
            w.finishAndRemoveTask()
            refreshWindowStrip(skip = w)
        }
        // 이름을 붙인 창은 빈 창이어도 한 번 더 물어본다
        val named = w.windowName != null
        if (pages == 0 && !named) {
            doClose()
            return
        }
        ThemedDialogBuilder(this)
            .setTitle("${w.windowLabel} 닫기")
            .setMessage(
                if (pages == 0) "이 창을 닫을까요?"
                else "창만 닫혀요. 탭 ${w.tabs.size}개는 남아 있어서 창 목록에서 다시 열 수 있어요."
            )
            .setNegativeButton("취소", null)
            .setPositiveButton("창 닫기") { _, _ -> doClose() }
            .show()
    }

    private fun refreshSwitcher(animateIn: Boolean, skipEnter: BrowserTab? = null) {
        scheduleStripRefresh()

        // 다시 그리기 전 위치를 기억해 두었다가, 남은 카드들이 미끄러지듯 새 자리로 이동하게 한다.
        val before = HashMap<BrowserTab, Pair<Int, Int>>()
        if (!animateIn) {
            val loc = IntArray(2)
            switcherRows.forEach { (tb, v) ->
                v.getLocationOnScreen(loc)
                before[tb] = loc[0] to loc[1]
            }
        }
        switcherRows.clear()
        switcherBoxes.clear()
        selCardBg.clear()
        selCardCheck.clear()
        selGroupCheck.clear()
        selHeaderMembers.clear()
        tabList.removeAllViews()
        // 다시 그리는 사이 사라진 탭은 선택에서 뺀다
        switcherSel.retainAll(tabs.toSet())
        updateSelectUi()
        refreshWindowStrip()
        val list = tabList

        var pending: LinearLayout? = null
        // 카드/헤더를 붙이는 곳: 평소엔 목록 자체, 그룹을 그리는 동안엔 그 그룹의 둥근 상자
        var target: LinearLayout = list
        var enterIndex = 0

        // 정사각형 카드: 폰은 2열, 화면이 넓을수록 열이 늘어난다 (카드가 너무 커지지 않도록).
        val cols = switcherCols()

        fun flushRow() {
            val p = pending ?: return
            while (p.childCount < cols) {
                p.addView(
                    View(this),
                    LinearLayout.LayoutParams(0, 1, 1f).apply { setMargins(dp(6), 0, dp(6), 0) }
                )
            }
            pending = null
        }

        fun addCell(v: View) {
            var p = pending
            if (p == null || p.childCount >= cols) {
                p = LinearLayout(this)
                p.orientation = LinearLayout.HORIZONTAL
                p.clipChildren = false
                p.tag = CARD_ROW_TAG
                // 그룹 상자 안은 상자 여백이 있어서 카드가 바깥 카드와 같은 선에 맞도록 여백을 줄인다
                val side = if (target === list) dp(12) else dp(4)
                target.addView(
                    p,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(side, 0, side, 0) }
                )
                pending = p
            }
            p.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            )
        }

        fun addTabRow(tab: BrowserTab, group: TabGroup?) {
            val row = layoutInflater.inflate(R.layout.item_tab, list, false)
            switcherRows[tab] = row
            row.findViewById<TextView>(R.id.tabTitle).text =
                if (tab.isHome) (if (tab.incognito) "시크릿 탭" else "새 탭")
                else tabTitle(tab)
            val fav = row.findViewById<ImageView>(R.id.tabFavicon)
            val bmp = if (tab.isHome) null else tab.favicon
            if (tab.incognito) {
                // 시크릿 탭 카드는 어둡게, 아이콘은 시크릿 모양으로
                row.findViewById<TextView>(R.id.tabTitle).setTextColor(incognitoTextColor)
                row.findViewById<ImageView>(R.id.tabClose).imageTintList =
                    android.content.res.ColorStateList.valueOf(incognitoTextColor)
                fav.setImageResource(R.drawable.ic_incognito)
                fav.imageTintList = android.content.res.ColorStateList.valueOf(incognitoTextColor)
            } else if (bmp != null) fav.setImageBitmap(bmp) else fav.setImageResource(homeIconRes())
            setThumb(row.findViewById(R.id.tabThumb), tab.thumb)

            val bar = row.findViewById<View>(R.id.tabGroupBar)
            if (group != null) {
                bar.visibility = View.VISIBLE
                bar.background.mutate().setTint(group.color)
            } else {
                bar.visibility = View.GONE
            }

            // 선택 모드에서는 '현재 탭' 대신 '고른 탭' 이 강조된다
            val lit = if (switcherSelecting) tab in switcherSel else tab === current
            if (!switcherSelecting) {
                row.setBackgroundResource(
                    when {
                        tab.incognito && lit -> R.drawable.bg_tab_card_incognito_active
                        tab.incognito -> R.drawable.bg_tab_card_incognito
                        lit -> R.drawable.bg_tab_card_active
                        else -> R.drawable.bg_tab_card
                    }
                )
            }
            if (switcherSelecting) {
                // 선택 모드: 카드를 누르면 체크가 켜지고 꺼진다. X 자리는 체크 동그라미가 된다.
                // (밀어서 닫기 · 길게 눌러 순서 바꾸기는 꺼 둔다)
                // 누를 때마다 목록을 다시 그리지 않고, 이 카드의 바탕 · 체크만 제자리에서 부드럽게 바꾼다.
                val sel = tab in switcherSel
                val outline = ThemeColors.get(row, com.google.android.material.R.attr.colorOutline)
                val cardBg = SelectCardDrawable(
                    offFill = if (tab.incognito) 0xFF3C4043.toInt() else selColor(com.google.android.material.R.attr.colorSurface),
                    onFill = if (tab.incognito) 0xFF3C4043.toInt() else selColor(com.google.android.material.R.attr.colorPrimaryContainer),
                    offStroke = if (tab.incognito) 0xFF5F6368.toInt() else selColor(com.google.android.material.R.attr.colorOutlineVariant),
                    onStroke = selColor(com.google.android.material.R.attr.colorPrimary),
                    radius = dp(15).toFloat(), offW = dp(1).toFloat(), onW = dp(2).toFloat()
                )
                // 선택 모드로 막 들어왔을 때는 '현재 탭' 강조가 스르르 꺼진다
                val fadeFrom = selEntering && tab === current && !sel
                cardBg.snapTo(if (sel || fadeFrom) 1f else 0f)
                row.background = cardBg
                selCardBg[tab] = cardBg

                val check = row.findViewById<ImageButton>(R.id.tabClose)
                val checkDrawable = bindSelectCheck(
                    check, if (tab.incognito) incognitoTextColor else outline, dp(4)
                )
                checkDrawable.snapTo(if (sel) 1f else 0f)
                selCardCheck[tab] = checkDrawable
                check.contentDescription = if (sel) "선택 해제" else "선택"
                check.setOnClickListener { toggleTabSelected(tab) }
                row.setOnClickListener { toggleTabSelected(tab) }
                val thumb = row.findViewById<View>(R.id.tabThumb)
                thumb.scaleX = if (sel) SEL_THUMB_SCALE else 1f
                thumb.scaleY = thumb.scaleX
                Motion.pressable(row, 0.96f)
                if (selEntering && Motion.enabled(this)) {
                    // X 가 체크 동그라미로 바뀔 때 톡 나타난다
                    Motion.pop(check, 0.4f)
                    if (fadeFrom) row.post { cardBg.animateTo(0f, 380f, 1f) }
                }
                addCell(row)
                return
            }
            row.setOnClickListener { closeTabSwitcher(tab) }
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 탭 메뉴
            bindDragGesture(
                row, 0.96f,
                onStart = { x, y -> startSwitcherDrag(tab, x, y) },
                onMove = { x, y -> swDrag?.let { it.rawX = x; it.rawY = y; updateSwitcherDrag() } },
                onEnd = { moved, canceled -> endSwitcherDrag(moved, canceled) },
                // 카드를 옆으로 밀어서 닫기 (X 버튼과 같은 동작)
                onSwipeDismiss = {
                    if (!switcherBusy) {
                        // 탭 목록 화면에서는 마지막 탭을 닫아도 앱을 끄지 않고 빈 새 탭(홈)만 남긴다
                        closeTabUndoable(tab, quitIfLast = false)
                        refreshSwitcher(false)
                    }
                },
                canSwipe = { !switcherBusy && !groupToggling && swDrag == null }
            )
            row.findViewById<ImageButton>(R.id.tabClose).setOnClickListener {
                if (switcherBusy) return@setOnClickListener
                it.isEnabled = false
                Motion.flyAway(row) {
                    closeTabUndoable(tab, quitIfLast = false)
                    refreshSwitcher(false)
                }
            }
            if (animateIn && tab !== skipEnter) {
                Motion.enter(row, minOf(enterIndex++ * 45L + 80L, 380L))
            }
            addCell(row)
        }

        fun addGroupHeader(group: TabGroup) {
            val header = layoutInflater.inflate(R.layout.item_group_header, target, false)
            val members = tabs.filter { it.groupId == group.id }
            header.findViewById<View>(R.id.groupDot).background.mutate().setTint(group.color)
            header.findViewById<TextView>(R.id.groupName).text = group.name
            // 개수: 그룹 색을 옅게 깐 알약 모양
            header.findViewById<TextView>(R.id.groupCount).apply {
                text = "${members.size}"
                setPadding(dp(9), dp(2), dp(9), dp(2))
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor(ColorUtils.setAlphaComponent(group.color, 0x40))
                }
            }
            // 접혀 있을 때는 안에 든 탭들의 아이콘을 작게 겹쳐 보여 준다
            val surfaceColor = ThemeColors.get(header, com.google.android.material.R.attr.colorSurface, 0)
            header.findViewById<LinearLayout>(R.id.groupPreview).apply {
                removeAllViews()
                if (group.collapsed) {
                    members.take(3).forEachIndexed { i, t ->
                        addView(ImageView(this@MainActivity).apply {
                            val bmp = if (t.isHome) null else t.favicon
                            if (bmp != null) setImageBitmap(bmp) else setImageResource(
                                if (t.isHome) homeIconRes() else R.drawable.ic_globe
                            )
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            setPadding(dp(2), dp(2), dp(2), dp(2))
                            background = GradientDrawable().apply {
                                shape = GradientDrawable.OVAL
                                setColor(surfaceColor)
                                setStroke(dp(1), group.color)
                            }
                        }, LinearLayout.LayoutParams(dp(20), dp(20)).apply {
                            if (i > 0) marginStart = -dp(6)
                        })
                    }
                    visibility = View.VISIBLE
                } else {
                    visibility = View.GONE
                }
            }
            // 펼침/접힘 화살표: 이전 상태에서 새 상태로 부드럽게 돌아간다
            val chevron = header.findViewById<ImageView>(R.id.groupChevron)
            val goal = if (group.collapsed) 0f else 180f
            val prev = groupRendered[group.id]
            if (prev != null && prev != group.collapsed && Motion.enabled(this)) {
                chevron.rotation = if (prev) 0f else 180f
                Motion.spring(chevron, DynamicAnimation.ROTATION, goal, 300f, 0.6f)
                Motion.pop(header.findViewById(R.id.groupCount), 0.7f)
            } else {
                chevron.rotation = goal
            }
            groupRendered[group.id] = group.collapsed
            header.setOnClickListener {
                if (groupToggling) return@setOnClickListener
                if (!group.collapsed && Motion.enabled(this)) {
                    // 접을 때: 카드들이 먼저 작아지며 사라진 뒤 목록을 다시 그린다
                    groupToggling = true
                    members.forEach { m ->
                        switcherRows[m]?.animate()?.alpha(0f)?.scaleX(0.85f)?.scaleY(0.85f)?.setDuration(140)?.start()
                    }
                    ui.postDelayed({
                        group.collapsed = true
                        groupToggling = false
                        refreshSwitcher(false)
                    }, 150)
                } else {
                    group.collapsed = !group.collapsed
                    refreshSwitcher(false)
                }
            }
            header.findViewById<ImageButton>(R.id.groupMenu).setOnClickListener {
                showGroupMenu(group, true) { refreshSwitcher(false) }
            }
            if (switcherSelecting) {
                // 선택 모드: 그룹 줄을 누르면 그 그룹의 탭이 모두 선택되고 (접혀 있어도), 다시 누르면 모두 해제된다
                val menuBtn = header.findViewById<ImageButton>(R.id.groupMenu)
                val allOn = members.isNotEmpty() && members.all { it in switcherSel }
                val someOn = members.any { it in switcherSel }
                val gCheck = bindSelectCheck(
                    menuBtn,
                    ThemeColors.get(menuBtn, com.google.android.material.R.attr.colorOutline),
                    dp(10)
                )
                gCheck.partial = someOn && !allOn
                gCheck.snapTo(if (allOn) 1f else 0f)
                selGroupCheck[group.id] = gCheck
                selHeaderMembers[group.id] = members
                if (selEntering && Motion.enabled(this)) Motion.pop(menuBtn, 0.4f)
                menuBtn.contentDescription = if (allOn) "그룹 선택 해제" else "그룹 전체 선택"
                menuBtn.setOnClickListener { toggleGroupSelected(group) }
                header.setOnClickListener { toggleGroupSelected(group) }
            }
            Motion.pressable(header, 0.98f)
            flushRow()
            target.addView(header)
        }

        /** 그룹을 담는 둥근 상자: 그룹 색을 옅게 깔고 테두리를 둘러 같은 그룹임을 한눈에 보여 준다 */
        fun newGroupBox(group: TabGroup): LinearLayout {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(0, dp(2), 0, dp(6))
            box.background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(ColorUtils.setAlphaComponent(group.color, 0x24))
                setStroke(dp(1), ColorUtils.setAlphaComponent(group.color, 0x66))
            }
            box.clipToOutline = true
            switcherBoxes[group.id] = box
            list.addView(
                box,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(8), dp(6), dp(8), dp(6)) }
            )
            return box
        }

        // 탭 순서대로 훑으면서, 그룹은 처음 나온 자리에 헤더 + 소속 탭을 한 번에 그린다.
        val drawn = mutableSetOf<Int>()
        tabs.toList().forEach { tab ->
            val g = groupOf(tab)
            if (g == null) {
                addTabRow(tab, null)
            } else if (drawn.add(g.id)) {
                flushRow()
                target = newGroupBox(g)
                addGroupHeader(g)
                if (!g.collapsed) {
                    tabs.filter { it.groupId == g.id }.forEach { addTabRow(it, g) }
                }
                flushRow()
                target = list
            }
        }
        flushRow()
        if (!animateIn) {
            Motion.glideFrom(list, before.mapNotNull { (tb, pos) -> switcherRows[tb]?.let { it to pos } }.toMap())
            // 그룹을 펼칠 때처럼 새로 나타나는 카드는 차례로 떠오르게 한다
            if (before.isNotEmpty()) {
                var i = 0
                switcherRows.forEach { (tb, row) ->
                    if (tb !in before) Motion.enter(row, minOf(i++ * 45L + 30L, 300L))
                }
            }
        }
    }

    private fun closeAllTabs() {
        val old = tabs.toList()
        closeTabsUndoable(old) {
            createTab(null, home = true)
            old.forEach { closeTab(it) }
        }
    }

    // ───────────────────────── 탭 화면 선택 모드 (여러 탭 한 번에 닫기) ─────────────────────────
    // 제목줄의 '선택' → 카드를 눌러 체크 → 아래 막대의 '삭제 (n)'. 그룹 줄을 누르면 그 그룹 전체가 선택된다.
    // 뒤로 가기는 먼저 선택 모드부터 끈다.

    private fun selColor(attr: Int) = ThemeColors.get(tabSwitcher, attr)

    /** 아래 막대(전체 선택 · 삭제)의 모양과 동작. 탭 화면을 만들 때 한 번만 건다. */
    private fun setupSelectBar() {
        val bar = tabSwitcher.findViewById<View>(R.id.selectBar)
        // 바탕과 구분되도록 한 단계 밝은 면 + 가는 테두리
        bar.background = GradientDrawable().apply {
            cornerRadius = dp(26).toFloat()
            setColor(selColor(com.google.android.material.R.attr.colorSurfaceContainerHighest))
            setStroke(dp(1), selColor(com.google.android.material.R.attr.colorOutlineVariant))
        }
        Motion.pressable(tabSwitcher.findViewById(R.id.selectDelete), 0.94f)
        tabSwitcher.findViewById<View>(R.id.selectAll).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            if (switcherSel.size == tabs.size) switcherSel.clear() else switcherSel.addAll(tabs)
            tabSwitcher.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
            syncSelection(stagger = true)
        }
        tabSwitcher.findViewById<View>(R.id.selectDelete).setOnClickListener {
            if (switcherSel.isNotEmpty()) confirmCloseSelected()
        }
    }

    /** 버튼의 바탕을 체크 동그라미 그림으로 바꾸고 돌려준다 (켜고 끄는 움직임은 이 그림이 맡는다). */
    private fun bindSelectCheck(btn: ImageButton, offColor: Int, inset: Int): CheckCircleDrawable {
        val d = CheckCircleDrawable(
            primary = selColor(com.google.android.material.R.attr.colorPrimary),
            offColor = offColor,
            onPrimary = selColor(com.google.android.material.R.attr.colorOnPrimary),
            strokePx = dp(2).toFloat()
        )
        btn.background = android.graphics.drawable.InsetDrawable(d, inset)
        btn.setImageDrawable(null)
        return d
    }

    /**
     * 선택이 바뀌었을 때 카드를 다시 만들지 않고 제자리에서 바꾼다.
     * 카드 바탕 색 · 테두리, 체크가 그려지는 모습, 미리보기가 살짝 작아지는 모습이 모두 스프링으로 이어진다.
     * 누르는 중이던 카드의 눌림 → 복귀 움직임도 끊기지 않는다.
     */
    private fun syncSelection(stagger: Boolean = false) {
        updateSelectUi()
        val animate = Motion.enabled(this)
        var i = 0
        selCardBg.forEach { (tab, bg) ->
            val on = tab in switcherSel
            val target = if (on) 1f else 0f
            val check = selCardCheck[tab]
            val thumb = switcherRows[tab]?.findViewById<View>(R.id.tabThumb)
            val changed = bg.progress.let { (it > 0.5f) != on } || check?.progress?.let { (it > 0.5f) != on } == true
            val delay = if (stagger && animate && changed) minOf(i++ * 18L, 220L) else 0L
            val apply = Runnable {
                if (!animate) {
                    bg.snapTo(target); check?.snapTo(target)
                    thumb?.scaleX = if (on) SEL_THUMB_SCALE else 1f
                    thumb?.scaleY = thumb?.scaleX ?: 1f
                } else {
                    // 켤 때는 통통 튀고, 끌 때는 군더더기 없이 돌아간다
                    bg.animateTo(target, 420f, if (on) 0.8f else 1f)
                    check?.animateTo(target, if (on) 520f else 600f, if (on) 0.5f else 1f)
                    thumb?.let {
                        Motion.spring(it, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X,
                            if (on) SEL_THUMB_SCALE else 1f, 420f, if (on) 0.55f else 0.9f)
                        Motion.spring(it, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y,
                            if (on) SEL_THUMB_SCALE else 1f, 420f, if (on) 0.55f else 0.9f)
                    }
                }
                switcherRows[tab]?.findViewById<ImageButton>(R.id.tabClose)?.contentDescription =
                    if (on) "선택 해제" else "선택"
            }
            if (delay > 0) ui.postDelayed(apply, delay) else apply.run()
        }
        // 그룹 줄: 전부 / 일부 / 없음
        selGroupCheck.forEach { (gid, gc) ->
            val members = selHeaderMembers[gid] ?: return@forEach
            val allOn = members.isNotEmpty() && members.all { it in switcherSel }
            val someOn = members.any { it in switcherSel }
            gc.partial = someOn && !allOn
            val target = if (allOn) 1f else 0f
            if (animate) gc.animateTo(target, if (allOn) 520f else 600f, if (allOn) 0.5f else 1f) else gc.snapTo(target)
        }
    }

    /** 제목줄 · 아래 막대를 선택 상태에 맞춘다 */
    private fun updateSelectUi() {
        val sel = switcherSelecting
        val n = switcherSel.size
        tabsTitle.text = when {
            !sel -> "탭 (${tabs.size})"
            n == 0 -> "탭을 선택하세요"
            else -> "${n}개 선택됨"
        }
        tabSwitcher.findViewById<Button>(R.id.btnSelectTabs).setText(
            if (sel) R.string.cancel_select else R.string.select_tabs
        )
        tabSwitcher.findViewById<View>(R.id.btnSwitcherMore).visibility = if (sel) View.GONE else View.VISIBLE
        if (!sel) {
            lastSelCount = 0
            delPillReady = null
            delPillAnim?.cancel()
            delPillAnim = null
            selAllCheck?.snapTo(0f)
            return
        }

        val allOn = tabs.isNotEmpty() && n == tabs.size
        tabSwitcher.findViewById<TextView>(R.id.selectAllText).text = if (allOn) "선택 해제" else "전체 선택"
        val allCheck = tabSwitcher.findViewById<ImageView>(R.id.selectAllCheck)
        val allDrawable = selAllCheck ?: CheckCircleDrawable(
            primary = selColor(com.google.android.material.R.attr.colorPrimary),
            offColor = selColor(com.google.android.material.R.attr.colorOutline),
            onPrimary = selColor(com.google.android.material.R.attr.colorOnPrimary),
            strokePx = dp(2).toFloat()
        ).also {
            selAllCheck = it
            allCheck.setPadding(0, 0, 0, 0)
            allCheck.background = it
            allCheck.setImageDrawable(null)
            it.snapTo(if (allOn) 1f else 0f)
        }
        if (Motion.enabled(this)) allDrawable.animateTo(if (allOn) 1f else 0f, if (allOn) 520f else 600f, if (allOn) 0.5f else 1f)
        else allDrawable.snapTo(if (allOn) 1f else 0f)
        // '삭제' 알약: 고른 것이 있으면 빨갛게 (누를 수 있음), 없으면 회색으로 눌러도 반응 없음
        val del = tabSwitcher.findViewById<TextView>(R.id.selectDelete)
        val ready = n > 0
        val onSurface = selColor(com.google.android.material.R.attr.colorOnSurface)
        val bgOn = androidx.core.content.ContextCompat.getColor(this, R.color.ev_danger)
        val bgOff = ColorUtils.setAlphaComponent(onSurface, 0x1F)
        val fgOn = androidx.core.content.ContextCompat.getColor(this, R.color.ev_on_danger)
        val fgOff = ColorUtils.setAlphaComponent(onSurface, 0x61)
        del.isEnabled = ready
        val pill = delPill ?: GradientDrawable().apply { cornerRadius = dp(22).toFloat() }.also {
            delPill = it
            del.background = it
        }
        fun paint(t: Float) {
            pill.setColor(ColorUtils.blendARGB(bgOff, bgOn, t))
            val fg = ColorUtils.blendARGB(fgOff, fgOn, t)
            del.setTextColor(fg)
            del.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(fg)
        }
        val goal = if (ready) 1f else 0f
        if (delPillReady == ready && delPillAnim?.isRunning == true) {
            // 이미 그 색으로 바뀌는 중이면 그대로 둔다 (개수만 바뀐 경우)
        } else if (delPillReady == null || delPillReady == ready || !Motion.enabled(this)) {
            delPillAnim?.cancel()
            delPillAnim = null
            paint(goal)
        } else {
            delPillAnim?.cancel()
            // 회색 ↔ 빨강이 스르르 바뀐다
            delPillAnim = android.animation.ValueAnimator.ofFloat(1f - goal, goal).apply {
                duration = 220
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener { paint(it.animatedValue as Float) }
                start()
            }
        }
        delPillReady = ready
        del.text = if (ready) "삭제 ($n)" else "삭제"
        del.contentDescription = if (ready) "선택한 탭 ${n}개 삭제" else "삭제 (탭을 먼저 선택하세요)"
        // 개수가 바뀌면 알약이 톡 튄다 (처음 켜질 때는 제외)
        if (ready && lastSelCount > 0 && lastSelCount != n) Motion.pop(del, 0.88f)
        lastSelCount = n
    }

    private var lastSelCount = 0
    private val SEL_THUMB_SCALE = 0.92f

    /** 아래 자리를 [새 탭 버튼 줄] ↔ [선택 막대] 로 바꾼다. 같은 자리에 겹쳐 있어서 목록 높이가 변하지 않는다. */
    private fun swapBottom(toSelect: Boolean, animate: Boolean) {
        val bar = tabSwitcher.findViewById<View>(R.id.selectBar)
        val buttons = tabSwitcher.findViewById<View>(R.id.switcherBottom)
        val showV = if (toSelect) bar else buttons
        val hideV = if (toSelect) buttons else bar
        Motion.cancel(showV)
        showV.animate().cancel()
        hideV.animate().cancel()
        showV.visibility = View.VISIBLE
        if (!animate || !Motion.enabled(this)) {
            showV.alpha = 1f; showV.translationY = 0f
            hideV.visibility = View.GONE
            hideV.alpha = 1f; hideV.translationY = 0f
            return
        }
        // 나타나는 쪽은 아래에서 떠오르고, 사라지는 쪽은 아래로 가라앉으며 옅어진다
        showV.alpha = 0f
        showV.translationY = dp(24).toFloat()
        Motion.spring(showV, DynamicAnimation.ALPHA, 1f, 400f, 1f)
        Motion.spring(showV, DynamicAnimation.TRANSLATION_Y, 0f, 380f, 0.78f)
        hideV.animate().alpha(0f).translationY(dp(24).toFloat()).setDuration(120).withEndAction {
            hideV.visibility = View.GONE
            hideV.alpha = 1f
            hideV.translationY = 0f
        }.start()
    }

    private fun enterSelectMode() {
        if (switcherSelecting) return
        switcherSelecting = true
        switcherSel.clear()
        lastSelCount = 0
        updateSelectUi()
        swapBottom(toSelect = true, animate = true)
        selEntering = true
        try { refreshSwitcher(false) } finally { selEntering = false }
    }

    /** animate: 사용자가 취소/뒤로 가기로 끌 때만 true. 탭 화면을 열고 닫는 중에는 바로 정리한다. */
    private fun exitSelectMode(redraw: Boolean = true, animate: Boolean = redraw) {
        if (!switcherSelecting) return
        switcherSelecting = false
        switcherSel.clear()
        updateSelectUi()
        swapBottom(toSelect = false, animate = animate)
        if (redraw) refreshSwitcher(false)
    }

    private fun toggleTabSelected(tab: BrowserTab) {
        if (switcherBusy || groupToggling) return
        if (!switcherSel.remove(tab)) switcherSel.add(tab)
        tabSwitcher.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        syncSelection()
    }

    private fun toggleGroupSelected(group: TabGroup) {
        if (switcherBusy || groupToggling) return
        val members = tabs.filter { it.groupId == group.id }
        if (members.isEmpty()) return
        if (members.all { it in switcherSel }) switcherSel.removeAll(members.toSet())
        else switcherSel.addAll(members)
        tabSwitcher.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        syncSelection(stagger = true)
    }

    /** 탭은 닫으면 다시 살릴 수 없어서(실행 취소가 안 돼서) 한 번 물어본다 */
    private fun confirmCloseSelected() {
        if (switcherBusy || groupToggling || swDrag != null) return
        val sel = tabs.filter { it in switcherSel }
        if (sel.isEmpty()) return
        val all = sel.size == tabs.size
        ThemedDialogBuilder(this)
            .setTitle(if (all) "탭 모두 닫기" else "탭 ${sel.size}개 닫기")
            .setMessage(
                if (all) "열려 있는 탭 ${sel.size}개를 모두 닫을까요? 빈 새 탭이 하나 남아요."
                else "선택한 탭 ${sel.size}개를 닫을까요?"
            )
            .setNegativeButton("취소", null)
            .setPositiveButton("닫기") { _, _ -> closeSelectedTabs() }
            .show()
    }

    private fun closeSelectedTabs() {
        if (switcherBusy) return
        val sel = tabs.filter { it in switcherSel }
        if (sel.isEmpty()) return
        val all = sel.size == tabs.size
        fun doClose() {
            if (all) {
                // 전부 고른 경우: 모두 닫기와 똑같이, 빈 새 탭(홈) 하나만 남긴다
                closeAllTabs()
            } else {
                // 지금 보던 탭은 맨 마지막에 닫는다 → 닫은 뒤 이어서 볼 탭을 고를 때, 이미 닫힌 탭이 뽑히지 않는다
                val order = sel.sortedBy { if (it === current) 1 else 0 }
                closeTabsUndoable(order) { order.forEach { closeTab(it, quitIfLast = false) } }
            }
            exitSelectMode(redraw = false, animate = true)
            refreshSwitcher(false)
        }
        if (!Motion.enabled(this)) {
            doClose()
            return
        }
        // 고른 카드들이 한꺼번에 작아지며 사라진 뒤 목록을 다시 그린다 (남은 카드는 빈자리로 미끄러진다)
        switcherBusy = true
        var fired = false
        val fire = {
            if (!fired) {
                fired = true
                switcherBusy = false
                doClose()
            }
        }
        sel.forEach { t ->
            val v = switcherRows[t] ?: return@forEach
            v.animate().alpha(0f).scaleX(0.82f).scaleY(0.82f).setDuration(160).start()
        }
        ui.postDelayed({ fire() }, 170)
    }

    /** 새 탭을 열었을 때: 홈 화면이 이미 보이는 중이어도 등장 애니메이션을 한 번 재생한다 */
    private var pendingHomeEnter = false

    private fun openNewTabAndFocus(opener: BrowserTab? = null, incognito: Boolean = false) {
        // 확장 프로그램이 새 탭 화면을 바꿨으면(chrome_url_overrides.newtab) 그 페이지를 연다. 시크릿 탭에서는 확장을 쓰지 않는다
        val extNewTab = if (incognito) null else extensions.overrideUrl("newtab")
        if (extNewTab != null) {
            createTab(extNewTab, opener = opener)
            hideKeyboard()
            return
        }
        val custom = prefs.homepage
        if (custom.isNotEmpty() && prefs.homepageOnNewTab && !incognito) {
            createTab(custom, opener = opener)
            hideKeyboard()
            return
        }
        // 이미 새 탭 화면을 보고 있어도 새 탭이 열리면 등장 애니메이션을 다시 보여 준다
        pendingHomeEnter = true
        createTab(null, opener = opener, home = true, incognito = incognito)
        // 새 탭(홈)에서 키보드가 저절로 올라오지 않게 한다. 입력하려면 검색창을 누르면 된다.
        hideKeyboard()
    }

    // ───────────────────────── 웹뷰 설정 ─────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    // ───────────────────────── 웹 대화상자 · 권한 · 인증 · 렌더러 복구 ─────────────────────────

    // ── JS 알림창 (alert / confirm / prompt) ──

    /** 보이는 탭에서만 띄우고, 짧은 시간에 계속 띄우는 페이지(알림창 도배)는 막는다 */
    private fun jsDialogAllowed(tab: BrowserTab): Boolean {
        if (tab !== current || isFinishing || isDestroyed || switcherOpen) return false
        val now = android.os.SystemClock.uptimeMillis()
        if (now - tab.jsDialogAt > 4000L) tab.jsDialogCount = 0
        tab.jsDialogAt = now
        return ++tab.jsDialogCount <= 3
    }

    private fun jsDialogTitle(url: String?): String {
        val host = runCatching { Uri.parse(url).host }.getOrNull()
        return if (host.isNullOrBlank()) "페이지 메시지" else "$host 의 메시지"
    }

    /** kind: 0 = alert, 1 = confirm, 2 = prompt */
    private fun showJsDialog(
        url: String?, message: String?, kind: Int,
        defaultValue: String?, result: android.webkit.JsResult
    ) {
        var done = false
        fun finish(ok: Boolean, text: String? = null) {
            if (done) return
            done = true
            try {
                if (ok) {
                    if (result is android.webkit.JsPromptResult) result.confirm(text ?: "") else result.confirm()
                } else {
                    result.cancel()
                }
            } catch (e: Exception) {
                // 페이지가 이미 사라졌으면 무시
            }
        }
        val b = ThemedDialogBuilder(this).setTitle(jsDialogTitle(url))
        var input: EditText? = null
        if (kind == 2) {
            val pad = dp(20)
            val box = FrameLayout(this)
            val field = EditText(this).apply {
                setText(defaultValue.orEmpty())
                setSelectAllOnFocus(true)
                setSingleLine()
            }
            Popup.styleInput(field)
            input = field
            box.setPadding(pad, dp(4), pad, 0)
            box.addView(field)
            b.setMessage(message.orEmpty()).setView(box)
        } else {
            b.setMessage(message.orEmpty())
        }
        b.setPositiveButton("확인") { _, _ -> finish(true, input?.text?.toString()) }
        if (kind != 0) b.setNegativeButton("취소") { _, _ -> finish(false) }
        // 뒤로가기/바깥 터치: alert 는 '확인'으로, confirm/prompt 는 '취소'로 처리
        b.setOnCancelListener { finish(kind == 0) }
        b.setOnDismissListener { finish(false) }
        b.show()
    }

    // ── 카메라 · 마이크 · 위치 권한 ──

    private val webPermDecisions = HashMap<String, Boolean>()
    private var webPermDialog: AlertDialog? = null
    private var webPermDone: (() -> Unit)? = null
    private val webPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val cb = webPermDone
            webPermDone = null
            cb?.invoke()
        }

    /**
     * 사이트가 카메라/마이크/위치를 쓰려 할 때: 사이트별로 허용/차단을 묻고(이번 실행 동안 기억),
     * 안드로이드 권한이 없으면 시스템 권한 창을 이어서 띄운다. anyOf: 목록 중 하나만 허용돼도 충분한지(위치).
     */
    private fun askWebPermission(
        origin: String, label: String, osPerms: List<String>, anyOf: Boolean, onDone: (Boolean) -> Unit
    ) {
        fun osOk() = if (anyOf) osPerms.any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        else osPerms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

        fun withOs() {
            if (osOk()) { onDone(true); return }
            webPermDone?.invoke()
            webPermDone = { onDone(osOk()) }
            webPermLauncher.launch(osPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray())
        }

        val key = "${normOrigin(origin)}|$label"
        when (webPermDecisions[key]) {
            true -> { withOs(); return }
            false -> { onDone(false); return }
            null -> Unit
        }
        if (isFinishing || isDestroyed) { onDone(false); return }
        webPermDialog?.dismiss()
        var answered = false
        val host = runCatching { Uri.parse(origin).host }.getOrNull() ?: origin
        webPermDialog = ThemedDialogBuilder(this)
            .setTitle(host)
            .setMessage("이 사이트가 ${label}을(를) 사용하려고 합니다. 허용할까요?")
            .setPositiveButton("허용") { _, _ ->
                answered = true
                webPermDecisions[key] = true
                withOs()
            }
            .setNegativeButton("차단") { _, _ ->
                answered = true
                webPermDecisions[key] = false
                onDone(false)
            }
            .setOnDismissListener { if (!answered) onDone(false) }
            .show()
    }

    /** 권한 기억 키용 주소: 스킴://호스트(기본이 아닌 포트만) — 요청 경로(끝 슬래시 등)가 달라도 같은 사이트로 본다 */
    private fun normOrigin(origin: String): String = try {
        val u = Uri.parse(origin)
        val host = u.host?.lowercase()
        if (host == null) origin else {
            val port = u.port
            val def = (u.scheme == "https" && port == 443) || (u.scheme == "http" && port == 80)
            "${u.scheme}://$host" + if (port > 0 && !def) ":$port" else ""
        }
    } catch (e: Exception) { origin }

    /** 카메라·마이크는 둘을 함께 묻는 요청에서 정한 값도 따른다 */
    private fun sitePerm(origin: String, label: String): Boolean? =
        webPermDecisions["$origin|$label"]
            ?: if (label == "카메라" || label == "마이크") webPermDecisions["$origin|카메라와 마이크"] else null

    private fun setSitePerm(origin: String, label: String, allow: Boolean) {
        webPermDecisions["$origin|$label"] = allow
        if (label == "카메라" || label == "마이크") {
            val cam = sitePerm(origin, "카메라")
            val mic = sitePerm(origin, "마이크")
            val both = "$origin|카메라와 마이크"
            when {
                cam == true && mic == true -> webPermDecisions[both] = true
                cam == false || mic == false -> webPermDecisions[both] = false
                else -> webPermDecisions.remove(both)
            }
        }
    }

    private fun resetSitePerms(origin: String) {
        webPermDecisions.keys.filter { it.startsWith("$origin|") }.forEach { webPermDecisions.remove(it) }
    }

    /** 이 사이트의 쿠키(상위 도메인에 걸린 것 포함)와 저장된 데이터를 지운다 */
    private fun clearSiteData(tab: BrowserTab, uri: Uri) {
        val host = uri.host ?: return
        val cm = cookieManagerFor(tab)
        val url = "${uri.scheme}://$host/"
        val names = (cm.getCookie(url) ?: "").split(";")
            .map { it.trim().substringBefore('=') }.filter { it.isNotEmpty() }.distinct()
        val parts = host.split('.')
        val domains = ArrayList<String?>()
        domains.add(null)
        for (i in 0 until parts.size - 1) domains.add(parts.drop(i).joinToString("."))
        for (n in names) for (d in domains) {
            val base = "$n=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/"
            val dom = if (d == null) "" else "; Domain=$d"
            cm.setCookie(url, base + dom)
            cm.setCookie(url, "$base$dom; Secure")
        }
        cm.flush()
        try { WebStorage.getInstance().deleteOrigin("${uri.scheme}://$host") } catch (_: Throwable) {}
        tab.liveWebView?.evaluateJavascript("try{localStorage.clear();sessionStorage.clear()}catch(e){}", null)
    }

    private fun siteInfoAvailable(): Boolean {
        val t = current ?: return false
        if (t.isHome) return false
        val u = t.liveWebView?.url ?: return false
        return u.startsWith("http://") || u.startsWith("https://")
    }

    /** 주소창 왼쪽 아이콘(자물쇠·지구본) 자리를 눌렀는지 */
    private fun siteIconHit(x: Float): Boolean {
        val d = urlBar.compoundDrawablesRelative[0] ?: return false
        val w = d.bounds.width()
        if (w <= 0) return false
        val edge = urlBar.paddingStart + w + urlBar.compoundDrawablePadding / 2 + dp(8)
        return if (urlBar.layoutDirection == View.LAYOUT_DIRECTION_RTL) x >= urlBar.width - edge else x <= edge
    }

    /**
     * 주소창의 자물쇠를 누르면 뜨는 '사이트 정보': 연결이 안전한지, 카메라·마이크·위치 허용 상태(켜고 끄기),
     * 권한 재설정, 이 사이트의 쿠키·데이터 지우기. 태블릿은 주소창 바로 아래에, 폰은 가운데 카드로 뜬다.
     */
    private fun showSiteInfo(anchor: View) {
        val tab = current ?: return
        val url = tab.liveWebView?.url ?: return
        val uri = Uri.parse(url)
        val host = uri.host ?: return
        if (uri.scheme != "http" && uri.scheme != "https") return
        val origin = normOrigin(url)
        val secure = uri.scheme == "https"
        // 한 번 더 확인: 취소하면 사이트 정보 창이 그대로 남는다
        fun reset(then: () -> Unit) {
            Popup.confirm(
                this, "권한을 재설정할까요?",
                "${host}의 카메라 · 마이크 · 위치 설정이 초기화돼요. 다음에 사이트가 쓰려고 할 때 다시 물어봐요.",
                positive = "재설정"
            ) {
                resetSitePerms(origin)
                toast("이 사이트의 권한 설정을 초기화했어요")
                then()
            }
        }
        if (Popup.canAnchor(this, anchor)) {
            Popup.panelAnchored(
                this, anchor, title = host, widthDp = 340,
                secondaryLabel = "권한 재설정", onSecondary = { close -> reset { close() } }
            ) { list, close, _ -> buildSiteInfoRows(list, tab, uri, origin, secure, close) }
        } else {
            Popup.panel(
                this, title = host, widthDp = 340,
                secondaryLabel = "권한 재설정", onSecondary = { d -> reset { d.dismiss() } }
            ) { list, dialog -> buildSiteInfoRows(list, tab, uri, origin, secure) { dialog.dismiss() } }
        }
    }

    private fun buildSiteInfoRows(
        list: LinearLayout, tab: BrowserTab, uri: Uri, origin: String, secure: Boolean, close: () -> Unit
    ) {
        val cOnSurface = themeColor(com.google.android.material.R.attr.colorOnSurface, R.color.ev_text)
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val cDanger = ContextCompat.getColor(this, R.color.ev_danger)
        val cOkBg = themeColor(com.google.android.material.R.attr.colorPrimaryContainer, R.color.ev_accent_soft)
        val cOkFg = themeColor(com.google.android.material.R.attr.colorOnPrimaryContainer, R.color.ev_accent_on_soft)
        val cBadBg = themeColor(com.google.android.material.R.attr.colorErrorContainer, R.color.ev_danger_soft)
        val cBadFg = themeColor(com.google.android.material.R.attr.colorOnErrorContainer, R.color.ev_danger)
        val cIdleBg = themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill)

        fun circle(bg: Int) = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(bg)
        }
        // 눌렀을 때 둥근 물결 (항목 모서리와 같은 곡률)
        fun ripple() = android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(androidx.core.graphics.ColorUtils.setAlphaComponent(cOnSurface, 0x1F)),
            null,
            android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.WHITE)
                cornerRadius = dp(16).toFloat()
            }
        )
        fun caption(text: String) = TextView(this).apply {
            this.text = text
            textSize = 12f
            letterSpacing = 0.02f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextColor(cMuted)
            setPadding(dp(16), dp(14), dp(16), dp(4))
            androidx.core.view.ViewCompat.setAccessibilityHeading(this, true)
        }

        /** 동그란 아이콘 + 제목/설명 + (오른쪽 스위치·화살표) 한 줄. 반환: 줄, 설명 글자, 아이콘 */
        fun row(icon: Int, title: String, sub: String?, trailing: View? = null): Triple<LinearLayout, TextView, ImageView> {
            val subView = TextView(this).apply {
                textSize = 12f
                setPadding(0, dp(1), 0, 0)
                setTextColor(cMuted)
                text = sub.orEmpty()
                visibility = if (sub.isNullOrEmpty()) View.GONE else View.VISIBLE
            }
            val iconView = ImageView(this).apply {
                setImageResource(icon)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = circle(cIdleBg)
                imageTintList = android.content.res.ColorStateList.valueOf(cMuted)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(60)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                addView(iconView, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(14) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(this@MainActivity).apply {
                        text = title
                        textSize = 15f
                        setTextColor(cOnSurface)
                    })
                    addView(subView)
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                if (trailing != null) addView(trailing)
            }
            return Triple(r, subView, iconView)
        }

        // 연결 상태: 안전하면 초록 카드, 아니면 붉은 카드
        run {
            val bg = if (secure) cOkBg else cBadBg
            val fg = if (secure) cOkFg else cBadFg
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(bg)
                    cornerRadius = dp(18).toFloat()
                }
                setPadding(dp(16), dp(14), dp(16), dp(14))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(if (secure) R.drawable.ic_lock else R.drawable.ic_warning)
                    imageTintList = android.content.res.ColorStateList.valueOf(fg)
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(14) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(this@MainActivity).apply {
                        text = if (secure) "이 연결은 안전합니다." else "이 연결은 안전하지 않습니다."
                        textSize = 15f
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        setTextColor(fg)
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = if (secure) "이 사이트와 주고받는 정보가 암호화돼요" else "비밀번호나 카드 번호 같은 정보는 입력하지 마세요"
                        textSize = 12f
                        alpha = 0.85f
                        setPadding(0, dp(2), 0, 0)
                        setTextColor(fg)
                    })
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            list.addView(card, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(2); bottomMargin = dp(2); marginStart = dp(4); marginEnd = dp(4)
            })
        }

        // 카메라 · 마이크 · 위치: 켜면 허용, 끄면 차단 (정하지 않았으면 쓰려 할 때 물어봐요)
        fun stateText(v: Boolean?) = when (v) {
            true -> "허용됨"
            false -> "차단됨"
            null -> "사용할 때 물어봐요"
        }
        // 상태에 따라 아이콘 동그라미와 설명 글자 색이 바뀐다: 허용=초록, 차단=빨강, 미정=회색
        fun applyState(icon: ImageView, sub: TextView, v: Boolean?) {
            icon.background = circle(when (v) { true -> cOkBg; false -> cBadBg; null -> cIdleBg })
            icon.imageTintList = android.content.res.ColorStateList.valueOf(when (v) { true -> cOkFg; false -> cBadFg; null -> cMuted })
            sub.setTextColor(when (v) { true -> cOkFg; false -> cDanger; null -> cMuted })
            sub.text = stateText(v)
        }

        list.addView(caption("사이트 권한"))
        listOf("카메라" to R.drawable.ic_camera, "마이크" to R.drawable.ic_mic, "위치" to R.drawable.ic_location).forEach { (label, icon) ->
            val sw = com.google.android.material.materialswitch.MaterialSwitch(this).apply {
                isChecked = sitePerm(origin, label) == true
                contentDescription = label
            }
            ThemeColors.skin(sw)
            val (r, sub, iconView) = row(icon, label, null, sw)
            applyState(iconView, sub, sitePerm(origin, label))
            sub.visibility = View.VISIBLE
            sw.setOnCheckedChangeListener { v, on ->
                setSitePerm(origin, label, on)
                applyState(iconView, sub, on)
                v.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
            }
            r.background = ripple()
            r.isClickable = true
            r.isFocusable = true
            r.setOnClickListener { sw.toggle() }
            list.addView(r)
        }

        // 쿠키 및 사이트 데이터: 누르면 상세 화면(쿠키 개수 · 지우기)
        list.addView(caption("저장된 데이터"))
        val count = siteCookieNames(tab, uri).size
        val chevron = ImageView(this).apply {
            setImageResource(R.drawable.ic_chevron_right)
            imageTintList = android.content.res.ColorStateList.valueOf(cMuted)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val (data, _, dataIcon) = row(
            R.drawable.ic_cookie, "쿠키 및 사이트 데이터",
            if (count > 0) "쿠키 ${count}개 저장됨" else "저장된 쿠키가 없어요", chevron
        )
        dataIcon.background = circle(cOkBg)
        dataIcon.imageTintList = android.content.res.ColorStateList.valueOf(cOkFg)
        data.background = ripple()
        data.isClickable = true
        data.isFocusable = true
        data.setOnClickListener {
            close()
            showSiteData(urlBar, tab, uri)
        }
        list.addView(data)
    }

    /** 이 주소에 걸린 쿠키 이름들 (값은 읽지 않는다) */
    private fun siteCookieNames(tab: BrowserTab, uri: Uri): List<String> {
        val host = uri.host ?: return emptyList()
        val raw = try { cookieManagerFor(tab).getCookie("${uri.scheme}://$host/") } catch (_: Throwable) { null }
        return (raw ?: "").split(";").map { it.trim().substringBefore('=') }.filter { it.isNotEmpty() }.distinct()
    }

    /**
     * '쿠키 및 사이트 데이터' 상세: 저장된 쿠키 개수와 이름 목록, 지우기. 왼쪽 '뒤로'는 사이트 정보로 돌아간다.
     * 사이트 정보 창과 같은 자리에 뜬다 (태블릿은 주소창 바로 아래, 폰은 가운데 카드).
     */
    private fun showSiteData(anchor: View, tab: BrowserTab, uri: Uri) {
        val host = uri.host ?: return
        val cOnSurface = themeColor(com.google.android.material.R.attr.colorOnSurface, R.color.ev_text)
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val cPrimary = themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)
        val names = siteCookieNames(tab, uri)

        // 한 번 더 확인: 취소하면 이 화면에 그대로 남는다
        fun confirmClear(then: () -> Unit) {
            Popup.confirm(
                this, "정말 지울까요?",
                "${host}의 쿠키 ${names.size}개와 저장된 데이터가 삭제돼요. 이 사이트에서 로그아웃될 수 있고, 되돌릴 수 없어요.",
                positive = "지우기", danger = true
            ) {
                then()
                clearSiteData(tab, uri)
                tab.liveWebView?.reload()
                toast("이 사이트의 쿠키와 데이터를 지웠어요")
            }
        }

        val cCard = themeColor(com.google.android.material.R.attr.colorSurfaceContainerHigh, R.color.ev_pill)
        fun fill(list: LinearLayout) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(2), dp(4), dp(2))
            }
            // 개수 카드: 큰 숫자 + 설명
            val stat = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(cCard)
                    cornerRadius = dp(18).toFloat()
                }
                setPadding(dp(20), dp(16), dp(20), dp(16))
            }
            stat.addView(TextView(this).apply {
                text = "${names.size}"
                textSize = 40f
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                includeFontPadding = false
                setTextColor(cPrimary)
            })
            stat.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(this@MainActivity).apply {
                    text = "저장된 쿠키"
                    textSize = 15f
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    setTextColor(cOnSurface)
                })
                addView(TextView(this@MainActivity).apply {
                    text = if (names.isEmpty()) "이 사이트에 걸린 쿠키가 없어요" else "이 사이트에 걸려 있어요"
                    textSize = 12f
                    setPadding(0, dp(2), 0, 0)
                    setTextColor(cMuted)
                })
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(16) })
            box.addView(stat)

            // 쿠키 이름: 둥근 칩으로 줄바꿈하며 나열 (내용은 읽지 않는다)
            if (names.isNotEmpty()) {
                box.addView(TextView(this).apply {
                    text = "쿠키 이름"
                    textSize = 12f
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    setTextColor(cMuted)
                    setPadding(dp(4), dp(16), dp(4), dp(6))
                    androidx.core.view.ViewCompat.setAccessibilityHeading(this, true)
                })
                val group = com.google.android.material.chip.ChipGroup(this).apply {
                    chipSpacingHorizontal = dp(6)
                    chipSpacingVertical = dp(6)
                }
                val shown = names.take(15)
                fun chip(label: String) = com.google.android.material.chip.Chip(this).apply {
                    text = label
                    textSize = 12f
                    isClickable = false
                    isCheckable = false
                    isFocusable = false
                    setEnsureMinTouchTargetSize(false)
                    chipMinHeight = dp(28).toFloat()
                    chipStrokeWidth = 0f
                    chipBackgroundColor = android.content.res.ColorStateList.valueOf(cCard)
                    setTextColor(cOnSurface)
                    typeface = android.graphics.Typeface.MONOSPACE
                }
                shown.forEach { group.addView(chip(it)) }
                if (names.size > shown.size) group.addView(chip("… 외 ${names.size - shown.size}개"))
                box.addView(group)
            }
            box.addView(TextView(this).apply {
                text = "지우면 이 사이트의 쿠키와 저장된 데이터가 모두 삭제되고, 로그인이 풀릴 수 있어요. 쿠키 이름만 보여 주고 내용은 읽지 않아요."
                textSize = 12f
                setLineSpacing(dp(2).toFloat(), 1f)
                setTextColor(cMuted)
                setPadding(dp(4), dp(16), dp(4), dp(4))
            })
            list.addView(box)
        }

        if (Popup.canAnchor(this, anchor)) {
            Popup.panelAnchored(
                this, anchor, title = "쿠키 및 사이트 데이터", subtitle = host, headerIcon = R.drawable.ic_cookie, widthDp = 340,
                secondaryLabel = "뒤로", onSecondary = { close -> close(); showSiteInfo(anchor) },
                closeLabel = "지우기",
                onClose = { close -> confirmClear { close() } }
            ) { list, _, _ -> fill(list) }
        } else {
            Popup.panel(
                this, title = "쿠키 및 사이트 데이터", subtitle = host, headerIcon = R.drawable.ic_cookie, widthDp = 340,
                secondaryLabel = "뒤로", onSecondary = { d -> d.dismiss(); showSiteInfo(anchor) },
                closeLabel = "지우기",
                onClose = { d -> confirmClear { d.dismiss() } }
            ) { list, _ -> fill(list) }
        }
    }

    private fun handleWebPermissionRequest(request: android.webkit.PermissionRequest) {
        val res = request.resources.toList()
        val cam = android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE in res
        val mic = android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE in res
        val granted = ArrayList<String>()
        // 보호된 콘텐츠(DRM) 재생은 그대로 허용
        if (android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID in res) {
            granted.add(android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID)
        }
        if (!cam && !mic) {
            try {
                if (granted.isEmpty()) request.deny() else request.grant(granted.toTypedArray())
            } catch (e: Exception) { }
            return
        }
        val os = ArrayList<String>()
        if (cam) os.add(Manifest.permission.CAMERA)
        if (mic) os.add(Manifest.permission.RECORD_AUDIO)
        val label = when {
            cam && mic -> "카메라와 마이크"
            cam -> "카메라"
            else -> "마이크"
        }
        askWebPermission(request.origin.toString(), label, os, anyOf = false) { ok ->
            try {
                if (ok) {
                    if (cam) granted.add(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    if (mic) granted.add(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    request.grant(granted.toTypedArray())
                } else {
                    request.deny()
                }
            } catch (e: Exception) {
                // 요청이 이미 취소됨
            }
        }
    }

    private fun handleGeolocationRequest(origin: String, callback: android.webkit.GeolocationPermissions.Callback) {
        askWebPermission(
            origin, "위치",
            listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            anyOf = true
        ) { ok ->
            try { callback.invoke(origin, ok, false) } catch (e: Exception) { }
        }
    }

    // ── HTTP 로그인(Basic/Digest) 과 인증서 오류 ──

    private val pendingAuth = ArrayList<android.webkit.HttpAuthHandler>()

    @Suppress("DEPRECATION")
    private fun askHttpAuth(view: WebView, handler: android.webkit.HttpAuthHandler, host: String?, realm: String?) {
        if (isFinishing || isDestroyed) { handler.cancel(); return }
        // 같은 주소가 여러 요청으로 동시에 물어도 창은 하나만 띄우고 같은 답을 모두에게 준다
        if (pendingAuth.isNotEmpty()) { pendingAuth.add(handler); return }
        pendingAuth.add(handler)
        val saved = try { view.getHttpAuthUsernamePassword(host, realm) } catch (e: Exception) { null }
        val etUser = EditText(this).apply {
            hint = "사용자 이름"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setText(saved?.getOrNull(0).orEmpty())
        }
        val etPass = EditText(this).apply {
            hint = "비밀번호"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(saved?.getOrNull(1).orEmpty())
        }
        Popup.styleInput(etUser)
        Popup.styleInput(etPass)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
            addView(etUser)
            addView(etPass, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) })
        }
        val plain = view.url?.startsWith("http://") == true
        var done = false
        fun finish(ok: Boolean) {
            if (done) return
            done = true
            val list = pendingAuth.toList()
            pendingAuth.clear()
            for (h in list) {
                try {
                    if (ok) h.proceed(etUser.text.toString(), etPass.text.toString()) else h.cancel()
                } catch (e: Exception) { }
            }
        }
        ThemedDialogBuilder(this)
            .setTitle("로그인이 필요합니다")
            .setMessage(
                (host ?: "") + (if (!realm.isNullOrBlank()) " · $realm" else "") +
                    (if (plain) "\n\n⚠ 이 연결은 암호화되어 있지 않아 입력한 비밀번호가 노출될 수 있어요." else "")
            )
            .setView(box)
            .setPositiveButton("로그인") { _, _ -> finish(true) }
            .setNegativeButton("취소") { _, _ -> finish(false) }
            .setOnDismissListener { finish(false) }
            .show()
    }

    private val sslAllowed = HashSet<String>()
    private val pendingSsl = ArrayList<android.webkit.SslErrorHandler>()

    private fun sslMessage(error: android.net.http.SslError): String = when (error.primaryError) {
        android.net.http.SslError.SSL_UNTRUSTED -> "이 사이트의 인증서를 신뢰할 수 없습니다. (발급 기관을 확인할 수 없음)"
        android.net.http.SslError.SSL_EXPIRED -> "이 사이트의 인증서가 만료되었습니다."
        android.net.http.SslError.SSL_IDMISMATCH -> "인증서가 이 사이트 주소와 일치하지 않습니다."
        android.net.http.SslError.SSL_NOTYETVALID -> "이 사이트의 인증서가 아직 유효하지 않습니다. (기기의 날짜·시간도 확인해 보세요)"
        android.net.http.SslError.SSL_DATE_INVALID -> "인증서의 날짜가 올바르지 않습니다. (기기의 날짜·시간도 확인해 보세요)"
        else -> "인증서에 문제가 있습니다."
    }

    /** 페이지 자체의 인증서 오류만 묻는다. 이미지·스크립트 같은 하위 요청의 오류는 조용히 막는다. */
    private fun askSslError(pageHost: String?, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
        val errHost = runCatching { Uri.parse(error.url).host }.getOrNull()
        if (errHost == null || errHost != pageHost || isFinishing || isDestroyed) {
            handler.cancel()
            return
        }
        val key = "$errHost|${error.primaryError}"
        if (key in sslAllowed) { handler.proceed(); return }
        if (pendingSsl.isNotEmpty()) { pendingSsl.add(handler); return }
        pendingSsl.add(handler)
        var done = false
        fun finish(proceed: Boolean) {
            if (done) return
            done = true
            if (proceed) sslAllowed.add(key)
            val list = pendingSsl.toList()
            pendingSsl.clear()
            for (h in list) {
                try { if (proceed) h.proceed() else h.cancel() } catch (e: Exception) { }
            }
        }
        ThemedDialogBuilder(this)
            .setTitle("보안 연결이 아닙니다")
            .setMessage("$errHost\n\n${sslMessage(error)}\n\n계속하면 비밀번호나 카드 정보 같은 중요한 정보가 노출될 수 있어요.")
            .setPositiveButton("돌아가기") { _, _ -> finish(false) }
            .setNegativeButton("위험을 감수하고 계속") { _, _ -> finish(true) }
            .setOnDismissListener { finish(false) }
            .show()
    }

    // ── 렌더러 프로세스가 죽었을 때 (메모리 부족 등): 앱이 같이 꺼지지 않게 WebView 를 새로 만든다 ──

    /** 이어보기용으로 마지막 재생 위치를 적어 둔다 (너무 짧은 영상·맨 처음·거의 끝은 제외) */
    private fun noteResume(tab: BrowserTab, pos: Double, dur: Double) {
        // 라이브(길이가 무한·0)나 아주 짧은 영상, 맨 처음(3초 미만)·거의 끝(5초 전)은 이어볼 필요가 없다
        if (tab.incognito || !dur.isFinite() || dur < 10.0 || pos < 3.0 || pos > dur - 5.0) return
        val u = tab.liveWebView?.url ?: return
        if (!u.startsWith("http") || u.startsWith(LOCAL_BASE)) return
        tab.resumePos = pos
        tab.resumeUrl = u
        saveResumeLight(tab)
    }

    private val resumeSp by lazy { getSharedPreferences("evergreen_resume", Context.MODE_PRIVATE) }
    private fun resumeKey(sid: Long) = "r_${windowNo}_$sid"

    /**
     * 앱이 안 보이거나 PiP 인 동안 재생 위치만 작은 설정 파일에 2초마다 적어 둔다 (탭 전체 저장은 무거워서 주소가 바뀔 때만 한다).
     * 시스템이 앱을 종료해도 마지막 2초 안쪽 위치로 이어 볼 수 있다. 탭 번호표(sid)는 탭 전체 저장 때 정해진다.
     */
    private fun saveResumeLight(tab: BrowserTab) {
        if (visibleNow && !isInPictureInPictureModeCompat()) return
        if (tab.stateId == 0L) return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - tab.resumeLightAt < 2_000L) return
        tab.resumeLightAt = now
        val u = tab.resumeUrl ?: return
        resumeSp.edit().putString(resumeKey(tab.stateId), "${tab.resumePos}\n$u").apply()
    }

    private var awaySaveAt = 0L
    private var awaySaveUrl: String? = null

    /**
     * PiP·백그라운드에서 재생하는 동안 탭 상태를 가끔 저장한다.
     * 지금까지는 앱을 나갈 때(onStop) 한 번만 저장해서, 그 뒤 PiP·알림의 「다음 영상」 으로 다른 영상(주소)으로 넘어간 뒤
     * 시스템이 앱을 종료하면 옛 영상 주소·옛 재생 위치로 복원돼 새로 불러온 것처럼 보였다.
     * 주소가 바뀌었거나 30초가 지났으면 저장한다 (재생 위치는 saveResumeLight 가 2초마다 따로 적는다) (화면에 앱이 보일 때는 기존 저장 시점으로 충분하다).
     */
    private fun saveTabsWhileAway(tab: BrowserTab) {
        if (tab.incognito || (visibleNow && !isInPictureInPictureModeCompat())) return
        val now = android.os.SystemClock.uptimeMillis()
        val u = tab.liveWebView?.url
        if (u == awaySaveUrl && now - awaySaveAt < 30_000L) return
        awaySaveUrl = u
        awaySaveAt = now
        saveTabs()
    }

    /**
     * 모바일↔데스크톱 사이트를 바꾸느라 페이지를 다시 불러오기 전에, 보던 영상의 위치를 적어 둔다.
     * 다시 불러온 페이지에서 영상이 준비되면 `resumeJs` 가 그 위치로 옮겨 준다 (예전에는 처음부터 다시 재생됐다).
     * [target] 은 새로 열릴 주소. 지금 재생 상태 보고(mediaProg)가 없거나 맨 앞·거의 끝·라이브면 적어 두지 않는다.
     */
    private fun carryPlaybackPosition(tab: BrowserTab, target: String) {
        if (!target.startsWith("http") || target.startsWith(LOCAL_BASE)) return
        val now = android.os.SystemClock.uptimeMillis()
        val best = tab.mediaProg.values
            .filter { it.dur.isFinite() && it.dur >= 10.0 && it.pos >= 3.0 && it.pos <= it.dur - 5.0 }
            .maxWithOrNull(compareBy<MediaProg>({ it.playing }, { it.at })) ?: return
        // 재생 중이면 마지막 보고 뒤로 흐른 시간만큼 앞으로 (보고는 1초마다라 길어야 몇 초)
        val pos = best.pos + if (best.playing) ((now - best.at).coerceIn(0L, 3000L)) / 1000.0 else 0.0
        tab.resumePos = pos
        tab.resumeUrl = target
        tab.resumeApply = true
        // 새로 불러온 페이지가 다른 영상이거나 영상이 없으면 쓰이지 않으니, 한참 뒤에는 거둔다
        ui.postDelayed({ if (tab in tabs && tab.resumePos == pos) tab.resumeApply = false }, 45_000L)
    }

    /** 모바일(m.)·www. 만 다른 같은 사이트: 유튜브처럼 모바일↔데스크톱 사이트로 넘어가면 주소의 앞머리만 바뀐다 */
    private fun resumeHost(h: String?): String? = h?.removePrefix("www.")?.removePrefix("m.")

    /** 같은 영상 페이지인지 (유튜브는 v= 값, 그 밖에는 # 앞까지) */
    private fun sameResumePage(a: String?, b: String?): Boolean {
        if (a == null || b == null) return false
        val ua = runCatching { Uri.parse(a) }.getOrNull() ?: return false
        val ub = runCatching { Uri.parse(b) }.getOrNull() ?: return false
        if (resumeHost(ua.host) != resumeHost(ub.host)) return false
        val va = ua.getQueryParameter("v"); val vb = ub.getQueryParameter("v")
        if (va != null || vb != null) return va == vb && ua.path == ub.path
        return ua.path == ub.path && a.substringBefore('#').substringAfter(ua.host.orEmpty(), "") ==
            b.substringBefore('#').substringAfter(ub.host.orEmpty(), "")
    }

    /** 다시 불러온 페이지에서 영상이 준비되면 저장해 둔 위치로 한 번 옮긴다 (광고 중이면 기다리고, 이미 앞으로 재생됐으면 건드리지 않는다) */
    private fun resumeJs(pos: Double): String =
        "(function(pos){if(window.__evResume)return;window.__evResume=1;var n=0,t=setInterval(function(){" +
        "if(++n>90){clearInterval(t);return}try{if(document.querySelector('.ad-showing'))return;" +
        "var vs=document.querySelectorAll('video'),v=null;for(var i=0;i<vs.length;i++){var x=vs[i];" +
        "if(isFinite(x.duration)&&x.duration>pos+2&&x.readyState>=1){v=x;break}}" +
        "if(!v)return;clearInterval(t);if((v.currentTime||0)<Math.min(5,pos-1))v.currentTime=pos}catch(e){}},500)})(" + pos + ")"

    /**
     * 웹뷰 렌더러(페이지를 그리는 별도 프로세스)의 우선순위.
     * 기본값은 '화면에 안 보이면 낮은 우선순위'라서, PiP·백그라운드 재생으로 앱이 가려진 동안 메모리가 모자라면
     * 렌더러가 먼저 종료되고, 앱을 다시 열면 페이지가 새로 불러와졌다. 소리가 나는 탭이 있거나 PiP 중이면
     * 안 보여도 중요한 렌더러로 취급하게 해 종료되지 않게 한다. (Android 8+)
     */
    private fun applyRendererPriority(tab: BrowserTab) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val wv = tab.liveWebView ?: return
        val keep = (bgAudioOn() && tab.mediaFrames.isNotEmpty()) || isInPictureInPictureModeCompat()
        runCatching { wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, !keep) }
    }

    private fun recoverRenderer(tab: BrowserTab, dead: WebView) {
        if (tab !in tabs || tab.liveWebView !== dead) {
            runCatching { dead.destroy() }
            return
        }
        val url = (if (tab.isHome) null else dead.url?.takeIf { it != "about:blank" && it != HOME_URL }) ?: tab.pendingUrl
        tab.pendingTitle = dead.title?.takeIf { it.isNotBlank() } ?: tab.pendingTitle
        tab.resumeApply = tab.resumePos > 0.0 && sameResumePage(url, tab.resumeUrl)
        val wasCurrent = tab === current
        val now = android.os.SystemClock.uptimeMillis()
        val looping = now - tab.crashAt < 10_000L
        tab.crashAt = now

        (dead.parent as? ViewGroup)?.removeView(dead)
        runCatching { dead.destroy() }
        val fresh = if (tab.incognito) newIncognitoWebView() else NestedWebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        tab.webView = fresh
        tab.mediaFrames.clear(); tab.sniffed.clear(); tab.sniffedSubs.clear()
        tab.progress = 100
        tab.errorUrl = null
        configure(tab)
        if (tab.desktop) applyUserAgent(fresh, true)
        onMediaChanged()

        if (wasCurrent) {
            tab.paused = false
            webContainer.addView(fresh)
            fresh.requestFocus()
            when {
                url == null -> if (tab.isHome) loadHome(tab)
                looping -> {
                    // 같은 페이지가 계속 죽으면 무한 새로고침 대신 안내 화면을 보여 준다
                    tab.errorUrl = url
                    fresh.loadDataWithBaseURL(
                        url, errorPageHtml(url, -1, "이 페이지를 열다가 계속 종료되었습니다"),
                        "text/html", "utf-8", url
                    )
                }
                else -> {
                    toast("메모리가 부족해 페이지가 종료되어 다시 불러옵니다")
                    fresh.loadUrl(url)
                }
            }
            updateUi()
        } else {
            // 보고 있지 않던 탭은 다시 선택할 때 불러온다
            tab.pendingUrl = url
            tab.paused = true
            fresh.onPause()
        }
        scheduleStripRefresh()
    }

    private fun configure(tab: BrowserTab) {
        val wv = tab.webView
        // 백그라운드 재생이 켜져 있고 이 탭에서 소리가 나는 중이면, 앱을 나가도 웹뷰가 멈추지 않게 한다
        (wv as? NestedWebView)?.keepPlaying = { bgAudioOn() && tab.mediaFrames.isNotEmpty() }
        // 글자를 선택했을 때 뜨는 시스템 팝업의 「AI에게 물어보기」: 선택한 글을 질문으로 미리 채워 AI 창을 연다
        (wv as? NestedWebView)?.onAskAi = { text ->
            val quoted = text.take(2000).lines().joinToString("\n") { "> $it" }
            assistant?.show(if (tbAi.isShown) tbAi else null, "이 내용을 설명해 주세요:\n$quoted")
        }

        // 확장 프로그램 우클릭 메뉴 중 '글자 선택' 항목: 선택 팝업에 끼워 넣는다
        (wv as? NestedWebView)?.let { nw ->
            nw.extSelectionTitles = {
                if (tab.incognito) emptyList() else extensions.contextMenuEntries(setOf("selection"), wv.url, null, null).map { it.title }
            }
            nw.onExtSelection = { i, text ->
                extensions.contextMenuEntries(setOf("selection"), wv.url, null, null).getOrNull(i)
                    ?.let { en -> extensions.contextMenuClick(en, wv.url, null, null, text) }
            }
        }

        if (baseUserAgent.isEmpty()) baseUserAgent = wv.settings.userAgentString
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (tab.incognito && !profilesSupported) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            // 파일 업로드(<input type=file>)로 고른 파일은 content:// 주소로 오므로 켜 둬야 올라간다.
            // (웹페이지가 content:// 를 직접 불러올 수는 없어서 보안상 문제는 없다)
            allowContentAccess = true
            setGeolocationEnabled(true)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }
        // 일부 사이트(영상 서비스 등)가 WebView를 낮은 품질로 취급하는 것을 피하기 위해 UA(및 Client Hints)에서 WebView 표시 제거
        applyUserAgent(wv, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val keep = (bgAudioOn() && tab.mediaFrames.isNotEmpty()) || isInPictureInPictureModeCompat()
            runCatching { wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, !keep) }
        }
        // 재생 상태 감지 (백그라운드 재생 / PiP 용)
        wv.addJavascriptInterface(MediaJs(tab), "EvMedia")
        wv.addJavascriptInterface(localDownload, "EvBlob")
        wv.addJavascriptInterface(DropJs(), "EvDrop")
        if (!tab.incognito) wv.addJavascriptInterface(StoreJs(tab), "EvStore")
        if (docStartScripts) {
            // 크롬 웹스토어의 'Chrome에 추가' 버튼을 'evergreen에 추가'로 바꿔 가로챈다 (웹스토어 주소에서만 돈다)
            if (!tab.incognito) androidx.webkit.WebViewCompat.addDocumentStartJavaScript(
                wv, STORE_BUTTON_JS, setOf("https://chromewebstore.google.com", "https://chrome.google.com")
            )
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, MediaScripts.INJECT, setOf("*"))
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, MediaScripts.PULL_GUARD, setOf("*"))
            // 웹툰처럼 이미지를 세로로 이어 붙인 페이지에서 이미지 사이에 보이는 가는 선(이음새) 보정
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, SEAM_FIX_JS, setOf("*"))
            // 클릭 가로채기 차단: 사용자가 누른 곳이 링크인지(그 주소는 무엇인지) 터치 순간부터 앱에 알린다
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, HIJACK_TAP_JS, setOf("*"))
            // 영상 위에서 끌 때 따라다니는 반투명 틀 차단
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, NO_GHOST_DRAG_JS, setOf("*"))
            // blob 다운로드: 페이지가 바로 취소해 버리는 blob 도 저장할 수 있게 원본을 붙잡아 둔다
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, LocalDownload.KEEP_BLOBS_JS, setOf("*"))
            // 광고 영역 숨김 (페이지가 그려지기 전부터 적용)
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, AdBlocker.COSMETIC_START_JS, setOf("*"))
            // 유튜브 광고 차단 (일반 광고 차단과 별개 설정)
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, AdBlocker.YT_AD_START_JS, setOf("*"))
            // 유튜브: HDR 화면인데 웹뷰가 'HDR 안 됨'으로 답해서 화질 메뉴에 HDR 이 안 뜨는 것을 바로잡는다 (HDR 화면일 때만)
            if (displayIsHdr()) androidx.webkit.WebViewCompat.addDocumentStartJavaScript(
                wv, HDR_SHIM_JS,
                setOf("https://www.youtube.com", "https://m.youtube.com", "https://youtube.com", "https://www.youtube-nocookie.com")
            )
        }
        // 크롬 확장 프로그램의 콘텐츠 스크립트 (시크릿 탭에서는 쓰지 않는다)
        extensions.attach(wv, tab.incognito)
        // WebView가 보내는 X-Requested-With(앱 패키지명) 헤더 제거 — 구글 등 로그인 차단/보안 경고의 주원인
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(wv.settings, emptySet())
        }
        // 사용자가 최근 화면을 만졌는지 기록 (로그인 팝업·앱 연동은 허용, 자동 팝업 광고는 계속 차단)
        wv.setOnTouchListener { v, ev ->
            val now = android.os.SystemClock.uptimeMillis()
            lastTouchAt = now
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                tapX = ev.x; tapY = ev.y
                // 닿는 순간부터 '누르는 중' 으로 본다 (touchstart·mousedown 에서 바로 다른 사이트로 보내는 가로채기를 잡으려고).
                // 이전 누름의 링크 판정이 남아 있으면 안 되므로, 이번 누름의 판정은 손을 뗄 때(또는 페이지 스크립트의 보고)로 채운다.
                tab.tapDownAt = now
                tab.tapAt = now
                tab.tapOnLink = false
                tab.tapHref = null
            }
            // 손을 뗄 때 누른 곳이 링크였는지 적어 둔다: 링크가 아닌 곳을 눌렀는데 다른 사이트로 가면 '클릭 가로채기' 로 본다
            if (ev.actionMasked == MotionEvent.ACTION_UP) {
                runCatching {
                    val hr = (v as WebView).hitTestResult
                    val t = hr.type
                    val extra = hr.extra
                    // 주소가 http(s) 가 아닌 링크(javascript:, 빈 링크)는 버튼 모양일 뿐이라 링크로 치지 않는다
                    val realHref = extra?.takeIf { it.startsWith("http://", true) || it.startsWith("https://", true) }
                    tab.tapOnLink = when (t) {
                        WebView.HitTestResult.SRC_ANCHOR_TYPE -> realHref != null
                        WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> true // 사진 링크는 주소를 바로 알 수 없다: 너그럽게 링크로 본다
                        else -> false
                    }
                    tab.tapHref = if (t == WebView.HitTestResult.SRC_ANCHOR_TYPE) realHref else null
                    tab.tapAt = now
                }
            }
            false
        }
        // 키보드(Enter)로 누른 다운로드 버튼도 사용자가 한 동작으로 본다
        wv.setOnKeyListener { _, _, _ -> lastTouchAt = android.os.SystemClock.uptimeMillis(); false }
        // 액티비티가 이미 hardwareAccelerated 이므로 WebView 에 별도 하드웨어 레이어를 씌우지 않는다.
        // 레이어를 씌우면 스크롤로 상단 메뉴가 숨겨져 WebView 가 커질 때, 늘어난 아래쪽 영역이
        // 레이어에 다시 그려지지 않아 흰 네모가 남는다.
        wv.setLayerType(View.LAYER_TYPE_NONE, null)
        applySecurity(wv, tab)
        applyWebAppearance(wv)
        applyAutofill(tab)
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.setOnScrollChangeListener { _, _, y, _, oldY ->
            onPageScroll(tab, y, oldY) // (스크롤바 갱신은 onPageScroll 안에서 한 번 한다)
        }

        // 현재 페이지의 호스트. shouldInterceptRequest 는 백그라운드 스레드에서 불리는데
        // 거기서 view.url 을 읽으면 WebView 스레드 위반으로 앱이 꺼지므로, 값을 따로 저장해서 쓴다.
        val pageHostRef = java.util.concurrent.atomic.AtomicReference<String?>(null)

        wv.webViewClient = object : WebViewClient() {
            override fun onScaleChanged(view: WebView, oldScale: Float, newScale: Float) {
                super.onScaleChanged(view, oldScale, newScale)
                (view as? NestedWebView)?.onPageScaleChanged(newScale)
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                // 확장 프로그램 안의 파일(옵션·팝업 페이지, chrome.runtime.getURL 로 받은 주소)
                if (request.url.host == ExtensionManager.HOST) return extensions.serve(request.url, request.requestHeaders?.get("Referer"))
                // 확장 프로그램의 요청 차단 규칙 (declarativeNetRequest): 시크릿 탭에서는 확장 프로그램을 쓰지 않는다
                if (extensions.dnrActive && !tab.incognito && request.url.scheme.let { it == "http" || it == "https" }) {
                    val dnrUrl = request.url.toString()
                    val dnrType = if (request.isForMainFrame) NetFilter.T_DOC else NetFilter.inferType(
                        dnrUrl, request.requestHeaders?.get("Accept"), false,
                        request.requestHeaders?.containsKey("Range") == true
                    )
                    if (extensions.dnrBlocks(dnrUrl, request.url.host, if (request.isForMainFrame) null else pageHostRef.get(), dnrType)) {
                        return blockedResponse(request.url, !request.isForMainFrame)
                    }
                    // redirect · upgradeScheme 규칙: 최상위 문서는 새 주소로 이동하고, 하위 리소스는 새 주소의 내용을 대신 돌려준다
                    val dnrTo = extensions.dnrRedirect(dnrUrl, request.url.host, if (request.isForMainFrame) null else pageHostRef.get(), dnrType)
                    if (dnrTo != null) {
                        if (request.isForMainFrame) {
                            ui.post { try { view.loadUrl(dnrTo) } catch (e: Exception) { } }
                            return WebResourceResponse("text/html", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                        }
                        extensions.dnrRedirectResponse(dnrTo, request)?.let { return it }
                    }
                }
                // webRequest 리스너 · modifyHeaders 규칙
                if (extensions.netActive && !tab.incognito && request.url.scheme.let { it == "http" || it == "https" }) {
                    val netUrl = request.url.toString()
                    val netType = if (request.isForMainFrame) NetFilter.T_DOC else NetFilter.inferType(
                        netUrl, request.requestHeaders?.get("Accept"), false,
                        request.requestHeaders?.containsKey("Range") == true
                    )
                    val nr = extensions.netIntercept(request, if (request.isForMainFrame) null else pageHostRef.get(), netType)
                    if (nr != null) {
                        if (nr.cancel) return blockedResponse(request.url, !request.isForMainFrame)
                        if (nr.redirect != null) {
                            if (request.isForMainFrame) {
                                val to = nr.redirect
                                ui.post { try { view.loadUrl(to) } catch (e: Exception) { } }
                                return WebResourceResponse("text/html", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                            }
                        }
                        nr.response?.let { return it }
                    }
                }
                if (request.isForMainFrame) {
                    // 스크립트가 띄운 팝업의 첫 요청: 새 창의 첫 이동은 shouldOverrideUrlLoading 을 거치지 않는 경우가 있어서 여기서도 한 번 검사한다
                    // (버튼을 눌렀는데 window.open 으로 엉뚱한 사이트를 여는 가로채기)
                    if (hijackGuard && tab.scriptPopup && !tab.popupVetted) {
                        tab.popupVetted = true
                        if (request.url.scheme.let { it == "http" || it == "https" } &&
                            isHijackedNav(tab, request.url, tab.popupFromUrl, request.isRedirect, true)
                        ) {
                            onHijackBlocked(tab, request.url.toString(), true)
                            return blockedResponse(request.url)
                        }
                    }
                    // 스크립트가 띄운 팝업이 광고 서버로 가면 아무것도 안 보여주고 탭을 닫는다
                    if (adBlockEnabled && tab.scriptPopup && adBlocker.isAdHost(request.url.host)) {
                        adBlocker.record(request.url.host, AdBlocker.KIND_POPUP)
                        tab.adBlocked.incrementAndGet()
                        ui.post {
                            if (tab in tabs) {
                                toast("광고 팝업을 차단했습니다")
                                closeTab(tab)
                            }
                        }
                        return blockedResponse(request.url)
                    }
                    pageHostRef.set(request.url.host)
                    tab.curHost = request.url.host
                    tab.adBlocked.set(0) // 새 페이지로 가면 '이 페이지' 차단 건수를 다시 센다
                    return null
                }
                val reqUrl = request.url.toString()
                // 유튜브 광고 차단이 켜져 있으면, 유튜브 페이지에서 광고 영상·광고 정보를 받는 구글 광고 서버 요청은 막지 않는다.
                // 막으면 광고가 안 불러와져서 유튜브가 한참 기다리다 포기하느라 광고 시작 때 로딩이 길어진다.
                // 광고는 막는 대신 바로 넘기는 쪽(광고 데이터 미리 지우기 · 건너뛰기 · 끝으로 넘기기)으로 처리한다.
                val ytAdPass = prefs.ytAdBlock && ytAdServerPass(pageHostRef.get(), request.url.host)
                // 이미 허용으로 판정된 호스트(영상 조각 등)는 요청 종류 추정까지 건너뛰고 바로 통과
                if (adBlockEnabled && !ytAdPass &&
                    !adBlocker.quickAllow(request.url.host, pageHostRef.get()) &&
                    adBlocker.shouldBlock(
                        request.url.host, pageHostRef.get(), reqUrl,
                        NetFilter.inferType(
                            reqUrl, request.requestHeaders?.get("Accept"), false,
                            request.requestHeaders?.containsKey("Range") == true
                        )
                    )
                ) {
                    adBlocker.record(request.url.host, AdBlocker.KIND_REQUEST)
                    tab.adBlocked.incrementAndGet()
                    return blockedResponse(request.url, true)
                }
                sniffMedia(tab, request.url, request.requestHeaders)
                if (strictTrackers && !ytAdPass) {
                    val block = try {
                        trackerBlocker.shouldBlock(request.url.host, pageHostRef.get())
                    } catch (e: Exception) {
                        false
                    }
                    if (block) {
                        trackerBlocker.blockedCount.incrementAndGet()
                        SecurityStats.add(SecurityStats.TRACKER)
                        return blockedResponse(request.url, true)
                    }
                }
                return null
            }

            // 페이지를 불러오지 못하면 기본 오류 화면 대신 앱의 오류 화면을 보여 준다.
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (!request.isForMainFrame) return
                val url = request.url.toString()
                if (!(url.startsWith("http://") || url.startsWith("https://"))) return
                val desc = error.description?.toString().orEmpty()
                // 사용자가 직접 멈추거나 다운로드로 바뀐 경우는 오류가 아니다
                if (error.errorCode == WebViewClient.ERROR_UNKNOWN && desc.contains("ERR_ABORTED")) return
                // HTTPS 우선으로 올린 연결이 안 되면, 사용자가 허락할 때만 http 로 되돌아간다
                val orig = tab.upgradedFrom
                if (orig != null && url.startsWith("https://") &&
                    request.url.host == runCatching { Uri.parse(orig).host }.getOrNull() &&
                    error.errorCode != WebViewClient.ERROR_HOST_LOOKUP
                ) {
                    ui.post { askHttpFallback(tab, view, orig) }
                }
                tab.errorUrl = url
                val html = errorPageHtml(url, error.errorCode, desc)
                ui.post { view.loadDataWithBaseURL(url, html, "text/html", "utf-8", url) }
            }

            // 404·500 같은 서버 오류도 같은 오류 화면으로 보여 준다 (메인 페이지만).
            // 로그인(401)·접근 거부(403)·요청 과다(429)나 보안 확인(Cloudflare 등) 응답은 그 사이트의 화면이 필요해서 건드리지 않는다.
            override fun onReceivedHttpError(
                view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse
            ) {
                if (!request.isForMainFrame) return
                val url = request.url.toString()
                if (!(url.startsWith("http://") || url.startsWith("https://"))) return
                val status = errorResponse.statusCode
                if (status < 400 || status == 401 || status == 403 || status == 407 || status == 429) return
                val hdr = errorResponse.responseHeaders.orEmpty()
                if (hdr.keys.any { it.equals("cf-mitigated", true) }) return
                val reason = errorResponse.reasonPhrase?.takeIf { it.isNotBlank() }
                val desc = if (reason != null) "HTTP $status · $reason" else "HTTP $status"
                tab.errorUrl = url
                val html = errorPageHtml(url, status, desc)
                ui.post { view.loadDataWithBaseURL(url, html, "text/html", "utf-8", url) }
            }

            // 렌더러가 죽어도 앱이 꺼지지 않게 하고, 그 탭만 새로 만든다 (API 26+)
            override fun onRenderProcessGone(
                view: WebView,
                detail: android.webkit.RenderProcessGoneDetail
            ): Boolean {
                ui.post { recoverRenderer(tab, view) }
                return true
            }

            override fun onReceivedHttpAuthRequest(
                view: WebView, handler: android.webkit.HttpAuthHandler, host: String?, realm: String?
            ) {
                // 확장 프로그램의 onAuthRequired 가 먼저 답할 기회를 갖는다 (못 풀면 기존 창으로 묻는다)
                if (extensions.authActive && !tab.incognito) {
                    extensions.netAuth(host, realm, view.url) { user, pass, cancel ->
                        ui.post {
                            if (user != null && pass != null) handler.proceed(user, pass)
                            else if (cancel) handler.cancel()
                            else askHttpAuth(view, handler, host, realm)
                        }
                    }
                    return
                }
                askHttpAuth(view, handler, host, realm)
            }

            override fun onReceivedSslError(
                view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError
            ) {
                askSslError(pageHostRef.get(), handler, error)
            }

            // 악성·피싱 사이트로 접속하려 하면 경고 화면을 띄우고 알려 준다.
            override fun onSafeBrowsingHit(
                view: WebView,
                request: WebResourceRequest,
                threatType: Int,
                callback: android.webkit.SafeBrowsingResponse
            ) {
                callback.showInterstitial(true)
                if (request.isForMainFrame) {
                    SecurityStats.add(SecurityStats.MALWARE)
                    toast("⚠ 악성 사이트로 의심되어 접속을 막았습니다")
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "http" || scheme == "https") {
                    // 사용자 동작 없는 광고 서버 이동 / 스크립트 팝업의 광고 이동은 막는다
                    if (adBlockEnabled && request.isForMainFrame &&
                        (!request.hasGesture() || tab.scriptPopup) &&
                        adBlocker.isAdHost(request.url.host)
                    ) {
                        adBlocker.record(request.url.host, AdBlocker.KIND_POPUP)
                        tab.adBlocked.incrementAndGet()
                        if (tab.scriptPopup) {
                            ui.post {
                                if (tab in tabs) {
                                    toast("광고 팝업을 차단했습니다")
                                    closeTab(tab)
                                }
                            }
                        }
                        return true
                    }
                    // '클릭 가로채기' 차단: 링크가 아닌 곳을 눌렀는데 전혀 다른 사이트로 보내거나 팝업을 여는 경우
                    if (hijackGuard && request.isForMainFrame) {
                        val cur = view.url
                        val firstNav = cur.isNullOrEmpty() || cur == "about:blank"
                        val popupFirst = tab.scriptPopup && firstNav
                        val fromU = if (popupFirst) tab.popupFromUrl else cur
                        if (isHijackedNav(tab, request.url, fromU, request.isRedirect, popupFirst)) {
                            onHijackBlocked(tab, request.url.toString(), popupFirst)
                            return true
                        }
                        tab.lastHopAt = android.os.SystemClock.uptimeMillis()
                    }
                    // 뒤로가기 직후, 사용자 동작 없이 페이지가 스스로 다른 곳으로 보내려 하면 막는다.
                    // (뒤로가기를 눌러도 같은 페이지로 계속 튕겨 돌아오는 "뒤로가기 함정" 방지)
                    // 오작동을 막으려고 아래를 모두 만족할 때만 막는다:
                    //  - 뒤로가기한 지 4초 안이고, 그 뒤로 사용자가 페이지를 만지지 않았다 (눌러서 가는 링크·서버 리다이렉트는 통과)
                    //  - 이동을 시작한 곳이 뒤로가기로 도착한(또는 떠나온) 페이지다
                    //  - 가는 곳이 도착한 페이지 자신의 주소 정리(http→https, www 붙이기, 끝 슬래시)가 아니다
                    val from = view.url
                    if (prefs.blockBackRedirect && request.isForMainFrame && !request.hasGesture() && from != null &&
                        tab.backAt != 0L &&
                        android.os.SystemClock.uptimeMillis() - tab.backAt < BACK_GUARD_MS &&
                        lastTouchAt == tab.backTouchMark &&
                        (sameDoc(from, tab.backTargetUrl) || sameDoc(from, tab.backLeftUrl)) &&
                        !sameDoc(request.url.toString(), tab.backTargetUrl) &&
                        !sameDoc(request.url.toString(), from)
                    ) {
                        // 튕기는 쪽은 뒤로가기로 도착한 페이지다 (없으면 지금 주소)
                        tab.redirectSources.add(tab.backTargetUrl ?: from)
                        tab.backAt = 0L
                        SecurityStats.add(SecurityStats.BACK)
                        toast("뒤로가기 중 자동 이동을 차단했습니다")
                        ui.post { if (tab in tabs && canGoBackSmart(tab)) goBackSmart(tab) }
                        return true
                    }
                    // HTTPS 우선: http 링크는 https 로 올려서 연결한다
                    if (request.isForMainFrame) {
                        val prev = tab.upgradedFrom
                        if (prev != null && runCatching { Uri.parse(prev).host }.getOrNull() == request.url.host) {
                            // https 로 올렸더니 서버가 스스로 http 로 되돌려 보낸 경우: 무한 반복을 막고 그대로 둔다
                            request.url.host?.lowercase()?.let { httpAllowed.add(it) }
                            tab.upgradedFrom = null
                            return false
                        }
                        val up = upgradeUrl(request.url.toString())
                        if (up != null) {
                            tab.upgradedFrom = request.url.toString()
                            SecurityStats.add(SecurityStats.HTTPS)
                            ui.post { view.loadUrl(up) }
                            return true
                        }
                    }
                    return false
                }

                // 웹 페이지가 내 기기 파일이나 다른 앱의 데이터로 이동하게 두지 않는다
                if (scheme == "about") return false
                if (scheme in BLOCKED_NAV_SCHEMES) return true

                // 사용자 동작 없이 외부 앱/스토어를 여는 리다이렉트(광고)는 차단
                if (!request.hasGesture() && !recentTouch()) return true

                return try {
                    val intent = if (scheme == "intent") {
                        Intent.parseUri(request.url.toString(), Intent.URI_INTENT_SCHEME).apply {
                            addCategory(Intent.CATEGORY_BROWSABLE)
                            component = null
                            selector = null
                            // 페이지가 파일 접근 권한을 끼워 넘기거나 내 파일을 가리키지 못하게 한다
                            flags = flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION).inv()
                            val ds = data?.scheme?.lowercase()
                            if (ds == "file" || ds == "content") throw SecurityException("blocked")
                        }
                    } else {
                        Intent(Intent.ACTION_VIEW, request.url)
                    }
                    startActivity(intent)
                    true
                } catch (e: ActivityNotFoundException) {
                    toast("이 링크를 열 수 있는 앱이 없습니다")
                    true
                } catch (e: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                (view as? NestedWebView)?.resetZoomTracking()
                ui.post { extNavEvent(tab, "started", url) }
                // 다른 페이지로 넘어가면 자동 스크롤도 멈춘다
                if (autoScrollerInst?.isRunningOn(view) == true) autoScrollerInst?.stop(null)
                // 홈 항목으로 들어가는 중: 덮개(홈 화면)만 보여 준다
                if (url == HOME_URL) {
                    tab.isHome = true
                    assistant?.refreshChips()
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                    return
                }
                pageHostRef.set(try { Uri.parse(url).host } catch (e: Exception) { null })
                tab.curHost = pageHostRef.get()
                tab.scrollRatio = -1f
                tab.cosmeticInjected = false
                tab.ownProgressBar = false
                tab.ownBarChecks = 0
                tab.desktopInjected = false
                tab.zoomInjected = false
                tab.darkInjected = false
                if (tab === current) scrollBars.show()
                // 다른 페이지로 넘어가면 이전 페이지의 찾기 결과는 의미가 없다
                if (tab.webView === findWebView) closeFind()
                // 페이지가 아이콘을 아직 안 알려 줬으면 저장해 둔 아이콘을 유지한다 (탭 아이콘이 지구본으로 깜빡이지 않게)
                tab.favicon = favicon ?: Favicons.cached(this@MainActivity, url)
                // 페이지가 아이콘을 늦게(또는 안) 알려 줘도 탭바 아이콘이 바로 바뀌게: 지금 탭바에 바로 반영하고,
                // 저장된 아이콘이 없으면 사이트 아이콘을 따로 받아 와 채운다 (웹뷰의 onReceivedIcon 을 기다리지 않는다)
                scheduleStripRefresh()
                if (tab.favicon == null && !tab.isHome && url != "about:blank" && !url.startsWith("data:")) {
                    Favicons.fetch(this@MainActivity, url) { bmp ->
                        if (bmp != null && tab.favicon == null && !tab.isHome && !isDestroyed) {
                            tab.favicon = bmp
                            scheduleStripRefresh()
                        }
                    }
                }
                if (url != "about:blank" && !url.startsWith("data:")) {
                    if (tab.isHome) tab.awaitCommit = true
                    tab.isHome = false
                    assistant?.refreshChips()
                }
                tab.stoppedByHome = false
                tab.sniffed.clear()
                tab.sniffedSubs.clear()
                if (tab.mediaFrames.isNotEmpty()) { tab.mediaFrames.clear(); onMediaChanged() }
                if (tab === current) updateUi()
            }

            // 새 페이지의 첫 화면이 그려졌다: 이제 웹뷰를 보여 준다 (그 전엔 이전 페이지가 비쳐 보였다)
            override fun onPageCommitVisible(view: WebView, url: String) {
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    ui.post { if (tab === current) updateUi() }
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                ui.post { extNavEvent(tab, "finished", url) }
                if (tab.awaitCommit) { tab.awaitCommit = false; if (tab === current) updateUi() }
                if (url.contains("/detail/") && (url.startsWith("https://chromewebstore.google.com/") || url.startsWith("https://chrome.google.com/webstore/"))) {
                    offerStoreInstall(tab, url, view.title)
                    if (!docStartScripts && !tab.incognito) view.evaluateJavascript(STORE_BUTTON_JS, null)
                }
                if (url == "about:blank") view.clearHistory()
                if (url == HOME_URL || view.url == HOME_URL) {
                    tab.isHome = true
                    assistant?.refreshChips()
                    tab.awaitCommit = false
                    if (tab.clearAtHome) { tab.clearAtHome = false; view.clearHistory() }
                }
                if (url.startsWith("https://")) tab.upgradedFrom = null
                // 문서 시작 스크립트로 이미 들어가 있으면 다시 실행하지 않는다 (페이지 완료 직후 JS 실행을 줄임)
                if (!docStartScripts) view.evaluateJavascript(MediaScripts.INJECT, null)
                if (!docStartScripts) view.evaluateJavascript(SEAM_FIX_JS, null)
                if (!docStartScripts) view.evaluateJavascript(HIJACK_TAP_JS, null)
                if (!docStartScripts) view.evaluateJavascript(NO_GHOST_DRAG_JS, null)
                // 문서 시작 스크립트를 못 쓰는 기기에서는 영상 배너 감지/팝업 차단 스크립트를 여기서 넣는다 (한 번만 돈다)
                if (!docStartScripts && adBlockEnabled) view.evaluateJavascript(AdBlocker.COSMETIC_START_JS, null)
                if (adBlockEnabled) view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                if (tab.desktop) view.evaluateJavascript(desktopViewportJs(), null)
                if (effectiveZoom(tab) != 100) view.evaluateJavascript(pageZoomJs(tab), null)
                if (tab.rate != 1f) view.evaluateJavascript(speedJs(tab.rate), null)
                if (needCssDark()) view.evaluateJavascript(forceDarkJs(true), null)
                if (tab.restoreScrollPending) restoreHandoffScroll(tab, view)
                // 렌더러 종료·앱 복원으로 다시 불러온 영상 페이지는 보던 위치로 이어 간다
                if (tab.resumeApply && sameResumePage(url, tab.resumeUrl)) {
                    tab.resumeApply = false
                    view.evaluateJavascript(resumeJs(tab.resumePos), null)
                }
                // (저장은 백그라운드 스레드에서 — 메인 스레드에서 JSON을 읽고 쓰면 페이지 전환이 버벅인다)
                if (tab.errorUrl != null && url != tab.errorUrl) tab.errorUrl = null
                if (url.startsWith("http") && !url.startsWith(LOCAL_BASE) && !url.startsWith("https://${ExtensionManager.HOST}/") && tab.errorUrl == null && !tab.incognito) {
                    val title = view.title
                    io.execute { prefs.addHistory(url, title) }
                }
                if (tab === current) {
                    updateUi()
                    pageScrollBar.bind(if (tab.isHome) null else view)
                    view.post { pageScrollBar.refresh() }
                    view.postDelayed({ pageScrollBar.refresh() }, 350)
                    // '항상 번역'이 켜져 있으면 저절로 번역한다 (홈·오류 화면 등 내부 페이지는 제외)
                    if (!tab.isHome && tab.errorUrl == null && url.startsWith("http") && !url.startsWith(LOCAL_BASE)) {
                        pageTranslator?.onPageLoaded(url)
                    }
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            // 영상 로딩 중 WebView 기본 포스터(회색 바탕 + 늘어난 거대한 재생 아이콘)가 보이는 문제:
            // 1x1 투명 비트맵으로 바꿔서 기본 포스터가 그려지지 않게 한다.
            private var blankPoster: Bitmap? = null
            override fun getDefaultVideoPoster(): Bitmap? {
                return blankPoster ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
                    .also { it.eraseColor(0); blankPoster = it }
            }

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                tab.progress = if (tab.isHome) 100 else newProgress
                // 페이지 자체 로딩 바가 있는지 두 번만 살핀다 (진행 20%, 60% 때). 있으면 브라우저 로딩 바를 숨긴다.
                if (!tab.isHome && !tab.ownProgressBar &&
                    ((newProgress >= 20 && tab.ownBarChecks == 0) || (newProgress >= 60 && tab.ownBarChecks == 1))
                ) {
                    tab.ownBarChecks++
                    view.evaluateJavascript(OWN_BAR_JS, null)
                }
                // 진행률 이벤트마다 JS를 실행하면 로딩이 느려지므로 페이지당 한 번만 넣는다. (끝날 때 한 번 더 확인)
                if (adBlockEnabled && newProgress >= 30 && !tab.cosmeticInjected) {
                    tab.cosmeticInjected = true
                    view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                }
                if (needCssDark() && newProgress >= 20 && !tab.darkInjected) {
                    tab.darkInjected = true
                    view.evaluateJavascript(forceDarkJs(true), null)
                }
                if (tab.desktop && newProgress >= 25 && !tab.desktopInjected) {
                    tab.desktopInjected = true
                    view.evaluateJavascript(desktopViewportJs(), null)
                }
                if (newProgress >= 25 && !tab.zoomInjected && effectiveZoom(tab) != 100) {
                    tab.zoomInjected = true
                    view.evaluateJavascript(pageZoomJs(tab), null)
                }
                if (tab === current) {
                    if (newProgress >= 100) webContainer.endRefresh()
                    showProgress(newProgress)
                }
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: android.webkit.JsResult): Boolean {
                if (!jsDialogAllowed(tab)) { result.confirm(); return true }
                showJsDialog(url, message, 0, null, result)
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: android.webkit.JsResult): Boolean {
                if (!jsDialogAllowed(tab)) { result.cancel(); return true }
                showJsDialog(url, message, 1, null, result)
                return true
            }

            override fun onJsPrompt(
                view: WebView, url: String?, message: String?, defaultValue: String?,
                result: android.webkit.JsPromptResult
            ): Boolean {
                if (!jsDialogAllowed(tab)) { result.cancel(); return true }
                showJsDialog(url, message, 2, defaultValue, result)
                return true
            }

            // 페이지를 나가려 할 때 "변경사항이 저장되지 않을 수 있습니다" 를 묻는 창 (웹뷰 기본 '탐색 확인' 창 대신 앱 팝업)
            override fun onJsBeforeUnload(view: WebView, url: String?, message: String?, result: android.webkit.JsResult): Boolean {
                // 보이지 않는 탭 · 닫히는 중인 화면에서는 묻지 않고 그대로 나간다
                if (tab !== current || isFinishing || isDestroyed || switcherOpen) { result.confirm(); return true }
                val host = runCatching { Uri.parse(url).host }.getOrNull()
                Popup.leavePage(this@MainActivity, host) { leave ->
                    try {
                        if (leave) result.confirm() else result.cancel()
                    } catch (e: Exception) {
                        // 페이지가 이미 사라졌으면 무시
                    }
                }
                return true
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                handleWebPermissionRequest(request)
            }

            override fun onPermissionRequestCanceled(request: android.webkit.PermissionRequest) {
                webPermDialog?.dismiss()
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String, callback: android.webkit.GeolocationPermissions.Callback
            ) {
                handleGeolocationRequest(origin, callback)
            }

            override fun onGeolocationPermissionsHidePrompt() {
                webPermDialog?.dismiss()
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                // 이전 선택창이 남아 있으면 취소 처리 (콜백을 안 부르면 이후 업로드가 먹통이 됨)
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    // 허용 형식(accept)을 처리하는 선택창이 없으면 모든 파일 선택창으로 다시 시도한다
                    try {
                        val any = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                            if (fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                            }
                        }
                        fileChooserLauncher.launch(Intent.createChooser(any, fileChooserParams.title ?: "파일 선택"))
                        true
                    } catch (e2: Exception) {
                        fileChooserCallback = null
                        filePathCallback.onReceiveValue(null)
                        toast("파일 선택 화면을 열 수 없어요")
                        false
                    }
                }
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                scheduleStripRefresh()
                // 시스템 미디어 플레이어 제목이 이 페이지 제목을 따라가는 중이면(페이지가 mediaSession 제목을 안 주는 사이트),
                // 곡·영상이 바뀌어 탭 제목이 바뀐 즉시 반영한다 (백그라운드에서도)
                if (mediaSel?.first === tab) ui.post { updateMediaSession() }
                // 미러링 화면의 제목도 새 영상 제목으로
                ui.post { refreshMirrorTitle(tab) }
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                // 홈(새 탭) 화면에선 뒤에 남은 이전 페이지가 보내는 아이콘을 받지 않는다
                if (!tab.isHome && icon != null) tab.favicon = icon
                if (!tab.isHome) Favicons.save(view.context, view.url, icon)
                scheduleStripRefresh()
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.resetTransform()
                browserUi.animate().cancel()
                browserUi.alpha = 1f
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.keepScreenOn = true
                fullscreenContainer.visibility = View.VISIBLE
                browserUi.visibility = View.GONE
                setFullscreenBackdrop(true)
                setSystemBarsVisible(false)
                refreshPipParams()
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message
            ): Boolean {
                // 사용자 동작 없이 열리는 팝업(팝업 광고)은 차단
                if (!isUserGesture && !recentTouch()) return false
                val newTab = createTab(null, opener = tab)
                newTab.scriptPopup = true
                newTab.popupFromUrl = view.url
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = newTab.webView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val target = tabs.firstOrNull { it.liveWebView === window } ?: return
                ui.post { closeTab(target) }
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            // 사용자가 화면을 만지지 않았는데 시작된 다운로드는 자동 다운로드로 보고 차단
            if (blockAutoDownload && !recentTouch(DOWNLOAD_TOUCH_MS)) {
                SecurityStats.add(SecurityStats.AUTO_DL)
                toast("자동 다운로드를 차단했습니다")
            } else if (url.startsWith("blob:") || url.startsWith("data:")) {
                // 페이지 안에서 만든 파일(blob/data)은 페이지에서 읽어와 저장한다
                requestNotificationPermission()
                toast("다운로드 시작")
                localDownload.handle(wv, url, contentDisposition, mimeType)
            } else {
                startDownload(url, userAgent, contentDisposition, mimeType)
                // 링크·팝업이 새 탭을 열고 곧바로 파일 다운로드로 바뀐 경우: 빈 탭만 남으므로 알아서 닫고 원래 탭으로 돌아간다
                val blank = wv.url.let { u -> u.isNullOrEmpty() || u == "about:blank" || u == url }
                if (blank && !wv.canGoBack() && !tab.isHome && tab.pendingUrl == null && tabs.size > 1) {
                    ui.postDelayed({ if (tab in tabs && !isFinishing && !isDestroyed) closeTab(tab) }, 300)
                }
            }
        }

        wv.setOnLongClickListener {
            val result = wv.hitTestResult
            val extra = result.extra
            when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (extra != null) showLinkMenu(extra, null, wv)
                    extra != null
                }
                WebView.HitTestResult.IMAGE_TYPE -> {
                    if (extra != null) showLinkMenu(null, extra, wv)
                    extra != null
                }
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    if (extra != null) {
                        val msg = Handler(Looper.getMainLooper()) { m ->
                            showLinkMenu(m.data.getString("url"), extra, wv)
                            true
                        }.obtainMessage()
                        wv.requestFocusNodeHref(msg)
                    }
                    extra != null
                }
                else -> false
            }
        }
    }

    // ───────────────────────── 주소창 / 빠른 검색 ─────────────────────────

    private fun setupUrlBar() {
        suggestAdapter = SuggestAdapter(this, suggestItems)
        suggestAdapter.onRemove = { q ->
            prefs.removeRecentSearch(q)
            showRecentSearches()
        }
        suggestAdapter.onClearAll = {
            prefs.clearRecentSearches()
            showRecentSearches()
        }
        urlBar.setAdapter(suggestAdapter)
        urlBar.threshold = 1
        // 추천 / 최근 검색 창: 메뉴 팝업과 같은 연한 면 + 둥근 모서리 + 얇은 테두리, 주소창과 살짝 띄운다
        // 블러가 켜져 있으면 뒤가 비치는 반투명 유리 + 팝업 뒤 블러, 아니면 예전처럼 불투명
        suggestAdapter.onShown = { v -> Blur.behindRootOf(v, this, 10) }
        applySuggestBackground()
        urlBar.dropDownVerticalOffset = dp(6)
        // 이미 입력창에 들어와 있을 때 빈 칸을 다시 누르면 최근 검색을 다시 보여 준다
        urlBar.setOnClickListener {
            if (urlBar.hasFocus() && !urlBar.isPopupShowing && urlBar.text.isNullOrBlank()) showRecentSearches()
        }
        // 왼쪽 자물쇠·지구본을 누르면 사이트 정보 팝업 (입력 중이 아닐 때만). 누른 채 움직이거나 취소하면 아무 일도 없다
        var siteIconDown = false
        urlBar.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    siteIconDown = !urlBar.hasFocus() && siteIconHit(ev.x) && siteInfoAvailable()
                    siteIconDown
                }
                MotionEvent.ACTION_UP -> if (siteIconDown) {
                    siteIconDown = false
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
                    showSiteInfo(urlBar)
                    true
                } else false
                MotionEvent.ACTION_CANCEL -> { val was = siteIconDown; siteIconDown = false; was }
                else -> siteIconDown
            }
        }

        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadFromInput(urlBar.text.toString())
                true
            } else {
                false
            }
        }

        urlBar.setOnItemClickListener { _, _, position, _ ->
            suggestAdapter.getItem(position)?.let { loadFromInput(it) }
        }

        // 다른 창에서 끌고 온 탭을 주소창에 놓으면 이 창의 현재 탭이 그 주소로 열린다 (글자로 붙여 넣지 않는다)
        urlBar.setOnDragListener { v, e -> onAddressReceiveDrag(v, e) }
        urlBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                scrollBars.show()
                ui.post { scrollBars.sync() }
                // 입력할 때는 전체 주소를 보여주고 전체 선택
                setUrlText(
                    if (current?.isHome == true) ""
                    else pageUrlOf(current, current?.webView)?.takeIf { it != "about:blank" && it != HOME_URL && !it.startsWith("data:") } ?: ""
                )
                urlBar.post {
                    urlBar.selectAll()
                    showRecentSearches()
                }
            } else {
                urlBar.dismissDropDown()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(urlBar.windowToken, 0)
                barsTempShown = false
                updateUi()
            }
        }

        urlBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher || !urlBar.hasFocus()) return
                suggestRunnable?.let { ui.removeCallbacks(it) }
                val q = s?.toString()?.trim().orEmpty()
                if (q.isEmpty()) {
                    showRecentSearches()
                    return
                }
                val r = Runnable { requestSuggestions(q) }
                suggestRunnable = r
                ui.postDelayed(r, 150)
            }
        })
    }

    /**
     * 탭이 지금 보여 주는 주소. 오류 화면(연결할 수 없어요 등)은 웹 기록에 "data:text/html;...base64," 같은 주소로 남을 수 있어서
     * (저장했다 되살린 탭·다른 창으로 옮긴 탭), 그럴 때는 실패한 원래 주소(errorUrl)를 대신 돌려준다.
     */
    private fun pageUrlOf(tab: BrowserTab?, wv: WebView? = tab?.liveWebView): String? {
        val u = wv?.url
        if (u != null && u.startsWith("data:")) tab?.errorUrl?.let { return it }
        return u
    }

    /** 주소창에 평소 보여줄 짧은 주소 (https://www. 를 뗀 도메인) */
    private fun displayUrl(url: String?): String {
        if (url.isNullOrBlank() || url == "about:blank" || url == HOME_URL) return ""
        // data: 주소(오류 화면 등 내부 화면)는 알아볼 수 없는 긴 글자라 주소창에 보이지 않게 한다
        if (url.startsWith("data:")) return ""
        // 기기에서 연 HTML 파일은 긴 주소 대신 파일 이름을 보여 준다
        if (url.startsWith("content://") || url.startsWith("file://")) {
            return localFileNames[url] ?: runCatching { Uri.parse(url).lastPathSegment }.getOrNull() ?: url
        }
        if (url.startsWith(LOCAL_BASE)) return Uri.decode(url.removePrefix(LOCAL_BASE).substringBefore('?').substringBefore('#'))
        if (url.startsWith("https://${ExtensionManager.HOST}/")) return ""   // 확장 프로그램이 바꾼 새 탭·기록 화면
        if (!url.startsWith("http")) return url
        val host = try { Uri.parse(url).host } catch (e: Exception) { null }
        return host?.removePrefix("www.") ?: url
    }

    /** 주소창 왼쪽 아이콘: https 면 자물쇠, 아니면 지구본 */
    private fun updateSecurityIcon(url: String?, incognito: Boolean = false) {
        val blank = url.isNullOrBlank() || url == "about:blank" || url == HOME_URL
        val secure = url?.startsWith("https://") == true
        val res = when {
            blank && incognito -> R.drawable.ic_incognito
            blank -> R.drawable.ic_search
            secure -> R.drawable.ic_lock
            else -> R.drawable.ic_globe
        }
        val icon = ContextCompat.getDrawable(this, res)?.mutate()
        icon?.setBounds(0, 0, dp(18), dp(18))
        icon?.setTint(
            if (incognito) incognitoTextColor
            else pillFg ?: ThemeColors.get(urlBar, com.google.android.material.R.attr.colorOnSurfaceVariant)
        )
        urlBar.setCompoundDrawablesRelative(icon, null, null, null)
    }

    private fun setUrlText(text: String) {
        suppressWatcher = true
        suggestItems.clear()
        urlBar.setText(text)
        suppressWatcher = false
    }

    @Volatile private var latestSuggestQuery = ""

    private fun requestSuggestions(q: String) {
        latestSuggestQuery = q
        // 북마크를 먼저, 그다음 방문 기록
        val marks = prefs.bookmarks()
            .filter { it.url.contains(q, true) || it.title.contains(q, true) }
            .map { it.url }
            .take(2)
        val local = (marks + prefs.history()
            .filter { it.first.contains(q, true) || it.second.contains(q, true) }
            .map { it.first })
            .distinct()
            .take(4)
        setSuggestions(local)

        io.execute {
            // 그 사이 글자가 더 쳐졌으면 이 요청은 쓸모없다 (빨리 칠 때 요청이 줄줄이 밀려 느려지던 것을 막는다)
            if (latestSuggestQuery != q) return@execute
            try {
                val remote = Suggest.fetch(q)
                ui.post {
                    if (urlBar.text.toString().trim() == q) {
                        setSuggestions((local + remote.filter { it !in local }).take(8))
                    }
                }
            } catch (e: Exception) {
                // 자동완성 실패는 무시
            }
        }
    }

    /** 주소창에 들어오거나 입력을 모두 지웠을 때: 최근에 직접 검색한 글자를 보여 준다 (시크릿 탭에서는 보여 주지 않는다) */
    /** 추천 / 최근 검색 창 배경: 주소창과 같은 색 (시크릿이면 시크릿 주소창 색). 창을 띄울 때마다 다시 만들어 테마 변경도 따라간다 */
    private fun applySuggestBackground() {
        val incog = current?.incognito == true
        val bg = if (incog) incognitoBarColor
            else pillTint?.defaultColor ?: ThemeColors.get(urlBar, com.google.android.material.R.attr.colorSurfaceContainerHigh)
        val fg = if (incog) incognitoTextColor else pillFg ?: ThemeColors.readableOn(bg, null)
        suggestAdapter.textColor = fg
        urlBar.setDropDownBackgroundDrawable(GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(bg or 0xFF000000.toInt())
            setStroke(dp(1), ColorUtils.setAlphaComponent(fg, 0x33))
        })
    }

    private fun showRecentSearches() {
        if (!urlBar.hasFocus()) return
        val items = if (current?.incognito == true) emptyList() else prefs.recentSearches().take(8)
        suggestAdapter.recentMode = items.isNotEmpty()
        suggestItems.clear()
        suggestItems.addAll(items)
        suggestAdapter.notifyDataSetChanged()
        if (items.isEmpty()) urlBar.dismissDropDown() else { applySuggestBackground(); urlBar.showDropDown() }
    }

    /** 주소가 아니라 검색어로 처리될 입력인가 (resolveInput 과 같은 기준) */
    private fun isSearchQuery(input: String): Boolean {
        if (input.startsWith("http://") || input.startsWith("https://")) return false
        val parts = input.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2 && SearchEngines.shortcuts.containsKey(parts[0].lowercase())) return true
        val isLocal = input.startsWith("localhost") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(input)
        if (!input.contains(" ") && (isLocal || input.contains("."))) return false
        return true
    }

    private fun setSuggestions(items: List<String>) {
        suggestAdapter.recentMode = false
        suggestItems.clear()
        suggestItems.addAll(items)
        suggestAdapter.notifyDataSetChanged()
        // 맨 위 추천이 주소면 사용자가 고르기 전에 도메인 조회를 해 둔다
        items.firstOrNull()?.let { if (it.startsWith("http")) prefetchDns(it) }
        if (items.isNotEmpty() && urlBar.hasFocus()) { applySuggestBackground(); urlBar.showDropDown() }
    }

    private fun resolveInput(input: String): String {
        if (input.startsWith("http://") || input.startsWith("https://")) return input

        // 빠른 검색 단축어 (예: "yt 노래", "n 날씨")
        val parts = input.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2) {
            SearchEngines.shortcuts[parts[0].lowercase()]?.let { return it + Uri.encode(parts[1]) }
        }

        val isLocal = input.startsWith("localhost") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(input)
        if (!input.contains(" ") && isLocal) return "http://$input"
        if (!input.contains(" ") && input.contains(".")) return "https://$input"

        return prefs.currentEngine().url(input)
    }

    private fun loadFromInput(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val tab = current
        // 직접 검색한 글자는 최근 검색으로 남긴다 (시크릿 탭 제외)
        if (tab?.incognito != true && isSearchQuery(input)) prefs.addRecentSearch(input)
        val wasHome = tab?.isHome == true
        tab?.isHome = false
        assistant?.refreshChips()
        // 홈 화면에서 연 주소는 홈을 그대로 보여 준 채 로딩하고, 새 페이지의 첫 화면이 그려지면 넘어간다
        // (예전에는 로딩 시작과 동시에 빈 웹뷰로 바뀌었다)
        if (tab != null && wasHome) {
            tab.awaitCommit = true
            ui.postDelayed({
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                }
            }, 12000)
        }
        var target = resolveInput(input)
        // HTTPS 우선: 직접 입력한 http 주소도 https 로 먼저 연결한다
        upgradeUrl(target)?.let {
            current?.upgradedFrom = target
            target = it
        }
        prefetchDns(target)
        current?.stoppedByHome = false
        current?.webView?.loadUrl(target)
        updateUi()
        urlBar.dismissDropDown()
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ───────────────────────── 컨트롤 / 뒤로가기 / UI ─────────────────────────

    /** 새로고침 버튼: 불러오는 중이면 중지, 아니면 새로고침 (주소창 안쪽 버튼과 옮겨 둔 버튼이 같이 쓴다) */
    private fun reloadOrStop() {
        val c = current ?: return
        if (c.progress in 1..99) c.webView.stopLoading() else reloadTab(c)
    }

    /**
     * 새로고침을 눌렀을 때: 곧 로딩 표시(X)로 바뀌면 그 아이콘 교체 애니메이션이 반응을 대신한다.
     * 표시가 안 바뀌면(홈 화면·이미 끝난 로딩 등) 화살표가 한 바퀴 돌아 눌렀다는 걸 알려 준다.
     */
    private fun refreshTapFeedback(v: View?) {
        v ?: return
        val before = loadingIcon
        v.postDelayed({
            if (loadingIcon == before && v.isAttachedToWindow && v.isShown) Motion.spinOnce(v)
        }, 240)
    }

    private fun setupControls() {
        val goBack = { navBack(); Unit }
        val goForward = { navForward(); Unit }
        val reload = { reloadOrStop() }
        val goHome = {
            // 홈도 하나의 기록으로 남긴다: 홈 → 뒤로가기 = 보던 페이지, 다시 앞으로가기 = 홈
            val custom = prefs.homepage
            if (custom.isNotEmpty()) {
                // 직접 정한 홈 페이지가 있으면 그 주소를 연다
                current?.let { it.webView.loadUrl(custom) }
            } else {
                current?.let { if (!it.isHome) loadHome(it) }
            }
            Unit
        }

        btnBack.setOnClickListener { goBack() }
        tbBack.setOnClickListener { goBack() }
        btnForward.setOnClickListener { goForward() }
        tbForward.setOnClickListener { goForward() }
        // 뒤로/앞으로 버튼을 꾹 누르면 기록 목록 → 누르면 그 페이지로 이동
        listOf(btnBack, tbBack).forEach {
            it.setOnLongClickListener { v -> showNavHistory(forward = false, anchor = v); true }
        }
        listOf(btnForward, tbForward).forEach {
            it.setOnLongClickListener { v -> showNavHistory(forward = true, anchor = v); true }
        }
        btnRefresh.setOnClickListener { reload(); refreshTapFeedback(btnRefresh) }
        btnHome.setOnClickListener { goHome() }
        tbHome.setOnClickListener { goHome() }
        tbDesktop.setOnClickListener { toggleDesktopSite() }
        tbAi.setOnClickListener { assistant?.show(tbAi) }
        btnTabs.setOnClickListener { openTabSwitcher() }
        btnBottomTabs.setOnClickListener { openTabSwitcher() }
        // 탭 버튼을 꾹 누르면 새 탭 추가
        listOf(btnTabs, btnBottomTabs, findViewById<View>(R.id.btnStripTabList)).forEach {
            it.setOnLongClickListener { v ->
                if (switcherOpen) return@setOnLongClickListener false
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                openNewTabAndFocus()
                true
            }
        }
        // 더보기를 연타해도 메뉴는 하나만 뜬다 (이미 떠 있으면 무시)
        val openMenuOnce = { v: View ->
            if (openMenu?.showing?.invoke() != true) showMenu(v)
        }
        btnMenu.setOnClickListener { openMenuOnce(it) }
        tbMenu.setOnClickListener { openMenuOnce(it) }
        // 바를 숨긴 동안 뜨는 버튼: 누르면 바를 다시 보이게 한다 (메뉴는 바의 메뉴 버튼으로)
        btnFloatMenu.setOnClickListener { toggleHideBars() }
        // 길게 누르면 주소창을 잠깐 불러온다 (바를 숨겨 둔 채로 주소를 입력할 수 있게)
        btnFloatMenu.setOnLongClickListener { focusUrlBar(); true }
        findViewById<View>(R.id.btnStripNewTab).setOnClickListener { openNewTabAndFocus() }
        // + 버튼은 32dp 라서 작은 팝업 창에서 누르기 어렵다. 버튼을 감싼 자리(가로 44dp · 탭 줄 높이 전체)도 같이 눌리게 한다
        findViewById<View>(R.id.stripPlusHolder)?.apply {
            isClickable = true
            setOnClickListener { openNewTabAndFocus() }
        }
        // + 는 마지막 탭 옆을 따라가다 오른쪽 끝에서 멈춘다 (위치만 연속으로 바뀜)
        val stripLayoutWatcher = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateStripPlus() }
        tabStripScroll.addOnLayoutChangeListener(stripLayoutWatcher)
        tabStrip.addOnLayoutChangeListener(stripLayoutWatcher)
        tabStripScroll.setOnScrollChangeListener { _, _, _, _, _ -> updateStripPlus() }
        // 탭 줄 폭이 바뀌면(창 크기 조절·접이식 펼침·분할 화면) 탭 폭을 다시 계산한다
        tabStripScroll.addOnLayoutChangeListener { v, l, _, r, _, _, _, _, _ ->
            val w = r - l
            if (w != lastStripViewportW) {
                lastStripViewportW = w
                if (expanded && w > 0) scheduleStripRefresh()
            }
        }
        updateStripPlus()
        findViewById<View>(R.id.btnStripTabList).setOnClickListener { openTabSwitcher() }
        setupFindBar()
        // 상/하단바 버튼은 버튼마다 눌렀을 때 움직임이 다르다 (뒤로=왼쪽으로 튐, 새로고침=한 바퀴, 설정=톱니바퀴 회전 …)
        listOf(
            btnBack to "back", tbBack to "back",
            btnForward to "forward", tbForward to "forward",
            btnRefresh to "refresh",
            btnHome to "home", tbHome to "home",
            btnTabs to "tabs", btnBottomTabs to "tabs",
            btnMenu to "menu", tbMenu to "menu",
            tbDesktop to "desktop", tbAi to "ai",
            findViewById<View>(R.id.btnStripNewTab) to "newtab",
            findViewById<View>(R.id.btnStripTabList) to "tablist"
        ).forEach { (view, kind) -> addPressAnim(view, kind) }
        // 데스크톱 버튼 아이콘은 모양 변하는 아이콘으로 바뀌었으니 지금 상태(모니터/폰)에 맞는 모양으로 맞춘다
        updateDesktopButton()
    }

    /**
     * 상단 탭 줄의 새 탭(+) 위치. + 는 하나만 두고 translationX 로 움직인다.
     *  - 탭이 적으면 마지막 탭 바로 옆
     *  - 탭이 많아 넘치면 오른쪽 끝에 멈춰 스크롤해도 항상 보임
     * 보이기/숨기기 전환이 없고 탭 폭 애니메이션·스크롤 중에도 매 프레임 연속으로 따라가므로 깜박이거나 튀지 않는다.
     */
    private var stripPlusBg: android.graphics.drawable.ColorDrawable? = null

    private fun updateStripPlus() {
        val holder = findViewById<View>(R.id.stripPlusHolder) ?: return
        val fade = findViewById<View>(R.id.stripPlusFade) ?: return
        val viewport = tabStripScroll.width
        if (viewport <= 0) return

        // + 밑으로 들어가는 탭은 불투명한 색으로 덮지 않고 투명하게 지운다 (StripScrollView.setCover).
        // 탭 줄 배경이 반투명 유리라서 색으로 덮으면 그 자리만 덩어리로 튄다.
        if (stripPlusBg == null) {
            stripPlusBg = android.graphics.drawable.ColorDrawable(0)
            holder.background = null
            fade.visibility = View.GONE
        }

        // 따라가는 위치(마지막 탭 옆)와 오른쪽 끝 멈춤 위치 중 더 왼쪽
        val follow = tabStripScroll.paddingStart + tabStrip.width - tabStripScroll.scrollX
        val rightStop = viewport - holder.width
        val x = minOf(follow, rightStop).coerceAtLeast(0)
        holder.translationX = x.toFloat()
        fade.translationX = (x - fade.width).toFloat()
        if (captionActive) updateCaptionTouchRegion()

        // 멈춤 위치를 넘어 탭이 + 밑으로 들어오기 시작하면 배경·그라데이션을 부드럽게 켠다
        val covered = ((follow - rightStop) / dp(16).toFloat()).coerceIn(0f, 1f)
        tabStripScroll.setCover(holder.width, fade.layoutParams.width, covered)
    }

    // ───────────────────────── 페이지 내 찾기 ─────────────────────────

    /** 지금 찾기 결과를 칠해 둔 WebView (탭을 옮기거나 닫을 때 이 뷰의 표시를 지운다) */
    private var findWebView: WebView? = null

    private fun setupFindBar() {
        etFind.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = runFind(s?.toString().orEmpty())
        })
        etFind.setOnEditorActionListener { _, actionId, ev ->
            val enter = ev?.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                findStep(!(ev?.isShiftPressed ?: false))
                true
            } else false
        }
        findViewById<View>(R.id.findNext).setOnClickListener { findStep(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { findStep(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }
        listOf<View>(
            findViewById(R.id.findNext), findViewById(R.id.findPrev), findViewById(R.id.findClose)
        ).forEach { addPressAnim(it) }
    }

    private fun openFind() {
        val tab = current ?: return
        if (tab.isHome) {
            toast("웹 페이지를 연 뒤에 찾을 수 있어요")
            return
        }
        // 위쪽 바가 스크롤로 숨겨져 있으면 찾기 바도 같이 올라가 버리므로 먼저 되돌린다.
        scrollBars.show(animate = false)
        findBar.visibility = View.VISIBLE
        ui.post { scrollBars.sync() }
        findWebView = tab.webView
        etFind.requestFocus()
        etFind.selectAll()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(etFind, InputMethodManager.SHOW_IMPLICIT)
        runFind(etFind.text.toString())
    }

    private fun closeFind() {
        ui.post { scrollBars.sync() }
        if (findBar.visibility != View.VISIBLE) return
        findWebView?.let {
            // 탭이 닫히며 WebView가 이미 정리된 뒤일 수 있다
            try { it.clearMatches(); it.setFindListener(null) } catch (_: Exception) {}
        }
        findWebView = null
        findBar.visibility = View.GONE
        findCount.text = ""
        etFind.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etFind.windowToken, 0)
        current?.webView?.requestFocus()
    }

    private fun runFind(query: String) {
        val wv = findWebView ?: return
        if (query.isEmpty()) {
            wv.clearMatches()
            findCount.text = ""
            return
        }
        wv.setFindListener { active, total, _ ->
            findCount.text = if (total == 0) "없음" else "${active + 1}/$total"
        }
        wv.findAllAsync(query)
    }

    private fun findStep(forward: Boolean) {
        if (etFind.text.isNullOrEmpty()) return
        findWebView?.findNext(forward)
    }

    private fun setupHome() {
        applyHomeTheme()
        refreshHomeShortcuts()
        refreshHomeWidget()
        // 개인정보 위젯 두 개를 동시에(또는 거의 동시에) 눌러 둘 다 열리지 않게 한다 (손가락 둘은 splitMotionEvents=false 로 막고, 연속 탭은 여기서 막는다)
        var lastWidgetTapAt = 0L
        fun widgetTapAllowed(): Boolean {
            val now = android.os.SystemClock.uptimeMillis()
            if (now - lastWidgetTapAt < 600L) return false
            lastWidgetTapAt = now
            return true
        }
        findViewById<View>(R.id.homeAdCard).apply {
            setOnClickListener { v -> if (widgetTapAllowed()) showAdBlockStats(v) }
            // 넓은 카드라서 살짝만 눌리고, 튀지 않고 부드럽게 돌아온다
            Motion.pressable(this, 0.985f, releaseDamping = SpringForce.DAMPING_RATIO_NO_BOUNCY)
        }
        findViewById<View>(R.id.homeSecCard).apply {
            setOnClickListener { v -> if (widgetTapAllowed()) showSecurityStats(v) }
            Motion.pressable(this, 0.985f, releaseDamping = SpringForce.DAMPING_RATIO_NO_BOUNCY)
        }
        // 개인정보 위젯의 가로 폭을 즐겨찾기 4칸 버튼(62dp) 줄의 양 끝에 맞춘다: 한 칸은 폭의 1/4, 버튼은 칸 가운데
        val shortcutsBox = findViewById<View>(R.id.homeShortcuts)
        val adHeader = findViewById<View>(R.id.homeWidgetHeader)
        val widgetCards = listOf(findViewById<View>(R.id.homeAdCard), findViewById<View>(R.id.homeSecCard))
        fun alignWidgetToTiles() {
            val w = shortcutsBox.width
            if (w <= 0) return
            val side = ((w / 4 - dp(62)) / 2).coerceAtLeast(0)
            for (card in widgetCards) {
                (card.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
                    if (it.marginStart != side || it.marginEnd != side) {
                        it.marginStart = side; it.marginEnd = side
                        card.layoutParams = it
                    }
                }
            }
            if (adHeader.paddingStart != side + dp(4)) adHeader.setPadding(side + dp(4), 0, side, 0)
        }
        shortcutsBox.addOnLayoutChangeListener { _, l, _, r, _, ol, _, oldR, _ ->
            // 레이아웃 계산 도중에 바로 고치면 카드 여백 변경이 반영되지 않고(헤더만 맞고 카드는 좁게 남음) 지나갈 수 있어서,
            // 계산이 끝난 뒤에 고친다
            if (r - l != oldR - ol) shortcutsBox.post { alignWidgetToTiles() }
        }
        shortcutsBox.post { alignWidgetToTiles() }
        // 창 크기가 바뀔 때마다(분할 화면·플로팅 창 등) 홈 폭을 다시 맞춘다.
        homeView.addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
            if (right - left != oldRight - oldLeft) homeContent.post { applyHomeWidth() }
        }
        // 새 탭 화면 크기가 정해지거나 바뀌면 (테마 배경이 있을 때) 흐린 배경을 다시 만든다
        homeView.addOnLayoutChangeListener { v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (themeSpec?.hasNtp == true && (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop)) v.post { refreshHomeGlass() }
        }
        homeContent.post { applyHomeWidth() }
        // 버튼·카드의 유리가 그려진 뒤 움직였으면(스크롤·애니메이션·레이아웃 변경) 그 자리의 배경으로 다시 그린다.
        // 한 번 그려 둔 그림은 뷰가 움직여도 그대로라서, 안 맞으면 블러가 사라진 것처럼 보였다
        homeView.viewTreeObserver.addOnPreDrawListener {
            for (ref in homeGlassDrawables) {
                val d = ref.get() ?: continue
                if (d.moved()) d.invalidateSelf()
            }
            true
        }
    }

    /** 넓은 창에서는 560dp 로 가운데 정렬, 그보다 좁으면 창 폭에 꽉 맞춰 양쪽이 잘리지 않게 한다. */
    private fun applyHomeWidth() {
        val parentW = homeView.width
        if (parentW <= 0) return
        val lp = homeContent.layoutParams as? FrameLayout.LayoutParams ?: return
        val target = if (parentW > dp(560)) dp(560) else ViewGroup.LayoutParams.MATCH_PARENT
        if (lp.width != target) {
            lp.width = target
            lp.gravity = Gravity.CENTER_HORIZONTAL
            homeContent.layoutParams = lp
        }
    }

    // ───────────────────────── 홈 즐겨찾기 ─────────────────────────

    /** 저장된 즐겨찾기로 홈 타일을 다시 그린다. 누르면 열고, 길게 누르면 편집·삭제·이동. */
    private fun refreshHomeShortcuts() {
        val box = findViewById<LinearLayout>(R.id.homeShortcuts)
        box.removeAllViews()
        val list = prefs.homeShortcuts()

        val onSurface = ThemeColors.get(homeView, com.google.android.material.R.attr.colorOnSurface)
        val surface = ThemeColors.get(homeView, com.google.android.material.R.attr.colorSurface)
        val muted = homeFgTheme ?: ThemeColors.get(homeView, com.google.android.material.R.attr.colorOnSurfaceVariant)
        // 즐겨찾기 아이콘은 흑백: 면은 테마 글자색을 연하게 섞고, 글자는 테마 글자색 그대로

        fun tile(
            glyph: String, label: String, accent: Int?,
            onClick: () -> Unit, onLong: (() -> Unit)?
        ): View {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
                if (onLong != null) setOnLongClickListener {
                    it.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    onLong()
                    true
                }
            }
            val face = FrameLayout(this).apply {
                // 타일 면: 라이트 모드는 흰색, 다크 모드는 검은색. 글자·아이콘은 면과 대비되는 색
                val night = systemNight()
                // 라이트: 흰 면 / 다크: 검은색 대신 아주 어두운 청록빛 초록 면
                val faceColor = if (night) 0xFF123A31.toInt() else android.graphics.Color.WHITE
                val lineColor = androidx.core.graphics.ColorUtils.setAlphaComponent(muted, if (night) 0x40 else 0x33)
                val bg = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(22).toFloat()
                    if (accent != null) {
                        setColor(faceColor)
                        setStroke(dp(1), androidx.core.graphics.ColorUtils.setAlphaComponent(muted, 0x22))
                    } else {
                        // '추가' 칸: 비어 있는 자리처럼 보이게 점선 테두리만
                        setColor(android.graphics.Color.TRANSPARENT)
                        setStroke((1.5f * resources.displayMetrics.density).toInt(), lineColor, dp(5).toFloat(), dp(4).toFloat())
                    }
                }
                if (accent != null) elevation = dp(3).toFloat()
                val sky = chromeSky()
                val fg: Int = when {
                    // 글자·아이콘: 검은색 대신 청록이 섞인 연두색
                    // 테마 새 탭이면 '추가' 칸의 + 도 고른 글자색을 따른다
                    homeFgTheme != null && accent == null -> homeFgTheme!!
                    // 테마 새 탭이면 바로가기 글자도 초록이 아니라 테마 색 (하늘색 칸 위에서는 그 위에서 읽히는 색)
                    sky != null -> readableOn(sky, themeSpec?.ntpText)
                    themeSpec?.samsungTabs == true -> readableOn(themeSpec?.samsungSel ?: android.graphics.Color.WHITE, homeFgTheme)
                    homeFgTheme != null -> readableOn(faceColor, homeFgTheme)
                    night -> if (accent != null) 0xFF7CE6B8.toInt() else 0xFF9AA0A6.toInt()
                    else -> if (accent != null) 0xFF17A673.toInt() else 0xFF5F6368.toInt()
                }
                // 삼성 테마: 바로가기 칸은 흰색 둥근 네모(은은한 그림자), '추가' 칸은 옅은 회색 면
                val samsung = themeSpec?.samsungTabs == true
                if (samsung) {
                    if (accent != null) { bg.setColor(themeSpec?.samsungSel ?: android.graphics.Color.WHITE); bg.setStroke(0, 0) }
                    else { bg.setColor(androidx.core.graphics.ColorUtils.setAlphaComponent(0xFF8E8E93.toInt(), 0x44)); bg.setStroke(0, 0) }
                }
                // 밝은 크롬 테마: 바로가기 칸을 하늘색으로 (그림자·테두리 없이)
                if (sky != null) {
                    bg.setColor(sky)
                    if (accent != null) { bg.setStroke(0, 0); elevation = 0f }
                }
                background = bg
                val glassBg = if (accent != null && sky == null && !samsung) homeGlassFor(this, 22) else null
                if (glassBg != null) { background = glassBg; elevation = 0f }
                if (accent != null) {
                    addView(TextView(context).apply {
                        text = glyph
                        gravity = Gravity.CENTER
                        textSize = 22f
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        setTextColor(if (glassBg != null) (homeSectionFg ?: homeFgTheme ?: fg) else fg)
                    }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                } else {
                    addView(ImageView(context).apply {
                        setImageResource(R.drawable.ic_add)
                        imageTintList = android.content.res.ColorStateList.valueOf(fg)
                        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
                }
            }
            col.addView(face, LinearLayout.LayoutParams(dp(62), dp(62)))
            col.addView(
                TextView(this).apply {
                    text = label
                    textSize = 12.5f
                    maxLines = 1
                    gravity = Gravity.CENTER
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(muted)
                    homeShadow(this)
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(9)
                    marginStart = dp(2); marginEnd = dp(2)
                }
            )
            addPressAnim(col)
            return col
        }

        val tiles = ArrayList<View>()
        list.forEachIndexed { i, sc ->
            val glyph = sc.glyph.ifBlank { sc.name.trim().take(1).uppercase() }.ifBlank { "•" }
            tiles.add(tile(glyph, sc.name, onSurface, { loadFromInput(sc.url) }, { showShortcutMenu(i) }))
        }
        if (list.size < MAX_HOME_SHORTCUTS) {
            tiles.add(tile("+", "추가", null, { showShortcutDialog(null, -1) }, null))
        }
        val perRow = 4
        tiles.chunked(perRow).forEachIndexed { r, rowTiles ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowTiles.forEach { line.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
            repeat(perRow - rowTiles.size) { line.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            box.addView(
                line,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (r > 0) topMargin = dp(24)
                }
            )
        }
    }

    // 차단 기록이 바뀌면 새 탭 위젯도 바로 따라 바뀐다. 차단은 아주 잦으므로 0.3초에 한 번만 갱신한다.
    private val homeStatsRefreshQueued = java.util.concurrent.atomic.AtomicBoolean(false)
    private val homeStatsListener = Runnable {
        if (homeStatsRefreshQueued.compareAndSet(false, true)) {
            window.decorView.postDelayed({
                homeStatsRefreshQueued.set(false)
                if (!isDestroyed && homeView.visibility == View.VISIBLE) refreshHomeWidget()
            }, 300L)
        }
    }

    /** 새 탭 화면 개인정보 위젯: 최근 7일 동안 막은 광고 수를 보여 준다 */
    private fun refreshHomeWidget() {
        refreshHomeSecurityWidget()
        val tv = findViewById<TextView>(R.id.homeAdText) ?: return
        val n = SecurityStats.weekTotal(SecurityStats.AD)
        val num = String.format(java.util.Locale.getDefault(), "%,d", n)
        val msg = "이번 주 광고 ${num}개를 차단했습니다."
        tv.text = android.text.SpannableString(msg).apply {
            val st = msg.indexOf(num)
            setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), st, st + num.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            // 숫자는 앱 포인트 색으로
            setSpan(android.text.style.ForegroundColorSpan(
                if (homeGlassBmp != null && homeFgTheme != null) homeFgTheme!!
                else ThemeColors.get(tv, com.google.android.material.R.attr.colorPrimary)
            ), st, st + num.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    /** 새 탭 화면 보안 현황 위젯: 보호 수준과 오늘 차단 수를 한 줄로 */
    private fun refreshHomeSecurityWidget() {
        val tv = findViewById<TextView>(R.id.homeSecText) ?: return
        val today = SecurityStats.todayTotal()
        val num = String.format(java.util.Locale.getDefault(), "%,d", today)
        val msg = if (today == 0) "오늘 차단한 위협이 아직 없습니다." else "오늘 ${num}번 차단했습니다."
        val spanEx = android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        tv.text = android.text.SpannableString(msg).apply {
            // 차단 횟수만 굵게 + 앱 포인트 색으로 강조 (0건이면 강조 없음)
            if (today > 0) {
                val st = msg.indexOf(num)
                setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), st, st + num.length, spanEx)
                setSpan(android.text.style.ForegroundColorSpan(
                    if (homeGlassBmp != null && homeFgTheme != null) homeFgTheme!!
                    else ThemeColors.get(tv, com.google.android.material.R.attr.colorPrimary)
                ), st, st + num.length, spanEx)
            }
        }
    }

    private fun showShortcutMenu(index: Int) {
        val list = prefs.homeShortcuts()
        val sc = list.getOrNull(index) ?: return
        val items = mutableListOf<Popup.Item>()
        items.add(Popup.Item(R.drawable.ic_edit, "편집", sc.url) { showShortcutDialog(sc, index) })
        if (index > 0) {
            items.add(Popup.Item(R.drawable.ic_back, "앞으로 옮기기") {
                val m = list.toMutableList()
                m.add(index - 1, m.removeAt(index))
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
            })
        }
        if (index < list.size - 1) {
            items.add(Popup.Item(R.drawable.ic_forward, "뒤로 옮기기") {
                val m = list.toMutableList()
                m.add(index + 1, m.removeAt(index))
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
            })
        }
        items.add(Popup.Item(R.drawable.ic_delete, "삭제", danger = true) {
            prefs.saveHomeShortcuts(list.filterIndexed { i, _ -> i != index })
            refreshHomeShortcuts()
        })
        Popup.menu(this, sc.name, items = items)
    }

    /** 추가(existing == null) 또는 편집 창. 주소에 https:// 가 없으면 붙여 준다. */
    private fun showShortcutDialog(existing: HomeShortcut?, index: Int) {
        val v = layoutInflater.inflate(R.layout.dialog_shortcut, null)
        val etName = v.findViewById<EditText>(R.id.etScName)
        val etUrl = v.findViewById<EditText>(R.id.etScUrl)
        val til = v.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilScUrl)
        if (existing != null) {
            etName.setText(existing.name)
            etUrl.setText(existing.url)
        }
        val builder = ThemedDialogBuilder(this)
            .setTitle(if (existing == null) "즐겨찾기 추가" else "즐겨찾기 편집")
            .setView(v)
            .setPositiveButton("저장", null)
            .setNegativeButton("취소", null)
        if (existing == null) builder.setNeutralButton("기본값으로", null)
        val dlg = builder.create()
        dlg.setOnShowListener {
            ThemeColors.skinDialog(dlg)
            dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var url = etUrl.text.toString().trim()
                if (url.isEmpty() || url.contains(' ')) {
                    til.error = "올바른 주소를 입력해 주세요"
                    return@setOnClickListener
                }
                if (!Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(url)) url = "https://$url"
                val host = Uri.parse(url).host?.removePrefix("www.")
                if (host.isNullOrBlank()) {
                    til.error = "올바른 주소를 입력해 주세요"
                    return@setOnClickListener
                }
                val name = etName.text.toString().trim().ifEmpty { host }
                val glyph = if (existing != null && existing.name == name) existing.glyph else ""
                val m = prefs.homeShortcuts().toMutableList()
                val sc = HomeShortcut(name, url, glyph)
                if (existing != null && index in m.indices) m[index] = sc else m.add(sc)
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
                dlg.dismiss()
            }
            if (existing == null) {
                dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    prefs.resetHomeShortcuts()
                    refreshHomeShortcuts()
                    dlg.dismiss()
                    toast("기본 즐겨찾기로 되돌렸어요")
                }
            }
        }
        dlg.show()
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    // 메뉴·설정·꾹 누르기 팝업이 떠 있으면 뒤로가기는 그 팝업만 닫는다 (웹페이지가 뒤로 가지 않게)
                    Popup.dismissTop() -> Unit
                    // 태블릿 AI 어시스턴트 팝업이 떠 있으면 그것만 닫는다 (키보드가 켜져 있으면 키보드만 접는다)
                    assistant?.handleBack() == true -> Unit
                    switcherSelecting -> exitSelectMode()
                    switcherOpen -> closeTabSwitcher()
                    findBar.visibility == View.VISIBLE -> closeFind()
                    mirrorActive -> if (mirrorOverlay?.closeSubPanel() != true) stopMirror()
                    customView != null -> hideCustomView()
                    navBack() -> Unit
                    tabs.size > 1 -> current?.let { closeTab(it) }
                    else -> {
                        // 더 이동할 기록이 없을 때: 한 번만 눌러서 앱이 꺼지지 않게, 2초 안에 한 번 더 눌러야 종료
                        val now = android.os.SystemClock.uptimeMillis()
                        if (now - lastExitBackAt < 2000L) {
                            // 종료(홈으로 나가기) 동작을 시스템에 넘기되, 앱이 살아 있는 채로 돌아올 수 있으니
                            // 바로 다시 켜 둔다. (꺼진 채로 두면 이후 뒤로가기가 전부 앱 종료로 처리된다)
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        } else {
                            lastExitBackAt = now
                            toast("한 번 더 누르면 앱이 종료돼요")
                        }
                    }
                }
            }
        })
    }

    /** 마지막으로 "종료하려고 뒤로가기"를 누른 시각 (두 번 눌러야 종료) */
    private var lastExitBackAt = 0L

    private fun updateUi() {
        val tab = current ?: return
        ui.post { scrollBars.sync() }
        val wv = tab.webView
        if (!urlBar.hasFocus()) {
            setUrlText(if (tab.isHome) "" else displayUrl(pageUrlOf(tab, wv)))
        }
        applyIncognitoUi(tab.incognito)
        updateSecureFlag()
        updateSecurityIcon(if (tab.isHome) null else pageUrlOf(tab, wv), tab.incognito)
        updateDesktopButton()
        // 홈 화면은 웹 기록의 한 항목이라 이전 페이지는 이미 내려가 있다 (영상·소리도 같이 멈춘다).
        if (tab.isHome) {
            tab.awaitCommit = false
            wv.visibility = View.INVISIBLE
        } else {
            wv.visibility = if (tab.awaitCommit) View.INVISIBLE else View.VISIBLE
            if (tab.paused) {
                tab.paused = false
                wv.onResume()
            }
            if (tab.stoppedByHome) {
                tab.stoppedByHome = false
                reloadTab(tab)
            }
        }
        if (tab.isHome || tab.awaitCommit) {
            val replay = tab.isHome && pendingHomeEnter
            if (replay) pendingHomeEnter = false
            if (homeView.visibility != View.VISIBLE || replay) {
                hideKeyboard()
                if (newTabAnimFor === tab && !switcherOpen && Motion.enabled(this)) {
                    newTabAnimFor = null
                    playNewTabEnter(homeView)
                } else {
                    homeView.animate().cancel()
                    Motion.cancel(homeView)
                    homeView.alpha = 1f
                    homeView.translationY = 0f
                    homeView.scaleX = 1f
                    homeView.scaleY = 1f
                }
                refreshHomeWidget()
                homeView.visibility = View.VISIBLE
                // 테마 새 탭인데 흐린 배경이 없으면(숨겨진 채 테마가 바뀐 경우 등) 화면이 배치된 뒤 다시 만든다
                if (themeSpec?.hasNtp == true && homeGlassBmp == null) homeView.post { refreshHomeGlass() }
                (homeContent as? ViewGroup)?.let { Motion.stagger(it, 0, 55, 330) }
            }
        } else if (homeView.visibility == View.VISIBLE && !switcherOpen && Motion.enabled(this)) {
            // 홈에서 새 페이지로 넘어갈 때: 홈이 뚝 사라지지 않고 페이지가 떠오르며 서로 바뀐다
            crossfadeHomeToPage(wv)
        } else {
            homeView.animate().cancel()
            homeView.visibility = View.GONE
        }
        showProgress(tab.progress)
        val canBack = canNavBack(tab)
        val canForward = canNavForward(tab)
        listOf(btnBack, tbBack).forEach {
            it.isEnabled = canBack
            it.alpha = if (canBack) 1f else 0.35f
        }
        listOf(btnForward, tbForward).forEach {
            it.isEnabled = canForward
            it.alpha = if (canForward) 1f else 0.35f
        }
        updateTabCount()
        applyHideBars()
        refreshPipParams()
    }

    private var loadingIcon = false

    /** 두 주소가 같은 문서인지: http/https 와 www., 끝 슬래시, #조각은 무시하고 주소·경로·쿼리를 비교한다 */
    private fun sameDoc(a: String?, b: String?): Boolean {
        if (a == null || b == null) return false
        if (a == b) return true
        return runCatching {
            val x = Uri.parse(a); val y = Uri.parse(b)
            fun host(u: Uri) = u.host.orEmpty().lowercase().removePrefix("www.")
            fun path(u: Uri) = (u.path ?: "").trimEnd('/')
            host(x).isNotEmpty() && host(x) == host(y) && path(x) == path(y) && x.query == y.query
        }.getOrDefault(false)
    }

    /** 뒤로 갈 때 '스스로 되돌려 보내는 페이지'를 건너뛰어 도착할 기록의 상대 위치 (없으면 0). */
    private fun backTarget(tab: BrowserTab): Int {
        val list = tab.webView.copyBackForwardList()
        var i = list.currentIndex - 1
        // 오류 화면(연결할 수 없어요 등)을 보는 중이면: 오류 화면은 실패한 주소와 같은 주소로 기록에 쌓여서,
        // 바로 앞 칸이 '방금 실패한 그 주소'다. 거기로 가면 다시 불러오다 또 실패해 제자리처럼 보이므로 건너뛴다.
        val err = tab.errorUrl
        if (err != null) {
            while (i >= 0 && sameDoc(list.getItemAtIndex(i).url, err)) i--
        }
        // 저장했다 되살린 오류 화면 항목(주소가 data:text/html... 로 바뀌어 빈 화면이 된다)도 건너뛴다
        while (i >= 0 && historyUrl(list.getItemAtIndex(i)).let { it != null && it.startsWith("data:") && it != HOME_URL }) i--
        // 차단 옵션을 끄면 예전에 기록해 둔 '튕기는 페이지'도 건너뛰지 않고 그냥 한 칸씩 간다
        if (prefs.blockBackRedirect) {
            while (i >= 0 && tab.redirectSources.contains(list.getItemAtIndex(i).url)) i--
        }
        return if (i >= 0) i - list.currentIndex else 0
    }

    private fun canGoBackSmart(tab: BrowserTab): Boolean = backTarget(tab) != 0

    /** 홈 항목을 불러온다 (새 탭 화면). 웹 기록에 한 칸으로 남는다. clear 면 다 불러온 뒤 기록을 비운다. */
    private fun loadHome(tab: BrowserTab, clear: Boolean = false) {
        tab.errorUrl = null
        tab.isHome = true
        assistant?.refreshChips()
        tab.awaitCommit = false
        tab.clearAtHome = clear
        tab.webView.loadDataWithBaseURL(HOME_URL, HOME_HTML, "text/html", "utf-8", HOME_URL)
        if (tab === current) {
            pageScrollBar.bind(null)
            updateUi()
        }
    }

    /**
     * 웹 기록 항목의 주소. 기록을 저장했다 되살린 탭은 새 탭(홈) 항목이 "data:text/html;...base64," 로 바뀌어 오므로
     * (제목이 없는 항목만) 다시 HOME_URL 로 돌려 홈으로 알아보게 한다. 오류 화면 항목은 제목이 있어 구분된다.
     */
    private fun historyUrl(item: android.webkit.WebHistoryItem?): String? {
        val u = item?.url ?: return null
        if (u == RESTORED_DATA_URL) {
            val t = item.title
            if (t.isNullOrBlank() || t == u || t == HOME_URL || t == "새 탭") return HOME_URL
        }
        return u
    }

    /** 기록 이동으로 도착할 항목(target)이 홈인지에 맞춰, 홈 화면 덮개를 바로 켜거나 끈다 */
    private fun applyHomeFor(tab: BrowserTab, target: String?) {
        val toHome = target == HOME_URL
        if (toHome == tab.isHome) return
        tab.isHome = toHome
        assistant?.refreshChips()
        if (!toHome) {
            // 홈에서 페이지로 돌아가는 중: 새 페이지의 첫 화면이 그려질 때까지 홈을 보여 준다
            tab.awaitCommit = true
            ui.postDelayed({
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                }
            }, 12000)
        }
        if (tab === current) {
            pageScrollBar.bind(if (toHome) null else tab.webView)
            updateUi()
        }
    }

    /** 뒤로가기. 새 탭(홈) 화면도 웹 기록의 한 칸이라서, 페이지 → 뒤로 → 홈 → 앞으로 → 페이지 로 오갈 수 있다. */
    private fun navBack(): Boolean {
        val c = current ?: return false
        if (!canGoBackSmart(c)) return false
        goBackSmart(c)
        return true
    }

    /** 앞으로 가기 (홈 항목 포함) */
    private fun navForward(): Boolean {
        val c = current ?: return false
        val wv = c.webView
        if (!wv.canGoForward()) return false
        val list = wv.copyBackForwardList()
        val target = historyUrl(list.getItemAtIndex(list.currentIndex + 1))
        wv.goForward()
        applyHomeFor(c, target)
        return true
    }

    private fun canNavBack(tab: BrowserTab): Boolean = canGoBackSmart(tab)

    private fun canNavForward(tab: BrowserTab): Boolean = tab.webView.canGoForward()

    /** 같은 페이지인지 비교하는 열쇠: 추적/세션용 주소 꼬리표는 무시한다 (구글 검색은 검색어만 본다). */
    private fun historyKey(url: String): String {
        val u = runCatching { Uri.parse(url) }.getOrNull() ?: return url
        val host = (u.host ?: return url.substringBefore('#').trimEnd('/')).lowercase().removePrefix("www.")
        val path = (u.path ?: "").trimEnd('/')
        if (host.startsWith("google.") || host.contains(".google.")) {
            if (path == "/search") return "google-search:" + (u.getQueryParameter("q") ?: "")
            if (path == "/webhp" || path.isEmpty()) return "google-home"
        }
        val noise = setOf(
            "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
            "fbclid", "gclid", "sxsrf", "ved", "ei", "iflsig", "sca_esv", "source",
            "uact", "oq", "gs_lp", "sclient", "biw", "bih", "dpr", "fbs", "si", "sa"
        )
        val query = runCatching { u.queryParameterNames }.getOrNull().orEmpty()
            .filter { it !in noise }.sorted()
            .joinToString("&") { "$it=${u.getQueryParameter(it).orEmpty()}" }
        return "$host$path" + if (query.isEmpty()) "" else "?$query"
    }

    /** 기록 목록에 보여줄 짧은 주소: 사이트 + 경로만, 검색은 검색어만, 너무 길면 …로 줄인다. */
    private fun shortUrl(url: String): String {
        val u = runCatching { Uri.parse(url) }.getOrNull() ?: return url.take(48)
        val host = u.host?.removePrefix("www.") ?: return url.removePrefix("https://").removePrefix("http://").take(48)
        val path = (u.path ?: "").trimEnd('/')
        val q = u.getQueryParameter("q") ?: u.getQueryParameter("query") ?: u.getQueryParameter("search_query")
        val tail = when {
            !q.isNullOrBlank() -> "  ·  검색: $q"
            u.query.isNullOrEmpty() -> ""
            else -> "?…"
        }
        val full = host + path + tail
        return if (full.length <= 48) full else full.take(47) + "…"
    }

    /** 뒤로/앞으로 버튼을 꾹 눌렀을 때: 이 탭의 이동 기록을 목록으로 보여주고, 고르면 그 페이지로 이동한다. */
    private fun showNavHistory(forward: Boolean, anchor: View? = null) {
        val tab = current ?: return
        val wv = tab.webView
        val list = try { wv.copyBackForwardList() } catch (e: Exception) { return }
        val cur = list.currentIndex
        // 뒤로: 가까운(최근) 기록부터 / 앞으로: 가까운 기록부터
        val indices = if (forward) (cur + 1 until list.size).toList() else (cur - 1 downTo 0).toList()
        if (indices.isEmpty()) {
            toast(if (forward) "앞으로 갈 기록이 없어요" else "뒤로 갈 기록이 없어요")
            return
        }
        // 중복 정리: 지금 보는 페이지와 같거나, 앞에서 이미 나온 페이지는 건너뛴다 (가장 가까운 것만 남김)
        val seen = HashSet<String>()
        historyUrl(list.getItemAtIndex(cur))?.let { seen.add(historyKey(it)) }
        val items = ArrayList<Popup.Item>()
        for (i in indices) {
            if (items.size >= 30) break
            val entry = list.getItemAtIndex(i) ?: continue
            val url = historyUrl(entry) ?: continue
            if (!seen.add(historyKey(url))) continue
            val isHomeEntry = url == HOME_URL || url.startsWith("evergreen://")
            val host = runCatching { Uri.parse(url).host }.getOrNull()
            val label = if (isHomeEntry) (if (tab.incognito) "시크릿 탭" else "새 탭")
                else entry.title?.takeIf { it.isNotBlank() } ?: host ?: url
            items.add(
                Popup.Item(
                    icon = if (isHomeEntry) R.drawable.ic_leaf_pixel else R.drawable.ic_globe,
                    label = label,
                    sub = if (isHomeEntry) null else shortUrl(url),
                    compactSub = true,
                    keepIconColor = isHomeEntry,
                    iconUrl = if (isHomeEntry || tab.incognito || !(url.startsWith("http://") || url.startsWith("https://"))) null else url
                ) {
                    val offset = i - wv.copyBackForwardList().currentIndex
                    if (offset != 0) wv.goBackOrForward(offset)
                    applyHomeFor(tab, url)
                    updateUi()
                }
            )
        }
        if (items.isEmpty()) {
            toast(if (forward) "앞으로 갈 기록이 없어요" else "뒤로 갈 기록이 없어요")
            return
        }
        val title = if (forward) "앞으로 가기 기록" else "뒤로 가기 기록"
        val icon = if (forward) R.drawable.ic_forward else R.drawable.ic_back
        val tablet = expanded
        if (tablet && anchor != null && anchor.isShown) {
            // 태블릿: 누른 뒤로/앞으로 버튼 바로 아래에 붙여서 띄운다
            Popup.menuAnchored(
                this, anchor,
                title = title,
                subtitle = "누르면 그 페이지로 이동해요",
                headerIcon = icon,
                items = items
            )
        } else {
            Popup.menu(
                this,
                title = title,
                subtitle = "누르면 그 페이지로 이동해요",
                headerIcon = icon,
                items = items
            )
        }
    }

    private fun goBackSmart(tab: BrowserTab) {
        val offset = backTarget(tab)
        if (offset == 0) return
        tab.backAt = android.os.SystemClock.uptimeMillis()
        tab.backTouchMark = lastTouchAt
        val list = tab.webView.copyBackForwardList()
        val target = historyUrl(list.getItemAtIndex(list.currentIndex + offset))
        tab.backTargetUrl = target
        tab.backLeftUrl = list.currentItem?.url
        tab.webView.goBackOrForward(offset)
        applyHomeFor(tab, target)
    }

    private fun hasPage(tab: BrowserTab): Boolean =
        historyUrl(tab.webView.copyBackForwardList().currentItem)?.let { it != "about:blank" && it != HOME_URL } == true

    /** 로딩 바를 부드럽게 채우고, 끝나면 서서히 사라지게. 로딩 중에는 새로고침 버튼이 X(중지)로 바뀐다. */
    private val OWN_BAR_JS = """
        (function(){try{
          var vw=innerWidth||document.documentElement.clientWidth, found=false;
          var q='[role=progressbar],#nprogress,.nprogress,yt-page-navigation-progress,[id*=progress i],[class*=progress i],[class*=loading-bar i],[class*=loadingbar i],[class*=topbar i],[class*=top-bar-loading i],[class*=page-loader i],[class*=pageloader i]';
          var els=document.querySelectorAll(q);
          for(var i=0;i<els.length&&i<200&&!found;i++){
            var e=els[i]; var cs=getComputedStyle(e);
            if(cs.display==='none'||cs.visibility==='hidden'||parseFloat(cs.opacity)===0) continue;
            var r=e.getBoundingClientRect();
            // 맨 위에 붙은 가는 막대 (높이 8px 이하, 폭이 조금이라도 있음)
            if(r.height>0&&r.height<=8&&r.width>=8&&r.top>=-2&&r.top<=8&&(cs.position==='fixed'||cs.position==='absolute'||cs.position==='sticky'||r.width>=vw*0.2)){found=true;}
            // 막대를 감싼 바깥 틀이 얇고, 그 안의 자식이 막대인 경우 (NProgress 의 .bar 등)
            if(!found&&r.top<=8&&r.height>0&&r.height<=8){found=true;}
          }
          if(found&&window.EvMedia&&EvMedia.ownBar)EvMedia.ownBar(true);
        }catch(e){}})();
    """.trimIndent()

    // ── 웹사이트 로딩 바 ──
    // 웹뷰가 알려 주는 진행률은 10 → 70 → 100 처럼 뚝뚝 끊겨 오므로, 그대로 그리면 바가 툭툭 튄다.
    // 그래서 (1) 바 안의 스프링 하나가 목표가 바뀌어도 속도를 이어 가며 부드럽게 따라가고 (2) 새 소식이 없어도 조금씩 기어가며
    // (3) 끝나면 끝까지 쭉 채운 뒤 사라진다. 채워진 부분 위로 빛이 흐른다(LoadBarView).
    // 바의 max 는 1000 (0.1% 단위)이다.
    private var progressTarget = 0
    private val progressTrickle = object : Runnable {
        override fun run() {
            if (progressBar.visibility != View.VISIBLE) return
            val cap = minOf(900, progressTarget + 150)
            val goal = progressBar.goal
            if (goal < cap) {
                // 목표를 조금씩 앞으로 민다. 약한 스프링이라 속도가 끊기지 않고 천천히 기어간다
                progressBar.glideTo(minOf(cap, goal + maxOf(4, (cap - goal) / 10)), 40f)
            }
            progressBar.postDelayed(this, 300L)
        }
    }

    private fun stopProgressAnim() {
        progressBar.halt()
        progressBar.removeCallbacks(progressTrickle)
    }

    // ── 삼성 테마 로딩 바: 탭 카드 바로 아래 ──
    // 로딩 계산은 기존 progressBar 가 그대로 맡고, 삼성 테마 + 상단 탭 줄이 보일 때만 그 바는 그리지 않고
    // 선택된 탭 카드의 아랫면에 놓은 같은 모양의 바(stripLoadBar)가 대신 그린다.
    private var stripLoadBar: LoadBarView? = null

    private fun syncStripLoadBar() {
        val cur = current
        val chip = if (cur != null) stripChips[cur]?.view else null
        val frame = tabStripScroll.parent as? ViewGroup
        val want = themeSpec?.samsungTabs == true && tabStripBar.visibility == View.VISIBLE && tabStripBar.isShown &&
            chip != null && chip.parent != null && frame != null
        if (!want) {
            if (progressBar.mirror != null) {
                progressBar.attachMirror(null)
                stripLoadBar?.visibility = View.GONE
            }
            return
        }
        frame!!; chip!!
        val bar = stripLoadBar ?: LoadBarView(this).apply {
            isIndeterminate = false
            max = 1000
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.TRANSPARENT)
            visibility = View.GONE
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            pivotX = 0f
            translationZ = dp(3).toFloat()
            stripLoadBar = this
        }
        if (bar.parent == null) frame.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2), android.view.Gravity.TOP))
        if (bar.progressTintList !== progressBar.progressTintList) bar.progressTintList = progressBar.progressTintList
        if (progressBar.mirror !== bar) progressBar.attachMirror(bar)
        if (progressBar.visibility != View.VISIBLE) return
        // 선택된 탭 카드의 frame 안 위치 (탭 줄이 가로로 스크롤된 만큼 뺀다)
        var x = 0f; var y = 0f
        var v: View = chip
        while (v !== frame) {
            val pv = v.parent as? View ?: return
            x += v.left + v.translationX - pv.scrollX
            y += v.top + v.translationY - pv.scrollY
            v = pv
        }
        val inset = dp(8).toFloat()
        val w = (chip.width - 2 * inset).coerceAtLeast(1f)
        val fw = frame.width.toFloat().coerceAtLeast(1f)
        val sx = w / fw
        val tx = x + inset
        val ty = y + chip.height - bar.layoutParams.height
        if (bar.scaleX != sx) bar.scaleX = sx
        if (bar.translationX != tx) bar.translationX = tx
        if (bar.translationY != ty) bar.translationY = ty
        // 탭 카드가 스크롤로 탭 줄 밖으로 반쯤 나가 있어도 바가 옆 버튼 위로 번지지 않게, 보이는 구간만 남긴다
        val vl = tabStripScroll.left.toFloat(); val vr = tabStripScroll.right.toFloat()
        val cl = ((vl - tx) / sx).toInt().coerceAtLeast(0)
        val cr = ((vr - tx) / sx).toInt().coerceAtMost(frame.width)
        bar.clipBounds = if (cr > cl) Rect(cl, 0, cr, bar.layoutParams.height) else Rect(0, 0, 0, 0)
    }

    private fun showProgress(p: Int) {
        if (isInPictureInPictureModeCompat() && customView == null) return   // PiP 에서는 로딩 바도 숨긴 채로 둔다
        val loading = p in 1..99
        if (current?.ownProgressBar == true) {
            // 페이지가 자기 로딩 바를 가지고 있으면 브라우저 로딩 바는 안 보인다 (새로고침↔중지 아이콘은 그대로 바뀐다)
            stopProgressAnim()
            progressBar.animate().cancel()
            progressBar.visibility = View.GONE
        } else if (loading) {
            progressBar.animate().cancel()
            progressBar.alpha = 1f
            if (progressBar.visibility != View.VISIBLE) {
                stopProgressAnim()
                progressBar.progress = 0
                progressBar.visibility = View.VISIBLE
            }
            // 새 주소로 다시 시작(리다이렉트 등)하면 진행률이 뒤로 가므로 처음부터 다시 채운다
            val t = maxOf(p * 10, 60)
            if (t < progressBar.progress - 200) {
                stopProgressAnim()
                progressBar.progress = 0
            }
            progressTarget = t
            if (t > progressBar.goal) progressBar.glideTo(t, 90f)
            progressBar.removeCallbacks(progressTrickle)
            progressBar.postDelayed(progressTrickle, 300L)
        } else if (progressBar.visibility == View.VISIBLE) {
            progressBar.removeCallbacks(progressTrickle)
            // 끝까지 빠르게 달려 채운 뒤(스프링이 이어받아 쭉 나간다), 잠깐 머물렀다가 사라진다
            progressBar.glideTo(1000, 320f)
            progressBar.animate().alpha(0f).setStartDelay(300).setDuration(280).withEndAction {
                progressBar.visibility = View.GONE
                progressBar.progress = 0
                progressBar.animate().setStartDelay(0)
            }.start()
        }
        if (loading != loadingIcon) {
            loadingIcon = loading
            // 아이콘을 휙 바꾸지 않고 돌면서 바뀐다: 로딩 시작 = 새로고침이 돌며 사라지고 X 가 돌아 들어옴,
            // 로딩 끝 = X 가 사라지고 새로고침 화살표가 한 바퀴 가까이 돌며 자리를 잡는다
            swapRefreshIcon(btnRefresh, loading)
            // 주소창 밖(왼쪽/오른쪽 묶음, 폰 하단바)에 옮겨 둔 새로고침 버튼도 같이 바꾼다
            swapRefreshIcon(topBarExtraViews["refresh"], loading)
            swapRefreshIcon(bottomExtraViews["refresh"], loading)
        }
    }

    private var homeFading = false

    /**
     * 홈 화면 → 웹페이지 전환. 홈은 살짝 커지며 투명해지고, 페이지는 투명에서 떠오르며 겹쳐 보인다.
     * 도는 중에 updateUi 가 또 불려도 다시 시작하지 않고, 도중에 홈으로 돌아가거나 새 탭 홈이 뜨면 끝 동작이 홈을 숨기지 않는다.
     */
    private fun crossfadeHomeToPage(page: View) {
        if (homeFading) return
        homeFading = true
        homeView.animate().cancel()
        // 투명도만 멈춘다: selectTab 이 시작한 확대(SCALE) 스프링까지 취소하면 웹 화면이 0.97배로 작아진 채 남는다
        Motion.stop(page, DynamicAnimation.ALPHA)
        page.alpha = 0f
        Motion.spring(page, DynamicAnimation.ALPHA, 1f, 240f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        homeView.animate().alpha(0f).scaleX(1.025f).scaleY(1.025f).setDuration(220)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.4f))
            .withEndAction {
                homeFading = false
                val t = current
                if (t != null && !t.isHome && !t.awaitCommit) homeView.visibility = View.GONE
                homeView.alpha = 1f
                homeView.scaleX = 1f
                homeView.scaleY = 1f
            }.start()
    }

    private val refreshSwapGen = java.util.WeakHashMap<View, Int>()

    /** 새로고침 ↔ 중지(X) 아이콘을 돌리며 바꾼다. 버튼 크기(스프링 눌림 효과)는 건드리지 않고 회전·투명도만 쓴다. */
    private fun swapRefreshIcon(v: ImageButton?, loading: Boolean) {
        v ?: return
        val res = if (loading) R.drawable.ic_close else R.drawable.ic_refresh
        val gen = (refreshSwapGen[v] ?: 0) + 1
        refreshSwapGen[v] = gen
        Motion.stop(v, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION)
        v.animate().cancel()
        if (!v.isAttachedToWindow || !v.isShown) {
            v.rotation = 0f; v.alpha = 1f
            v.setImageResource(res)
            return
        }
        val dir = if (loading) 1f else -1f
        v.animate().rotation(90f * dir).alpha(0f).setDuration(110L)
            .setInterpolator(android.view.animation.AccelerateInterpolator())
            .withEndAction {
                if (refreshSwapGen[v] != gen) return@withEndAction   // 그 사이 다시 바뀌었으면 새 쪽이 마무리한다
                v.setImageResource(res)
                v.rotation = if (loading) -90f else -270f
                v.animate().rotation(0f).alpha(1f).setDuration(if (loading) 220L else 340L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(if (loading) 1.3f else 1.1f))
                    .start()
            }.start()
    }

    /** 버튼을 누르면 쏙 들어갔다가 탄성 있게 튀어 돌아오는 효과 (스프링) */
    private fun addPressAnim(v: View, barKind: String? = null) {
        // 바의 "player" 는 내장 플레이어를 여는 버튼 (재생/일시정지 버튼이 아님) → 전용 동작(openplayer)
        val kind = if (barKind == "player") "openplayer" else barKind
        if (kind != null) Motion.barButton(v, kind) else Motion.pressable(v, 0.86f)
    }

    private fun hideCustomView() {
        val view = customView ?: return
        fullscreenContainer.resetTransform()
        fullscreenContainer.removeView(view)
        fullscreenContainer.keepScreenOn = false
        fullscreenContainer.visibility = View.GONE
        browserUi.visibility = View.VISIBLE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        setFullscreenBackdrop(false)
        setSystemBarsVisible(true)
        refreshPipParams()
    }

    /**
     * 동영상 전체화면 동안 창 뒤 배경을 검정으로 바꾼다. 상태표시줄/노치/내비게이션 바 자리는 인셋 여백으로 남는데,
     * 그 아래로 앱 면 색(흰색)의 루트 배경이 비쳐 상단이 하얗게 보이던 문제를 막는다.
     */
    private fun setFullscreenBackdrop(on: Boolean) {
        val surface = getColor(R.color.ev_surface)
        try {
            window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(if (on) android.graphics.Color.BLACK else surface))
        } catch (_: Throwable) {}
        statusBand?.let { b ->
            bandAnim?.cancel()
            if (on) {
                b.base = android.graphics.Color.BLACK
                b.band = android.graphics.Color.BLACK
            } else {
                b.base = surface
                b.band = surface
            }
            b.invalidateSelf()
        }
        if (!on) updateStatusBarColor()
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
            // 전체화면 영상이 끝나면, 상/하단바 숨기기가 켜져 있을 때 상태표시줄도 다시 숨김
            statusBarHiddenByHideBars = false
            if (customView == null && barsHiddenNow) applyStatusBarForHideBars(true)
            if (customView == null && scrollBars.fraction > 0.02f) applyStatusBarForScroll(true)
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ───────────────────────── 메뉴 ─────────────────────────

    /**
     * 메뉴. 폰에서는 아래에서 올라오는 시트, 태블릿(최소 폭 600dp 이상)에서는 누른 버튼 바로 아래에 뜨는 팝업.
     * @param anchor 눌린 메뉴 버튼 (태블릿 팝업을 붙일 기준)
     */
    private var menuAnchorRight = -1
    /** 메뉴창의 목록 영역 높이(px) — [0] 바텀시트, [1] 태블릿 팝업. 설정창을 메뉴창과 같은 크기로 띄우는 데 쓴다 */
    private val menuScrollH = IntArray(2)
    /** 설정 창을 다시 띄울 때 열어 둘 카테고리 (테마 색 스위치처럼 창 전체 색이 바뀌는 설정에서 같은 자리로 돌아오게) */
    private var settingsReopenBig: String? = null
    private var menuAnchorBottom = -1
    private var menuAnchorWinRight = -1
    private var menuAnchorWinBottom = -1
    /** 태블릿 메뉴를 띄운 버튼 (목록 팝업의 ← 로 돌아올 때 메뉴를 같은 자리에 다시 띄우려고) */
    private var menuAnchorRef: java.lang.ref.WeakReference<View>? = null
    // 태블릿 메뉴·설정 팝업 오른쪽(화면 가장자리까지)의 좁은 빈 영역. 여기를 눌러도 팝업이 닫히거나 뒤의 화면이 눌리지 않게 막는다 (화면 좌표)
    private var menuDeadZone: Rect? = null
    private var menuDeadZonePopup: java.lang.ref.WeakReference<PopupWindow>? = null
    private var swallowingDeadZoneTouch = false

    /** 목록 팝업(다운로드 / 방문 기록 / 북마크)을 여는 intent. 태블릿이면 메뉴가 떠 있던 자리를 같이 넘긴다. */
    private fun listIntent(cls: Class<*>): Intent = Intent(this, cls).apply {
        ListUi.reopenMenu = false
        // 시트 뒤에서 흐려질 화면 (북마크·방문 기록·다운로드 시트가 이 화면을 흐리게 한다)
        ListUi.behindActivity = java.lang.ref.WeakReference(this@MainActivity)
        // 태블릿: 목록이 뒤 화면이 보이는 팝업으로 뜨므로, 이 창이 멈추더라도 웹페이지는 멈추지 않게 표시해 둔다
        listPopupOpen = resources.configuration.smallestScreenWidthDp >= 600
        if (expanded && menuAnchorRight > 0 && menuAnchorBottom > 0) {
            putExtra(ListUi.EXTRA_ANCHOR_RIGHT, menuAnchorRight)
            putExtra(ListUi.EXTRA_ANCHOR_BOTTOM, menuAnchorBottom)
            if (menuAnchorWinRight > 0 && menuAnchorWinBottom > 0) {
                putExtra(ListUi.EXTRA_ANCHOR_WIN_RIGHT, menuAnchorWinRight)
                putExtra(ListUi.EXTRA_ANCHOR_WIN_BOTTOM, menuAnchorWinBottom)
            }
        }
    }

    private var menuReopenAnchor: java.lang.ref.WeakReference<View>? = null

    /** 북마크·방문 기록·다운로드 화면에서 뒤로 나오면 그 화면을 열었던 메뉴를 다시 연다. */
    private fun reopenMenuAfterList() {
        // 태블릿: 목록 팝업의 ←/뒤로가기가 ListUi.reopenMenu 를 켜 두면 onResume 이 메뉴를 다시 띄운다
        // (바깥을 눌러 닫은 경우는 일부러 메뉴 없이 닫힌다). 여기서 또 열면 메뉴가 두 번 뜬다.
        if (expanded || suppressMenuReopen) return
        // 폰: ← / 뒤로가기로 나왔을 때만 메뉴로 돌아간다. 시트를 아래로 내리거나 바깥을 눌러 닫으면 메뉴를 다시 열지 않는다.
        if (!ListUi.reopenMenu) return
        ListUi.reopenMenu = false
        ui.post {
            if (isFinishing || isDestroyed) return@post
            val a = menuReopenAnchor?.get()?.takeIf { it.isAttachedToWindow }
                ?: (if (btnFloatMenu.isShown) btnFloatMenu else if (tbMenu.isShown) tbMenu else btnMenu)
            showMenu(a)
        }
    }

    /**
     * 메뉴 맨 위 미디어 플레이어. 웹에서 재생 중이거나 방금 멈춘 미디어가 있을 때만 보이고,
     * 재생/일시정지 · 10초 이동 · 위치 이동을 한다. (조작은 페이지 스크립트로 보낸다)
     */
    private fun bindMediaCard(view: View, dismiss: () -> Unit) {
        val card = view.findViewById<View>(R.id.mediaCard)
        val seek = view.findViewById<SeekBar>(R.id.mediaSeek)
        // 끌면 막대가 부드럽게 굵어지고 손잡이가 톡 커진다
        seek.progressDrawable = SmoothSeekTrack(
            this,
            themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill),
            themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)
        )
        seek.thumb = SmoothSeekThumb(
            this,
            themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent),
            themeColor(com.google.android.material.R.attr.colorOutline, R.color.ev_muted)
        )
        val posText = view.findViewById<TextView>(R.id.mediaPos)
        val durText = view.findViewById<TextView>(R.id.mediaDur)
        val playBtn = view.findViewById<ImageButton>(R.id.mediaPlay)

        fun fresh(p: MediaProg, now: Long) =
            if (p.playing) now - p.at < 5000L else now - p.at < 10 * 60_000L

        /** 떠 있는 모든 창 (이 창이 먼저). 미디어 카드는 다른 창에서 재생 중인 것도 같이 보여 준다 */
        fun wins(): List<MainActivity> =
            listOf(this) + instances.filter { it !== this && !it.isFinishing && !it.isDestroyed }
        fun ownerOf(t: BrowserTab): MainActivity? = wins().firstOrNull { t in it.tabs }
        /** 이 창의 탭 → 다른 창의 탭 순서 (각 창에서는 지금 보는 탭이 먼저) */
        fun orderedTabs(): List<BrowserTab> =
            wins().flatMap { w -> listOfNotNull(w.current) + w.tabs.filter { it !== w.current } }

        fun pickMedia(): Pair<BrowserTab, String>? {
            val now = android.os.SystemClock.uptimeMillis()
            val order = orderedTabs()
            // 1) 재생 중인 것 (지금 보는 탭 먼저)
            for (t in order) {
                if (t.liveWebView == null || t.mediaFrames.isEmpty()) continue
                val e = t.mediaProg.entries
                    .filter { it.key in t.mediaFrames && it.key !in t.mediaDismissed && it.value.playing && fresh(it.value, now) }
                    .maxByOrNull { it.value.at }
                if (e != null) return t to e.key
                // 아직 진행 보고가 안 왔으면 재생 중이라는 사실만으로 먼저 보여 준다
                if (t.mediaProg.keys.none { it in t.mediaFrames }) {
                    val k = t.mediaFrames.keys.firstOrNull { it !in t.mediaDismissed }
                    if (k != null) return t to k
                }
            }
            // 2) 방금 멈춘 것
            for (t in order) {
                if (t.liveWebView == null) continue
                val e = t.mediaProg.entries.filter { it.key !in t.mediaDismissed && fresh(it.value, now) }.maxByOrNull { it.value.at }
                if (e != null) return t to e.key
            }
            return null
        }

        /** 넘겨 볼 수 있는 미디어 전체: 탭 순서 → 프레임 순서로 고정 (재생 상태가 바뀌어도 순서는 그대로) */
        fun candidates(): List<Pair<BrowserTab, String>> {
            val now = android.os.SystemClock.uptimeMillis()
            val out = ArrayList<Pair<BrowserTab, String>>()
            for (t in orderedTabs()) {
                if (t.liveWebView == null) continue
                for (fid in t.mediaFrames.keys.sorted()) {
                    if (fid in t.mediaDismissed) continue
                    val p = t.mediaProg[fid]
                    if (p == null || fresh(p, now)) out.add(t to fid)
                }
            }
            return out
        }

        var sel = pickMedia() ?: return
        val motionOn = Motion.enabled(this)
        card.visibility = View.VISIBLE
        // 카드가 아래에서 살짝 떠오르며 나타난다 (스프링)
        Motion.enter(card, 60, 14f)
        val ctl = view.findViewById<ViewGroup>(R.id.mediaControls)
        if (motionOn) {
            // 조작 버튼이 카드보다 살짝 늦게, 가운데부터 통통 튀며 나타난다
            // 칸 순서: 0 이전, 1 뒤로, 2 재생, 3 앞으로, 4 다음 → 재생이 먼저, 바깥쪽 버튼이 나중
            for ((i, c) in listOf(2, 1, 3, 0, 4).map { ctl.getChildAt(it) }.withIndex()) {
                c.scaleX = 0.5f; c.scaleY = 0.5f; c.alpha = 0f
                c.postDelayed({
                    Motion.spring(c, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 400f, 1f)
                    Motion.spring(c, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 420f, 0.45f)
                    Motion.spring(c, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 420f, 0.45f)
                }, 150L + i * 45L)
            }
        }
        var dragging = false
        var curDur = -1.0
        var lastPlaying: Boolean? = null
        var seekAnim: android.animation.ObjectAnimator? = null

        // 재생↔일시정지 아이콘: 다른 내장 플레이어와 같은 그림(삼각형 ↔ 두 막대)이 매끄럽게 모양을 바꾼다.
        // (예전에는 이미지를 통째로 갈아 끼운 뒤 버튼을 비틀어 튕겨서 어색했다)
        val playMorph = MorphIconDrawable.install(playBtn, "player")
        fun setPlayIcon(playing: Boolean) {
            playBtn.contentDescription = if (playing) "일시정지" else "재생"
            val prev = lastPlaying
            lastPlaying = playing
            val animate = prev != null && prev != playing && motionOn && playBtn.isShown
            if (playMorph != null) playMorph.settle(if (playing) 1f else 0f, animate)
            else playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        }

        /** −10/+10 을 누르면 가는 방향으로 살짝 밀렸다가 제자리로 돌아온다 */
        fun nudge(v: View, dir: Int) {
            if (!motionOn) return
            v.translationX = dir * dp(7).toFloat()
            Motion.spring(v, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.45f)
        }

        fun fmt(sec: Double): String {
            if (sec.isNaN() || sec < 0) return "--:--"
            val s = sec.toInt()
            val h = s / 3600
            val m = (s % 3600) / 60
            val ss = s % 60
            return if (h > 0) String.format("%d:%02d:%02d", h, m, ss) else String.format("%d:%02d", m, ss)
        }

        /**
         * 재생 위치 막대: 페이지가 1초마다 알려 주는 위치를 기다리지 않고, 마지막 보고에서 흐른 시간만큼
         * 화면 프레임마다 직접 계산해서 그린다(외삽). 그래서 지연·끊김 없이 실제 재생과 함께 움직인다.
         * 위치를 크게 옮긴 경우(막대 이동, ±10초)만 짧게 감속하며 따라간다.
         */
        val SM = 10000
        fun estPos(): Double {
            val p = sel.first.mediaProg[sel.second] ?: return 0.0
            var x = p.pos
            if (p.playing) x += (android.os.SystemClock.uptimeMillis() - p.at) / 1000.0
            if (p.dur > 0) x = x.coerceAtMost(p.dur)
            return x.coerceAtLeast(0.0)
        }
        fun progFor(x: Double): Int = if (curDur > 0) (x / curDur * SM).toInt().coerceIn(0, SM) else 0
        var lastShownSec = -1
        fun paintSeek() {
            if (dragging || seekAnim?.isRunning == true) return
            val x = estPos()
            seek.progress = progFor(x)
            val sec = x.toInt()
            if (sec != lastShownSec) { lastShownSec = sec; posText.text = fmt(x) }
        }
        var frameOn = false
        val frame = object : Runnable {
            override fun run() {
                if (!view.isAttachedToWindow || card.visibility != View.VISIBLE) { frameOn = false; return }
                // 메뉴가 뜨는 동안에는 매 프레임 다시 그리지 않는다 (등장 애니메이션과 겹쳐 끊기던 부분)
                if (android.os.SystemClock.uptimeMillis() < menuQuietUntil) { view.postDelayed(this, 60); return }
                paintSeek()
                if (sel.first.mediaProg[sel.second]?.playing == true) view.postOnAnimation(this) else frameOn = false
            }
        }
        fun kickFrame() {
            if (frameOn || !view.isAttachedToWindow) return
            frameOn = true
            view.postOnAnimation(frame)
        }
        fun moveSeek(target: Int, first: Boolean) {
            val cur = seek.progress
            if (first || !motionOn || cur == target) {
                seekAnim?.cancel()
                seek.progress = target
                return
            }
            if (kotlin.math.abs(target - cur) <= SM / 40) return   // 작은 차이는 프레임 갱신이 알아서 맞춘다
            seekAnim?.cancel()
            seekAnim = android.animation.ObjectAnimator.ofInt(seek, "progress", cur, target).apply {
                duration = 200L
                interpolator = android.view.animation.DecelerateInterpolator(1.8f)
                start()
            }
        }
        var firstRender = true

        fun sendTo(target: Pair<BrowserTab, String>, a: String, v: Double = 0.0) {
            val (t, f) = target
            t.liveWebView?.evaluateJavascript(
                "window.postMessage({__ev:'cmd',f:${JSONObject.quote(f)},a:'$a',v:$v},'*');", null
            )
        }
        fun send(a: String, v: Double = 0.0) = sendTo(sel, a, v)

        val swipeCard = card as SwipeCardLayout
        var goTo: (Int) -> Unit = {}
        val dotsRow = view.findViewById<LinearLayout>(R.id.mediaDots)
        val dotViews = ArrayList<View>()
        var dotIndex = -1
        val dotSmall = (6 * resources.displayMetrics.density).toInt()
        val dotBig = (18 * resources.displayMetrics.density).toInt()
        val primary = themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)

        fun sizeDot(v: View, w: Int) {
            v.layoutParams = (v.layoutParams as LinearLayout.LayoutParams).also { it.width = w }
        }

        /** 페이지 점: 현재 것은 길쭉한 알약 모양, 나머지는 작은 점. 바뀔 때 늘어나고 줄어든다 */
        fun updateDots(count: Int, index: Int, onPick: (Int) -> Unit) {
            if (count <= 1) {
                dotsRow.visibility = View.GONE
                dotViews.clear(); dotsRow.removeAllViews(); dotIndex = -1
                return
            }
            dotsRow.visibility = View.VISIBLE
            if (dotViews.size != count) {
                dotsRow.removeAllViews(); dotViews.clear()
                for (i in 0 until count) {
                    val d = View(this)
                    d.background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dotSmall / 2f
                        setColor(primary)
                    }
                    val lp = LinearLayout.LayoutParams(dotSmall, dotSmall)
                    lp.marginStart = dotSmall / 2; lp.marginEnd = dotSmall / 2
                    d.layoutParams = lp
                    d.alpha = 0.3f
                    d.setOnClickListener { onPick(i) }
                    dotsRow.addView(d); dotViews.add(d)
                }
                dotIndex = -1
            }
            if (index == dotIndex) return
            val old = dotIndex
            dotIndex = index
            for ((i, d) in dotViews.withIndex()) {
                val on = i == index
                val toW = if (on) dotBig else dotSmall
                val toA = if (on) 1f else 0.3f
                if (!motionOn || old < 0) { sizeDot(d, toW); d.alpha = toA; continue }
                if (i != index && i != old) continue
                val fromW = d.layoutParams.width
                android.animation.ValueAnimator.ofInt(fromW, toW).apply {
                    duration = 240
                    interpolator = android.view.animation.DecelerateInterpolator(1.5f)
                    addUpdateListener { sizeDot(d, it.animatedValue as Int) }
                    start()
                }
                d.animate().alpha(toA).setDuration(240).start()
            }
        }

        val iconView = view.findViewById<View>(R.id.mediaIconBox)
        val iconImg = view.findViewById<ImageView>(R.id.mediaIcon)
        val badgeImg = view.findViewById<ImageView>(R.id.mediaBadge)
        val subText = view.findViewById<TextView>(R.id.mediaSub)
        val prevBtn = view.findViewById<View>(R.id.mediaPrev)
        val nextBtn = view.findViewById<View>(R.id.mediaNext)
        val backBtn = view.findViewById<View>(R.id.mediaBack)
        val fwdBtn = view.findViewById<View>(R.id.mediaFwd)
        val dp1 = resources.displayMetrics.density

        /** 재생 중엔 아이콘이 천천히 숨 쉬듯 커졌다 작아지고, 멈추면 살짝 작아진 채 가만히 있는다 */
        var pulse: android.animation.ValueAnimator? = null
        fun setPulse(on: Boolean) {
            if (!motionOn) return
            if (on) {
                if (pulse?.isRunning == true) return
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 300f, 0.7f)
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 300f, 0.7f)
                pulse = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 1500
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    repeatMode = android.animation.ValueAnimator.REVERSE
                    interpolator = android.view.animation.AccelerateDecelerateInterpolator()
                    addUpdateListener {
                        val k = 1f + 0.07f * (it.animatedValue as Float)
                        iconView.scaleX = k
                        iconView.scaleY = k
                    }
                    start()
                }
            } else {
                pulse?.cancel()
                pulse = null
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 0.9f, 300f, 0.6f)
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 0.9f, 300f, 0.6f)
            }
        }

        /** 재생/일시정지 버튼 모양: 재생 중엔 둥근 네모, 멈추면 동그라미로 부드럽게 바뀐다 */
        val playFill = ((playBtn.background.mutate() as? android.graphics.drawable.RippleDrawable)
            ?.findDrawableByLayerId(R.id.media_play_fill) as? android.graphics.drawable.GradientDrawable)
        var playRadius = 32f * dp1
        var radiusAnim: android.animation.ValueAnimator? = null
        fun setPlayShape(playing: Boolean, animate: Boolean) {
            val g = playFill ?: return
            val target = (if (playing) 22f else 32f) * dp1
            radiusAnim?.cancel()
            if (!animate || !motionOn) { playRadius = target; g.cornerRadius = target; return }
            radiusAnim = android.animation.ValueAnimator.ofFloat(playRadius, target).apply {
                duration = 320
                interpolator = android.view.animation.OvershootInterpolator(1.4f)
                addUpdateListener { playRadius = it.animatedValue as Float; g.cornerRadius = playRadius }
                start()
            }
        }

        var renderRef: () -> Unit = {}
        var exitDeleteRef: () -> Unit = {}
        var switching = false

        val content = view.findViewById<View>(R.id.mediaContent)
        swipeCard.content = content

        /**
         * 다른 미디어로 넘긴다. 카드 바탕과 점은 가만히 있고 안쪽 내용만 움직인다:
         * 지금 내용이 손가락이 밀던 방향으로 흘러 나가며 흐려지고(손가락 위치에서 이어서),
         * 새 내용이 반대쪽에서 미끄러져 들어와 자리를 잡는다.
         */
        fun goToImpl(i: Int) {
            val list = candidates()
            val cur = list.indexOf(sel)
            if (i !in list.indices || i == cur || switching) { swipeCard.springBack(); return }
            val dir = if (i > cur) 1 else -1
            val swap = {
                sel = list[i]
                firstRender = true   // 막대·버튼 모양은 애니메이션 없이 새 미디어 상태로 바로 맞춘다
                renderRef()
            }
            if (!motionOn) { swap(); return }
            switching = true
            Motion.cancel(content)
            val dist = card.width * 0.28f
            val dm = androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X
            content.animate().translationX(-dir * dist).alpha(0f).setDuration(130)
                .setInterpolator(android.view.animation.AccelerateInterpolator(1.1f))
                .withEndAction {
                    swap()
                    content.translationX = dir * dist
                    content.alpha = 0f
                    Motion.spring(content, dm, 0f, 520f, 0.86f)
                    Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 600f, 1f)
                    switching = false
                }.start()
        }
        goTo = { i -> goToImpl(i) }

        fun render() {
            if (ownerOf(sel.first) == null || (sel.first.mediaProg[sel.second] == null && sel.second !in sel.first.mediaFrames)) {
                val n = pickMedia()
                if (n == null) {
                    exitDeleteRef()
                    if (motionOn) {
                        card.animate().cancel()
                        card.animate().alpha(0f).setDuration(160)
                            .withEndAction { card.visibility = View.GONE }.start()
                    } else {
                        card.visibility = View.GONE
                    }
                    return
                }
                sel = n
            }
            val (t, f) = sel
            val p = t.mediaProg[f]
            val url = pageUrlOf(t)?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val host = url?.let { displayUrl(it) }.orEmpty()
            val mm = t.mediaMeta[f]
            view.findViewById<TextView>(R.id.mediaTitle).text =
                mm?.title?.takeIf { it.isNotBlank() }
                    ?: t.liveWebView?.title?.takeIf { it.isNotBlank() } ?: host.ifBlank { "재생 중" }
            val playing = p?.playing ?: true
            val owner = ownerOf(t)
            val status = when {
                owner != null && owner !== this && playing -> "${owner.windowLabel}에서 재생 중"
                owner != null && owner !== this -> "${owner.windowLabel} · 일시정지됨"
                t !== current && playing -> "다른 탭에서 재생 중"
                t !== current -> "다른 탭 · 일시정지됨"
                playing -> "재생 중"
                else -> "일시정지됨"
            }
            val tail = mm?.artist?.takeIf { it.isNotBlank() } ?: host
            subText.text = if (tail.isBlank()) status else "$status · $tail"
            val isVideo = t.mediaFrames[f]?.video != false
            val fav = t.favicon
            if (fav != null && !fav.isRecycled) {
                // 사이트 아이콘이 있으면 그걸 크게, 없으면 종류 아이콘
                iconImg.imageTintList = null
                iconImg.setPadding(dp(9), dp(9), dp(9), dp(9))
                iconImg.setImageBitmap(fav)
            } else {
                iconImg.imageTintList = android.content.res.ColorStateList.valueOf(
                    themeColor(com.google.android.material.R.attr.colorOnPrimaryContainer, R.color.ev_accent_on_soft)
                )
                iconImg.setPadding(dp(12), dp(12), dp(12), dp(12))
                iconImg.setImageResource(if (isVideo) R.drawable.ic_movie else R.drawable.ic_music)
            }
            badgeImg.setImageResource(if (isVideo) R.drawable.ic_movie else R.drawable.ic_music)
            setPlayIcon(playing)
            setPlayShape(playing, !firstRender)
            setPulse(playing)
            val all = candidates()
            updateDots(all.size, all.indexOf(sel)) { i -> goTo(i) }
            curDur = p?.dur ?: -1.0
            val canSeek = curDur > 0
            seek.isEnabled = canSeek
            backBtn.alpha = if (canSeek) 1f else 0.4f
            fwdBtn.alpha = if (canSeek) 1f else 0.4f
            if (!dragging) {
                moveSeek(if (canSeek && p != null) progFor(estPos()) else 0, firstRender)
                val x = estPos()
                lastShownSec = x.toInt()
                posText.text = fmt(x)
                if (playing) kickFrame()
            }
            durText.text = if (canSeek) fmt(curDur) else if (p != null) "라이브" else "--:--"
            firstRender = false
        }

        view.findViewById<View>(R.id.mediaHead).setOnClickListener {
            val t = sel.first
            val owner = ownerOf(t) ?: return@setOnClickListener
            if (owner !== this) {
                // 다른 창에서 재생 중이면 그 창으로 넘어가 그 탭을 보여 준다
                dismiss()
                if (owner.current !== t) owner.selectTab(t)
                bringWindowToFront(owner)
            } else if (t !== current) {
                dismiss()
                selectTab(t)
            }
        }
        playBtn.setOnClickListener {
            val (t, f) = sel
            val p = t.mediaProg[f]
            // 멈추는 순간의 위치로 고정해서 막대가 되돌아가거나 튀지 않게 한다
            if (p != null) t.mediaProg[f] = MediaProg(estPos(), p.dur, !p.playing, android.os.SystemClock.uptimeMillis())
            send("toggle")
            render()
        }
        prevBtn.setOnClickListener { send("prev"); nudge(it, -1) }
        nextBtn.setOnClickListener { send("next"); nudge(it, 1) }
        view.findViewById<View>(R.id.mediaBack).setOnClickListener {
            if (curDur > 0) { send("skip", -10.0); nudge(it, -1) }
        }
        view.findViewById<View>(R.id.mediaFwd).setOnClickListener {
            if (curDur > 0) { send("skip", 10.0); nudge(it, 1) }
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser && curDur > 0) posText.text = fmt(progress / SM.toDouble() * curDur)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                seekAnim?.cancel()
                // 옮기는 동안 현재 시간이 커지고 포인트 색이 된다
                posText.pivotX = 0f
                posText.setTextColor(themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent))
                if (motionOn) {
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1.25f, 500f, 0.6f)
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1.25f, 500f, 0.6f)
                }
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                if (curDur > 0) { send("seek", sb.progress / SM.toDouble() * curDur); lastShownSec = -1 }
                posText.setTextColor(themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted))
                if (motionOn) {
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 400f, 0.7f)
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 400f, 0.7f)
                }
            }
        })
        listOf(playBtn, prevBtn, backBtn, fwdBtn, nextBtn).forEach { Motion.pressable(it, 0.92f) }

        // 메뉴가 떠 있는 동안 0.5초마다 위치를 새로 그린다
        val tick = object : Runnable {
            override fun run() {
                if (!view.isAttachedToWindow || card.visibility != View.VISIBLE) return
                render()
                ui.postDelayed(this, 500)
            }
        }
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                ui.removeCallbacks(tick)
                ui.post(tick)
                frameOn = false
                kickFrame()
            }

            override fun onViewDetachedFromWindow(v: View) {
                ui.removeCallbacks(tick)
                frameOn = false
                pulse?.cancel()
                pulse = null
                radiusAnim?.cancel()
            }
        })
        renderRef = { render() }

        // ── 꾹 누르면: 카드가 흐려지고 삭제 버튼이 나온다 ──
        val inner = view.findViewById<View>(R.id.mediaInner)
        val delLayer = view.findViewById<View>(R.id.mediaDeleteLayer)
        val delBtn = view.findViewById<View>(R.id.mediaDeleteBtn)
        var deleteMode = false
        val maxBlur = 10f * dp1
        var blurAnim: android.animation.ValueAnimator? = null
        var wiggle: android.animation.ObjectAnimator? = null

        /** 안쪽 내용 흐림: Android 12+ 는 실제 블러, 그 아래는 투명도만 */
        fun setBlur(k: Float) {   // k: 0(선명) .. 1(흐림)
            inner.alpha = 1f - 0.82f * k
            if (Blur.active()) {
                val r = maxBlur * k
                inner.setRenderEffect(
                    if (r < 0.5f) null
                    else android.graphics.RenderEffect.createBlurEffect(r, r, android.graphics.Shader.TileMode.CLAMP)
                )
            }
            val sc = 1f - 0.03f * k
            inner.scaleX = sc; inner.scaleY = sc
        }
        fun animBlur(to: Float, dur: Long) {
            blurAnim?.cancel()
            if (!motionOn) { setBlur(to); return }
            blurAnim = android.animation.ValueAnimator.ofFloat(
                (1f - inner.alpha) / 0.82f, to
            ).apply {
                duration = dur
                interpolator = android.view.animation.DecelerateInterpolator(1.6f)
                addUpdateListener { setBlur(it.animatedValue as Float) }
                start()
            }
        }

        fun exitDeleteMode(animate: Boolean = true) {
            if (!deleteMode) return
            deleteMode = false
            swipeCard.locked = false
            wiggle?.cancel(); wiggle = null
            delLayer.animate().cancel()
            Motion.cancel(delBtn)
            if (animate && motionOn) {
                animBlur(0f, 220)
                delBtn.animate().scaleX(0.7f).scaleY(0.7f).setDuration(140).start()
                delLayer.animate().alpha(0f).setDuration(140)
                    .withEndAction { if (!deleteMode) delLayer.visibility = View.GONE }.start()
            } else {
                blurAnim?.cancel()
                setBlur(0f)
                delLayer.visibility = View.GONE
            }
        }

        fun enterDeleteMode() {
            if (deleteMode || card.visibility != View.VISIBLE || dragging) return
            deleteMode = true
            swipeCard.locked = true
            card.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            delLayer.animate().cancel()
            delBtn.animate().cancel()
            delBtn.alpha = 1f; delBtn.translationY = 0f
            delLayer.alpha = 0f
            delLayer.visibility = View.VISIBLE
            // 꾹 누르며 눌려 있던 카드가 통 하고 돌아온다
            if (motionOn) {
                card.pivotX = card.width / 2f; card.pivotY = card.height / 2f
                Motion.spring(card, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 500f, 0.4f)
                Motion.spring(card, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 500f, 0.4f)
            }
            animBlur(1f, 260)
            if (motionOn) {
                delLayer.animate().alpha(1f).setDuration(200).start()
                delBtn.scaleX = 0.4f; delBtn.scaleY = 0.4f; delBtn.rotation = -6f
                delBtn.postDelayed({
                    if (!deleteMode) return@postDelayed
                    Motion.spring(delBtn, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 420f, 0.42f)
                    Motion.spring(delBtn, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 420f, 0.42f)
                    Motion.spring(delBtn, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, 0f, 300f, 0.35f)
                }, 70)
                // 삭제 버튼이 눌러 달라는 듯 아주 살짝 숨 쉰다
                wiggle = android.animation.ObjectAnimator.ofFloat(delBtn, View.TRANSLATION_Y, 0f, -dp1 * 2f).apply {
                    startDelay = 600
                    duration = 900
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    repeatMode = android.animation.ValueAnimator.REVERSE
                    interpolator = android.view.animation.AccelerateDecelerateInterpolator()
                    start()
                }
            } else {
                delLayer.alpha = 1f
            }
        }

        /** 카드째 사라질 때: 위로 접히듯 높이가 줄고 흐려진다 */
        fun collapseCard() {
            val lp = card.layoutParams as ViewGroup.MarginLayoutParams
            val h0 = card.height
            val mt = lp.topMargin; val mb = lp.bottomMargin
            card.animate().cancel()
            android.animation.ValueAnimator.ofFloat(1f, 0f).apply {
                duration = 260
                interpolator = android.view.animation.DecelerateInterpolator(1.4f)
                addUpdateListener {
                    val k = it.animatedValue as Float
                    lp.height = (h0 * k).toInt().coerceAtLeast(1)
                    lp.topMargin = (mt * k).toInt(); lp.bottomMargin = (mb * k).toInt()
                    card.alpha = k
                    card.requestLayout()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: android.animation.Animator) {
                        card.visibility = View.GONE
                        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        lp.topMargin = mt; lp.bottomMargin = mb
                        card.alpha = 1f
                        delLayer.visibility = View.GONE
                        setBlur(0f)
                        card.requestLayout()
                    }
                })
                start()
            }
        }

        fun deleteSelected() {
            val (t, f) = sel
            val playingNow = t.mediaProg[f]?.playing ?: (f in t.mediaFrames)
            // 재생 중이면 멈추고, 이 미디어는 다시 재생하기 전까지 카드에서 뺀다
            if (playingNow) send("toggle")
            t.mediaDismissed[f] = android.os.SystemClock.uptimeMillis()
            t.mediaProg.remove(f); t.mediaMeta.remove(f); t.mediaWave.remove(f); t.mediaFrames.remove(f); t.mediaThumb.remove(f)
            val hasNext = pickMedia() != null
            if (hasNext || !motionOn) exitDeleteMode(animate = false)
            onMediaChanged()
            if (!motionOn) { firstRender = true; render(); return }
            if (!hasNext) {
                // 흐린 채로 삭제 화면 그대로 접히며 사라진다 (끝나면 원래 상태로 되돌려 둔다)
                deleteMode = false
                swipeCard.locked = false
                wiggle?.cancel(); wiggle = null
                delBtn.animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(120).start()
                collapseCard()
                return
            }
            // 남은 미디어가 있으면: 지금 내용이 위로 떠오르며 사라지고, 다음 내용이 아래에서 올라온다
            switching = true
            Motion.cancel(content)
            content.animate().translationY(-dp1 * 14f).alpha(0f).setDuration(140)
                .setInterpolator(android.view.animation.AccelerateInterpolator(1.1f))
                .withEndAction {
                    firstRender = true
                    render()
                    content.translationY = dp1 * 14f
                    Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_Y, 0f, 480f, 0.8f)
                    Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 600f, 1f)
                    switching = false
                }.start()
        }

        // 누르는 동안 카드가 서서히 눌려 들어가 "꾹 누르는 중"임을 보여 준다 (조작 버튼·막대는 영향 없음)
        val pressIn = View.OnTouchListener { _, e ->
            if (motionOn && !deleteMode) when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    card.pivotX = card.width / 2f; card.pivotY = card.height / 2f
                    Motion.spring(card, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 0.965f, 90f, 1f)
                    Motion.spring(card, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 0.965f, 90f, 1f)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    Motion.spring(card, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 500f, 0.5f)
                    Motion.spring(card, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 500f, 0.5f)
                }
            }
            false
        }
        listOf(content, view.findViewById<View>(R.id.mediaHead)).forEach { it.setOnTouchListener(pressIn) }

        val onLong = View.OnLongClickListener { enterDeleteMode(); true }
        listOf(card, content, view.findViewById<View>(R.id.mediaHead)).forEach { it.setOnLongClickListener(onLong) }
        delLayer.setOnClickListener { exitDeleteMode() }
        delBtn.setOnClickListener { deleteSelected() }
        Motion.pressable(delBtn, 0.94f)
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) { blurAnim?.cancel(); exitDeleteMode(animate = false) }
        })
        exitDeleteRef = { exitDeleteMode(animate = false) }
        swipeCard.ignoreView = seek
        swipeCard.canSwipe = { dir ->
            val list = candidates()
            val i = list.indexOf(sel)
            i >= 0 && (i + dir) in list.indices
        }
        swipeCard.onSwipe = { dir ->
            val i = candidates().indexOf(sel)
            goTo(i + dir)
        }
        render()
    }

    /**
     * 메뉴 맨 위 링크 공유 카드. 지금 보는 탭의 미리보기 · 제목 · 주소를 보여 주고,
     * 메뉴가 떠 있는 동안 0.4초마다 확인해서 탭 전환 / 주소 이동 / 제목 변경이 있으면 바로 다시 그린다.
     */
    private fun bindShareCard(view: View, dismiss: () -> Unit) {
        val card = view.findViewById<View>(R.id.shareCard)
        val info = view.findViewById<View>(R.id.shareInfo)
        val thumb = view.findViewById<ImageView>(R.id.shareThumb)
        val titleV = view.findViewById<TextView>(R.id.shareTitle)
        val hostV = view.findViewById<TextView>(R.id.shareHost)
        val lock = view.findViewById<ImageView>(R.id.shareLock)
        val motionOn = Motion.enabled(this)
        var shownTab: BrowserTab? = null
        var shownUrl: String? = null
        var shownTitle: String? = null
        var shownVisible = false
        var first = true
        var thumbRetry: Runnable? = null
        var latestUrl: String? = null

        fun capture() {
            if (isFinishing || isDestroyed) return
            captureContentAsync { bmp ->
                if (!isFinishing && !isDestroyed) setThumb(thumb, bmp)
            }
        }

        fun render() {
            val t = current
            val url = pageUrlOf(t, t?.webView)?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val visible = t != null && !t.isHome && url != null
            if (!visible) {
                latestUrl = null
                if (shownVisible) {
                    shownVisible = false; shownTab = null; shownUrl = null; shownTitle = null
                    if (motionOn) {
                        card.animate().cancel()
                        card.animate().alpha(0f).setDuration(140).withEndAction { card.visibility = View.GONE }.start()
                    } else card.visibility = View.GONE
                }
                return
            }
            latestUrl = url
            val title = t!!.webView.title?.takeIf { it.isNotBlank() } ?: displayUrl(url!!)
            val tabChanged = t !== shownTab
            val urlChanged = url != shownUrl
            if (shownVisible && !tabChanged && !urlChanged && title == shownTitle) return

            val wasVisible = shownVisible
            shownVisible = true
            shownTab = t; shownUrl = url; shownTitle = title
            val animate = motionOn && wasVisible && !first && (tabChanged || urlChanged)
            // 메뉴가 처음 뜨는 순간(펼침 애니메이션 중)에는 화면 복사를 하지 않는다. 영상이 재생 중이면 그 순간 끊겨 보인다.
            val opening = !wasVisible && first

            fun apply() {
                titleV.text = title
                hostV.text = displayUrl(url!!)
                lock.setImageResource(if (url.startsWith("https://")) R.drawable.ic_lock else R.drawable.ic_globe)
            }
            if (!wasVisible) {
                card.animate().cancel()
                card.visibility = View.VISIBLE
                card.alpha = 1f
                apply()
                if (opening) t.thumb?.let { setThumb(thumb, it) } else capture()
                if (!first) Motion.enter(card, 0, 10f)
            } else if (animate) {
                // 글자는 아래에서 살짝 떠오르며 바뀌고, 미리보기는 통통 튀며 바뀐다
                info.alpha = 0f
                info.translationY = dp(8).toFloat()
                apply()
                Motion.spring(info, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 300f, 1f)
                Motion.spring(info, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_Y, 0f, 300f, 0.75f)
                capture()
                Motion.pop(thumb, 0.82f)
            } else {
                apply() // 제목만 바뀐 경우(로딩 중)는 조용히 글자만 갈아 끼운다
            }
            first = false
            // 탭을 바꾸거나 이동한 직후엔 아직 그려지는 중일 수 있어서, 잠시 뒤 미리보기를 한 번 더 갱신한다
            if (tabChanged || urlChanged) {
                thumbRetry?.let { ui.removeCallbacks(it) }
                thumbRetry = Runnable { capture() }.also { ui.postDelayed(it, if (opening) 450L else 900L) }
            }
        }

        view.findViewById<View>(R.id.btnShareLink).setOnClickListener {
            val u = latestUrl ?: return@setOnClickListener
            dismiss()
            shareText(u)
        }
        card.visibility = View.GONE
        val tick = object : Runnable {
            override fun run() {
                if (!view.isAttachedToWindow) return
                render()
                ui.postDelayed(this, 400)
            }
        }
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                ui.removeCallbacks(tick); ui.post(tick)
            }

            override fun onViewDetachedFromWindow(v: View) {
                ui.removeCallbacks(tick)
                thumbRetry?.let { ui.removeCallbacks(it) }
            }
        })
        render() // 처음 모습은 메뉴가 뜨기 전에 바로 채워 둔다
    }

    /** 태블릿 팝업의 왼쪽 위치 (showMenu 의 wantLeft 와 같은 계산) */
    private fun wantLeftForZone(loc: IntArray, anchorView: View, width: Int, screenW: Int): Int =
        (loc[0] + anchorView.width - width).coerceIn(dp(8), (screenW - width - dp(8)).coerceAtLeast(dp(8)))

    private fun showMenu(anchor: View? = null, settings: Boolean = false, fromMenu: Boolean = true) {
        // 설정을 메뉴에서 열었을 때만 ←/뒤로가기/바깥 누름으로 메뉴에 돌아간다 (상단바 버튼으로 열었으면 그냥 닫힌다)
        val backToMenu = settings && fromMenu
        menuQuietUntil = android.os.SystemClock.uptimeMillis() + 600L
        suppressMenuReopen = false
        menuReopenAnchor = anchor?.let { java.lang.ref.WeakReference(it) }
        val tabletPopup = anchor != null && anchor.isShown &&
            expanded
        if (tabletPopup) menuAnchorRef = java.lang.ref.WeakReference(anchor)
        val sheet = if (tabletPopup) null else BottomSheetDialog(this)
        var popup: PopupWindow? = null
        var closedByUs = false
        fun dismissMenu() {
            closedByUs = true
            sheet?.dismiss()
            popup?.dismiss()
        }
        openMenu = OpenMenu(
            showing = { sheet?.isShowing == true || popup?.isShowing == true },
            close = { dismissMenu() },
            settings = settings,
            fromMenu = fromMenu
        )
        val view = layoutInflater.inflate(R.layout.dialog_menu, null)
        ThemeColors.skin(view)
        val list = view.findViewById<LinearLayout>(R.id.menuList)
        // 설정 화면 안에서 카테고리 → 하위 설정 창으로 들어가 있는지 (null = 카테고리 목록)
        var openBig: String? = null
        // 하위 설정 창에서 카테고리 목록으로 돌아간다. 돌아갔으면 true (뒤로가기·← 버튼이 먼저 이걸 부른다)
        var settingsNav: (() -> Boolean)? = null
        // 손잡이는 아래에서 올라오는 시트에만 (태블릿 카드 팝업에는 필요 없다)
        if (sheet == null) view.findViewById<View>(R.id.sheetHandle).visibility = View.GONE
        view.findViewById<View>(R.id.btnCloseMenu).setOnClickListener { dismissMenu() }
        if (settings) {
            // 설정창은 마지막으로 뜬 메뉴창과 같은 높이로 (목록 영역을 같은 높이로 고정하고 안에서 스크롤)
            val keepH = menuScrollH[if (tabletPopup) 1 else 0]
            if (keepH > 0) view.findViewById<View>(R.id.menuScroll)?.let { sv ->
                sv.layoutParams = sv.layoutParams.apply { height = keepH }
            }
            view.findViewById<TextView>(R.id.menuTitle).text = "설정"
            view.findViewById<View>(R.id.btnMenuBack).apply {
                visibility = if (backToMenu) View.VISIBLE else View.GONE
                setOnClickListener {
                    if (settingsNav?.invoke() == true) return@setOnClickListener
                    dismissMenu()
                    showMenu(anchor)
                }
            }
        }

        // 맨 위: 지금 보는 페이지의 링크 공유 카드 (미리보기 · 제목 · 주소 · 공유 버튼)
        // 메뉴가 열려 있는 동안 탭을 바꾸거나 페이지가 이동·로딩되면 카드도 실시간으로 따라 바뀐다.
        if (!settings) bindShareCard(view) { dismissMenu() }

        // 웹에서 미디어가 재생 중이면 공유 카드 위에 미디어 플레이어를 보여 준다
        if (!settings) bindMediaCard(view) { dismissMenu() }

        // 항목들은 제목(머리말) 아래 둥근 카드 안에 묶어서 보여 준다.
        var card: LinearLayout? = null
        // 항목이 그려지는 곳: 보통은 목록 자체, 설정 화면에서는 묶음 블록(inBlock) 안이나 검색 결과 칸
        var host: LinearLayout = list
        var inBlock = false
        fun currentCard(): LinearLayout {
            card?.let { return it }
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                tag = "menuCard"
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setColor(ThemeColors.get(list, com.google.android.material.R.attr.colorSurface, 0))
                }
                clipToOutline = true
            }
            val side = if (inBlock) dp(8) else dp(14)
            host.addView(
                c,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(side, 0, side, dp(4)) }
            )
            card = c
            return c
        }

        fun trimDividers(root: ViewGroup) {
            for (i in 0 until root.childCount) {
                val c = root.getChildAt(i)
                if (c is LinearLayout && c.tag == "menuCard") {
                    if (c.childCount > 0) c.getChildAt(c.childCount - 1).findViewById<View>(R.id.rowDivider)?.visibility = View.GONE
                } else if (c is ViewGroup) trimDividers(c)
            }
        }

        // 누르면 다른 화면이나 선택창이 열리는 항목에는 오른쪽에 화살표를 붙인다.
        val navTitles = setOf(
            "설정", "북마크", "방문 기록", "다운로드 목록", "검색 엔진", "웹 페이지 다크 모드", "글자 크기",
            "재생 속도", "광고 차단 현황", "보안 현황", "직접 선택한 광고 관리", "자동완성 서비스", "상/하단바 버튼 편집"
        )

        fun newRow(icon: Int, title: String, sub: String?): View {
            val parent = currentCard()
            val row = layoutInflater.inflate(R.layout.item_menu_row, parent, false)
            ThemeColors.skin(row)
            val iconView = row.findViewById<ImageView>(R.id.rowIcon)
            iconView.setImageResource(icon)
            row.findViewById<TextView>(R.id.rowTitle).text = title
            val st = row.findViewById<TextView>(R.id.rowSub)
            if (sub != null) {
                st.text = sub
                st.visibility = View.VISIBLE
            }
            if (title in navTitles) row.findViewById<View>(R.id.rowChevron).visibility = View.VISIBLE
            // 지우는 항목은 붉은 색으로 눈에 띄게
            if (title.endsWith("삭제")) {
                iconView.backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.ev_danger_soft))
                iconView.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.ev_danger))
                row.findViewById<TextView>(R.id.rowTitle).setTextColor(getColor(R.color.ev_danger))
            }
            parent.addView(row)
            return row
        }

        fun addHeader(text: String) {
            val h = layoutInflater.inflate(R.layout.item_menu_header, list, false) as TextView
            ThemeColors.skin(h)
            h.text = text
            // 묶음 블록 안의 소제목은 안쪽으로 들여 쓴다
            if (inBlock) h.setPadding(dp(18), dp(12), dp(16), dp(6))
            host.addView(h)
            card = null   // 다음 항목부터 새 카드
        }

        fun addRow(icon: Int, title: String, sub: String? = null, action: () -> Unit) {
            val row = newRow(icon, title, sub)
            row.setOnClickListener {
                dismissMenu()
                action()
            }
        }

        // 설정 창을 닫지 않고 그 위에 선택창·팝업을 띄우는 항목. 팝업을 닫고 돌아오면 '현재: …' 글자를 새로 고친다.
        fun addKeepRow(icon: Int, title: String, sub: () -> String?, action: () -> Unit) {
            val row = newRow(icon, title, sub())
            row.setOnClickListener { action() }
            row.viewTreeObserver.addOnWindowFocusChangeListener { hasFocus ->
                if (hasFocus) row.findViewById<TextView>(R.id.rowSub)?.let { st ->
                    val t = sub()
                    if (t != null) { st.text = t; st.visibility = View.VISIBLE }
                }
            }
        }

        // 스위치 행: 시트를 닫지 않고 바로 켜고 끈다.
        fun addToggle(
            icon: Int,
            title: String,
            sub: () -> String?,
            checked: Boolean,
            action: () -> Boolean
        ) {
            val row = newRow(icon, title, sub())
            val sw = row.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.rowSwitch)
            sw.visibility = View.VISIBLE
            sw.isChecked = checked
            row.contentDescription = title
            row.setOnClickListener {
                row.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                sw.isChecked = action()
                row.findViewById<TextView>(R.id.rowSub).text = sub()
            }
        }

        if (!settings) {
            // 메뉴 = 지금 바로 쓰는 것(탭 · 이 페이지 · 동영상 · 보관함). 바꿔 두고 쓰는 것은 모두 설정으로 보낸다.
            val onPage = current?.isHome != true

            addHeader("탭")
            addRow(R.drawable.ic_add, "새 탭") { openNewTabAndFocus() }
            addRow(R.drawable.ic_incognito, "새 시크릿 탭", "방문 기록과 쿠키가 남지 않아요") { openNewTabAndFocus(incognito = true) }
            addRow(R.drawable.ic_tab, "새 창", "앱을 한 개 더 띄워 나란히 사용합니다") { openNewWindow() }
            recentlyClosed.lastOrNull()?.let { c ->
                val n = recentlyClosed.count { it.batch == c.batch }
                if (n > 1) addRow(R.drawable.ic_history, "닫은 탭 ${n}개 다시 열기", c.title) { reopenClosedTab() }
                else addRow(R.drawable.ic_history, "닫은 탭 다시 열기", c.title) { reopenClosedTab() }
            }
            addRow(R.drawable.ic_folder, "현재 탭을 새 그룹으로") { groupCurrentTab() }

            // 이 페이지: 지금 보고 있는 페이지에 하는 일 (누르면 바로 실행)
            addHeader(if (onPage) "이 페이지" else "도구")
            if (onPage) {
                val bookmarked = currentBookmark() != null
                addRow(
                    if (bookmarked) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border,
                    if (bookmarked) "북마크 수정" else "북마크에 추가"
                ) { bookmarkCurrent() }
                addRow(R.drawable.ic_search, "페이지에서 찾기") { openFind() }
                addRow(R.drawable.ic_globe, "페이지 번역", "한국어로 번역 · 다시 누르면 원문") { pageTranslator?.togglePageTranslation() }
            }
            addRow(
                R.drawable.ic_ai, "AI 어시스턴트",
                if (prefs.geminiKey.isBlank()) "Gemini API 키를 넣으면 쓸 수 있어요"
                else "${GeminiModels.byId(prefs.geminiModel).label} · 요약, 번역, 질문"
            ) { assistant?.show(if (tbAi.isShown) tbAi else null) }

            // 보기: 화면을 어떻게 보여줄지 (확대·바 숨기기·PC 화면)
            addHeader("보기")
            if (onPage) {
                addRow(
                    R.drawable.ic_text, "화면 확대/축소",
                    "현재: ${current?.let { effectiveZoom(it) } ?: 100}%" + if (current?.pageZoom != null) " (이 탭만)" else ""
                ) { showPageZoomDialog() }
            }
            addToggle(
                R.drawable.ic_hide_bars, "상/하단바 숨기기",
                { if (prefs.hideBars) "바 다시 보이기 버튼만 보여요 · 길게 누르면 주소창" else "화면을 넓게 써요" },
                prefs.hideBars
            ) {
                toggleHideBars()
                prefs.hideBars
            }
            addToggle(
                R.drawable.ic_desktop, "데스크톱 사이트",
                { null },
                current?.desktop == true
            ) {
                toggleDesktopSite()
                current?.desktop == true
            }

            // 광고: 차단 켜고 끄기 + 직접 고르기
            addHeader("광고")
            addToggle(
                R.drawable.ic_shield, "광고 차단",
                { "이 페이지 ${current?.adBlocked?.get() ?: 0}건 · 오늘 ${adBlocker.stats(0).today}건" },
                adBlockEnabled
            ) {
                toggleAdBlock()
                adBlockEnabled
            }
            if (onPage) {
                addRow(R.drawable.ic_edit, "광고 직접 선택", "눌러서 차단할 광고 고르기") { startAdPicker() }

                addHeader("동영상")
                addRow(R.drawable.ic_pip, "동영상 PiP", "작은 창으로 띄우기") { startPipFromMenu() }
                addRow(R.drawable.ic_play, "내장 플레이어로 재생", "앱 안의 플레이어로 열기") { openInternalPlayer() }
                addRow(R.drawable.ic_movie, "페이지의 영상 파일 찾기") { findVideos() }
            }

            addHeader("보관함")
            addRow(R.drawable.ic_bookmark, "북마크", "${prefs.bookmarks().size}개") { openBookmarks() }
            addRow(R.drawable.ic_history, "방문 기록", "${prefs.historyItems().size}개") { openHistory() }
            addRow(R.drawable.ic_download, "다운로드 목록") { openDownloads() }

            addHeader("더 보기")
            addRow(R.drawable.ic_settings, "설정", "검색 엔진 · 화면 · 재생 · 광고 차단 · 보안 · 개인정보") {
                showMenu(anchor, settings = true)
            }
        } else {
            // ── 설정 화면: 큰 묶음(블록) → 작은 소제목 → 항목.
            // 항목은 먼저 등록만 해 두고, 묶음으로 그릴 때와 검색 결과·관련 설정을 그릴 때 같은 항목을 다시 그린다. ──
            class SEntry(
                val kind: Int, val title: String, val desc: String = "",
                val big: String = "", val sub: String = "", val add: (() -> Unit)? = null
            )
            val entries = ArrayList<SEntry>()
            var curBig = ""
            var curSub = ""
            fun big(title: String, desc: String) { curBig = title; curSub = ""; entries.add(SEntry(0, title, desc)) }
            fun sub(title: String) { curSub = title; entries.add(SEntry(1, title)) }
            fun reg(title: String, add: () -> Unit) { entries.add(SEntry(2, title, big = curBig, sub = curSub, add = add)) }

            big("브라우저", "검색 엔진 · 홈 페이지 · 탭 · 번역 · 자동 스크롤")
            sub("일반")
            reg("검색 엔진") { addKeepRow(R.drawable.ic_search, "검색 엔진", { "현재: ${prefs.currentEngine().name}" }) { showEngineDialog() } }
            reg("홈 페이지") { addKeepRow(R.drawable.ic_home, "홈 페이지", { prefs.homepage.ifEmpty { "기본 (새 탭 화면)" } }) { showHomepageDialog() } }
            reg("확장 프로그램") { addKeepRow(
                R.drawable.ic_extension, "확장 프로그램",
                {
                    val all = extensions.list()
                    if (all.isEmpty()) "크롬 확장 프로그램(zip · crx)을 추가해요" else "${all.count { it.enabled }}개 사용 중 · 전체 ${all.size}개"
                }
            ) { extAnchorRef = null; showExtensions() } }

            reg("모바일/데스크톱 자동 전환") { addToggle(
                R.drawable.ic_desktop, "모바일/데스크톱 자동 전환",
                {
                    if (prefs.autoSiteMode) "창이 넓으면 데스크톱 사이트, 좁으면 모바일 사이트로 자동으로 바꿔요 (바뀔 때 페이지를 다시 불러와요)"
                    else "꺼져 있어요 · 창 크기가 바뀌어도 지금 모드를 유지해요. 상단바/메뉴의 데스크톱 버튼으로만 바꿔요"
                },
                prefs.autoSiteMode
            ) {
                prefs.autoSiteMode = !prefs.autoSiteMode
                if (prefs.autoSiteMode && !mirrorActive && !isInPictureInPictureModeCompat()) {
                    // 다시 켜면 지금 창 크기에 맞춰 바로 판단한다
                    siteModeWide = null
                    syncSiteModeWithLayout(siteWideNow(wideForWindow()))
                }
                prefs.autoSiteMode
            } }

            sub("탭")
            reg("탭을 끌어서 새 창 열기") { addToggle(
                R.drawable.ic_tab, "탭을 끌어서 새 창 열기",
                { if (prefs.dragTabToWindow) "탭 줄 밖으로 끌어내 놓으면 팝업 창으로 열려요" else "꺼져 있어요 · 다른 창이 열려 있으면 탭 메뉴의 \"탭을 다른 창으로 이동\"으로 옮길 수 있어요" },
                prefs.dragTabToWindow
            ) {
                prefs.dragTabToWindow = !prefs.dragTabToWindow
                prefs.dragTabToWindow
            } }

            sub("번역")
            reg("항상 번역") { addToggle(
                R.drawable.ic_globe, "항상 번역",
                { if (prefs.alwaysTranslate) "페이지를 열 때마다 저절로 한국어로 번역해요" else "켜면 페이지를 열 때마다 저절로 한국어로 번역해요" },
                prefs.alwaysTranslate
            ) {
                prefs.alwaysTranslate = !prefs.alwaysTranslate
                if (prefs.alwaysTranslate) pageTranslator?.translateCurrentIfNeeded()
                prefs.alwaysTranslate
            } }
            reg("번역 설정") { addKeepRow(
                R.drawable.ic_settings, "번역 설정",
                { "Gemini 사용 · 진행 카드" }
            ) { pageTranslator?.showSettings() } }

            sub("자동 스크롤")
            reg("자동 스크롤 속도") { addKeepRow(
                R.drawable.ic_arrow_down, "자동 스크롤 속도",
                { if (prefs.smartAutoScroll) "스마트 자동 스크롤이 켜져 있어 아래의 내용·빈 그림 속도를 써요" else "현재: ${prefs.autoScrollSpeed}단계 · 꾹 눌러서 뜨는 메뉴의 「자동 스크롤」에 쓰여요" }
            ) { showAutoScrollSpeedDialog() } }
            reg("스마트 자동 스크롤") { addToggle(
                R.drawable.ic_auto_scroll, "스마트 자동 스크롤",
                { if (prefs.smartAutoScroll) "글·그림이 보이면 천천히, 빈 그림만 보이면 빠르게 알아서 속도를 맞춰요 (웹툰용)" else "꺼져 있어요 · 켜면 화면 내용을 보고 속도를 유동적으로 바꿔요" },
                prefs.smartAutoScroll
            ) {
                prefs.smartAutoScroll = !prefs.smartAutoScroll
                prefs.smartAutoScroll
            } }
            reg("스마트 자동 스크롤 속도") { addKeepRow(
                R.drawable.ic_arrow_down, "스마트 자동 스크롤 속도",
                { "내용 ${prefs.autoScrollContentLevel}단계 · 빈 그림 ${prefs.autoScrollBlankLevel}단계" }
            ) { showSmartScrollSpeedDialog() } }
            reg("자동 스크롤 중 화면을 만지면") { addKeepRow(
                R.drawable.ic_pause, "자동 스크롤 중 화면을 만지면",
                { "현재: ${autoScrollTouchLabel()}" }
            ) { showAutoScrollTouchDialog() } }
            reg("자동 스크롤 조작 막대") { addToggle(
                R.drawable.ic_show_bars, "자동 스크롤 조작 막대",
                { if (prefs.autoScrollControls) "자동 스크롤 중 화면 아래에 닫기·속도 조절·일시정지 막대가 떠요" else "꺼져 있어요 · 멈추려면 화면을 만지거나 꾹 눌러서 뜨는 메뉴를 써요" },
                prefs.autoScrollControls
            ) {
                prefs.autoScrollControls = !prefs.autoScrollControls
                // 이미 흐르는 중이면 막대를 바로 켜고 끈다
                autoScrollerInst?.applyControlsSetting()
                prefs.autoScrollControls
            } }

            big("화면", "다크 모드 · 글자 크기 · 상/하단바 · 블러 · 테마 색")
            reg("스크롤해서 상/하단바 숨기기") { addToggle(
                R.drawable.ic_hide_bars, "스크롤해서 상/하단바 숨기기",
                {
                    if (prefs.hideBars) "'상/하단바 숨기기'가 켜져 있어서 지금은 쓰이지 않아요"
                    else if (prefs.hideBarsOnScroll) "페이지를 내리면 바가 손가락을 따라 사라지고, 올리면 다시 나타나요"
                    else "켜면 페이지를 내릴 때 상단·하단 바가 사라지고 올리면 다시 나타나요"
                },
                prefs.hideBarsOnScroll
            ) {
                toggleHideBarsOnScroll()
                prefs.hideBarsOnScroll
            } }
            reg("북마크바 표시") { addToggle(
                R.drawable.ic_bookmark, "북마크바 표시",
                { if (prefs.bookmarkBar) "주소창 아래에 북마크를 가로로 보여 줘요 · 북마크가 없으면 보이지 않아요" else "꺼져 있어요 · 북마크는 메뉴의 북마크에서 볼 수 있어요" },
                prefs.bookmarkBar
            ) {
                prefs.bookmarkBar = !prefs.bookmarkBar
                refreshBookmarkBar()
                prefs.bookmarkBar
            } }
            reg("블러 효과") { addToggle(
                R.drawable.ic_blur, "블러 효과",
                { if (prefs.blurEffects) "바·팝업·탭 화면에 유리처럼 흐린 배경을 써요" else "꺼져 있어요 · 모든 블러 없이 불투명하게 보여요" },
                prefs.blurEffects
            ) {
                prefs.blurEffects = !prefs.blurEffects
                Blur.enabled = prefs.blurEffects
                // 바·상태표시줄 배경은 화면을 만들 때 정해지므로, 열려 있는 모든 창을 다시 만들어 바로 적용한다
                ui.post { instances.toList().forEach { a -> if (!a.isFinishing) a.recreate() } }
                prefs.blurEffects
            } }
            reg("메뉴·팝업에도 테마 색 적용") { addToggle(
                R.drawable.ic_extension, "메뉴·팝업에도 테마 색 적용",
                { if (prefs.themeMenus) "메뉴·설정·팝업 같은 창에도 테마 색을 입혀요" else "꺼져 있어요 · 탭바·툴바·주소창만 테마 색이고, 창들은 앱 기본 색이에요" },
                prefs.themeMenus
            ) {
                prefs.themeMenus = !prefs.themeMenus
                applyExtTheme()
                // 창 바탕·머리말·시트 모양까지 한 번에 새 색이 되도록, 지금 보던 카테고리 그대로 설정 창을 새로 띄운다
                val ob = openBig
                ui.post {
                    if (!isFinishing && !isDestroyed) {
                        settingsReopenBig = ob
                        dismissMenu()
                        showMenu(anchor, settings = true, fromMenu = backToMenu)
                    }
                }
                prefs.themeMenus
            } }
            reg("상/하단바 버튼 편집") { addKeepRow(
                R.drawable.ic_edit, "상/하단바 버튼 편집",
                { "${TopBarConfig.enabled(prefs, expanded).size}개 표시 중 · 보이기/숨기기, 순서 바꾸기" }
            ) { showTopBarEditor() } }
            reg("웹 페이지 다크 모드") { addKeepRow(R.drawable.ic_dark, "웹 페이지 다크 모드", { "현재: ${darkModeLabel()}" }) { showDarkModeDialog() } }
            reg("글자 크기") { addKeepRow(R.drawable.ic_text, "글자 크기", { "현재: ${textZoom}%" }) { showTextSizeDialog() } }

            big("미디어", "재생 속도 · 백그라운드 · 영상")
            reg("재생 속도") { addKeepRow(R.drawable.ic_play, "재생 속도", { "현재: ${current?.rate ?: 1f}x" }) { showSpeedDialog() } }
            reg("백그라운드 재생") { addToggle(
                R.drawable.ic_play, "백그라운드 재생",
                { "앱을 나가거나 화면을 꺼도 소리가 계속 나옵니다" },
                prefs.backgroundAudio
            ) {
                prefs.backgroundAudio = !prefs.backgroundAudio
                onMediaChanged()
                prefs.backgroundAudio
            } }
            reg("시스템 미디어 플레이어에 표시") { addToggle(
                R.drawable.ic_play, "시스템 미디어 플레이어에 표시",
                { "알림창·잠금화면의 미디어 컨트롤에서 웹 미디어를 조작할 수 있어요" },
                prefs.mediaControls
            ) {
                prefs.mediaControls = !prefs.mediaControls
                mediaKey = ""
                pushKey = ""
                if (prefs.mediaControls) requestNotificationPermission()
                onMediaChanged()
                prefs.mediaControls
            } }
            reg("전체화면에서 아래로 밀어 나가기") { addToggle(
                R.drawable.ic_play, "전체화면에서 아래로 밀어 나가기",
                { if (prefs.swipeDownExit) "전체화면 영상·내장 플레이어·미러링 화면의 가운데를 아래로 밀면 빠져나가요" else "꺼져 있어요 · 뒤로 가기나 닫기 버튼으로 나가요" },
                prefs.swipeDownExit
            ) {
                prefs.swipeDownExit = !prefs.swipeDownExit
                prefs.swipeDownExit
            } }
            reg("영상 아래 버튼 표시") { addToggle(
                R.drawable.ic_pip, "영상 아래 버튼 표시",
                { if (prefs.videoButtons) "영상 아래에 '내장 플레이어로 열기'와 'PiP로 보기' 버튼이 떠요" else "꺼져 있어요 · 메뉴의 내장 플레이어·PiP 항목은 그대로 쓸 수 있어요" },
                prefs.videoButtons
            ) {
                prefs.videoButtons = !prefs.videoButtons
                prefs.videoButtons
            } }

            reg("영상 못 찾으면 미러링") { addToggle(
                R.drawable.ic_pip, "영상 못 찾으면 미러링",
                { if (prefs.mirrorFallback) "내장 플레이어가 영상을 못 찾으면 페이지 영상을 창 가득 그대로 보여 줘요" else "꺼져 있어요 · 못 찾으면 알림만 띄우고 열지 않아요" },
                prefs.mirrorFallback
            ) {
                prefs.mirrorFallback = !prefs.mirrorFallback
                prefs.mirrorFallback
            } }

            big("알림", "다운로드 · 앱 안 안내 · 백그라운드")
            sub("다운로드")
            reg("다운로드 진행 알림") { addToggle(
                R.drawable.ic_download, "다운로드 진행 알림",
                { if (prefs.notifyDownloadProgress) "받는 동안 알림창에 진행률을 보여 줘요" else "꺼져 있어요 · 앱 안 진행 카드만 보여요" },
                prefs.notifyDownloadProgress
            ) {
                prefs.notifyDownloadProgress = !prefs.notifyDownloadProgress
                if (prefs.notifyDownloadProgress) requestNotificationPermission()
                prefs.notifyDownloadProgress
            } }
            reg("다운로드 완료 알림") { addToggle(
                R.drawable.ic_download, "다운로드 완료 알림",
                { if (prefs.notifyDownloadDone) "앱을 벗어나 있을 때 다 받으면 알림으로 알려 줘요" else "꺼져 있어요 · 앱 안에서만 알려 줘요" },
                prefs.notifyDownloadDone
            ) {
                prefs.notifyDownloadDone = !prefs.notifyDownloadDone
                if (prefs.notifyDownloadDone) requestNotificationPermission()
                prefs.notifyDownloadDone
            } }
            reg("다운로드 완료 안내 (앱 안)") { addToggle(
                R.drawable.ic_download, "다운로드 완료 안내 (앱 안)",
                { if (prefs.notifyDownloadDoneInApp) "앱을 보고 있을 때 다 받으면 '열기' 안내가 떠요" else "꺼져 있어요 · 다 받아도 안내가 뜨지 않아요" },
                prefs.notifyDownloadDoneInApp
            ) {
                prefs.notifyDownloadDoneInApp = !prefs.notifyDownloadDoneInApp
                prefs.notifyDownloadDoneInApp
            } }
            reg("다운로드 실패 알림") { addToggle(
                R.drawable.ic_download, "다운로드 실패 알림",
                { if (prefs.notifyDownloadFailed) "받지 못했을 때 알림으로 알려 줘요" else "꺼져 있어요 · 실패해도 알림이 뜨지 않아요" },
                prefs.notifyDownloadFailed
            ) {
                prefs.notifyDownloadFailed = !prefs.notifyDownloadFailed
                if (prefs.notifyDownloadFailed) requestNotificationPermission()
                prefs.notifyDownloadFailed
            } }

            sub("앱 안 안내")
            reg("탭 닫기 되돌리기 안내") { addToggle(
                R.drawable.ic_tab, "탭 닫기 되돌리기 안내",
                { if (prefs.notifyTabUndo) "탭을 닫으면 '되돌리기' 안내가 떠요" else "꺼져 있어요 · 탭을 닫아도 안내가 뜨지 않아요" },
                prefs.notifyTabUndo
            ) {
                prefs.notifyTabUndo = !prefs.notifyTabUndo
                prefs.notifyTabUndo
            } }
            reg("삭제 실행 취소 안내") { addToggle(
                R.drawable.ic_delete, "삭제 실행 취소 안내",
                { if (prefs.notifyDeleteUndo) "북마크·기록을 지우면 '실행 취소' 안내가 떠요" else "꺼져 있어요 · 지워도 실행 취소 안내가 뜨지 않아요" },
                prefs.notifyDeleteUndo
            ) {
                prefs.notifyDeleteUndo = !prefs.notifyDeleteUndo
                prefs.notifyDeleteUndo
            } }
            reg("이동 차단 안내") { addToggle(
                R.drawable.ic_shield, "이동 차단 안내",
                { if (prefs.notifyRedirectBlocked) "다른 사이트로 가는 걸 막으면 안내와 '이동' 버튼이 떠요" else "꺼져 있어요 · 막아도 안내가 뜨지 않아요" },
                prefs.notifyRedirectBlocked
            ) {
                prefs.notifyRedirectBlocked = !prefs.notifyRedirectBlocked
                prefs.notifyRedirectBlocked
            } }

            sub("백그라운드")
            reg("AI 답변 받는 중 알림") { addToggle(
                R.drawable.ic_ai, "AI 답변 받는 중 알림",
                { if (prefs.notifyAiKeepAlive) "AI 답변을 받는 동안 조용한 알림을 띄워 앱이 꺼지지 않게 해요" else "꺼져 있어요 · 알림창에 보이지 않게 숨겨요" },
                prefs.notifyAiKeepAlive
            ) {
                prefs.notifyAiKeepAlive = !prefs.notifyAiKeepAlive
                prefs.notifyAiKeepAlive
            } }
            reg("미디어 컨트롤 알림") { addToggle(
                R.drawable.ic_play, "미디어 컨트롤 알림",
                { if (prefs.mediaControls) "알림창·잠금화면에서 재생 중인 영상을 조작할 수 있어요" else "꺼져 있어요 · 알림창에 재생 컨트롤이 뜨지 않아요" },
                prefs.mediaControls
            ) {
                prefs.mediaControls = !prefs.mediaControls
                mediaKey = ""
                pushKey = ""
                if (prefs.mediaControls) requestNotificationPermission()
                onMediaChanged()
                prefs.mediaControls
            } }
            reg("악성 사이트 경고 알림") { addToggle(
                R.drawable.ic_shield, "악성 사이트 경고 알림",
                { if (malwareWarning) "위험한 사이트에 접속하면 경고하고 막아요" else "꺼져 있어요 · 위험한 사이트도 경고 없이 열려요" },
                malwareWarning
            ) {
                toggleMalwareWarning()
                malwareWarning
            } }
            reg("시스템 알림 설정") { addKeepRow(
                R.drawable.ic_settings, "시스템 알림 설정",
                { if (notificationsAllowed()) "휴대폰 설정에서 소리·팝업·채널별로 바꿔요" else "지금 알림이 꺼져 있어요 · 눌러서 켜기" }
            ) { openSystemNotificationSettings() } }

            big("광고 차단", "광고 · 유튜브 광고 · 차단 현황")
            reg("광고 차단") { addToggle(
                R.drawable.ic_shield, "광고 차단",
                { "이 페이지 ${current?.adBlocked?.get() ?: 0}건 · 오늘 ${adBlocker.stats(0).today}건 차단됨" },
                adBlockEnabled
            ) {
                toggleAdBlock()
                adBlockEnabled
            } }
            reg("유튜브 광고 차단") { addToggle(
                R.drawable.ic_shield, "유튜브 광고 차단",
                { if (prefs.ytAdBlock) "유튜브 광고 칸을 숨기고 광고 영상은 바로 넘겨요" else "꺼져 있어요 · 일반 광고 차단과 따로 켜고 꺼요" },
                prefs.ytAdBlock
            ) {
                prefs.ytAdBlock = !prefs.ytAdBlock
                prefs.ytAdBlock
            } }
            reg("유튜브 광고 미리 지우기") { addToggle(
                R.drawable.ic_shield, "유튜브 광고 미리 지우기",
                { if (prefs.ytAdPrune) "영상 정보에서 광고를 빼서 광고가 시작되지 않게 해요" else "꺼져 있어요 · 광고가 나오면 넘기기·건너뛰기로 처리해요" },
                prefs.ytAdPrune
            ) {
                prefs.ytAdPrune = !prefs.ytAdPrune
                prefs.ytAdPrune
            } }
            reg("유튜브 광고 건너뛰기 자동 클릭") { addToggle(
                R.drawable.ic_shield, "유튜브 광고 건너뛰기 자동 클릭",
                { if (prefs.ytAutoSkip) "건너뛰기 버튼이 나오면 자동으로 눌러요" else "꺼져 있어요 · 건너뛰기는 직접 눌러야 해요" },
                prefs.ytAutoSkip
            ) {
                prefs.ytAutoSkip = !prefs.ytAutoSkip
                prefs.ytAutoSkip
            } }
            reg("광고 차단 현황") { addKeepRow(
                R.drawable.ic_shield, "광고 차단 현황",
                { "오늘 ${adBlocker.stats(0).today}건 · 전체 ${adBlocker.stats(0).total}건 차단" }
            ) { showAdBlockStats() } }
            reg("직접 선택한 광고 관리") { addKeepRow(
                R.drawable.ic_delete, "직접 선택한 광고 관리",
                { if (adBlocker.userRuleCount == 0) "아직 직접 고른 광고가 없어요" else "${adBlocker.userRuleCount}개 · 보기 · 삭제" }
            ) { showUserAdRules() } }
            reg("광고 차단 목록 업데이트") { addRow(
                R.drawable.ic_refresh, "광고 차단 목록 업데이트",
                "마지막 업데이트: ${AdBlockStatsUi.agoText(adBlocker.lastUpdated)}"
            ) { updateAdBlockList() } }

            big("보안", "악성 사이트 · HTTPS · 자동 이동 차단")
            reg("보안 현황") { addKeepRow(
                R.drawable.ic_shield, "보안 현황",
                { SecurityStatsUi.summary(securityToggles()) }
            ) { showSecurityStats() } }
            reg("악성 사이트 접속 알림") { addToggle(
                R.drawable.ic_shield, "악성 사이트 접속 알림",
                { "위험한 사이트에 접속하면 경고하고 막습니다" },
                malwareWarning
            ) {
                toggleMalwareWarning()
                malwareWarning
            } }
            reg("HTTPS 우선 연결") { addToggle(
                R.drawable.ic_lock, "HTTPS 우선 연결",
                { "http 주소도 먼저 보안 연결로 시도하고, 안 되면 허락을 구합니다" },
                httpsFirst
            ) {
                toggleHttpsFirst()
                httpsFirst
            } }
            reg("접속 차단 우회") { addToggle(
                R.drawable.ic_shield, "접속 차단 우회",
                { "차단된 사이트도 열 수 있게 DNS 를 암호화하고 연결 첫 패킷을 쪼개 보냅니다 (웹페이지에만 적용)" },
                prefs.sniBypass
            ) {
                toggleSniBypass()
                prefs.sniBypass
            } }
            reg("자동 다운로드 차단") { addToggle(
                R.drawable.ic_download, "자동 다운로드 차단",
                { "직접 누르지 않은 파일 다운로드를 막습니다" },
                blockAutoDownload
            ) {
                toggleBlockAutoDownload()
                blockAutoDownload
            } }
            reg("뒤로가기 중 자동 이동 차단") { addToggle(
                R.drawable.ic_back, "뒤로가기 중 자동 이동 차단",
                { "뒤로가기 직후 페이지가 스스로 다른 곳으로 보내는 것을 막습니다" },
                prefs.blockBackRedirect
            ) {
                prefs.blockBackRedirect = !prefs.blockBackRedirect
                toast(if (prefs.blockBackRedirect) "뒤로가기 중 자동 이동 차단 켜짐" else "뒤로가기 중 자동 이동 차단 꺼짐")
                prefs.blockBackRedirect
            } }
            reg("클릭 가로채기 이동 차단") { addToggle(
                R.drawable.ic_shield, "클릭 가로채기 이동 차단",
                { "링크가 아닌 곳을 눌렀는데 다른 사이트로 보내거나 새 탭을 여는 것을 막습니다" },
                hijackGuard
            ) {
                hijackGuard = !hijackGuard
                prefs.blockHijackNav = hijackGuard
                toast(if (hijackGuard) "클릭 가로채기 이동 차단 켜짐" else "클릭 가로채기 이동 차단 꺼짐")
                hijackGuard
            } }

            big("개인정보", "트래커 · 자동완성 · 기록 삭제")
            reg("트래커 차단 (엄격)") { addToggle(
                R.drawable.ic_shield, "트래커 차단 (엄격)",
                {
                    if (strictTrackers) "필요한 트래커만 허용 · ${trackerBlocker.blockedCount.get()}건 차단됨"
                    else "필요한 것 외 모든 트래커 차단 · 맞춤 광고가 줄어듭니다"
                },
                strictTrackers
            ) {
                toggleStrictTrackers()
                strictTrackers
            } }
            reg("캡차 건너뛰기") { addToggle(
                R.drawable.ic_lock, "캡차 건너뛰기",
                { "인증 데이터로 추적하지 못하게 함 · 자동 인증 지원 사이트에서만" },
                skipCaptchaTracking
            ) {
                toggleSkipCaptcha()
                skipCaptchaTracking
            } }
            reg("비밀번호·자동완성") { addToggle(
                R.drawable.ic_lock, "비밀번호·자동완성",
                { "로그인 정보 저장과 입력을 기기의 자동완성 서비스에 맡깁니다 · 시크릿 탭에서는 쓰지 않아요" },
                autofillEnabled
            ) {
                toggleAutofill()
                autofillEnabled
            } }
            reg("자동완성 서비스") { addRow(R.drawable.ic_phone, "자동완성 서비스", autofillServiceStatus()) { openAutofillSettings() } }
            reg("방문 기록·캐시·쿠키 삭제") { addRow(R.drawable.ic_delete, "방문 기록·캐시·쿠키 삭제") { clearBrowsingData() } }

            big("앱 정보", "버전 · 업데이트")
            reg("자동 업데이트") { addToggle(
                R.drawable.ic_download, "자동 업데이트",
                { if (Updater.autoEnabled(this@MainActivity)) "켜짐 · Wi-Fi 에서 새 버전을 받아 두었다가 앱을 떠날 때 설치해요" else "꺼짐 · 새 버전이 있으면 물어봐요" },
                Updater.autoEnabled(this@MainActivity)
            ) {
                Updater.setAutoEnabled(this@MainActivity, !Updater.autoEnabled(this@MainActivity))
                Updater.autoEnabled(this@MainActivity)
            } }
            reg("업데이트 확인") { addRow(R.drawable.ic_download, "업데이트 확인", "현재 버전 ${BuildConfig.VERSION_NAME}") { Updater.manualCheck(this@MainActivity) } }
            reg("업데이트 로그") { addRow(R.drawable.ic_history, "업데이트 로그", "버전별로 바뀐 내용 보기") { Changelog.show(this@MainActivity) } }

            // ───────── 그리기: 큰 묶음마다 둥근 블록으로 감싸고, 묶음 사이는 넉넉히 띄운다 ─────────
            val cSurface = ThemeColors.get(list, com.google.android.material.R.attr.colorSurface, 0)
            val cOn = ThemeColors.get(list, com.google.android.material.R.attr.colorOnSurface, 0)
            val cOnVar = ThemeColors.get(list, com.google.android.material.R.attr.colorOnSurfaceVariant, 0)

            val groupsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val resultsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            var groupsDirty = false

            // 카테고리 블록의 아이콘 / 항목 개수
            val bigIcons = mapOf(
                "브라우저" to R.drawable.ic_globe, "화면" to R.drawable.ic_dark, "미디어" to R.drawable.ic_play,
                "알림" to R.drawable.ic_bell, "광고 차단" to R.drawable.ic_shield, "보안" to R.drawable.ic_lock, "개인정보" to R.drawable.ic_incognito, "앱 정보" to R.drawable.ic_settings
            )
            fun countOf(big: String) = entries.count { it.kind == 2 && it.big == big }
            var searchRowRef: View? = null
            val menuScrollView = view.findViewById<android.widget.ScrollView>(R.id.menuScroll)
            lateinit var renderGroups: () -> Unit

            // 화면이 바뀔 때의 움직임: 새 내용이 옆에서 스프링으로 밀려 들어오고, 카드들이 차례로 떠오르며, 제목이 살짝 따라 바뀐다.
            fun playPage(forward: Boolean) {
                if (!Motion.enabled(this)) return
                val dir = if (forward) 1f else -1f
                groupsBox.translationX = dir * dp(30).toFloat()
                Motion.spring(groupsBox, DynamicAnimation.TRANSLATION_X, 0f, 380f, 0.85f)
                val items = if (openBig == null) groupsBox else (groupsBox.getChildAt(0) as? ViewGroup ?: groupsBox)
                for (i in 0 until items.childCount) Motion.enter(items.getChildAt(i), minOf(i * 28L, 260L), 12f)
                val t = view.findViewById<TextView>(R.id.menuTitle)
                t.alpha = 0f
                t.translationX = dir * dp(14).toFloat()
                Motion.spring(t, DynamicAnimation.ALPHA, 1f, 400f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                Motion.spring(t, DynamicAnimation.TRANSLATION_X, 0f, 400f, 0.85f)
            }

            // 카테고리 블록: 아이콘 · 이름 · 설명 · 개수 · 화살표. 누르면 그 카테고리의 하위 설정 창이 열린다.
            fun bigCard(e: SEntry): View {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    minimumHeight = dp(76)
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                    isClickable = true
                    isFocusable = true
                    background = GradientDrawable().apply {
                        cornerRadius = dp(24).toFloat()
                        setColor(cSurface)
                    }
                    foreground = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground)).let { ta ->
                        ta.getDrawable(0).also { ta.recycle() }
                    }
                    clipToOutline = true
                    contentDescription = "${e.title} 설정, ${countOf(e.title)}개 항목"
                }
                row.addView(ImageView(this).apply {
                    setImageResource(bigIcons[e.title] ?: R.drawable.ic_settings)
                    // 아이콘 타일 색도 글자색처럼 테마에서 가져온다 (XML 바탕은 ?attr 이 기본 초록으로 풀려 테마 아이콘색과 어긋났다)
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(ThemeColors.get(list, com.google.android.material.R.attr.colorPrimaryContainer, cSurface))
                    }
                    imageTintList = android.content.res.ColorStateList.valueOf(
                        ThemeColors.get(list, com.google.android.material.R.attr.colorOnPrimaryContainer, cOn)
                    )
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(14) })
                val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                texts.addView(TextView(this).apply {
                    text = e.title
                    textSize = 16.5f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(cOn)
                })
                if (e.desc.isNotEmpty()) texts.addView(TextView(this).apply {
                    text = e.desc
                    textSize = 12.5f
                    setTextColor(cOnVar)
                    setPadding(0, dp(2), 0, 0)
                })
                row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                Motion.pressable(row, 0.97f)
                row.setOnClickListener {
                    row.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                    openBig = e.title
                    renderGroups()
                    menuScrollView?.scrollTo(0, 0)
                    playPage(true)
                }
                return row
            }

            renderGroups = {
                groupsBox.removeAllViews()
                host = groupsBox; inBlock = false; card = null
                val ob = openBig
                if (ob == null) {
                    // ① 카테고리 목록
                    for (e in entries) if (e.kind == 0) {
                        groupsBox.addView(bigCard(e), LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { setMargins(dp(10), if (groupsBox.childCount == 0) dp(4) else 0, dp(10), dp(8)) })
                    }
                } else {
                    // ② 한 카테고리의 하위 설정 창
                    // 진한 회색 배경 없이 시트 배경 위에 흰 카드가 바로 놓이게 한다 (위치는 그대로)
                    val block = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(0, dp(4), 0, dp(8))
                    }
                    groupsBox.addView(block, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(dp(10), dp(4), dp(10), dp(8)) })
                    host = block; inBlock = true; card = null
                    var started = false
                    for (e in entries) when (e.kind) {
                        0 -> started = e.title == ob
                        1 -> if (started && e.title != ob) addHeader(e.title)
                        else -> if (started) e.add?.invoke()
                    }
                }
                trimDividers(groupsBox)
                groupsDirty = false
                // 제목 · ← 버튼 · 검색창을 지금 화면에 맞춘다
                view.findViewById<TextView>(R.id.menuTitle).text = ob ?: "설정"
                val backBtn = view.findViewById<View>(R.id.btnMenuBack)
                val wantBack = ob != null || backToMenu
                if (wantBack && backBtn.visibility != View.VISIBLE) {
                    backBtn.visibility = View.VISIBLE
                    if (Motion.enabled(this)) {
                        backBtn.alpha = 0f
                        Motion.spring(backBtn, DynamicAnimation.ALPHA, 1f, 400f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                    }
                } else if (!wantBack) backBtn.visibility = View.GONE
                searchRowRef?.let { sr ->
                    if (ob == null && sr.visibility != View.VISIBLE) {
                        sr.visibility = View.VISIBLE
                        if (Motion.enabled(this)) {
                            sr.alpha = 0f
                            Motion.spring(sr, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                        }
                    } else if (ob != null) sr.visibility = View.GONE
                }
            }
            settingsNav = {
                if (openBig != null) {
                    openBig = null
                    renderGroups()
                    menuScrollView?.scrollTo(0, 0)
                    playPage(false)
                    true
                } else false
            }

            // ───────── 검색 ─────────
            // 제목 + 같은 뜻의 낱말 + 소속 묶음 이름으로 찾는다. 'ㄱㄱ' 처럼 초성만 쳐도 찾는다.
            val keyMap = mapOf(
                "검색 엔진" to "구글 네이버 다음 덕덕고 빙 검색 주소창 google naver engine",
                "홈 페이지" to "시작 페이지 새 탭 홈 homepage home",
                "스크롤해서 상/하단바 숨기기" to "자동 숨김 스크롤 툴바 상단바 하단바 바 숨기기 전체화면",
                "블러 효과" to "흐림 유리 투명 반투명 성능 배터리 blur",
                "메뉴·팝업에도 테마 색 적용" to "테마 색 메뉴창 팝업 설정창 창 색 크롬 테마 확장 프로그램 theme",
                "북마크바 표시" to "즐겨찾기 북마크 줄 주소창 아래 툴바 bookmark bar favorites",
                "상/하단바 버튼 편집" to "툴바 버튼 순서 주소창 새로고침 뒤로 앞으로 홈 위치 배치 이동 꾸미기",
                "웹 페이지 다크 모드" to "어둡게 야간 밤 테마 다크 dark night 검정",
                "글자 크기" to "폰트 글씨 확대 크게 작게 텍스트 zoom",
                "탭을 끌어서 새 창 열기" to "탭 드래그 창 분리 멀티윈도우 분할 팝업 창",
                "모바일/데스크톱 자동 전환" to "pc 컴퓨터 폰 휴대폰 사이트 모드 데스크탑 ui 자동 창 크기 분할 화면 새로고침 desktop mobile auto",
                "재생 속도" to "배속 빠르게 느리게 영상 속도 playback speed",
                "백그라운드 재생" to "소리 화면 꺼짐 유튜브 음악 오디오 background",
                "시스템 미디어 플레이어에 표시" to "알림 잠금화면 미디어 컨트롤 알림창 재생 버튼",
                "다운로드 진행 알림" to "알림창 진행률 받는 중 퍼센트 notification",
                "다운로드 완료 알림" to "다 받음 완료 열기 알림 notification",
                "다운로드 완료 안내 (앱 안)" to "다 받음 열기 버튼 토스트 앱 안 알림",
                "다운로드 실패 알림" to "받지 못함 오류 실패 알림",
                "탭 닫기 되돌리기 안내" to "탭 닫음 복구 되돌리기 토스트",
                "삭제 실행 취소 안내" to "북마크 기록 지움 되돌리기 undo 토스트",
                "이동 차단 안내" to "리다이렉트 하이재킹 막음 이동 버튼 토스트",
                "AI 답변 받는 중 알림" to "ai 답변 백그라운드 유지 알림창 숨기기",
                "미디어 컨트롤 알림" to "알림 잠금화면 재생 버튼 알림창 영상 컨트롤",
                "악성 사이트 경고 알림" to "피싱 위험 사이트 경고 멀웨어 알림",
                "시스템 알림 설정" to "알림 권한 소리 팝업 채널 방해 금지 notification",
                "전체화면에서 아래로 밀어 나가기" to "제스처 스와이프 전체화면 나가기 영상",
                "영상 아래 버튼 표시" to "내장 플레이어 pip 버튼 영상 열기",
                "영상 못 찾으면 미러링" to "화면 복제 영상 감지 실패 내장 플레이어",
                "확장 프로그램" to "크롬 chrome extension 애드온 플러그인 crx zip 유저스크립트 userscript 추가 설치",
                "광고 차단" to "광고 팝업 배너 adblock 차단 켜기 끄기",
                "유튜브 광고 차단" to "유튜브 youtube 광고 숨기기 넘기기 차단 영상 켜기 끄기",
                "유튜브 광고 미리 지우기" to "유튜브 youtube 광고 데이터 제거 시작 안 되게 프리롤 차단",
                "유튜브 광고 건너뛰기 자동 클릭" to "유튜브 youtube 스킵 건너뛰기 자동 광고 영상",
                "광고 차단 현황" to "통계 차단 건수 오늘 전체",
                "직접 선택한 광고 관리" to "광고 규칙 수동 삭제 직접 고른 요소 숨기기",
                "광고 차단 목록 업데이트" to "필터 규칙 업데이트 갱신 목록",
                "업데이트 로그" to "변경 내역 버전 패치노트 릴리스 노트 바뀐 내용",
                "보안 현황" to "보안 점수 요약 상태 위협",
                "악성 사이트 접속 알림" to "피싱 위험 사이트 경고 멀웨어 악성코드 보호",
                "HTTPS 우선 연결" to "https 보안 연결 http 암호화 자물쇠",
                "자동 다운로드 차단" to "다운로드 자동 파일 몰래 차단",
                "뒤로가기 중 자동 이동 차단" to "리다이렉트 뒤로 가기 갇힘 돌아가기 못하게",
                "클릭 가로채기 이동 차단" to "리다이렉트 새 탭 팝업 클릭 낚시 하이재킹",
                "트래커 차단 (엄격)" to "추적 쿠키 맞춤 광고 프라이버시 개인정보 tracker",
                "캡차 건너뛰기" to "captcha 인증 로봇 사람 확인 추적",
                "비밀번호·자동완성" to "로그인 저장 암호 패스워드 자동 입력 autofill",
                "자동완성 서비스" to "비밀번호 관리자 구글 기기 설정 autofill 서비스",
                "방문 기록·캐시·쿠키 삭제" to "지우기 초기화 정리 데이터 삭제 캐시 쿠키 히스토리 개인정보"
            )
            // 함께 찾게 되는 설정끼리의 묶음: 검색 결과 아래 '관련 설정' 추천에 쓴다
            val clusters = listOf(
                listOf("광고 차단", "유튜브 광고 차단", "유튜브 광고 건너뛰기 자동 클릭", "광고 차단 현황", "직접 선택한 광고 관리", "광고 차단 목록 업데이트", "트래커 차단 (엄격)"),
                listOf("스크롤해서 상/하단바 숨기기", "상/하단바 버튼 편집", "북마크바 표시", "블러 효과", "메뉴·팝업에도 테마 색 적용"),
                listOf("웹 페이지 다크 모드", "글자 크기", "블러 효과"),
                listOf("다운로드 진행 알림", "다운로드 완료 알림", "다운로드 완료 안내 (앱 안)", "다운로드 실패 알림", "AI 답변 받는 중 알림", "미디어 컨트롤 알림", "악성 사이트 경고 알림", "시스템 알림 설정"),
                listOf("탭 닫기 되돌리기 안내", "삭제 실행 취소 안내", "이동 차단 안내"),
                listOf("재생 속도", "백그라운드 재생", "시스템 미디어 플레이어에 표시", "전체화면에서 아래로 밀어 나가기", "영상 아래 버튼 표시", "영상 못 찾으면 미러링"),
                listOf("보안 현황", "악성 사이트 접속 알림", "HTTPS 우선 연결", "자동 다운로드 차단", "뒤로가기 중 자동 이동 차단", "클릭 가로채기 이동 차단"),
                listOf("비밀번호·자동완성", "자동완성 서비스", "방문 기록·캐시·쿠키 삭제", "캡차 건너뛰기", "트래커 차단 (엄격)"),
                listOf("검색 엔진", "홈 페이지", "모바일/데스크톱 자동 전환"),
                listOf("탭을 끌어서 새 창 열기", "상/하단바 버튼 편집")
            )
            val popular = listOf("검색 엔진", "광고 차단", "웹 페이지 다크 모드", "백그라운드 재생", "상/하단바 버튼 편집")
            val choseong = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
            fun chosungOf(t: String): String = buildString {
                for (ch in t) {
                    if (ch in '가'..'힣') append(choseong[(ch - '가') / 588])
                    else if (!ch.isWhitespace()) append(ch.lowercaseChar())
                }
            }
            fun isJamo(t: String) = t.isNotEmpty() && t.all { it in 'ㄱ'..'ㅎ' }
            fun tokenScore(e: SEntry, t: String): Int {
                if (isJamo(t)) return if (chosungOf(e.title).contains(t)) 3 else 0
                val title = e.title.lowercase()
                if (title.contains(t)) return 3
                if ((keyMap[e.title] ?: "").lowercase().contains(t)) return 2
                if ((e.big + " " + e.sub).lowercase().contains(t)) return 1
                return 0
            }

            fun renderResults(query: String) {
                resultsBox.removeAllViews()
                host = resultsBox; inBlock = false; card = null
                val items = entries.filter { it.kind == 2 }
                val tokens = query.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
                // 모든 낱말이 맞는 것을 먼저, 하나도 없으면 하나라도 맞는 것을 보여 준다
                var scored = items.map { e -> e to tokens.map { tokenScore(e, it) } }
                    .filter { (_, sc) -> sc.all { it > 0 } }
                    .map { (e, sc) -> e to sc.sum() }
                if (scored.isEmpty()) scored = items.map { e -> e to tokens.sumOf { tokenScore(e, it) } }.filter { it.second > 0 }
                val matches = scored.sortedByDescending { it.second }.map { it.first }
                val related: List<SEntry>
                if (matches.isEmpty()) {
                    resultsBox.addView(TextView(this).apply {
                        text = "'$query' 와 맞는 설정이 없어요\n다른 낱말로 찾아보거나 아래 설정을 둘러보세요"
                        textSize = 14f
                        setTextColor(cOnVar)
                        setLineSpacing(dp(3).toFloat(), 1f)
                        setPadding(dp(28), dp(14), dp(22), dp(4))
                    })
                    related = popular.mapNotNull { t -> items.firstOrNull { it.title == t } }
                    if (related.isNotEmpty()) addHeader("자주 찾는 설정")
                } else {
                    addHeader("검색 결과 ${matches.size}개")
                    matches.forEach { it.add?.invoke() }
                    // 찾은 설정과 같은 묶음에 있거나 같은 소제목 아래 있는 다른 설정을 추천한다
                    val have = matches.map { it.title }.toSet()
                    val points = LinkedHashMap<String, Int>()
                    for (m in matches) {
                        for (c in clusters) if (m.title in c) for (t in c) if (t !in have) points[t] = (points[t] ?: 0) + 2
                        for (o in items) if (o.title !in have && o.sub.isNotEmpty() && o.sub == m.sub) points[o.title] = (points[o.title] ?: 0) + 1
                    }
                    related = points.entries.sortedByDescending { it.value }.take(4)
                        .mapNotNull { en -> items.firstOrNull { it.title == en.key } }
                    if (related.isNotEmpty()) addHeader("관련 설정")
                }
                related.forEach { it.add?.invoke() }
                trimDividers(resultsBox)
                groupsDirty = true
            }

            // ───────── 맨 위 검색창 ─────────
            val searchRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(26).toFloat()
                    setColor(cSurface)
                }
                setPadding(dp(16), 0, dp(4), 0)
            }
            searchRow.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_search)
                imageTintList = android.content.res.ColorStateList.valueOf(cOnVar)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }, LinearLayout.LayoutParams(dp(20), dp(20)))
            val searchEdit = android.widget.EditText(this).apply {
                hint = "설정 검색"
                setHintTextColor((cOnVar and 0x00FFFFFF) or 0xAA000000.toInt())
                setTextColor(cOn)
                textSize = 15f
                background = null
                setSingleLine(true)
                inputType = android.text.InputType.TYPE_CLASS_TEXT
                imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
                setPadding(dp(12), dp(14), dp(8), dp(14))
                contentDescription = "설정 검색"
            }
            searchRow.addView(searchEdit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val clearBtn = ImageButton(this).apply {
                setImageResource(R.drawable.ic_close)
                imageTintList = android.content.res.ColorStateList.valueOf(cOnVar)
                setBackgroundResource(borderlessBgRes())
                contentDescription = "검색어 지우기"
                visibility = View.GONE
                setOnClickListener { searchEdit.setText("") }
            }
            searchRow.addView(clearBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
            searchEdit.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val q = s?.toString()?.trim().orEmpty()
                    clearBtn.visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
                    view.findViewById<android.widget.ScrollView>(R.id.menuScroll)?.scrollTo(0, 0)
                    if (q.isEmpty()) {
                        resultsBox.visibility = View.GONE
                        // 검색 결과에서 켜고 끈 항목이 있을 수 있으니 묶음 화면을 새로 그린다
                        if (groupsDirty) renderGroups()
                        groupsBox.visibility = View.VISIBLE
                    } else {
                        groupsBox.visibility = View.GONE
                        resultsBox.visibility = View.VISIBLE
                        renderResults(q)
                    }
                }
            })
            searchEdit.setOnEditorActionListener { v, actionId, _ ->
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
                    true
                } else false
            }
            searchRowRef = searchRow
            list.addView(searchRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(14), dp(4), dp(14), dp(6)) })
            list.addView(groupsBox)
            list.addView(resultsBox)
            settingsReopenBig?.let { openBig = it; settingsReopenBig = null }
            renderGroups()
        }

        // 카드의 마지막 항목 아래 구분선은 지운다 (묶음 블록·검색 결과 칸 안의 카드도 찾아서)
        trimDividers(list)

        if (sheet != null) {
            if (settings) {
                sheet.onBackPressedDispatcher.addCallback(sheet, object : OnBackPressedCallback(true) {
                    override fun handleOnBackPressed() {
                        // 하위 설정 창이면 카테고리 목록으로, 아니면 (메뉴에서 왔으면) 메뉴로, 아니면 닫기
                        if (settingsNav?.invoke() == true) return
                        dismissMenu()
                        if (backToMenu) showMenu(anchor)
                    }
                })
            }
            // (아래로 내려서 닫기·바깥 누름은 메뉴로 돌아가지 않고 그냥 닫힌다. ← 버튼과 뒤로가기만 메뉴로 돌아간다)
            sheet.setContentView(view)
            if (settings) sheet.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            sheet.behavior.maxWidth = dp(600)
            // 내려서 닫기는 목록이 맨 위에 있을 때만: 스크롤이 내려가 있으면 시트가 따라 내려오지 않고 목록만 스크롤된다
            view.findViewById<android.widget.ScrollView>(R.id.menuScroll)?.let { sv ->
                val b = sheet.behavior
                b.isDraggable = sv.scrollY <= 0
                sv.setOnScrollChangeListener { _, _, y, _, _ -> b.isDraggable = y <= 0 }
            }
            Motion.stagger(list, 90, 32, 360)
            // 뒤 페이지를 흐리게 + 시트를 반투명 유리처럼 (Android 12+ 에서 지원될 때만)
            // 시트 색은 태블릿 메뉴 팝업과 같은 colorSurfaceContainer 로 맞춘다 (블러 여부와 상관없이)
            val glass = Blur.behind(sheet.window, this)
            sheet.setOnShowListener {
                sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
                // 시트가 처음 배치될 때 기본 배경을 입히므로, 그 뒤에 같은 색의 배경으로 바꾼다
                sheet.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.let { v ->
                    v.post {
                        val r = dp(28).toFloat()
                        v.background = if (glass) {
                            Blur.glass(
                                this, com.google.android.material.R.attr.colorSurfaceContainer, r, topOnly = true
                            )
                        } else {
                            GradientDrawable().apply {
                                setColor(Blur.surface(this@MainActivity, com.google.android.material.R.attr.colorSurfaceContainer, false))
                                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                            }
                        }
                    }
                }
            }
            sheet.show()
            if (!settings) view.post {
                view.findViewById<View>(R.id.menuScroll)?.height?.takeIf { it > 0 }?.let { menuScrollH[0] = it }
            }
            return
        }

        // 태블릿: 버튼 바로 아래, 버튼의 오른쪽 끝에 맞춰 뜨는 둥근 카드 팝업
        val anchorView = anchor ?: return
        // 팝업 창·프리폼 창에서도 맞도록 위치는 창 안 좌표(getLocationInWindow)와 창 크기로 계산한다
        val screenW = anchorView.rootView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val screenH = anchorView.rootView.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        val width = minOf(dp(360), screenW - dp(16))
        val loc = IntArray(2)
        anchorView.getLocationInWindow(loc)
        val locScreen = IntArray(2)
        anchorView.getLocationOnScreen(locScreen)
        val below = loc[1] + anchorView.height
        val maxH = (screenH - below - dp(12)).coerceAtLeast(dp(240))
        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val height = minOf(view.measuredHeight, maxH)
        val bg = Popup.anchoredBackground(this, view)
        val pw = PopupWindow(view, width, height, true).apply {
            setBackgroundDrawable(bg)
            isOutsideTouchable = true
            elevation = dp(Popup.ANCHORED_ELEVATION_DP).toFloat()
            animationStyle = R.style.Evergreen_MenuPopupAnim
            // 설정의 검색창에 글자를 칠 수 있게 (키보드가 뜨면 목록이 줄어든다)
            if (settings) {
                inputMethodMode = PopupWindow.INPUT_METHOD_NEEDED
                softInputMode = android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }
        }
        popup = pw
        Popup.track(pw)
        // 팝업 오른쪽 끝에서 앱 창의 오른쪽 가장자리까지의 좁은 띠(팝업과 같은 높이)는 눌러도 반응하지 않게 한다
        run {
            val gapRight = screenW - (wantLeftForZone(loc, anchorView, width, screenW) + width)
            if (gapRight in 1..dp(48)) {
                val originX = locScreen[0] - loc[0]
                val originY = locScreen[1] - loc[1]
                val zone = Rect(
                    originX + screenW - gapRight, originY + below - dp(4),
                    originX + screenW, originY + screenH
                )
                menuDeadZone = zone
                menuDeadZonePopup = java.lang.ref.WeakReference(pw)
                var swallow = false
                pw.setTouchInterceptor { _, ev ->
                    // 팝업은 바깥 터치를 두 가지로 받는다: (1) 팝업 창이 화면 전체 터치를 받는 경우엔 범위 밖 좌표의 ACTION_DOWN,
                    // (2) 아닌 경우엔 ACTION_OUTSIDE. 둘 다 이 띠 안이면 삼켜서 팝업이 닫히지 않게 한다
                    val inZone = zone.contains(ev.rawX.toInt(), ev.rawY.toInt())
                    when (ev.actionMasked) {
                        MotionEvent.ACTION_OUTSIDE -> inZone
                        MotionEvent.ACTION_DOWN -> { swallow = inZone; swallow }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { val r = swallow; swallow = false; r }
                        else -> swallow
                    }
                }
            } else {
                menuDeadZone = null
            }
        }
        if (settings) {
            // 설정 팝업이 우리가 닫은 게 아니면(뒤로가기·바깥 누름):
            // 하위 설정 창에서는 설정(카테고리 목록)으로, 설정 첫 화면에서는 (메뉴에서 왔으면) 메뉴로 돌아간다
            pw.setOnDismissListener {
                if (!closedByUs && !isFinishing && !isDestroyed && !isChangingConfigurations) {
                    if (openBig != null) showMenu(anchor, settings = true, fromMenu = backToMenu)
                    else if (backToMenu) showMenu(anchor)
                }
            }
        }
        // 북마크 / 방문 기록 / 다운로드 팝업이 이 메뉴와 같은 자리에 뜨도록 기억해 둔다
        menuAnchorRight = locScreen[0] + anchorView.width   // 다른 창(목록 팝업)에 넘기는 값이라 화면 좌표
        menuAnchorBottom = locScreen[1] + anchorView.height
        menuAnchorWinRight = loc[0] + anchorView.width      // 앱 창 안 좌표 (목록 팝업의 위치 계산용)
        menuAnchorWinBottom = loc[1] + anchorView.height
        // 버튼의 오른쪽 끝에 맞추되 화면 밖으로는 나가지 않게
        val wantLeft = (loc[0] + anchorView.width - width).coerceIn(dp(8), (screenW - width - dp(8)).coerceAtLeast(dp(8)))
        Popup.prepareAnchoredEnter(view, loc[0] + anchorView.width / 2f - wantLeft, width)
        pw.showAsDropDown(anchorView, wantLeft - loc[0], dp(4))
        Blur.behindPopup(pw, this)
        Popup.playAnchoredEnter(view, list)
        if (!settings) view.post {
            view.findViewById<View>(R.id.menuScroll)?.height?.takeIf { it > 0 }?.let { menuScrollH[1] = it }
        }
    }

    /**
     * UA 문자열과 Client Hints(Sec-CH-UA)를 함께 바꾼다.
     * WebView 는 UA 에서 "wv"를 지워도 Sec-CH-UA / navigator.userAgentData 에 "Android WebView" 브랜드를 실어 보내서,
     * 구글이 "브라우저 또는 앱이 안전하지 않을 수 있습니다"로 로그인을 막는다. 브랜드를 일반 Chrome 으로 맞춘다.
     */
    private fun applyUserAgent(wv: WebView, desktop: Boolean) {
        wv.settings.userAgentString = if (desktop) desktopUserAgent() else mobileUserAgent()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) return
        try {
            val full = Regex("Chrome/([\\d.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
            val major = full.substringBefore('.')
            val brands = listOf(
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Not)A;Brand").setMajorVersion("99").setFullVersion("99.0.0.0").build(),
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Chromium").setMajorVersion(major).setFullVersion(full).build(),
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Google Chrome").setMajorVersion(major).setFullVersion(full).build()
            )
            val md = androidx.webkit.UserAgentMetadata.Builder()
                .setBrandVersionList(brands)
                .setFullVersion(full)
                .setPlatform(if (desktop) "Linux" else "Android")
                .setPlatformVersion(if (desktop) "6.5.0" else (Build.VERSION.RELEASE + ".0.0"))
                .setMobile(!desktop)
                .setModel(if (desktop) "" else Build.MODEL)
                .setArchitecture(if (desktop) "x86" else "")
                .setBitness(if (desktop) 64 else 0)
                .build()
            WebSettingsCompat.setUserAgentMetadata(wv.settings, md)
        } catch (e: Exception) {
            // 지원하지 않는 WebView 면 UA 문자열 변경만 적용
        }
    }

    private fun mobileUserAgent(): String =
        baseUserAgent.replace("; wv", "").replace(" Version/4.0", "")

    private fun desktopUserAgent(): String {
        val ver = Regex("Chrome/([\\d.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$ver Safari/537.36"
    }

    /** PC용 화면 폭으로 레이아웃되도록 viewport 를 덮어쓴다. (UA 만 바꿔서는 모바일 폭으로 그려지는 사이트가 많음) */
    private fun desktopViewportJs(): String {
        val w = maxOf(webAreaWidthDp(), 1024)
        return "(function(){var m=document.querySelector('meta[name=viewport]');" +
            "if(!m){m=document.createElement('meta');m.name='viewport';" +
            "(document.head||document.documentElement).appendChild(m);}" +
            "m.setAttribute('content','width=$w,');" +
            "(function(m){requestAnimationFrame(function(){m.setAttribute('content','width=$w');});})(m);})();"
    }

    /** m.example.com / en.m.wikipedia.org 같은 모바일 전용 주소를 PC 주소로 바꾼다. */
    private fun toDesktopUrl(url: String): String {
        val host = Uri.parse(url).host ?: return url
        val newHost = when {
            host.startsWith("m.") -> {
                val rest = host.removePrefix("m.")
                if (rest.count { it == '.' } >= 2) rest else "www.$rest"
            }
            host.contains(".m.") -> host.replaceFirst(".m.", ".")
            else -> host
        }
        return if (newHost == host) url else url.replaceFirst(host, newHost)
    }

    /** 태블릿 툴바의 데스크톱/모바일 버튼: 지금 모드가 아니라 '누르면 바뀔 모드'를 아이콘으로 보여준다. */
    private fun updateDesktopButton() {
        val desktop = current?.desktop == true
        // 모니터 ↔ 폰: 아이콘을 바꿔 끼우지 않고 모양이 스프링으로 변한다
        val shape = if (desktop) 1f else 0f
        (tbDesktop.drawable as? MorphIconDrawable)?.settle(shape, tbDesktop.isShown && Motion.enabled(this))
            ?: tbDesktop.setImageResource(if (desktop) R.drawable.ic_phone else R.drawable.ic_desktop)
        tbDesktop.contentDescription = if (desktop) "모바일 사이트로 보기" else "데스크톱 사이트로 보기"
        bottomExtraViews["desktop"]?.let { b ->
            (b.drawable as? MorphIconDrawable)?.settle(shape, b.isShown && Motion.enabled(this))
                ?: b.setImageResource(if (desktop) R.drawable.ic_phone else R.drawable.ic_desktop)
            b.contentDescription = tbDesktop.contentDescription
        }
    }

    private fun toggleDesktopSite() {
        val tab = current ?: return
        val on = !tab.desktop
        // 직접 고른 것이므로 '폰 화면이라 자동으로 모바일' 상태는 끝낸다
        autoMobile = false
        // 한 번 켜면 모든 탭·새 탭·앱을 다시 켠 뒤에도 유지된다 (끄기 전까지).
        prefs.desktopSite = on
        for (t in tabs) {
            t.desktop = on
            t.desktopInjected = false
            t.liveWebView?.let { applyUserAgent(it, on) }
        }
        updateDesktopButton()

        val url = tab.webView.url
        if (tab.isHome || url == null || url == "about:blank" || url == HOME_URL) {
            toast(if (tab.desktop) "데스크톱 모드: 이 탭에서 여는 페이지부터 적용됩니다" else "모바일 모드로 돌아갑니다")
            return
        }
        val target = if (tab.desktop && url.startsWith("http")) toDesktopUrl(url) else url
        carryPlaybackPosition(tab, target)
        if (target != url) tab.webView.loadUrl(target) else reloadTab(tab)
        toast(if (tab.desktop) "데스크톱 사이트로 다시 불러옵니다" else "모바일 사이트로 다시 불러옵니다")
    }

    private fun toggleHideBarsOnScroll() {
        prefs.hideBarsOnScroll = !prefs.hideBarsOnScroll
        for (a in instances) a.resetScrollBars()
        toast(if (prefs.hideBarsOnScroll) "스크롤하면 바 숨김 켜짐" else "스크롤하면 바 숨김 꺼짐")
    }

    /** 스크롤로 숨겨져 있던 바를 바로 원래대로 돌려 놓는다 (기능을 끄거나 고정 숨김을 켤 때) */
    private fun resetScrollBars() {
        scrollBars.reset()
        ui.post { scrollBars.sync() }
    }

    private fun toggleHideBars() {
        prefs.hideBars = !prefs.hideBars
        if (prefs.hideBars) for (a in instances) a.resetScrollBars()
        barsTempShown = false
        // 다른 창(여러 창 모드)에도 같은 설정이 적용되도록 모두 갱신
        for (a in instances) a.applyHideBars()
        toast(if (prefs.hideBars) "상/하단바 숨김 켜짐" else "상/하단바 숨김 꺼짐")
    }

    private fun groupCurrentTab() {
        val tab = current ?: return
        showGroupEditor(null) { name, color ->
            moveToGroup(tab, createGroup(name, color))
            // 상단 탭줄(그룹 알약·색 막대)과 탭 전환 화면을 다시 그린다
            scheduleStripRefresh()
            if (switcherOpen) refreshSwitcher(false)
            toast("'$name' 그룹에 추가했습니다")
        }
    }

    // ───────────────────────── 스크롤 시 바 숨김 ─────────────────────────
    // 바를 움직이는 일은 모두 ScrollBarsController 가 한다. 여기서는 페이지 스크롤 위치만 기록한다.

    private fun onPageScroll(tab: BrowserTab, y: Int, oldY: Int) {
        if (tab === current) pageScrollBar.refresh()
        // 창 크기가 바뀌는 중에 내용이 다시 배치되며 생기는 스크롤은 '사용자가 옮긴 위치'가 아니므로 기록하지 않는다
        if (resizeBurst) return
        tab.scrollRatio = scrollRatioOf(tab.liveWebView)
        // 위로 스크롤해서(관성 포함) 맨 위에 닿으면 바를 다시 보여 준다
        if (tab === current && y <= dp(8) && y < oldY) scrollBars.show()
    }

    private fun barsResync() {
        browserUi.requestLayout()
        webContainer.requestLayout()
        browserUi.invalidate()
        webContainer.invalidate()
        pageScrollBar.refresh()
        current?.webView?.let { wv ->
            wv.requestLayout()
            wv.invalidate()
            wv.post {
                if (wv.parent === webContainer) {
                    wv.requestLayout()
                    wv.invalidate()
                    wv.postInvalidateOnAnimation()
                    pageScrollBar.refresh()
                }
            }
        }
    }

    /** 탭의 웹뷰에 보안 설정(Safe Browsing, 서드파티 쿠키)을 적용한다. */
    private fun applySecurity(wv: WebView, tab: BrowserTab? = null) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
            WebSettingsCompat.setSafeBrowsingEnabled(wv.settings, malwareWarning)
        }
        // 서드파티 쿠키를 막으면 인증(캡차) 제공업체가 사이트 간에 나를 따라다니며 추적하기 어렵다.
        cookieManagerFor(tab).setAcceptThirdPartyCookies(wv, !skipCaptchaTracking)
    }

    private fun toggleStrictTrackers() {
        strictTrackers = !strictTrackers
        prefs.strictTrackers = strictTrackers
        toast(if (strictTrackers) "트래커 차단(엄격) 켜짐" else "트래커 차단(엄격) 꺼짐")
        current?.let { reloadTab(it) }
    }

    private fun toggleSkipCaptcha() {
        skipCaptchaTracking = !skipCaptchaTracking
        prefs.skipCaptchaTracking = skipCaptchaTracking
        tabs.forEach { t -> t.liveWebView?.let { applySecurity(it, t) } }
        toast(if (skipCaptchaTracking) "캡차 건너뛰기 켜짐 (지원 사이트에서만 동작)" else "캡차 건너뛰기 꺼짐")
    }

    private fun toggleMalwareWarning() {
        malwareWarning = !malwareWarning
        prefs.malwareWarning = malwareWarning
        tabs.forEach { t -> t.liveWebView?.let { applySecurity(it, t) } }
        toast(if (malwareWarning) "악성 사이트 알림 켜짐" else "악성 사이트 알림 꺼짐")
    }

    private fun toggleBlockAutoDownload() {
        blockAutoDownload = !blockAutoDownload
        prefs.blockAutoDownload = blockAutoDownload
        toast(if (blockAutoDownload) "자동 다운로드 차단 켜짐" else "자동 다운로드 차단 꺼짐")
    }

    private fun toggleAdBlock() {
        adBlockEnabled = !adBlockEnabled
        prefs.adBlock = adBlockEnabled
        toast(if (adBlockEnabled) "광고 차단 켜짐" else "광고 차단 꺼짐")
        current?.let { reloadTab(it) }
    }

    private fun securityToggles() = SecurityStatsUi.Toggles(
        adBlock = adBlockEnabled,
        malware = malwareWarning,
        https = httpsFirst,
        autoDownload = blockAutoDownload,
        backRedirect = prefs.blockBackRedirect,
        hijack = hijackGuard,
        strictTrackers = strictTrackers,
        skipCaptcha = skipCaptchaTracking
    )

    private var securityDialog: android.app.Dialog? = null

    /** @param origin 새 탭 화면 위젯에서 열 때 그 카드: 카드가 펼쳐져 현황 창이 되고, 닫으면 다시 카드로 접힌다 */
    private fun showSecurityStats(origin: View? = null) {
        if (securityDialog?.isShowing == true) return
        securityDialog = SecurityStatsUi.show(this, securityToggles(), origin)
    }

    private var adStatsDialog: android.app.Dialog? = null

    /** @param origin 새 탭 화면 위젯에서 열 때 그 카드: 카드가 펼쳐져 현황 창이 되고, 닫으면 다시 카드로 접힌다 */
    private fun showAdBlockStats(origin: View? = null) {
        // 카드가 펼쳐지는 중에 또 눌러도 창이 겹쳐 뜨지 않게
        if (adStatsDialog?.isShowing == true) return
        val tab = current
        adStatsDialog = AdBlockStatsUi.show(
            ctx = this,
            blocker = adBlocker,
            enabled = adBlockEnabled,
            pageBlocked = if (tab == null || tab.isHome) null else tab.adBlocked.get(),
            onUpdate = { updateAdBlockList() },
            origin = origin
        )
    }

    /** 설정 > 광고 직접 선택: 지금 보는 페이지를 선택 모드로 바꾼다 */
    private fun startAdPicker() {
        val tab = current
        if (tab == null || tab.isHome || tab.errorUrl != null) {
            toast("먼저 광고가 있는 페이지를 열어 주세요")
            return
        }
        if (!adBlockEnabled) {
            toast("광고 차단을 먼저 켜 주세요")
            return
        }
        // 메뉴는 이미 닫혔다. 페이지 안에 선택 화면(안내 막대)이 뜨고, 누르는 요소가 빨갛게 표시된다
        tab.webView.evaluateJavascript(AdScripts.PICKER_JS, null)
        toast("차단할 광고를 눌러 주세요")
    }

    private fun showUserAdRules() {
        AdBlockUserRulesUi.show(this, adBlocker, false) {
            // 삭제한 규칙은 새로 불러와야 화면에 되살아난다
            current?.let { if (!it.isHome) reloadTab(it) }
        }
    }

    private fun updateAdBlockList() {
        toast("차단 목록을 내려받는 중…")
        io.execute {
            try {
                val n = adBlocker.update()
                ui.post { toast("차단 목록 적용 완료 (${n}개 도메인)") }
            } catch (e: Exception) {
                ui.post { toast("업데이트 실패: ${e.message}") }
            }
        }
    }

    private fun showEngineDialog() {
        val engines = prefs.allEngines()
        val selected = engines.indexOfFirst { it.key == prefs.engineKey }.coerceAtLeast(0)
        val hasCustom = engines.any { it.custom }
        val labels = ArrayList<String>()
        engines.forEach { labels.add(if (it.custom) it.name + "  (직접 추가)" else it.name) }
        labels.add("＋ 검색엔진 추가")
        if (hasCustom) labels.add("추가한 검색엔진 삭제…")
        ThemedDialogBuilder(this)
            .setTitle("검색 엔진")
            .setSingleChoiceItems(labels.toTypedArray(), selected) { d, which ->
                d.dismiss()
                when {
                    which < engines.size -> {
                        prefs.engineKey = engines[which].key
                        refreshSettingsAfterEngine()
                    }
                    which == engines.size -> showAddEngineDialog()
                    else -> showRemoveEngineDialog()
                }
            }
            .show()
    }

    /** 홈 버튼을 눌렀을 때 열 홈 페이지를 정한다. 비워 두고 저장하면 기본(새 탭 화면)으로 돌아간다 */
    private fun showHomepageDialog() {
        val et = EditText(this).apply {
            setText(prefs.homepage)
            hint = "https://www.example.com"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSelection(text.length)
        }
        val cb = android.widget.CheckBox(this).apply {
            text = "새 탭에서도 이 페이지 열기"
            isChecked = prefs.homepageOnNewTab
        }
        val help = TextView(this).apply {
            text = "홈 버튼을 누르면 이 주소가 열려요. 비워 두면 기본 새 탭 화면을 써요."
            textSize = 12f
            alpha = 0.7f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(et)
            addView(help, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
            addView(cb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        fun save() {
            var u = et.text.toString().trim()
            if (u.isNotEmpty() && !u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
            prefs.homepage = u
            prefs.homepageOnNewTab = cb.isChecked && u.isNotEmpty()
            toast(if (u.isEmpty()) "홈 페이지: 기본 (새 탭 화면)" else "홈 페이지를 저장했어요")
        }
        val dlg = ThemedDialogBuilder(this)
            .setTitle("홈 페이지")
            .setView(box)
            .setNegativeButton("취소", null)
            .setNeutralButton("기본값") { _, _ ->
                prefs.homepage = ""
                prefs.homepageOnNewTab = false
                toast("홈 페이지: 기본 (새 탭 화면)")
            }
            .setPositiveButton("저장") { _, _ -> save() }
            .create()
        et.setOnEditorActionListener { _, _, _ -> save(); dlg.dismiss(); true }
        dlg.show()
        et.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** 설정 화면이 떠 있어도 '현재: …' 글자가 바뀌어 보이게 한다 */
    private fun refreshSettingsAfterEngine() {
        toast("검색 엔진: ${prefs.currentEngine().name}")
    }

    /** 검색엔진 직접 추가: 이름 + 검색 주소. 주소에서 검색어 자리는 %s 로 적는다 */
    private fun showAddEngineDialog() {
        val etName = EditText(this).apply {
            hint = "이름 (예: 쿠팡)"
            setSingleLine()
            filters = arrayOf(android.text.InputFilter.LengthFilter(20))
        }
        val etUrl = EditText(this).apply {
            hint = "https://www.coupang.com/np/search?q=%s"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val help = TextView(this).apply {
            text = "검색 주소에서 검색어가 들어갈 자리를 %s 로 적어 주세요.\n" +
                "(예: https://www.google.com/search?q=%s)\n" +
                "사이트에서 아무거나 검색한 뒤 주소창의 주소를 복사해서, 검색어 부분만 %s 로 바꾸면 돼요."
            textSize = 12f
            alpha = 0.7f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(etName)
            addView(etUrl)
            addView(help, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        val dlg = ThemedDialogBuilder(this)
            .setTitle("검색엔진 추가")
            .setView(box)
            .setNegativeButton("취소", null)
            .setPositiveButton("추가", null)
            .create()
        dlg.setOnShowListener {
            ThemeColors.skinDialog(dlg)
            dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = etName.text.toString().trim()
                var url = etUrl.text.toString().trim()
                val err = when {
                    name.isEmpty() -> "이름을 입력해 주세요"
                    url.isEmpty() -> "검색 주소를 입력해 주세요"
                    else -> null
                }
                if (err != null) { toast(err); return@setOnClickListener }
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                // %s / {searchTerms} / {q} 중 어느 것으로 적어도 받아 준다
                val marker = listOf("%s", "{searchTerms}", "{query}", "{q}").firstOrNull { url.contains(it) }
                if (marker == null) { toast("검색어가 들어갈 자리를 %s 로 적어 주세요"); return@setOnClickListener }
                val idx = url.indexOf(marker)
                val prefix = url.substring(0, idx)
                val suffix = url.substring(idx + marker.length)
                val host = Uri.parse(url.replace(marker, "x")).let { u ->
                    if (u.scheme != null && !u.host.isNullOrEmpty()) "${u.scheme}://${u.host}" else null
                }
                if (host == null) { toast("주소 형식이 올바르지 않아요"); return@setOnClickListener }
                val key = "custom_" + System.currentTimeMillis()
                prefs.addCustomEngine(SearchEngine(key, name, prefix, host, suffix, true))
                prefs.engineKey = key
                dlg.dismiss()
                toast("검색엔진을 추가했어요: $name")
            }
        }
        dlg.show()
        etName.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** 직접 추가한 검색엔진 지우기 */
    private fun showRemoveEngineDialog() {
        val customs = prefs.customEngines()
        if (customs.isEmpty()) return
        ThemedDialogBuilder(this)
            .setTitle("삭제할 검색엔진")
            .setItems(customs.map { it.name }.toTypedArray()) { _, which ->
                val e = customs[which]
                Popup.confirm(this, "검색엔진 삭제", "'${e.name}' 검색엔진을 삭제할까요?", "삭제", danger = true) {
                    prefs.removeCustomEngine(e.key)
                    toast("삭제했어요")
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    /** 삭제하기 전에 한 번 더 물어본다 */
    private fun clearBrowsingData() {
        Popup.confirm(
            this,
            "방문 기록·캐시·쿠키 삭제",
            "방문 기록, 캐시, 쿠키와 사이트 저장 데이터를 모두 삭제할까요?\n\n" +
                "로그인된 사이트에서 로그아웃될 수 있고, 삭제한 데이터는 되돌릴 수 없어요.",
            "삭제", danger = true
        ) { doClearBrowsingData() }
    }

    private fun doClearBrowsingData() {
        tabs.forEach {
            it.liveWebView?.clearCache(true)
            it.liveWebView?.clearHistory()
            it.redirectSources.clear()
        }
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies(null)
        prefs.clearHistory()
        toast("삭제했습니다")
    }

    // ───────────────────────── 영상 재생 속도 ─────────────────────────

    private fun speedJs(rate: Float): String = """
        (function(r){
          window.__sbRate = r;
          function apply(){
            document.querySelectorAll('video,audio').forEach(function(v){
              if (v.playbackRate !== window.__sbRate) v.playbackRate = window.__sbRate;
            });
          }
          apply();
          if (window.__sbRateTimer) { clearInterval(window.__sbRateTimer); window.__sbRateTimer = null; }
          if (r !== 1) window.__sbRateTimer = setInterval(apply, 800);
        })($rate);
    """.trimIndent()

    // ───────────────────────── HTTPS 우선 연결 ─────────────────────────

    private var httpsFirst = true

    // ───────────────────────── 클릭 가로채기 이동 차단 ─────────────────────────

    /** 호스트의 '사이트 단위' 키 (m.a.com / www.a.com → a.com, b.co.kr 같은 2단계 도메인도 처리) */
    private fun siteKey(host: String): String {
        val parts = host.lowercase().trimEnd('.').split('.')
        if (parts.size <= 2) return parts.joinToString(".")
        val second = parts[parts.size - 2]
        val twoLevel = parts.last().length == 2 && second in setOf("co", "com", "or", "ne", "go", "ac", "re", "pe", "ed", "gov", "org", "net")
        return parts.takeLast(if (twoLevel) 3 else 2).joinToString(".")
    }

    /** 로그인·결제처럼 다른 사이트로 가는 것이 정상인 주소 */
    private fun looksLikeSignInOrPay(url: Uri, host: String): Boolean {
        val h = host.lowercase()
        if (h.startsWith("accounts.") || h.startsWith("login.") || h.startsWith("auth.") || h.startsWith("sso.") ||
            h.startsWith("id.") || h.startsWith("nid.") || h.startsWith("signin.") || h.contains("oauth") ||
            h.contains("pay") || h.contains("pg.") || h.contains("inicis") || h.contains("kcp") ||
            h.contains("nicepay") || h.contains("danal") || h.contains("paypal") ||
            h.endsWith("appleid.apple.com") || h.endsWith("login.microsoftonline.com") || h.endsWith("live.com")
        ) return true
        val path = (url.encodedPath ?: "").lowercase()
        return Regex("(oauth|authorize|signin|sign-in|sign_in|login|logon|sso|passport|checkout|payment|share|sharer|intent/tweet|intent/post)").containsMatchIn(path)
    }

    /**
     * 사용자가 링크가 아닌 곳(빈 곳·버튼 모양 덮개)을 눌렀는데 곧바로 다른 사이트로 가려는지.
     * - 링크를 누른 경우, 서버 리다이렉트, 같은 사이트 안 이동, 로그인·결제 주소, 허락받은 사이트는 통과
     * - 팝업은 연 페이지에서 누른 직후(5초 안) 첫 이동만 본다
     * 백그라운드 스레드에서 불려도 안전하다 (화면을 건드리지 않는다).
     */
    private fun isHijackedNav(tab: BrowserTab, url: Uri, fromUrl: String?, isRedirect: Boolean, popupFirst: Boolean): Boolean {
        if (!hijackGuard) return false
        val now = android.os.SystemClock.uptimeMillis()
        // 방금 확인하고 통과시킨 이동이 곧바로 이어 보내는 서버 리다이렉트(링크 → 추적 주소 → 도착 주소)는 통과.
        // (페이지 스크립트가 location 을 바꾸는 이동은 리다이렉트 표시가 붙어 와도 이 조건에 안 걸려 아래에서 검사한다)
        if (isRedirect && tab.lastHopAt != 0L && now - tab.lastHopAt < 2000L) return false
        val destHost = url.host?.lowercase() ?: return false
        if (fromUrl == null || !fromUrl.startsWith("http") || fromUrl.startsWith(LOCAL_BASE)) return false
        val fromHost = runCatching { Uri.parse(fromUrl).host }.getOrNull()?.lowercase() ?: return false
        val destKey = siteKey(destHost)
        if (destKey == siteKey(fromHost) || destKey in hijackAllowed) return false
        if (looksLikeSignInOrPay(url, destHost)) return false
        val src = if (popupFirst) (tab.opener ?: tab) else tab
        val windowMs = if (popupFirst) 5000L else 2500L
        // 누른 곳 정보: 페이지 스크립트가 알려 준 것(이번 누름에 대한 것일 때)을 우선, 아니면 웹뷰가 잰 것
        val jsAt = src.tapJsAt
        val jsFresh = jsAt != 0L && jsAt >= src.tapDownAt - 150L
        val lastAt = if (jsFresh) maxOf(jsAt, src.tapAt) else src.tapAt
        if (lastAt == 0L || now - lastAt > windowMs) return false
        val onLink: Boolean
        val href: String?
        if (jsFresh) {
            val h = src.tapJsHref
            onLink = h.startsWith("http://", true) || h.startsWith("https://", true)
            href = h
        } else {
            onLink = src.tapOnLink
            href = src.tapHref
        }
        // 링크가 아닌 곳(빈 곳·버튼 모양 덮개·javascript: 링크)을 눌렀는데 다른 사이트로 간다
        if (!onLink) return true
        // 링크를 눌렀어도, 그 링크가 가리키는 사이트와 다른 사이트로 가면 가로챈 것이다
        // (예: href="#" 인 '재생' 버튼의 클릭 처리기가 광고 사이트로 보냄). 링크 주소를 모르면 통과.
        val linkKey = href?.let { runCatching { Uri.parse(it).host }.getOrNull() }?.let { siteKey(it) } ?: return false
        return linkKey != destKey
    }

    /** 막은 뒤: 알림에 '이동' 버튼을 달아, 정말 가려던 것이면 한 번에 갈 수 있게 한다 */
    private fun onHijackBlocked(tab: BrowserTab, url: String, popup: Boolean) {
        SecurityStats.add(SecurityStats.HIJACK)
        val host = runCatching { Uri.parse(url).host }.getOrNull() ?: url
        val opener = tab.opener
        ui.post {
            if (isFinishing || isDestroyed) return@post
            if (popup && tab in tabs) closeTab(tab)
            if (prefs.notifyRedirectBlocked) AppToast.showAction(this, "다른 사이트로 이동을 막았습니다", host, "이동") {
                hijackAllowed.add(siteKey(host))
                if (popup) createTab(url, select = true, opener = opener?.takeIf { it in tabs })
                else if (tab in tabs) tab.webView.loadUrl(url)
            }
        }
    }

    /** 이번 실행 동안 http 로 열기로 허락받은 사이트 */
    private val httpAllowed: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** http 주소를 https 로 올린 주소를 돌려준다. 올리지 않을 주소(이미 https, 내부망·IP, 허락받은 사이트)는 null */
    private fun upgradeUrl(url: String): String? {
        if (!httpsFirst || !url.startsWith("http://")) return null
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return null
        val internal = !host.contains('.') || host == "localhost" || host.endsWith(".local") ||
            host.endsWith(".lan") || host.endsWith(".internal") || host.endsWith(".home") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host) || host.contains(':')
        if (internal || host in httpAllowed) return null
        return "https://" + url.removePrefix("http://")
    }

    private fun askHttpFallback(tab: BrowserTab, view: WebView, httpUrl: String) {
        if (isFinishing || isDestroyed || tab !in tabs || tab !== current) return
        val host = runCatching { Uri.parse(httpUrl).host }.getOrNull() ?: return
        ThemedDialogBuilder(this)
            .setTitle("보안 연결(HTTPS)을 쓸 수 없어요")
            .setMessage("$host\n\n이 사이트는 보안 연결을 지원하지 않는 것 같아요. 보안되지 않은 연결(http)로 계속하면 주고받는 내용이 다른 사람에게 보일 수 있어요.")
            .setPositiveButton("http로 계속") { _, _ ->
                httpAllowed.add(host.lowercase())
                tab.upgradedFrom = null
                view.loadUrl(httpUrl)
            }
            .setNegativeButton("취소") { _, _ -> tab.upgradedFrom = null }
            .setOnCancelListener { tab.upgradedFrom = null }
            .show()
    }

    private fun toggleSniBypass() {
        val on = !prefs.sniBypass
        if (on && !SniBypass.apply(applicationContext, true)) {
            toast("이 기기의 웹뷰는 프록시 설정을 지원하지 않아 쓸 수 없어요")
            return
        }
        if (!on) SniBypass.apply(applicationContext, false)
        prefs.sniBypass = on
        toast(if (on) "접속 차단 우회 켜짐 · 열려 있는 페이지는 새로고침하세요" else "접속 차단 우회 꺼짐")
    }

    private fun toggleHttpsFirst() {
        httpsFirst = !httpsFirst
        prefs.httpsFirst = httpsFirst
        toast(if (httpsFirst) "HTTPS 우선 연결 켜짐" else "HTTPS 우선 연결 꺼짐")
    }

    // ───────────────────────── 비밀번호 · 자동완성 ─────────────────────────

    private var autofillEnabled = true

    /**
     * 웹뷰의 로그인 폼을 안드로이드 자동완성 프레임워크(Google·삼성 패스·Bitwarden 등)에 연결한다.
     * 시크릿 탭은 저장·입력 대상에서 뺀다.
     */
    private fun applyAutofill(tab: BrowserTab) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        tab.webView.importantForAutofill =
            if (autofillEnabled && !tab.incognito) View.IMPORTANT_FOR_AUTOFILL_YES
            else View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
    }

    private fun toggleAutofill() {
        autofillEnabled = !autofillEnabled
        prefs.autofill = autofillEnabled
        tabs.forEach { applyAutofill(it) }
        if (!autofillEnabled && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            // 입력 중이던 폼이 있으면 저장 안내가 뜨지 않도록 취소
            getSystemService(android.view.autofill.AutofillManager::class.java)?.cancel()
        }
        toast(if (autofillEnabled) "비밀번호·자동완성 켜짐" else "비밀번호·자동완성 꺼짐")
    }

    private fun autofillServiceStatus(): String {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) {
            return "Android 8.0 이상에서 지원됩니다"
        }
        val afm = getSystemService(android.view.autofill.AutofillManager::class.java)
        return when {
            afm == null || !afm.isAutofillSupported -> "이 기기에서는 자동완성을 쓸 수 없어요"
            afm.hasEnabledAutofillServices() -> "사용 중인 서비스가 있어요 · 눌러서 바꾸기"
            else -> "선택된 서비스가 없어요 · 눌러서 비밀번호 관리자 고르기"
        }
    }

    /** 기기의 자동완성 서비스 선택 화면을 연다 (없으면 설정 앱의 일반 화면) */
    private fun openAutofillSettings() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        val intent = Intent(android.provider.Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE)
            .setData(Uri.parse("package:$packageName"))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
                toast("설정 화면을 열 수 없어요")
            }
        }
    }

    // ───────────────────────── 웹 화면: 다크 모드 · 글자 크기 ─────────────────────────

    /** 0 = 끔, 1 = 기기가 다크 모드일 때만, 2 = 항상 */
    private var darkMode = 1
    private var textZoom = 100

    private fun systemNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** 기기가 밝은 모드인데 "항상 켜기"인 경우: 시스템 기능으로는 안 되므로 CSS 로 색을 뒤집는다 */
    private fun needCssDark(): Boolean = darkMode == 2 && !systemNight()

    private fun darkModeLabel(): String = when (darkMode) {
        0 -> "끄기"
        2 -> "항상 켜기"
        else -> "기기가 다크 모드일 때"
    }

    private fun forceDarkJs(on: Boolean): String = if (on) {
        "(function(){if(document.getElementById('ev-dark'))return;var s=document.createElement('style');" +
            "s.id='ev-dark';s.textContent='html{background:#fff!important;filter:invert(1) hue-rotate(180deg)!important}" +
            "img,picture,video,canvas,iframe{filter:invert(1) hue-rotate(180deg)!important}';" +
            "(document.head||document.documentElement).appendChild(s)})()"
    } else {
        "(function(){var s=document.getElementById('ev-dark');if(s)s.remove()})()"
    }

    /** 웹뷰에 글자 크기와 다크 모드를 적용한다 */
    private fun applyWebAppearance(wv: WebView) {
        wv.settings.textZoom = textZoom
        val dark = darkMode != 0 && systemNight()
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(wv.settings, dark)
            } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                @Suppress("DEPRECATION")
                WebSettingsCompat.setForceDark(
                    wv.settings,
                    if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
                )
            }
        } catch (e: Exception) {
            // 지원하지 않는 WebView 면 그대로 둔다
        }
    }

    private fun showDarkModeDialog() {
        val labels = arrayOf("끄기", "기기가 다크 모드일 때", "항상 켜기")
        ThemedDialogBuilder(this)
            .setTitle("웹 페이지 다크 모드")
            .setSingleChoiceItems(labels, darkMode) { d, which ->
                darkMode = which
                prefs.webDarkMode = which
                tabs.forEach { t ->
                    t.liveWebView?.let { applyWebAppearance(it) }
                    t.darkInjected = false
                    // 지금 열려 있는 페이지에도 바로 반영 (CSS 방식은 켜고 끄기를 스크립트로)
                    if (!t.isHome) t.liveWebView?.evaluateJavascript(forceDarkJs(needCssDark()), null)
                    if (needCssDark()) t.darkInjected = true
                }
                d.dismiss()
                toast("다크 모드: ${darkModeLabel()}")
            }
            .show()
    }

    // ───────────────────────── 페이지 확대/축소 (50% ~ 500%) ─────────────────────────

    private fun effectiveZoom(tab: BrowserTab): Int = (tab.pageZoom ?: prefs.pageZoom).coerceIn(50, 500)

    /**
     * 핀치 줌이 아니라 페이지 자체를 키우고 줄인다 (PC 브라우저의 Ctrl +/- 와 같은 방식).
     * 레이아웃 뷰포트 너비를 (화면 너비 ÷ 배율) 로 바꿔서, 글자·이미지·여백이 함께 커지고 줄이 다시 나뉜다.
     * 100% 면 원래 뷰포트로 되돌린다. 사이트가 뷰포트 설정을 다시 바꾸면 곧바로 다시 덮어쓴다.
     */
    private fun pageZoomJs(tab: BrowserTab, zoom: Int? = null): String {
        val z = (zoom ?: effectiveZoom(tab)).coerceIn(50, 500)
        if (z == 100) return PAGE_ZOOM_OFF_JS
        val wv = tab.liveWebView
        val dp = if (wv != null && wv.width > 0) (wv.width / resources.displayMetrics.density).toInt()
        else webAreaWidthDp()
        val base = if (tab.desktop) maxOf(dp, 1024) else maxOf(dp, 1)
        val w = (base * 100f / z).coerceAtLeast(1f)
        return "(function(){var W=${"%.2f".format(java.util.Locale.US, w)};" + PAGE_ZOOM_ON_JS + "})();"
    }

    private fun applyPageZoom(tab: BrowserTab) {
        if (tab.isHome) return
        tab.zoomInjected = true
        tab.liveWebView?.evaluateJavascript(pageZoomJs(tab), null)
    }

    /** 확대/축소·글자 크기 팝업이 함께 쓰는 게이지 영역 (큰 배율 숫자 + 게이지바 + 양 끝 값) */
    private class GaugeParts(val label: TextView, val gauge: ZoomGauge, val ends: View)

    private fun themeColor(attr: Int, fallback: Int) =
        ThemeColors.get(this, attr, ContextCompat.getColor(this, fallback))

    private fun gaugeParts(min: Int, max: Int, step: Int, value: Int, desc: String, unit: String = "%", defaultValue: Int = 100): GaugeParts {
        val cPrimary = themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val cTrack = themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill)
        val label = TextView(this).apply {
            textSize = 44f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(cPrimary)
            setPadding(0, dp(4), 0, dp(12))
        }
        val gauge = ZoomGauge(this).apply {
            this.min = min; this.max = max; this.step = step; this.defaultValue = defaultValue
            activeColor = cPrimary
            inactiveColor = cTrack
            dotOnActiveColor = android.graphics.Color.WHITE
            this.value = value
            contentDescription = desc
        }
        fun endLabel(t: String) = TextView(this).apply {
            text = t
            textSize = 12f
            setTextColor(cMuted)
        }
        val ends = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, 0)
            addView(endLabel("${min}${unit}"))
            addView(android.view.View(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(endLabel("${max}${unit}"))
        }
        setPercentLabel(label, value, unit)
        return GaugeParts(label, gauge, ends)
    }

    private fun setPercentLabel(label: TextView, v: Int, unit: String = "%") {
        val sp = android.text.SpannableString("${v}${unit}")
        sp.setSpan(android.text.style.RelativeSizeSpan(0.5f), sp.length - unit.length, sp.length,
            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        label.text = sp
    }

    private fun showPageZoomDialog() {
        val tab = current ?: return
        val zMin = 50
        val zMax = 500
        val zStep = 10
        var applied = false

        val cOnSurface = themeColor(com.google.android.material.R.attr.colorOnSurface, R.color.ev_text)
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val cTrack = themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill)

        var zoom = (Math.round((effectiveZoom(tab) - zMin) / zStep.toFloat()) * zStep + zMin).coerceIn(zMin, zMax)
        val parts = gaugeParts(zMin, zMax, zStep, zoom, "화면 확대/축소")

        // 다른 팝업의 항목(popup_item)과 같은 안쪽 여백: 목록 8dp + 12dp = 머리말 글자와 같은 20dp
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }

        // '이 탭에만 적용': 한 줄 (제목 + 설명 / 스위치)
        val tabOnly = com.google.android.material.materialswitch.MaterialSwitch(this).apply {
            isChecked = tab.pageZoom != null
        }
        ThemeColors.skin(tabOnly)
        val tabOnlyTitle = TextView(this).apply {
            text = "이 탭에만 적용"
            textSize = 15f
            setTextColor(cOnSurface)
        }
        val hint = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(1), 0, 0)
            setTextColor(cMuted)
        }
        fun refreshHint() {
            hint.text = if (tabOnly.isChecked) "다른 탭은 전체 설정(${prefs.pageZoom}%)을 따라요"
            else "모든 탭과 새 탭에 적용돼요"
        }
        refreshHint()
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
            isClickable = true
            isFocusable = true
            setOnClickListener { tabOnly.toggle() }
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(tabOnlyTitle)
                addView(hint)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(tabOnly)
        }
        tabOnly.setOnCheckedChangeListener { _, _ -> refreshHint() }

        // 실시간 미리보기: 움직이는 동안 지금 보는 페이지에 바로 반영한다 (저장은 '적용'을 눌러야)
        val handler = Handler(Looper.getMainLooper())
        val previewRun = Runnable {
            if (!tab.isHome) tab.liveWebView?.evaluateJavascript(pageZoomJs(tab, zoom), null)
        }
        parts.gauge.onValueChange = { v ->
            zoom = v
            setPercentLabel(parts.label, v)
            handler.removeCallbacks(previewRun)
            handler.postDelayed(previewRun, 60L)
        }

        box.addView(parts.label)
        box.addView(parts.gauge)
        box.addView(parts.ends)
        box.addView(android.view.View(this).apply { setBackgroundColor(cTrack) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(16) })
        box.addView(tabRow)

        // 다른 팝업과 같은 공통 틀(Popup.panel). 뒤 페이지가 바뀌는 걸 봐야 해서 미리보기 모드로 띄운다
        val dialog = Popup.panel(
            this,
            title = "화면 확대/축소",
            subtitle = "페이지의 글자와 이미지가 함께 커지고 작아져요",
            headerIcon = R.drawable.ic_text,
            widthDp = 340,
            secondaryLabel = "취소",
            onSecondary = { d -> d.dismiss() },
            closeLabel = "적용",
            onClose = { d ->
                applied = true
                val z = zoom
                if (tabOnly.isChecked) {
                    tab.pageZoom = z
                    applyPageZoom(tab)
                } else {
                    prefs.pageZoom = z
                    tab.pageZoom = null
                    // 이 탭만 따로 정해 둔 탭은 그 값을 유지하고, 나머지 탭에 새 값을 적용한다
                    tabs.filter { it.pageZoom == null }.forEach { applyPageZoom(it) }
                }
                toast("화면 확대/축소: ${z}%" + if (tabOnly.isChecked) " (이 탭만)" else "")
                d.dismiss()
            },
            preview = true
        ) { list, _ -> list.addView(box) }
        dialog.setOnDismissListener {
            handler.removeCallbacks(previewRun)
            // 적용을 누르지 않고 닫았다면 미리보기를 걷어내고 원래 배율로 되돌린다
            if (!applied) applyPageZoom(tab)
        }
    }

    private fun showTextSizeDialog() {
        val tMin = 50
        val tMax = 200
        val tStep = 10
        var applied = false

        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        var size = (Math.round((textZoom - tMin) / tStep.toFloat()) * tStep + tMin).coerceIn(tMin, tMax)
        val parts = gaugeParts(tMin, tMax, tStep, size, "글자 크기")

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        val sample = TextView(this).apply {
            text = "가나다라 ABC abc 123"
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
            setTextColor(cMuted)
            textSize = 16f * size / 100f
        }
        parts.gauge.onValueChange = { v ->
            size = v
            setPercentLabel(parts.label, v)
            sample.textSize = 16f * v / 100f
            // 보고 있는 페이지에 바로 반영해서 미리 볼 수 있게
            current?.webView?.settings?.textZoom = v
        }
        box.addView(parts.label)
        box.addView(parts.gauge)
        box.addView(parts.ends)
        box.addView(sample)

        fun commit(z: Int) {
            applied = true
            textZoom = z
            prefs.textZoom = z
            tabs.forEach { it.liveWebView?.settings?.textZoom = z }
        }
        val dialog = Popup.panel(
            this,
            title = "글자 크기",
            subtitle = "웹 페이지 글자만 크게 또는 작게 보여요",
            headerIcon = R.drawable.ic_text,
            widthDp = 340,
            secondaryLabel = "기본값",
            onSecondary = { d -> commit(100); d.dismiss() },
            closeLabel = "적용",
            onClose = { d -> commit(size); d.dismiss() },
            preview = true
        ) { list, _ -> list.addView(box) }
        dialog.setOnDismissListener {
            // 적용/기본값을 누르지 않고 닫았다면 원래 크기로 되돌린다
            current?.webView?.settings?.textZoom = textZoom
        }
    }

    // ───────────────────────── 자동 스크롤 설정 ─────────────────────────

    private fun autoScrollTouchLabel(): String =
        if (prefs.autoScrollTouch == 1) "완전히 멈춤" else "만지는 동안만 멈췄다가 이어서"

    private fun showAutoScrollTouchDialog() {
        val labels = arrayOf("만지는 동안만 멈췄다가 이어서", "완전히 멈춤")
        ThemedDialogBuilder(this)
            .setTitle("자동 스크롤 중 화면을 만지면")
            .setSingleChoiceItems(labels, prefs.autoScrollTouch) { d, which ->
                prefs.autoScrollTouch = which
                d.dismiss()
                toast("화면을 만지면: ${autoScrollTouchLabel()}")
            }
            .show()
    }

    /** 자동 스크롤 속도 (1~50단계). 움직이는 동안 '화면 한 장을 내려가는 데 걸리는 시간'을 보여 준다 */
    private fun showAutoScrollSpeedDialog() {
        val lMin = AutoScroller.MIN_LEVEL
        val lMax = AutoScroller.MAX_LEVEL
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        var level = prefs.autoScrollSpeed
        val parts = gaugeParts(lMin, lMax, 1, level, "자동 스크롤 속도", unit = "단계", defaultValue = AutoScroller.DEFAULT_LEVEL)
        val screenDp = resources.displayMetrics.heightPixels / resources.displayMetrics.density
        fun hintFor(l: Int): String {
            val sec = screenDp / AutoScroller.dpPerSecond(l)
            val t = if (sec >= 10f) "${Math.round(sec)}초" else "${"%.1f".format(java.util.Locale.US, sec)}초"
            return "화면 한 장을 내려가는 데 약 $t 걸려요"
        }
        val hint = TextView(this).apply {
            text = hintFor(level)
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(cMuted)
            setPadding(0, dp(12), 0, dp(4))
        }
        parts.gauge.onValueChange = { v ->
            level = v
            setPercentLabel(parts.label, v, "단계")
            hint.text = hintFor(v)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
            addView(parts.label)
            addView(parts.gauge)
            addView(parts.ends)
            addView(hint)
        }
        Popup.panel(
            this,
            title = "자동 스크롤 속도",
            subtitle = "꾹 눌러서 뜨는 메뉴의 「자동 스크롤」이 흐르는 속도예요",
            headerIcon = R.drawable.ic_arrow_down,
            widthDp = 340,
            secondaryLabel = "기본값",
            onSecondary = { d ->
                prefs.autoScrollSpeed = AutoScroller.DEFAULT_LEVEL
                d.dismiss()
            },
            closeLabel = "적용",
            onClose = { d ->
                prefs.autoScrollSpeed = level
                d.dismiss()
            }
        ) { list, _ -> list.addView(box) }
    }

    /** 스마트 자동 스크롤 속도: 내용(글·그림)이 보일 때 / 빈 그림만 보일 때의 단계 (1~50) */
    private fun showSmartScrollSpeedDialog() {
        val lMin = AutoScroller.MIN_LEVEL
        val lMax = AutoScroller.MAX_LEVEL
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        var content = prefs.autoScrollContentLevel
        var blank = prefs.autoScrollBlankLevel
        val pc = gaugeParts(lMin, lMax, 1, content, "내용 구간 속도", unit = "단계", defaultValue = AutoScroller.DEFAULT_CONTENT_LEVEL)
        val pb = gaugeParts(lMin, lMax, 1, blank, "빈 그림 구간 속도", unit = "단계", defaultValue = AutoScroller.DEFAULT_BLANK_LEVEL)
        fun title(t: String) = TextView(this).apply {
            text = t
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(cMuted)
            setPadding(0, dp(8), 0, 0)
        }
        pc.gauge.onValueChange = { v -> content = v; setPercentLabel(pc.label, v, "단계") }
        pb.gauge.onValueChange = { v -> blank = v; setPercentLabel(pb.label, v, "단계") }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
            addView(title("글·그림이 보일 때 (내용 구간)"))
            addView(pc.label); addView(pc.gauge); addView(pc.ends)
            addView(title("빈 그림만 보일 때 (빈 구간)"))
            addView(pb.label); addView(pb.gauge); addView(pb.ends)
        }
        Popup.panel(
            this,
            title = "스마트 자동 스크롤 속도",
            subtitle = "화면 내용에 따라 두 속도 사이를 부드럽게 오가요",
            headerIcon = R.drawable.ic_arrow_down,
            widthDp = 340,
            secondaryLabel = "기본값",
            onSecondary = { d ->
                prefs.autoScrollContentLevel = AutoScroller.DEFAULT_CONTENT_LEVEL
                prefs.autoScrollBlankLevel = AutoScroller.DEFAULT_BLANK_LEVEL
                d.dismiss()
            },
            closeLabel = "적용",
            onClose = { d ->
                prefs.autoScrollContentLevel = content
                // 빈 그림이 내용보다 느리면 의미가 없으니 최소한 같게 맞춘다
                prefs.autoScrollBlankLevel = maxOf(blank, content)
                d.dismiss()
            }
        ) { list, _ -> list.addView(box) }
    }

    private fun showSpeedDialog() {
        val tab = current ?: return
        val rates = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
        val labels = rates.map { "${it}x" }.toTypedArray()
        val selected = rates.indexOfFirst { r -> r == tab.rate }.let { if (it < 0) 2 else it }
        ThemedDialogBuilder(this)
            .setTitle("재생 속도")
            .setSingleChoiceItems(labels, selected) { d, which ->
                tab.rate = rates[which]
                tab.webView.evaluateJavascript(speedJs(tab.rate), null)
                d.dismiss()
            }
            .show()
    }

    // ───────────────────────── 다운로드 ─────────────────────────

    private val errorTemplate: String by lazy {
        assets.open("error.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun htmlEscape(t: String) =
        t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** 불러오지 못했을 때 보여 주는 오류 화면 (가지에서 떨어져 나간 나뭇잎 일러스트) */
    private fun errorPageHtml(url: String, code: Int, desc: String): String {
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.takeIf { it.isNotBlank() } ?: url
        val (title, msg) = when (code) {
            WebViewClient.ERROR_HOST_LOOKUP ->
                "사이트를 찾을 수 없어요" to "주소가 맞는지 확인하거나, 잠시 뒤에 다시 시도해 보세요."
            WebViewClient.ERROR_CONNECT, WebViewClient.ERROR_IO, WebViewClient.ERROR_TIMEOUT ->
                "연결할 수 없어요" to "서버가 응답하지 않거나 인터넷 연결이 불안정해요."
            WebViewClient.ERROR_FAILED_SSL_HANDSHAKE ->
                "보안 연결에 실패했어요" to "이 사이트와 안전하게 연결할 수 없어요."
            WebViewClient.ERROR_REDIRECT_LOOP ->
                "페이지가 계속 다른 곳으로 이동해요" to "사이트 설정에 문제가 있을 수 있어요. 쿠키를 지우고 다시 시도해 보세요."
            WebViewClient.ERROR_BAD_URL ->
                "주소가 올바르지 않아요" to "주소를 다시 확인해 주세요."
            400 ->
                "잘못된 요청이에요" to "주소를 다시 확인하거나 잠시 뒤에 다시 시도해 보세요."
            404 ->
                "페이지를 찾을 수 없어요" to "주소가 바뀌었거나 삭제된 페이지일 수 있어요. 주소를 다시 확인해 주세요."
            410 ->
                "삭제된 페이지예요" to "이 페이지는 더 이상 제공되지 않아요."
            408 ->
                "응답 시간이 초과됐어요" to "서버가 요청을 기다리다 연결을 끊었어요. 다시 시도해 보세요."
            500, 502, 503, 504 ->
                "서버에 문제가 생겼어요" to "사이트 쪽 문제예요. 잠시 뒤에 다시 시도해 보세요."
            in 400..599 ->
                "웹페이지를 사용할 수 없어요" to "사이트에서 오류를 돌려보냈어요. 잠시 뒤에 다시 시도해 보세요."
            else ->
                "웹페이지를 사용할 수 없어요" to "페이지를 불러오는 중 문제가 생겼어요."
        }
        return errorTemplate
            .replace("__TITLE__", htmlEscape(title))
            .replace("__MSG__", htmlEscape(msg))
            .replace("__HOST__", htmlEscape(host))
            .replace("__CODE__", htmlEscape(desc))
            .replace("__URL_JSON__", JSONObject.quote(url))
            .replace("__NEXT_JSON__", nextNumberUrl(url)?.let { (u, label) ->
                "{\"url\":" + JSONObject.quote(u) + ",\"label\":" + JSONObject.quote(label) + "}"
            } ?: "null")
    }

    /**
     * 주소의 번호를 1 늘린 주소와 버튼에 쓸 글자를 돌려준다. 번호가 없으면 null.
     * 도메인 이름 칸(blacktoon145.com 의 blacktoon145)에 번호가 있으면 그 번호를 올린다.
     * 없으면 경로(path)의 마지막 번호, 그것도 없으면 쿼리(?page=3 같은)의 마지막 번호를 올린다.
     * 서브도메인(s3.example.com)·파일 확장자(.mp4)·%XX 인코딩 안의 숫자는 번호로 보지 않고, 001 → 002 처럼 자릿수를 지킨다.
     */
    private fun nextNumberUrl(url: String): Pair<String, String>? {
        val m = Regex("^(https?://[^/?#]*)([^?#]*)(\\?[^#]*)?(#.*)?$", RegexOption.DOT_MATCHES_ALL).matchEntire(url) ?: return null
        val origin = m.groupValues[1]
        val path = m.groupValues[2]
        val query = m.groupValues[3]
        val frag = m.groupValues[4]
        // %E2 같은 인코딩은 글자 수는 그대로 두고 숫자가 아닌 글자로 가려서 찾는다
        fun mask(s: String) = s.replace(Regex("%[0-9A-Fa-f]{2}")) { "___" }
        fun bump(s: String, isPath: Boolean): Triple<Int, Int, String>? {
            val masked = mask(s)
            val extAt = if (isPath) (Regex("\\.(?=[A-Za-z0-9]*[A-Za-z])[A-Za-z0-9]{1,5}$").find(masked)?.range?.first ?: masked.length) else masked.length
            val run = Regex("\\d+").findAll(masked.substring(0, extAt)).lastOrNull() ?: return null
            val old = run.value
            var n = java.math.BigInteger(old).add(java.math.BigInteger.ONE).toString()
            if (old.length > 1 && old.startsWith("0")) n = n.padStart(old.length, '0')
            return Triple(run.range.first, run.range.last + 1, n)
        }
        // 도메인 이름 안의 번호가 먼저다 (blacktoon145.com → blacktoon146.com). 주소가 번호째 바뀌는 사이트용
        run {
            val schemeEnd = origin.indexOf("://") + 3
            val hostPort = origin.substring(schemeEnd)
            val portAt = hostPort.lastIndexOf(':')
            val host = if (portAt >= 0 && hostPort.substring(portAt + 1).all { it.isDigit() }) hostPort.substring(0, portAt) else hostPort
            val rest = hostPort.substring(host.length)
            val labels = host.split('.')
            if (labels.size < 2 || labels.all { l -> l.isNotEmpty() && l.all { it.isDigit() } }) return@run  // IP 주소 등
            // 도메인 이름 칸: .com 앞 칸 (co.kr 처럼 두 칸짜리 끝은 한 칸 더 앞)
            var idx = labels.size - 2
            if (labels.size >= 3 && labels.last().length == 2 &&
                labels[idx] in setOf("co", "or", "ne", "go", "ac", "re", "pe", "com", "net", "org", "gov", "edu")
            ) idx--
            val hit = bump(labels[idx], false) ?: return@run
            val (a, b, n) = hit
            val newLabels = labels.toMutableList().also { it[idx] = it[idx].replaceRange(a, b, n) }
            val newHost = newLabels.joinToString(".")
            return (origin.substring(0, schemeEnd) + newHost + rest + path + query + frag) to "다음 번호 ($newHost)"
        }
        bump(path, true)?.let { (a, b, n) ->
            return (origin + path.replaceRange(a, b, n) + query + frag) to "다음 번호 ($n)"
        }
        if (query.isNotEmpty()) bump(query, false)?.let { (a, b, n) ->
            return (origin + path + query.replaceRange(a, b, n) + frag) to "다음 번호 ($n)"
        }
        return null
    }

    /** 오류 화면을 보여 주는 중이면 그 주소를 다시 불러오고, 아니면 보통 새로고침 */
    private fun reloadTab(tab: BrowserTab) {
        if (tab.isHome && tab.errorUrl == null) return
        val err = tab.errorUrl
        if (err != null) {
            tab.errorUrl = null
            tab.webView.loadUrl(err)
        } else {
            tab.webView.reload()
        }
    }

    /** 차단한 요청에 돌려줄 빈 403 응답. 종류에 맞는 MIME 을 달아 두면 페이지 스크립트가 덜 깨진다. */
    /** 유튜브 페이지에서 광고 영상·광고 정보를 내려주는 구글 광고 서버인지 (막지 않고 통과시킬 대상) */
    private fun ytAdServerPass(pageHost: String?, host: String?): Boolean {
        if (pageHost == null || host == null) return false
        val p = pageHost.lowercase()
        if (!(p == "youtube.com" || p.endsWith(".youtube.com"))) return false
        val h = host.lowercase()
        return arrayOf("doubleclick.net", "2mdn.net", "googlesyndication.com", "googleadservices.com")
            .any { h == it || h.endsWith(".$it") }
    }

    private fun blockedResponse(uri: Uri, subResource: Boolean = false): WebResourceResponse {
        // WebResourceResponse 는 3xx 상태 코드를 허용하지 않는다(IllegalArgumentException).
        // 하위 요청도 403 으로 막는다: img/script 는 onerror, CORS fetch/XHR 은 네트워크 오류로 실패한다.
        val p = uri.path?.lowercase().orEmpty()
        val mime = when {
            p.endsWith(".js") || p.contains("/js/") -> "application/javascript"
            p.endsWith(".css") -> "text/css"
            p.endsWith(".gif") || p.endsWith(".png") || p.endsWith(".jpg") || p.endsWith(".jpeg") || p.endsWith(".webp") -> "image/gif"
            else -> "text/plain"
        }
        val headers = if (subResource) mapOf("Cache-Control" to "no-store") else emptyMap()
        return WebResourceResponse(mime, "utf-8", 403, "Blocked", headers, ByteArrayInputStream(ByteArray(0)))
    }

    /** 경로 끝의 확장자(점 뒤, 소문자). 확장자가 없거나 너무 길면 null — 문자열을 통째로 복사하지 않는다 */
    private fun extOf(path: String): String? {
        val d = path.lastIndexOf('.')
        if (d < 0 || path.length - d > 7) return null
        return path.substring(d + 1).lowercase()
    }

    /** 주소 뒤쪽(쿼리)에 스트리밍 목록을 가리키는 표시가 있는지 (예: ?file=index.m3u8, ?format=m3u8, ?type=mpd) */
    private fun queryLooksLikeManifest(q: String?): Boolean {
        if (q == null) return false
        return q.contains("m3u8", ignoreCase = true) || q.contains(".mpd", ignoreCase = true) ||
            q.contains("=mpd", ignoreCase = true) || q.contains("manifest(format=mpd", ignoreCase = true)
    }

    private fun looksLikeMediaUrl(path: String): Boolean {
        val ext = extOf(path)
        if (ext != null && ext in SNIFF_MEDIA_EXTS) return true
        return path.endsWith(".ism/manifest", ignoreCase = true)
    }

    /** 영상 파일 / HLS / DASH 요청이면 내장 플레이어 후보로 기억해 둔다. (백그라운드 스레드에서, 모든 하위 요청마다 불림 → 할당을 최소화) */
    private fun sniffMedia(tab: BrowserTab, uri: Uri, headers: Map<String, String>? = null) {
        val path = uri.path ?: return
        val ext = extOf(path)
        if (ext != null && ext in SNIFF_SUB_EXTS) {
            synchronized(tab.sniffedSubs) {
                if (tab.sniffedSubs.size >= 12) tab.sniffedSubs.remove(tab.sniffedSubs.first())
                tab.sniffedSubs.add(uri.toString())
            }
            return
        }
        val isMedia = looksLikeMediaUrl(path) || run {
            // 확장자가 주소 뒤쪽(쿼리)에 붙어 있는 스트리밍 주소도 잡는다 (예: ...?file=index.m3u8, ?format=m3u8)
            queryLooksLikeManifest(uri.encodedQuery)
        } || path.contains(".m3u8", ignoreCase = true) || path.contains(".mpd", ignoreCase = true)
        // 확장자가 없는 영상 주소(예: /stream/abc, /video?id=3): <video> 가 처음 보내는 요청은 Range: bytes=0- 로 시작한다.
        // 파일 이름만으로는 영상인지 알 수 없어도, 이 모양의 첫 요청이면 영상 후보로 기억해 둔다.
        val isRangeMedia = !isMedia && headers != null && run {
            val rng = headers["Range"] ?: headers["range"]
            if (rng == null || !rng.startsWith("bytes=0-")) return@run false
            val last = path.substringAfterLast('/')
            if (last.contains('.') && last.substringAfterLast('.').lowercase() !in DYNAMIC_MEDIA_EXTS) return@run false
            val acc = (headers["Accept"] ?: headers["accept"])?.lowercase()
            acc == null || acc.startsWith("*/*") || acc.startsWith("video/") || acc.startsWith("audio/")
        }
        if (!isMedia && !isRangeMedia) return
        val u = uri.toString()
        synchronized(tab.sniffed) {
            if (tab.sniffed.size >= SNIFF_MAX) tab.sniffed.remove(tab.sniffed.first())
            tab.sniffed.add(u)
        }
    }

    /** 영상 후보 한 개: 주소 / 재생 중이던 위치(ms) / 지금 재생 중인지 */
    private class MediaCand(val url: String, val posMs: Long, val playing: Boolean = false)

    /**
     * 지금 페이지에서 영상 후보를 모은다 (내장 플레이어와 '영상 저장하기'가 같이 쓴다).
     * 페이지 안을 직접 훑은 것(재생 중인 것이 앞) + 페이지가 실제로 주고받은 요청에서 잡아 둔 것(최근 것이 앞, 스트리밍 목록 우선).
     * blob 주소는 재생에는 못 쓰므로 따로(blobs) 돌려준다.
     */
    private fun gatherMediaCands(
        tab: BrowserTab,
        done: (cands: List<MediaCand>, blobs: List<MediaCand>, title: String, subsJson: String?) -> Unit
    ) {
        val wv = tab.webView
        wv.evaluateJavascript(MediaScripts.FIND_MEDIA) { raw ->
            val cands = ArrayList<MediaCand>()
            val blobs = ArrayList<MediaCand>()
            var pageTitle = wv.title.orEmpty()
            var subsJson: String? = null // 페이지의 <track> 자막 (있으면 플레이어에 같이 넘긴다)
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    val o = JSONObject(inner)
                    pageTitle = o.optString("title", pageTitle)
                    subsJson = o.optJSONArray("subs")?.takeIf { it.length() > 0 }?.toString()
                    val a = o.getJSONArray("items")
                    for (i in 0 until a.length()) {
                        val e = a.getJSONObject(i)
                        cands.add(MediaCand(e.getString("u"), (e.optDouble("t", 0.0) * 1000).toLong(), e.optBoolean("p", false)))
                    }
                    val b = o.optJSONArray("blobs")
                    if (b != null) {
                        for (i in 0 until b.length()) {
                            val e = b.getJSONObject(i)
                            blobs.add(MediaCand(e.getString("u"), 0L, e.optBoolean("p", false)))
                        }
                    }
                }
            } catch (e: Exception) {
                // 페이지에서 못 찾으면 요청 목록만 사용
            }
            // 페이지가 자바스크립트로 따로 불러온 자막 파일도 같이 넘긴다 (<track> 태그가 없는 플레이어용)
            val extraSubs = synchronized(tab.sniffedSubs) { tab.sniffedSubs.toList() }
            if (extraSubs.isNotEmpty()) {
                try {
                    val arr = JSONArray(subsJson?.takeIf { it.isNotBlank() } ?: "[]")
                    val known = HashSet<String>()
                    for (i in 0 until arr.length()) known.add(arr.getJSONObject(i).optString("u"))
                    for (u in extraSubs) {
                        if (arr.length() >= 8) break
                        if ((u.startsWith("http://") || u.startsWith("https://")) && known.add(u)) {
                            arr.put(JSONObject().put("u", u).put("l", "").put("g", ""))
                        }
                    }
                    if (arr.length() > 0) subsJson = arr.toString()
                } catch (e: Exception) { }
            }
            val have = cands.map { it.url }.toHashSet()
            // 요청 기록은 최근 것이 앞에 오게 뒤집고(가장 최근에 틀어진 영상일 가능성이 높다), 스트리밍 목록을 파일보다 앞에 둔다
            val sn = synchronized(tab.sniffed) { tab.sniffed.toList() }.asReversed()
            sn.sortedBy {
                val p = it.lowercase()
                if (p.contains(".m3u8") || p.contains(".mpd")) 0 else 1
            }.forEach { if (it !in have) cands.add(MediaCand(it, 0L)) }
            // 영상 파일 주소를 바로 연 탭이면 그 주소 자체가 영상이다
            wv.url?.let { u ->
                if (u !in have && (looksLikeMediaUrl(Uri.parse(u).path.orEmpty()) || u.lowercase().contains(".m3u8"))) {
                    cands.add(0, MediaCand(u, 0L))
                }
            }
            val list = cands.filter { it.url.startsWith("http://") || it.url.startsWith("https://") }.take(MEDIA_CAND_MAX)
            done(list, blobs, pageTitle, subsJson)
        }
    }

    private fun isYouTubeUrl(url: String?): Boolean {
        val h = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return false
        return h == "youtu.be" || h == "youtube.com" || h.endsWith(".youtube.com") || h == "youtube-nocookie.com"
    }

    private var mirrorActive = false

    /**
     * 미러링: 내장 플레이어가 열 수 없는 영상(blob/MSE 등)은 파일을 가져오지 않고,
     * 페이지에서 재생 중인 영상을 그대로 창 가득 키워 보여 준다. 소리·화질은 페이지 재생 그대로다.
     * 뒤로 가기·탭 전환으로 원래 화면으로 돌아온다.
     */
    private fun startMirror() {
        val tab = current ?: return
        if (tab.liveWebView == null) return
        if (customView != null) hideCustomView()
        mirrorActive = true
        tabStripBar.visibility = View.GONE
        toolbarView.visibility = View.GONE
        bottomBar.visibility = View.GONE
        progressBar.visibility = View.GONE
        btnFloatMenu.visibility = View.GONE
        setFullscreenBackdrop(true)
        setSystemBarsVisible(false)
        addMirrorOverlay(tab)
        // 창 여백을 미러링용(카메라 자리까지 가득)으로 다시 계산한다
        (findViewById<View>(R.id.browserUi)?.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
        // 전환 애니메이션 없이 바로 창 가득 보여 준다 (v2.5.59)
        tab.liveWebView?.evaluateJavascript(MediaScripts.MIRROR_ON_OWN, null)
        // 미러링 중에 홈으로 나가면 작은 창(PiP)이 되도록 자동 진입을 켠다
        refreshPipParams()
    }

    private var mirrorOverlay: MirrorOverlay? = null
    private var mirrorRotated = false
    private var mirrorRootBg: android.graphics.drawable.Drawable? = null
    private var mirrorRootBgSaved = false

    /** 미러링 중인 영상 위에 내장 플레이어 스타일 컨트롤(재생·이동·배속·화면 비율·PiP·회전·닫기)을 얹는다 */
    private fun addMirrorOverlay(tab: BrowserTab) {
        removeMirrorOverlay()
        val o = MirrorOverlay(this)
        val (mt, mh) = mirrorTitleFor(tab)
        o.setTitle(mt, mh)
        o.setPipAvailable(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        o.onCommand = { cmd, v -> mirrorSend(cmd, v) }
        o.onClose = { stopMirror() }
        o.onPip = { startPipFromMenu() }
        o.onRotate = { toggleMirrorOrientation() }
        o.onQuality = { id -> current?.liveWebView?.evaluateJavascript(MediaScripts.mirrorQuality(id), null) }
        // 자막: 페이지가 따로 불러온 자막 파일(.vtt/.srt/.ass/.ttml)도 고를 수 있게 주소와 받아 오는 방법을 넘긴다
        o.fileSubProvider = { synchronized(tab.sniffedSubs) { tab.sniffedSubs.toList() } }
        o.fileFetcher = { u -> fetchSubText(tab, u) }
        val root = findViewById<View>(R.id.browserUi)?.parent as? ViewGroup ?: return
        // 화면 가운데를 아래로 밀면 미러링 화면이 내려오며 닫힌다 (전체화면 나가기와 같은 제스처)
        val sw = FullscreenSwipeLayout(this)
        sw.addView(o, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        sw.enabledProvider = { prefs.swipeDownExit && mirrorOverlay === o && !isInPictureInPictureModeCompat() && !o.swipeBlocked() }
        sw.startFilter = { x, y -> !o.touchOnSeek(sw, x, y) }
        // 미러링도 두 손가락으로 확대 · 축소: 영상은 뒤쪽 웹뷰에 있으므로 컨트롤은 그대로 두고 웹뷰 쪽만 확대한다
        sw.zoomEnabled = { mirrorOverlay === o && !isInPictureInPictureModeCompat() && !o.swipeBlocked() }
        sw.zoomTargets = { listOfNotNull(webContainer.parent as? View) }
        sw.onZoomLabel = { o.showZoomLabel(it) }
        sw.onDismiss = { stopMirror() }
        // 영상은 컨트롤 뒤쪽 웹뷰에 있으므로, 밀어 내릴 때 웹뷰 영역도 컨트롤과 함께 내려가고 작아지게 한다
        sw.companions = { listOfNotNull(webContainer.parent as? View) }
        // 웹뷰가 작아지며 내려가면 드러나는 바탕이 밝은 앱 배경색이라 번쩍이므로, 미러링 동안만 검정으로 둔다
        mirrorRootBgSaved = true
        mirrorRootBg = root.background
        root.setBackgroundColor(android.graphics.Color.BLACK)
        root.addView(sw, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        mirrorOverlay = o
        o.start()
    }

    /** 미러링 화면 위쪽에 보일 제목과 사이트 주소: 페이지가 알려 준 지금 영상 제목(mediaSession) → 탭 제목 */
    private fun mirrorTitleFor(tab: BrowserTab): Pair<String, String> {
        val host = runCatching { Uri.parse(tab.liveWebView?.url).host }.getOrNull().orEmpty().removePrefix("www.")
        val sel = mediaSel
        val meta = (if (sel != null && sel.first === tab) tab.mediaMeta[sel.second]?.title?.takeIf { it.isNotBlank() } else null)
            ?: tab.mediaMeta.values.firstOrNull { it.title.isNotBlank() }?.title
        val pageTitle = tab.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" }.orEmpty()
        return (meta ?: pageTitle) to host
    }

    /** 미러링 중에 영상이 바뀌면(유튜브 다음 영상 등) 위쪽 제목도 따라 바꾼다 */
    private fun refreshMirrorTitle(tab: BrowserTab) {
        if (!mirrorActive || tab !== current) return
        val o = mirrorOverlay ?: return
        val (t, h) = mirrorTitleFor(tab)
        o.setTitle(t, h)
    }

    private fun removeMirrorOverlay() {
        mirrorOverlay?.let {
            it.release()
            val holder = it.parent as? ViewGroup
            // 밀어 내리던 중이었다면 웹뷰 영역의 위치·크기·투명도를 원래대로 (안 하면 웹뷰가 내려간 채로 남는다)
            if (holder is FullscreenSwipeLayout) holder.resetTransform()
            val rootView = (holder as? FullscreenSwipeLayout)?.parent as? ViewGroup
            if (holder is FullscreenSwipeLayout) rootView?.removeView(holder) else holder?.removeView(it)
            if (mirrorRootBgSaved) {
                rootView?.background = mirrorRootBg
            }
        }
        mirrorRootBgSaved = false
        mirrorRootBg = null
        mirrorOverlay = null
    }

    /** 미러링 자막용: 자막 파일 내용을 받아 온다 (페이지와 같은 쿠키·UA·Referer). 백그라운드 스레드에서 부른다 */
    private fun fetchSubText(tab: BrowserTab, url: String): String? {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return null
        return try {
            val wv = tab.liveWebView
            val b = okhttp3.Request.Builder().url(url)
            wv?.settings?.userAgentString?.let { b.header("User-Agent", it) }
            wv?.url?.takeIf { it.startsWith("http") }?.let { b.header("Referer", it) }
            cookieManagerFor(tab).getCookie(url)?.takeIf { it.isNotBlank() }?.let { b.header("Cookie", it) }
            PlayerHttp.client.newCall(b.build()).execute().use { r ->
                val body = r.body
                if (!r.isSuccessful || body == null || body.contentLength() > 3_000_000L) null else body.string()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** 덧씌운 컨트롤의 조작을 미러링 중인 영상에 보낸다 */
    private fun mirrorSend(cmd: String, v: Double) {
        val tab = current ?: return
        // 메뉴의 '재생 속도'와 같은 값을 쓰게 해서, 페이지를 옮겨도 고른 배속이 이어진다
        if (cmd == "rate") tab.rate = v.toFloat()
        tab.liveWebView?.evaluateJavascript(MediaScripts.mirrorCmd(cmd, v), null)
    }

    private fun toggleMirrorOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        mirrorRotated = true
    }

    private fun stopMirror() {
        if (!mirrorActive) return
        mirrorActive = false
        removeMirrorOverlay()
        // 창 여백을 원래대로 (카메라·상태표시줄 자리를 비워 둔다)
        (findViewById<View>(R.id.browserUi)?.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
        if (mirrorRotated) {
            mirrorRotated = false
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        tabs.forEach { it.liveWebView?.evaluateJavascript(MediaScripts.MIRROR_OFF, null) }
        // 미러링을 끄면 페이지의 영상이 비어 보일 수 있다: 내장 플레이어에서 돌아올 때처럼 두 번 다시 그리게 한다
        ui.postDelayed({ repaintPageVideos() }, 150L)
        ui.postDelayed({ repaintPageVideos() }, 600L)
        setFullscreenBackdrop(false)
        setSystemBarsVisible(true)
        toolbarView.visibility = View.VISIBLE
        applyLayoutMode(pip = false)
        refreshPipParams()
    }

    /**
     * 내장 플레이어의 이전/다음 영상: 페이지의 '이전·다음 영상' 버튼을 대신 누르고,
     * 새로 잡힌 영상 주소(누르기 전에 없던 것)를 찾으면 열려 있는 플레이어를 그 영상으로 바꾼다.
     */
    private fun skipBase(u: String): String = u.substringBefore('?')

    private fun playerSkip(tab: BrowserTab, dir: Int, curUrl: String) {
        val wv = tab.webView
        // 플레이어가 앞에 있는 동안 멈춰 있을 수 있는 페이지를 깨워서 버튼 누르기와 새 영상 요청이 돌아가게 한다
        tab.liveWebView?.onResume()
        tab.liveWebView?.resumeTimers()
        gatherMediaCands(tab) { before, _, _, _ ->
            val seen = HashSet<String>()
            for (c in before) seen.add(skipBase(c.url))
            seen.add(skipBase(curUrl))
            wv.evaluateJavascript(MediaScripts.pageSkip(dir)) { r ->
                if (r != null && r.contains("btn")) {
                    ui.postDelayed({ playerSkipPoll(tab, dir, seen, 0) }, 600L)
                } else {
                    PlayerActivity.skipFailed(if (dir > 0) "페이지에서 다음 영상 버튼을 찾지 못했어요" else "페이지에서 이전 영상 버튼을 찾지 못했어요")
                }
            }
        }
    }

    /** 버튼을 누른 뒤 0.5초마다 새로 잡힌 영상 주소를 찾아, 찾으면 열려 있는 플레이어를 그 영상으로 바꾼다 (최대 8초) */
    private fun playerSkipPoll(tab: BrowserTab, dir: Int, seen: Set<String>, tries: Int) {
        if (!PlayerActivity.isOpen()) return
        // 누른 뒤 페이지가 새 영상을 자동으로 틀기 시작해도 소리가 겹치지 않게
        pauseAllMedia()
        gatherMediaCands(tab) { list, _, pageTitle, subsJson ->
            val found = list.firstOrNull { skipBase(it.url) !in seen }
            val wv = tab.webView
            if (found != null) {
                PlayerActivity.switchTo(
                    found.url, pageTitle, wv.url, wv.settings.userAgentString,
                    cookieManagerFor(tab).getCookie(found.url), subsJson
                )
            } else if (tries < 15) {
                ui.postDelayed({ playerSkipPoll(tab, dir, seen, tries + 1) }, 500L)
            } else {
                PlayerActivity.skipFailed(if (dir > 0) "다음 영상을 찾지 못했어요" else "이전 영상을 찾지 못했어요")
            }
        }
    }

    /** 지금 페이지의 영상을 앱 안의 플레이어로 연다. 재생 중이던 위치에서 이어서 재생한다. */
    private fun openInternalPlayer(
        preferUrl: String? = null,
        preferPosMs: Long = 0L,
        fromVideoButton: Boolean = false
    ) {
        val tab = current ?: return
        val wv = tab.webView
        // 유튜브는 내장 플레이어를 쓰지 않는다. 대신 페이지에서 재생 중인 영상을 미러링(창 가득 보기)으로 보여 준다
        if (isYouTubeUrl(wv.url)) {
            wv.evaluateJavascript(
                "(function(){return document.querySelectorAll('video').length})()"
            ) { r ->
                if ((r?.trim()?.toIntOrNull() ?: 0) > 0) startMirror()
                else toast("재생 중인 유튜브 영상을 찾지 못했어요. 영상을 먼저 재생해 보세요")
            }
            return
        }
        gatherMediaCands(tab) { list, _, pageTitle, subsJson ->
            fun startPlayer(c: MediaCand, zoom: Boolean) {
                PlayerActivity.skipHook = { dir, cur -> playerSkip(tab, dir, cur) }
                PlayerActivity.start(
                    this, c.url, pageTitle, wv.url, wv.settings.userAgentString,
                    cookieManagerFor(tab).getCookie(c.url), c.posMs, subsJson, zoom
                )
                pauseAllMedia()
                playerOpened = true
                if (customView != null) hideCustomView()
            }

            // 확대 전환 없이 바로 플레이어를 연다
            fun launch(c: MediaCand) = startPlayer(c, false)

            // 영상 아래 버튼으로 연 경우: 그 영상의 주소를 바로 연다.
            if (preferUrl != null && (preferUrl.startsWith("http://") || preferUrl.startsWith("https://"))) {
                launch(MediaCand(preferUrl, preferPosMs))
                return@gatherMediaCands
            }
            // 영상 아래 버튼인데 그 영상의 주소를 직접 얻지 못한 경우(blob/MSE 등):
            // 지금 재생 중이라고 확인된 후보만 그 영상으로 본다. 확실하지 않으면 엉뚱한(가까운) 영상을 열지 않고 알림만 띄운다.
            if (fromVideoButton) {
                val target = list.firstOrNull { it.playing }
                if (target != null) {
                    launch(MediaCand(target.url, preferPosMs, true))
                } else if (prefs.mirrorFallback) {
                    // 내장 플레이어가 못 여는 영상: 다른 영상을 열지 않고, 페이지에서 재생되는 그대로 창 가득 보여 준다
                    startMirror()
                } else {
                    toast("이 영상에 맞는 주소를 찾지 못해 열지 않았어요")
                }
                return@gatherMediaCands
            }
            // 미러링 자동 전환이 켜져 있고 페이지에 영상이 있어 보이면, 못 찾았다는 창 없이 바로 미러링
            if (list.isEmpty() && prefs.mirrorFallback) {
                wv.evaluateJavascript(
                    "(function(){return document.querySelectorAll('video,iframe').length})()"
                ) { r ->
                    if ((r?.trim()?.toIntOrNull() ?: 0) > 0) startMirror() else showNoVideoDialog()
                }
                return@gatherMediaCands
            }
            when {
                list.isEmpty() -> showNoVideoDialog()
                list.size == 1 -> launch(list[0])
                // 지금 재생 중인 영상이 있으면 고르게 하지 않고 바로 그 영상을 연다 (이어서 재생)
                list.any { it.playing } -> launch(list.first { it.playing })
                else -> {
                    val names = list.map {
                        val host = runCatching { Uri.parse(it.url).host }.getOrNull().orEmpty()
                        val file = it.url.substringBefore('?').substringAfterLast('/').ifBlank { "영상" }
                        "$host · $file"
                    }.toTypedArray()
                    ThemedDialogBuilder(this)
                        .setTitle("내장 플레이어로 재생")
                        .setItems(names) { _, i -> launch(list[i]) }
                        .setNegativeButton("취소", null)
                        .show()
                }
            }
        }
    }

    /** 확대 전환이 시작할 영상 자리 (창 좌표 px). exact 는 영상이 화면 안에 거의 다 보이는지 */
    private class ZoomTarget(val rect: Rect, val exact: Boolean)

    /** 영상 아래 버튼이 방금 알려 준 영상 위치를 한 번만 꺼내 쓴다. 오래됐으면 버린다 */
    private fun takeZoomTarget(tab: BrowserTab): ZoomTarget? {
        val raw = tab.zoomRaw ?: return null
        tab.zoomRaw = null
        if (android.os.SystemClock.uptimeMillis() - tab.zoomRawAt > 4000L) return null
        return zoomTargetOf(tab.webView, raw)
    }

    /** 페이지가 알려 준 CSS px 위치를 창 좌표(px)로 바꾸고, 웹뷰 영역 밖으로 나간 부분은 자른다. 너무 작으면 null */
    private fun zoomTargetOf(wv: WebView, raw: DoubleArray): ZoomTarget? {
        if (wv.width <= 0 || wv.height <= 0 || !wv.isShown) return null
        val sc = wv.width / raw[4]
        val loc = IntArray(2)
        wv.getLocationInWindow(loc)
        val l = loc[0] + raw[0] * sc
        val t = loc[1] + raw[1] * sc
        val w = raw[2] * sc
        val h = raw[3] * sc
        val full = Rect(Math.round(l).toInt(), Math.round(t).toInt(), Math.round(l + w).toInt(), Math.round(t + h).toInt())
        val r = Rect(full)
        if (!r.intersect(loc[0], loc[1], loc[0] + wv.width, loc[1] + wv.height)) return null
        val d = resources.displayMetrics.density
        if (r.width() < 48 * d || r.height() < 32 * d) return null
        val exact = r.width().toLong() * r.height() >= full.width().toLong() * full.height() * 0.85
        return ZoomTarget(r, exact)
    }

    private fun showNoVideoDialog() {
        ThemedDialogBuilder(this)
            .setTitle("재생할 영상을 찾지 못했어요")
            .setMessage(
                "영상을 먼저 한 번 재생한 뒤 다시 눌러 보세요.\n\n" +
                    "암호화(DRM)된 영상이나 blob 방식으로만 재생되는 영상은 열 수 없습니다."
            )
            .setPositiveButton("확인", null)
            .setNeutralButton("화면 그대로 보기") { _, _ -> startMirror() }
            .show()
    }

    /**
     * 페이지의 영상을 찾아 기기에 저장한다.
     * 일반 파일(mp4 등)뿐 아니라 HLS(m3u8) 스트리밍(Android 10+, 조각을 받아 mp4 로 묶음),
     * 페이지가 만들어 둔 blob 파일, 주소에 확장자가 없는 영상, 다른 도메인 iframe 안에서 재생된 영상까지 후보에 올린다.
     * (내장 플레이어가 영상을 찾는 방식과 같다)
     */
    private fun findVideos() {
        val tab = current ?: return
        val wv = tab.webView
        gatherMediaCands(tab) { list, blobs, pageTitle, _ ->
            class Item(val url: String, val label: String, val kind: Int) // kind: 0 파일, 1 HLS, 2 blob
            val hlsOk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
            var skippedStream = false
            val files = ArrayList<Item>()
            val streams = ArrayList<Item>()
            for (c in list) {
                val low = c.url.lowercase()
                val host = runCatching { Uri.parse(c.url).host }.getOrNull().orEmpty()
                val file = c.url.substringBefore('?').substringAfterLast('/').ifBlank { "영상" }
                when {
                    // DASH / 스무스 스트리밍은 영상과 소리가 따로 쪼개져 있어 파일 하나로 받을 수 없다
                    low.contains(".mpd") || low.contains(".ism/") || low.substringBefore('?').endsWith(".ism") -> skippedStream = true
                    HlsDownload.looksLikeHls(c.url, null) || low.contains(".m3u8") ->
                        if (hlsOk) streams.add(Item(c.url, "[스트리밍] $host · $file", 1)) else skippedStream = true
                    else -> files.add(Item(c.url, "$host · $file", 0))
                }
            }
            val items = ArrayList<Item>()
            items.addAll(files)
            items.addAll(streams)
            blobs.forEachIndexed { i, b -> items.add(Item(b.url, "[페이지 안의 파일] 영상 ${i + 1}", 2)) }
            val shown = items.take(MEDIA_CAND_MAX)

            if (shown.isEmpty()) {
                ThemedDialogBuilder(this)
                    .setTitle("저장할 영상을 찾지 못했어요")
                    .setMessage(
                        (if (skippedStream) "이 페이지는 mpd(DASH)나 안드로이드 10 미만에서 받을 수 없는 스트리밍 영상만 있어요.\n\n" else "") +
                            "영상을 먼저 한 번 재생한 뒤 다시 눌러 보세요.\n\n" +
                            "보호(DRM)된 영상과 mpd 방식 영상은 저장할 수 없습니다."
                    )
                    .setPositiveButton("확인", null)
                    .show()
                return@gatherMediaCands
            }
            val names = shown.map { it.label }.toTypedArray()
            ThemedDialogBuilder(this)
                .setTitle("저장할 영상 선택")
                .setItems(names) { _, i ->
                    val it0 = shown[i]
                    when (it0.kind) {
                        1 -> enqueueDownload(
                            it0.url, wv.settings.userAgentString, null, "application/x-mpegURL",
                            pageTitle, cookieManagerFor(tab).getCookie(it0.url)
                        )
                        2 -> {
                            requestNotificationPermission()
                            toast("다운로드 시작")
                            localDownload.handle(wv, it0.url, null, null)
                        }
                        else -> enqueueDownload(
                            it0.url, wv.settings.userAgentString, null, null,
                            null, cookieManagerFor(tab).getCookie(it0.url)
                        )
                    }
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }

    // ───────────────────────── AI 어시스턴트 ─────────────────────────

    /**
     * 지금 보는 페이지의 제목·주소·본문·선택한 글을 모아 AI 에게 넘긴다. 열린 페이지가 없으면 null.
     * [withImages] 가 true 면 페이지 안의 사진(화면에 보이는 것 우선, 최대 [AssistantImages.MAX_IMAGES] 장)도 내려받아 함께 담는다.
     * 사진을 받는 동안 기다려야 하므로, 이 경우 [cb] 는 사진이 준비된 뒤에 메인 스레드에서 불린다.
     */
    private fun fetchPageForAssistant(withImages: Boolean, cb: (PageSnapshot?) -> Unit) {
        val tab = current
        if (tab == null || tab.isHome || !hasPage(tab)) {
            cb(null)
            return
        }
        tab.webView.evaluateJavascript(PAGE_TEXT_JS) { raw ->
            var snap: PageSnapshot? = null
            var cands: List<AssistantImages.Cand> = emptyList()
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    val o = JSONObject(inner)
                    snap = PageSnapshot(
                        o.optString("url"), o.optString("title"),
                        o.optString("text"), o.optString("sel")
                    )
                    if (withImages) cands = AssistantImages.parse(o.optJSONArray("imgs"))
                }
            } catch (e: Exception) {
                snap = null
            }
            val base = snap
            if (base == null || cands.isEmpty()) {
                cb(base)
            } else {
                // 메인 스레드에서 웹뷰 정보(UA·쿠키)를 미리 꺼내 두고, 내려받기는 백그라운드에서 한다
                val picked = AssistantImages.pick(cands)
                val ua = tab.webView.settings.userAgentString ?: ""
                val cm = cookieManagerFor(tab)
                val cookies = HashMap<String, String>()
                for (c in picked) {
                    if (!c.url.startsWith("http")) continue
                    cookies[c.url] = try {
                        cm.getCookie(c.url) ?: ""
                    } catch (e: Exception) {
                        ""
                    }
                }
                val total = cands.size
                Thread {
                    val imgs = try {
                        AssistantImages.load(picked, ua, cookies, base.url)
                    } catch (e: Throwable) {
                        emptyList()
                    }
                    ui.post { cb(base.copy(images = imgs, imageTotal = total)) }
                }.apply { isDaemon = true }.start()
            }
        }
    }

    /**
     * 꾹 눌러 「AI에게 물어보기」를 고른 사진 [url] 을 내려받아 AI 에게 보낼 사진으로 만든다.
     * 페이지 안에서 그 사진이 화면에 보이는 부분(긴 웹툰 사진을 자를 때 쓴다)과 설명(alt)을 찾아 같이 쓰고,
     * 내려받기는 백그라운드에서 하고 [cb] 는 메인 스레드에서 불린다. 못 받으면 null.
     */
    private fun fetchImageForAssistant(url: String, cb: (PageImage?) -> Unit) {
        val tab = current
        val wv = tab?.liveWebView
        if (tab == null || wv == null) {
            cb(null)
            return
        }
        fun go(cand: AssistantImages.Cand) {
            val ua = wv.settings.userAgentString ?: ""
            val cookie = try { cookieManagerFor(tab).getCookie(url) ?: "" } catch (e: Exception) { "" }
            val referer = wv.url ?: ""
            Thread {
                val img = try {
                    AssistantImages.loadChosen(cand, ua, cookie, referer)
                } catch (e: Throwable) {
                    null
                }
                ui.post { cb(img) }
            }.apply { isDaemon = true }.start()
        }
        val fallback = AssistantImages.Cand(url, "", 0.0, 0.0, -1.0, -1.0)
        if (tab.isHome || !hasPage(tab)) {
            go(fallback)
            return
        }
        wv.evaluateJavascript(PAGE_TEXT_JS) { raw ->
            var cand: AssistantImages.Cand? = null
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    cand = AssistantImages.parse(JSONObject(inner).optJSONArray("imgs")).firstOrNull { it.url == url }
                }
            } catch (e: Exception) {
                cand = null
            }
            go(cand ?: fallback)
        }
    }

    /** 지금 보는 페이지에서 JS 를 실행한다. 열린 페이지가 없으면 null 을 돌려준다. */
    private fun runJsOnCurrentPage(js: String, cb: (String?) -> Unit) {
        val tab = current
        if (tab == null || tab.isHome || !hasPage(tab)) {
            cb(null)
            return
        }
        tab.webView.evaluateJavascript(js) { raw -> cb(raw) }
    }

    private val downloadCard by lazy { DownloadProgressCard(this) { openDownloads() } }

    private val localDownload by lazy { LocalDownload(applicationContext) { msg -> toast(msg) } }

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("blob/data 형식 주소는 직접 다운로드할 수 없습니다")
            return
        }
        // 시크릿 탭의 로그인 쿠키는 앱 기본 저장소에 없으므로, 그 탭의 쿠키를 같이 넘긴다
        enqueueDownload(url, userAgent, contentDisposition, mimeType, null, cookieManagerFor(current).getCookie(url))
    }

    private fun enqueueDownload(
        url: String, userAgent: String?, contentDisposition: String?, mimeType: String?,
        title: String? = null, cookie: String? = null
    ) {
        val referer = current?.webView?.url?.takeIf { it.startsWith("http") }

        // Android 10 이상: 여러 연결로 나눠 받는 빠른 다운로드
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            requestNotificationPermission()
            try {
                DownloadService.start(this, url, userAgent, contentDisposition, mimeType, referer, title, cookie)
                // 시스템 알림 말고도 앱 안에서 진행 상황을 보여 준다
                downloadCard.begin()
                return
            } catch (e: Exception) {
                // 서비스를 시작하지 못하면 시스템 다운로더로
            }
        }
        systemDownload(url, userAgent, contentDisposition, mimeType, referer)
    }

    private fun systemDownload(
        url: String, userAgent: String?, contentDisposition: String?, mimeType: String?, referer: String?
    ) {
        val name = SystemDownload.enqueue(this, url, userAgent, contentDisposition, mimeType, referer)
        toast(if (name != null) "다운로드 중: $name" else "다운로드에 실패했습니다")
    }

    /** 이 앱의 알림이 시스템에서 허용돼 있는지 */
    private fun notificationsAllowed(): Boolean =
        try { androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled() } catch (e: Exception) { true }

    /** 휴대폰의 이 앱 알림 설정 화면을 연다 (열 수 없으면 앱 정보 화면) */
    private fun openSystemNotificationSettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName))
        } catch (e: Exception) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (e2: Exception) { /* 무시 */ }
        }
    }

    /** Android 13+ 에서 다운로드 진행 알림을 보이려면 알림 권한이 필요하다. (거부해도 다운로드는 진행됨) */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || askedNotificationPermission) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotificationPermission = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private var adListTryAt = 0L

    /**
     * 차단 목록이 없거나 3일이 지났으면 내려받는다.
     * 실패해도 일주일을 기다리지 않고, 앱을 다시 열 때(30분 간격 이상) 또 시도한다.
     */
    private fun autoUpdateAdBlockList() {
        val now = System.currentTimeMillis()
        val threeDays = 3L * 24 * 60 * 60 * 1000
        if (now - adBlocker.lastUpdated < threeDays) return
        if (now - adListTryAt < 30L * 60 * 1000) return
        adListTryAt = now
        prefs.adblockLastTry = now
        // 자동완성과 같은 스레드를 막지 않도록 별도 스레드에서 실행
        Thread {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            try {
                adBlocker.update()
            } catch (e: Exception) {
                // 실패하면 다음에 앱을 열 때 다시 시도
            }
        }.apply { isDaemon = true }.start()
    }

    /** 앱 안의 다운로드 목록 화면 (폴더로 정리 가능) */
    private fun openDownloads() {
        bookmarksLauncher.launch(listIntent(DownloadsActivity::class.java))
    }

    // ───────────────────────── 북마크 ─────────────────────────

    /** 지금 보고 있는 웹페이지 주소 (홈 화면이거나 웹페이지가 아니면 null) */
    private fun currentPageUrl(): String? {
        val tab = current ?: return null
        if (tab.isHome) return null
        return pageUrlOf(tab, tab.webView)?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun currentBookmark(): Bookmark? = currentPageUrl()?.let { prefs.findBookmark(it) }

    /** 현재 페이지를 북마크에 추가하거나, 이미 있으면 수정/삭제 대화상자를 연다. */
    private fun bookmarkCurrent() {
        val url = currentPageUrl()
        if (url == null) {
            toast("북마크할 웹페이지가 없습니다")
            return
        }
        val title = current?.webView?.title.orEmpty()
        ListUi.showBookmarkEditor(this, prefs, prefs.findBookmark(url), url, title) { msg -> toast(msg) }
    }

    private fun openHistory() {
        // 확장 프로그램이 기록 화면을 바꿨으면(chrome_url_overrides.history) 새 탭에서 그 페이지를 연다
        extensions.overrideUrl("history")?.let { createTab(it, opener = current); reopenMenuAfterListNot(); return }
        bookmarksLauncher.launch(listIntent(HistoryActivity::class.java))
    }

    private fun openBookmarks() {
        extensions.overrideUrl("bookmarks")?.let { createTab(it, opener = current); reopenMenuAfterListNot(); return }
        bookmarksLauncher.launch(listIntent(BookmarksActivity::class.java))
    }

    /** 목록 화면 대신 확장 페이지를 탭으로 열었을 때: 메뉴를 다시 열지 않도록 표시를 지운다 */
    private fun reopenMenuAfterListNot() { ListUi.reopenMenu = false }

    private fun showLinkMenu(link: String?, image: String?, anchor: View? = null) {
        fun isWeb(u: String?) = u != null && (u.startsWith("http://") || u.startsWith("https://"))
        val webLink = link?.takeIf { isWeb(it) }
        val webImage = image?.takeIf { isWeb(it) }
        if (webLink == null && webImage == null) return

        val target = webLink ?: webImage!!
        val items = mutableListOf<Popup.Item>()
        if (webLink != null) {
            items.add(Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { createTab(webLink, opener = current) })
            items.add(Popup.Item(R.drawable.ic_copy, "링크 주소 복사") { copyToClipboard(webLink) })
            items.add(Popup.Item(R.drawable.ic_share, "링크 공유") { shareText(webLink) })
            items.add(Popup.Item(R.drawable.ic_download, "링크 파일 다운로드") {
                startDownload(webLink, current?.webView?.settings?.userAgentString, null, null)
            })
        }
        if (webImage != null) {
            items.add(Popup.Item(R.drawable.ic_download, "이미지 저장") {
                startDownload(webImage, current?.webView?.settings?.userAgentString, null, null)
            })
            items.add(Popup.Item(R.drawable.ic_copy, "이미지 복사") { copyImageToClipboard(webImage) })
            items.add(Popup.Item(R.drawable.ic_image, "새 탭에서 이미지 열기") { createTab(webImage, opener = current) })
            if (webLink != null) items.add(Popup.Item(R.drawable.ic_copy, "이미지 주소 복사") { copyToClipboard(webImage) })
        }
        // 확장 프로그램의 우클릭 메뉴(contextMenus) 항목
        if (current?.incognito != true) {
            val menuCtx = HashSet<String>().apply { add("page"); if (webLink != null) add("link"); if (webImage != null) add("image") }
            val menuPage = current?.liveWebView?.url
            extensions.contextMenuEntries(menuCtx, menuPage, webLink, webImage).forEach { en ->
                items.add(Popup.Item(R.drawable.ic_extension, en.title, en.extName) {
                    extensions.contextMenuClick(en, menuPage, webLink, webImage)
                })
            }
        }
        // 자동 스크롤: 지금 보는 페이지를 설정한 속도로 저절로 내려 준다 (이미 흐르는 중이면 멈추기)
        current?.takeIf { !it.isHome }?.liveWebView?.let { wv ->
            if (autoScroller.isRunningOn(wv)) {
                items.add(Popup.Item(R.drawable.ic_stop_circle, "자동 스크롤 멈추기") { autoScroller.stop("자동 스크롤을 멈췄어요") })
            } else {
                items.add(Popup.Item(R.drawable.ic_auto_scroll, "자동 스크롤") { autoScroller.start(wv) })
            }
        }
        // AI 에게 물어보기: 질문을 입력창에 미리 채워 AI 창을 연다 (보내기 전에 고칠 수 있다)
        // 이미지만 꾹 눌렀다면 링크 주소 대신 그 사진을 AI 창에 첨부한다 (보내면 내 말풍선에 사진이 보인다)
        val askImage = if (webImage != null && webLink == null) webImage else null
        val askText = if (askImage != null) {
            "이 이미지가 무엇인지 설명해 주세요."
        } else {
            "이 링크가 어떤 내용인지 설명해 주세요: $target"
        }
        items.add(Popup.Item(R.drawable.ic_ai, "AI에게 물어보기") {
            assistant?.show(if (tbAi.isShown) tbAi else null, askText, askImage)
        })
        window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        val menuTitle = Uri.parse(target).host?.removePrefix("www.") ?: if (webLink != null) "링크" else "이미지"
        val menuIcon = if (webLink != null) R.drawable.ic_globe else R.drawable.ic_image
        if (anchor != null && anchor.isAttachedToWindow) {
            // 누른 자리 바로 아래에 띄운다 (창 안 좌표로 계산)
            val l = IntArray(2)
            anchor.getLocationInWindow(l)
            Popup.menuAnchored(
                this, anchor, title = menuTitle, subtitle = target, headerIcon = menuIcon,
                items = items, pointX = l[0] + tapX.toInt(), pointY = l[1] + tapY.toInt()
            )
        } else {
            Popup.menu(this, title = menuTitle, subtitle = target, headerIcon = menuIcon, items = items)
        }
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        try {
            startActivity(Intent.createChooser(send, "공유"))
        } catch (e: Exception) {
            toast("공유할 수 있는 앱이 없습니다")
        }
    }

    /**
     * 이미지 자체를 클립보드에 복사한다 (다른 앱에 붙여넣으면 주소가 아니라 사진이 들어간다).
     * 웹뷰와 같은 User-Agent·쿠키·Referer 로 받아 캐시 폴더에 두고, FileProvider 주소로 클립보드에 올린다.
     */
    private fun copyImageToClipboard(url: String) {
        val tab = current
        val ua = tab?.liveWebView?.settings?.userAgentString.orEmpty()
        val referer = tab?.liveWebView?.url.orEmpty()
        val cookie = try { cookieManagerFor(tab).getCookie(url).orEmpty() } catch (e: Exception) { "" }
        toast("이미지를 복사하는 중…")
        io.execute {
            var ok = false
            try {
                val bytes = AssistantImages.fetchBytes(url, ua, cookie, referer)
                if (bytes != null && bytes.isNotEmpty()) {
                    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    val ext = when (o.outMimeType) {
                        "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/jpeg" -> "jpg"
                        else -> null
                    }
                    if (ext != null) {
                        val dir = java.io.File(cacheDir, "clip_images")
                        dir.mkdirs()
                        dir.listFiles()?.forEach { it.delete() }   // 이전에 복사해 둔 사진은 지운다
                        val f = java.io.File(dir, "image_${System.currentTimeMillis()}.$ext")
                        f.writeBytes(bytes)
                        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.updates", f)
                        ui.post {
                            if (isFinishing || isDestroyed) return@post
                            try {
                                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newUri(contentResolver, "image", uri))
                                toast("이미지를 복사했어요")
                            } catch (e: Exception) { toast("이미지를 복사하지 못했어요") }
                        }
                        ok = true
                    }
                }
            } catch (e: Exception) { }
            if (!ok) ui.post { if (!isFinishing && !isDestroyed) toast("이미지를 복사하지 못했어요") }
        }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", text))
        toast("복사했습니다")
    }

    /** 앱 자체 알림을 띄울 때 창 아래에서 띄울 높이. 아래 막대(뒤로/홈/탭)가 보이면 그 바로 위, 아니면 0 */
    fun toastLift(): Int {
        var lift = 0
        if (::bottomBar.isInitialized && bottomBar.isShown && bottomBar.height > 0) {
            val l = IntArray(2)
            bottomBar.getLocationInWindow(l)
            lift = (window.decorView.height - l[1]) + dp(12)
        }
        return lift
    }

    private fun toast(msg: String) {
        AppToast.show(this, msg, toastLift())
    }

    companion object {
        /** 상단바·상태표시줄 유리: 흐림 반경(dp)과 색 덮는 정도(클수록 은은) */
        /** 시스템 미디어 플레이어(알림)를 눌렀을 때 열 탭의 번호 */
        internal const val EXTRA_OPEN_TAB = "evergreen.open_media_tab"

        /** 런처 아이콘 길게 누르기 바로가기 (res/xml/shortcuts.xml 과 같은 값) */
        private const val ACTION_SHORTCUT_NEW_TAB = "com.example.evergreen.action.NEW_TAB"
        private const val ACTION_SHORTCUT_NEW_INCOGNITO = "com.example.evergreen.action.NEW_INCOGNITO"
        private const val ACTION_SHORTCUT_WEB_SEARCH = "com.example.evergreen.action.WEB_SEARCH"
        private const val ACTION_SHORTCUT_BOOKMARKS = "com.example.evergreen.action.BOOKMARKS"
        private const val EXTRA_WINDOW_NO = "evergreen.window_no"
        private const val STATE_WINDOW_NO = "evergreen.state_window_no"
        private const val EXTRA_RESTORE = "evergreen.restore_tabs"
        private const val EXTRA_HANDOFF = "evergreen.tab_handoff"

        /** 새 창을 여는 방식: 기본(옆에 붙이기) / 팝업(떠 있는 창) */
        private const val WIN_DEFAULT = 0
        private const val WIN_POPUP = 1

        /** 새 창이 뜨는 동안 옮겨 갈 탭의 상태를 잠깐 맡아 두는 곳 (같은 프로세스라 Bundle 을 그대로 넘긴다) */
        private val handoffs = HashMap<Long, TabHandoff>()
        private var handoffSeq = 0L
        /** 새 탭(홈) 화면이 웹 기록에 남을 때 쓰는 주소 */
        const val HOME_URL = "evergreen://home"
        /** 저장해 둔 웹 기록을 되살리면, 새 탭(홈) 항목의 주소가 이렇게 내용이 빠진 data 주소로 돌아온다 */
        private const val RESTORED_DATA_URL = "data:text/html;charset=utf-8;base64,"
        /** 기기에서 연 HTML 파일을 불러올 때 쓰는 가짜 주소 (주소창에는 파일 이름만 보인다) */
        const val LOCAL_BASE = "https://local.evergreen/"
        private const val HOME_HTML =
            "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<title>새 탭</title>" +
            "<style>html,body{margin:0;background:transparent}</style></head><body></body></html>"

        /** 지금 떠 있는 창(인스턴스)들. 앱을 여러 창으로 띄울 수 있어서, 하나만 가진 자원은 이걸로 조율한다 */
        private val instances = ArrayList<MainActivity>()

        /** 지금 떠 있는 창들 (런처 진입점이 새 창을 띄울지 정하는 데 쓴다) */
        internal fun runningWindows(): List<MainActivity> = instances.toList()
        private var primary: MainActivity? = null

        /** 기기에서 연 HTML 파일의 이름 (주소 → 파일 이름) */
        private val localFileNames = HashMap<String, String>()

        /** 탭을 시스템 드래그로 끌고 있는 창 (다른 창의 탭 줄이 받을 수 있는지 판단하는 데 쓴다) */
        private var sysDragSource: MainActivity? = null

        /** 탭 화면의 카드 줄(가로 한 줄) 표시용 태그 */
        private const val CARD_ROW_TAG = "cardRow"

        /** 웹 페이지가 이동할 수 없게 막는 주소 형식 */
        private val BLOCKED_NAV_SCHEMES = setOf("file", "content", "javascript", "data", "filesystem")

        private const val MAX_HOME_SHORTCUTS = 8

        /** 뒤로가기 후 이 시간(ms) 안에 일어나는 '사용자 동작 없는' 페이지 이동은 자동 리다이렉트로 보고 막는다 */
        private const val BACK_GUARD_MS = 4000L
        private const val DOWNLOAD_TOUCH_MS = 15_000L

        /**
         * AI 어시스턴트에 넘길 페이지 내용 (본문은 3만 자까지) + 페이지 안의 사진 목록.
         * 사진 목록(imgs)에는 아이콘 크기를 넘는 <img> 만 담고, 각 사진이 지금 화면에 얼마나 보이는지(vis)와
         * 보이는 세로 구간(y0~y1, 사진 높이 대비)을 같이 알려 준다. 사진을 받는 건 앱(AssistantImages)이 한다.
         * (코틀린 원시 문자열이라 자바스크립트에 달러 기호를 쓰면 안 된다)
         */
        private const val PAGE_TEXT_JS = """(function(){
var t=(document.body&&document.body.innerText)||'';
var s='';try{s=String(window.getSelection())}catch(e){}
var imgs=[];
try{
var vw=window.innerWidth||document.documentElement.clientWidth||0;
var vh=window.innerHeight||document.documentElement.clientHeight||0;
var seen={};
var all=document.images;
for(var i=0;i<all.length&&imgs.length<80;i++){
var el=all[i];
var u=el.currentSrc||el.src||'';
var ds=el.getAttribute('data-src')||el.getAttribute('data-original')||el.getAttribute('data-lazy-src')||'';
if(ds&&(!u||u.indexOf('data:')===0)){try{u=new URL(ds,document.baseURI).href}catch(x){u=ds}}
if(!u||seen[u])continue;
if(u.indexOf('data:')===0&&(u.indexOf('data:image/')!==0||u.indexOf('data:image/svg')===0||u.length>3000000))continue;
var r=el.getBoundingClientRect();
if(r.width<80||r.height<80)continue;
var cs=window.getComputedStyle(el);
if(cs.visibility==='hidden'||cs.display==='none'||parseFloat(cs.opacity)===0)continue;
var nw=el.naturalWidth||0,nh=el.naturalHeight||0;
var tp=Math.max(0,r.top),bt=Math.min(vh,r.bottom),lf=Math.max(0,r.left),rt=Math.min(vw,r.right);
var vis=(bt>tp&&rt>lf)?(bt-tp)*(rt-lf):0;
var it={u:u,alt:String(el.alt||el.title||el.getAttribute('aria-label')||'').slice(0,120),vis:vis,area:r.width*r.height};
if(vis>0){it.y0=(tp-r.top)/r.height;it.y1=(bt-r.top)/r.height;}
if(u.indexOf('blob:')===0){
try{var k=Math.min(1,1280/Math.max(nw,nh,1));var cv=document.createElement('canvas');cv.width=Math.max(1,Math.round(nw*k));cv.height=Math.max(1,Math.round(nh*k));cv.getContext('2d').drawImage(el,0,0,cv.width,cv.height);it.u=cv.toDataURL('image/jpeg',0.85);}catch(x){continue;}
}
seen[u]=1;imgs.push(it);
}
}catch(e){}
return JSON.stringify({url:location.href,title:document.title||'',text:t.slice(0,30000),sel:s.slice(0,4000),imgs:imgs});
})()"""

        private const val FIND_VIDEO_JS =
            "(function(){var r=[];document.querySelectorAll('video,video source,audio source')" +
                ".forEach(function(e){var u=e.currentSrc||e.src;if(u&&/^https?:/.test(u))r.push(u);});" +
                "return JSON.stringify(Array.from(new Set(r)));})()"
    }
}

/** 입력한 글자와 상관없이 전달받은 목록을 그대로 보여주는 자동완성 어댑터 */
class NoFilterAdapter(context: Context, private val data: MutableList<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, data) {

    private val noFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): Filter.FilterResults =
            Filter.FilterResults().also {
                it.values = data
                it.count = data.size
            }

        override fun publishResults(constraint: CharSequence?, results: Filter.FilterResults?) {
            if (data.isNotEmpty()) notifyDataSetChanged() else notifyDataSetInvalidated()
        }
    }

    override fun getFilter(): Filter = noFilter
}

/**
 * 클릭 가로채기 차단용: 진짜 사용자 입력(touchstart/pointerdown/mousedown/click)이 일어날 때마다
 * 눌린 곳을 감싼 링크(a[href])의 주소를 앱(EvMedia.tap)에 알린다. 캡처 단계라 페이지의 처리기보다 먼저 돌고,
 * 앱 쪽 호출은 동기라서 페이지가 그 뒤에 어디로 보내든 앱은 '무엇을 눌렀는지' 먼저 알고 있다.
 * 스크립트가 만든 가짜 이벤트(isTrusted=false)는 무시한다.
 */
private const val HIJACK_TAP_JS = """
(function(){
 if(window.__evTap) return; window.__evTap=1;
 var rep=function(e){
  try{
   if(!e.isTrusted) return;
   var a=null, p=e.composedPath?e.composedPath():null, i, el;
   if(p){
    for(i=0;i<p.length;i++){
     el=p[i];
     if(el&&el.nodeType===1&&el.hasAttribute&&(el.tagName==='A'||el.tagName==='AREA'||el.localName==='a')&&el.hasAttribute('href')){ a=el; break; }
    }
   }
   if(!a&&e.target&&e.target.closest){ try{ a=e.target.closest('a[href],area[href]'); }catch(x){} }
   var h='';
   if(a){
    if(typeof a.href==='string') h=a.href;
    else{ h=a.getAttribute('href')||''; try{ h=new URL(h,location.href).href; }catch(x){} }
   }
   EvMedia.tap(h);
  }catch(x){}
 };
 var o={capture:true,passive:true};
 ['touchstart','pointerdown','mousedown','click'].forEach(function(n){ document.addEventListener(n,rep,o); });
})();
"""

/**
 * 영상 위에서 길게 눌러 끌면 웹뷰가 '선택 영역 통째로' 반투명 그림을 만들어 손가락에 달고 다니는 문제 차단.
 * 끌기 시작(dragstart)을 막는다: ① 영상 · 플레이어 안에서 시작한 끌기 ② 영상이 들어 있거나 화면의 큰 부분을 차지하는 글자 선택 끌기.
 * 이미지 · 링크 · 작은 글자 선택 끌기는 그대로 둔다. 주의: Kotlin 원시 문자열이라 달러 기호를 쓰지 않는다.
 */
private const val NO_GHOST_DRAG_JS = """
(function(){
 if(window.__evNoGhost) return; window.__evNoGhost=1;
 window.addEventListener('dragstart',function(e){
  try{
   var t=e.target, el=t&&t.nodeType===3?t.parentElement:t;
   if(!el||!el.closest) return;
   if(el.closest('video,.html5-video-player,#movie_player,[class*="video-player"],[class*="videoPlayer"]')){ e.preventDefault(); return; }
   var sel=window.getSelection&&window.getSelection();
   if(t&&t.nodeType===3&&sel&&sel.rangeCount&&!sel.isCollapsed){
    var r=sel.getRangeAt(0), b=r.getBoundingClientRect();
    var vw=window.innerWidth||1, vh=window.innerHeight||1;
    var big=(b.width*b.height)>0.35*vw*vh;
    var hasVideo=false; try{ var vs=document.querySelectorAll('video'); for(var i=0;i<vs.length;i++){ if(sel.containsNode(vs[i],true)){ hasVideo=true; break; } } }catch(x){}
    if(big||hasVideo) e.preventDefault();
   }
  }catch(x){}
 },true);
})();
"""

/**
 * 크롬 웹스토어 상세 페이지의 'Chrome에 추가' 버튼을 'evergreen에 추가'로 바꾸고, 누르면 앱이 확장 프로그램을 설치하게 한다.
 * - 버튼 글자는 언어마다 달라서, 'Chrome' 이 들어 있고 '추가/Add/追加…' 가 들어 있는 짧은 버튼을 찾는다 ('삭제/Remove/추가됨' 은 제외).
 * - 웹스토어가 지원하지 않는 브라우저라며 버튼을 비활성(회색)으로 두는 경우가 있어서 켜 주고 파란색으로 칠한다.
 * - 웹스토어 화면은 나중에 다시 그려지므로 MutationObserver 로 계속 맞춘다 (이미 맞으면 아무것도 바꾸지 않아 반복되지 않는다).
 * - 누르면 캡처 단계에서 페이지의 처리기보다 먼저 막고 EvStore.install() 을 부른다 (사용자가 직접 누른 경우만).
 * 주의: 이 문자열은 Kotlin 원시 문자열이라 JS 안에 달러 기호를 쓰지 않는다.
 */
private const val STORE_BUTTON_JS = """
(function(){
 if(window.__evStore) return;
 if(!/(^|\.)chromewebstore\.google\.com|^chrome\.google\.com/.test(location.hostname)) return;
 window.__evStore=1;
 var ko=/^ko/i.test(document.documentElement.lang||navigator.language||'');
 var L_ADD=ko?'evergreen에 추가':'Add to evergreen';
 var L_BUSY=ko?'설치 중…':'Installing…';
 var L_DEL=ko?'evergreen에서 삭제':'Remove from evergreen';
 var L_BUSYDEL=ko?'삭제 중…':'Removing…';
 var L_NO=ko?'evergreen\uACFC \uD638\uD658\uB418\uC9C0 \uC54A\uC544\uC694':'Not compatible with evergreen';
 var L_WARN=ko?'그래도 evergreen에 추가':'Add to evergreen anyway';
 var label=L_ADD, busy=false, busyTxt=L_BUSY, inst=false, incompat='', hard=false, checked='';
 var ADDW=/add|추가|追加|添加|新增|añadir|agregar|ajouter|hinzufügen|adicionar|aggiungi|добавить|toevoegen|ekle|dodaj|thêm|เพิ่ม|إضافة|הוסף/i;
 var REMW=/remove|삭제|제거|削除|移除|eliminar|supprimer|entfernen|remover|удалить|added|추가됨|追加済|已添加|añadido|ajouté/i;
 function txt(el){ return (el.innerText||el.textContent||'').replace(/\s+/g,' ').trim(); }
 function isAdd(el){
  var t=txt(el);
  if(!t||t.length>40) return false;
  if(REMW.test(t)) return false;
  return /chrome|크롬/i.test(t)&&ADDW.test(t);
 }
 function setText(el){
  var w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT,null), n, first=null;
  while((n=w.nextNode())){
   if(!n.data.trim()) continue;
   if(!first){ first=n; if(n.data!==label) n.data=label; }
   else if(n.data!=='') n.data='';
  }
  if(!first&&txt(el)!==label) el.textContent=label;
 }
 function fix(el){
  el.setAttribute('data-evx','1');
  if(el.hasAttribute('disabled')){ el.removeAttribute('disabled'); }
  if(el.disabled) el.disabled=false;
  if(el.getAttribute('aria-disabled')==='true') el.setAttribute('aria-disabled','false');
  var st=el.style;
  if(st.pointerEvents!=='auto') st.setProperty('pointer-events','auto','important');
  var mode=inst?'d':(incompat?(hard?'n':'w'):'a');
  if(el.getAttribute('data-evs')!==mode){
   el.setAttribute('data-evs',mode);
   st.setProperty('background-color',inst?'#fff':(mode==='n'?'#e8eaed':(mode==='w'?'#f9ab00':'#1a73e8')),'important');
   st.setProperty('color',inst?'#d93025':(mode==='n'?'#80868b':(mode==='w'?'#202124':'#fff')),'important');
   st.setProperty('border',inst?'1px solid #dadce0':'none','important');
   st.setProperty('cursor',mode==='n'?'not-allowed':'pointer','important');
   if(mode==='n'||mode==='w') el.setAttribute('title',incompat); else el.removeAttribute('title');
  }
  // 글자는 버튼 안쪽 요소(span)에 따로 색이 칠해져 있는 경우가 많다: 흰 바탕(삭제)에서 흰 글자가 되지 않게 안쪽 요소도 버튼 색을 따르게 한다
  var kids=el.querySelectorAll('*'), k;
  for(k=0;k<kids.length;k++){
   if(kids[k].style.getPropertyValue('color')!=='inherit') kids[k].style.setProperty('color','inherit','important');
  }
  setText(el);
 }
 var BRAND=/^chrome\s*(웹\s*스토어|web\s*store)\s*/i;
 function brand(){
  var w=document.createTreeWalker(document.body||document.documentElement,NodeFilter.SHOW_TEXT,null), n, t;
  while((n=w.nextNode())){
   t=n.data; if(t.length>40||t.indexOf('evergreen')>=0) continue;
   if(BRAND.test(t.trim())&&t.trim().length<=24) n.data=t.trim()+' for evergreen';
  }
  if(document.title.indexOf('evergreen')<0) document.title=document.title.replace(/chrome\s*(웹\s*스토어|web\s*store)/i,function(m){return m+' for evergreen';});
 }
 function scan(){
  try{ brand(); }catch(x){}
  try{ inst=EvStore.installed(location.href)===true; }catch(x){}
  if(location.href!==checked){ checked=location.href; incompat=''; hard=false; try{ EvStore.checkCompat(checked); }catch(x){} }
  label=busy?busyTxt:(inst?L_DEL:(incompat?(hard?L_NO:L_WARN):L_ADD));
  var els=document.querySelectorAll('button,[role="button"],a[role="button"]'), i, el;
  for(i=0;i<els.length;i++){
   el=els[i];
   if(el.hasAttribute('data-evx')) fix(el);
   else if(isAdd(el)) fix(el);
  }
 }
 var tm=0;
 function later(){ if(tm) return; tm=setTimeout(function(){ tm=0; try{ scan(); }catch(x){} },80); }
 function start(){
  scan();
  try{ new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['disabled','aria-disabled','class']}); }catch(x){}
 }
 if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start); else start();
 var block=function(e){
  var el=e.target&&e.target.closest?e.target.closest('[data-evx]'):null;
  if(!el) return;
  e.stopImmediatePropagation(); e.stopPropagation();
  if(e.type==='click'){
   e.preventDefault();
   if(incompat&&hard&&!inst) return;
   if(e.isTrusted&&!busy){
    busyTxt=inst?L_BUSYDEL:L_BUSY; busy=true; scan();
    try{ if(inst) EvStore.remove(); else EvStore.install(); }catch(x){ window.__evxState(false); }
   }
  }
 };
 ['click','auxclick','pointerdown','pointerup','mousedown','mouseup','touchstart','touchend'].forEach(function(t){
  window.addEventListener(t,block,true);
 });
 window.__evxCompat=function(r,h){ incompat=String(r||''); hard=!!h; scan(); };
 window.__evxState=function(ok){ busy=false; scan(); };
})();
"""

/**
 * 유튜브 HDR: 사이트는 (dynamic-range: high) 미디어 쿼리와 MediaCapabilities 로 HDR 재생이 되는지 묻는다.
 * 웹뷰는 HDR 화면이어도 이 두 질문에 '아니오' 로 답하는 일이 있어 화질 메뉴에 HDR 이 빠진다.
 *  ① (dynamic-range: high) / (video-dynamic-range: high) → 참
 *  ② decodingInfo 가 HDR(PQ · HLG · rec2020) 때문에 거절하면, HDR 조건만 빼고 다시 물어 디코더가 되면 지원으로 답한다
 *     (디코더 자체가 안 되면 그대로 거절 — 안 되는 걸 되는 척 하지 않는다)
 */
private const val HDR_SHIM_JS = """
(function(){
  try {
    if (window.__evHdr) return; window.__evHdr = 1;
    var mm = window.matchMedia && window.matchMedia.bind(window);
    if (mm) window.matchMedia = function(q) {
      var s = String(q);
      if (/(^|[^-])(video-)?dynamic-range\s*:\s*high/.test(s) && !/not\s/.test(s)) {
        return { matches: true, media: s, onchange: null,
          addListener: function(){}, removeListener: function(){},
          addEventListener: function(){}, removeEventListener: function(){}, dispatchEvent: function(){ return false; } };
      }
      return mm(q);
    };
    var mc = navigator.mediaCapabilities;
    if (mc && mc.decodingInfo) {
      var orig = mc.decodingInfo.bind(mc);
      mc.decodingInfo = function(cfg) {
        return orig(cfg).then(function(r) {
          try {
            var v = cfg && cfg.video;
            if (r && r.supported) return r;
            if (!v || !(v.transferFunction || v.colorGamut || v.hdrMetadataType)) return r;
            var v2 = {}; for (var k in v) if (k !== 'transferFunction' && k !== 'colorGamut' && k !== 'hdrMetadataType') v2[k] = v[k];
            var c2 = {}; for (var j in cfg) c2[j] = cfg[j]; c2.video = v2;
            return orig(c2).then(function(r2) {
              if (r2 && r2.supported) return { supported: true, smooth: r2.smooth, powerEfficient: r2.powerEfficient, keySystemAccess: r2.keySystemAccess || null };
              return r;
            });
          } catch (e) { return r; }
        });
      };
    }
  } catch (e) {}
})();
"""

/**
 * 웹툰 이미지 이음새 보정.
 * 페이지가 화면에 맞춰 줄어들어 보이거나(데스크톱 사이트·페이지 확대/축소) 화면 배율이 정수가 아니면
 * 이미지 가장자리가 소수 픽셀에 걸려, 이미지와 이미지 사이로 배경색 선이 비친다.
 * 위아래로 맞붙은 큰 이미지는 아래 이미지를 위로 '기기 픽셀 1.5개' 만큼만 겹쳐 올려 선을 덮는다.
 * (예전엔 위 이미지 밑에 마지막 한 줄을 늘인 띠를 붙였는데, 띠와 이미지가 맞닿는 가장자리에 옅은 선이 남고
 *  늦게 불러온 이미지는 자리표시 이미지가 띠로 남았다. 겹쳐 올리는 방식은 그런 가장자리 자체가 없다)
 * <img> 뿐 아니라 배경 그림(style="background:url(..)")으로 이어 붙인 페이지도 같은 방식으로 처리한다.
 *
 * 스크롤이 끊기지 않게: ① 스크롤 중에는 하지 않고 멈춘 뒤에 한다 ② 읽기를 한꺼번에 먼저 하고 쓰기를 나중에 한꺼번에 한다
 * (읽기·쓰기를 번갈아 하면 이미지마다 레이아웃을 다시 계산하게 된다) ③ 이미지 위치가 그대로면 건너뛴다.
 */
private const val SEAM_FIX_JS = """
(function(){
 if(window.__evSeam)return; window.__evSeam=1;
 var timer=0,lastScroll=0,lastSig='';
 // 기기 픽셀 1개가 CSS px 로 얼마인지 (화면 배율 × 페이지 축소 배율)
 function devPx(){
  var iw=window.innerWidth||document.documentElement.clientWidth||0;
  var sw=(window.screen&&screen.width)||iw;
  var s=iw>0?Math.min(1,sw/iw):1; if(!(s>0))s=1;
  var d=window.devicePixelRatio||1; if(!(d>0))d=1;
  return 1/(d*s);
 }
 function run(){
  timer=0;
  if(Date.now()-lastScroll<700){later();return}
  var imgs=document.querySelectorAll('img,[style*="url("]'); if(!imgs||imgs.length<2)return; // <img> 와 배경 그림 요소
  var vw=window.innerWidth||document.documentElement.clientWidth||0;
  var sy=window.pageYOffset||0;
  var px=devPx();
  var ov=Math.min(6,Math.max(0.3,1.5*px)); // 약 1.5 기기 픽셀만 겹친다 (그림이 눈에 띄게 잘리지 않는 양)
  // 1) 읽기만 한다
  var L=[],sig=vw+'|'+ov.toFixed(2)+'|'+imgs.length;
  for(var i=0;i<imgs.length;i++){
   var im=imgs[i];
   var isI=im.tagName==='IMG';
   if(isI&&(!im.complete||!im.naturalHeight)){L.push(null);continue}
   var r=im.getBoundingClientRect();
   if(r.width<vw*0.4||r.height<40){L.push(null);continue}
   L.push({isI:isI,im:im,top:r.top+sy,bot:r.bottom+sy,l:r.left,w:r.width});
   sig+='|'+Math.round(r.top+sy)+','+Math.round(r.height);
  }
  // 위치가 그대로면 건너뛴다 (이미지가 늦게 뜨거나 바뀌면 위치가 달라져 다시 한다)
  if(sig===lastSig)return;
  lastSig=sig;
  // 2) 무엇을 바꿀지 정한다: 위 이미지에 바로 맞붙은 이미지는 위로 ov 만큼 겹쳐 올린다
  var va=[],set=[],prev=null;
  for(var k=0;k<L.length;k++){
   var c=L[k];
   if(!c){prev=null;continue}
   if(c.isI&&c.im.__evs!==1)va.push(c.im);
   var want=0;
   if(prev){
    var cur=c.im.__evo||0; // 이미 겹쳐 둔 만큼은 원래 간격에 되돌려 더해서 본다
    var gap=c.top-prev.bot+cur;
    if(Math.abs(c.l-prev.l)<4&&Math.abs(c.w-prev.w)<4&&gap>-1&&gap<1.5*px+0.5)want=ov;
   }
   if(Math.abs((c.im.__evo||0)-want)>0.01){
    if(want&&c.im.__evbase===undefined){
     var mt=parseFloat(getComputedStyle(c.im).marginTop); c.im.__evbase=isNaN(mt)?0:mt;
     c.im.__evinl=c.im.style.getPropertyValue('margin-top'); c.im.__evpri=c.im.style.getPropertyPriority('margin-top');
    }
    set.push([c.im,want]);
   }
   prev=c;
  }
  // 3) 쓰기만 한다
  for(var a=0;a<va.length;a++){va[a].__evs=1;va[a].style.setProperty('vertical-align','top','important');}
  for(var b=0;b<set.length;b++){
   var m=set[b][0],w=set[b][1];
   if(w)m.style.setProperty('margin-top',(m.__evbase-w)+'px','important');
   else if(m.__evinl)m.style.setProperty('margin-top',m.__evinl,m.__evpri);
   else m.style.removeProperty('margin-top');
   m.__evo=w;
  }
 }
 function later(){ if(!timer)timer=setTimeout(run,300); }
 function start(){
  later();
  document.addEventListener('load',later,true);
  window.addEventListener('scroll',function(){lastScroll=Date.now()},{passive:true,capture:true});
  window.addEventListener('resize',later);
  window.addEventListener('orientationchange',later);
  try{ new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true}); }catch(e){}
  setTimeout(later,1500);setTimeout(later,4000);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start); else start();
})();
"""

/** 페이지 확대/축소: 뷰포트 너비를 W 로 바꾼다 (W = 화면 너비 ÷ 배율). 위에서 `var W=...;` 를 먼저 붙여 쓴다. */
private const val PAGE_ZOOM_ON_JS = """
var d=document,h=d.head||d.documentElement;
var m=d.querySelector('meta[name=viewport]');
if(!window.__evZ){window.__evZ={}}
var Z=window.__evZ;
Z.w=W;
Z.fix=function(){
 var mm=d.querySelector('meta[name=viewport]');
 var c='width='+Z.w+',minimum-scale=0.05,maximum-scale=10,user-scalable=yes';
 if(!mm){mm=d.createElement('meta');mm.name='viewport';mm.setAttribute('data-ev-added','1');(d.head||d.documentElement).appendChild(mm)}
 if(mm.getAttribute('data-ev-orig')===null&&!mm.hasAttribute('data-ev-added'))mm.setAttribute('data-ev-orig',mm.getAttribute('content')||'');
 if(mm.getAttribute('content')!==c)mm.setAttribute('content',c);
};
Z.fix();
if(!Z.obs){
 Z.obs=new MutationObserver(function(){
  var mm=d.querySelector('meta[name=viewport]');
  if(!mm||mm.getAttribute('content')!=='width='+Z.w+',minimum-scale=0.05,maximum-scale=10,user-scalable=yes'){
   if(mm&&mm.getAttribute('data-ev-orig')===null&&!mm.hasAttribute('data-ev-added'))mm.setAttribute('data-ev-orig',mm.getAttribute('content')||'');
   Z.fix();
  }
 });
 Z.obs.observe(d.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['content','name']});
}
"""

/** 페이지 확대/축소 해제: 원래 뷰포트로 되돌린다 */
private const val PAGE_ZOOM_OFF_JS = """
(function(){
 var Z=window.__evZ; if(!Z)return;
 if(Z.obs){Z.obs.disconnect();Z.obs=null}
 var mm=document.querySelector('meta[name=viewport]');
 if(mm){
  if(mm.hasAttribute('data-ev-added')){mm.remove()}
  else if(mm.getAttribute('data-ev-orig')!==null){mm.setAttribute('content',mm.getAttribute('data-ev-orig'));mm.removeAttribute('data-ev-orig')}
 }
 window.__evZ=null;
})();
"""

/** 하위 요청에서 영상으로 보는 확장자 / 자막 확장자 (요청마다 목록을 새로 만들지 않도록 한 번만 만든다) */
private val SNIFF_MEDIA_EXTS = hashSetOf(
    "m3u8", "mpd", "mp4", "webm", "m4v", "mov", "mkv", "avi", "flv", "3gp", "3g2", "f4v", "m2ts", "mts",
    "ogv", "ogm", "wmv", "asf", "ismv", "mpg", "mpeg"
)
/** 탭마다 기억해 두는 영상 후보 주소 최대 개수 / 한 번에 보여 주는 후보 최대 개수 */
private const val SNIFF_MAX = 60
private const val MEDIA_CAND_MAX = 25
private val SNIFF_SUB_EXTS = hashSetOf("vtt", "srt", "ass", "ssa", "ttml", "dfxp")
/** 파일이 아니라 프로그램이 영상을 내려 주는 주소의 확장자 (예: video.php?id=3) */
private val DYNAMIC_MEDIA_EXTS = hashSetOf("php", "asp", "aspx", "jsp", "cgi", "do", "action", "ashx")

/** 끌어 온 파일을 페이지에 첨부하는 스크립트: 놓은 자리에 drop 이벤트 → 처리되지 않았으면 파일 선택 칸에 직접 넣는다 */
private const val DROP_JS = """(function(){try{
var items=__ITEMS__,px=__X__,py=__Y__,dpr=window.devicePixelRatio||1,CH=786432,files=[];
for(var k=0;k<items.length;k++){var it=items[k],parts=[];
 for(var off=0;off<it.size;off+=CH){var b=EvDrop.read(it.id,off,Math.min(CH,it.size-off));
  if(!b)return 'err';var bin=atob(b),u=new Uint8Array(bin.length);
  for(var i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);parts.push(u);}
 files.push(new File(parts,it.name,{type:it.type}));}
var dt=new DataTransfer();files.forEach(function(f){dt.items.add(f)});
var cx=px/dpr,cy=py/dpr,el=document.elementFromPoint(cx,cy)||document.body;
function fire(t){var ev=new DragEvent(t,{bubbles:true,cancelable:true,dataTransfer:dt,clientX:cx,clientY:cy});el.dispatchEvent(ev);return ev.defaultPrevented;}
fire('dragenter');fire('dragover');
if(fire('drop'))return 'ok';
var inp=null;
if(el.tagName==='INPUT'&&el.type==='file')inp=el;
else{var lb=el.closest&&el.closest('label');if(lb&&lb.control&&lb.control.type==='file')inp=lb.control;}
if(!inp){var all=[].slice.call(document.querySelectorAll('input[type=file]')).filter(function(i){return !i.disabled});
 var fm=el.closest&&el.closest('form');
 inp=(fm&&all.filter(function(i){return fm.contains(i)})[0])||
  all.filter(function(i){var r=i.getBoundingClientRect();return r.width>0&&r.height>0})[0]||all[0];}
if(!inp)return 'none';
var d2=new DataTransfer();(inp.multiple?files:files.slice(0,1)).forEach(function(f){d2.items.add(f)});
inp.files=d2.files;
inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));
return 'ok';}catch(e){return 'err'}})()"""
