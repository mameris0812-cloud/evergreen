package com.example.evergreen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 방문 기록.
 * - 맨 위 '최근 1시간' 과 날짜별(오늘 / 어제 / 11월 3일 (화) …)로 묶여 있고, 줄을 누르면 기록이 펼쳐지고 접힌다.
 *   처음 열면 '최근 1시간' 과 '오늘' 이 함께 펼쳐져 있다.
 * - 항목을 누르면 현재 탭, ⋮ 메뉴(또는 길게 누르기)로 새 탭 열기 / 주소 복사 / 삭제
 * - 고른 주소는 북마크 화면과 같은 방식(EXTRA_URL)으로 MainActivity 에 돌려준다.
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private val adapter = RowAdapter()
    private lateinit var select: ListSelect<String>

    /** 목록에 그려지는 줄: 날짜 줄 또는 기록 한 개 */
    private sealed class Row {
        class Header(val day: Long, val label: String, val count: Int, val open: Boolean) : Row()
        class Entry(val item: HistoryItem, val day: Long) : Row()
    }

    private companion object {
        /** 맨 위 '최근 1시간' 줄의 day 값 (실제 날짜 0시 시각이나 0(날짜 없음)과 겹치지 않는 값) */
        const val RECENT_DAY = -2L
        const val RECENT_MS = 60L * 60L * 1000L
    }

    private val rows = ArrayList<Row>()
    /** 선택 · 전체 선택의 대상: 접혀 있는 날의 기록까지 모두 */
    private val allItems = ArrayList<HistoryItem>()
    /** 펼쳐 둔 날 (그 날 0시의 시각). 처음엔 '최근 1시간'과 오늘이 펼쳐져 있다 */
    private val openDays = HashSet<Long>()
    private var firstShow = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        ThemeColors.skin(findViewById(android.R.id.content))   // XML 의 ?attr 색에도 테마 색 입히기 (목록 줄은 만들어질 때마다 자동)
        ListUi.fitSystemBars(this)
        ListUi.applyTabletPopup(this)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "방문 기록"
        findViewById<View>(R.id.btnListBack).setOnClickListener { ListUi.closeSheet(this, backToMenu = true) }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        // 날짜별 목록이라 칩 줄은 쓰지 않는다
        (findViewById<View>(R.id.chipRow).parent as? View)?.visibility = View.GONE
        listView.adapter = adapter
        select = ListSelect(
            this, listView, findViewById(R.id.btnListAction), findViewById(R.id.listTitle),
            visibleKeys = { allItems.map { it.url } },
            onChanged = { adapter.notifyDataSetChanged() },
            onDelete = { urls -> deleteMany(urls) }
        )

        // 방문 기록을 열면 '최근 1시간'과 '오늘'이 함께 미리 펼쳐져 있다 (나머지 날짜는 접힌 채)
        openDays.add(RECENT_DAY)
        openDays.add(startOfToday())
        refreshView()
    }

    private fun startOfDay(t: Long): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun startOfToday(): Long = startOfDay(System.currentTimeMillis())

    /** 오늘 / 어제 / 11월 3일 (화) — 올해가 아니면 연도도 붙인다 */
    private fun dayLabel(day: Long): String {
        val today = startOfToday()
        if (day == today) return "오늘"
        if (day == startOfDay(today - 1)) return "어제"
        val sameYear = Calendar.getInstance().apply { timeInMillis = day }.get(Calendar.YEAR) ==
            Calendar.getInstance().apply { timeInMillis = today }.get(Calendar.YEAR)
        val fmt = if (sameYear) "M월 d일 (E)" else "yyyy년 M월 d일 (E)"
        return SimpleDateFormat(fmt, Locale.KOREA).format(Date(day))
    }

    private fun refreshView() {
        val all = prefs.historyItems().sortedByDescending { it.time }
        allItems.clear()
        allItems.addAll(all)

        // 날짜별로 묶는다 (시간이 없는 오래된 기록은 맨 아래 '날짜 없음' 으로)
        val byDay = LinkedHashMap<Long, MutableList<HistoryItem>>()
        all.forEach { byDay.getOrPut(if (it.time > 0L) startOfDay(it.time) else 0L) { ArrayList() }.add(it) }

        rows.clear()
        // 맨 위: 최근 1시간 줄 (날짜 줄과 같은 방식으로 펼치고 접는다. 1시간 안의 기록이 없으면 보이지 않는다)
        val cutoff = System.currentTimeMillis() - RECENT_MS
        val recent = all.filter { it.time > 0L && it.time >= cutoff }
        if (recent.isNotEmpty()) {
            val open = RECENT_DAY in openDays
            rows.add(Row.Header(RECENT_DAY, "최근 1시간", recent.size, open))
            if (open) recent.forEach { rows.add(Row.Entry(it, RECENT_DAY)) }
        }
        byDay.forEach { (day, list) ->
            val open = day in openDays
            rows.add(Row.Header(day, if (day == 0L) "날짜 없음" else dayLabel(day), list.size, open))
            if (open) list.forEach { rows.add(Row.Entry(it, day)) }
        }
        select.retain()
        adapter.notifyDataSetChanged()
        if (firstShow) listView.postDelayed({ firstShow = false }, 700)

        if (rows.isEmpty()) {
            emptyView.text = "방문 기록이 없습니다"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    /** 날짜 줄 안의 기록은 시각만 보여 준다 (날짜는 위 줄에 있다) */
    private fun timeLabel(t: Long): String =
        if (t <= 0L) "" else SimpleDateFormat("a h:mm", Locale.KOREA).format(Date(t))

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getViewTypeCount(): Int = 2
        override fun getItemViewType(position: Int): Int = if (rows[position] is Row.Header) 0 else 1

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
            when (val r = rows[position]) {
                is Row.Header -> headerView(r, convertView, parent, position)
                is Row.Entry -> entryView(r, convertView, parent)
            }

        private fun headerView(r: Row.Header, convertView: View?, parent: ViewGroup, position: Int): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_history_date, parent, false)
            resetAnim(v)
            val chevron = v.findViewById<ImageView>(R.id.dateChevron)
            v.findViewById<TextView>(R.id.dateLabel).text = r.label
            // 눌러서 돌고 있는 화살표는 건드리지 않는다 (상태가 다를 때만 곧바로 맞춘다)
            if (chevron.tag != r.open) {
                chevron.animate().cancel()
                chevron.rotation = if (r.open) 180f else 0f
                chevron.tag = r.open
            }
            v.contentDescription = "${r.label}, 기록 ${r.count}개, " + if (r.open) "접기" else "펼치기"
            v.setOnClickListener { toggleDay(r, chevron) }
            return v
        }

        private fun entryView(r: Row.Entry, convertView: View?, parent: ViewGroup): View {
            val h = r.item
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)
            resetAnim(v)

            select.bindRow(v, h.url, R.drawable.ic_globe)
            if (!select.isSelected(h.url) || !select.active) Favicons.apply(v.findViewById(R.id.rowIcon), h.url)
            v.findViewById<ProgressBar>(R.id.rowProgress).visibility = View.GONE
            v.findViewById<TextView>(R.id.rowTitle).text = ListUi.displayTitle(h.title, h.url)
            val label = timeLabel(h.time)
            v.findViewById<TextView>(R.id.rowSub).text = if (label.isEmpty()) h.url else "$label · ${h.url}"

            v.setOnClickListener { if (select.active) select.toggle(h.url) else openUrl(h.url, newTab = false) }
            v.setOnLongClickListener {
                if (select.active) select.toggle(h.url) else select.enter(h.url)
                true
            }
            v.findViewById<ImageButton>(R.id.rowMore).setOnClickListener { showMenu(h) }
            return v
        }
    }

    /** 재활용되는 행에 남은 애니메이션 흔적을 지운다 */
    private fun resetAnim(v: View) {
        Motion.cancel(v)
        v.animate().cancel()
        v.alpha = 1f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f; v.clipBounds = null
    }

    /** 줄을 알아보는 열쇠 (목록이 다시 그려져도 같은 줄인지 알아보려고) */
    private fun rowKey(r: Row): String = when (r) {
        is Row.Header -> "h${r.day}"
        is Row.Entry -> "e${r.day}|${r.item.url}"
    }

    /** 지금 화면에 보이는 줄들의 위치 (움직이는 중이면 눈에 보이는 위치) */
    private fun snapshotTops(): HashMap<String, Int> {
        val m = HashMap<String, Int>()
        for (i in 0 until listView.childCount) {
            val r = rows.getOrNull(listView.firstVisiblePosition + i) ?: continue
            val v = listView.getChildAt(i)
            m[rowKey(r)] = (v.top + v.translationY).toInt()
        }
        return m
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** 돌고 있는 펼침·접힘 움직임 (있으면 다음 누름 전에 끝난 상태로 맞춘다) */
    private var toggleAnim: android.animation.ValueAnimator? = null
    private val openInterp = android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)
    private val closeInterp = android.view.animation.PathInterpolator(0.4f, 0f, 0.2f, 1f)

    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x

    private fun viewAt(pos: Int): View? = listView.getChildAt(pos - listView.firstVisiblePosition)

    private fun clearAnimState() {
        for (i in 0 until listView.childCount) {
            val v = listView.getChildAt(i)
            v.translationY = 0f; v.alpha = 1f; v.clipBounds = null
        }
    }

    private fun onNextPreDraw(block: () -> Unit) {
        listView.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                listView.viewTreeObserver.removeOnPreDrawListener(this)
                block()
                return true
            }
        })
    }

    /**
     * 날짜 줄 아래의 모든 줄(그 날의 기록 + 그 아래 줄)을 한 덩어리로 같이 민다.
     * 그 날의 기록은 날짜 줄 아랫선 밑으로 나온 부분만 보이게 잘라(clip) 날짜 줄 속에서 나오고 들어가는 것처럼 보인다.
     * 모든 줄이 같은 값(offset) 하나로 움직이므로 어긋나거나 겹치지 않는다.
     */
    private fun applySlide(day: Long, headerPos: Int, offset: Float, fade: Float) {
        val edge = viewAt(headerPos)?.bottom ?: return
        val first = listView.firstVisiblePosition
        for (i in 0 until listView.childCount) {
            val pos = first + i
            if (pos <= headerPos) continue
            val v = listView.getChildAt(i)
            v.translationY = offset
            val r = rows.getOrNull(pos)
            if (r is Row.Entry && r.day == day) {
                val clipTop = (edge - (v.top + offset)).toInt().coerceIn(0, v.height)
                v.clipBounds = android.graphics.Rect(0, clipTop, v.width, v.height)
                v.alpha = fade
            }
        }
    }

    private fun runToggle(
        ms: Long, ip: android.animation.TimeInterpolator,
        onFrame: (Float) -> Unit, onDone: () -> Unit
    ) {
        val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
        a.duration = ms
        a.interpolator = ip
        a.addUpdateListener { if (!isFinishing && !isDestroyed) onFrame(it.animatedFraction) }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (toggleAnim === a) toggleAnim = null
                if (!isFinishing && !isDestroyed) onDone()
            }
        })
        toggleAnim = a
        a.start()
    }

    /** 접힌 뒤 목록이 새로 그려질 때 자리가 달라진 줄은 살짝 미끄러지고, 새로 보이는 줄은 살며시 나타난다 */
    private fun settle(before: Map<String, Int>) {
        onNextPreDraw {
            val first = listView.firstVisiblePosition
            for (i in 0 until listView.childCount) {
                val r = rows.getOrNull(first + i) ?: continue
                val v = listView.getChildAt(i)
                val old = before[rowKey(r)]
                if (old != null) {
                    val dy = (old - v.top).toFloat()
                    if (dy != 0f) {
                        v.translationY = dy
                        v.animate().translationY(0f).setDuration(220).setInterpolator(openInterp).start()
                    }
                } else {
                    v.alpha = 0f
                    v.animate().alpha(1f).setDuration(220).start()
                }
            }
        }
    }

    /**
     * 날짜 줄을 눌렀을 때: 화살표·기록·아래 줄이 하나의 진행값으로 함께 움직인다.
     * 펼침: 기록이 날짜 줄 밑에서 내려오고 아래 줄이 같이 밀려 내려간다 (넘치면 스크롤도 같은 흐름으로).
     * 접힘: 기록이 날짜 줄 속으로 올라가 들어가고 아래 줄이 같이 올라온다.
     */
    private fun toggleDay(h: Row.Header, @Suppress("UNUSED_PARAMETER") chevron: ImageView) {
        toggleAnim?.end()
        val day = h.day
        val opening = day !in openDays
        firstShow = false
        val headerPos = rows.indexOfFirst { it is Row.Header && it.day == day }
        val headerView = viewAt(headerPos)
        val chev = headerView?.findViewById<ImageView>(R.id.dateChevron)
        val rotTo = if (opening) 180f else 0f
        chev?.animate()?.cancel()
        chev?.tag = opening
        val rotFrom = chev?.rotation ?: rotTo

        if (!Motion.enabled(this) || headerView == null) {
            chev?.rotation = rotTo
            if (opening) openDays.add(day) else openDays.remove(day)
            refreshView()
            return
        }
        val limit = listView.height - listView.paddingBottom
        val cap = (limit - headerView.bottom).coerceAtLeast(0).toFloat()

        if (!opening) {
            var sum = 0
            val first = listView.firstVisiblePosition
            for (i in 0 until listView.childCount) {
                val r = rows.getOrNull(first + i)
                if (r is Row.Entry && r.day == day) sum += listView.getChildAt(i).height
            }
            val shift = minOf(sum.toFloat(), cap)
            if (shift <= 0f) {
                chev?.rotation = rotTo
                openDays.remove(day); refreshView()
                return
            }
            runToggle(300L, closeInterp, { p ->
                chev?.rotation = rotFrom + (rotTo - rotFrom) * p
                applySlide(day, headerPos, -shift * p, clamp01((1f - p) / 0.6f))
            }) {
                chev?.rotation = rotTo
                val before = snapshotTops()
                clearAnimState()
                openDays.remove(day)
                refreshView()
                settle(before)
            }
            return
        }

        val before = snapshotTops()
        openDays.add(day)
        refreshView()
        onNextPreDraw {
            val hp = rows.indexOfFirst { it is Row.Header && it.day == day }
            val hv = viewAt(hp)
            if (hv == null) { chev?.rotation = rotTo; return@onNextPreDraw }
            val first = listView.firstVisiblePosition
            var shift = -1f
            var count = 0
            var sample: View? = null
            for (i in 0 until listView.childCount) {
                val r = rows.getOrNull(first + i) ?: continue
                if (r is Row.Entry && r.day == day) { if (sample == null) sample = listView.getChildAt(i); continue }
                if (first + i > hp && shift < 0f) {
                    val old = before[rowKey(r)]
                    if (old != null) shift = (listView.getChildAt(i).top - old).toFloat()
                }
            }
            rows.forEach { if (it is Row.Entry && it.day == day) count++ }
            val capNow = (limit - hv.bottom).coerceAtLeast(0).toFloat()
            shift = if (shift < 0f) capNow else minOf(shift, capNow)
            if (shift <= 0f) { chev?.rotation = rotTo; return@onNextPreDraw }
            // 펼친 기록이 화면 아래로 넘치면, 날짜 줄이 가려지지 않는 선까지 같은 흐름으로 스크롤한다
            var scrollTotal = 0
            if (sample != null) {
                val need = hv.bottom + count * sample.height - limit
                val room = hv.top - listView.paddingTop
                val dy = minOf(need, room)
                if (dy > dp(8)) scrollTotal = dy
            }
            var scrolled = 0
            applySlide(day, hp, -shift, 0f)
            runToggle(360L, openInterp, { p ->
                chev?.rotation = rotFrom + (rotTo - rotFrom) * p
                if (scrollTotal > 0) {
                    val target = (scrollTotal * p).toInt()
                    if (target != scrolled) { listView.scrollListBy(target - scrolled); scrolled = target }
                }
                applySlide(day, hp, -shift * (1f - p), clamp01(p / 0.5f))
            }) {
                chev?.rotation = rotTo
                clearAnimState()
            }
        }
    }

    private fun openUrl(url: String, newTab: Boolean) {
        setResult(
            RESULT_OK,
            Intent().putExtra(BookmarksActivity.EXTRA_URL, url)
                .putExtra(BookmarksActivity.EXTRA_NEW_TAB, newTab)
        )
        ListUi.closeSheet(this)
    }

    private fun showMenu(h: HistoryItem) {
        Popup.menu(
            this,
            title = ListUi.displayTitle(h.title, h.url),
            subtitle = h.url,
            headerIcon = R.drawable.ic_globe,
            items = listOf(
                Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { openUrl(h.url, newTab = true) },
                Popup.Item(R.drawable.ic_copy, "주소 복사") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("url", h.url))
                    ListUi.toast(this, "복사했습니다")
                },
                Popup.Item(R.drawable.ic_delete, "기록에서 삭제", danger = true) {
                    prefs.removeHistory(h.url)
                    refreshView()
                }
            )
        )
    }

    /** 묻지 않고 바로 지우고, 알림의 '실행 취소' 로 되돌릴 수 있게 한다 */
    private fun deleteMany(urls: Set<String>) {
        val n = urls.size
        val before = prefs.historyItems()
        if (n >= before.size) prefs.clearHistory() else prefs.removeHistories(urls)
        select.finishDelete()
        refreshView()
        ListUi.undoToast(this, "방문 기록 ${n}개를 삭제했습니다") {
            prefs.setHistoryItems(before)
            refreshView()
        }
    }

}
