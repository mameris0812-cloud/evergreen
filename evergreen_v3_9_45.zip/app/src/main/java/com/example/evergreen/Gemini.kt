package com.example.evergreen

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class GeminiModel(val id: String, val label: String)

object GeminiModels {
    val LITE = GeminiModel("gemini-3.5-flash-lite", "3.5 Flash-Lite")
    val FLASH = GeminiModel("gemini-3.5-flash", "3.5 Flash")
    val PRO = GeminiModel("gemini-3.8-flash", "3.8 Flash")

    val all = listOf(LITE, FLASH, PRO)

    fun byId(id: String): GeminiModel = all.firstOrNull { it.id == id } ?: FLASH
}

/**
 * API 키를 여러 개 넣어 두면 돌아가며 쓰고, 한도(429)가 찼거나 거부된 키는 잠시 쉬게 한 뒤 다른 키로 다시 보낸다.
 */
object GeminiKeyPool {
    private val cool = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val counter = java.util.concurrent.atomic.AtomicInteger()

    @Volatile
    private var known: List<String> = emptyList()

    private fun now() = System.currentTimeMillis()

    /** 이번에 쓸 키. 쉬는 중이 아닌 키를 번갈아 고른다 (모두 쉬는 중이면 가장 빨리 풀리는 키) */
    fun pick(keys: List<String>): String {
        known = keys
        if (keys.isEmpty()) return ""
        val t = now()
        val ok = keys.filter { (cool[it] ?: 0L) <= t }
        if (ok.isNotEmpty()) return ok[Math.floorMod(counter.getAndIncrement(), ok.size)]
        return keys.minByOrNull { cool[it] ?: 0L } ?: keys[0]
    }

    fun cooldown(key: String, ms: Long) { cool[key] = now() + ms }

    /** 한도가 차서 잠시 쉬는 중인 키인지 (설정 화면 표시용) */
    fun resting(key: String): Boolean = (cool[key] ?: 0L) > now()

    /** [exclude] 에 없고 지금 쉬는 중도 아닌 다른 키. 없으면 null */
    fun alternative(exclude: Set<String>): String? {
        val t = now()
        return known.firstOrNull { it !in exclude && (cool[it] ?: 0L) <= t }
    }
}

/**
 * 모델은 사용자가 고르지 않고 일에 맞춰 자동으로 정한다.
 * 가벼운 일은 빠른 Flash-Lite, 페이지를 읽거나 사진을 볼 땐 더 똑똑한 모델.
 * 모델이 없거나(404) 한도(429)·서버 오류(5xx)가 나면 [fallbacks] 순서대로 다른 모델로 다시 보낸다.
 */
object GeminiAuto {
    /** 페이지 글 번역: 짧은 글 묶음이라 가장 빠른 모델로 충분 */
    val TRANSLATE = GeminiModels.LITE.id
    /** 사진 속 글자 읽기·번역, 실시간 자막(소리): 사진/소리를 잘 알아듣는 모델 */
    val VISION = GeminiModels.FLASH.id
    /** 확장 프로그램의 요약 */
    val SUMMARY = GeminiModels.LITE.id

    private val dead: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    fun markDead(model: String) { dead.add(model) }

    /** 채팅 질문 하나에 쓸 모델 */
    fun forChat(question: String, turns: Int, hasPageText: Boolean, imageCount: Int): String {
        val q = question.trim()
        val heavyWords = listOf("분석", "비교", "자세히", "논리", "증명", "코드", "계산", "왜 ", "원인", "추론", "표로", "단계별")
        val complex = q.length > 400 || heavyWords.any { q.contains(it) }
        val id = when {
            imageCount > 0 || complex -> GeminiModels.PRO.id
            hasPageText || turns > 6 -> GeminiModels.FLASH.id
            else -> GeminiModels.LITE.id
        }
        return live(id)
    }

    /** [model] 이 실패했을 때 차례로 써 볼 다른 모델들 (없어진 모델은 뺀다) */
    fun fallbacks(model: String): List<String> {
        val order = when (model) {
            GeminiModels.LITE.id -> listOf(GeminiModels.FLASH.id, GeminiModels.PRO.id)
            GeminiModels.PRO.id -> listOf(GeminiModels.FLASH.id, GeminiModels.LITE.id)
            else -> listOf(GeminiModels.PRO.id, GeminiModels.LITE.id)
        }
        return order.filter { it !in dead }
    }

    /** 없어진 걸로 알려진 모델이면 다른 모델로 바꾼다 */
    fun live(model: String): String =
        if (model !in dead) model else fallbacks(model).firstOrNull() ?: model

    /** 지금 쓰는 모델 이름 (AI 창 위쪽 표시용) */
    fun label(model: String): String = GeminiModels.byId(model).label
}

/**
 * Gemini 3.x 는 따로 정하지 않으면 매번 길게 "생각"한 뒤에야 첫 글자를 보내서 느리다.
 * 요청에 thinkingLevel 을 넣어 생각 시간을 줄인다. 모델이 이 설정을 거부하면(400) 그 모델은 설정 없이 다시 보낸다.
 */
object GeminiThinking {
    const val MINIMAL = "minimal"
    const val LOW = "low"

    private val unsupported: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /**
     * [gen] (generationConfig) 에 생각 설정을 넣는다. 넣었으면 true.
     * [includeThoughts] 이면 모델이 "생각한 내용의 요약"도 함께 보내 달라고 한다 (AI 사고 과정 표시용).
     */
    fun apply(gen: JSONObject, model: String, level: String, includeThoughts: Boolean = false): Boolean {
        if (level.isEmpty() || model in unsupported) return false
        val cfg = JSONObject().put("thinkingLevel", level)
        if (includeThoughts) cfg.put("includeThoughts", true)
        gen.put("thinkingConfig", cfg)
        return true
    }

    /** 400 오류가 생각 설정 때문이면 그 모델을 기억해 두고 true (같은 요청을 설정 없이 다시 보내면 된다) */
    fun rejected(code: Int, body: String?, model: String, applied: Boolean): Boolean {
        if (!applied || code != 400 || body == null || !body.contains("thinking", ignoreCase = true)) return false
        unsupported.add(model)
        return true
    }
}

/**
 * Google 검색 연결(grounding). 켜 두면 모델이 필요하다고 판단할 때만 웹을 검색해서 답하고,
 * 어떤 말로 검색했고 어느 사이트를 참고했는지 응답에 함께 실려 온다 (앱은 이걸 출처 칩으로 보여 준다).
 * 모델이 이 도구를 거부하면(400) 그 모델은 검색 없이 다시 보낸다.
 */
object GeminiSearch {
    private val unsupported: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** [body] (요청 본문) 에 검색 도구를 넣는다. 넣었으면 true */
    fun apply(body: JSONObject, model: String, on: Boolean): Boolean {
        if (!on || model in unsupported) return false
        body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return true
    }

    /** 400 오류가 검색 도구 때문이면 그 모델을 기억해 두고 true (같은 요청을 검색 없이 다시 보내면 된다) */
    fun rejected(code: Int, body: String?, model: String, applied: Boolean): Boolean {
        if (!applied || code != 400 || body == null) return false
        val b = body.lowercase()
        if (!b.contains("google_search") && !b.contains("googlesearch") && !b.contains("tool")) return false
        unsupported.add(model)
        return true
    }
}

/** AI 에게 같이 보낼 사진 한 장. [base64] 는 JPEG 를 Base64 로 인코딩한 것, [label] 은 사진 설명(alt 등) */
class PageImage(val mime: String, val base64: String, val label: String)

/** AI 가 웹 검색으로 참고한 출처 한 곳. [title] 은 보통 사이트 이름(도메인), [url] 은 누르면 열 주소 */
data class SearchSource(val title: String, val url: String) {
    /** 아이콘을 구하는 데 쓸 사이트 주소 (검색 결과 주소는 중간 전달 주소라서 제목의 도메인을 쓴다) */
    val iconUrl: String?
        get() {
            val t = title.trim().lowercase()
            return if (t.contains('.') && !t.contains(' ') && !t.contains('/')) "https://$t" else null
        }
}

data class ChatMsg(val role: String, var text: String, val images: List<PageImage> = emptyList()) {
    /** AI 가 답하기 전에 정리한 생각의 요약 (모델이 보내 준 경우만) */
    var thought: String = ""

    /** 질문을 받고 첫 답이 나오기까지 걸린 시간(ms). 0 이면 모름 */
    var thinkMs: Long = 0L

    /** AI 가 웹에서 검색한 말들 */
    var searchQueries: List<String> = emptyList()

    /** AI 가 웹 검색으로 참고한 출처들 (검색을 했을 때만) */
    var sources: List<SearchSource> = emptyList()
}

/**
 * 지금 보고 있는 웹페이지의 내용 (AI 에게 참고 자료로 보낸다).
 * [images] 는 AI 에게 실제로 첨부한 사진, [imageTotal] 은 페이지에서 찾은 (의미 있는 크기의) 사진 수.
 */
data class PageSnapshot(
    val url: String,
    val title: String,
    val text: String,
    val selection: String,
    val images: List<PageImage> = emptyList(),
    val imageTotal: Int = 0
)

/** API 키를 기기 보안 저장소(Android Keystore)의 키로 암호화해서 저장한다. */
object KeyVault {
    private const val ALIAS = "evergreen_ai_key"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, secretKey())
            val iv = c.iv
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            "e:" + Base64.encodeToString(iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) {
            // 보안 저장소를 쓸 수 없는 기기: 앱 전용 저장소에 그대로 저장
            "p:$plain"
        }
    }

    fun decrypt(stored: String): String? {
        if (stored.startsWith("p:")) return stored.substring(2)
        if (!stored.startsWith("e:")) return null
        return try {
            val all = Base64.decode(stored.substring(2), Base64.NO_WRAP)
            val iv = all.copyOfRange(0, 12)
            val ct = all.copyOfRange(12, all.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}

/** Gemini API (generativelanguage.googleapis.com) 스트리밍 호출. 반드시 백그라운드 스레드에서 부른다. */
class GeminiClient {
    private companion object {
        const val MAX_OUTPUT_TOKENS = 65536
        const val MAX_CONTINUE = 4
    }

    @Volatile
    private var conn: HttpURLConnection? = null

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
        try {
            conn?.disconnect()
        } catch (e: Exception) {
            // 이미 끝난 연결
        }
    }

    fun stream(
        apiKey: String,
        model: String,
        system: String,
        history: List<ChatMsg>,
        onDelta: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
        json: Boolean = false,
        thinking: String = GeminiThinking.MINIMAL,
        search: Boolean = false,
        includeThoughts: Boolean = false,
        onThought: (String) -> Unit = {},
        onGrounding: (List<String>, List<SearchSource>) -> Unit = { _, _ -> }
    ) {
        cancelled = false
        var curModel = GeminiAuto.live(model)
        var curKey = apiKey
        val tried = mutableSetOf(curModel)
        val triedKeys = mutableSetOf<String>()
        // 답이 토큰 한도로 잘리거나 연결이 중간에 끊기면, 받은 부분을 붙여서 "이어서 써 줘" 로 자동 재요청한다.
        val msgs = history.toMutableList()
        var total = 0
        var round = 0
        while (true) {
            val roundText = StringBuilder()
            val r = once(curKey, curModel, system, msgs, json, thinking, search, includeThoughts, onThought, onGrounding) { d ->
                roundText.append(d)
                total += d.length
                onDelta(d)
            }
            if (cancelled) { onDone(); return }
            when {
                r.error != null && r.fatal -> {
                    // 글자를 하나도 못 받았고 모델 쪽 문제(없음·한도·서버 오류)면 다른 모델로 바로 다시 보낸다
                    // 키 한도(429)가 찼거나 키가 거부됐으면 다른 키로 같은 요청을 다시 보낸다
                    if (total == 0 && (r.code == 429 || r.badKey)) {
                        GeminiKeyPool.cooldown(curKey, if (r.badKey) 600_000L else 60_000L)
                        triedKeys.add(curKey)
                        val altKey = GeminiKeyPool.alternative(triedKeys)
                        if (altKey != null) {
                            curKey = altKey
                            continue
                        }
                    }
                    if (r.code == 404) GeminiAuto.markDead(curModel)
                    val retryable = total == 0 && (r.code == 404 || r.code == 429 || r.code in 500..599)
                    val next = if (retryable) GeminiAuto.fallbacks(curModel).firstOrNull { it !in tried } else null
                    if (next != null) {
                        tried.add(next)
                        curModel = next
                        triedKeys.clear()
                        continue
                    }
                    onError(r.error)
                    return
                }
                // 정상 종료
                r.error == null && r.finish != "MAX_TOKENS" -> {
                    if (total == 0) {
                        onError(
                            when {
                                r.blocked.isNotEmpty() -> "요청이 안전 정책에 의해 차단되었어요 (${r.blocked})"
                                r.finish.isNotEmpty() -> "응답이 비어 있어요 (${r.finish})"
                                else -> "응답이 비어 있어요"
                            }
                        )
                    } else onDone()
                    return
                }
            }
            // 여기까지 오면: 토큰 한도로 잘렸거나(MAX_TOKENS) 중간에 연결이 끊긴 경우
            round++
            if (roundText.isEmpty() || round > MAX_CONTINUE) {
                if (total > 0 && r.error == null) onDone()
                else onError(r.error ?: "응답이 중간에 끊겼어요")
                return
            }
            msgs.add(ChatMsg("model", roundText.toString()))
            msgs.add(ChatMsg("user", "끊긴 바로 그 지점부터 이어서 계속 써 줘. 앞에 쓴 내용은 반복하지 말고, 인사말이나 설명 없이 본문만 이어 써."))
        }
    }

    private class Round(
        val finish: String,
        val blocked: String,
        val error: String?,
        val fatal: Boolean,
        val code: Int = 0,
        val badKey: Boolean = false
    )

    /** 요청 한 번. 받은 글자는 [onText] 로 흘려 보낸다. */
    private fun once(
        apiKey: String,
        model: String,
        system: String,
        history: List<ChatMsg>,
        json: Boolean,
        thinking: String,
        search: Boolean,
        includeThoughts: Boolean,
        onThought: (String) -> Unit,
        onGrounding: (List<String>, List<SearchSource>) -> Unit,
        onText: (String) -> Unit
    ): Round {
        var c: HttpURLConnection? = null
        var got = false
        var blocked = ""
        var finish = ""
        // 검색한 말과 참고한 출처 (응답 조각마다 실려 올 수 있어서 모아 둔다)
        val queries = LinkedHashSet<String>()
        val sources = LinkedHashMap<String, SearchSource>()
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            c = url.openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 300000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)

            val contents = JSONArray()
            for (m in history) {
                val parts = JSONArray()
                // 사진은 글보다 앞에 둔다 (Gemini 권장 순서)
                for (img in m.images) {
                    parts.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject().put("mimeType", img.mime).put("data", img.base64)
                        )
                    )
                }
                parts.put(JSONObject().put("text", m.text))
                contents.put(JSONObject().put("role", m.role).put("parts", parts))
            }
            val body = JSONObject().put("contents", contents)
            val gen = JSONObject().put("maxOutputTokens", MAX_OUTPUT_TOKENS)
            if (json) gen.put("responseMimeType", "application/json")
            val thinkApplied = GeminiThinking.apply(gen, model, thinking, includeThoughts)
            // JSON 으로만 답하게 하는 요청에는 검색 도구를 같이 쓸 수 없다
            val searchApplied = GeminiSearch.apply(body, model, search && !json)
            body.put("generationConfig", gen)
            if (system.isNotBlank()) {
                body.put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
            }
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = try {
                    c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
                // 이 모델이 생각 설정을 모르면 설정 없이 한 번 더 보낸다
                if (GeminiThinking.rejected(code, err, model, thinkApplied)) {
                    return once(apiKey, model, system, history, json, thinking, search, includeThoughts, onThought, onGrounding, onText)
                }
                // 이 모델이 검색 도구를 모르면 검색 없이 한 번 더 보낸다
                if (GeminiSearch.rejected(code, err, model, searchApplied)) {
                    return once(apiKey, model, system, history, json, thinking, search, includeThoughts, onThought, onGrounding, onText)
                }
                val bad = code == 401 || code == 403 || (code == 400 && (err ?: "").contains("API key", ignoreCase = true))
                return Round("", "", describeError(code, err), true, code, bad)
            }

            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.substring(5).trim()
                    if (data.isEmpty() || data == "[DONE]") continue
                    val o = JSONObject(data)
                    val br = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                    if (br.isNotEmpty()) blocked = br
                    val cand = o.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                    val fr = cand.optString("finishReason")
                    if (fr.isNotEmpty()) finish = fr
                    // 웹 검색을 했다면: 검색한 말과 참고한 사이트 목록이 실려 온다
                    val gm = cand.optJSONObject("groundingMetadata")
                    if (gm != null) {
                        val before = queries.size + sources.size
                        gm.optJSONArray("webSearchQueries")?.let { qa ->
                            for (i in 0 until qa.length()) {
                                val q = qa.optString(i, "").trim()
                                if (q.isNotEmpty()) queries.add(q)
                            }
                        }
                        gm.optJSONArray("groundingChunks")?.let { ca ->
                            for (i in 0 until ca.length()) {
                                val web = ca.optJSONObject(i)?.optJSONObject("web") ?: continue
                                val u = web.optString("uri", "")
                                if (u.isEmpty() || sources.containsKey(u)) continue
                                val title = web.optString("title", "").ifBlank { u }
                                sources[u] = SearchSource(title, u)
                            }
                        }
                        if (queries.size + sources.size != before) {
                            onGrounding(queries.toList(), sources.values.toList())
                        }
                    }
                    val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until parts.length()) {
                        val p = parts.optJSONObject(i) ?: continue
                        if (p.optBoolean("thought", false)) {
                            // 모델이 정리한 생각의 요약: 답이 아니라 사고 과정 표시용으로만 넘긴다
                            val th = p.optString("text", "")
                            if (th.isNotEmpty()) onThought(th)
                            continue
                        }
                        val t = p.optString("text", "")
                        if (t.isNotEmpty()) {
                            got = true
                            onText(t)
                        }
                    }
                }
            }
            // finishReason 없이 스트림이 끝났다면 중간에 끊긴 것으로 본다
            if (got && finish.isEmpty() && !cancelled) {
                return Round("", blocked, "응답이 중간에 끊겼어요", false)
            }
            return Round(finish, blocked, null, false)
        } catch (e: Exception) {
            val msg = "네트워크 오류: ${e.message ?: e.javaClass.simpleName}"
            // 글자를 하나라도 받은 뒤의 오류는 이어받기를 시도하고, 처음부터 실패한 건 바로 오류로 알린다
            return Round(finish, blocked, msg, !got)
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
                // 무시
            }
            conn = null
        }
    }

    private fun describeError(code: Int, body: String?): String {
        val msg = try {
            JSONObject(body ?: "").optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        val head = when (code) {
            400 -> "요청이 올바르지 않거나 API 키가 잘못되었어요"
            401, 403 -> "API 키가 거부되었어요. 키와 사용 권한을 확인해 주세요"
            404 -> "모델을 찾을 수 없어요"
            429 -> "요청 한도를 넘었어요. 잠시 후 다시 시도해 주세요"
            in 500..599 -> "Gemini 서버에 문제가 있어요. 잠시 후 다시 시도해 주세요"
            else -> "오류가 났어요 ($code)"
        }
        return if (msg.isNullOrBlank()) head else "$head\n$msg"
    }
}
