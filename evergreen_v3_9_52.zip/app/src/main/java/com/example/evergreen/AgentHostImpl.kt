package com.example.evergreen

import android.os.Handler
import android.os.Looper
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * [AgentHost] 의 구현: AI 도구와 2만 줄짜리 MainActivity 사이의 얇은 연결 층.
 * MainActivity 안쪽을 직접 만지지 않고, MainActivity 가 열어 둔 `agentXxx()` 함수만 부른다.
 * 도구는 백그라운드 스레드에서 도니, 화면·탭을 만지는 일은 여기서 메인 스레드로 넘기고 결과를 기다린다.
 */
class MainAgentHost(private val activity: MainActivity) : AgentHost {
    private val handler = Handler(Looper.getMainLooper())

    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val task = FutureTask<T>(Callable<T> { block() })
        handler.post(task)
        try {
            return task.get(8, TimeUnit.SECONDS)
        } catch (e: TimeoutException) {
            task.cancel(false)
            throw IllegalStateException("앱이 응답하지 않아요")
        } catch (e: ExecutionException) {
            throw (e.cause ?: e)
        }
    }

    private fun alive(): Boolean = !activity.isFinishing && !activity.isDestroyed

    override fun tabs(): List<AgentTab> = onMain { if (alive()) activity.agentTabs() else emptyList() }
}
