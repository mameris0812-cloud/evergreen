package com.example.evergreen

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.RectF
import android.view.ViewOutlineProvider
import android.widget.ScrollView
import android.widget.SeekBar
import androidx.core.view.doOnLayout
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Rational
import android.util.TypedValue
import android.text.Editable
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringForce
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Filter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

/** 한 프레임에서 재생 중인 미디어 정보 (영상이면 가로·세로 크기) */
class MediaFrame(val video: Boolean, val w: Int, val h: Int)

/** 메뉴의 미디어 플레이어에 보여 줄 재생 진행 상황 (pos·dur 는 초, dur<=0 이면 길이를 모름/라이브) */
class MediaProg(val pos: Double, val dur: Double, val playing: Boolean, val at: Long)

/** 페이지(mediaSession)가 알려 준 지금 곡·영상의 제목과 아티스트 */
class MediaMeta(val title: String, val artist: String, val art: String = "")

/** 메뉴의 미디어 플레이어 파형용 소리 크기 (bands: 0..1 막대 값들, unavailable: 이 페이지는 소리를 읽을 수 없음) */
class MediaWave(val bands: FloatArray?, val unavailable: Boolean, val at: Long)

/**
 * 탭을 다른 창으로 옮길 때 같이 들고 가는 상태.
 * 웹 기록(앞/뒤로 가기), 페이지 확대 비율, 스크롤 위치, 데스크톱 보기, 음소거, 재생 속도를 그대로 이어 준다.
 */
class TabHandoff(
    val url: String?,
    val title: String?,
    val desktop: Boolean,
    val incognito: Boolean,
    val pageZoom: Int?,
    val muted: Boolean,
    val rate: Float,
    val state: Bundle?,
    val scrollRatio: Float,
    val scrollX: Int,
    val scrollY: Int
)

class BrowserTab(initial: WebView? = null) {
    private var wv: WebView? = initial

    /** 복원된 탭은 실제로 열 때까지 WebView 만들기를 미룬다 (앱 시작이 빨라진다). 처음 webView 에 접근할 때 한 번 실행된다 */
    var lazyInit: (() -> Unit)? = null

    var webView: WebView
        get() {
            if (wv == null) {
                val init = lazyInit
                lazyInit = null
                init?.invoke()
            }
            return wv ?: error("WebView 가 아직 만들어지지 않았습니다")
        }
        set(v) { wv = v }

    /** 이미 만들어진 WebView (없으면 null). 모든 탭을 훑는 작업에서 WebView 를 억지로 만들지 않기 위해 쓴다 */
    val liveWebView: WebView? get() = wv

    /** 시크릿 탭: 방문 기록·탭 복원에 남지 않고, 쿠키·저장소는 별도 프로필에 담겼다가 탭을 다 닫으면 지워진다 */
    var incognito: Boolean = false

    /** HTTPS 우선: 이 탭이 https 로 올려서 연결을 시도 중인 원래 http 주소 */
    var upgradedFrom: String? = null

    /** 이번 페이지 로드에서 강제 다크(CSS) 스타일을 이미 넣었는지 */
    var darkInjected: Boolean = false

    /** 지금 재생 중인 미디어가 있는 프레임들 (키: 프레임 id). 비어 있으면 재생 중이 아님 */
    val mediaFrames = HashMap<String, MediaFrame>()

    /** 프레임별 재생 진행 상황 (메뉴의 미디어 플레이어용). 페이지를 떠나면 지워진다 */
    val mediaProg = HashMap<String, MediaProg>()

    /** 프레임별 제목·아티스트 (페이지가 mediaSession 으로 알려 준 것). 곡이 바뀌면 같이 바뀐다 */
    val mediaMeta = HashMap<String, MediaMeta>()

    /** 프레임별 실시간 소리 크기 (메뉴의 미디어 플레이어가 열려 있는 동안만 들어온다) */
    val mediaWave = HashMap<String, MediaWave>()

    /** 불러오지 못해 오류 화면을 보여 주는 중인 주소 (새로고침하면 이 주소를 다시 불러온다) */
    var errorUrl: String? = null

    /** 이 페이지에서 오간 영상/스트리밍 주소 (내장 플레이어용). 페이지가 바뀌면 비운다. */
    val sniffed: MutableSet<String> = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    /** 이 페이지에서 오간 자막 파일 주소 (.vtt/.srt/.ass/.ttml). 자바스크립트 플레이어가 따로 불러오는 자막까지 내장 플레이어에 넘기려고 모은다 */
    val sniffedSubs: MutableSet<String> = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    var progress: Int = 100
    var rate: Float = 1f

    /** 홈으로 나가면서 로딩을 중단시킨 탭: 페이지로 돌아오면 다시 불러온다 */
    var stoppedByHome: Boolean = false

    /** 마지막으로 안정돼 있던 스크롤 위치의 비율 (0~1, 모르면 -1). 창 크기·비율이 바뀌어 내용이 다시 배치돼도 같은 자리로 돌아오려고 쓴다 */
    var scrollRatio: Float = -1f

    /** 0 = 그룹 없음 */
    var groupId: Int = 0

    /** 이번 페이지 로드에서 광고 숨김 CSS를 이미 넣었는지 */
    var cosmeticInjected: Boolean = false

    /** 이 페이지가 자체 로딩 바(맨 위 가는 진행 막대)를 가지고 있다 → 브라우저 로딩 바는 숨긴다 */
    var ownProgressBar: Boolean = false
    var ownBarChecks: Int = 0

    /** 이 페이지(이번 주소 이동)에서 막은 광고 건수 — 백그라운드 스레드에서 올라간다 */
    val adBlocked = java.util.concurrent.atomic.AtomicInteger(0)

    var favicon: Bitmap? = null

    /** 탭 화면에 보여줄 페이지 미리보기 (탭을 떠날 때 / 탭 화면을 열 때 갱신) */
    var thumb: Bitmap? = null

    /** 이 탭을 연 탭 (뒤로가기로 탭을 닫으면 여기로 돌아간다) */
    var opener: BrowserTab? = null

    /** 데스크톱 사이트 요청 */
    var desktop: Boolean = false

    /** 이 페이지에 데스크톱 뷰포트를 이미 적용했는지 */
    var desktopInjected: Boolean = false

    /** 이 탭에만 적용한 페이지 확대/축소 (%). null 이면 전체 설정(prefs.pageZoom)을 따른다 */
    var pageZoom: Int? = null

    /** 이 페이지에 확대/축소를 이미 적용했는지 */
    var zoomInjected: Boolean = false

    /** 앱을 다시 켰을 때 복원된 탭: 선택하기 전까지는 불러오지 않고 주소/제목만 들고 있다 */
    var pendingUrl: String? = null
    var pendingTitle: String? = null

    /** 다른 창에서 넘어온 탭의 웹 기록(WebView.saveState). 처음 불러올 때 주소만 여는 대신 이 상태 그대로 되살린다 */
    var pendingState: Bundle? = null

    /** 넘어온 탭이 되살아난 뒤 맞출 스크롤 위치 (비율 우선, 모르면 -1 / 픽셀 위치) */
    var pendingScrollRatio: Float = -1f
    var pendingScrollX: Int = 0
    var pendingScrollY: Int = 0
    var restoreScrollPending: Boolean = false

    /** 새 탭 홈 화면을 보여주는 중인지 (홈 화면은 웹 기록에 들어 있는 항목이라 뒤로/앞으로 가기로 오갈 수 있다) */
    var isHome: Boolean = false

    /** 홈 항목이 다 불러와지면 웹 기록을 비운다 (마지막 탭을 닫아 새 탭으로 되돌릴 때) */
    var clearAtHome: Boolean = false

    /** 탭 음소거: true 면 이 탭의 모든 소리(video/audio/WebAudio)를 끈다 */
    @Volatile var muted: Boolean = false

    /** 홈에서 다른 페이지로 넘어가는 중: 새 페이지의 첫 화면이 그려질 때까지 웹뷰(이전 페이지 잔상)를 가리고 홈을 보여 준다 */
    var awaitCommit: Boolean = false

    /** WebView 를 onPause 시켜 둔 상태인지 (홈 화면이거나 다른 탭을 보는 중) */
    var paused: Boolean = false

    /** 페이지 스크립트(window.open)가 연 팝업 탭인지: 광고 팝업 판별에 쓴다 */
    var scriptPopup: Boolean = false

    /** JS 알림창 도배 방지용: 최근 몇 번 띄웠는지 / 마지막 시각 */
    var jsDialogCount: Int = 0
    var jsDialogAt: Long = 0L

    /** 렌더러가 마지막으로 죽은 시각 (같은 페이지가 계속 죽는지 보려고) */
    var crashAt: Long = 0L

    /** 마지막으로 뒤로가기를 한 시각 (uptimeMillis) */
    var backAt: Long = 0L

    /** 뒤로가기로 도착한 기록의 주소 / 떠나온 기록의 주소 / 그때까지 페이지를 만진 마지막 시각 (자동 이동 판단용) */
    var backTargetUrl: String? = null
    var backLeftUrl: String? = null
    var backTouchMark: Long = 0L

    /** 뒤로가기로 돌아오면 스스로 다른 곳으로 되돌려 보내는 페이지 주소 (뒤로가기 때 건너뛴다) */
    val redirectSources = HashSet<String>()
}

open class MainActivity : AppCompatActivity() {

    /** 첫 번째 창만 탭을 저장·복원한다 (여러 창이 같은 저장소를 덮어쓰지 않게) */
    private var isPrimary = false
    private var restoreSlot = false

    /** 창 번호 (창 1, 창 2 …). 열려 있는 동안 바뀌지 않는다 */
    private var windowNo = 0

    /** 사용자가 붙인 창 이름 (없으면 "창 1", "창 2" …). 창 번호별로 저장돼서 창을 닫았다 다시 열어도 남는다 */
    private var windowName: String?
        get() = prefs.windowName(windowNo)
        set(v) = prefs.setWindowName(windowNo, v)
    private val windowLabel: String get() = windowName ?: "창 $windowNo"

    /** 새 창을 따로 띄운다 (최근 앱에 별개 항목으로 생기고, 멀티윈도우에서는 옆에 붙는다) */
    internal fun openNewWindow(
        url: String? = null,
        restoreNo: Int = 0,
        handoff: TabHandoff? = null,
        mode: Int = WIN_DEFAULT,
        dropX: Int = 0,
        dropY: Int = 0,
        inheritNo: Int = 0
    ) {
        val handoffId = if (handoff != null) ++handoffSeq else 0L
        if (handoff != null) handoffs[handoffId] = handoff
        // 팝업은 '옆에 붙이기' 대신 떠 있는 창으로 열어야 해서 ADJACENT 를 빼고, 나머지는 예전처럼 옆에 붙인다
        var flags = Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
        if (mode != WIN_POPUP) flags = flags or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
        startActivity(
            Intent(this, BrowserWindowActivity::class.java).addFlags(flags).apply {
                // 주소는 넘긴 상태를 못 찾았을 때(예: 앱 프로세스가 다시 시작됐을 때)를 위한 예비
                if (url != null) data = Uri.parse(url)
                if (handoffId != 0L) putExtra(EXTRA_HANDOFF, handoffId)
                if (restoreNo > 0) {
                    putExtra(EXTRA_WINDOW_NO, restoreNo)
                    putExtra(EXTRA_RESTORE, true)
                } else if (inheritNo > 0) {
                    // 이 창이 곧 닫히고 탭이 새 창으로 넘어가는 경우: 새 창이 이 창의 번호를 이어받는다 (번호가 2부터 시작하지 않게)
                    putExtra(EXTRA_WINDOW_NO, inheritNo)
                }
            },
            windowLaunchOptions(mode, dropX, dropY)
        )
    }

    /**
     * 새 창이 놓일 자리를 시스템에 알린다 (시스템 화면 기준).
     * 팝업: 놓은 자리 중심의 떠 있는 창(자유 창 모드).
     * 자유 창을 지원하지 않는 기기에서는 시스템이 무시하고 평소처럼 새 창으로 열린다.
     */
    private fun windowLaunchOptions(mode: Int, x: Int, y: Int): Bundle? {
        if (mode == WIN_DEFAULT || Build.VERSION.SDK_INT < 24) return null
        return try {
            val s = screenBounds()
            val rect = when (mode) {
                else -> {
                    val w = (s.width() * 0.6f).toInt().coerceIn(minOf(dp(360), s.width()), s.width())
                    val h = (s.height() * 0.7f).toInt().coerceIn(minOf(dp(420), s.height()), s.height())
                    val l = (x - w / 2).coerceIn(s.left, s.right - w)
                    val t = (y - h / 2).coerceIn(s.top, s.bottom - h)
                    Rect(l, t, l + w, t + h)
                }
            }
            val o = android.app.ActivityOptions.makeBasic()
            o.setLaunchBounds(rect)
            val b = o.toBundle() ?: Bundle()
            // 팝업은 자유 창(freeform, 5) 으로 요청한다. 지원하지 않는 기기에서는 무시된다
            if (mode == WIN_POPUP) b.putInt("android.activity.windowingMode", 5)
            b
        } catch (e: Throwable) {
            null
        }
    }

    /** 시스템 화면 전체 크기 (앱 창이 일부만 차지해도 화면 기준) */
    private fun screenBounds(): Rect {
        if (Build.VERSION.SDK_INT >= 30) return windowManager.maximumWindowMetrics.bounds
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }


    private lateinit var prefs: Prefs
    private lateinit var adBlocker: AdBlocker

    private lateinit var urlBar: AutoCompleteTextView
    private lateinit var progressBar: ProgressBar
    private lateinit var webContainer: PullRefreshLayout
    private lateinit var pageScrollBar: WebPageScrollBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnTabs: View
    private lateinit var tabCount: TextView
    private lateinit var btnBottomTabs: View
    private lateinit var tabCountBottom: TextView
    private lateinit var stripTabCount: TextView
    private lateinit var btnMenu: ImageButton
    private lateinit var fullscreenContainer: FullscreenSwipeLayout
    private lateinit var homeTagline: TextView
    private var homeTaglineDefault: CharSequence = ""
    private lateinit var findBar: View
    private lateinit var etFind: EditText
    private lateinit var findCount: TextView
    private lateinit var browserUi: View
    private lateinit var bottomBar: View
    private lateinit var tabStripBar: View
    private lateinit var tabStripScroll: HorizontalScrollView
    private lateinit var tabStrip: LinearLayout
    private lateinit var navGroup: View
    private lateinit var tbBack: ImageButton
    private lateinit var tbForward: ImageButton
    private lateinit var tbHome: ImageButton
    private lateinit var tbMenu: ImageButton
    private lateinit var tbDesktop: ImageButton
    private lateinit var tbAi: ImageButton
    private lateinit var tabletActions: View
    private lateinit var homeView: View
    private lateinit var homeContent: View
    private lateinit var tabSwitcher: View
    private lateinit var tabList: LinearLayout
    private lateinit var tabScroll: ScrollView
    private lateinit var tabsTitle: TextView
    private lateinit var tabMorph: ImageView
    private var switcherOpen = false
    private var switcherBusy = false
    private val switcherRows = HashMap<BrowserTab, View>()
    private val switcherBoxes = HashMap<Int, View>()
    private var morphRadius = 0f
    private var assistant: AssistantUi? = null

    /** 태블릿(넓은 화면) 레이아웃 사용 중인지 */
    private var expanded = false
    private var stripRefreshQueued = false
    private var windowStripQueued = false
    private var lastStripCurrent: BrowserTab? = null
    private var baseUserAgent: String = ""
    @Volatile private var lastTouchAt = 0L
    private fun recentTouch(windowMs: Long = 5000L) = android.os.SystemClock.uptimeMillis() - lastTouchAt < windowMs

    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null

    private val groups = mutableListOf<TabGroup>()
    private var nextGroupId = 1

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    @Volatile
    private var adBlockEnabled = true
    private val trackerBlocker = TrackerBlocker()
    private var strictTrackers = false
    private var skipCaptchaTracking = false
    private var malwareWarning = true
    private var blockAutoDownload = true
    // 스크롤 시 메뉴바 숨김 기능은 설정에서 제거됨 (항상 꺼짐)
    private val hideBarsOnScroll = false
    private val hideStatusBarOnScroll = false
    private var statusBarHiddenByScroll = false
    private var barsFraction = 0f      // 0 = 보임, 1 = 숨김
    private var barsTarget = 0f
    private var barsAnim: android.animation.ValueAnimator? = null
    private var barsLayoutHidden = false     // true: 레이아웃이 '바 숨김' 형태(웹 영역이 화면 전체 크기)
    private var barsStartRunnable: Runnable? = null
    private var barsGestureActive = false     // 손가락으로 스크롤 중 (바가 손가락을 따라 움직이는 중)
    private var barsGestureDy = 0
    private var barsLastDir = 0
    private var barsConsumeAfter = 0L
    private var barsIgnoreScrollUntil = 0L  // 바 애니메이션 중 웹뷰 크기 변화로 생기는 가짜 스크롤 무시
    private var scrollAcc = 0
    private val toolbarView by lazy { findViewById<View>(R.id.toolbar) }

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val suggestItems = mutableListOf<String>()
    private lateinit var suggestAdapter: SuggestAdapter
    private var suggestRunnable: Runnable? = null
    private var suppressWatcher = false
    private var askedNotificationPermission = false

    /** 웹페이지의 <input type="file"> 업로드: 파일 선택 화면을 띄우고 결과를 WebView 에 돌려준다. */
    private var fileChooserCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileChooserCallback
            fileChooserCallback = null
            val uris = if (result.resultCode == RESULT_OK) {
                // 파일 관리자마다 결과를 담는 방식이 달라, 표준 해석이 비면 직접 꺼내 본다
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
                    ?.takeIf { it.isNotEmpty() }
                    ?: result.data?.let { d ->
                        val cd = d.clipData
                        when {
                            cd != null && cd.itemCount > 0 ->
                                Array(cd.itemCount) { i -> cd.getItemAt(i).uri }
                            d.data != null -> arrayOf(d.data!!)
                            else -> null
                        }
                    }
            } else null
            cb?.onReceiveValue(uris)
        }

    /** 북마크 화면에서 고른 주소를 받아 현재 탭(또는 새 탭)에서 연다. */
    private val bookmarksLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            val url = data?.getStringExtra(BookmarksActivity.EXTRA_URL)
            if (data == null || url == null) {
                // 주소를 고르지 않고 뒤로 나왔다 → 이 화면을 열었던 메뉴로 돌아간다
                reopenMenuAfterList()
                return@registerForActivityResult
            }
            if (data.getBooleanExtra(BookmarksActivity.EXTRA_NEW_TAB, false)) {
                createTab(url, opener = current)
            } else {
                loadFromInput(url)
            }
        }

    // ───────────────────────── 생명주기 ─────────────────────────

    // ───────────────────────── 크래시 기록 ─────────────────────────
    // 앱이 꺼지면 원인(스택 트레이스)을 파일에 남기고, 다시 켰을 때 화면에 보여 준다.

    private val crashFile get() = java.io.File(filesDir, "last_crash.txt")

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        val file = crashFile
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = java.io.StringWriter()
                throwable.printStackTrace(java.io.PrintWriter(sw))
                file.writeText(
                    "시각: ${java.util.Date()}\n스레드: ${thread.name}\n" +
                        "기기: ${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n" +
                        sw.toString().take(6000)
                )
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    private fun showLastCrashIfAny() {
        val f = crashFile
        if (!f.exists()) return
        val text = try { f.readText() } catch (e: Exception) { return }
        f.delete()
        if (text.isBlank()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("앱이 꺼진 원인 기록")
            .setMessage(text.take(1500))
            .setPositiveButton("복사") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", text))
                toast("복사했어요. 개발자에게 붙여넣어 보내 주세요")
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 시스템 미디어 플레이어(알림)를 눌러 들어왔으면, 재생 중인 탭이 있는 창으로 보내고 이 인스턴스는 닫는다
        if (savedInstanceState == null && routeToMediaTab()) return
        registerPipReceiver()
        // launchMode 가 standard 라서, 같은 작업(창)에 이미 이 앱이 떠 있는데 밖에서 링크·공유로 또 열리면
        // 창이 겹쳐 생긴다. 그럴 땐 새로 만들지 않고 기존 창에 넘기고 닫는다 (예전 singleTop 과 같은 효과)
        if (savedInstanceState == null && forwardToExistingWindow()) return
        instances.add(this)
        ui.post { notifyOtherWindows() }
        val wantNo = intent?.getIntExtra(EXTRA_WINDOW_NO, 0) ?: 0
        // 닫히는 중인 창은 번호를 쥐고 있지 않은 것으로 본다 (마지막 탭을 새 창으로 옮기며 닫히는 창의 번호를 이어받기 위해)
        val others = instances.filter { it !== this && !it.isFinishing }
        // 창 번호: 저장된 창을 다시 열 때는 그 번호, 첫 창은 1, 새 창은 쓰고 있지 않은 가장 작은 번호
        // (탭이 남아 있는 닫힌 창의 번호는 건너뛴다). 번호가 계속 커지지 않고, 겹치지 않는다.
        var openedSavedWindow = false
        windowNo = when {
            wantNo > 0 && others.none { it.windowNo == wantNo } -> wantNo
            others.isEmpty() -> {
                // 앱을 새로 켤 때: 1번 창에 탭이 있으면 1번, 없으면 탭이 남아 있는 가장 작은 번호의 창을 먼저 연다
                // (비어 있는 1번 창 대신 이미 탭이 있는 창이 열리게)
                val p = Prefs(applicationContext)
                if (savedInstanceState != null || p.savedTabCount(1) > 0) 1
                else p.savedWindowNos().sorted().firstOrNull { it != 1 && p.savedTabCount(it) > 0 }
                    ?.also { openedSavedWindow = true } ?: 1
            }
            else -> {
                val taken = Prefs(applicationContext).savedWindowNos()
                var n = 1
                while (n in taken || others.any { it.windowNo == n }) n++
                n
            }
        }
        // 1번 창은 늘 저장분을 되살리고, 다른 창은 앱을 켤 때 저장된 창을 다시 열 때만 되살린다
        restoreSlot = windowNo == 1 || openedSavedWindow || intent?.getBooleanExtra(EXTRA_RESTORE, false) == true
        isPrimary = primary == null
        if (isPrimary) primary = this
        installCrashLogger()
        window.decorView.post { showLastCrashIfAny() }
        setContentView(R.layout.activity_main)
        installCaptionIntegration()

        urlBar = findViewById(R.id.urlBar)
        progressBar = findViewById(R.id.progressBar)
        webContainer = findViewById(R.id.webContainer)
        // WebView 위에 겹쳐지는 우측 드래그 스크롤바. 페이지 자체의 세로 스크롤과 직접 동기화한다.
        pageScrollBar = WebPageScrollBar(this)
        (webContainer.parent as? FrameLayout)?.addView(
            pageScrollBar,
            FrameLayout.LayoutParams(dp(32), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
        )
        // 손가락 움직임을 메뉴바가 먼저 받아 쓰고, 남는 만큼만 페이지가 스크롤된다 (크롬 방식)
        webContainer.onNestedStart = { onBarsGestureStart() }
        webContainer.onNestedPreScrollDy = { dy -> onBarsPreScroll(dy) }
        webContainer.onNestedStop = { onBarsGestureStop() }
        // 바 높이가 바뀌거나(탭 스트립 표시 등) 키보드가 나타났다 사라지면 전체 크기 고정 레이아웃을 다시 맞춘다
        val barsSizeListener = View.OnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) browserUi.post { barsSyncFullLayout() }
        }
        barsSizeListenerRef = barsSizeListener
        // 페이지가 맨 위일 때(그리고 홈 화면이 아닐 때)만 아래로 당겨 새로고침
        webContainer.canChildScrollUp = {
            val c = current
            c == null || c.isHome || c.webView.scrollY > 0
        }
        // 핀치로 확대해 둔 페이지에서는 당겨서 새로고침을 하지 않는다 (확대 후 끌어내리는 동작은 화면 이동이다)
        webContainer.isPullBlocked = {
            val c = current
            c == null || c.isHome || (c.webView as? NestedWebView)?.isZoomedIn == true
        }
        MediaBridge.onStop = { instances.toList().forEach { a -> a.ui.post { a.pauseAllMedia() } } }
        webContainer.onRefresh = {
            val c = current
            if (c == null || c.isHome) {
                webContainer.endRefresh()
            } else {
                reloadTab(c)
                // 로딩 완료 신호가 안 오더라도 표시기가 남지 않게
                webContainer.postDelayed({ webContainer.endRefresh() }, 8000)
            }
        }
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnHome = findViewById(R.id.btnHome)
        btnTabs = findViewById(R.id.btnTabs)
        tabCount = findViewById(R.id.tabCount)
        btnBottomTabs = findViewById(R.id.btnBottomTabs)
        tabCountBottom = findViewById(R.id.tabCountBottom)
        stripTabCount = findViewById(R.id.stripTabCount)
        btnMenu = findViewById(R.id.btnMenu)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        fullscreenContainer.enabledProvider = { prefs.swipeDownExit && customView != null && !isInPictureInPictureModeCompat() }
        fullscreenContainer.onDismiss = {
            // 영상이 내려가며 사라진 뒤, 브라우저 화면이 부드럽게 나타난다
            browserUi.alpha = 0f
            hideCustomView()
            browserUi.animate().cancel()
            browserUi.animate().alpha(1f).setDuration(200).start()
        }
        // 전체화면 동영상을 아래로 끌어내리면 전체화면 해제
        homeTagline = findViewById(R.id.homeTagline)
        homeTaglineDefault = homeTagline.text
        findBar = findViewById(R.id.findBar)
        etFind = findViewById(R.id.etFind)
        findCount = findViewById(R.id.findCount)
        browserUi = findViewById(R.id.browserUi)
        bottomBar = findViewById(R.id.bottomBar)
        tabStripBar = findViewById(R.id.tabStripBar)
        // 탭 줄 자체는 그림자를 만들지 않는다.
        tabStripBar.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) { outline.setEmpty() }
        }
        // 다른 창에서 끌고 온 탭을 받는다
        tabStripBar.setOnDragListener { v, e -> onStripReceiveDrag(v, e) }
        // 다른 앱에서 파일을 끌어다 이 창에 놓으면 새 탭으로 연다
        window.decorView.setOnDragListener { _, e -> onExternalDragRoot(e) }
        tabStripScroll = findViewById(R.id.tabStripScroll)
        tabStrip = findViewById(R.id.tabStrip)
        navGroup = findViewById(R.id.navGroup)
        tbBack = findViewById(R.id.tbBack)
        tbForward = findViewById(R.id.tbForward)
        tbHome = findViewById(R.id.tbHome)
        tbMenu = findViewById(R.id.tbMenu)
        tbDesktop = findViewById(R.id.tbDesktop)
        tbAi = findViewById(R.id.tbAi)
        tabletActions = findViewById(R.id.tabletActions)
        homeView = findViewById(R.id.homeView)
        barsSizeListenerRef?.let {
            toolbarView.addOnLayoutChangeListener(it)
            tabStripBar.addOnLayoutChangeListener(it)
        }
        browserUi.viewTreeObserver.addOnGlobalLayoutListener {
            val ime = androidx.core.view.ViewCompat.getRootWindowInsets(browserUi)
                ?.isVisible(WindowInsetsCompat.Type.ime()) == true
            if (ime != imeVisible) {
                imeVisible = ime
                browserUi.post { barsSyncFullLayout() }
            }
        }
        homeContent = findViewById(R.id.homeContent)
        tabSwitcher = findViewById(R.id.tabSwitcher)
        applySwitcherCaptionInset(switcherCaptionTop)
        tabList = findViewById(R.id.tabList)
        tabScroll = findViewById(R.id.tabScroll)
        // 끄는 카드가 첫 줄 아래에서 잘리지 않도록 목록 쪽은 항상 잘라내기를 끈다
        // (스크롤 영역 가장자리는 바깥 레이아웃이 계속 잘라 주므로 스크롤된 카드가 머리글 위로 번지지 않는다)
        tabScroll.clipChildren = false
        tabList.clipChildren = false
        tabsTitle = findViewById(R.id.tabsTitle)
        tabMorph = findViewById(R.id.tabMorph)

        prefs = Prefs(this)
        // 되살리는 창이 아닌 새 창이 예전에 같은 번호였던 창의 이름을 물려받지 않게 한다
        if (!restoreSlot && windowNo !in prefs.savedWindowNos()) prefs.setWindowName(windowNo, null)
        // 악성 사이트 검사(Safe Browsing)를 미리 깨워 두어 첫 페이지 이동이 느려지지 않게
        if (prefs.malwareWarning && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            WebView.startSafeBrowsing(applicationContext, null)
        }
        adBlocker = AdBlocker(this)
        adBlockEnabled = prefs.adBlock
        strictTrackers = prefs.strictTrackers
        skipCaptchaTracking = prefs.skipCaptchaTracking
        malwareWarning = prefs.malwareWarning
        blockAutoDownload = prefs.blockAutoDownload
        autofillEnabled = prefs.autofill
        httpsFirst = prefs.httpsFirst
        darkMode = prefs.webDarkMode
        textZoom = prefs.textZoom
        assistant = AssistantUi(
            activity = this,
            prefs = prefs,
            fetchPage = { cb -> fetchPageForAssistant(cb) },
            runPageJs = { js, cb -> runJsOnCurrentPage(js, cb) },
            openUrl = { url -> createTab(url, opener = current) }
        )
        // 광고 목록 읽기는 수 초 걸릴 수 있다. 자동완성·기록 저장이 도는 io 스레드를 막지 않게 따로, 낮은 우선순위로 돈다
        Thread {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            adBlocker.load()
        }.apply { isDaemon = true }.start()
        autoUpdateAdBlockList()

        CookieManager.getInstance().setAcceptCookie(true)
        // 지난번에 앱이 갑자기 꺼졌다면 남아 있는 시크릿 데이터를 지운다 (다른 창이 떠 있으면 그 창의 시크릿 탭이 있을 수 있으니 건드리지 않는다)
        if (instances.size == 1) purgeIncognitoIfUnused()

        applyLayoutMode()
        setupUrlBar()
        setupControls()
        setupHome()
        setupBackHandler()
        setupTabSwitcher()

        // 화면 회전·테마 변경으로 다시 만들어질 때는 같은 인텐트를 또 처리하지 않는다
        val startUrl = if (savedInstanceState == null) launchTarget(intent) else null
        // 다른 창에서 탭이 통째로 넘어온 경우: 주소만이 아니라 웹 기록·확대·스크롤까지 이어받는다
        val handoff = if (savedInstanceState == null) {
            intent?.getLongExtra(EXTRA_HANDOFF, 0L)?.takeIf { it != 0L }?.let { handoffs.remove(it) }
        } else null

        val restored = if (restoreSlot && handoff == null) restoreTabs() else false
        // 앱을 새로 켤 때는 1번 창만 되살린다. 저장된 다른 창들을 자동으로 같이 띄우면
        // 화면이 분할로 갈라지므로, 그 창들은 탭 화면의 창 목록에서 눌러 직접 연다.
        if (handoff != null) receiveTab(handoff, select = true)
        else if (startUrl != null) createTab(startUrl)
        else if (!restored) createTab(null, home = true)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // 창을 끌어 크기·비율을 바꿀 때마다 불린다: 모드(폰/태블릿)가 바뀔 때만 전체를 다시 짜고, 아니면 가볍게 맞춘다
        beginResizeBurst()
        if (wideForWindow() != expanded) applyLayoutMode() else onWindowResized()
        scheduleWebRelayout()
    }

    // ── 창 크기·비율이 바뀔 때 스크롤 위치 지키기 ──

    private var resizeBurst = false
    private var resizeTouchMark = 0L

    /** 지금 스크롤 위치를 (전체 스크롤 가능 길이 대비) 비율로. 스크롤할 수 없으면 0 */
    private fun scrollRatioOf(wv: WebView?): Float {
        wv ?: return -1f
        @Suppress("DEPRECATION")
        val max = (wv.contentHeight * wv.scale).toInt() - wv.height
        return if (max > 0) (wv.scrollY.toFloat() / max).coerceIn(0f, 1f) else 0f
    }

    /**
     * 크기가 바뀌는 첫 순간부터 '안정될 때까지' 스크롤 기록을 멈춰 두고(= 바뀌기 직전 비율이 남는다),
     * 크기 변화가 끝난 뒤 그 비율로 되돌린다. 내용이 늦게 다시 배치되는 페이지를 위해 한 번 더 맞춘다.
     */
    private fun beginResizeBurst() {
        if (!resizeBurst) {
            resizeBurst = true
            resizeTouchMark = lastTouchAt
        }
        ui.removeCallbacks(resizeRestoreFirst)
        ui.removeCallbacks(resizeRestoreSecond)
        ui.postDelayed(resizeRestoreFirst, 450)
    }

    private fun restoreScrollRatio() {
        val t = current ?: return
        val wv = t.liveWebView ?: return
        val ratio = t.scrollRatio
        if (ratio < 0f || t.isHome || switcherOpen || wv.parent !== webContainer) return
        // 그 사이 사용자가 직접 만졌으면 그 위치를 존중한다
        if (lastTouchAt != resizeTouchMark) return
        @Suppress("DEPRECATION")
        val max = (wv.contentHeight * wv.scale).toInt() - wv.height
        val target = if (max > 0) (ratio * max).toInt() else 0
        if (kotlin.math.abs(wv.scrollY - target) > dp(2)) wv.scrollTo(wv.scrollX, target)
    }

    // 두 번째 복원이 끝날 때까지 스크롤 기록을 멈춰 둔다 (늦게 재배치되며 튄 위치가 '기준 비율'을 덮어쓰지 않게)
    private val resizeRestoreFirst = Runnable {
        if (isFinishing || isDestroyed) return@Runnable
        restoreScrollRatio()
        ui.removeCallbacks(resizeRestoreSecond)
        ui.postDelayed(resizeRestoreSecond, 550)
    }

    private val resizeRestoreSecond = Runnable {
        if (isFinishing || isDestroyed) return@Runnable
        restoreScrollRatio()
        resizeBurst = false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun tabKey(t: BrowserTab) = System.identityHashCode(t)

    /** 알림에서 온 인텐트면, 그 탭이 있는 (다른) 창을 앞으로 가져와 탭을 연다. 처리했으면 true */
    private fun routeToMediaTab(): Boolean {
        val id = intent?.getIntExtra(EXTRA_OPEN_TAB, 0) ?: 0
        if (id == 0) return false
        val host = instances.firstOrNull { w ->
            w !== this && !w.isFinishing && !w.isDestroyed && w.tabs.any { tabKey(it) == id }
        } ?: return false
        host.openMediaTab(id)
        finish()
        return true
    }

    /** 이 창에서 해당 탭을 열고, 이 창이 속한 작업을 앞으로 가져온다 */
    internal fun openMediaTab(id: Int) {
        val tab = tabs.firstOrNull { tabKey(it) == id } ?: return
        if (switcherOpen && !switcherBusy) closeTabSwitcher(tab)
        else if (tab !== current) selectTab(tab)
        val front = runCatching {
            getSystemService(android.app.ActivityManager::class.java)
                .appTasks.firstOrNull { it.taskInfo.taskId == taskId }?.also { it.moveToFront() } != null
        }.getOrDefault(false)
        if (!front) {
            startActivity(Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }

    /** 밖에서 들어온 인텐트를 이 창에서 처리한다 (onNewIntent 와, 겹쳐 열린 인스턴스가 넘겨 줄 때 공통) */
    internal fun handleIncomingIntent(intent: Intent) {
        intent.getIntExtra(EXTRA_OPEN_TAB, 0).takeIf { it != 0 }?.let { openMediaTab(it); return }
        // 이미 켜져 있는데 시스템 작업 표시줄에서 앱 아이콘을 끌어다 놓아 런처 실행이 들어온 경우:
        // 시스템이 '새 인스턴스·옆에 붙이기' 로 요청했는데 이 창으로 전달됐다면, 새 창을 옆에 띄운다
        if (isTaskbarNewWindowLaunch(intent)) {
            openNewWindow()
            return
        }
        launchTarget(intent)?.let { createTab(it) }
    }

    /**
     * 같은 작업에 이미 떠 있는 창이 있으면 이번 인텐트를 그 창에 넘기고 이 인스턴스는 닫는다.
     * 새 창 요청(MULTIPLE_TASK / NEW_DOCUMENT)이나 추가 창(BrowserWindowActivity)은 그대로 새 창으로 둔다.
     */
    private fun forwardToExistingWindow(): Boolean {
        val i = intent ?: return false
        if (this is BrowserWindowActivity) return false
        if (i.flags and (Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_NEW_DOCUMENT) != 0) return false
        val host = instances.firstOrNull {
            it !== this && !it.isFinishing && !it.isDestroyed && it.taskId == taskId
        } ?: return false
        host.handleIncomingIntent(i)
        finish()
        return true
    }

    /**
     * 런처(작업 표시줄) 아이콘 실행인데 시스템이 새 작업 / 옆에 붙이기를 요청한 경우인지.
     * 평범한 아이콘 탭(플래그 없음)은 해당하지 않아서, 그냥 앱을 앞으로 가져오는 기존 동작이 그대로다.
     */
    private fun isTaskbarNewWindowLaunch(i: Intent): Boolean {
        if (i.action != Intent.ACTION_MAIN || !i.hasCategory(Intent.CATEGORY_LAUNCHER) || i.data != null) return false
        val asked = Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
        return i.flags and asked != 0
    }

    /**
     * 밖에서 들어온 인텐트가 열어 달라는 주소를 돌려준다.
     * - 링크(VIEW) → 그 주소
     * - 다른 앱의 공유(SEND) / 글자 선택 메뉴(PROCESS_TEXT) → 글에 주소가 있으면 그 주소, 없으면 검색 주소
     */
    private fun launchTarget(intent: Intent?): String? {
        intent ?: return null
        intent.data?.let { d ->
            // 다른 앱이 보낸 주소는 웹 주소와 'HTML 파일 열기'만 받는다 (javascript: 등은 무시)
            val sc = d.scheme?.lowercase()
            if (sc == "http" || sc == "https") return d.toString()
            if (intent.action == Intent.ACTION_VIEW && sc == "content" && isHtmlFile(d, intent.type)) {
                queryFileName(d)?.let { localFileNames[d.toString()] = it }
                return d.toString()
            }
            return null
        }
        val text = when (intent.action) {
            Intent.ACTION_SEND ->
                if (intent.type?.startsWith("text/") == true) intent.getStringExtra(Intent.EXTRA_TEXT) else null
            Intent.ACTION_PROCESS_TEXT ->
                intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }?.trim()
        if (text.isNullOrEmpty()) return null
        // "제목\n https://..." 처럼 공유된 글에서는 주소만 골라 연다
        Regex("https?://[^\\s<>\"']+").find(text)?.let { return it.value.trimEnd('.', ',', ')', ']') }
        // 그 밖의 글은 한 줄로 정리해서 검색 (너무 길면 자른다). 단축어("yt 노래" 등)는 적용하지 않는다.
        val query = text.replace(Regex("\\s+"), " ").take(300)
        return prefs.currentEngine().url(query)
    }

    /** 열어 달라고 온 파일이 HTML 문서인지: 형식이 HTML 이거나, 형식을 모르면 파일 이름이 .html/.htm 으로 끝나는 경우 */
    private fun isHtmlFile(d: Uri, mime: String?): Boolean {
        val t = (mime ?: try { contentResolver.getType(d) } catch (e: Throwable) { null })?.lowercase()
        if (t == "text/html" || t == "application/xhtml+xml") return true
        if (t != null && t != "*/*" && t != "application/octet-stream") return false
        val name = (queryFileName(d) ?: d.lastPathSegment ?: "").lowercase()
        return name.endsWith(".html") || name.endsWith(".htm") || name.endsWith(".xhtml")
    }

    /** content:// 파일의 이름 (주소창에 보여 주기 위해) */
    private fun queryFileName(d: Uri): String? = try {
        contentResolver.query(d, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Throwable) {
        null
    }

    /** 이 창이 지금 화면에 보이는 중인지 (onStart ~ onStop). 런처 진입점이 "이미 보고 있는 앱을 또 눌렀는지" 가리는 데 쓴다 */
    @Volatile
    internal var visibleNow = false

    override fun onStart() {
        super.onStart()
        visibleNow = true
    }

    override fun onStop() {
        super.onStop()
        visibleNow = false
        saveTabs()
    }

    override fun onPause() {
        super.onPause()
        saveTabs()
        adBlocker.flush()
        if (!isInPictureInPictureMode) {
            // 백그라운드 재생이 켜져 있으면 소리가 나는 탭은 멈추지 않는다
            tabs.forEach {
                if (!(prefs.backgroundAudio && it.mediaFrames.isNotEmpty())) it.liveWebView?.onPause()
            }
        }
        CookieManager.getInstance().flush()
    }

    override fun onResume() {
        super.onResume()
        // 앱을 나갔다 올 때 멈춘 모든 탭을 다시 깨운다 (안 보이는 탭도 계속 돌아가야 하므로)
        tabs.forEach { it.liveWebView?.onResume(); it.paused = false }
        current?.webView?.onResume()
        autoUpdateAdBlockList()
        // 다른 창에 다녀왔을 때 탭 화면의 창 목록도 최신으로
        if (switcherOpen) refreshWindowStrip()
        // 북마크 / 방문 기록 / 다운로드 팝업의 ← 로 돌아왔으면 메뉴를 다시 띄운다
        if (ListUi.reopenMenu) {
            ListUi.reopenMenu = false
            val a = menuAnchorRef?.get()
            if (a != null) window.decorView.post { if (!isFinishing && a.isShown) showMenu(a) }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // 영상을 전체화면으로 보는 중에 앱을 나가면 작은 창으로 바뀐다.
        // Android 12+ 는 refreshPipParams() 의 자동 진입이 처리한다. 그 이전 버전은 여기서 직접 들어간다.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && autoPipWanted()) enterPip()
    }

    // ───────────────────────── PiP (작은 창 재생) ─────────────────────────

    private var pipKey = ""

    private fun pipWanted(): Boolean {
        if (customView != null) return true
        val t = current ?: return false
        return !t.isHome && t.mediaFrames.values.any { it.video }
    }

    /** 앱을 나갈 때 저절로 작은 창이 되는 경우: 영상을 전체화면으로 보고 있을 때만 */
    private fun autoPipWanted(): Boolean = customView != null

    private var lastPipRatio: android.util.Rational? = null

    private fun pipRatio(): android.util.Rational {
        val f = current?.mediaFrames?.values?.firstOrNull { it.video && it.w > 0 && it.h > 0 }
        // 일시정지하면 재생 정보가 사라지는데, 그때 비율이 16:9 로 튀어 작은 창 모양이 바뀌지 않게 마지막 비율을 기억한다
        if (f == null) lastPipRatio?.let { return it }
        var w = f?.w ?: 16
        var h = f?.h ?: 9
        val r = w.toFloat() / h
        if (r > 2.39f) { w = 239; h = 100 } else if (r < 0.4184f) { w = 100; h = 239 }
        return android.util.Rational(w, h).also { if (f != null) lastPipRatio = it }
    }

    /** PiP 작은 창에 시스템이 그려 주는 재생/일시정지 버튼 */
    private val pipActionName by lazy { "$packageName.PIP_TOGGLE.${System.identityHashCode(this)}" }
    private var pipReceiver: android.content.BroadcastReceiver? = null

    private fun registerPipReceiver() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                handleMediaControl(intent?.getStringExtra("cmd") ?: "toggle", 0L)
            }
        }
        try {
            ContextCompat.registerReceiver(
                this, r, android.content.IntentFilter(pipActionName), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            pipReceiver = r
        } catch (e: Exception) {
            // 무시
        }
    }

    private fun pipPlaying(): Boolean = mediaSel?.first?.mediaFrames?.isNotEmpty() == true

    private fun pipParams(auto: Boolean): PictureInPictureParams {
        val b = PictureInPictureParams.Builder().setAspectRatio(pipRatio())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playing = pipPlaying()
            fun act(code: Int, cmd: String, res: Int, label: String): android.app.RemoteAction {
                val pi = PendingIntent.getBroadcast(
                    this, code, Intent(pipActionName).setPackage(packageName).putExtra("cmd", cmd),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                return android.app.RemoteAction(
                    android.graphics.drawable.Icon.createWithResource(this, res), label, label, pi
                )
            }
            b.setActions(
                listOf(
                    act(1, "prev", R.drawable.ic_pip_prev, "이전 영상"),
                    act(0, "toggle", if (playing) R.drawable.ic_pip_pause else R.drawable.ic_pip_play, if (playing) "일시정지" else "재생"),
                    act(2, "next", R.drawable.ic_pip_next, "다음 영상")
                )
            )
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) b.setAutoEnterEnabled(auto)
        return b.build()
    }

    private fun enterPip(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || isInPictureInPictureMode) return false
        return try {
            enterPictureInPictureMode(pipParams(autoPipWanted()))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** 영상 비율을 맞춰 두고, Android 12+ 에서는 홈으로 나갈 때 저절로 작은 창으로 바뀌게 한다. */
    private fun refreshPipParams() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val want = autoPipWanted()
        val r = pipRatio()
        val key = "$want $r ${pipPlaying()}"
        if (key == pipKey) return
        pipKey = key
        try {
            setPictureInPictureParams(pipParams(want))
        } catch (e: Exception) {
            // PiP 불가 시 무시
        }
    }

    private fun startPipFromMenu() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            toast("이 기기는 PiP 를 지원하지 않아요")
        } else if (!pipWanted()) {
            toast("재생 중인 동영상이 없어요")
        } else if (!enterPip()) {
            toast("PiP 를 시작할 수 없어요")
        }
    }

    private fun isInPictureInPictureModeCompat(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (customView != null) return
        if (isInPictureInPictureMode) {
            // 주소창·탭바 등을 숨기고 재생 중인 동영상만 창 가득 보이게
            tabStripBar.visibility = View.GONE
            toolbarView.visibility = View.GONE
            bottomBar.visibility = View.GONE
            progressBar.visibility = View.GONE
            current?.webView?.evaluateJavascript(MediaScripts.PIP_ON, null)
        } else {
            toolbarView.visibility = View.VISIBLE
            applyLayoutMode(pip = false)
            current?.webView?.evaluateJavascript(MediaScripts.PIP_OFF, null)
        }
    }

    // ───────────────────────── 백그라운드 재생 ─────────────────────────

    private val stopMediaRunnable = Runnable {
        if (instances.none { a -> a.tabs.any { it.mediaFrames.isNotEmpty() } } || !prefs.backgroundAudio) {
            mediaKey = ""
            pushKey = ""
            MediaService.stop(this)
        }
    }
    private var mediaKey = ""

    // ── 시스템 미디어 플레이어 (알림창·잠금화면 미디어 컨트롤) ──

    /** 시스템 미디어 플레이어가 조작할 (탭, 프레임) */
    private var mediaSel: Pair<BrowserTab, String>? = null
    private var pushKey = ""
    private var pushPlaying = false
    private var pushPos = 0.0
    private var pushAt = 0L
    private val mediaIdleCheck = Runnable { onMediaChanged() }

    /** 아직 살아 있는 조작 대상. 일시정지한 지 10분이 넘었거나 페이지를 떠났으면 null */
    private fun mediaSessionTarget(): Pair<BrowserTab, String>? {
        val sel = mediaSel ?: return null
        val (t, f) = sel
        if (t !in tabs) return null
        val p = t.mediaProg[f] ?: return null
        if (!p.playing && android.os.SystemClock.uptimeMillis() - p.at > 10L * 60 * 1000) return null
        return sel
    }

    private val mediaArtCache = android.util.LruCache<String, Bitmap>(4)
    private val mediaArtLoading = HashSet<String>()
    /** 받기에 실패한 주소 → 실패한 시각. 영영 포기하지 않고 20초 뒤에 다시 시도한다 */
    private val mediaArtFailed = HashMap<String, Long>()
    private fun mediaArtGivenUp(url: String): Boolean {
        val at = mediaArtFailed[url] ?: return false
        if (android.os.SystemClock.uptimeMillis() - at > 20_000L) { mediaArtFailed.remove(url); return false }
        return true
    }

    /** 썸네일 주소의 그림을 받아 와(가장 긴 쪽 512px 이하로 줄여) 미디어 플레이어를 다시 갱신한다 */
    private fun loadMediaArt(url: String, referer: String = "") {
        if (!mediaArtLoading.add(url)) return
        Thread {
            var bmp: Bitmap? = null
            try {
                val rb = okhttp3.Request.Builder().url(url)
                    .header("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
                if (referer.startsWith("http")) rb.header("Referer", referer)
                val req = rb.build()
                PlayerHttp.client.newCall(req).execute().use { r ->
                    val body = r.body
                    if (r.isSuccessful && body != null && body.contentLength() <= 6_000_000L) {
                        val bytes = body.bytes()
                        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        var sample = 1
                        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2
                        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                        val d = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                        if (d != null) {
                            val m = maxOf(d.width, d.height)
                            bmp = if (m > 512) {
                                val sc = 512f / m
                                Bitmap.createScaledBitmap(d, (d.width * sc).toInt().coerceAtLeast(1), (d.height * sc).toInt().coerceAtLeast(1), true)
                            } else d
                        }
                    }
                }
            } catch (e: Throwable) {
                // 받기 실패: 사이트 아이콘을 그대로 쓴다
            }
            val done = bmp
            ui.post {
                mediaArtLoading.remove(url)
                if (done != null) { mediaArtCache.put(url, done); mediaArtFailed.remove(url) }
                else mediaArtFailed[url] = android.os.SystemClock.uptimeMillis()
                // 받기에 실패했을 때는 화면에 달라질 게 없으니 불필요하게 다시 밀어 넣지 않는다
                updateMediaSession(force = done != null)
            }
        }.start()
    }

    /** 재생 상태·곡 정보가 바뀌었거나 재생 위치가 크게 달라졌을 때만 시스템 미디어 플레이어를 갱신한다 */
    private fun updateMediaSession(force: Boolean = false) {
        if (!prefs.mediaControls) return
        val sel = mediaSessionTarget() ?: return
        val (t, f) = sel
        val p = t.mediaProg[f] ?: return
        val m = t.mediaMeta[f]
        val host = runCatching { Uri.parse(t.liveWebView?.url).host }.getOrNull().orEmpty()
        val pageTitle = t.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" }
        val title = m?.title?.takeIf { it.isNotBlank() } ?: pageTitle ?: host
        val artist = m?.artist.orEmpty()
        val durKey = if (p.dur > 0) p.dur.toLong() else -1L
        // 시스템 미디어 플레이어 그림: 영상/곡 그림(썸네일)을 받아 오고, 못 받으면 사이트 아이콘
        val artUrl = m?.art.orEmpty()
        val artBmp = if (artUrl.isNotEmpty()) mediaArtCache.get(artUrl) else null
        if (artUrl.isNotEmpty() && artBmp == null && !mediaArtGivenUp(artUrl)) loadMediaArt(artUrl, t.liveWebView?.url.orEmpty())
        val key = "${System.identityHashCode(t)}|$f|$title|$artist|${p.playing}|$durKey|$artUrl|${artBmp != null}"
        val now = android.os.SystemClock.uptimeMillis()
        val predicted = if (pushPlaying) pushPos + (now - pushAt) / 1000.0 else pushPos
        val drift = kotlin.math.abs(p.pos - predicted) > 2.0
        if (key == pushKey && !drift && !force) return
        pushKey = key
        pushPlaying = p.playing
        pushPos = p.pos
        pushAt = now
        MediaBridge.art = artBmp ?: t.favicon?.let { b ->
            if (b.width > 256 || b.height > 256) {
                val sc = 256f / maxOf(b.width, b.height)
                runCatching { Bitmap.createScaledBitmap(b, (b.width * sc).toInt().coerceAtLeast(1), (b.height * sc).toInt().coerceAtLeast(1), true) }.getOrNull()
            } else b
        }
        MediaBridge.onControl = { a, v -> ui.post { handleMediaControl(a, v) } }
        MediaBridge.openTabId = tabKey(t)
        MediaService.start(
            this, title, host, controls = true, artist = artist, playing = p.playing,
            posMs = (p.pos * 1000).toLong(), durMs = if (p.dur > 0) (p.dur * 1000).toLong() else -1L
        )
        // 일시정지 상태로 오래 두면 10분 뒤에 알림을 거둔다
        ui.removeCallbacks(mediaIdleCheck)
        if (!p.playing) ui.postDelayed(mediaIdleCheck, 10L * 60 * 1000 + 1000)
    }

    /** 시스템 미디어 플레이어에서 온 조작을 페이지의 미디어에 전한다 */
    private fun handleMediaControl(a: String, v: Long) {
        val (t, f) = mediaSel ?: return
        val p = t.mediaProg[f]
        fun send(cmd: String, value: Double = 0.0) {
            t.liveWebView?.evaluateJavascript(
                "window.postMessage({__ev:'cmd',f:${JSONObject.quote(f)},a:'$cmd',v:$value},'*');", null
            )
        }
        when (a) {
            "play" -> if (p?.playing != true) send("toggle")
            "pause" -> if (p?.playing != false) send("toggle")
            "toggle" -> send("toggle")
            "seek" -> send("seek", v / 1000.0)
            "skip" -> send("skip", v / 1000.0)
            "next" -> send("next")
            "prev" -> send("prev")
        }
    }

    /** 페이지가 재생 상태를 알려 올 때 (메인 스레드) */
    private inner class MediaJs(val tab: BrowserTab) {
        /** true 면 페이지에 "숨겨지지 않았다"고 알려 스스로 멈추지 못하게 한다. 지금 안 보이는 탭도 계속 돌게 하려고 항상 true */
        @JavascriptInterface
        fun bg(): Boolean = prefs.backgroundAudio || tab !== current

        /** 이 탭이 음소거인지 (페이지 스크립트가 소리를 끌지 판단) */
        @JavascriptInterface
        fun muted(): Boolean = tab.muted

        /** 손가락이 닿은 자리가 페이지 안쪽에서 이미 스크롤되어 있다/스크롤 중이다 → 당겨서 새로고침 금지 (백그라운드 스레드에서 불린다) */
        @JavascriptInterface
        fun pullInner(v: Boolean) {
            if (tab === current) webContainer.innerScrolled = v
        }

        /** 페이지가 자체 로딩 바를 그리고 있다고 알려 올 때 (백그라운드 스레드에서 불린다) */
        @JavascriptInterface
        fun ownBar(v: Boolean) {
            if (!v) return
            ui.post {
                tab.ownProgressBar = true
                if (tab === current) {
                    progressBar.animate().cancel()
                    progressBar.visibility = View.GONE
                }
            }
        }

        /**
         * 페이지(다른 도메인의 iframe 포함)에서 재생이 시작된 영상 주소.
         * 주 프레임 스크립트는 다른 도메인의 iframe 안을 볼 수 없어서, iframe 쪽 스크립트가 직접 알려 오게 했다.
         * (백그라운드 스레드에서 불린다)
         */
        @JavascriptInterface
        fun src(url: String?) {
            if (url.isNullOrEmpty() || !(url.startsWith("http://") || url.startsWith("https://"))) return
            synchronized(tab.sniffed) {
                if (url in tab.sniffed) return
                if (tab.sniffed.size >= SNIFF_MAX) tab.sniffed.remove(tab.sniffed.first())
                tab.sniffed.add(url)
            }
        }

        @JavascriptInterface
        fun adblock(): Boolean = adBlockEnabled

        /** 이 주소가 광고인지 (페이지 스크립트의 팝업/링크 확인용) */
        @JavascriptInterface
        fun adurl(url: String?): Boolean = adBlockEnabled && adBlocker.isAdUrl(url)

        /**
         * 페이지 스크립트가 보내려는 요청(fetch/XHR/sendBeacon)이 광고·추적인지.
         * 맞으면 페이지 쪽에서 진짜 차단기처럼 '네트워크 오류'로 실패시키고 차단 건수에 센다.
         */
        @JavascriptInterface
        fun adreq(url: String?, pageHost: String?): Boolean {
            if (!adBlockEnabled || url.isNullOrEmpty()) return false
            val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return false
            val blocked = adBlocker.shouldBlock(host, pageHost, url, NetFilter.inferType(url, null, false))
            if (blocked) {
                adBlocker.record(host, AdBlocker.KIND_REQUEST)
                tab.adBlocked.incrementAndGet()
            }
            return blocked
        }

        /**
         * 페이지의 <video> 가 가리키는 주소가 광고 영상(배너)인지: 광고 서버 목록, 영상 배너 주소 모양, 예외 규칙까지 본다.
         * 영상 배너 감지 스크립트가 쓴다 (차단 건수는 실제로 가렸을 때 [adhid] 로 센다).
         */
        @JavascriptInterface
        fun advid(url: String?, pageHost: String?): Boolean = adBlockEnabled && adBlocker.isAdVideoUrl(url, pageHost)

        /** 영상 배너를 화면에서 가렸을 때: 차단 건수에 센다 */
        @JavascriptInterface
        fun adhid(pageHost: String?) {
            if (!adBlockEnabled) return
            adBlocker.record(pageHost, AdBlocker.KIND_REQUEST)
            tab.adBlocked.incrementAndGet()
        }

        /** 이 사이트에서 사용자가 직접 고른 광고의 선택자 목록 (JSON 배열 글자) */
        @JavascriptInterface
        fun aduser(host: String?): String {
            if (!adBlockEnabled) return "[]"
            val arr = org.json.JSONArray()
            for (s in adBlocker.userSelectors(host)) arr.put(s)
            return arr.toString()
        }

        /** '광고 직접 선택' 에서 '차단' 을 눌렀을 때 */
        @JavascriptInterface
        fun adpick(host: String?, selector: String?, label: String?, src: String?): Boolean =
            adBlocker.addUserRule(host, selector, label, src)

        /** '광고 직접 선택' 이 끝났을 때 (blocked = 이번에 고른 개수) */
        @JavascriptInterface
        fun adpickEnd(blocked: Int) {
            ui.post {
                if (tab !in tabs) return@post
                if (blocked > 0) toast("광고 ${blocked}건을 직접 차단했어요 · 설정에서 관리할 수 있어요")
                if (tab === current) updateUi()
            }
        }

        /** 오류 화면의 '다시 시도' (오류 화면은 loadDataWithBaseURL 이라 location.replace 로는 다시 불러와지지 않는다) */
        @JavascriptInterface
        fun errRetry() {
            ui.post { if (tab in tabs && tab.errorUrl != null) reloadTab(tab) }
        }

        /** 오류 화면의 '이전으로' */
        @JavascriptInterface
        fun errBack() {
            ui.post {
                if (tab !in tabs || tab.errorUrl == null) return@post
                if (canGoBackSmart(tab)) {
                    goBackSmart(tab)
                } else {
                    // 돌아갈 페이지가 없으면 시작 화면으로
                    loadHome(tab)
                }
            }
        }

        /** 첫 화면에만 적용하는 광고 영역 숨김 CSS (내려받은 목록 기준) */
        @JavascriptInterface
        fun adcss(host: String?): String = adBlocker.topCss(host)

        /** 재생 위치·길이 보고 (백그라운드 스레드에서 불린다) */
        @JavascriptInterface
        fun progress(fid: String, pos: Double, dur: Double, playing: Boolean) {
            val now = android.os.SystemClock.uptimeMillis()
            ui.post {
                if (tab !in tabs) return@post
                tab.mediaProg[fid] = MediaProg(pos, dur, playing, now)
                if (playing || mediaSel?.second == fid) {
                    if (playing) mediaSel = tab to fid
                    updateMediaSession()
                }
            }
        }

        /** 곡·영상 제목/아티스트 보고 (곡이 바뀔 때마다 온다) */
        @JavascriptInterface
        fun meta(fid: String, title: String?, artist: String?, art: String?) {
            val t = title.orEmpty().trim().take(200)
            val a = artist.orEmpty().trim().take(200)
            val im = art.orEmpty().trim().take(2000)
            ui.post {
                if (tab !in tabs) return@post
                if (t.isEmpty() && a.isEmpty() && im.isEmpty()) tab.mediaMeta.remove(fid) else tab.mediaMeta[fid] = MediaMeta(t, a, im)
                if (mediaSel?.second == fid) updateMediaSession()
            }
        }

        /** 파형용 소리 크기 보고: 막대 값을 쉼표로 이은 글자, 빈 글자 = 값 없음, 'x' = 읽을 수 없는 페이지 */
        @JavascriptInterface
        fun wave(fid: String, csv: String) {
            val now = android.os.SystemClock.uptimeMillis()
            val w = when {
                csv.isEmpty() -> null
                csv == "x" -> MediaWave(null, true, now)
                else -> MediaWave(
                    csv.split(',').map { (it.toIntOrNull() ?: 0) / 99f }.toFloatArray(), false, now
                )
            }
            ui.post {
                if (tab !in tabs) return@post
                if (w == null) tab.mediaWave.remove(fid) else tab.mediaWave[fid] = w
            }
        }

        /** 이 프레임의 페이지가 닫혔다: 진행 상황을 지운다 */
        @JavascriptInterface
        fun gone(fid: String) {
            ui.post {
                tab.mediaProg.remove(fid); tab.mediaWave.remove(fid); tab.mediaMeta.remove(fid)
                // 시스템 미디어 플레이어가 조작하던 페이지를 떠났으면 알림을 거둔다
                if (mediaSel?.second == fid) onMediaChanged()
            }
        }

        /** 영상 아래 '내장 플레이어로 열기' 버튼. url 은 그 영상의 주소(http/https, 없으면 빈 문자열), pos 는 초 */
        @JavascriptInterface
        fun openPlayer(url: String?, pos: Double, fromVideoButton: Boolean) {
            ui.post {
                if (tab === current) openInternalPlayer(
                    url?.takeIf { it.isNotBlank() }, (pos * 1000).toLong(), fromVideoButton
                )
            }
        }

        /** 영상 아래 버튼('내장 플레이어로 열기' / 'PiP로 보기')을 보여 줄지 (설정에서 끌 수 있다) */
        @JavascriptInterface
        fun buttons(): Boolean = prefs.videoButtons

        /** 유튜브 광고의 '건너뛰기' 버튼을 자동으로 누를지 */
        @JavascriptInterface
        fun ytAutoSkip(): Boolean = prefs.ytAutoSkip

        /** 영상 아래 'PiP로 보기' 버튼 */
        @JavascriptInterface
        fun pip() {
            ui.post { if (tab === current) startPipFromMenu() }
        }

        @JavascriptInterface
        fun state(fid: String, playing: Boolean, video: Boolean, w: Int, h: Int) {
            ui.post {
                if (tab !in tabs) return@post
                if (playing) {
                    tab.mediaFrames[fid] = MediaFrame(video, w, h)
                    mediaSel = tab to fid
                } else {
                    tab.mediaFrames.remove(fid)
                }
                onMediaChanged()
            }
        }
    }

    // ── 보고 있지 않은 탭이 소리·영상을 계속 내도록, 화면 뒤 1px 칸에 붙여 둔다 ──

    private var parkHost: FrameLayout? = null

    private fun parkHost(): FrameLayout? {
        parkHost?.let { return it }
        val area = webContainer.parent as? FrameLayout ?: return null
        val h = FrameLayout(this).apply {
            clipChildren = true
            alpha = 0.01f
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
        area.addView(h, 0, FrameLayout.LayoutParams(1, 1))
        parkHost = h
        return h
    }

    private fun parkIfPlaying(tab: BrowserTab) {
        val wv = tab.liveWebView ?: return
        if (tab.mediaFrames.isEmpty() || wv.parent != null) return
        val host = parkHost() ?: return
        // 웹뷰 크기는 화면과 똑같이 유지해서 페이지 배치가 바뀌지 않게 한다
        val w = webContainer.width.coerceAtLeast(dp(320))
        val h = webContainer.height.coerceAtLeast(dp(480))
        wv.layoutParams = FrameLayout.LayoutParams(w, h)
        host.addView(wv)
    }

    /** 다시 화면에 올리기 전에 보이지 않는 칸에서 떼고, 크기를 화면에 맞게 되돌린다 */
    private fun unparkWebView(tab: BrowserTab) {
        val wv = tab.liveWebView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    /** 더 이상 소리가 나지 않는 탭은 보이지 않는 칸에서 내려 자원을 아낀다 */
    private val sweepParked = Runnable {
        val host = parkHost ?: return@Runnable
        tabs.forEach { t ->
            val wv = t.liveWebView ?: return@forEach
            if (wv.parent === host && t.mediaFrames.isEmpty()) host.removeView(wv)
        }
    }

    private fun onMediaChanged() {
        // 보고 있지 않은 탭에서 재생이 시작됐다면 그 탭도 붙여 둔다
        tabs.forEach { if (it !== current) parkIfPlaying(it) }
        ui.removeCallbacks(sweepParked)
        ui.postDelayed(sweepParked, 4000)
        val playing = tabs.filter { it.mediaFrames.isNotEmpty() }
        val sessionTarget = if (prefs.mediaControls) mediaSessionTarget() else null
        if (sessionTarget != null) {
            // 시스템 미디어 플레이어에 보여 주는 동안(일시정지 포함)은 서비스를 유지한다
            ui.removeCallbacks(stopMediaRunnable)
            updateMediaSession()
        } else if (playing.isEmpty() || !prefs.backgroundAudio) {
            // 버퍼링이나 다음 영상으로 넘어가는 짧은 끊김에는 알림을 유지한다
            ui.removeCallbacks(stopMediaRunnable)
            ui.postDelayed(stopMediaRunnable, 2500)
        } else {
            ui.removeCallbacks(stopMediaRunnable)
            val t = playing.firstOrNull { it === current } ?: playing.first()
            val host = runCatching { Uri.parse(t.liveWebView?.url).host }.getOrNull().orEmpty()
            val title = t.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" } ?: host
            val key = "${System.identityHashCode(t)}|$title"
            if (key != mediaKey) {
                mediaKey = key
                // 알림 권한을 따로 요청하지 않는다 (재생 알림을 띄우지 않기 위해)
                MediaBridge.openTabId = tabKey(t)
                MediaService.start(this, title, host)
            }
        }
        refreshPipParams()
    }

    private fun pauseAllMedia() {
        tabs.forEach { it.liveWebView?.evaluateJavascript(MediaScripts.PAUSE_ALL, null) }
    }

    override fun onDestroy() {
        extDropPerms.forEach { runCatching { it.release() } }
        extDropPerms.clear()
        pipReceiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        pipReceiver = null
        downloadCard.destroy()
        spareWebView?.destroy()
        spareWebView = null
        instances.remove(this)
        notifyOtherWindows()
        // 창을 닫아도 탭은 남는다 (탭 화면의 창 목록에서 다시 열 수 있다). 앱을 켤 때 자동으로 열리지만 않게 한다
        if (isFinishing && ::prefs.isInitialized) prefs.markWindowClosed(windowNo)
        if (primary === this) {
            primary = null
            // 대표 창이 닫히면 남은 창 하나가 탭 저장을 이어받는다 (사용자가 닫은 경우에만)
            if (isFinishing) instances.firstOrNull()?.let { it.isPrimary = true; primary = it }
        }
        ui.removeCallbacks(stopMediaRunnable)
        ui.removeCallbacks(sweepParked)
        if (instances.isEmpty()) {
            MediaBridge.onStop = null
            MediaService.stop(this)
        }
        tabs.forEach {
            val w = it.liveWebView ?: return@forEach
            w.stopLoading()
            (w.parent as? ViewGroup)?.removeView(w)
            w.destroy()
        }
        tabs.clear()
        if (instances.isEmpty()) purgeIncognitoIfUnused(false)
        io.shutdown()
        super.onDestroy()
    }

    // ───────────────────────── 탭 ─────────────────────────

    // ───────────────────────── 탭 저장 / 복원 ─────────────────────────

    /** 열려 있는 탭(주소·그룹·데스크톱 여부·선택한 탭)을 저장한다. 앱을 껐다 켜도 그대로 남는다. */
    private fun saveTabs() {
        try {
            // 시크릿 탭은 저장하지 않는다 (앱을 다시 켜면 사라진다)
            val saved = tabs.filter { !it.incognito }
            if (tabs.isEmpty()) return
            // 1번이 아닌 창에 열린 페이지가 하나도 없으면 저장할 게 없다 (저장분이 있었다면 지운다)
            if (windowNo != 1 && saved.all { it.isHome }) {
                prefs.clearSavedTabsFor(windowNo)
                return
            }
            val arr = JSONArray()
            for (t in saved) {
                val lw = t.liveWebView
                val live = lw?.url?.takeIf { (it.startsWith("http://") || it.startsWith("https://")) && !it.startsWith(LOCAL_BASE) }
                val url = if (t.isHome) null else (live ?: t.pendingUrl?.takeIf { !it.startsWith(LOCAL_BASE) && !it.startsWith("content://") })
                val title = (if (live != null) lw?.title else t.pendingTitle).orEmpty()
                arr.put(
                    JSONObject()
                        .put("url", url ?: "")
                        .put("title", title)
                        .put("home", url == null)
                        .put("desktop", t.desktop)
                        .put("group", t.groupId)
                )
            }
            val gs = JSONArray()
            for (g in groups) {
                gs.put(
                    JSONObject().put("id", g.id).put("name", g.name)
                        .put("color", g.color).put("collapsed", g.collapsed)
                )
            }
            val root = JSONObject()
                .put("tabs", arr)
                .put("groups", gs)
                .put("cur", (current?.let { saved.indexOf(it) } ?: 0).coerceAtLeast(0))
                .put("nextGid", nextGroupId)
            prefs.setSavedTabsFor(windowNo, root.toString())
        } catch (e: Exception) {
            // 저장 실패는 무시
        }
    }

    /** 저장된 탭을 되살린다. 선택한 탭만 바로 불러오고 나머지는 선택할 때 불러온다. 복원한 탭이 있으면 true. */
    private fun restoreTabs(): Boolean {
        val raw = prefs.savedTabsFor(windowNo) ?: return false
        return try {
            val root = JSONObject(raw)
            val arr = root.getJSONArray("tabs")
            if (arr.length() == 0) return false
            val gs = root.optJSONArray("groups")
            if (gs != null) {
                for (i in 0 until gs.length()) {
                    val g = gs.getJSONObject(i)
                    groups.add(TabGroup(g.getInt("id"), g.getString("name"), g.getInt("color"), g.optBoolean("collapsed", false)))
                }
            }
            nextGroupId = maxOf(root.optInt("nextGid", 1), (groups.maxOfOrNull { it.id } ?: 0) + 1)
            for (i in 0 until minOf(arr.length(), 40)) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url").takeIf { it.isNotEmpty() }
                val home = o.optBoolean("home", false) || url == null
                val tab = createTab(null, select = false, home = home, lazy = true)
                val gid = o.optInt("group", 0)
                tab.groupId = if (groups.any { it.id == gid }) gid else 0
                if (!home) {
                    tab.pendingUrl = url
                    tab.pendingTitle = o.optString("title").takeIf { it.isNotBlank() }
                }
            }
            val idx = root.optInt("cur", 0).coerceIn(0, tabs.size - 1)
            selectTab(tabs[idx])
            pruneEmptyGroups()
            true
        } catch (e: Exception) {
            // 일부만 만들어졌더라도 있는 탭으로 시작
            if (tabs.isNotEmpty()) {
                if (current == null) selectTab(tabs[0])
                true
            } else false
        }
    }

    /** 탭 제목: 불러온 페이지 제목 → (복원만 된 탭이면) 저장해 둔 제목/주소 → "새 탭" */
    private fun tabTitle(tab: BrowserTab): String {
        // 홈(새 탭)이거나 빈 페이지면 WebView 가 돌려주는 "about:blank" 제목을 쓰지 않는다
        if (tab.isHome) return if (tab.incognito) "시크릿 탭" else "새 탭"
        val lw = tab.liveWebView
        val blank = lw?.url == "about:blank" || lw?.url == HOME_URL
        return lw?.title?.takeIf { it.isNotBlank() && !blank && it != "about:blank" }
            ?: tab.pendingTitle
            ?: tab.pendingUrl?.let { runCatching { Uri.parse(it).host }.getOrNull() }
            ?: "새 탭"
    }

    private fun homeUrl(): String = prefs.currentEngine().homeUrl

    // ───────────────────────── 로딩 속도 ─────────────────────────

    private val docStartScripts: Boolean by lazy {
        WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
    }

    /** 새 탭을 바로 열 수 있도록 미리 만들어 둔 빈 웹뷰 한 개 (화면이 한가할 때 만든다) */
    private var spareWebView: WebView? = null

    private fun prepareSpareWebView() {
        if (spareWebView != null) return
        Looper.myQueue().addIdleHandler {
            if (spareWebView == null && !isFinishing && !isDestroyed) {
                spareWebView = NestedWebView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            }
            false
        }
    }

    private val dnsWarm: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** 곧 열 가능성이 높은 주소(입력한 주소, 첫 자동완성 등)의 도메인 조회를 미리 해 둔다 */
    private fun prefetchDns(url: String?) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return
        val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return
        if (dnsWarm.size > 300) dnsWarm.clear()
        if (!dnsWarm.add(host)) return
        // 조회가 오래 걸려도 다른 백그라운드 작업(기록 저장, 자동완성)을 막지 않게 별도 스레드에서
        Thread {
            try {
                java.net.InetAddress.getAllByName(host)
            } catch (e: Exception) {
                dnsWarm.remove(host)
            }
        }.apply { isDaemon = true }.start()
    }

    // ───────────────────────── 시크릿 탭 ─────────────────────────

    private val incognitoProfileName = "incognito"
    private var incognitoWarned = false

    private val profilesSupported: Boolean by lazy {
        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
    }

    /** 시크릿 전용 프로필에 붙은 웹뷰. 프로필이 쿠키·캐시·저장소를 따로 들고 있다. 지원하지 않는 기기면 기록만 남기지 않는다. */
    private fun newIncognitoWebView(): WebView {
        val wv = NestedWebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        if (profilesSupported) {
            try {
                androidx.webkit.WebViewCompat.setProfile(wv, incognitoProfileName)
            } catch (e: Exception) {
                warnNoIsolation()
            }
        } else {
            warnNoIsolation()
        }
        return wv
    }

    private fun warnNoIsolation() {
        if (incognitoWarned) return
        incognitoWarned = true
        toast("이 기기의 WebView는 쿠키 분리를 지원하지 않아 방문 기록만 남기지 않습니다")
    }

    /** 이 탭이 쓰는 쿠키 저장소 (시크릿이면 시크릿 프로필 것) */
    private fun cookieManagerFor(tab: BrowserTab?): CookieManager {
        if (tab?.incognito == true && profilesSupported) {
            try {
                return androidx.webkit.ProfileStore.getInstance()
                    .getOrCreateProfile(incognitoProfileName).cookieManager
            } catch (e: Exception) {
                // 아래 기본값
            }
        }
        return CookieManager.getInstance()
    }

    /** 시크릿 탭이 하나도 없으면 시크릿 프로필(쿠키·캐시·저장소)을 통째로 지운다. */
    private fun purgeIncognitoIfUnused(retry: Boolean = true) {
        if (!profilesSupported || tabs.any { it.incognito }) return
        try {
            androidx.webkit.ProfileStore.getInstance().deleteProfile(incognitoProfileName)
        } catch (e: Exception) {
            // 웹뷰가 아직 정리되는 중이면 잠시 뒤 한 번 더 시도한다
            if (retry) ui.postDelayed({ purgeIncognitoIfUnused(false) }, 800)
        }
    }

    /** 시크릿 탭이 보이는 동안에는 스크린샷·최근 앱 미리보기를 막는다 */
    private fun updateSecureFlag() {
        val secure = current?.incognito == true || (switcherOpen && tabs.any { it.incognito })
        if (secure) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }

    private var urlTextDefault: android.content.res.ColorStateList? = null
    private var urlHintDefault: android.content.res.ColorStateList? = null
    private val incognitoBarColor = 0xFF3C4043.toInt()
    private val incognitoTextColor = 0xFFE8EAED.toInt()

    /** 시크릿 탭이면 주소창을 어둡게, 아니면 원래대로 */
    private fun applyIncognitoUi(on: Boolean) {
        if (urlTextDefault == null) {
            urlTextDefault = urlBar.textColors
            urlHintDefault = urlBar.hintTextColors
        }
        urlBar.backgroundTintList = if (on) android.content.res.ColorStateList.valueOf(incognitoBarColor) else null
        urlBar.setTextColor(if (on) android.content.res.ColorStateList.valueOf(incognitoTextColor) else urlTextDefault)
        urlBar.setHintTextColor(if (on) android.content.res.ColorStateList.valueOf(0xFF9AA0A6.toInt()) else urlHintDefault)
        homeTagline.text = if (on) "시크릿 탭 · 방문 기록과 쿠키가 저장되지 않아요" else homeTaglineDefault
    }

    private fun createTab(
        url: String?,
        select: Boolean = true,
        opener: BrowserTab? = null,
        home: Boolean = false,
        incognito: Boolean = false,
        lazy: Boolean = false
    ): BrowserTab {
        // 시크릿 탭에서 연 링크·팝업도 시크릿으로 이어진다
        val incog = incognito || opener?.incognito == true
        val tab = BrowserTab()
        tab.incognito = incog
        tab.isHome = home
        if (prefs.desktopSite || opener?.desktop == true) tab.desktop = true
        tab.lazyInit = {
            tab.webView = if (incog) newIncognitoWebView()
            else spareWebView?.also { spareWebView = null } ?: NestedWebView(this)
            tab.webView.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            configure(tab)
            if (tab.desktop) applyUserAgent(tab.webView, true)
            // 새 탭은 홈 화면을 웹 기록의 첫 항목으로 가진다 → 첫 페이지에서 뒤로가기를 하면 홈으로 돌아온다
            if (home) tab.webView.loadDataWithBaseURL(HOME_URL, HOME_HTML, "text/html", "utf-8", HOME_URL)
        }
        if (!lazy) tab.webView
        // 링크/팝업으로 열린 탭은 연 탭 바로 옆에 두고, 같은 그룹에 넣는다.
        tab.opener = opener
        val at = if (opener != null) tabs.indexOf(opener) else -1
        if (opener != null && at >= 0) {
            if (!incog) tab.groupId = opener.groupId
            tabs.add(at + 1, tab)
        } else {
            tabs.add(tab)
        }
        if (select) selectTab(tab)
        if (url != null) {
            if (url.startsWith("content://")) {
                // 기기에 있는 HTML 파일: 내용을 직접 읽어 불러온다 (형식 정보가 없거나 권한이 사라져도 열리게)
                loadLocalHtml(tab, url)
            } else {
                prefetchDns(url)
                tab.webView.loadUrl(url)
            }
        }
        updateTabCount()
        prepareSpareWebView()
        return tab
    }

    /**
     * 기기의 HTML 파일(content://)을 탭에 연다.
     * 파일 내용을 읽어 가짜 https 주소(LOCAL_BASE)를 기준으로 불러오므로,
     * 파일 형식(MIME)이 text/plain 이어도 문서로 열리고, localStorage 같은 웹 저장소도 동작한다.
     */
    private fun loadLocalHtml(tab: BrowserTab, uriStr: String, mime: String = "text/html") {
        val uri = Uri.parse(uriStr)
        val name = localFileNames[uriStr] ?: queryFileName(uri) ?: uri.lastPathSegment ?: "file.html"
        localFileNames[uriStr] = name
        val wv = tab.webView
        Thread {
            val bytes = try {
                contentResolver.openInputStream(uri)?.use { it.readBytes() }
            } catch (e: Throwable) {
                null
            }
            ui.post {
                if (isFinishing || isDestroyed) return@post
                if (bytes == null || bytes.size > 40 * 1024 * 1024) {
                    toast(if (bytes == null) "파일을 열 수 없습니다" else "파일이 너무 커서 열 수 없습니다")
                    // 아무것도 못 불러온 빈 탭이 남지 않게 닫는다
                    if (tab in tabs && tab.webView.url.isNullOrEmpty() && tabs.size > 1) closeTab(tab)
                    return@post
                }
                // 기록용 주소(historyUrl)도 같게 줘야 일반 탭처럼 주소창·제목·새로고침·뒤로가기가 정상 동작한다
                val pageUrl = LOCAL_BASE + Uri.encode(name)
                wv.loadDataWithBaseURL(pageUrl, decodeHtmlBytes(bytes), mime, "UTF-8", pageUrl)
            }
        }.apply { isDaemon = true }.start()
    }

    /** HTML 바이트를 글자로 바꾼다: BOM → <meta charset> → UTF-8 순으로 인코딩을 정한다 */
    private fun decodeHtmlBytes(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        val head = String(b, 0, minOf(b.size, 2048), Charsets.ISO_8859_1)
        val cs = Regex("charset\\s*=\\s*[\"']?([A-Za-z0-9_\\-]+)", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        val charset = try { if (cs != null) java.nio.charset.Charset.forName(cs) else Charsets.UTF_8 } catch (e: Throwable) { Charsets.UTF_8 }
        return String(b, charset)
    }

    private fun selectTab(tab: BrowserTab) {
        val alreadyCurrent = current === tab
        if (!alreadyCurrent) closeFind()
        current?.let {
            // 탭 화면의 카드에 보여줄 미리보기를 남겨 둔다 (탭 화면이 열려 있을 땐 이미 찍어 둠)
            if (it !== tab && !switcherOpen) it.thumb = captureContent()
            webContainer.removeView(it.webView)
            // 다른 탭으로 옮겨도 이전 탭을 멈추지 않는다 (영상·소리·스크립트가 계속 동작)
            // 소리·영상이 나오는 중이면 화면 뒤의 보이지 않는 칸에 계속 붙여 둔다 (떼어 놓으면 멈추는 경우가 있다)
            if (it !== tab) parkIfPlaying(it)
        }
        current = tab
        scrollAcc = 0
        webContainer.reset()
        setBarsHidden(false)
        groupOf(tab)?.collapsed = false
        unparkWebView(tab)
        webContainer.addView(tab.webView)
        pageScrollBar.bind(if (tab.isHome) null else tab.webView)
        Motion.cancel(tab.webView)
        if (switcherOpen || alreadyCurrent) {
            // 탭 화면에서 고른 경우: 카드가 펼쳐지는 전환이 대신 보여주므로 여기선 바로 표시
            // 이미 보고 있는 탭을 다시 고른 경우: 페이드 없이 그대로 둔다
            tab.webView.alpha = 1f
            tab.webView.scaleX = 1f
            tab.webView.scaleY = 1f
        } else {
            tab.webView.alpha = 0f
            tab.webView.scaleX = 0.97f
            tab.webView.scaleY = 0.97f
            Motion.spring(tab.webView, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_X, 1f, 260f, 0.8f)
            Motion.spring(tab.webView, DynamicAnimation.SCALE_Y, 1f, 260f, 0.8f)
        }
        tab.pendingUrl?.let { u ->
            tab.pendingUrl = null
            tab.isHome = false
            tab.stoppedByHome = false
            // 다른 창에서 넘어온 탭은 웹 기록·스크롤·확대를 담은 상태로 되살린다 (실패하면 주소만 연다)
            val st = tab.pendingState
            tab.pendingState = null
            val restored = st != null && runCatching { tab.webView.restoreState(st) != null }.getOrDefault(false)
            if (restored) {
                tab.restoreScrollPending = tab.pendingScrollRatio >= 0f ||
                    tab.pendingScrollX != 0 || tab.pendingScrollY != 0
            } else {
                tab.restoreScrollPending = false
                tab.webView.loadUrl(u)
            }
        }
        tab.webView.onResume()
        tab.paused = false
        tab.webView.requestFocus()
        updateUi()
    }

    /**
     * @param quitIfLast 사용자가 직접 마지막 탭을 닫은 경우 true: 탭을 비운 뒤 앱을 끈다.
     *   (페이지 스크립트가 닫는 경우 등은 false 로 두어 앱이 갑자기 꺼지지 않게 한다)
     */
    private fun closeTab(tab: BrowserTab, quitIfLast: Boolean = false) {
        val wasLast = tabs.size == 1
        // 마지막 탭이 시크릿이면 일반 새 탭을 하나 만들어 두고 시크릿 탭을 닫는다
        if (tabs.size == 1 && tab.incognito) createTab(null, select = false, home = true)
        if (tabs.size == 1) {
            tab.groupId = 0
            pruneEmptyGroups()
            tab.isHome = true
            if (tab === current) pageScrollBar.bind(null)
            tab.redirectSources.clear()
            tab.thumb = null
            tab.mediaFrames.clear()
            onMediaChanged()
            tab.webView.stopLoading()
            tab.favicon = null
            tab.pendingUrl = null
            tab.pendingTitle = null
            // 이미 홈 항목이면 기록만 비운다. 아니면 홈을 불러오고, 다 불러와지면 기록을 비운다
            if (tab.webView.url == HOME_URL) tab.webView.clearHistory()
            else loadHome(tab, clear = true)
            updateUi()
            scheduleStripRefresh()
            if (quitIfLast && wasLast) finishAndRemoveTask()
            return
        }
        val index = tabs.indexOf(tab)
        tabs.remove(tab)
        tabs.forEach { if (it.opener === tab) it.opener = null }
        if (tab === current) {
            webContainer.removeView(tab.webView)
            current = null
            // 링크로 열린 탭을 닫으면 그 탭을 연 탭으로 돌아간다.
            val next = tab.opener?.takeIf { it in tabs } ?: tabs[minOf(index, tabs.size - 1)]
            selectTab(next)
        }
        tab.mediaFrames.clear()
        tab.lazyInit = null
        tab.liveWebView?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading(); it.destroy()
        }
        if (tab.incognito) purgeIncognitoIfUnused()
        pruneEmptyGroups()
        updateTabCount()
        onMediaChanged()
        if (quitIfLast && wasLast) finishAndRemoveTask()
    }

    private fun updateTabCount() {
        val n = tabs.size
        val text = if (n > 99) "99+" else n.toString()
        for (tv in listOf(tabCount, tabCountBottom, stripTabCount)) {
            if (tv.text.toString() != text) {
                tv.text = text
                // 자리수가 늘어나도 상자 안에 딱 맞도록 글자 크기 조절
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (n > 99) 8f else if (n >= 10) 10f else 12f)
                Motion.pop(tv)
            }
        }
        scheduleStripRefresh()
    }

    // ───────────────────────── 탭 그룹 ─────────────────────────

    private fun groupOf(tab: BrowserTab): TabGroup? =
        if (tab.groupId == 0) null else groups.firstOrNull { it.id == tab.groupId }

    private fun nextGroupColor(): Int = TabGroup.COLORS[groups.size % TabGroup.COLORS.size]

    private fun defaultGroupName(): String = "그룹 $nextGroupId"

    private fun createGroup(name: String, color: Int): TabGroup {
        val g = TabGroup(nextGroupId++, name, color)
        groups.add(g)
        return g
    }

    /** 탭이 하나도 없는 그룹은 자동으로 사라진다. */
    private fun pruneEmptyGroups() {
        groups.removeAll { g -> tabs.none { it.groupId == g.id } }
    }

    /** group == null 이면 그룹에서 빼낸다. 그룹으로 넣을 때는 그 그룹의 마지막 탭 바로 뒤로 옮겨 붙어 있게 한다. */
    private fun moveToGroup(tab: BrowserTab, group: TabGroup?) {
        if (tab.incognito && group != null) {
            toast("시크릿 탭은 그룹에 넣을 수 없어요")
            return
        }
        if (group == null) {
            tab.groupId = 0
        } else {
            val old = tabs.indexOf(tab)
            tabs.remove(tab)
            val last = tabs.indexOfLast { it.groupId == group.id }
            tab.groupId = group.id
            if (last >= 0) tabs.add(last + 1, tab) else tabs.add(old.coerceIn(0, tabs.size), tab)
        }
        pruneEmptyGroups()
    }

    private fun ungroup(group: TabGroup) {
        tabs.filter { it.groupId == group.id }.forEach { it.groupId = 0 }
        groups.remove(group)
    }

    private fun closeGroup(group: TabGroup) {
        tabs.filter { it.groupId == group.id }.forEach { closeTab(it) }
        pruneEmptyGroups()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** 그룹 만들기 / 편집 대화상자 (이름 + 색상). 위쪽 미리보기로 탭 줄에 보일 모습을 바로 확인한다. */
    private fun showGroupEditor(existing: TabGroup?, onSave: (String, Int) -> Unit) {
        val view = layoutInflater.inflate(R.layout.dialog_group, null)
        val et = view.findViewById<EditText>(R.id.etGroupName)
        val grid = view.findViewById<GridLayout>(R.id.colorGrid)
        val preview = view.findViewById<TextView>(R.id.groupPreview)
        var selected = existing?.color ?: nextGroupColor()
        et.setText(existing?.name ?: defaultGroupName())
        et.setSelection(et.text.length)

        fun updatePreview() {
            preview.text = et.text.toString().trim().ifEmpty { existing?.name ?: defaultGroupName() }
            preview.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(selected)
            }
        }

        fun renderColors(popColor: Int? = null) {
            grid.removeAllViews()
            TabGroup.COLORS.forEach { c ->
                val swatch = TextView(this)
                swatch.gravity = android.view.Gravity.CENTER
                swatch.textSize = 16f
                swatch.setTextColor(0xFFFFFFFF.toInt())
                swatch.contentDescription = "색상 선택"
                swatch.text = if (c == selected) "✓" else ""
                swatch.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                }
                swatch.layoutParams = GridLayout.LayoutParams().apply {
                    width = dp(40)
                    height = dp(40)
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                }
                swatch.setOnClickListener {
                    selected = c
                    renderColors(c)
                    updatePreview()
                }
                grid.addView(swatch)
                if (c == popColor) Motion.pop(swatch, 0.7f)
            }
        }
        renderColors()
        updatePreview()
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updatePreview() }
            override fun afterTextChanged(s: Editable?) {}
        })

        MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "새 그룹" else "그룹 편집")
            .setView(view)
            .setNegativeButton("취소", null)
            .setPositiveButton(if (existing == null) "만들기" else "저장") { _, _ ->
                val name = et.text.toString().trim().ifEmpty { existing?.name ?: defaultGroupName() }
                onSave(name, selected)
            }
            .show()
    }

    /** 북마크할 수 있는 탭의 웹 주소 (홈 화면이거나 웹페이지가 아니면 null). 아직 불러오지 않은 복원 탭은 저장된 주소를 쓴다. */
    private fun tabBookmarkUrl(tab: BrowserTab): String? {
        if (tab.isHome) return null
        val u = tab.liveWebView?.url ?: tab.pendingUrl
        return u?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    /**
     * 화면에 보이는 순서대로 한 덩어리씩 센다: 그룹에 속하지 않은 탭 하나, 또는 그룹 하나(안의 탭들).
     * 그룹에 속한 탭은 그룹 안에서만, 그룹 밖의 탭은 덩어리(탭/그룹 상자) 단위로 움직인다.
     */
    private fun tabUnits(): List<List<BrowserTab>> {
        val units = ArrayList<List<BrowserTab>>()
        val seen = HashSet<Int>()
        for (t in tabs) {
            val g = groupOf(t)
            if (g == null) units.add(listOf(t))
            else if (seen.add(g.id)) units.add(tabs.filter { it.groupId == g.id })
        }
        return units
    }

    /** 탭을 앞(-1)/뒤(+1)로 한 칸 옮긴다 (데이터만). 그룹 안의 탭은 그룹 안에서, 그룹에 없는 탭은 그룹 덩어리를 통째로 건너뛴다. */
    private fun reorderTab(tab: BrowserTab, dir: Int) {
        val g = groupOf(tab)
        if (g != null) {
            val m = tabs.filter { it.groupId == g.id }
            val other = m.getOrNull(m.indexOf(tab) + dir) ?: return
            val i = tabs.indexOf(tab)
            val j = tabs.indexOf(other)
            tabs[i] = other
            tabs[j] = tab
        } else {
            val units = tabUnits()
            val u = units.indexOfFirst { it.size == 1 && it[0] === tab && groupOf(it[0]) == null }
            if (u < 0) return
            val neighbor = units.getOrNull(u + dir) ?: return
            tabs.remove(tab)
            if (dir < 0) tabs.add(tabs.indexOf(neighbor.first()), tab)
            else tabs.add(tabs.indexOf(neighbor.last()) + 1, tab)
        }
    }

    // ───────────────────────── 끌어서 탭 순서 바꾸기 ─────────────────────────

    /**
     * 길게 눌러 끌기 공통 터치 처리.
     * 길게 누르면 끌기가 시작되고(onStart 가 true), 손가락을 움직이는 동안 onMove, 떼면 onEnd 가 불린다.
     * 끌지 않고 그냥 뗐으면 onEnd 의 moved 가 false 라서 호출한 쪽이 메뉴를 띄우면 된다.
     * pressedScale 이 있으면 누르는 동안 카드가 쏙 들어가는 효과도 같이 준다.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun bindDragGesture(
        v: View,
        pressedScale: Float?,
        onStart: (rawX: Float, rawY: Float) -> Boolean,
        onMove: (rawX: Float, rawY: Float) -> Unit,
        onEnd: (moved: Boolean, canceled: Boolean) -> Unit,
        // 옆으로 밀어서 치우는 동작 (주면 켜진다). 충분히 밀거나 빠르게 튕기면 불리고, 아니면 제자리로 돌아온다.
        onSwipeDismiss: (() -> Unit)? = null,
        canSwipe: () -> Boolean = { true }
    ) {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        var dragging = false
        var moved = false
        var swiping = false
        var crossed = false
        var vt: android.view.VelocityTracker? = null
        var downX = 0f
        var downY = 0f
        var lastX = 0f
        var lastY = 0f

        fun releaseTracker() {
            vt?.recycle()
            vt = null
        }
        // 놓았을 때 제자리로: 손가락 속도를 이어받아 살짝 튕기며 돌아온다
        fun springBack(view: View, vx: Float = 0f) {
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.7f)
                .setStartVelocity(vx)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, 0f, 420f, 0.7f)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 500f, 1f)
        }
        // 놓았을 때 치우기: 손가락이 움직이던 속도 그대로 날아가며 투명해지고, 거의 사라지면 목록을 다시 그려 빈자리를 메운다
        fun flyOff(view: View, dir: Float, vx: Float) {
            val w = view.width.toFloat().coerceAtLeast(1f)
            if (!Motion.enabled(view.context)) {
                onSwipeDismiss?.invoke()
                return
            }
            var fired = false
            fun fire() {
                if (fired) return
                fired = true
                onSwipeDismiss?.invoke()
            }
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, dir * w * 1.5f, 320f, 1f) { fire() }
                .setStartVelocity(vx)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, dir * 12f, 260f, 1f)
            Motion.spring(view, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 0f, 520f, 1f) { fire() }
        }
        fun finishSwipe(view: View, dx: Float, vx: Float) {
            val w = view.width.toFloat().coerceAtLeast(1f)
            val sameDir = vx * dx > 0f
            val flung = sameDir && Math.abs(vx) > 1200f && Math.abs(dx) > w * 0.1f
            if (Math.abs(dx) > w * 0.4f || flung) {
                flyOff(view, if (dx > 0) 1f else -1f, vx)
            } else {
                springBack(view, vx)
            }
        }

        val handler: (View, MotionEvent) -> Boolean = { view, e ->
            lastX = e.rawX
            lastY = e.rawY
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    moved = false
                    swiping = false
                    crossed = false
                    downX = e.rawX
                    downY = e.rawY
                    if (onSwipeDismiss != null) {
                        releaseTracker()
                        vt = android.view.VelocityTracker.obtain().also { it.addMovement(e) }
                    }
                    false
                }
                MotionEvent.ACTION_MOVE -> when {
                    dragging -> {
                        if (!moved && Math.hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > slop) moved = true
                        onMove(e.rawX, e.rawY)
                        true
                    }
                    onSwipeDismiss != null -> {
                        vt?.addMovement(e)
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        // 가로로 뚜렷하게 움직일 때만 밀기로 본다 (세로 스크롤과 구분)
                        if (!swiping && canSwipe() && Math.abs(dx) > slop * 2 && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            swiping = true
                            view.cancelLongPress()
                            view.isPressed = false
                            view.parent?.requestDisallowInterceptTouchEvent(true)
                            // 이전에 돌던 이동/투명도 스프링을 멈추고 손가락이 직접 움직이게 한다 (크기는 눌린 상태 유지)
                            Motion.cancel(view)
                            view.scaleX = pressedScale ?: 1f
                            view.scaleY = pressedScale ?: 1f
                        }
                        if (swiping) {
                            val w = view.width.toFloat().coerceAtLeast(1f)
                            view.translationX = dx
                            // 밀수록 살짝 기울고 옅어진다
                            view.rotation = (dx / w * 10f).coerceIn(-12f, 12f)
                            view.alpha = (1f - Math.abs(dx) / (w * 1.2f)).coerceIn(0.2f, 1f)
                            val past = Math.abs(dx) > view.width * 0.4f
                            if (past != crossed) {
                                crossed = past
                                view.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                            }
                            true
                        } else false
                    }
                    else -> false
                }
                MotionEvent.ACTION_UP -> when {
                    dragging -> {
                        dragging = false
                        view.isPressed = false
                        onEnd(moved, false)
                        true
                    }
                    swiping -> {
                        swiping = false
                        vt?.let {
                            it.addMovement(e)
                            it.computeCurrentVelocity(1000)
                            finishSwipe(view, e.rawX - downX, it.xVelocity)
                        } ?: springBack(view)
                        releaseTracker()
                        true
                    }
                    else -> {
                        releaseTracker()
                        false
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        onEnd(moved, true)
                    }
                    if (swiping) {
                        swiping = false
                        springBack(view)
                    }
                    releaseTracker()
                    false
                }
                else -> false
            }
        }
        v.setOnLongClickListener { view ->
            dragging = onStart(lastX, lastY)
            if (dragging) {
                view.isPressed = false
                // 끄는 동안 스크롤 뷰가 터치를 가로채지 않게 한다
                view.parent?.requestDisallowInterceptTouchEvent(true)
            }
            true
        }
        if (pressedScale != null) Motion.pressable(v, pressedScale, handler)
        else v.setOnTouchListener { view, e -> handler(view, e) }
    }

    // ── 상단 탭 줄 (가로) ──

    private var stripDrag: StripChip? = null
    private var stripGrab = 0f
    private var stripRawX = 0f
    private var stripSwapped = false

    // 탭을 탭 줄 밖(위/아래)으로 끌어내면 새 창으로 열린다
    private var stripRawY = 0f
    private var stripCanDetach = false
    private var stripDetached = false
    private var stripGhost: View? = null

    /** 끌고 있는 탭이 줄의 양 끝에 가까워지면 탭 줄이 알아서 그쪽으로 스크롤된다 */
    private val stripAutoScroll = object : Runnable {
        override fun run() {
            if (stripDrag == null) return
            val loc = IntArray(2)
            tabStripScroll.getLocationOnScreen(loc)
            val rel = stripRawX - loc[0]
            val edge = dp(56).toFloat()
            val w = tabStripScroll.width
            val dx = when {
                rel < edge -> -(edge - rel) / edge * dp(14)
                rel > w - edge -> (rel - (w - edge)) / edge * dp(14)
                else -> 0f
            }
            if (dx != 0f) {
                val step = if (dx > 0) maxOf(1, dx.toInt()) else minOf(-1, dx.toInt())
                val before = tabStripScroll.scrollX
                tabStripScroll.scrollBy(step, 0)
                if (tabStripScroll.scrollX != before) updateStripDrag()
            }
            tabStripScroll.postOnAnimation(this)
        }
    }

    private val stripClipSaved = ArrayList<Pair<ViewGroup, Boolean>>()

    /** 끄는 동안 탭 줄과 그 바깥 레이아웃의 '자식 영역 밖 잘라내기'를 풀어, 끄는 탭이 가장자리에서 잘리지 않게 한다 */
    private fun setStripUnclipped(unclipped: Boolean) {
        if (unclipped) {
            var p: android.view.ViewParent? = tabStrip
            while (p is ViewGroup) {
                stripClipSaved.add(p to p.clipChildren)
                p.clipChildren = false
                p = p.parent
            }
        } else {
            stripClipSaved.forEach { (g, old) -> g.clipChildren = old }
            stripClipSaved.clear()
        }
    }

    private fun startStripDrag(tab: BrowserTab, rawX: Float, rawY: Float): Boolean {
        val c = stripChips[tab] ?: return false
        if (stripDrag != null) return false
        stripDrag = c
        stripSwapped = false
        stripRawX = rawX
        stripRawY = rawY
        // 설정에서 껐거나 시크릿 탭이면 새 창으로 끌어낼 수 없다 (새 탭 화면은 새 탭 화면 그대로 새 창으로 간다)
        stripCanDetach = prefs.dragTabToWindow && !tab.incognito
        stripDetached = false
        val loc = IntArray(2)
        tabStrip.getLocationOnScreen(loc)
        stripGrab = rawX - loc[0] - c.view.left
        c.view.translationZ = dp(5).toFloat()
        // 탭 줄을 올리지 않는다: 툴바가 탭 줄 위에 그려져서 끄는 탭의 그림자가 탭 줄 아래(툴바 쪽)로 번지지 않는다
        c.bg?.alpha = 255 // 선택되지 않은 탭도 끄는 동안은 카드처럼 보이게
        setStripUnclipped(true)
        tabStripScroll.postOnAnimation(stripAutoScroll)
        return true
    }

    /** 끌고 있는 탭이 손가락을 따라가는 위치 (탭 줄 안쪽으로 제한) */
    private fun stripDragWant(c: StripChip): Float {
        val maxLeft = (tabStrip.width - c.view.width).coerceAtLeast(0)
        return stripDragRaw().coerceIn(0f, maxLeft.toFloat())
    }

    /** 손가락 위치만으로 계산한 탭의 왼쪽 위치 (탭 줄 밖으로 나가도 제한하지 않음) */
    private fun stripDragRaw(): Float {
        val loc = IntArray(2)
        tabStrip.getLocationOnScreen(loc)
        return stripRawX - loc[0] - stripGrab
    }

    /** dir 쪽으로 이웃한 덩어리(탭 하나, 또는 그룹 알약 + 그 탭들)의 뷰들 */
    private fun stripNeighbor(tab: BrowserTab, dir: Int): List<View>? {
        val g = groupOf(tab)
        if (g != null) {
            val m = tabs.filter { it.groupId == g.id }
            val n = m.getOrNull(m.indexOf(tab) + dir) ?: return null
            return stripChips[n]?.view?.let { listOf(it) }
        }
        val units = tabUnits()
        val u = units.indexOfFirst { it.size == 1 && it[0] === tab && groupOf(it[0]) == null }
        if (u < 0) return null
        val unit = units.getOrNull(u + dir) ?: return null
        val g2 = groupOf(unit[0])
        val views = ArrayList<View>()
        if (g2 != null) stripPills[g2.id]?.let { views.add(it) }
        if (g2 == null || !g2.collapsed) unit.forEach { t -> stripChips[t]?.view?.let { views.add(it) } }
        return views.takeIf { it.isNotEmpty() }
    }

    private fun stripDesiredOrder(): List<View> {
        val out = ArrayList<View>()
        val seen = HashSet<Int>()
        for (t in tabs) {
            val g = groupOf(t)
            if (g != null && seen.add(g.id)) stripPills[g.id]?.let { out.add(it) }
            if (g != null && g.collapsed) continue
            stripChips[t]?.view?.let { out.add(it) }
        }
        return out
    }

    private fun updateStripDrag() {
        val c = stripDrag ?: return
        if (stripChips[c.tab] !== c || c.view.parent == null) {
            stripDrag = null
            return
        }
        val v = c.view
        val want = stripDragWant(c)
        v.translationX = want - v.left
        // 탭 줄에서 충분히 벗어나면 "새 창으로 열기" 상태: 순서 바꾸기는 멈추고 손가락을 따라다니는 미리보기를 보여 준다
        if (stripCanDetach) {
            val sl = IntArray(2)
            tabStripScroll.getLocationOnScreen(sl)
            val m = dp(40)
            // 세로로 탭 줄을 벗어났거나, 창이 좌우로 나란히 있을 때 손가락이 이 창의 옆 가장자리를 넘어
            // 다른 창으로 넘어갔으면 "밖"이다. (옆 창의 탭 줄은 같은 높이라 세로만 보면 영영 안 벗어난다)
            val dl = IntArray(2)
            window.decorView.getLocationOnScreen(dl)
            val sideM = dp(12)
            val outsideSide = stripRawX < dl[0] - sideM || stripRawX > dl[0] + window.decorView.width + sideM
            // 주소창 위로 올라오면 탭 줄과 가까워도 바로 '밖'으로 본다 (주소창에 놓을 수 있게)
            var overAddr = false
            if (urlBar.isShown) {
                val ul = IntArray(2)
                urlBar.getLocationOnScreen(ul)
                overAddr = stripRawX >= ul[0] && stripRawX <= ul[0] + urlBar.width &&
                    stripRawY >= ul[1] && stripRawY <= ul[1] + urlBar.height
            }
            val outside = outsideSide || overAddr || stripRawY > sl[1] + tabStripScroll.height + m || stripRawY < sl[1] - m
            if (outside != stripDetached) {
                stripDetached = outside
                v.performHapticFeedback(
                    if (outside && Build.VERSION.SDK_INT >= 23) android.view.HapticFeedbackConstants.CONTEXT_CLICK
                    else android.view.HapticFeedbackConstants.CLOCK_TICK
                )
                // 원래 탭은 빈 자리처럼 흐려지고 조금 작아진다
                val sc = if (outside) 0.9f else 1f
                v.animate().alpha(if (outside) 0.3f else 1f).scaleX(sc).scaleY(sc).setDuration(160).start()
                if (outside) {
                    // 시스템 드래그로 바꿔 카드가 앱 밖에서도 보이게 한다. 안 되는 기기에서는 예전처럼 창 안 카드
                    if (!beginSystemDrag(c)) showStripGhost(c.tab, c.icon.drawable)
                } else removeStripGhost()
            }
            if (stripDetached) {
                moveStripGhost()
                return
            }
        }
        // 순서를 바꿀지는 제한하기 전의 손가락 위치로 판단한다.
        // (제한한 위치로 보면 맨 앞/맨 뒤 탭과는 중심이 절대 넘어가지 못해 첫 번째 자리로 옮길 수 없었다)
        val cx = stripDragRaw() + v.width / 2f
        var dir = 0
        stripNeighbor(c.tab, 1)?.last()?.let { e ->
            if (e.parent != null && cx > e.left + e.width / 2f) dir = 1
        }
        if (dir == 0) {
            stripNeighbor(c.tab, -1)?.first()?.let { e ->
                if (e.parent != null && cx < e.left + e.width / 2f) dir = -1
            }
        }
        if (dir != 0) swapStripDrag(c, dir)
    }

    /** 데이터 순서를 바꾸고, 끌고 있는 뷰는 그대로 둔 채 나머지 뷰들만 새 순서로 다시 끼운다 (이웃 탭은 미끄러지듯 자리를 옮긴다) */
    private fun swapStripDrag(c: StripChip, dir: Int) {
        val v = c.view
        val oldLeft = HashMap<View, Int>()
        for (i in 0 until tabStrip.childCount) {
            val ch = tabStrip.getChildAt(i)
            if (ch !== v) oldLeft[ch] = ch.left
        }
        reorderTab(c.tab, dir)
        stripSwapped = true
        val desired = stripDesiredOrder()
        val di = desired.indexOf(v)
        if (di < 0) return
        val others = desired.filter { it !== v }
        others.forEach { tabStrip.removeView(it) }
        var at = tabStrip.indexOfChild(v)
        for (i in 0 until di) {
            tabStrip.addView(desired[i], at)
            at++
        }
        var after = at + 1
        for (i in di + 1 until desired.size) {
            tabStrip.addView(desired[i], after)
            after++
        }
        tabStrip.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                tabStrip.viewTreeObserver.removeOnPreDrawListener(this)
                others.forEach { ov ->
                    val o = oldLeft[ov] ?: return@forEach
                    val dx = o - ov.left
                    if (dx != 0) {
                        ov.animate().cancel()
                        ov.translationX = dx + ov.translationX
                        ov.animate().translationX(0f).setDuration(180).setInterpolator(stripEase).start()
                    }
                }
                if (stripDrag === c) v.translationX = stripDragWant(c) - v.left
                return true
            }
        })
    }

    /**
     * 끄는 탭을 따라다니는 카드 (창 맨 위에 그려서 탭 줄 밖에서도 보인다).
     * 파비콘 + 제목 + "놓으면 새 창으로 열려요" 안내. 나타날 때 통통 튀며 커지고, 움직이는 방향으로 살짝 기운다.
     */
    private fun showStripGhost(tab: BrowserTab, favicon: android.graphics.drawable.Drawable?) {
        removeStripGhost(animate = false)
        val g = buildStripGhostView(tab, favicon)
        stripGhostLastX = stripRawX
        (window.decorView as ViewGroup).addView(g, FrameLayout.LayoutParams(stripGhostW, stripGhostH))
        stripGhost = g
        moveStripGhost()
        // 나타나기: 작게 시작해 통통 튀며 커진다
        if (Motion.enabled(this)) {
            g.alpha = 0f
            g.scaleX = 0.7f
            g.scaleY = 0.7f
            Motion.spring(g, DynamicAnimation.SCALE_X, 1f, 520f, 0.55f)
            Motion.spring(g, DynamicAnimation.SCALE_Y, 1f, 520f, 0.55f)
            Motion.spring(g, DynamicAnimation.ALPHA, 1f, 700f, 1f)
        }
    }

    /**
     * 끄는 카드 모양을 만들어 크기를 재 둔다. 창 안 카드와 시스템 드래그 카드가 같이 쓴다.
     * 위: 파비콘 + 제목 / 가운데: 페이지 미리보기 / 아래: "팝업 창으로 열기" 안내 알약.
     * 시스템 드래그 그림자는 비트맵이라 elevation 그림자가 안 그려지므로, 바깥 여백에 그림자를 직접 그린다.
     */
    private fun buildStripGhostView(tab: BrowserTab, favicon: android.graphics.drawable.Drawable?): View {
        val title = (tab.liveWebView?.title?.takeIf { it.isNotBlank() } ?: tab.pendingTitle?.takeIf { it.isNotBlank() }
            ?: tabBookmarkUrl(tab)?.let { runCatching { Uri.parse(it).host }.getOrNull() }).orEmpty()
            .ifBlank { if (tab.isHome) "새 탭" else "" }
        fun attr(a: Int, def: Int) = com.google.android.material.color.MaterialColors.getColor(tabStrip, a, def)
        val surface = attr(com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFF202124.toInt())
        val accent = attr(com.google.android.material.R.attr.colorPrimary, 0xFF1A73E8.toInt())
        val onAccent = attr(com.google.android.material.R.attr.colorOnPrimary, 0xFFFFFFFF.toInt())
        val thumbBg = attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFFEDEDED.toInt())
        val outline = attr(com.google.android.material.R.attr.colorOutlineVariant, 0x33000000)

        val cardW = dp(208)
        val thumbH = dp(112)
        val pad = dp(10)
        val shadowPad = dp(22) // 그림자·기울임이 잘리지 않게 카드 바깥에 둔 여백
        stripGhostPad = shadowPad
        stripGhostSurface = surface

        val icon = ImageView(this).apply {
            val d = favicon?.constantState?.newDrawable()?.mutate()
            if (d != null) setImageDrawable(d) else {
                setImageResource(R.drawable.ic_tab)
                setColorFilter(onSurface)
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            background = GradientDrawable().apply { cornerRadius = dp(5).toFloat(); setColor(0x00000000) }
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        val titleTv = TextView(this).apply {
            text = title
            setTextColor(onSurface)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(icon, LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) })
            addView(titleTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        // 페이지 미리보기 (위쪽 기준으로 꽉 채움). 없으면 파비콘을 크게
        val shot: Bitmap? = (if (current === tab) captureContent() else null) ?: tab.thumb
        val thumbRadius = dp(10).toFloat()
        val thumb = ImageView(this).apply {
            background = GradientDrawable().apply { cornerRadius = thumbRadius; setColor(thumbBg) }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            if (shot != null) {
                scaleType = ImageView.ScaleType.MATRIX
                setImageBitmap(shot)
                imageMatrix = topCropMatrix(shot, cardW - pad * 2, thumbH)
            } else {
                scaleType = ImageView.ScaleType.CENTER
                val d = favicon?.constantState?.newDrawable()?.mutate()
                if (d != null) setImageDrawable(d) else {
                    setImageResource(R.drawable.ic_tab)
                    setColorFilter(onSurface and 0x00FFFFFF or 0x66000000)
                }
            }
        }

        val hintTv = TextView(this).apply {
            text = "놓으면 새 창으로 열려요"
            setTextColor(onAccent)
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(accent) }
        }

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(header, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(22)))
            addView(thumb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, thumbH).apply { topMargin = dp(8) })
            addView(hintTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10); gravity = Gravity.CENTER_HORIZONTAL
            })
            background = GradientDrawable().apply {
                setColor(surface)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), outline)
            }
        }

        val g = object : FrameLayout(this) {
            private val sp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = surface
                setShadowLayer(dp(14).toFloat(), 0f, dp(6).toFloat(), 0x55000000)
            }
            private val r = RectF()

            override fun dispatchDraw(canvas: Canvas) {
                r.set(shadowPad.toFloat(), shadowPad.toFloat(), (width - shadowPad).toFloat(), (height - shadowPad).toFloat())
                canvas.drawRoundRect(r, dp(18).toFloat(), dp(18).toFloat(), sp)
                super.dispatchDraw(canvas)
            }
        }.apply {
            setWillNotDraw(false)
            setLayerType(View.LAYER_TYPE_SOFTWARE, null) // setShadowLayer 는 소프트웨어 그리기에서 확실히 동작
            setPadding(shadowPad, shadowPad, shadowPad, shadowPad)
            addView(body, FrameLayout.LayoutParams(cardW, FrameLayout.LayoutParams.WRAP_CONTENT))
        }
        g.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        stripGhostW = g.measuredWidth
        stripGhostH = g.measuredHeight
        return g
    }

    private var stripGhostPad = 0
    private var stripGhostSurface = 0xFFFFFFFF.toInt()
    private var stripGhostW = 0
    private var stripGhostH = 0
    private var stripGhostLastX = 0f

    private fun moveStripGhost() {
        val g = stripGhost ?: return
        val dl = IntArray(2)
        window.decorView.getLocationOnScreen(dl)
        // 손가락 바로 위에 띄운다 (손가락에 가리지 않게)
        g.x = stripRawX - dl[0] - stripGhostW / 2f
        g.y = stripRawY - dl[1] - stripGhostH - dp(28)
        // 움직인 방향으로 살짝 기울고, 멈추면 천천히 바로 선다
        val dx = stripRawX - stripGhostLastX
        stripGhostLastX = stripRawX
        val target = (dx * 0.8f).coerceIn(-9f, 9f)
        g.rotation = g.rotation * 0.75f + target * 0.25f
    }

    /**
     * 카드를 치운다. [commit] 이면 새 창으로 열리는 중이라 커지며 사라지고,
     * 아니면(탭 줄로 돌아옴) 작아지며 사라진다.
     */
    private fun removeStripGhost(commit: Boolean = false, animate: Boolean = true) {
        val g = stripGhost ?: return
        stripGhost = null
        val parent = g.parent as? ViewGroup
        if (!animate || !Motion.enabled(this)) {
            parent?.removeView(g)
            return
        }
        Motion.cancel(g)
        val to = if (commit) 1.25f else 0.8f
        g.animate().alpha(0f).scaleX(to).scaleY(to).rotation(0f)
            .setDuration(if (commit) 240 else 150)
            .withEndAction { parent?.removeView(g) }
            .start()
    }

    private fun endStripDrag(moved: Boolean, canceled: Boolean) {
        // 시스템 드래그로 넘어가면 손가락 이벤트가 취소로 끝난다. 마무리는 드래그가 끝날 때 한다
        if (sysDragActive) return
        val c = stripDrag ?: return
        stripDrag = null
        val detach = stripDetached && !canceled
        stripDetached = false
        stripCanDetach = false
        removeStripGhost(commit = detach)
        tabStripScroll.removeCallbacks(stripAutoScroll)
        val v = c.view
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
        v.animate().translationX(0f).setDuration(160).setInterpolator(stripEase)
            .withEndAction {
                v.translationZ = 0f
                if (stripDrag == null) {
                    setStripUnclipped(false)
                }
            }.start()
        applyChipSelection(c)
        if (stripSwapped) saveTabs()
        scheduleStripRefresh()
        // 끌지 않고 그냥 뗐으면 예전처럼 탭 메뉴
        if (!canceled && !moved && !stripSwapped) showTabMenu(c.tab, c.view) { scheduleStripRefresh() }
        // 탭 줄 밖에서 놓았으면 이 탭을 새 창으로 옮긴다 (웹 기록·확대·스크롤이 따라간다)
        if (detach && moveTabToWindow(c.tab, null, closeEmptyWindow = true)) scheduleStripRefresh()
    }

    // ── 탭을 시스템 드래그로 끌어내기 (카드가 앱 밖에서도 보이고, 놓으면 팝업) ──

    private var sysDragActive = false
    private var sysDragOverlay: TabDropOverlay? = null
    private var sysDragZone = TabDropOverlay.ZONE_POPUP
    private var sysDragX = 0
    private var sysDragY = 0
    private var sysDropHandled = false
    private var sysDragMorph: SpringAnimation? = null
    private var sysDragMorphValue = 1f
    private var sysDragTilt = 0f
    private var sysDragShadow: View.DragShadowBuilder? = null
    private var sysDragLastX = Int.MIN_VALUE
    private var sysDragViewRef: View? = null

    private fun updateSysDragShadow(v: View) {
        val sh = sysDragShadow ?: return
        if (!sysDragActive || !v.isAttachedToWindow) {
            sysDragMorph?.cancel()
            return
        }
        try { v.updateDragShadow(sh) } catch (_: Throwable) { sysDragMorph?.cancel() }
    }

    /** 다른 창의 탭 줄에 놓였으면 그 창 (놓은 창이 알려 준다. 드래그가 끝날 때 이 창이 옮긴다) */
    private var sysDragTarget: MainActivity? = null

    /**
     * 탭 줄 밖으로 나간 탭을 시스템 드래그로 넘긴다. 시스템이 카드를 그려서 앱 창 밖에서도 보인다.
     * 드래그가 시작되면 이 창에는 놓을 곳을 알려 주는 투명 막을 얹는다. 시작하지 못하면 false (예전 방식으로 대신한다).
     */
    private fun beginSystemDrag(c: StripChip): Boolean {
        if (Build.VERSION.SDK_INT < 24 || sysDragActive) return false
        val url = tabBookmarkUrl(c.tab) ?: "새 탭"
        val card = buildStripGhostView(c.tab, c.icon.drawable)
        val w = card.measuredWidth
        val h = card.measuredHeight
        if (w <= 0 || h <= 0) return false
        card.layout(0, 0, w, h)
        val overlay = TabDropOverlay(this)
        val root = window.decorView as ViewGroup
        root.addView(
            overlay,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        overlay.setOnDragListener { v, e -> onStripSysDrag(v, e) }
        sysDragOverlay = overlay
        sysDragActive = true
        sysDropHandled = false
        sysDragZone = TabDropOverlay.ZONE_POPUP
        sysDragX = stripRawX.toInt()
        sysDragY = stripRawY.toInt()
        val lift = dp(28)
        val animate = Motion.enabled(this)
        val sp = stripGhostPad
        val chipW = c.view.width.coerceAtLeast(dp(96)).toFloat()
        val chipH = c.view.height.coerceAtLeast(dp(32)).toFloat()
        val innerW = (w - sp * 2).toFloat()
        val innerH = (h - sp * 2).toFloat()
        sysDragMorphValue = if (animate) 0f else 1f
        sysDragTilt = 0f
        val clipPath = android.graphics.Path()
        val clipRect = RectF()
        val shadowPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = stripGhostSurface }
        val shadow = object : View.DragShadowBuilder(card) {
            private fun m() = sysDragMorphValue
            private fun clipH() = chipH + (innerH - chipH) * m().coerceIn(0f, 1f)

            override fun onProvideShadowMetrics(outSize: android.graphics.Point, outTouch: android.graphics.Point) {
                outSize.set(w, h)
                // 처음엔 칩 한가운데가 손가락, 끝나면 손가락 바로 위에 카드가 뜬다 (손가락에 가리지 않게)
                val m = m()
                outTouch.set(w / 2, (sp + clipH() / 2 + (h / 2f + lift) * m).toInt())
            }

            override fun onDrawShadow(canvas: Canvas) {
                val m = m()
                val t = m.coerceIn(0f, 1f)
                val cw = chipW + (innerW - chipW) * t
                val ch = clipH()
                val cx = w / 2f
                val top = sp.toFloat()
                // 칩 모양 틀이 카드 크기로 펼쳐지며 내용이 드러난다 (모서리도 칩 → 카드로 부드럽게)
                clipRect.set(cx - cw / 2, top, cx + cw / 2, top + ch)
                val radius = dp(10) + (dp(18) - dp(10)) * t
                clipPath.reset()
                clipPath.addRoundRect(clipRect, radius.toFloat(), radius.toFloat(), android.graphics.Path.Direction.CW)
                // 스프링이 목표를 살짝 넘을 때는 전체가 아주 조금 커졌다 돌아온다
                val over = 1f + (m - 1f).coerceIn(0f, 0.25f) * 0.4f
                val px = cx
                val py = top + ch / 2
                canvas.save()
                canvas.rotate(sysDragTilt, w / 2f, h.toFloat())
                canvas.scale(over, over, px, py)
                // 그림자: 틀이 커지는 만큼 같이 커진다
                shadowPaint.setShadowLayer(dp(14) * (0.4f + 0.6f * t), 0f, dp(6) * (0.4f + 0.6f * t), (0x55 * (0.5f + 0.5f * t)).toInt() shl 24)
                canvas.drawRoundRect(clipRect, radius.toFloat(), radius.toFloat(), shadowPaint)
                canvas.clipPath(clipPath)
                // 카드 내용: 윗줄(파비콘+제목)은 처음부터 보이고, 미리보기·안내는 틀이 커지면서 드러난다
                canvas.save()
                card.draw(canvas)
                canvas.restore()
                canvas.restore()
            }
        }
        sysDragSource = this
        sysDragTarget = null
        // GLOBAL 이 없으면 시스템이 드래그 이벤트를 출발한 창에게만 주어서, 다른 창의 탭 줄은 아무것도 받지 못한다.
        // 그래서 다른 창이 떠 있을 때만 GLOBAL 을 켠다. (창이 하나뿐이면 예전처럼 켜지 않아,
        // 런처·멀티태스킹 UI 가 화면 가장자리에서 끼어들지 않는다)
        val hasOtherWindow = instances.any { it !== this && !it.isFinishing && !it.isDestroyed }
        val dragFlags = if (hasOtherWindow) View.DRAG_FLAG_OPAQUE or View.DRAG_FLAG_GLOBAL else View.DRAG_FLAG_OPAQUE
        val started = try {
            c.view.startDragAndDrop(
                stripDragClip(url),
                shadow,
                null,
                dragFlags
            )
        } catch (e: Throwable) {
            false
        }
        if (!started) {
            root.removeView(overlay)
            sysDragOverlay = null
            sysDragActive = false
            if (sysDragSource === this) sysDragSource = null
            return false
        }
        sysDragShadow = shadow
        sysDragViewRef = c.view
        if (animate) {
            sysDragMorph?.cancel()
            // 고정 시간 대신 스프링: 손가락으로 집어 올리는 것처럼 살짝 넘쳤다가 자리를 잡는다
            sysDragMorph = SpringAnimation(FloatValueHolder(0f)).apply {
                spring = SpringForce(1f).apply {
                    stiffness = 260f
                    dampingRatio = 0.58f
                }
                setStartVelocity(2.2f)
                setMinimumVisibleChange(0.002f)
                addUpdateListener { _, value, _ ->
                    sysDragMorphValue = value
                    updateSysDragShadow(c.view)
                }
                start()
            }
        }
        tabStripScroll.removeCallbacks(stripAutoScroll)
        return true
    }

    /**
     * 탭 끌기용 클립. 주소를 글자(text/plain)로 실어 보내면 삼성 분할 화면 UI 가 '링크'로 보고
     * 기본 브라우저(삼성 인터넷)로 열어 버린다 (새 탭 화면은 "새 탭" 글자가 그대로 열렸다).
     * 그래서 글자는 싣지 않고, 이 앱(MainActivity)을 새 창으로 여는 명시적 인텐트만 싣는다.
     * 라벨 "evergreen-tab" 은 다른 창의 탭 줄이 우리 드래그인지 알아볼 때 쓴다.
     */
    private fun stripDragClip(url: String): ClipData {
        val web = url.startsWith("http://") || url.startsWith("https://")
        val launch = Intent(this, MainActivity::class.java).apply {
            if (web) {
                action = Intent.ACTION_VIEW
                data = Uri.parse(url)
            }
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                    Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
            )
        }
        return ClipData(
            android.content.ClipDescription("evergreen-tab", arrayOf(android.content.ClipDescription.MIMETYPE_TEXT_INTENT)),
            ClipData.Item(launch)
        )
    }

    private fun onStripSysDrag(v: View, e: DragEvent): Boolean {
        if (!sysDragActive) return false
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED, DragEvent.ACTION_DRAG_ENTERED -> return true
            DragEvent.ACTION_DRAG_LOCATION -> {
                trackSysDrag(v, e)
                return true
            }
            DragEvent.ACTION_DRAG_EXITED -> {
                // 이 창 밖으로 나가면 (다른 앱/화면 위) 놓았을 때 팝업이다
                sysDragZone = TabDropOverlay.ZONE_POPUP
                sysDragOverlay?.setZone(TabDropOverlay.ZONE_POPUP)
                updateAddressDropHighlight()
                return true
            }
            DragEvent.ACTION_DROP -> {
                trackSysDrag(v, e)
                sysDropHandled = true
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                // 이 창에서 놓았으면 그 구역대로 / 다른 앱이 받아 갔으면 그대로 두고 / 아무도 안 받았으면 팝업
                val zone = when {
                    sysDropHandled -> sysDragZone
                    e.result -> TabDropOverlay.ZONE_NONE
                    else -> TabDropOverlay.ZONE_POPUP
                }
                val x = sysDragX
                val y = sysDragY
                val tgt = sysDragTarget
                sysDragTarget = null
                // 이벤트를 나눠 주는 도중에는 뷰를 떼지 않는다
                window.decorView.post { endStripSysDrag(zone, x, y, tgt) }
                return true
            }
        }
        return false
    }

    /** 놓을 곳 추적: 시스템 화면 좌표로 바꿔 어느 구역인지 정한다 */
    private fun trackSysDrag(v: View, e: DragEvent) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val sx = loc[0] + e.x.toInt()
        val sy = loc[1] + e.y.toInt()
        // 움직인 방향으로 카드가 살짝 기울고, 멈추면 천천히 바로 선다
        if (Motion.enabled(this)) {
            val dx = if (sysDragLastX == Int.MIN_VALUE) 0 else sx - sysDragLastX
            val target = (dx * 0.6f).coerceIn(-5f, 5f)
            val next = sysDragTilt * 0.8f + target * 0.2f
            if (Math.abs(next - sysDragTilt) > 0.05f || Math.abs(next) > 0.05f) {
                sysDragTilt = next
                if (sysDragMorph?.isRunning != true) sysDragViewRef?.let { updateSysDragShadow(it) }
            }
        }
        sysDragLastX = sx
        sysDragX = sx
        sysDragY = sy
        val z = sysZoneAt(sx, sy)
        if (z != sysDragZone) {
            sysDragZone = z
            sysDragOverlay?.setZone(z)
            updateAddressDropHighlight()
            v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    /** 탭을 주소창 위로 끌어 왔을 때 주소창이 살짝 흐려져 \"여기에 놓으면 된다\"고 알려 준다 */
    private fun updateAddressDropHighlight() {
        val on = sysDragActive && sysDragZone == TabDropOverlay.ZONE_ADDRESS
        val v = (urlBar.parent as? View) ?: urlBar
        v.animate().alpha(if (on) 0.55f else 1f).setDuration(120).start()
    }

    /** 탭을 주소창에 놓았다: 지금 보는 탭을 그 탭의 주소로 열고, 끌어 온 탭은 닫는다 (주소를 옮겨 온 셈) */
    private fun dropTabOnAddressBar(tab: BrowserTab) {
        if (tab === current) return
        val url = tabBookmarkUrl(tab)
        if (url == null) {
            toast("이 탭은 열 주소가 없어요")
            return
        }
        loadFromInput(url)
        closeTab(tab)
    }

    /** 탭 줄 위: 취소(제자리) / 그 밖: 팝업 */
    private fun sysZoneAt(sx: Int, sy: Int): Int {
        // 주소창 위에 있으면 (탭 줄 여유 범위와 겹쳐도) 주소창이 우선
        if (urlBar.isShown) {
            val ul = IntArray(2)
            urlBar.getLocationOnScreen(ul)
            val um = dp(6)
            if (sx >= ul[0] - um && sx <= ul[0] + urlBar.width + um &&
                sy >= ul[1] - um && sy <= ul[1] + urlBar.height + um) {
                return TabDropOverlay.ZONE_ADDRESS
            }
        }
        val sl = IntArray(2)
        tabStripScroll.getLocationOnScreen(sl)
        val m = dp(20)
        if (tabStripScroll.isShown && sy >= sl[1] - m && sy <= sl[1] + tabStripScroll.height + m) {
            return TabDropOverlay.ZONE_NONE
        }
        return TabDropOverlay.ZONE_POPUP
    }

    private fun endStripSysDrag(zone: Int, x: Int, y: Int, target: MainActivity? = null) {
        if (!sysDragActive) return
        sysDragActive = false
        sysDragMorph?.cancel()
        sysDragMorph = null
        sysDragShadow = null
        sysDragViewRef = null
        sysDragLastX = Int.MIN_VALUE
        if (sysDragSource === this) sysDragSource = null
        sysDropHandled = false
        sysDragOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        sysDragOverlay = null
        updateAddressDropHighlight()
        val c = stripDrag
        stripDrag = null
        stripDetached = false
        stripCanDetach = false
        tabStripScroll.removeCallbacks(stripAutoScroll)
        if (c != null) {
            val v = c.view
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
            v.animate().translationX(0f).setDuration(160).setInterpolator(stripEase)
                .withEndAction {
                    v.translationZ = 0f
                    if (stripDrag == null) setStripUnclipped(false)
                }.start()
            applyChipSelection(c)
        }
        if (stripSwapped) saveTabs()
        scheduleStripRefresh()
        if (c == null) return
        // 주소창에 놓았으면 지금 보는 탭이 그 탭의 주소로 바뀐다
        if (zone == TabDropOverlay.ZONE_ADDRESS && target == null) {
            dropTabOnAddressBar(c.tab)
            return
        }
        // 다른 창의 탭 줄에 놓았으면 그 창으로 옮긴다 (옮긴 탭은 그 창에서 바로 열린다)
        if (target != null) {
            if (moveTabToWindow(c.tab, target, selectInTarget = true)) scheduleStripRefresh()
            return
        }
        if (zone == TabDropOverlay.ZONE_NONE) return
        if (moveTabToWindow(c.tab, null, WIN_POPUP, x, y, closeEmptyWindow = true)) scheduleStripRefresh()
    }

    /** 다른 창에서 끌고 온 탭을 이 창의 탭 줄이 받는다 */
    private fun onStripReceiveDrag(v: View, e: DragEvent): Boolean {
        val src = sysDragSource
        val mine = src != null && src !== this && !isFinishing && !isDestroyed &&
            e.clipDescription?.label?.toString() == "evergreen-tab"
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED, DragEvent.ACTION_DRAG_LOCATION -> return mine
            DragEvent.ACTION_DRAG_ENTERED -> {
                if (mine) {
                    v.animate().alpha(0.7f).setDuration(120).start()
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                }
                return mine
            }
            DragEvent.ACTION_DRAG_EXITED -> {
                v.animate().alpha(1f).setDuration(120).start()
                return mine
            }
            DragEvent.ACTION_DROP -> {
                v.animate().alpha(1f).setDuration(120).start()
                if (!mine || src == null) return false
                src.sysDragTarget = this
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                v.animate().alpha(1f).setDuration(120).start()
                return true
            }
        }
        return false
    }

    // ── 다른 앱에서 끌어온 파일 → 새 탭 ──

    private var extDropOverlay: TabDropOverlay? = null
    /** 끌어 놓은 파일을 읽을 권한. 탭에서 파일을 읽는 동안(창이 닫힐 때까지) 붙들어 둔다 */
    private val extDropPerms = ArrayList<androidx.core.view.DragAndDropPermissionsCompat>()

    /**
     * 다른 앱이 끌고 온 '파일'인지. 시작할 때는 형식(MIME)만 보이므로, 일반 글자·링크(text/plain, text/html)와
     * 앱 실행용 드래그만 있는 경우는 제외한다. (이 창이 막으로 덮이면 웹페이지 입력칸에 글자를 끌어다 놓는 것이 안 되기 때문)
     */
    private fun acceptsExternalDrop(e: DragEvent): Boolean {
        if (sysDragActive) return false
        val d = e.clipDescription ?: return false
        if (d.label?.toString() == "evergreen-tab") return false
        for (i in 0 until d.mimeTypeCount) {
            val m = d.getMimeType(i).lowercase()
            if (m == "text/plain" || m == "text/html" || m == "text/uri-list" ||
                m.startsWith("text/vnd.android") || m.startsWith("application/vnd.android.")) continue
            return true
        }
        return false
    }

    private fun onExternalDragRoot(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                if (!acceptsExternalDrop(e)) return false
                showExtDropOverlay()
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                window.decorView.post { hideExtDropOverlay() }
                return false
            }
        }
        return false
    }

    /** 웹뷰가 드롭을 가로채지 못하게, 끌고 오는 동안만 창 전체에 투명한 막을 얹는다 */
    private fun showExtDropOverlay() {
        if (extDropOverlay != null || isFinishing || isDestroyed) return
        val ov = TabDropOverlay(this)
        ov.setOnDragListener { _, e -> onExternalFileDrag(e) }
        (window.decorView as ViewGroup).addView(
            ov, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        extDropOverlay = ov
    }

    private fun hideExtDropOverlay() {
        val ov = extDropOverlay ?: return
        extDropOverlay = null
        (ov.parent as? ViewGroup)?.removeView(ov)
    }

    private fun onExternalFileDrag(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED, DragEvent.ACTION_DRAG_ENTERED,
            DragEvent.ACTION_DRAG_LOCATION, DragEvent.ACTION_DRAG_EXITED -> return true
            DragEvent.ACTION_DROP -> {
                val cd = e.clipData ?: return false
                val uris = ArrayList<Pair<Uri, String?>>()
                for (i in 0 until cd.itemCount) {
                    val u = cd.getItemAt(i).uri ?: continue
                    val hint = if (i < cd.description.mimeTypeCount) cd.description.getMimeType(i) else null
                    uris.add(u to hint)
                }
                if (uris.isEmpty()) return false
                // 다른 앱의 파일을 읽으려면 놓는 순간에 권한을 받아 둬야 한다
                try {
                    androidx.core.app.ActivityCompat.requestDragAndDropPermissions(this, e)?.let { extDropPerms.add(it) }
                } catch (_: Throwable) {
                }
                uris.take(10).forEach { (u, hint) -> openDroppedFile(u, hint) }
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                window.decorView.post { hideExtDropOverlay() }
                return true
            }
        }
        return false
    }

    /** 끌어 온 파일 하나를 새 탭으로 연다. 웹뷰가 보여 줄 수 있는 형식만 연다 */
    private fun openDroppedFile(uri: Uri, hint: String?) {
        val s = uri.toString()
        val sc = uri.scheme?.lowercase()
        if (sc == "http" || sc == "https") { createTab(s); return }
        if (sc != "content") return
        val name = queryFileName(uri) ?: uri.lastPathSegment ?: "파일"
        localFileNames[s] = name
        val typeRaw: String? = try { contentResolver.getType(uri) } catch (_: Throwable) { null }
        val given = (typeRaw ?: hint)?.lowercase()
        val mime: String = if (given.isNullOrBlank() || given == "application/octet-stream" || given == "*/*") {
            val ext = name.substringAfterLast('.', "").lowercase()
            android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        } else given
        when {
            mime == "text/html" || mime == "application/xhtml+xml" -> createTab(s)
            mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/") -> {
                // 웹뷰가 content:// 주소를 직접 불러와 그림·영상·소리로 보여 준다
                val tab = createTab(null)
                tab.webView.loadUrl(s)
            }
            mime.startsWith("text/") || mime == "application/json" || mime == "application/xml" ||
                mime == "application/javascript" -> {
                val tab = createTab(null)
                loadLocalHtml(tab, s, "text/plain")
            }
            else -> toast("이 형식은 탭으로 열 수 없어요: $name")
        }
    }

    // ── 탭 화면 (카드 격자) ──

    private class SwitcherDrag(
        val tab: BrowserTab,
        val view: View,
        val scope: List<BrowserTab>,
        val from: Int,
        val slots: List<Rect>,   // 스크롤 내용 기준 좌표의 각 카드 자리
        val grabX: Float,        // 카드 왼쪽 위 모서리에서 손가락까지의 거리
        val grabY: Float,
        val boxes: Map<Int, Rect>  // 이 탭을 넣을 수 있는 그룹 상자들의 자리
    ) {
        var targetGroup = 0
        var to = from
        /** 손가락이 올라가 있는 창 칩 (null 이면 없음) / 그 칩이 가리키는 창 (null 이면 "＋ 새 창") */
        var winChip: View? = null
        var winTarget: MainActivity? = null
        var rawX = 0f
        var rawY = 0f
    }

    private var swDrag: SwitcherDrag? = null

    private val swAutoScroll = object : Runnable {
        override fun run() {
            val d = swDrag ?: return
            val loc = IntArray(2)
            tabScroll.getLocationOnScreen(loc)
            val top = loc[1]
            val bottom = top + tabScroll.height
            val edge = dp(80).toFloat()
            val dy = when {
                d.rawY < top + edge -> -(top + edge - d.rawY) / edge * dp(18)
                d.rawY > bottom - edge -> (d.rawY - (bottom - edge)) / edge * dp(18)
                else -> 0f
            }
            if (dy != 0f) {
                val step = if (dy > 0) maxOf(1, dy.toInt()) else minOf(-1, dy.toInt())
                val before = tabScroll.scrollY
                tabScroll.scrollBy(0, step)
                if (tabScroll.scrollY != before) updateSwitcherDrag()
            }
            tabScroll.postOnAnimation(this)
        }
    }

    /** 끄는 카드가 이웃 줄·상자 위에 그려지도록 위로 띄운다 */
    private fun liftCard(v: View, lift: Boolean) {
        v.translationZ = if (lift) dp(10).toFloat() else 0f
        var p = v.parent
        while (p is ViewGroup && p !== tabScroll) {
            // 카드 줄과 목록은 평소에도 잘라내기를 끈 상태로 둔다
            p.clipChildren = if (lift) false else !(p === tabList || p.tag == CARD_ROW_TAG)
            if (p !== tabList) {
                // 그룹 상자(배경 있음)는 둥근 모서리 클립을 잠깐 풀어 카드가 상자 밖으로 나갈 수 있게 한다
                if (p.background != null) p.clipToOutline = !lift
                p.translationZ = if (lift) dp(10).toFloat() else 0f
            }
            p = p.parent
        }
        // 스크롤 뷰도 자식(tabList)의 영역 밖은 잘라 버리므로 같이 풀어 준다 (안 그러면 카드가 첫 줄 아래에서 잘린다)
        tabScroll.clipChildren = false
    }

    /** 스크롤 내용 기준 좌표에서의 뷰 자리 */
    private fun contentRect(v: View): Rect {
        var x = 0
        var y = 0
        var c: View = v
        while (c !== tabScroll) {
            x += c.left
            y += c.top
            c = c.parent as? View ?: break
        }
        return Rect(x, y, x + v.width, y + v.height)
    }

    private fun setBoxHighlight(groupId: Int, on: Boolean) {
        if (groupId == 0) return
        val s = if (on) 1.03f else 1f
        switcherBoxes[groupId]?.animate()?.scaleX(s)?.scaleY(s)?.setDuration(140)?.start()
    }

    private fun startSwitcherDrag(tab: BrowserTab, rawX: Float, rawY: Float): Boolean {
        if (switcherBusy || groupToggling || swDrag != null) return false
        val g = groupOf(tab)
        // 같은 그룹 안에서, 또는 그룹에 속하지 않은 탭끼리 순서를 바꾼다
        val scope = tabs.filter { groupOf(it)?.id == g?.id && switcherRows.containsKey(it) }
        val from = scope.indexOf(tab)
        val view = switcherRows[tab]
        if (from < 0 || view == null) return false
        val slots = scope.map { t -> contentRect(switcherRows[t]!!) }
        // 시크릿 탭은 그룹에 넣을 수 없다. 자기 그룹 상자는 제외.
        val boxes = if (tab.incognito) emptyMap() else
            switcherBoxes.filter { it.key != tab.groupId }.mapValues { contentRect(it.value) }
        val loc = IntArray(2)
        tabScroll.getLocationOnScreen(loc)
        val fx = rawX - loc[0]
        val fy = rawY - loc[1] + tabScroll.scrollY
        val s = slots[from]
        swDrag = SwitcherDrag(tab, view, scope, from, slots, fx - s.left, fy - s.top, boxes).also {
            it.rawX = rawX
            it.rawY = rawY
        }
        liftCard(view, true)
        Motion.spring(view, DynamicAnimation.SCALE_X, 1.06f, 600f, 0.7f)
        Motion.spring(view, DynamicAnimation.SCALE_Y, 1.06f, 600f, 0.7f)
        tabScroll.postOnAnimation(swAutoScroll)
        return true
    }

    private fun updateSwitcherDrag() {
        val d = swDrag ?: return
        if (switcherRows[d.tab] !== d.view || d.view.parent == null) {
            swDrag = null
            return
        }
        val loc = IntArray(2)
        tabScroll.getLocationOnScreen(loc)
        val fx = d.rawX - loc[0]
        val fy = d.rawY - loc[1] + tabScroll.scrollY
        val s = d.slots[d.from]
        val left = fx - d.grabX
        val top = fy - d.grabY
        d.view.translationX = left - s.left
        d.view.translationY = top - s.top
        val cx = (left + s.width() / 2f).toInt()
        val cy = (top + s.height() / 2f).toInt()
        // 손가락이 창 칩 위에 있으면 '그 창으로 옮기기' 대상이 된다 (칩이 커지며 강조)
        val hit = windowChipAt(d.rawX, d.rawY)
        if (hit?.first !== d.winChip) {
            if ((hit == null) != (d.winChip == null)) {
                val k = if (hit != null) 0.62f else 1.06f
                Motion.spring(d.view, DynamicAnimation.SCALE_X, k, 520f, 0.65f)
                Motion.spring(d.view, DynamicAnimation.SCALE_Y, k, 520f, 0.65f)
                Motion.spring(d.view, DynamicAnimation.ALPHA, if (hit != null) 0.85f else 1f, 400f, 1f)
            }
            d.winChip?.let { setWinHighlight(it, false) }
            d.winChip = hit?.first
            d.winTarget = hit?.second
            if (hit != null) {
                setWinHighlight(hit.first, true)
                hit.first.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                setBoxHighlight(d.targetGroup, false)
                d.targetGroup = 0
                if (d.to != d.from) {
                    d.to = d.from
                    previewSwitcherOrder(d)
                }
            }
        }
        if (d.winChip != null) return
        // 다른 그룹 상자 위로 가져가면 '그룹에 넣기' 대상이 되어 상자가 커지며 강조된다
        val gid = d.boxes.entries.firstOrNull { it.value.contains(cx, cy) }?.key ?: 0
        if (gid != d.targetGroup) {
            setBoxHighlight(d.targetGroup, false)
            d.targetGroup = gid
            setBoxHighlight(gid, true)
            if (gid != 0 && d.to != d.from) {
                d.to = d.from
                previewSwitcherOrder(d)
            }
        }
        if (gid != 0) return
        val j = d.slots.indexOfFirst { it.contains(cx, cy) }
        if (j >= 0 && j != d.to) {
            d.to = j
            previewSwitcherOrder(d)
        }
    }

    private fun switcherOrder(d: SwitcherDrag): List<BrowserTab> =
        d.scope.toMutableList().also { it.add(d.to, it.removeAt(d.from)) }

    /** 놓으면 이렇게 된다는 걸 미리 보여 주기: 나머지 카드들이 새 자리로 비켜 준다 */
    private fun previewSwitcherOrder(d: SwitcherDrag) {
        val order = switcherOrder(d)
        d.scope.forEachIndexed { k, t ->
            if (k == d.from) return@forEachIndexed
            val a = d.slots[k]
            val b = d.slots[order.indexOf(t)]
            switcherRows[t]?.animate()
                ?.translationX((b.left - a.left).toFloat())
                ?.translationY((b.top - a.top).toFloat())
                ?.setDuration(180)?.start()
        }
    }

    private fun endSwitcherDrag(moved: Boolean, canceled: Boolean) {
        val d = swDrag ?: return
        swDrag = null
        tabScroll.removeCallbacks(swAutoScroll)
        val v = d.view
        setBoxHighlight(d.targetGroup, false)
        val wc = d.winChip
        wc?.let { setWinHighlight(it, false) }
        if (!canceled && wc != null && switcherRows[d.tab] === v && v.parent != null) {
            // 카드가 지금 있는 자리와 칩의 중심 (옮기고 나면 칩이 다시 그려질 수 있어 미리 잰다)
            val cl = IntArray(2)
            val chl = IntArray(2)
            v.getLocationOnScreen(cl)
            wc.getLocationOnScreen(chl)
            val dx = (chl[0] + wc.width / 2f) - (cl[0] + v.width * v.scaleX / 2f)
            val dy = (chl[1] + wc.height / 2f) - (cl[1] + v.height * v.scaleY / 2f)
            if (moveTabToWindow(d.tab, d.winTarget)) {
                // 나머지 카드는 제자리로, 끌던 카드는 칩 쪽으로 빨려 들어가며 작아지고 사라진다
                d.scope.forEach { t -> if (t !== d.tab) switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(160)?.start() }
                Motion.cancel(v)
                Motion.spring(v, DynamicAnimation.TRANSLATION_X, v.translationX + dx, 420f, 0.9f)
                Motion.spring(v, DynamicAnimation.TRANSLATION_Y, v.translationY + dy, 420f, 0.9f)
                Motion.spring(v, DynamicAnimation.SCALE_X, 0.08f, 380f, 1f)
                Motion.spring(v, DynamicAnimation.SCALE_Y, 0.08f, 380f, 1f)
                v.animate().alpha(0f).setStartDelay(120).setDuration(160).start()
                // 도착하면 칩이 톡 튀며 받았다고 알려 준다
                ui.postDelayed({ if (wc.isAttachedToWindow) Motion.pop(wc, 0.88f) }, 200)
                ui.postDelayed({
                    if (switcherOpen) {
                        liftCard(v, false)
                        refreshSwitcher(false)
                    }
                }, 330)
                return
            }
        }
        if (!canceled && d.targetGroup != 0 && switcherRows[d.tab] === v && v.parent != null) {
            val g = groups.firstOrNull { it.id == d.targetGroup }
            if (g != null) {
                moveToGroup(d.tab, g)
                saveTabs()
                d.scope.forEach { t -> if (t !== d.tab) switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(120)?.start() }
                v.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setDuration(140).start()
                ui.postDelayed({
                    if (switcherOpen) {
                        liftCard(v, false)
                        refreshSwitcher(false)
                    }
                }, 150)
                return
            }
        }
        Motion.spring(v, DynamicAnimation.SCALE_X, 1f, 480f, 0.6f)
        Motion.spring(v, DynamicAnimation.SCALE_Y, 1f, 480f, 0.6f)
        val live = switcherRows[d.tab] === v && v.parent != null
        if (canceled || !live || d.to == d.from) {
            d.scope.forEach { t ->
                switcherRows[t]?.animate()?.translationX(0f)?.translationY(0f)?.setDuration(180)?.start()
            }
            v.postDelayed({ liftCard(v, false) }, 220)
            // 끌지 않고 그냥 뗐으면 예전처럼 탭 메뉴
            if (!canceled && live && !moved) showTabMenu(d.tab) { refreshSwitcher(false) }
            return
        }
        // 새 순서를 저장: 이 범위의 탭들이 차지하던 자리에 새 순서대로 다시 넣는다 (다른 탭·그룹은 그대로)
        val order = switcherOrder(d)
        val idx = tabs.indices.filter { tabs[it] in d.scope }
        idx.forEachIndexed { n, i -> tabs[i] = order[n] }
        saveTabs()
        val a = d.slots[d.from]
        val b = d.slots[d.to]
        v.animate().translationX((b.left - a.left).toFloat()).translationY((b.top - a.top).toFloat())
            .setDuration(180).start()
        ui.postDelayed({
            if (switcherOpen) {
                liftCard(v, false)
                refreshSwitcher(false)
            }
        }, 200)
    }

    /** anchor 가 있으면(상단 탭 줄) 그 탭 바로 아래에 붙여 띄우고, 없으면 화면 가운데 팝업 */
    private fun showTabMenu(tab: BrowserTab, anchor: View? = null, onChanged: () -> Unit) {
        val items = mutableListOf<Popup.Item>()
        val own = groupOf(tab)

        // 탭 음소거: 꾹 누른 그 탭의 소리만 끄고 켠다 (다른 탭에서 계속 재생되는 탭도 포함)
        items.add(
            Popup.Item(
                if (tab.muted) R.drawable.ic_volume_up else R.drawable.ic_volume_off,
                if (tab.muted) "탭 음소거 해제" else "탭 음소거",
                if (tab.muted) "이 탭의 소리를 다시 켭니다" else "이 탭의 소리를 끕니다"
            ) {
                setTabMuted(tab, !tab.muted)
                onChanged()
            }
        )

        // 꾹 누른 그 탭의 페이지를 북마크에 추가(이미 있으면 수정). 현재 보는 탭이 아니어도 된다.
        tabBookmarkUrl(tab)?.let { url ->
            val saved = prefs.findBookmark(url)
            val title = tab.liveWebView?.title?.takeIf { it.isNotBlank() } ?: tab.pendingTitle.orEmpty()
            items.add(
                Popup.Item(
                    if (saved != null) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border,
                    if (saved != null) "북마크 수정" else "북마크에 추가",
                    Uri.parse(url).host?.removePrefix("www.")
                ) {
                    ListUi.showBookmarkEditor(this, prefs, saved, url, title) { msg -> toast(msg) }
                }
            )
        }
        // 크롬의 "탭을 다른 창으로 이동": 열려 있는 다른 창이 있을 때만 보이고, 어느 창으로 갈지 고른다 (새 창도 고를 수 있다).
        // 다른 창이 하나도 없으면 이 메뉴는 아예 보이지 않는다 (새 창으로 빼기는 탭을 끌어내는 동작으로)
        // 탭은 이 창에서 닫히고, 웹 기록·확대 비율·스크롤 위치가 그대로 따라간다 (시크릿 탭은 일반 새 창으로 새지 않게 제외)
        val otherWindows = instances.filter { it !== this && !it.isFinishing && !it.isDestroyed }
        val canNewWindow = !tab.incognito
        if (otherWindows.isNotEmpty()) {
            items.add(Popup.Item(R.drawable.ic_tab, "탭을 다른 창으로 이동", "이 탭을 지금 상태 그대로 다른 창으로 옮깁니다") {
                // 다른 창이 딱 하나면 고르는 창 없이 바로 그 창으로 옮긴다
                if (otherWindows.size == 1) {
                    if (moveTabToWindow(tab, otherWindows[0])) onChanged()
                } else {
                    showMoveTabChooser(tab, otherWindows, false, onChanged)
                }
            })
        }
        // 새 창으로 이동은 따로 둔다. 이 창에는 새 탭이 남는다 (마지막 탭이었다면 홈 탭으로 바뀐다)
        if (canNewWindow) {
            items.add(Popup.Item(R.drawable.ic_window_new, "탭을 새 창으로 이동", "이 탭을 지금 상태 그대로 새 창으로 옮깁니다") {
                if (moveTabToWindow(tab, null)) onChanged()
            })
        }
        // 탭 위치는 메뉴가 아니라 탭을 길게 누른 채 끌어서 바꾼다
        items.add(Popup.Item(R.drawable.ic_add, "새 그룹 만들기", "이 탭을 새 그룹에 담습니다") {
            showGroupEditor(null) { name, color ->
                val g = createGroup(name, color)
                moveToGroup(tab, g)
                onChanged()
            }
        })
        groups.filter { it.id != tab.groupId }.forEach { g ->
            val n = tabs.count { it.groupId == g.id }
            items.add(Popup.Item(R.drawable.ic_tab, "'${g.name}' 그룹에 추가", "탭 ${n}개", dotColor = g.color) {
                moveToGroup(tab, g)
                onChanged()
            })
        }
        if (own != null) {
            items.add(Popup.Item(R.drawable.ic_close, "'${own.name}' 그룹에서 빼기", "탭은 그대로 남습니다") {
                moveToGroup(tab, null)
                onChanged()
            })
        }

        val subtitle = (if (own != null) "그룹: ${own.name}" else "그룹에 속해 있지 않음") +
            if (tab.muted) " · 음소거 중" else ""
        if (anchor != null && anchor.isAttachedToWindow) {
            Popup.menuAnchored(
                this, anchor,
                title = tabTitle(tab),
                subtitle = subtitle,
                headerIcon = R.drawable.ic_tab,
                headerColor = own?.color,
                items = items
            )
        } else {
            Popup.menu(
                this,
                title = tabTitle(tab),
                subtitle = subtitle,
                headerColor = own?.color,
                headerIcon = R.drawable.ic_tab,
                items = items
            )
        }
    }

    /** 탭을 음소거하거나 해제한다. 보고 있지 않은 탭, 화면 뒤에 붙여 둔 탭, iframe 안의 영상까지 모두 적용된다 */
    private fun setTabMuted(tab: BrowserTab, mute: Boolean) {
        tab.muted = mute
        tab.liveWebView?.evaluateJavascript(MediaScripts.MUTE_SYNC, null)
        toast(if (mute) "탭을 음소거했어요" else "탭 음소거를 해제했어요")
    }

    private fun showGroupMenu(group: TabGroup, inSwitcher: Boolean, onChanged: () -> Unit) {
        val n = tabs.count { it.groupId == group.id }
        val items = listOf(
            Popup.Item(R.drawable.ic_add, "이 그룹에 새 탭") {
                openNewTabAndFocus(tabs.lastOrNull { it.groupId == group.id })
                if (inSwitcher) closeTabSwitcher()
            },
            Popup.Item(
                R.drawable.ic_expand_more,
                if (group.collapsed) "그룹 펼치기" else "그룹 접기",
                if (group.collapsed) "숨겨 둔 탭을 다시 보여줍니다" else "탭을 한 줄로 접어 둡니다"
            ) {
                group.collapsed = !group.collapsed
                onChanged()
            },
            Popup.Item(R.drawable.ic_edit, "이름·색상 변경") {
                showGroupEditor(group) { name, color ->
                    group.name = name
                    group.color = color
                    onChanged()
                }
            },
            Popup.Item(R.drawable.ic_folder, "그룹 해제", "탭은 닫지 않고 그룹만 없앱니다") {
                ungroup(group)
                onChanged()
            },
            Popup.Item(R.drawable.ic_delete, "그룹의 탭 모두 닫기", "탭 ${n}개가 닫힙니다", danger = true) {
                Popup.confirm(
                    this, "탭 ${n}개를 닫을까요?",
                    "'${group.name}' 그룹의 탭이 모두 닫힙니다.", "모두 닫기", danger = true
                ) {
                    closeGroup(group)
                    onChanged()
                }
            }
        )
        Popup.menu(
            this,
            title = group.name,
            subtitle = "탭 ${n}개" + if (group.collapsed) " · 접힘" else "",
            headerColor = group.color,
            items = items
        )
    }

    // ───────────────────────── 태블릿 레이아웃 / 탭 스트립 ─────────────────────────

    /**
     * 창의 현재 폭이 600dp 이상이면 넓은(태블릿) 레이아웃. 짧은 변이 아니라 지금 폭으로 정해서,
     * 창을 가로로 길게 늘리면 넓은 화면으로, 좁게 줄이면 폰 화면으로 바뀐다.
     * 경계(600dp)에서 창을 끌 때 계속 깜빡이지 않도록, 이미 넓은 상태면 560dp 밑으로 내려가야 좁은 화면으로 돌아간다.
     */
    private fun wideForWindow(): Boolean {
        val w = resources.configuration.screenWidthDp
        return if (expanded) w >= 560 else w >= 600
    }

    private var lastCols = 0

    /**
     * 웹페이지를 새 창 크기에 맞춘다. 모바일 사이트는 웹뷰가 알아서 다시 배치되지만,
     * 데스크톱 사이트 보기와 페이지 확대/축소는 "페이지를 불러올 때의 폭"으로 뷰포트를 한 번 덮어쓴 것이라
     * 창 크기를 바꾸면 옛 폭이 남는다. 크기 변화가 멈추면(끄는 중에는 잠깐 기다림) 새 폭으로 다시 덮어쓴다.
     */
    private val webRelayout = Runnable {
        if (isFinishing || isDestroyed || isInPictureInPictureModeCompat()) return@Runnable
        for (t in tabs) {
            val wv = t.liveWebView ?: continue
            if (t.isHome || t.pendingUrl != null) continue
            if (t.desktop) wv.evaluateJavascript(desktopViewportJs(), null)
            if (effectiveZoom(t) != 100) wv.evaluateJavascript(pageZoomJs(t), null)
        }
    }

    private fun scheduleWebRelayout() {
        ui.removeCallbacks(webRelayout)
        ui.postDelayed(webRelayout, 160)
    }

    /** 탭 화면의 카드 열 수: 폭이 넓을수록 늘어난다 */
    private fun switcherCols(): Int = (resources.configuration.screenWidthDp / 170).coerceIn(2, 5)

    /** 레이아웃 모드는 그대로인 크기·비율 변화: 필요한 곳만 새 크기에 맞춰 다시 계산한다 */
    private fun onWindowResized() {
        if (isInPictureInPictureModeCompat()) return
        if (switcherOpen && switcherCols() != lastCols) {
            lastCols = switcherCols()
            refreshSwitcher(false)
        }
        if (expanded) {
            tabStripScroll.doOnLayout {
                lastStripViewportW = tabStripScroll.width
                refreshTabStrip()
                updateStripPlus()
            }
        }
        if (switcherOpen) refreshWindowStrip()
        browserUi.post { barsSyncFullLayout() }
    }

    /** 넓은(태블릿) 레이아웃이면 상단 탭 스트립 + 툴바에 내비게이션, 아니면 폰 레이아웃(하단 바) */
    private fun applyLayoutMode(pip: Boolean = isInPictureInPictureModeCompat()) {
        val wide = wideForWindow()
        expanded = wide
        lastCols = switcherCols()
        // PiP 로 들어가면 화면 크기 변경 알림이 와서 이 함수가 불리는데, 그때 바를 다시 보이게 하면 안 된다
        if (pip && customView == null) {
            tabStripBar.visibility = View.GONE
            toolbarView.visibility = View.GONE
            bottomBar.visibility = View.GONE
            progressBar.visibility = View.GONE
            return
        }
        tabStripBar.visibility = if (wide) View.VISIBLE else View.GONE
        navGroup.visibility = if (wide) View.VISIBLE else View.GONE
        tabletActions.visibility = if (wide) View.VISIBLE else View.GONE
        tbMenu.visibility = if (wide) View.VISIBLE else View.GONE
        // 폰: 탭 버튼은 하단 바에 있다 / 태블릿: 주소창 오른쪽 툴바에 있다
        btnTabs.visibility = if (wide) View.VISIBLE else View.GONE
        bottomBar.visibility = if (wide) View.GONE else View.VISIBLE
        urlBar.layoutParams = urlBar.layoutParams.apply { height = dp(if (wide) 40 else 44) }
        urlBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (wide) 16f else 15f)
        // 폰 → 태블릿: 탭 줄이 방금 보이게 돼서 아직 배치 전(폭 0)이다. 배치가 끝난 뒤 실제 폭으로 탭 크기를 다시 계산한다.
        if (wide) {
            tabStripScroll.doOnLayout {
                lastStripViewportW = tabStripScroll.width
                refreshTabStrip()
                updateStripPlus()
            }
        }
        // 탭 전환 화면이 열려 있으면 새 화면 폭에 맞춰 열 수·카드 크기를 다시 계산한다
        if (switcherOpen) refreshSwitcher(false)
        // 폰 ↔ 태블릿 전환 시 숨김 상태 초기화 (남은 마진 때문에 바가 잘리는 것 방지)
        barsAnim?.cancel()
        barsStartRunnable?.let { webContainer.removeCallbacks(it) }
        barsStartRunnable = null
        barsLayoutHidden = false
        barsViewportReady = true
        barsGestureActive = false
        (webContainer.parent as? View)?.translationY = 0f
        barsFraction = 0f
        barsTarget = 0f
        for (v in listOf(tabStripBar, toolbarView)) {
            (v.layoutParams as? LinearLayout.LayoutParams)?.let { it.topMargin = 0; v.layoutParams = it }
        }
        (bottomBar.layoutParams as? LinearLayout.LayoutParams)?.let { it.bottomMargin = 0; bottomBar.layoutParams = it }
        for (v in listOf(tabStripBar, toolbarView, progressBar, bottomBar)) v.translationY = 0f
        barsSyncedTopH = -1
        homeView.setPadding(0, 0, 0, 0)
        browserUi.post { barsSyncFullLayout() }
        updateStatusBarColor()
        // 제목줄 통합 중이면 탭 줄이 보이는지에 따라 위 여백이 달라지므로 인셋을 다시 적용
        if (captionEdgeToEdge) (browserUi.parent as? View)?.let { androidx.core.view.ViewCompat.requestApplyInsets(it) }
    }

    // ───────────────────── 창 모드(프리폼) 제목줄 통합 ─────────────────────

    /**
     * 데스크톱/프리폼 창에서는 시스템이 제목줄(캡션 바)을 앱 위에 따로 그려서,
     * 탭 줄이 제목줄 아래 한 줄을 더 차지한다. 크롬처럼 탭 줄을 그 제목줄 자리에 그리도록
     * 캡션 바 인셋이 있을 때만 가장자리까지 그리기로 바꾼다. (폰·전체 화면에서는 아무것도 바뀌지 않는다)
     */
    private var captionEdgeToEdge = false
    private var captionActive = false
    private var captionTopApplied = -1
    private var captionStartApplied = -1
    private var captionEndApplied = -1

    private fun installCaptionIntegration() {
        if (Build.VERSION.SDK_INT < 30) return
        // Android 15+ (targetSdk 35): 가장자리까지 그리기가 기본이라 처음부터 인셋을 직접 처리한다
        if (Build.VERSION.SDK_INT >= 35) {
            captionEdgeToEdge = true
            enableCaptionEdgeToEdge()
            return
        }
        val decor = window.decorView
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(decor) { v, insets ->
            if (!captionEdgeToEdge &&
                insets.getInsets(WindowInsetsCompat.Type.captionBar()).top > 0
            ) {
                captionEdgeToEdge = true
                v.post { enableCaptionEdgeToEdge() }
            }
            androidx.core.view.ViewCompat.onApplyWindowInsets(v, insets)
        }
    }

    private fun enableCaptionEdgeToEdge() {
        val decor = window.decorView
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(decor, null)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // 데스크톱 창 제목줄을 투명하게 만들어야(APPEARANCE_TRANSPARENT_CAPTION_BAR_BACKGROUND = 1 shl 7, Android 15+)
        // 앱이 제목줄 자리에 그릴 수 있고 캡션 바 인셋도 들어온다. 탭 줄 배경이 밝으면 시스템 버튼은 어두운 색
        // (APPEARANCE_LIGHT_CAPTION_BARS = 1 shl 8).
        try {
            val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
            val transparent = 1 shl 7
            val light = 1 shl 8
            window.insetsController?.setSystemBarsAppearance(
                transparent or (if (night) 0 else light), transparent or light
            )
        } catch (_: Throwable) {}

        val root = findViewById<View>(R.id.browserUi)?.parent as? View ?: return
        statusBand = StatusBandDrawable(getColor(R.color.ev_surface), getColor(R.color.ev_surface)).also { root.background = it }
        updateStatusBarColor()
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val cap = insets.getInsets(WindowInsetsCompat.Type.captionBar())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // 제목줄이 있으면 위 여백은 0: 탭 줄이 그 자리를 쓴다. 없으면(전체 화면 등) 보통 시스템 바 여백.
            val stripInCaption = cap.top > 0 && captionHasWindowControls(insets, v.width, cap.top) &&
                tabStripBar.visibility == View.VISIBLE
            val top = if (stripInCaption) 0 else sys.top
            v.setPadding(sys.left, top, sys.right, maxOf(sys.bottom, ime.bottom))
            statusBand?.h = top
            applyCaptionToStrip(if (stripInCaption) cap.top else 0)
            // 탭 목록 화면은 제목줄(시스템 버튼) 아래에서 시작하도록 그 높이만큼 위 여백을 준다
            applySwitcherCaptionInset(if (stripInCaption) cap.top else 0)
            WindowInsetsCompat.CONSUMED
        }
        androidx.core.view.ViewCompat.requestApplyInsets(root)
    }

    /**
     * 팝업 창의 제목줄 방식: 창 버튼(최소화·최대화·닫기)이 있는 일반 제목줄이면 true, 가운데 손잡이만 있는 얇은 방식이면 false.
     * 삼성 인터넷처럼 일반 제목줄일 때만 탭을 제목줄 안에 넣고, 손잡이 방식이면 탭 줄을 그 아래에 보통대로 둔다.
     * 시스템이 알려주는 시스템 요소 위치(getBoundingRects)에 오른쪽 요소가 있으면 일반 제목줄,
     * 알려주지 않으면 제목줄 높이(32dp 이상)로 판단한다.
     */
    private fun captionHasWindowControls(insets: WindowInsetsCompat, width: Int, capTop: Int): Boolean {
        val byHeight = capTop >= dp(32)
        if (Build.VERSION.SDK_INT < 30 || width <= 0) return byHeight
        return try {
            val wi = insets.toWindowInsets() ?: return byHeight
            val m = android.view.WindowInsets::class.java.getMethod("getBoundingRects", Int::class.javaPrimitiveType)
            val rects = (m.invoke(wi, android.view.WindowInsets.Type.captionBar()) as? List<*>)
                ?.filterIsInstance<Rect>()?.filter { it.width() > 0 } ?: return byHeight
            if (rects.isEmpty()) byHeight else rects.any { it.centerX() > width * 0.6f }
        } catch (_: Throwable) { byHeight }
    }

    private var switcherCaptionOn = false
    private var switcherCaptionTop = 0

    /**
     * 팝업/데스크톱 창에서 탭 목록 헤더("모두 닫기")가 오른쪽 시스템 창 버튼(…, 최소화, 최대화, 닫기)과 겹치지 않게 한다.
     * 화면 전체를 아래로 밀면 카드 자리가 바뀌어 열고 닫는 전환이 어색해지므로, 세로 위치는 그대로 두고
     * 헤더의 오른쪽 여백만 시스템 버튼 폭만큼 늘린다.
     */
    private fun applySwitcherCaptionInset(top: Int) {
        switcherCaptionOn = top > 0
        switcherCaptionTop = top
        if (!::tabSwitcher.isInitialized) return
        val header = tabSwitcher.findViewById<View>(R.id.switcherHeader) ?: return
        // 팝업/데스크톱 창: 이전 버튼·"탭"·"모두 닫기"가 시스템 버튼(…, 최소화, 최대화, 닫기) 줄에 겹치지 않게
        // 제목줄 높이만큼 헤더를 아래로 내린다. 오른쪽 여백은 겹칠 일이 없으니 기본값.
        val pt = if (switcherCaptionOn) top else 0
        val lp = header.layoutParams
        val h = dp(56) + pt
        if (header.paddingTop != pt || header.paddingEnd != dp(8) || lp.height != h) {
            header.setPadding(header.paddingLeft, pt, dp(8), header.paddingBottom)
            lp.height = h
            header.layoutParams = lp
        }
    }

    private var captionTouchInstalled = false

    /**
     * 제목줄 영역의 터치는 기본적으로 시스템이 창 이동용으로 가져간다. 탭·+ 버튼이 있는 부분만
     * setSystemGestureExclusionRects 로 앱이 터치(탭 선택·스크롤)를 받게 하고, 나머지 빈 곳은 창 끌기용으로 남긴다.
     */
    private fun installCaptionTouchRegion() {
        if (captionTouchInstalled) return
        captionTouchInstalled = true
        val l = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateCaptionTouchRegion() }
        tabStripBar.addOnLayoutChangeListener(l)
        tabStrip.addOnLayoutChangeListener(l)
        tabStripScroll.addOnLayoutChangeListener(l)
        findViewById<View>(R.id.btnStripTabList)?.addOnLayoutChangeListener(l)
    }

    /**
     * 제목줄 안에서 앱이 터치를 받아야 하는 곳(탭 줄·새 탭(+)·탭 목록 버튼)을 시스템에 알린다.
     * 예전에는 탭 줄만 알려서 오른쪽 탭 목록 버튼이 시스템에 먹혔다. 이제 보이는 버튼마다 따로 알리고,
     * 창을 옮기거나 크기를 바꾼 뒤에도 시스템이 값을 잃지 않도록 다시 걸어 준다.
     */
    private fun updateCaptionTouchRegion(force: Boolean = false) {
        if (Build.VERSION.SDK_INT < 29) return
        val rects = ArrayList<Rect>()
        if (captionActive && tabStripBar.height > 0 && tabStripScroll.width > 0) {
            val h = tabStripBar.height
            // 좌표는 모두 tabStripBar 기준. (제목줄 안에서는 바 왼쪽에 시스템 아이콘 자리 padding 이 있어서
            // 스크롤 뷰의 left 만 쓰면 영역이 그만큼 왼쪽으로 밀려 + 버튼이 시스템에 먹힌다)
            fun rectOf(v: View, pad: Int): Rect {
                var x = v.left + v.translationX.toInt()
                var p = v.parent as? View
                while (p != null && p !== tabStripBar) { x += p.left; p = p.parent as? View }
                return Rect(x - pad, 0, x + v.width + pad, h)
            }
            val scrollRect = rectOf(tabStripScroll, 0)
            val contentW = tabStripScroll.paddingStart + tabStrip.width
            rects.add(Rect(scrollRect.left, 0, scrollRect.left + minOf(contentW, tabStripScroll.width), h))
            // 새 탭(+) 버튼: 마지막 탭 옆을 따라 움직이므로 지금 실제 위치로 알린다
            findViewById<View>(R.id.stripPlusHolder)?.takeIf { it.width > 0 }?.let { rects.add(rectOf(it, dp(2))) }
            findViewById<View>(R.id.btnStripTabList)?.takeIf { it.visibility == View.VISIBLE && it.width > 0 }?.let {
                rects.add(rectOf(it, dp(4)))
            }
        }
        if (force || tabStripBar.systemGestureExclusionRects != rects) tabStripBar.systemGestureExclusionRects = rects
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 팝업 창을 끌거나 크기를 바꾸면 시스템이 제목줄 터치 영역을 비울 수 있어서 다시 알린다
        if (captionActive && ::tabStripBar.isInitialized) tabStripBar.post { updateCaptionTouchRegion(force = true) }
    }

    /**
     * 캡션 높이(px)에 맞춰 탭 줄 높이·탭 위치·좌우 비움 폭을 정한다. capTop = 0 이면 원래 모양으로 되돌린다.
     * 탭 줄 높이는 제목줄 높이와 똑같이 해서 탭의 세로 가운데가 시스템 버튼의 가운데와 같게 한다.
     * 좌우 비움 폭은 시스템 아이콘·메뉴(왼쪽)와 최소화·최대화·닫기 버튼(오른쪽)이 실제로 차지하는 폭에 맞춘 값이다.
     */
    private fun applyCaptionToStrip(capTop: Int) {
        val inCaption = capTop > 0
        val h = if (inCaption) maxOf(capTop, dp(32)) else dp(44)
        // 탭 위쪽 여백: 기본 6dp, 제목줄 안에서는 2dp (탭 높이는 최대 42dp)
        val pt = if (inCaption) maxOf(dp(2), h - dp(42)) else dp(6)
        val start = if (inCaption) dp(68) else 0
        // 오른쪽 비움: 시스템 버튼(메뉴·최소화·최대화·닫기)이 실제로 차지하는 폭 + 여유.
        // 여유가 모자라면 오른쪽 끝에 멈춘 + 버튼이 시스템 버튼의 터치 영역과 겹쳐 눌리지 않았다
        val end = if (inCaption) dp(208) else 0
        if (h == captionTopApplied && start == captionStartApplied && end == captionEndApplied) return
        captionTopApplied = h; captionStartApplied = start; captionEndApplied = end
        captionActive = inCaption

        tabStripBar.layoutParams = tabStripBar.layoutParams.apply { height = h }
        tabStripBar.setPadding(start, 0, end, 0)
        tabStripScroll.setPadding(tabStripScroll.paddingLeft, pt, tabStripScroll.paddingRight, 0)
        // + 버튼·탭 목록 버튼은 탭과 같은 세로 가운데. center_vertical 에 위 여백 m 을 주면 중심이 (바 높이 + m)/2 라서,
        // 탭 영역(위 여백 pt 를 뺀 나머지)의 중심 (바 높이 + pt)/2 와 맞추려면 m = pt (기본 6dp)
        // 풀스크린(기본 모양)은 예전 값(pt - 3dp)을 그대로 두고, 제목줄 안에 들어간 팝업 창에서만 pt 로 맞춘다
        val plusTop = if (inCaption) pt else pt - dp(3)
        for (id in intArrayOf(R.id.btnStripNewTab, R.id.btnStripTabList)) {
            val v = findViewById<View>(id) ?: continue
            (v.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.topMargin = plusTop; v.layoutParams = it }
        }
        installCaptionTouchRegion()
        updateCaptionTouchRegion()
        browserUi.post {
            if (expanded) {
                tabStripScroll.doOnLayout {
                    lastStripViewportW = tabStripScroll.width
                    refreshTabStrip()
                    updateStripPlus()
                }
            }
            barsSyncFullLayout()
        }
    }

    private var statusBarAnim: android.animation.ValueAnimator? = null
    private var bandAnim: android.animation.ValueAnimator? = null
    private var statusBand: StatusBandDrawable? = null

    /** 바탕색으로 채우고, 맨 위 h px 만 band 색으로 덮는 배경 (상태표시줄 자리를 탭 줄/주소창 색과 맞추기 위해) */
    private class StatusBandDrawable(var base: Int, var band: Int) : android.graphics.drawable.Drawable() {
        var h = 0
            set(v) { if (field != v) { field = v; invalidateSelf() } }
        private val paint = android.graphics.Paint()
        override fun draw(canvas: android.graphics.Canvas) {
            val b = bounds
            paint.color = base
            canvas.drawRect(b, paint)
            if (h > 0) {
                paint.color = band
                canvas.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), (b.top + h).toFloat(), paint)
            }
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = android.graphics.PixelFormat.OPAQUE
    }

    /** 상태표시줄을 화면 맨 위에 있는 영역(탭바 / 주소창 / 탭 목록)의 배경색과 똑같이 맞춘다. */
    private fun updateStatusBarColor(switcher: Boolean = switcherOpen) {
        val target = getColor(
            when {
                // 탭 목록 화면 배경. 단 블러가 켜져 있으면 바로 아래에 흐려진 페이지(탭 줄/주소창)가 보이므로,
                // 상태표시줄 자리도 그 색을 그대로 둬야 흰 띠로 튀지 않고 이어져 보인다.
                switcher && !switcherGlass() -> R.color.ev_bg
                expanded -> R.color.ev_pill_high   // 태블릿 상단 탭바 배경
                else -> R.color.ev_surface         // 폰 상단 주소창 배경
            }
        )
        // targetSdk 35 에서는 window.statusBarColor 가 무시되므로, 상태표시줄 자리는 루트 배경의 윗부분을 직접 칠한다
        statusBand?.let { b ->
            if (b.band != target) {
                bandAnim?.cancel()
                bandAnim = android.animation.ValueAnimator.ofArgb(b.band, target).apply {
                    duration = 180
                    addUpdateListener { b.band = it.animatedValue as Int; b.invalidateSelf() }
                    start()
                }
            }
        }
        if (window.statusBarColor == target) return
        statusBarAnim?.cancel()
        statusBarAnim = android.animation.ValueAnimator.ofArgb(window.statusBarColor, target).apply {
            duration = 180
            addUpdateListener { window.statusBarColor = it.animatedValue as Int }
            start()
        }
    }

    /**
     * 이 창의 탭 개수·제목 등이 바뀌었을 때, 탭 화면을 열어 둔 다른 창들의 '창 목록'도 다시 그리게 한다.
     * (예전에는 onResume 에서만 갱신해서, 분할 화면·프리폼처럼 여러 창이 동시에 보일 때 반영되지 않았다)
     */
    private fun notifyOtherWindows() {
        instances.toList().forEach { a -> if (a !== this) a.queueWindowStripRefresh() }
    }

    /** 탭 화면이 열려 있으면 창 목록을 (한 번에 몰아서) 다시 그린다. 카드를 끄는 중이면 끝난 뒤로 미룬다 */
    private fun queueWindowStripRefresh() {
        if (windowStripQueued || !switcherOpen || isFinishing || isDestroyed) return
        windowStripQueued = true
        ui.postDelayed(object : Runnable {
            override fun run() {
                if (!switcherOpen || isFinishing || isDestroyed) { windowStripQueued = false; return }
                if (swDrag != null || wsDragView != null) { ui.postDelayed(this, 300); return }
                windowStripQueued = false
                refreshWindowStrip()
            }
        }, 80)
    }

    private fun scheduleStripRefresh() {
        notifyOtherWindows()
        if (!expanded || stripRefreshQueued) return
        stripRefreshQueued = true
        ui.post {
            stripRefreshQueued = false
            refreshTabStrip()
        }
    }

    /** 상단 탭바의 탭 하나 (뷰를 재사용하면서 제목·아이콘·선택 상태만 바꾼다) */
    private class StripChip(val view: View, val tab: BrowserTab) {
        val title: TextView = view.findViewById(R.id.stripTitle)
        val icon: ImageView = view.findViewById(R.id.stripIcon)
        val bar: View = view.findViewById(R.id.stripGroupBar)
        var bg: android.graphics.drawable.Drawable? = null
        var width = 0
        var selected = false
        var selFraction = 0f
        var iconKey: Any? = null
        var iconKind: String? = null   // 아이콘 종류가 바뀔 때만 살짝 페이드 (같은 종류의 파비콘 교체는 조용히)
        var following = false
        var widthAnim: android.animation.ValueAnimator? = null
        var selAnim: android.animation.ValueAnimator? = null
    }

    private val stripChips = HashMap<BrowserTab, StripChip>()
    private val stripPills = HashMap<Int, TextView>()
    private var stripReady = false
    private val stripEase by lazy { android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f) }

    private fun setViewWidth(v: View, w: Int) {
        val lp = v.layoutParams ?: return
        if (lp.width != w) {
            lp.width = w
            v.layoutParams = lp
        }
    }

    private fun animateChipWidth(c: StripChip, to: Int, animate: Boolean) {
        c.widthAnim?.cancel()
        c.width = to
        val from = c.view.layoutParams.width
        if (!animate || from == to) {
            setViewWidth(c.view, to)
            c.following = false
            return
        }
        c.widthAnim = android.animation.ValueAnimator.ofInt(from, to).apply {
            duration = 280
            interpolator = stripEase
            addUpdateListener {
                setViewWidth(c.view, it.animatedValue as Int)
                if (c.following) ensureStripVisible(c, false)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    c.following = false
                }
            })
            start()
        }
    }

    private fun applyChipSelection(c: StripChip) {
        c.bg?.alpha = (255 * c.selFraction).toInt()
        c.title.setTextColor(
            androidx.core.graphics.ColorUtils.blendARGB(
                getColor(R.color.ev_muted), getColor(R.color.ev_text), c.selFraction
            )
        )
    }

    private fun animateChipSelection(c: StripChip, selected: Boolean, animate: Boolean) {
        c.selAnim?.cancel()
        c.selected = selected
        val to = if (selected) 1f else 0f
        if (!animate) {
            c.selFraction = to
            applyChipSelection(c)
            return
        }
        c.selAnim = android.animation.ValueAnimator.ofFloat(c.selFraction, to).apply {
            duration = 220
            interpolator = stripEase
            addUpdateListener {
                c.selFraction = it.animatedValue as Float
                applyChipSelection(c)
            }
            start()
        }
    }

    /** 탭(또는 그룹 알약)을 폭을 줄이며 사라지게 한 뒤 떼어낸다. 오른쪽 탭들이 부드럽게 왼쪽으로 당겨진다. */
    private fun retireStripView(v: View, c: StripChip?, animate: Boolean) {
        c?.widthAnim?.cancel()
        c?.selAnim?.cancel()
        c?.following = false
        if (!animate || v.parent == null || v.width == 0) {
            tabStrip.removeView(v)
            return
        }
        v.isEnabled = false
        v.isClickable = false
        v.isLongClickable = false
        v.animate().alpha(0f).setDuration(170).start()
        setViewWidth(v, v.width)
        android.animation.ValueAnimator.ofInt(v.width, 0).apply {
            duration = 260
            interpolator = stripEase
            addUpdateListener { setViewWidth(v, it.animatedValue as Int) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    tabStrip.removeView(v)
                }
            })
            start()
        }
    }

    /** 탭이 가려지지 않게 스크롤 (이미 다 보이면 가만히 둔다) */
    private fun ensureStripVisible(c: StripChip, smooth: Boolean) {
        val vw = tabStripScroll.width
        if (vw <= 0) return
        val sx = tabStripScroll.scrollX
        val left = c.view.left
        val right = left + maxOf(c.width, c.view.width)
        val pad = dp(28)
        val target = when {
            left - pad < sx -> left - pad
            right + pad > sx + vw -> right + pad - vw
            else -> return
        }.coerceAtLeast(0)
        if (smooth) tabStripScroll.smoothScrollTo(target, 0) else tabStripScroll.scrollTo(target, 0)
    }

    private fun bindStripChip(tab: BrowserTab, group: TabGroup?, width: Int, animate: Boolean): View {
        var c = stripChips[tab]
        val isNew = c == null
        if (c == null) {
            val v = layoutInflater.inflate(R.layout.item_strip_tab, tabStrip, false)
            c = StripChip(v, tab)
            stripChips[tab] = c
            // 파비콘 모서리를 살짝 둥글게
            c.icon.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(4).toFloat())
                }
            }
            c.icon.clipToOutline = true
            c.bg = getDrawable(R.drawable.bg_strip_tab_selected)?.mutate()?.also { it.alpha = 0 }
            v.background = c.bg
            v.setOnClickListener { if (tab !== current) selectTab(tab) }
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 탭 메뉴
            bindDragGesture(
                v, null,
                onStart = { x, y -> startStripDrag(tab, x, y) },
                onMove = { x, y -> stripRawX = x; stripRawY = y; updateStripDrag() },
                onEnd = { moved, canceled -> endStripDrag(moved, canceled) }
            )
            c.view.findViewById<ImageButton>(R.id.stripClose).setOnClickListener { closeTab(tab, quitIfLast = true) }
        }
        val chip = c

        // 제목: 홈(새 탭)이면 항상 "새 탭" — 이전 페이지 제목이 남아 있어도 쓰지 않는다
        val title = if (tab.isHome) "새 탭"
            else tab.liveWebView?.title?.takeIf { it.isNotBlank() && it != "about:blank" }
                ?: tab.liveWebView?.url?.takeIf { it != "about:blank" && it != HOME_URL }?.let { Uri.parse(it).host }
                ?: tabTitle(tab)
        if (chip.title.text.toString() != title) {
            chip.title.text = title
            if (animate && !isNew) {
                chip.title.alpha = 0.25f
                chip.title.animate().alpha(1f).setDuration(220).start()
            }
        }

        // 아이콘: 홈이면 잎사귀, 페이지면 파비콘(없으면 지구본)
        val fav = if (tab.isHome) null else tab.favicon
        val key: Any = if (tab.incognito) "incognito" else fav ?: if (tab.isHome) "home" else "globe"
        val kind = when {
            tab.incognito -> "incognito"
            fav != null -> "fav"
            tab.isHome -> "home"
            else -> "globe"
        }
        if (chip.iconKey != key) {
            val kindChanged = chip.iconKind != kind
            chip.iconKind = kind
            chip.iconKey = key
            chip.icon.imageTintList = if (tab.incognito)
                MaterialColors.getColor(chip.icon, com.google.android.material.R.attr.colorOnSurface)
                    .let { android.content.res.ColorStateList.valueOf(it) }
            else null
            when {
                tab.incognito -> chip.icon.setImageResource(R.drawable.ic_incognito)
                fav != null -> chip.icon.setImageBitmap(fav)
                tab.isHome -> chip.icon.setImageResource(R.drawable.ic_leaf_pixel)
                else -> chip.icon.setImageResource(R.drawable.ic_globe)
            }
            // 사이트가 파비콘을 여러 번 보내도 통통 튀지 않게: 크기 변화·오버슛은 쓰지 않고,
            // 아이콘 종류가 바뀔 때(지구본 → 파비콘 등)만 부드럽게 페이드한다.
            chip.icon.animate().cancel()
            chip.icon.scaleX = 1f; chip.icon.scaleY = 1f
            if (animate && !isNew && kindChanged) {
                chip.icon.alpha = 0f
                chip.icon.animate().alpha(1f).setDuration(180).start()
            } else {
                chip.icon.alpha = 1f
            }
        }

        if (group != null) {
            chip.bar.visibility = View.VISIBLE
            chip.bar.background.mutate().setTint(group.color)
        } else {
            chip.bar.visibility = View.INVISIBLE
        }

        val sel = tab === current
        if (isNew) {
            chip.selected = sel
            chip.selFraction = if (sel) 1f else 0f
            applyChipSelection(chip)
        } else if (chip.selected != sel) {
            animateChipSelection(chip, sel, animate)
        }

        if (isNew) {
            chip.width = width
            if (animate) {
                chip.view.layoutParams.width = 0
                chip.view.alpha = 0f
                chip.following = sel
                chip.view.animate().alpha(1f).setStartDelay(50).setDuration(220).start()
                // 실제 너비 애니메이션은 뷰가 붙은 뒤 시작 (아래 refreshTabStrip 에서)
                chip.view.tag = width
            } else {
                chip.view.layoutParams.width = width
            }
        } else if (chip.width != width) {
            animateChipWidth(chip, width, animate)
        }
        return chip.view
    }

    private fun bindStripPill(group: TabGroup, animate: Boolean): View {
        var pill = stripPills[group.id]
        val isNew = pill == null
        if (pill == null) {
            pill = layoutInflater.inflate(R.layout.item_strip_group, tabStrip, false) as TextView
            stripPills[group.id] = pill
            pill.setOnClickListener {
                group.collapsed = !group.collapsed
                scheduleStripRefresh()
            }
            pill.setOnLongClickListener {
                showGroupMenu(group, false) { scheduleStripRefresh() }
                true
            }
            Motion.pressable(pill, 0.92f)
            if (animate) pill.alpha = 0f
        }
        val n = tabs.count { it.groupId == group.id }
        pill.text = if (group.collapsed) "${group.name} ($n)" else group.name
        pill.background.mutate().setTint(group.color)
        // 접힘/펼침이 바뀌면 알약이 톡 튀어 변화를 알려 준다
        val wasCollapsed = pill.tag as? Boolean
        if (wasCollapsed != null && wasCollapsed != group.collapsed && animate) Motion.pop(pill, 0.8f)
        pill.tag = group.collapsed
        if (isNew && animate) {
            pill.animate().alpha(1f).setDuration(220).start()
            Motion.pop(pill, 0.7f)
        }
        return pill
    }

    private var lastStripViewportW = 0

    private fun refreshTabStrip() {
        if (!expanded) return
        // 아직 배치 전이면 폭을 알 수 없다 (임의의 폭으로 만들면 비율이 틀어진다). 배치되면 레이아웃 리스너가 다시 부른다.
        if (tabStripScroll.width <= 0) return
        val animate = stripReady && tabStripScroll.width > 0 && Motion.enabled(this)

        val visible = tabs.count { val g = groupOf(it); g == null || !g.collapsed }

        // 탭 너비는 고정 범위(124~220dp)로 계산해서 지정 → 탭이 한없이 길어지지 않게 함.
        // 탭이 많으면 최소 너비로 줄고 스크롤, 적으면 최대 너비에서 멈춤.
        val avail = tabStripScroll.width - dp(60)
        val chipWidth = if (avail > 0) {
            (avail / maxOf(1, visible)).coerceIn(dp(124), dp(220))
        } else dp(180)

        val desired = ArrayList<View>()
        val keepTabs = HashSet<BrowserTab>()
        val keepPills = HashSet<Int>()
        tabs.toList().forEach { tab ->
            val group = groupOf(tab)
            if (group != null && keepPills.add(group.id)) desired.add(bindStripPill(group, animate))
            if (group != null && group.collapsed) return@forEach
            desired.add(bindStripChip(tab, group, chipWidth, animate))
            keepTabs.add(tab)
        }

        // 없어진 탭/그룹은 폭을 줄이며 사라지게
        stripChips.entries.toList().forEach { (t, c) ->
            if (t !in keepTabs) {
                stripChips.remove(t)
                retireStripView(c.view, c, animate)
            }
        }
        stripPills.entries.toList().forEach { (id, p) ->
            if (id !in keepPills) {
                stripPills.remove(id)
                retireStripView(p, null, animate)
            }
        }

        // 순서대로 배치 (새 뷰는 이전 뷰 바로 뒤에 끼우고, 순서가 어긋난 뷰만 옮긴다)
        var prev: View? = null
        for (v in desired) {
            if (v.parent == null) {
                tabStrip.addView(v, prev?.let { tabStrip.indexOfChild(it) + 1 } ?: 0)
            } else if (prev != null && tabStrip.indexOfChild(v) < tabStrip.indexOfChild(prev)) {
                tabStrip.removeView(v)
                tabStrip.addView(v, tabStrip.indexOfChild(prev) + 1)
            }
            prev = v
        }

        // 새로 생긴 탭: 폭 0 에서 목표 폭까지 자라나게
        stripChips.values.forEach { c ->
            val target = c.view.tag as? Int ?: return@forEach
            c.view.tag = null
            animateChipWidth(c, target, true)
        }

        // 선택한 탭이 바뀌었거나 새로 생겼을 때만 그 탭이 보이도록 스크롤 (직접 스크롤 중에는 건드리지 않음)
        val cur = current?.let { stripChips[it] }
        if (cur != null && lastStripCurrent !== current) {
            lastStripCurrent = current
            if (!cur.following) tabStripScroll.post { ensureStripVisible(cur, true) }
        }

        if (tabStripScroll.width > 0) stripReady = true
    }

    // ───────────────────────── 키보드 단축키 (태블릿 + 키보드) ─────────────────────────

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && handleShortcut(event)) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun handleShortcut(e: KeyEvent): Boolean {
        if (e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_T -> openNewTabAndFocus()
                KeyEvent.KEYCODE_W -> current?.let { closeTab(it, quitIfLast = true) }
                KeyEvent.KEYCODE_L -> focusUrlBar()
                KeyEvent.KEYCODE_F -> openFind()
                KeyEvent.KEYCODE_R -> current?.let { reloadTab(it) }
                KeyEvent.KEYCODE_D -> bookmarkCurrent()
                KeyEvent.KEYCODE_TAB -> cycleTab(if (e.isShiftPressed) -1 else 1)
                in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9 -> {
                    val target = if (e.keyCode == KeyEvent.KEYCODE_9) {
                        tabs.lastOrNull()
                    } else {
                        tabs.getOrNull(e.keyCode - KeyEvent.KEYCODE_1)
                    }
                    if (target != null) selectTab(target)
                }
                else -> return false
            }
            return true
        }
        if (e.isAltPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> navBack()
                KeyEvent.KEYCODE_DPAD_RIGHT -> navForward()
                else -> return false
            }
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_F5) {
            current?.let { reloadTab(it) }
            return true
        }
        return false
    }

    /** 주소창 입력 중 다른 화면 영역을 누르면 키보드와 입력 포커스를 함께 닫는다. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && ::urlBar.isInitialized && urlBar.hasFocus()) {
            val rect = Rect()
            urlBar.getGlobalVisibleRect(rect)
            val outsideAddressBar = !rect.contains(ev.rawX.toInt(), ev.rawY.toInt())
            if (outsideAddressBar) hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun cycleTab(delta: Int) {
        if (tabs.size < 2) return
        val i = tabs.indexOf(current).coerceAtLeast(0)
        selectTab(tabs[(i + delta + tabs.size) % tabs.size])
    }

    /** 키보드를 내리고 입력창에서 포커스를 뺀다. (홈 화면에서 키보드가 저절로 뜨지 않게) */
    private fun hideKeyboard() {
        urlBar.dismissDropDown()
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    private fun focusUrlBar() {
        urlBar.requestFocus()
        urlBar.selectAll()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(urlBar, InputMethodManager.SHOW_IMPLICIT)
    }

    // ───────────────────────── 탭 전환 화면 (전체 화면) ─────────────────────────

    private val thumbScale = 0.6f

    /** 지금 보이는 페이지 영역(웹뷰 + 홈 화면)을 비트맵으로 찍는다. */
    private fun captureContent(): Bitmap? {
        val area = webContainer.parent as? View ?: return null
        val w = area.width
        val h = area.height
        if (w <= 0 || h <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(
                (w * thumbScale).toInt().coerceAtLeast(1),
                (h * thumbScale).toInt().coerceAtLeast(1),
                Bitmap.Config.RGB_565
            )
            val c = Canvas(bmp)
            c.drawColor(MaterialColors.getColor(area, com.google.android.material.R.attr.colorSurface))
            c.scale(thumbScale, thumbScale)
            area.draw(c)
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    /** 이미지를 위쪽 기준으로 꽉 채워 보여주는 행렬 (페이지의 윗부분이 보이도록) */
    private fun topCropMatrix(bmp: Bitmap, w: Int, h: Int): Matrix {
        val s = maxOf(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        return Matrix().apply {
            setScale(s, s)
            postTranslate((w - bmp.width * s) / 2f, 0f)
        }
    }

    private fun setThumb(iv: ImageView, bmp: Bitmap?) {
        if (bmp == null) {
            iv.scaleType = ImageView.ScaleType.CENTER
            iv.alpha = 1f
            iv.setImageResource(R.drawable.ic_leaf_pixel)
            return
        }
        iv.scaleType = ImageView.ScaleType.MATRIX
        iv.setImageBitmap(bmp)
        fun apply() {
            if (iv.width > 0 && iv.height > 0) iv.imageMatrix = topCropMatrix(bmp, iv.width, iv.height)
        }
        iv.addOnLayoutChangeListener { _, l, tp, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - tp != ob - ot) apply()
        }
        apply()
    }

    private fun rectInRoot(v: View): RectF {
        val root = IntArray(2)
        val loc = IntArray(2)
        val rootView = tabMorph.parent as View
        rootView.getLocationOnScreen(root)
        // FrameLayout 의 margin 은 padding 안쪽 기준이다. 풀스크린에서는 루트에 상태표시줄만큼 위 여백이 있어서,
        // 이걸 빼지 않으면 전환 그림과 흐린 배경이 그 높이만큼 아래로 내려간다 (팝업 창은 여백이 0 이라 멀쩡했다)
        root[0] += rootView.paddingLeft
        root[1] += rootView.paddingTop
        v.getLocationOnScreen(loc)
        return RectF(
            (loc[0] - root[0]).toFloat(), (loc[1] - root[1]).toFloat(),
            (loc[0] - root[0] + v.width).toFloat(), (loc[1] - root[1] + v.height).toFloat()
        )
    }

    private fun lerp(a: Float, b: Float, p: Float) = a + (b - a) * p

    /**
     * 스냅샷이 from 영역에서 to 영역으로 스프링으로 늘어나거나 줄어든다. (모서리 둥글기도 함께 변함)
     * 페이지 → 탭 카드, 탭 카드 → 페이지 전환에 모두 쓴다.
     */
    private fun runMorph(bmp: Bitmap, from: RectF, to: RectF, r0: Float, r1: Float, onEnd: () -> Unit) {
        tabMorph.scaleType = ImageView.ScaleType.MATRIX
        tabMorph.setImageBitmap(bmp)
        tabMorph.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, morphRadius)
            }
        }
        tabMorph.clipToOutline = true
        Motion.cancel(tabMorph)
        tabMorph.alpha = 1f
        tabMorph.visibility = View.VISIBLE
        val lp = FrameLayout.LayoutParams(1, 1)

        fun apply(p: Float) {
            val l = lerp(from.left, to.left, p)
            val tp = lerp(from.top, to.top, p)
            val w = maxOf(1f, lerp(from.width(), to.width(), p))
            val h = maxOf(1f, lerp(from.height(), to.height(), p))
            lp.leftMargin = l.toInt()
            lp.topMargin = tp.toInt()
            lp.width = w.toInt()
            lp.height = h.toInt()
            tabMorph.layoutParams = lp
            morphRadius = lerp(r0, r1, p.coerceIn(0f, 1f))
            tabMorph.imageMatrix = topCropMatrix(bmp, w.toInt(), h.toInt())
            tabMorph.invalidateOutline()
        }
        apply(0f)

        SpringAnimation(FloatValueHolder(0f))
            .setSpring(SpringForce(1f).setStiffness(320f).setDampingRatio(0.82f))
            .setMinimumVisibleChange(0.002f)
            .addUpdateListener { _, value, _ -> apply(value) }
            .addEndListener { _, _, _, _ ->
                apply(1f)
                onEnd()
            }
            .start()
    }

    private fun hideMorph(fade: Boolean) {
        if (fade && Motion.enabled(this)) {
            Motion.spring(tabMorph, DynamicAnimation.ALPHA, 0f, 700f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                tabMorph.visibility = View.GONE
                tabMorph.alpha = 1f
                tabMorph.setImageDrawable(null)
            }
        } else {
            Motion.cancel(tabMorph)
            tabMorph.visibility = View.GONE
            tabMorph.alpha = 1f
            tabMorph.setImageDrawable(null)
        }
    }

    private fun setupTabSwitcher() {
        tabSwitcher.findViewById<View>(R.id.btnCloseSheet).setOnClickListener { closeTabSwitcher() }
        tabSwitcher.findViewById<Button>(R.id.btnCloseAll).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            closeAllTabs()
            closeTabSwitcher()
        }
        tabSwitcher.findViewById<Button>(R.id.btnNewIncognito).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            openNewTabAndFocus(incognito = true)
            closeTabSwitcher()
        }
        tabSwitcher.findViewById<Button>(R.id.btnNewTab).setOnClickListener {
            if (switcherBusy) return@setOnClickListener
            openNewTabAndFocus()
            closeTabSwitcher()
        }
    }

    // ───────────────────────── 탭 화면 배경 블러 ─────────────────────────

    private val SWITCHER_BLUR_DP = 40
    private var switcherBlurAnim: android.animation.ValueAnimator? = null
    private var switcherBlurRadius = 0f

    /** 탭 화면 뒤의 웹 페이지를 흐리게(유리 느낌) 할 수 있는지. 안 되는 기기는 예전처럼 불투명 배경. */
    // 앱 안에서 그림을 흐리는 RenderEffect 는 창 블러(isCrossWindowBlurEnabled)와 상관없이 Android 12+ 이면 된다.
    // 예전에는 창 블러 허용 여부까지 따졌는데, 팝업(프리폼) 창 등에서 그 값이 false 라 블러가 통째로 꺼졌다.
    private fun switcherGlass() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    /** 뒤쪽 페이지의 블러 반경을 부드럽게 바꾼다 (0 이면 끄기) */
    private fun animateSwitcherBlur(toDp: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val to = Blur.dp(this, toDp).toFloat()
        switcherBlurAnim?.cancel()
        if (!Motion.enabled(this)) {
            switcherBlurRadius = to
            Blur.blurView(browserUi, to)
            return
        }
        switcherBlurAnim = android.animation.ValueAnimator.ofFloat(switcherBlurRadius, to).apply {
            duration = 240
            addUpdateListener {
                switcherBlurRadius = it.animatedValue as Float
                Blur.blurView(browserUi, switcherBlurRadius)
            }
            start()
        }
    }

    private fun clearSwitcherBlur() {
        switcherBlurAnim?.cancel()
        switcherBlurRadius = 0f
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Blur.blurView(browserUi, 0f)
        removeSwitcherBackdrop()
    }

    /**
     * 탭 화면 뒤 배경: 예전에는 웹페이지(WebView) 전체에 실시간 블러를 걸고 반경을 매 프레임 바꿨는데,
     * 전체화면처럼 큰 창에서는 그게 너무 무거워서 전환이 뚝뚝 끊겼다. 이제 페이지를 작게 한 장 찍어
     * 한 번만 흐려 두고, 그 그림의 투명도만 바꿔서 서서히 보이게 한다 (움직이는 동안 블러를 다시 계산하지 않는다).
     */
    private var switcherBackdrop: ImageView? = null

    private fun showSwitcherBackdrop() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        removeSwitcherBackdrop()
        val parent = tabSwitcher.parent as? FrameLayout ?: return
        val w = browserUi.width
        val h = browserUi.height
        if (w <= 0 || h <= 0) return
        val sc = 0.3f
        val bmp = try {
            Bitmap.createBitmap((w * sc).toInt().coerceAtLeast(1), (h * sc).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        } catch (e: Throwable) { return }
        try {
            val c = Canvas(bmp)
            c.drawColor(MaterialColors.getColor(browserUi, com.google.android.material.R.attr.colorSurface))
            c.scale(sc, sc)
            browserUi.draw(c)
        } catch (e: Throwable) { return }
        val r = rectInRoot(browserUi)
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
            alpha = 0f
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            val blur = Blur.dp(this@MainActivity, 56) * sc
            try {
                setRenderEffect(android.graphics.RenderEffect.createBlurEffect(blur, blur, android.graphics.Shader.TileMode.CLAMP))
            } catch (_: Throwable) {}
        }
        parent.addView(
            iv, parent.indexOfChild(tabSwitcher),
            FrameLayout.LayoutParams(w, h).apply { leftMargin = r.left.toInt(); topMargin = r.top.toInt() }
        )
        switcherBackdrop = iv
        if (Motion.enabled(this)) iv.animate().alpha(1f).setDuration(240).start() else iv.alpha = 1f
    }

    private fun fadeOutSwitcherBackdrop() {
        val iv = switcherBackdrop ?: return
        if (Motion.enabled(this)) iv.animate().alpha(0f).setDuration(260).start() else iv.alpha = 0f
    }

    private fun removeSwitcherBackdrop() {
        val iv = switcherBackdrop ?: return
        switcherBackdrop = null
        iv.animate().cancel()
        (iv.parent as? ViewGroup)?.removeView(iv)
        iv.setImageDrawable(null)
    }

    /**
     * 탭 화면 바탕의 반투명 면(흰 막). 전환(카드가 날아가는 동안)에는 없애 두고, 다 열린 뒤에 서서히 입힌다.
     * 예전에는 전환 내내 페이지 위에 반투명 흰 막이 덮여 있어 뿌옇게 보였다.
     */
    private var switcherTintAnim: android.animation.ValueAnimator? = null
    // 0 = 흰 막을 아예 입히지 않는다 (블러만 보임). 막을 다시 쓰려면 0xA0 쯤으로
    private val switcherTintAlpha = 0

    private fun animateSwitcherTint(toAlpha: Int, durationMs: Long) {
        switcherTintAnim?.cancel()
        val base = MaterialColors.getColor(tabSwitcher, com.google.android.material.R.attr.colorSurfaceContainer)
        fun set(a: Int) = tabSwitcher.setBackgroundColor(androidx.core.graphics.ColorUtils.setAlphaComponent(base, a.coerceIn(0, 255)))
        val from = ((tabSwitcher.background as? android.graphics.drawable.ColorDrawable)?.color ?: 0).ushr(24)
        if (!Motion.enabled(this) || durationMs <= 0 || from == toAlpha) { set(toAlpha); return }
        switcherTintAnim = android.animation.ValueAnimator.ofInt(from, toAlpha).apply {
            duration = durationMs
            addUpdateListener { set(it.animatedValue as Int) }
            start()
        }
    }

    private fun openTabSwitcher() {
        if (switcherOpen || switcherBusy) return
        val cur = current ?: return
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)

        val area = webContainer.parent as View
        val shot = captureContent()
        cur.thumb = shot
        val from = rectInRoot(area)

        switcherOpen = true
        updateSecureFlag()
        switcherBusy = true
        updateStatusBarColor()
        refreshSwitcher(animateIn = true, skipEnter = cur)
        tabSwitcher.alpha = 0f
        val glass = switcherGlass()
        switcherTintAnim?.cancel()
        tabSwitcher.setBackgroundColor(
            if (glass) androidx.core.graphics.ColorUtils.setAlphaComponent(
                MaterialColors.getColor(tabSwitcher, com.google.android.material.R.attr.colorSurfaceContainer), 0)
            else Blur.surface(this, com.google.android.material.R.attr.colorSurfaceContainer, false)
        )
        tabSwitcher.visibility = View.VISIBLE

        tabSwitcher.doOnLayout {
            // 실시간 블러: 진짜 페이지 화면에 직접 흐림 효과를 걸고 반경을 키운다 (사진을 찍어 두는 방식 아님)
            if (glass) animateSwitcherBlur(SWITCHER_BLUR_DP)
            val card = switcherRows[cur]
            val thumb = card?.findViewById<ImageView>(R.id.tabThumb)
            if (card != null) {
                val r = Rect()
                card.getDrawingRect(r)
                tabScroll.offsetDescendantRectToMyCoords(card, r)
                tabScroll.scrollTo(0, maxOf(0, r.top - dp(12)))
            }
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 1f, 240f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            if (shot == null || thumb == null || !Motion.enabled(this)) {
                tabSwitcher.alpha = 1f
                if (glass) animateSwitcherTint(switcherTintAlpha, 160) else browserUi.visibility = View.INVISIBLE
                switcherBusy = false
                return@doOnLayout
            }
            val to = rectInRoot(thumb)
            thumb.alpha = 0f
            // 움직이는 동안 진짜 페이지는 숨겨서, 찍어 둔 그림과 겹쳐 두 겹으로 보이는 일이 없게 한다
            if (!glass) (webContainer.parent as? View)?.alpha = 0f
            runMorph(shot, from, to, 0f, dp(10).toFloat()) {
                thumb.alpha = 1f
                hideMorph(false)
                if (glass) animateSwitcherTint(switcherTintAlpha, 160) else browserUi.visibility = View.INVISIBLE
                switcherBusy = false
            }
        }
    }

    /** 탭 화면을 닫는다. target 탭의 카드가 있으면 카드가 펼쳐지며 페이지가 되고, 없으면 부드럽게 사라진다. */
    private fun closeTabSwitcher(target: BrowserTab? = null) {
        if (!switcherOpen || switcherBusy) return
        switcherBusy = true
        updateStatusBarColor(switcher = false)

        val tab = target ?: current ?: tabs.firstOrNull()
        val thumbView = tab?.let { switcherRows[it] }?.findViewById<ImageView>(R.id.tabThumb)
        val bmp = tab?.thumb
        val vis = Rect()
        val canMorph = tab != null && thumbView != null && bmp != null &&
            thumbView.getGlobalVisibleRect(vis) && Motion.enabled(this)
        val from = if (canMorph) rectInRoot(thumbView!!) else null

        if (switcherGlass()) animateSwitcherTint(0, 120)
        val sameTab = tab != null && tab === current
        if (tab != null && tab !== current) selectTab(tab)
        browserUi.visibility = View.VISIBLE
        fadeOutSwitcherBackdrop()
        browserUi.animate().cancel()
        browserUi.alpha = 1f
        // 실시간 블러를 서서히 푼다
        if (switcherGlass()) animateSwitcherBlur(0)
        // 탭 카드를 찍어 둔 뒤 창 크기·여백이 달라졌을 수 있어서, 현재 탭이면 지금 페이지를 새로 찍어
        // 끝 그림이 실제 페이지와 정확히 겹치게 한다 (예전에는 낡은 그림이 어긋난 채 겹쳐 글자가 두 겹으로 보였다)
        val endBmp = if (canMorph && sameTab) (captureContent() ?: bmp) else bmp

        val pageArea = webContainer.parent as? View
        fun finish() {
            pageArea?.alpha = 1f
            browserUi.animate().cancel()
            browserUi.alpha = 1f
            clearSwitcherBlur()
            tabSwitcher.visibility = View.GONE
            tabSwitcher.alpha = 1f
            tabList.removeAllViews()
            switcherRows.clear()
            switcherOpen = false
            updateSecureFlag()
            switcherBusy = false
        }

        if (canMorph && from != null) {
            val to = rectInRoot(webContainer.parent as View)
            thumbView!!.alpha = 0f
            Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            if (!switcherGlass()) pageArea?.alpha = 0f
            runMorph(endBmp!!, from, to, dp(10).toFloat(), 0f) {
                // 그림을 서서히 지우면 진짜 페이지와 겹쳐 두 겹으로 보이므로, 한 프레임에 바로 바꿔 끼운다
                finish()
                hideMorph(false)
            }
        } else {
            // 카드가 없거나 화면 밖: 페이지가 살짝 커지며 나타나고 탭 화면은 사라진다.
            val chrome = browserUi
            if (Motion.enabled(this)) {
                Motion.cancel(chrome)
                chrome.alpha = 0f
                chrome.scaleX = 0.95f
                chrome.scaleY = 0.95f
                Motion.spring(chrome, DynamicAnimation.ALPHA, 1f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
                Motion.spring(chrome, DynamicAnimation.SCALE_X, 1f, 260f, 0.78f)
                Motion.spring(chrome, DynamicAnimation.SCALE_Y, 1f, 260f, 0.78f)
                Motion.spring(tabSwitcher, DynamicAnimation.ALPHA, 0f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
                    finish()
                }
            } else {
                finish()
            }
        }
    }

    /** 탭 화면에서 마지막으로 그린 그룹별 접힘 상태 (화살표가 돌아가는 방향을 정하려고) */
    private val groupRendered = HashMap<Int, Boolean>()
    private var groupToggling = false

    // ───────────────────────── 탭 화면의 창 관리 ─────────────────────────

    /**
     * 탭 화면 위쪽에 열려 있는 창들을 가로로 보여 준다 (창이 2개 이상일 때만).
     * 창을 누르면 그 창으로 가고, 창의 X 를 누르면 그 창을 닫는다. 맨 끝의 "＋ 새 창"으로 창을 더 연다.
     */
    private fun refreshWindowStrip(skip: MainActivity? = null) {
        // 칩을 끄는 중에는 다시 그리지 않는다 (끝나면 endWindowDrag 가 다시 그린다)
        if (wsDragView != null) return
        val strip = tabSwitcher.findViewById<View>(R.id.windowStrip)
        val box = tabSwitcher.findViewById<LinearLayout>(R.id.windowStripList)
        // 다시 그리기 전 칩들의 자리를 기억해 두었다가, 남은 칩은 미끄러지고 새 칩은 톡 나타나게 한다
        val animateChips = strip.visibility == View.VISIBLE && Motion.enabled(this)
        val oldLefts = HashMap<Int, Int>()
        if (animateChips) {
            windowDragChips.forEach { oldLefts[it.second] = it.first.left }
            windowAddChip?.let { oldLefts[-1] = it.left }
        }
        box.removeAllViews()
        windowChips.clear()
        val wins = instances.filter { it !== skip && !it.isFinishing && !it.isDestroyed }
        // 닫았지만 탭이 남아 있는 창들: 눌러서 다시 연다
        val closed = prefs.savedWindowNos().filter { n -> wins.none { it.windowNo == n } && prefs.savedTabCount(n) > 0 }.sorted()
        if (wins.size + closed.size < 2) {
            strip.visibility = View.GONE
            return
        }
        strip.visibility = View.VISIBLE

        val attrSurface = com.google.android.material.R.attr.colorSurface
        val surface = MaterialColors.getColor(box, attrSurface, 0)
        val activeBg = MaterialColors.getColor(box, com.google.android.material.R.attr.colorPrimaryContainer, 0)
        val activeFg = MaterialColors.getColor(box, com.google.android.material.R.attr.colorOnPrimaryContainer, 0)
        val textMain = MaterialColors.getColor(box, com.google.android.material.R.attr.colorOnSurface, 0)
        val textSub = MaterialColors.getColor(box, com.google.android.material.R.attr.colorOnSurfaceVariant, 0)

        fun styled(chip: View, bg: Int) {
            val shape = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(bg) }
            val mask = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFFFFFFFF.toInt()) }
            chip.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x22000000), shape, mask
            )
        }

        windowDragChips.clear()
        windowAddChip = null
        fun addWinChip(w: MainActivity) {
            val chip = layoutInflater.inflate(R.layout.item_window_chip, box, false)
            val me = w === this
            val fg = if (me) activeFg else textMain
            val sub = if (me) activeFg else textSub
            styled(chip, if (me) activeBg else surface)
            chip.findViewById<TextView>(R.id.windowTitle).apply {
                text = if (me) "${w.windowLabel} · 현재" else w.windowLabel
                setTextColor(fg)
            }
            // 다른 창의 시크릿 탭 제목은 보여 주지 않는다
            val cur = w.current
            val pageName = when {
                cur == null || cur.isHome -> "새 탭"
                cur.incognito -> "시크릿 탭"
                else -> w.tabTitle(cur)
            }
            chip.findViewById<TextView>(R.id.windowSub).apply {
                text = "탭 ${w.tabs.size}개 · $pageName"
                setTextColor(sub)
            }
            val close = chip.findViewById<ImageButton>(R.id.windowClose)
            close.imageTintList = android.content.res.ColorStateList.valueOf(sub)
            if (me) {
                // 지금 보고 있는 창은 여기서 닫지 않는다
                close.visibility = View.GONE
                chip.setPadding(chip.paddingLeft, 0, dp(14), 0)
            } else {
                chip.setOnClickListener { bringWindowToFront(w) }
                close.setOnClickListener { confirmCloseWindow(w) }
                windowChips.add(chip to w)
            }
            box.addView(chip)
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 이름 바꾸기
            bindWindowDrag(chip, w.windowNo)
            windowDragChips.add(chip to w.windowNo)
        }

        fun addClosedChip(n: Int) {
            val chip = layoutInflater.inflate(R.layout.item_window_chip, box, false)
            styled(chip, surface)
            chip.alpha = 0.7f
            chip.findViewById<TextView>(R.id.windowTitle).apply { text = prefs.windowName(n) ?: "창 $n"; setTextColor(textMain) }
            chip.findViewById<TextView>(R.id.windowSub).apply {
                text = "탭 ${prefs.savedTabCount(n)}개 · 닫힌 창"
                setTextColor(textSub)
            }
            chip.findViewById<View>(R.id.windowClose).visibility = View.GONE
            chip.setPadding(chip.paddingLeft, 0, dp(14), 0)
            chip.setOnClickListener { openNewWindow(restoreNo = n) }
            box.addView(chip)
            bindWindowDrag(chip, n)
            windowDragChips.add(chip to n)
        }

        // 저장된 순서대로 (순서가 없는 창은 원래 순서 그대로 뒤에)
        val order = prefs.windowOrder()
        val entries = ArrayList<Pair<Int, MainActivity?>>()
        wins.forEach { entries.add(it.windowNo to it) }
        closed.forEach { entries.add(it to null) }
        entries.sortedBy { e -> order.indexOf(e.first).let { if (it < 0) Int.MAX_VALUE else it } }
            .forEach { (n, w) -> if (w != null) addWinChip(w) else addClosedChip(n) }

        // 맨 끝: 새 창
        val add = layoutInflater.inflate(R.layout.item_window_chip, box, false)
        styled(add, surface)
        add.findViewById<TextView>(R.id.windowTitle).apply { text = "＋ 새 창"; setTextColor(textMain) }
        add.findViewById<View>(R.id.windowSub).visibility = View.GONE
        add.findViewById<View>(R.id.windowClose).visibility = View.GONE
        add.setPadding(dp(16), 0, dp(16), 0)
        add.setOnClickListener { openNewWindow() }
        windowChips.add(add to null)
        box.addView(add)
        windowAddChip = add

        if (animateChips) {
            val fresh = ArrayList<Pair<View, Int>>(windowDragChips)
            fresh.add(Pair(add, -1))
            box.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    box.viewTreeObserver.removeOnPreDrawListener(this)
                    fresh.forEach { (v, no) ->
                        val old = oldLefts[no]
                        if (old == null) {
                            // 새로 생긴 창
                            if (no != -1) Motion.pop(v, 0.8f)
                        } else if (old != v.left) {
                            v.translationX = (old - v.left).toFloat()
                            Motion.spring(v, DynamicAnimation.TRANSLATION_X, 0f, 380f, 0.8f)
                        }
                    }
                    return true
                }
            })
        }
    }

    // ── 탭 화면의 창 칩 끌어서 순서 바꾸기 (상단 탭 줄과 같은 방식) ──

    /** 지금 그려진 창 칩들 (화면 순서대로, "＋ 새 창"은 제외) */
    private val windowDragChips = ArrayList<Pair<View, Int>>()
    private var windowAddChip: View? = null
    private var wsDragView: View? = null
    private var wsDragNo = 0
    private var wsGrab = 0f
    private var wsRawX = 0f
    private var wsSwapped = false

    private fun bindWindowDrag(chip: View, no: Int) {
        bindDragGesture(
            chip, null,
            onStart = { x, _ -> startWindowDrag(chip, no, x) },
            onMove = { x, _ -> wsRawX = x; updateWindowDrag() },
            onEnd = { moved, canceled -> endWindowDrag(moved, canceled) }
        )
    }

    /** 끌고 있는 칩이 창 목록의 양 끝에 가까워지면 목록이 그쪽으로 스크롤된다 */
    private val wsAutoScroll = object : Runnable {
        override fun run() {
            if (wsDragView == null) return
            val strip = tabSwitcher.findViewById<android.widget.HorizontalScrollView>(R.id.windowStrip)
            val loc = IntArray(2)
            strip.getLocationOnScreen(loc)
            val rel = wsRawX - loc[0]
            val edge = dp(56).toFloat()
            val w = strip.width
            val dx = when {
                rel < edge -> -(edge - rel) / edge * dp(14)
                rel > w - edge -> (rel - (w - edge)) / edge * dp(14)
                else -> 0f
            }
            if (dx != 0f) {
                val step = if (dx > 0) maxOf(1, dx.toInt()) else minOf(-1, dx.toInt())
                val before = strip.scrollX
                strip.scrollBy(step, 0)
                if (strip.scrollX != before) updateWindowDrag()
            }
            strip.postOnAnimation(this)
        }
    }

    private fun windowBox() = tabSwitcher.findViewById<LinearLayout>(R.id.windowStripList)

    private fun startWindowDrag(chip: View, no: Int, rawX: Float): Boolean {
        if (wsDragView != null || swDrag != null || switcherBusy) return false
        if (windowDragChips.none { it.first === chip }) return false
        val box = windowBox()
        wsDragView = chip
        wsDragNo = no
        wsSwapped = false
        wsRawX = rawX
        val loc = IntArray(2)
        box.getLocationOnScreen(loc)
        wsGrab = rawX - loc[0] - chip.left
        chip.translationZ = dp(8).toFloat()
        chip.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        // 집어 올리면 살짝 커지며 떠오른다
        Motion.spring(chip, DynamicAnimation.SCALE_X, 1.07f, 620f, 0.6f)
        Motion.spring(chip, DynamicAnimation.SCALE_Y, 1.07f, 620f, 0.6f)
        // 끄는 칩이 가장자리에서 잘리지 않게
        box.clipChildren = false
        tabSwitcher.findViewById<View>(R.id.windowStrip).postOnAnimation(wsAutoScroll)
        return true
    }

    /** 손가락 위치만으로 계산한 칩의 왼쪽 (목록 안쪽 좌표) */
    private fun wsDragRaw(): Float {
        val loc = IntArray(2)
        windowBox().getLocationOnScreen(loc)
        return wsRawX - loc[0] - wsGrab
    }

    private fun updateWindowDrag() {
        val v = wsDragView ?: return
        if (v.parent == null) { wsDragView = null; return }
        // "＋ 새 창" 칩 앞까지만 움직일 수 있다
        val maxLeft = ((windowAddChip?.left ?: windowBox().width) - v.width).coerceAtLeast(0)
        val want = wsDragRaw().coerceIn(0f, maxLeft.toFloat())
        v.translationX = want - v.left
        // 순서를 바꿀지는 제한하기 전의 손가락 위치로 판단한다 (맨 앞/맨 뒤 칩과도 자리를 바꿀 수 있게)
        val cx = wsDragRaw() + v.width / 2f
        val i = windowDragChips.indexOfFirst { it.first === v }
        if (i < 0) return
        val next = windowDragChips.getOrNull(i + 1)?.first
        val prev = windowDragChips.getOrNull(i - 1)?.first
        when {
            next != null && cx > next.left + next.width / 2f -> swapWindowChip(i, 1)
            prev != null && cx < prev.left + prev.width / 2f -> swapWindowChip(i, -1)
        }
    }

    /** 끌고 있는 칩은 그대로 두고, 이웃 칩만 반대편으로 옮긴다 (미끄러지듯 자리를 옮긴다) */
    private fun swapWindowChip(i: Int, dir: Int) {
        val box = windowBox()
        val v = windowDragChips[i].first
        val nbPair = windowDragChips[i + dir]
        val nb = nbPair.first
        val oldLeft = nb.left
        windowDragChips[i + dir] = windowDragChips[i]
        windowDragChips[i] = nbPair
        wsSwapped = true
        box.removeView(nb)
        box.addView(nb, if (dir > 0) box.indexOfChild(v) else box.indexOfChild(v) + 1)
        box.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                box.viewTreeObserver.removeOnPreDrawListener(this)
                val dx = oldLeft - nb.left
                if (dx != 0) {
                    nb.translationX = dx + nb.translationX
                    Motion.spring(nb, DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.8f)
                }
                if (wsDragView === v) {
                    val maxLeft = ((windowAddChip?.left ?: box.width) - v.width).coerceAtLeast(0)
                    v.translationX = wsDragRaw().coerceIn(0f, maxLeft.toFloat()) - v.left
                }
                return true
            }
        })
    }

    private fun endWindowDrag(moved: Boolean, canceled: Boolean) {
        val v = wsDragView ?: return
        val no = wsDragNo
        wsDragView = null
        val strip = tabSwitcher.findViewById<View>(R.id.windowStrip)
        strip.removeCallbacks(wsAutoScroll)
        // 놓으면 제자리로 탄성 있게 안착한다
        Motion.spring(v, DynamicAnimation.TRANSLATION_X, 0f, 460f, 0.78f)
        Motion.spring(v, DynamicAnimation.SCALE_X, 1f, 520f, 0.6f)
        Motion.spring(v, DynamicAnimation.SCALE_Y, 1f, 520f, 0.6f) { v.translationZ = 0f }
        if (wsSwapped) {
            // 새 순서를 저장하고, 탭 화면이 열려 있는 다른 창들도 같은 순서로 다시 그린다
            prefs.setWindowOrder(windowDragChips.map { it.second })
            notifyOtherWindows()
        }
        // 안착하는 동안은 그대로 두고, 끝난 뒤 목록을 새로 그린다 (바로 그리면 안착 모션이 끊긴다)
        ui.postDelayed({ if (switcherOpen && wsDragView == null) refreshWindowStrip() }, 320)
        // 끌지 않고 그냥 뗐으면 예전처럼 이름 바꾸기
        if (!canceled && !moved && !wsSwapped) showRenameWindow(no)
    }

    /** 창 이름 바꾸기. 비워 두고 저장하면 기본 이름("창 N")으로 돌아간다 */
    private fun showRenameWindow(no: Int) {
        val et = EditText(this).apply {
            setText(prefs.windowName(no) ?: "")
            hint = "창 $no"
            setSingleLine()
            filters = arrayOf(android.text.InputFilter.LengthFilter(20))
            setSelection(text.length)
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun save() {
            prefs.setWindowName(no, et.text.toString().trim().ifEmpty { null })
            if (switcherOpen) refreshWindowStrip()
            notifyOtherWindows()
        }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("창 이름 바꾸기")
            .setView(box)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ -> save() }
            .create()
        et.setOnEditorActionListener { _, _, _ -> save(); dlg.dismiss(); true }
        dlg.show()
        et.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** 탭 화면의 창 칩들: 탭 카드를 끌어다 놓을 수 있는 자리 (창 = 그 창으로, null = 새 창) */
    private val windowChips = ArrayList<Pair<View, MainActivity?>>()

    private fun windowChipAt(x: Float, y: Float): Pair<View, MainActivity?>? {
        // x, y 는 화면 전체 기준(rawX/rawY)이다. getGlobalVisibleRect 는 '창 안' 좌표라서
        // 분할 화면·프리폼처럼 창이 화면 모서리에 붙어 있지 않으면 어긋난다 → 화면 좌표로 맞춰서 비교한다.
        val strip = tabSwitcher.findViewById<View>(R.id.windowStrip)
        val sl = IntArray(2)
        strip.getLocationOnScreen(sl)
        val stripRect = Rect(sl[0], sl[1], sl[0] + strip.width, sl[1] + strip.height)
        val loc = IntArray(2)
        val r = Rect()
        val m = dp(6)
        for (p in windowChips) {
            val c = p.first
            if (!c.isShown) continue
            c.getLocationOnScreen(loc)
            r.set(loc[0], loc[1], loc[0] + c.width, loc[1] + c.height)
            // 가로로 스크롤돼 가려진 칩은 제외
            if (!r.intersect(stripRect)) continue
            r.inset(-m, -m)
            if (r.contains(x.toInt(), y.toInt())) return p
        }
        return null
    }

    private fun setWinHighlight(chip: View, on: Boolean) {
        val s = if (on) 1.08f else 1f
        chip.animate().scaleX(s).scaleY(s).setDuration(140).start()
    }

    /**
     * 다른 창(또는 새 창)에서 넘어온 탭을 이 창에 만든다.
     * 웹 기록·확대 비율·스크롤 위치를 그대로 이어받는다. [select] 가 false 면 보고 있던 탭은 그대로 두고, 고르면 그때 불러온다.
     */
    private fun receiveTab(h: TabHandoff, select: Boolean = false) {
        val t = createTab(null, select = false, home = h.url == null, incognito = h.incognito, lazy = !select)
        t.desktop = h.desktop
        t.pageZoom = h.pageZoom
        t.muted = h.muted
        t.rate = h.rate
        if (h.url != null) {
            t.pendingUrl = h.url
            t.pendingTitle = h.title
            t.pendingState = h.state
            t.pendingScrollRatio = h.scrollRatio
            t.pendingScrollX = h.scrollX
            t.pendingScrollY = h.scrollY
        }
        if (select) selectTab(t)
        saveTabs()
        if (switcherOpen) refreshSwitcher(false)
    }

    /**
     * 되살아난 탭의 스크롤을 맞춘다. 창 크기가 달라졌거나 확대 비율을 다시 적용해 내용이 다시 배치되어도
     * 같은 자리를 보도록, 페이지가 다 불러와진 뒤 비율로 두 번 맞춘다. 그 사이 사용자가 만지면 멈춘다.
     */
    private fun restoreHandoffScroll(tab: BrowserTab, wv: WebView) {
        if (!tab.restoreScrollPending) return
        tab.restoreScrollPending = false
        val ratio = tab.pendingScrollRatio
        val sx = tab.pendingScrollX
        val sy = tab.pendingScrollY
        tab.pendingScrollRatio = -1f
        tab.pendingScrollX = 0
        tab.pendingScrollY = 0
        val touchMark = lastTouchAt
        fun apply() {
            if (isFinishing || isDestroyed || tab.liveWebView !== wv || lastTouchAt != touchMark) return
            if (ratio >= 0f) {
                @Suppress("DEPRECATION")
                val max = (wv.contentHeight * wv.scale).toInt() - wv.height
                val y = if (max > 0) (ratio * max).toInt() else 0
                if (kotlin.math.abs(wv.scrollY - y) > dp(2)) wv.scrollTo(sx, y)
            } else if (wv.scrollX != sx || wv.scrollY != sy) {
                wv.scrollTo(sx, sy)
            }
            if (tab === current) pageScrollBar.refresh()
        }
        // 확대 비율 스크립트가 들어가 다시 배치된 뒤에 맞춘다
        wv.postDelayed({ apply() }, 250)
        wv.postDelayed({ apply() }, 800)
        wv.postDelayed({ apply() }, 1600)
    }

    /** 이 탭의 현재 상태(웹 기록·확대·스크롤 등)를 다른 창으로 들고 갈 수 있게 담는다. 탭을 닫기 전에 불러야 한다 */
    private fun captureHandoff(tab: BrowserTab): TabHandoff {
        val lw = tab.liveWebView
        val live = lw?.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        val url = if (tab.isHome) null else (live ?: tab.pendingUrl)
        val title = (if (live != null) lw?.title else tab.pendingTitle)?.takeIf { it.isNotBlank() }
        var state: Bundle? = null
        var ratio = -1f
        var sx = 0
        var sy = 0
        if (url != null) {
            if (live != null && lw != null) {
                val b = Bundle()
                if (runCatching { lw.saveState(b) }.getOrNull() != null) state = b
                sx = lw.scrollX
                sy = lw.scrollY
                // 화면에 붙어 있을 때만 현재 비율을 믿을 수 있다 (떼어 둔 웹뷰는 높이가 0)
                ratio = if (lw.height > 0) scrollRatioOf(lw) else tab.scrollRatio
            } else {
                // 아직 불러오지 않은 채 넘겨받아 두었던 탭이면 받은 상태를 그대로 다시 넘긴다
                state = tab.pendingState
                ratio = tab.pendingScrollRatio
                sx = tab.pendingScrollX
                sy = tab.pendingScrollY
            }
        }
        return TabHandoff(
            url = url, title = title, desktop = tab.desktop, incognito = tab.incognito,
            pageZoom = tab.pageZoom, muted = tab.muted, rate = tab.rate,
            state = state, scrollRatio = ratio, scrollX = sx, scrollY = sy
        )
    }

    /** [target] 창으로 탭을 옮긴다 (null 이면 새 창을 열어 거기로). 이 창에서는 탭이 닫힌다. 옮겼으면 true */
    private fun moveTabToWindow(
        tab: BrowserTab,
        target: MainActivity?,
        mode: Int = WIN_DEFAULT,
        dropX: Int = 0,
        dropY: Int = 0,
        closeEmptyWindow: Boolean = false,
        selectInTarget: Boolean = false
    ): Boolean {
        if (target == null && tab.incognito) {
            toast("시크릿 탭은 새 창으로 옮길 수 없어요")
            return false
        }
        if (target != null && (target.isFinishing || target.isDestroyed)) return false
        // 탭을 닫기 전에 상태를 먼저 담는다
        val h = captureHandoff(tab)
        val closeWindow = tabs.size == 1 && (target != null || closeEmptyWindow)
        if (target == null) {
            openNewWindow(
                h.url, handoff = h, mode = mode, dropX = dropX, dropY = dropY,
                inheritNo = if (closeWindow) windowNo else 0
            )
        } else target.receiveTab(h, select = selectInTarget)
        // 다른 창으로 옮기다 이 창이 비면 창도 닫는다. 메뉴로 새 창에 옮길 때는 이 창에 새(홈) 탭을 남기고,
        // 탭을 끌어서 새 창으로 뺄 때는 closeEmptyWindow 로 빈 창을 같이 닫는다
        closeTab(tab, quitIfLast = closeWindow)
        if (closeWindow) return true
        toast(
            when {
                target != null -> "탭을 ${target.windowLabel}(으)로 옮겼어요"
                mode == WIN_POPUP -> "팝업 창으로 옮겼어요"
                else -> "새 창으로 옮겼어요"
            }
        )
        return true
    }

    /** 탭을 옮길 창을 고른다: 열려 있는 다른 창들을 앱 공통 팝업(메뉴와 같은 모양)으로 보여 준다 */
    private fun showMoveTabChooser(
        tab: BrowserTab,
        windows: List<MainActivity>,
        canNewWindow: Boolean,
        onChanged: () -> Unit
    ) {
        fun move(target: MainActivity?) {
            // 고르는 사이 대상 창이 닫혔을 수 있다
            if (target != null && (target.isFinishing || target.isDestroyed)) {
                toast("그 창은 이미 닫혔어요")
                return
            }
            if (moveTabToWindow(tab, target)) onChanged()
        }
        val items = ArrayList<Popup.Item>()
        windows.forEach { w ->
            items.add(Popup.Item(R.drawable.ic_tab, w.windowLabel, "탭 ${w.tabs.size}개") { move(w) })
        }
        if (canNewWindow) {
            items.add(Popup.Item(R.drawable.ic_add, "새 창", "이 탭만 담은 새 창을 엽니다") { move(null) })
        }
        Popup.menu(
            this,
            title = "탭을 다른 창으로 이동",
            subtitle = tabTitle(tab),
            headerIcon = R.drawable.ic_tab,
            items = items
        )
    }

    /** 다른 창을 맨 앞으로 가져온다 */
    @Suppress("DEPRECATION")
    private fun bringWindowToFront(w: MainActivity) {
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
            val target = am.appTasks.firstOrNull { t ->
                val info = t.taskInfo
                val id = if (Build.VERSION.SDK_INT >= 29) info.taskId else info.id
                id == w.taskId
            }
            if (target != null) target.moveToFront() else toast("창을 찾지 못했어요")
        } catch (e: Throwable) {
            toast("창을 전환하지 못했어요")
        }
    }

    /** 창 닫기: 안에 열린 페이지가 있으면 한 번 물어본다 */
    private fun confirmCloseWindow(w: MainActivity) {
        val pages = w.tabs.count { !it.isHome }
        fun doClose() {
            w.finishAndRemoveTask()
            refreshWindowStrip(skip = w)
        }
        // 이름을 붙인 창은 빈 창이어도 한 번 더 물어본다
        val named = w.windowName != null
        if (pages == 0 && !named) {
            doClose()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("${w.windowLabel} 닫기")
            .setMessage(
                if (pages == 0) "이 창을 닫을까요?"
                else "창만 닫혀요. 탭 ${w.tabs.size}개는 남아 있어서 창 목록에서 다시 열 수 있어요."
            )
            .setNegativeButton("취소", null)
            .setPositiveButton("창 닫기") { _, _ -> doClose() }
            .show()
    }

    private fun refreshSwitcher(animateIn: Boolean, skipEnter: BrowserTab? = null) {
        scheduleStripRefresh()

        // 다시 그리기 전 위치를 기억해 두었다가, 남은 카드들이 미끄러지듯 새 자리로 이동하게 한다.
        val before = HashMap<BrowserTab, Pair<Int, Int>>()
        if (!animateIn) {
            val loc = IntArray(2)
            switcherRows.forEach { (tb, v) ->
                v.getLocationOnScreen(loc)
                before[tb] = loc[0] to loc[1]
            }
        }
        switcherRows.clear()
        switcherBoxes.clear()
        tabList.removeAllViews()
        tabsTitle.text = "탭 (${tabs.size})"
        refreshWindowStrip()
        val list = tabList

        var pending: LinearLayout? = null
        // 카드/헤더를 붙이는 곳: 평소엔 목록 자체, 그룹을 그리는 동안엔 그 그룹의 둥근 상자
        var target: LinearLayout = list
        var enterIndex = 0

        // 정사각형 카드: 폰은 2열, 화면이 넓을수록 열이 늘어난다 (카드가 너무 커지지 않도록).
        val cols = switcherCols()

        fun flushRow() {
            val p = pending ?: return
            while (p.childCount < cols) {
                p.addView(
                    View(this),
                    LinearLayout.LayoutParams(0, 1, 1f).apply { setMargins(dp(6), 0, dp(6), 0) }
                )
            }
            pending = null
        }

        fun addCell(v: View) {
            var p = pending
            if (p == null || p.childCount >= cols) {
                p = LinearLayout(this)
                p.orientation = LinearLayout.HORIZONTAL
                p.clipChildren = false
                p.tag = CARD_ROW_TAG
                // 그룹 상자 안은 상자 여백이 있어서 카드가 바깥 카드와 같은 선에 맞도록 여백을 줄인다
                val side = if (target === list) dp(12) else dp(4)
                target.addView(
                    p,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(side, 0, side, 0) }
                )
                pending = p
            }
            p.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            )
        }

        fun addTabRow(tab: BrowserTab, group: TabGroup?) {
            val row = layoutInflater.inflate(R.layout.item_tab, list, false)
            switcherRows[tab] = row
            row.findViewById<TextView>(R.id.tabTitle).text =
                if (tab.isHome) (if (tab.incognito) "시크릿 탭" else "새 탭")
                else tabTitle(tab)
            val fav = row.findViewById<ImageView>(R.id.tabFavicon)
            val bmp = if (tab.isHome) null else tab.favicon
            if (tab.incognito) {
                // 시크릿 탭 카드는 어둡게, 아이콘은 시크릿 모양으로
                row.findViewById<TextView>(R.id.tabTitle).setTextColor(incognitoTextColor)
                row.findViewById<ImageView>(R.id.tabClose).imageTintList =
                    android.content.res.ColorStateList.valueOf(incognitoTextColor)
                fav.setImageResource(R.drawable.ic_incognito)
                fav.imageTintList = android.content.res.ColorStateList.valueOf(incognitoTextColor)
            } else if (bmp != null) fav.setImageBitmap(bmp) else fav.setImageResource(R.drawable.ic_leaf_pixel)
            setThumb(row.findViewById(R.id.tabThumb), tab.thumb)

            val bar = row.findViewById<View>(R.id.tabGroupBar)
            if (group != null) {
                bar.visibility = View.VISIBLE
                bar.background.mutate().setTint(group.color)
            } else {
                bar.visibility = View.GONE
            }

            row.setBackgroundResource(
                when {
                    tab.incognito && tab === current -> R.drawable.bg_tab_card_incognito_active
                    tab.incognito -> R.drawable.bg_tab_card_incognito
                    tab === current -> R.drawable.bg_tab_card_active
                    else -> R.drawable.bg_tab_card
                }
            )
            row.setOnClickListener { closeTabSwitcher(tab) }
            // 길게 눌러 끌면 순서 바꾸기, 끌지 않고 떼면 탭 메뉴
            bindDragGesture(
                row, 0.96f,
                onStart = { x, y -> startSwitcherDrag(tab, x, y) },
                onMove = { x, y -> swDrag?.let { it.rawX = x; it.rawY = y; updateSwitcherDrag() } },
                onEnd = { moved, canceled -> endSwitcherDrag(moved, canceled) },
                // 카드를 옆으로 밀어서 닫기 (X 버튼과 같은 동작)
                onSwipeDismiss = {
                    if (!switcherBusy) {
                        // 탭 목록 화면에서는 마지막 탭을 닫아도 앱을 끄지 않고 빈 새 탭(홈)만 남긴다
                        closeTab(tab, quitIfLast = false)
                        refreshSwitcher(false)
                    }
                },
                canSwipe = { !switcherBusy && !groupToggling && swDrag == null }
            )
            row.findViewById<ImageButton>(R.id.tabClose).setOnClickListener {
                if (switcherBusy) return@setOnClickListener
                it.isEnabled = false
                Motion.flyAway(row) {
                    closeTab(tab, quitIfLast = false)
                    refreshSwitcher(false)
                }
            }
            if (animateIn && tab !== skipEnter) {
                Motion.enter(row, minOf(enterIndex++ * 45L + 80L, 380L))
            }
            addCell(row)
        }

        fun addGroupHeader(group: TabGroup) {
            val header = layoutInflater.inflate(R.layout.item_group_header, target, false)
            val members = tabs.filter { it.groupId == group.id }
            header.findViewById<View>(R.id.groupDot).background.mutate().setTint(group.color)
            header.findViewById<TextView>(R.id.groupName).text = group.name
            // 개수: 그룹 색을 옅게 깐 알약 모양
            header.findViewById<TextView>(R.id.groupCount).apply {
                text = "${members.size}"
                setPadding(dp(9), dp(2), dp(9), dp(2))
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor(ColorUtils.setAlphaComponent(group.color, 0x40))
                }
            }
            // 접혀 있을 때는 안에 든 탭들의 아이콘을 작게 겹쳐 보여 준다
            val surfaceColor = MaterialColors.getColor(header, com.google.android.material.R.attr.colorSurface, 0)
            header.findViewById<LinearLayout>(R.id.groupPreview).apply {
                removeAllViews()
                if (group.collapsed) {
                    members.take(3).forEachIndexed { i, t ->
                        addView(ImageView(this@MainActivity).apply {
                            val bmp = if (t.isHome) null else t.favicon
                            if (bmp != null) setImageBitmap(bmp) else setImageResource(
                                if (t.isHome) R.drawable.ic_leaf_pixel else R.drawable.ic_globe
                            )
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            setPadding(dp(2), dp(2), dp(2), dp(2))
                            background = GradientDrawable().apply {
                                shape = GradientDrawable.OVAL
                                setColor(surfaceColor)
                                setStroke(dp(1), group.color)
                            }
                        }, LinearLayout.LayoutParams(dp(20), dp(20)).apply {
                            if (i > 0) marginStart = -dp(6)
                        })
                    }
                    visibility = View.VISIBLE
                } else {
                    visibility = View.GONE
                }
            }
            // 펼침/접힘 화살표: 이전 상태에서 새 상태로 부드럽게 돌아간다
            val chevron = header.findViewById<ImageView>(R.id.groupChevron)
            val goal = if (group.collapsed) 0f else 180f
            val prev = groupRendered[group.id]
            if (prev != null && prev != group.collapsed && Motion.enabled(this)) {
                chevron.rotation = if (prev) 0f else 180f
                Motion.spring(chevron, DynamicAnimation.ROTATION, goal, 300f, 0.6f)
                Motion.pop(header.findViewById(R.id.groupCount), 0.7f)
            } else {
                chevron.rotation = goal
            }
            groupRendered[group.id] = group.collapsed
            header.setOnClickListener {
                if (groupToggling) return@setOnClickListener
                if (!group.collapsed && Motion.enabled(this)) {
                    // 접을 때: 카드들이 먼저 작아지며 사라진 뒤 목록을 다시 그린다
                    groupToggling = true
                    members.forEach { m ->
                        switcherRows[m]?.animate()?.alpha(0f)?.scaleX(0.85f)?.scaleY(0.85f)?.setDuration(140)?.start()
                    }
                    ui.postDelayed({
                        group.collapsed = true
                        groupToggling = false
                        refreshSwitcher(false)
                    }, 150)
                } else {
                    group.collapsed = !group.collapsed
                    refreshSwitcher(false)
                }
            }
            header.findViewById<ImageButton>(R.id.groupMenu).setOnClickListener {
                showGroupMenu(group, true) { refreshSwitcher(false) }
            }
            Motion.pressable(header, 0.98f)
            flushRow()
            target.addView(header)
        }

        /** 그룹을 담는 둥근 상자: 그룹 색을 옅게 깔고 테두리를 둘러 같은 그룹임을 한눈에 보여 준다 */
        fun newGroupBox(group: TabGroup): LinearLayout {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(0, dp(2), 0, dp(6))
            box.background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(ColorUtils.setAlphaComponent(group.color, 0x24))
                setStroke(dp(1), ColorUtils.setAlphaComponent(group.color, 0x66))
            }
            box.clipToOutline = true
            switcherBoxes[group.id] = box
            list.addView(
                box,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(8), dp(6), dp(8), dp(6)) }
            )
            return box
        }

        // 탭 순서대로 훑으면서, 그룹은 처음 나온 자리에 헤더 + 소속 탭을 한 번에 그린다.
        val drawn = mutableSetOf<Int>()
        tabs.toList().forEach { tab ->
            val g = groupOf(tab)
            if (g == null) {
                addTabRow(tab, null)
            } else if (drawn.add(g.id)) {
                flushRow()
                target = newGroupBox(g)
                addGroupHeader(g)
                if (!g.collapsed) {
                    tabs.filter { it.groupId == g.id }.forEach { addTabRow(it, g) }
                }
                flushRow()
                target = list
            }
        }
        flushRow()
        if (!animateIn) {
            Motion.glideFrom(list, before.mapNotNull { (tb, pos) -> switcherRows[tb]?.let { it to pos } }.toMap())
            // 그룹을 펼칠 때처럼 새로 나타나는 카드는 차례로 떠오르게 한다
            if (before.isNotEmpty()) {
                var i = 0
                switcherRows.forEach { (tb, row) ->
                    if (tb !in before) Motion.enter(row, minOf(i++ * 45L + 30L, 300L))
                }
            }
        }
    }

    private fun closeAllTabs() {
        val old = tabs.toList()
        createTab(null, home = true)
        old.forEach { closeTab(it) }
    }

    private fun openNewTabAndFocus(opener: BrowserTab? = null, incognito: Boolean = false) {
        val custom = prefs.homepage
        if (custom.isNotEmpty() && prefs.homepageOnNewTab && !incognito) {
            createTab(custom, opener = opener)
            hideKeyboard()
            return
        }
        createTab(null, opener = opener, home = true, incognito = incognito)
        // 새 탭(홈)에서 키보드가 저절로 올라오지 않게 한다. 입력하려면 검색창을 누르면 된다.
        hideKeyboard()
    }

    // ───────────────────────── 웹뷰 설정 ─────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    // ───────────────────────── 웹 대화상자 · 권한 · 인증 · 렌더러 복구 ─────────────────────────

    // ── JS 알림창 (alert / confirm / prompt) ──

    /** 보이는 탭에서만 띄우고, 짧은 시간에 계속 띄우는 페이지(알림창 도배)는 막는다 */
    private fun jsDialogAllowed(tab: BrowserTab): Boolean {
        if (tab !== current || isFinishing || isDestroyed || switcherOpen) return false
        val now = android.os.SystemClock.uptimeMillis()
        if (now - tab.jsDialogAt > 4000L) tab.jsDialogCount = 0
        tab.jsDialogAt = now
        return ++tab.jsDialogCount <= 3
    }

    private fun jsDialogTitle(url: String?): String {
        val host = runCatching { Uri.parse(url).host }.getOrNull()
        return if (host.isNullOrBlank()) "페이지 메시지" else "$host 의 메시지"
    }

    /** kind: 0 = alert, 1 = confirm, 2 = prompt */
    private fun showJsDialog(
        url: String?, message: String?, kind: Int,
        defaultValue: String?, result: android.webkit.JsResult
    ) {
        var done = false
        fun finish(ok: Boolean, text: String? = null) {
            if (done) return
            done = true
            try {
                if (ok) {
                    if (result is android.webkit.JsPromptResult) result.confirm(text ?: "") else result.confirm()
                } else {
                    result.cancel()
                }
            } catch (e: Exception) {
                // 페이지가 이미 사라졌으면 무시
            }
        }
        val b = MaterialAlertDialogBuilder(this).setTitle(jsDialogTitle(url))
        var input: EditText? = null
        if (kind == 2) {
            val pad = dp(20)
            val box = FrameLayout(this)
            val field = EditText(this).apply {
                setText(defaultValue.orEmpty())
                setSelectAllOnFocus(true)
                setSingleLine()
            }
            Popup.styleInput(field)
            input = field
            box.setPadding(pad, dp(4), pad, 0)
            box.addView(field)
            b.setMessage(message.orEmpty()).setView(box)
        } else {
            b.setMessage(message.orEmpty())
        }
        b.setPositiveButton("확인") { _, _ -> finish(true, input?.text?.toString()) }
        if (kind != 0) b.setNegativeButton("취소") { _, _ -> finish(false) }
        // 뒤로가기/바깥 터치: alert 는 '확인'으로, confirm/prompt 는 '취소'로 처리
        b.setOnCancelListener { finish(kind == 0) }
        b.setOnDismissListener { finish(false) }
        b.show()
    }

    // ── 카메라 · 마이크 · 위치 권한 ──

    private val webPermDecisions = HashMap<String, Boolean>()
    private var webPermDialog: AlertDialog? = null
    private var webPermDone: (() -> Unit)? = null
    private val webPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val cb = webPermDone
            webPermDone = null
            cb?.invoke()
        }

    /**
     * 사이트가 카메라/마이크/위치를 쓰려 할 때: 사이트별로 허용/차단을 묻고(이번 실행 동안 기억),
     * 안드로이드 권한이 없으면 시스템 권한 창을 이어서 띄운다. anyOf: 목록 중 하나만 허용돼도 충분한지(위치).
     */
    private fun askWebPermission(
        origin: String, label: String, osPerms: List<String>, anyOf: Boolean, onDone: (Boolean) -> Unit
    ) {
        fun osOk() = if (anyOf) osPerms.any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        else osPerms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

        fun withOs() {
            if (osOk()) { onDone(true); return }
            webPermDone?.invoke()
            webPermDone = { onDone(osOk()) }
            webPermLauncher.launch(osPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray())
        }

        val key = "$origin|$label"
        when (webPermDecisions[key]) {
            true -> { withOs(); return }
            false -> { onDone(false); return }
            null -> Unit
        }
        if (isFinishing || isDestroyed) { onDone(false); return }
        webPermDialog?.dismiss()
        var answered = false
        val host = runCatching { Uri.parse(origin).host }.getOrNull() ?: origin
        webPermDialog = MaterialAlertDialogBuilder(this)
            .setTitle(host)
            .setMessage("이 사이트가 ${label}을(를) 사용하려고 합니다. 허용할까요?")
            .setPositiveButton("허용") { _, _ ->
                answered = true
                webPermDecisions[key] = true
                withOs()
            }
            .setNegativeButton("차단") { _, _ ->
                answered = true
                webPermDecisions[key] = false
                onDone(false)
            }
            .setOnDismissListener { if (!answered) onDone(false) }
            .show()
    }

    private fun handleWebPermissionRequest(request: android.webkit.PermissionRequest) {
        val res = request.resources.toList()
        val cam = android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE in res
        val mic = android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE in res
        val granted = ArrayList<String>()
        // 보호된 콘텐츠(DRM) 재생은 그대로 허용
        if (android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID in res) {
            granted.add(android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID)
        }
        if (!cam && !mic) {
            try {
                if (granted.isEmpty()) request.deny() else request.grant(granted.toTypedArray())
            } catch (e: Exception) { }
            return
        }
        val os = ArrayList<String>()
        if (cam) os.add(Manifest.permission.CAMERA)
        if (mic) os.add(Manifest.permission.RECORD_AUDIO)
        val label = when {
            cam && mic -> "카메라와 마이크"
            cam -> "카메라"
            else -> "마이크"
        }
        askWebPermission(request.origin.toString(), label, os, anyOf = false) { ok ->
            try {
                if (ok) {
                    if (cam) granted.add(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    if (mic) granted.add(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    request.grant(granted.toTypedArray())
                } else {
                    request.deny()
                }
            } catch (e: Exception) {
                // 요청이 이미 취소됨
            }
        }
    }

    private fun handleGeolocationRequest(origin: String, callback: android.webkit.GeolocationPermissions.Callback) {
        askWebPermission(
            origin, "위치",
            listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            anyOf = true
        ) { ok ->
            try { callback.invoke(origin, ok, false) } catch (e: Exception) { }
        }
    }

    // ── HTTP 로그인(Basic/Digest) 과 인증서 오류 ──

    private val pendingAuth = ArrayList<android.webkit.HttpAuthHandler>()

    @Suppress("DEPRECATION")
    private fun askHttpAuth(view: WebView, handler: android.webkit.HttpAuthHandler, host: String?, realm: String?) {
        if (isFinishing || isDestroyed) { handler.cancel(); return }
        // 같은 주소가 여러 요청으로 동시에 물어도 창은 하나만 띄우고 같은 답을 모두에게 준다
        if (pendingAuth.isNotEmpty()) { pendingAuth.add(handler); return }
        pendingAuth.add(handler)
        val saved = try { view.getHttpAuthUsernamePassword(host, realm) } catch (e: Exception) { null }
        val etUser = EditText(this).apply {
            hint = "사용자 이름"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setText(saved?.getOrNull(0).orEmpty())
        }
        val etPass = EditText(this).apply {
            hint = "비밀번호"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(saved?.getOrNull(1).orEmpty())
        }
        Popup.styleInput(etUser)
        Popup.styleInput(etPass)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
            addView(etUser)
            addView(etPass, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) })
        }
        val plain = view.url?.startsWith("http://") == true
        var done = false
        fun finish(ok: Boolean) {
            if (done) return
            done = true
            val list = pendingAuth.toList()
            pendingAuth.clear()
            for (h in list) {
                try {
                    if (ok) h.proceed(etUser.text.toString(), etPass.text.toString()) else h.cancel()
                } catch (e: Exception) { }
            }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("로그인이 필요합니다")
            .setMessage(
                (host ?: "") + (if (!realm.isNullOrBlank()) " · $realm" else "") +
                    (if (plain) "\n\n⚠ 이 연결은 암호화되어 있지 않아 입력한 비밀번호가 노출될 수 있어요." else "")
            )
            .setView(box)
            .setPositiveButton("로그인") { _, _ -> finish(true) }
            .setNegativeButton("취소") { _, _ -> finish(false) }
            .setOnDismissListener { finish(false) }
            .show()
    }

    private val sslAllowed = HashSet<String>()
    private val pendingSsl = ArrayList<android.webkit.SslErrorHandler>()

    private fun sslMessage(error: android.net.http.SslError): String = when (error.primaryError) {
        android.net.http.SslError.SSL_UNTRUSTED -> "이 사이트의 인증서를 신뢰할 수 없습니다. (발급 기관을 확인할 수 없음)"
        android.net.http.SslError.SSL_EXPIRED -> "이 사이트의 인증서가 만료되었습니다."
        android.net.http.SslError.SSL_IDMISMATCH -> "인증서가 이 사이트 주소와 일치하지 않습니다."
        android.net.http.SslError.SSL_NOTYETVALID -> "이 사이트의 인증서가 아직 유효하지 않습니다. (기기의 날짜·시간도 확인해 보세요)"
        android.net.http.SslError.SSL_DATE_INVALID -> "인증서의 날짜가 올바르지 않습니다. (기기의 날짜·시간도 확인해 보세요)"
        else -> "인증서에 문제가 있습니다."
    }

    /** 페이지 자체의 인증서 오류만 묻는다. 이미지·스크립트 같은 하위 요청의 오류는 조용히 막는다. */
    private fun askSslError(pageHost: String?, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
        val errHost = runCatching { Uri.parse(error.url).host }.getOrNull()
        if (errHost == null || errHost != pageHost || isFinishing || isDestroyed) {
            handler.cancel()
            return
        }
        val key = "$errHost|${error.primaryError}"
        if (key in sslAllowed) { handler.proceed(); return }
        if (pendingSsl.isNotEmpty()) { pendingSsl.add(handler); return }
        pendingSsl.add(handler)
        var done = false
        fun finish(proceed: Boolean) {
            if (done) return
            done = true
            if (proceed) sslAllowed.add(key)
            val list = pendingSsl.toList()
            pendingSsl.clear()
            for (h in list) {
                try { if (proceed) h.proceed() else h.cancel() } catch (e: Exception) { }
            }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("보안 연결이 아닙니다")
            .setMessage("$errHost\n\n${sslMessage(error)}\n\n계속하면 비밀번호나 카드 정보 같은 중요한 정보가 노출될 수 있어요.")
            .setPositiveButton("돌아가기") { _, _ -> finish(false) }
            .setNegativeButton("위험을 감수하고 계속") { _, _ -> finish(true) }
            .setOnDismissListener { finish(false) }
            .show()
    }

    // ── 렌더러 프로세스가 죽었을 때 (메모리 부족 등): 앱이 같이 꺼지지 않게 WebView 를 새로 만든다 ──

    private fun recoverRenderer(tab: BrowserTab, dead: WebView) {
        if (tab !in tabs || tab.liveWebView !== dead) {
            runCatching { dead.destroy() }
            return
        }
        val url = (if (tab.isHome) null else dead.url?.takeIf { it != "about:blank" && it != HOME_URL }) ?: tab.pendingUrl
        tab.pendingTitle = dead.title?.takeIf { it.isNotBlank() } ?: tab.pendingTitle
        val wasCurrent = tab === current
        val now = android.os.SystemClock.uptimeMillis()
        val looping = now - tab.crashAt < 10_000L
        tab.crashAt = now

        (dead.parent as? ViewGroup)?.removeView(dead)
        runCatching { dead.destroy() }
        val fresh = if (tab.incognito) newIncognitoWebView() else NestedWebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        tab.webView = fresh
        tab.mediaFrames.clear(); tab.sniffed.clear(); tab.sniffedSubs.clear()
        tab.progress = 100
        tab.errorUrl = null
        configure(tab)
        if (tab.desktop) applyUserAgent(fresh, true)
        onMediaChanged()

        if (wasCurrent) {
            tab.paused = false
            webContainer.addView(fresh)
            fresh.requestFocus()
            when {
                url == null -> if (tab.isHome) loadHome(tab)
                looping -> {
                    // 같은 페이지가 계속 죽으면 무한 새로고침 대신 안내 화면을 보여 준다
                    tab.errorUrl = url
                    fresh.loadDataWithBaseURL(
                        url, errorPageHtml(url, -1, "이 페이지를 열다가 계속 종료되었습니다"),
                        "text/html", "utf-8", url
                    )
                }
                else -> {
                    toast("메모리가 부족해 페이지가 종료되어 다시 불러옵니다")
                    fresh.loadUrl(url)
                }
            }
            updateUi()
        } else {
            // 보고 있지 않던 탭은 다시 선택할 때 불러온다
            tab.pendingUrl = url
            tab.paused = true
            fresh.onPause()
        }
        scheduleStripRefresh()
    }

    private fun configure(tab: BrowserTab) {
        val wv = tab.webView
        // 백그라운드 재생이 켜져 있고 이 탭에서 소리가 나는 중이면, 앱을 나가도 웹뷰가 멈추지 않게 한다
        (wv as? NestedWebView)?.keepPlaying = { prefs.backgroundAudio && tab.mediaFrames.isNotEmpty() }

        if (baseUserAgent.isEmpty()) baseUserAgent = wv.settings.userAgentString
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (tab.incognito && !profilesSupported) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            // 파일 업로드(<input type=file>)로 고른 파일은 content:// 주소로 오므로 켜 둬야 올라간다.
            // (웹페이지가 content:// 를 직접 불러올 수는 없어서 보안상 문제는 없다)
            allowContentAccess = true
            setGeolocationEnabled(true)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }
        // 일부 사이트(영상 서비스 등)가 WebView를 낮은 품질로 취급하는 것을 피하기 위해 UA(및 Client Hints)에서 WebView 표시 제거
        applyUserAgent(wv, false)
        // 재생 상태 감지 (백그라운드 재생 / PiP 용)
        wv.addJavascriptInterface(MediaJs(tab), "EvMedia")
        wv.addJavascriptInterface(localDownload, "EvBlob")
        if (docStartScripts) {
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, MediaScripts.INJECT, setOf("*"))
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, MediaScripts.PULL_GUARD, setOf("*"))
            // blob 다운로드: 페이지가 바로 취소해 버리는 blob 도 저장할 수 있게 원본을 붙잡아 둔다
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, LocalDownload.KEEP_BLOBS_JS, setOf("*"))
            // 광고 영역 숨김 / 유튜브 영상 광고 건너뛰기 (페이지가 그려지기 전부터 적용)
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(wv, AdBlocker.COSMETIC_START_JS, setOf("*"))
        }
        // WebView가 보내는 X-Requested-With(앱 패키지명) 헤더 제거 — 구글 등 로그인 차단/보안 경고의 주원인
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(wv.settings, emptySet())
        }
        // 사용자가 최근 화면을 만졌는지 기록 (로그인 팝업·앱 연동은 허용, 자동 팝업 광고는 계속 차단)
        wv.setOnTouchListener { _, _ -> lastTouchAt = android.os.SystemClock.uptimeMillis(); false }
        // 키보드(Enter)로 누른 다운로드 버튼도 사용자가 한 동작으로 본다
        wv.setOnKeyListener { _, _, _ -> lastTouchAt = android.os.SystemClock.uptimeMillis(); false }
        // 액티비티가 이미 hardwareAccelerated 이므로 WebView 에 별도 하드웨어 레이어를 씌우지 않는다.
        // 레이어를 씌우면 스크롤로 상단 메뉴가 숨겨져 WebView 가 커질 때, 늘어난 아래쪽 영역이
        // 레이어에 다시 그려지지 않아 흰 네모가 남는다.
        wv.setLayerType(View.LAYER_TYPE_NONE, null)
        applySecurity(wv, tab)
        applyWebAppearance(wv)
        applyAutofill(tab)
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.setOnScrollChangeListener { _, _, y, _, oldY ->
            onPageScroll(tab, y, oldY) // (스크롤바 갱신은 onPageScroll 안에서 한 번 한다)
        }

        // 현재 페이지의 호스트. shouldInterceptRequest 는 백그라운드 스레드에서 불리는데
        // 거기서 view.url 을 읽으면 WebView 스레드 위반으로 앱이 꺼지므로, 값을 따로 저장해서 쓴다.
        val pageHostRef = java.util.concurrent.atomic.AtomicReference<String?>(null)

        wv.webViewClient = object : WebViewClient() {
            override fun onScaleChanged(view: WebView, oldScale: Float, newScale: Float) {
                super.onScaleChanged(view, oldScale, newScale)
                (view as? NestedWebView)?.onPageScaleChanged(newScale)
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                if (request.isForMainFrame) {
                    // 스크립트가 띄운 팝업이 광고 서버로 가면 아무것도 안 보여주고 탭을 닫는다
                    if (adBlockEnabled && tab.scriptPopup && adBlocker.isAdHost(request.url.host)) {
                        adBlocker.record(request.url.host, AdBlocker.KIND_POPUP)
                        tab.adBlocked.incrementAndGet()
                        ui.post {
                            if (tab in tabs) {
                                toast("광고 팝업을 차단했습니다")
                                closeTab(tab)
                            }
                        }
                        return blockedResponse(request.url)
                    }
                    pageHostRef.set(request.url.host)
                    tab.adBlocked.set(0) // 새 페이지로 가면 '이 페이지' 차단 건수를 다시 센다
                    return null
                }
                val reqUrl = request.url.toString()
                // 이미 허용으로 판정된 호스트(영상 조각 등)는 요청 종류 추정까지 건너뛰고 바로 통과
                if (adBlockEnabled &&
                    !adBlocker.quickAllow(request.url.host, pageHostRef.get()) &&
                    adBlocker.shouldBlock(
                        request.url.host, pageHostRef.get(), reqUrl,
                        NetFilter.inferType(
                            reqUrl, request.requestHeaders?.get("Accept"), false,
                            request.requestHeaders?.containsKey("Range") == true
                        )
                    )
                ) {
                    adBlocker.record(request.url.host, AdBlocker.KIND_REQUEST)
                    tab.adBlocked.incrementAndGet()
                    return blockedResponse(request.url, true)
                }
                sniffMedia(tab, request.url, request.requestHeaders)
                if (strictTrackers) {
                    val block = try {
                        trackerBlocker.shouldBlock(request.url.host, pageHostRef.get())
                    } catch (e: Exception) {
                        false
                    }
                    if (block) {
                        trackerBlocker.blockedCount.incrementAndGet()
                        return blockedResponse(request.url, true)
                    }
                }
                return null
            }

            // 페이지를 불러오지 못하면 기본 오류 화면 대신 앱의 오류 화면을 보여 준다.
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (!request.isForMainFrame) return
                val url = request.url.toString()
                if (!(url.startsWith("http://") || url.startsWith("https://"))) return
                val desc = error.description?.toString().orEmpty()
                // 사용자가 직접 멈추거나 다운로드로 바뀐 경우는 오류가 아니다
                if (error.errorCode == WebViewClient.ERROR_UNKNOWN && desc.contains("ERR_ABORTED")) return
                // HTTPS 우선으로 올린 연결이 안 되면, 사용자가 허락할 때만 http 로 되돌아간다
                val orig = tab.upgradedFrom
                if (orig != null && url.startsWith("https://") &&
                    request.url.host == runCatching { Uri.parse(orig).host }.getOrNull() &&
                    error.errorCode != WebViewClient.ERROR_HOST_LOOKUP
                ) {
                    ui.post { askHttpFallback(tab, view, orig) }
                }
                tab.errorUrl = url
                val html = errorPageHtml(url, error.errorCode, desc)
                ui.post { view.loadDataWithBaseURL(url, html, "text/html", "utf-8", url) }
            }

            // 렌더러가 죽어도 앱이 꺼지지 않게 하고, 그 탭만 새로 만든다 (API 26+)
            override fun onRenderProcessGone(
                view: WebView,
                detail: android.webkit.RenderProcessGoneDetail
            ): Boolean {
                ui.post { recoverRenderer(tab, view) }
                return true
            }

            override fun onReceivedHttpAuthRequest(
                view: WebView, handler: android.webkit.HttpAuthHandler, host: String?, realm: String?
            ) {
                askHttpAuth(view, handler, host, realm)
            }

            override fun onReceivedSslError(
                view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError
            ) {
                askSslError(pageHostRef.get(), handler, error)
            }

            // 악성·피싱 사이트로 접속하려 하면 경고 화면을 띄우고 알려 준다.
            override fun onSafeBrowsingHit(
                view: WebView,
                request: WebResourceRequest,
                threatType: Int,
                callback: android.webkit.SafeBrowsingResponse
            ) {
                callback.showInterstitial(true)
                if (request.isForMainFrame) toast("⚠ 악성 사이트로 의심되어 접속을 막았습니다")
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "http" || scheme == "https") {
                    // 사용자 동작 없는 광고 서버 이동 / 스크립트 팝업의 광고 이동은 막는다
                    if (adBlockEnabled && request.isForMainFrame &&
                        (!request.hasGesture() || tab.scriptPopup) &&
                        adBlocker.isAdHost(request.url.host)
                    ) {
                        adBlocker.record(request.url.host, AdBlocker.KIND_POPUP)
                        tab.adBlocked.incrementAndGet()
                        if (tab.scriptPopup) {
                            ui.post {
                                if (tab in tabs) {
                                    toast("광고 팝업을 차단했습니다")
                                    closeTab(tab)
                                }
                            }
                        }
                        return true
                    }
                    // 뒤로가기 직후, 사용자 동작 없이 페이지가 스스로 다른 곳으로 보내려 하면 막는다.
                    // (뒤로가기를 눌러도 같은 페이지로 계속 튕겨 돌아오는 "뒤로가기 함정" 방지)
                    // 오작동을 막으려고 아래를 모두 만족할 때만 막는다:
                    //  - 뒤로가기한 지 4초 안이고, 그 뒤로 사용자가 페이지를 만지지 않았다 (눌러서 가는 링크·서버 리다이렉트는 통과)
                    //  - 이동을 시작한 곳이 뒤로가기로 도착한(또는 떠나온) 페이지다
                    //  - 가는 곳이 도착한 페이지 자신의 주소 정리(http→https, www 붙이기, 끝 슬래시)가 아니다
                    val from = view.url
                    if (prefs.blockBackRedirect && request.isForMainFrame && !request.hasGesture() && from != null &&
                        tab.backAt != 0L &&
                        android.os.SystemClock.uptimeMillis() - tab.backAt < BACK_GUARD_MS &&
                        lastTouchAt == tab.backTouchMark &&
                        (sameDoc(from, tab.backTargetUrl) || sameDoc(from, tab.backLeftUrl)) &&
                        !sameDoc(request.url.toString(), tab.backTargetUrl) &&
                        !sameDoc(request.url.toString(), from)
                    ) {
                        // 튕기는 쪽은 뒤로가기로 도착한 페이지다 (없으면 지금 주소)
                        tab.redirectSources.add(tab.backTargetUrl ?: from)
                        tab.backAt = 0L
                        toast("뒤로가기 중 자동 이동을 차단했습니다")
                        ui.post { if (tab in tabs && canGoBackSmart(tab)) goBackSmart(tab) }
                        return true
                    }
                    // HTTPS 우선: http 링크는 https 로 올려서 연결한다
                    if (request.isForMainFrame) {
                        val prev = tab.upgradedFrom
                        if (prev != null && runCatching { Uri.parse(prev).host }.getOrNull() == request.url.host) {
                            // https 로 올렸더니 서버가 스스로 http 로 되돌려 보낸 경우: 무한 반복을 막고 그대로 둔다
                            request.url.host?.lowercase()?.let { httpAllowed.add(it) }
                            tab.upgradedFrom = null
                            return false
                        }
                        val up = upgradeUrl(request.url.toString())
                        if (up != null) {
                            tab.upgradedFrom = request.url.toString()
                            ui.post { view.loadUrl(up) }
                            return true
                        }
                    }
                    return false
                }

                // 웹 페이지가 내 기기 파일이나 다른 앱의 데이터로 이동하게 두지 않는다
                if (scheme == "about") return false
                if (scheme in BLOCKED_NAV_SCHEMES) return true

                // 사용자 동작 없이 외부 앱/스토어를 여는 리다이렉트(광고)는 차단
                if (!request.hasGesture() && !recentTouch()) return true

                return try {
                    val intent = if (scheme == "intent") {
                        Intent.parseUri(request.url.toString(), Intent.URI_INTENT_SCHEME).apply {
                            addCategory(Intent.CATEGORY_BROWSABLE)
                            component = null
                            selector = null
                            // 페이지가 파일 접근 권한을 끼워 넘기거나 내 파일을 가리키지 못하게 한다
                            flags = flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION).inv()
                            val ds = data?.scheme?.lowercase()
                            if (ds == "file" || ds == "content") throw SecurityException("blocked")
                        }
                    } else {
                        Intent(Intent.ACTION_VIEW, request.url)
                    }
                    startActivity(intent)
                    true
                } catch (e: ActivityNotFoundException) {
                    toast("이 링크를 열 수 있는 앱이 없습니다")
                    true
                } catch (e: Exception) {
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                (view as? NestedWebView)?.resetZoomTracking()
                // 홈 항목으로 들어가는 중: 덮개(홈 화면)만 보여 준다
                if (url == HOME_URL) {
                    tab.isHome = true
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                    return
                }
                pageHostRef.set(try { Uri.parse(url).host } catch (e: Exception) { null })
                tab.scrollRatio = -1f
                tab.cosmeticInjected = false
                tab.ownProgressBar = false
                tab.ownBarChecks = 0
                tab.desktopInjected = false
                tab.zoomInjected = false
                tab.darkInjected = false
                if (tab === current) { scrollAcc = 0; setBarsHidden(false) }
                // 다른 페이지로 넘어가면 이전 페이지의 찾기 결과는 의미가 없다
                if (tab.webView === findWebView) closeFind()
                tab.favicon = favicon
                if (url != "about:blank" && !url.startsWith("data:")) {
                    if (tab.isHome) tab.awaitCommit = true
                    tab.isHome = false
                }
                tab.stoppedByHome = false
                tab.sniffed.clear()
                tab.sniffedSubs.clear()
                if (tab.mediaFrames.isNotEmpty()) { tab.mediaFrames.clear(); onMediaChanged() }
                if (tab === current) updateUi()
            }

            // 새 페이지의 첫 화면이 그려졌다: 이제 웹뷰를 보여 준다 (그 전엔 이전 페이지가 비쳐 보였다)
            override fun onPageCommitVisible(view: WebView, url: String) {
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    ui.post { if (tab === current) updateUi() }
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (tab.awaitCommit) { tab.awaitCommit = false; if (tab === current) updateUi() }
                if (url == "about:blank") view.clearHistory()
                if (url == HOME_URL || view.url == HOME_URL) {
                    tab.isHome = true
                    tab.awaitCommit = false
                    if (tab.clearAtHome) { tab.clearAtHome = false; view.clearHistory() }
                }
                if (url.startsWith("https://")) tab.upgradedFrom = null
                // 문서 시작 스크립트로 이미 들어가 있으면 다시 실행하지 않는다 (페이지 완료 직후 JS 실행을 줄임)
                if (!docStartScripts) view.evaluateJavascript(MediaScripts.INJECT, null)
                // 문서 시작 스크립트를 못 쓰는 기기에서는 영상 배너 감지/팝업 차단 스크립트를 여기서 넣는다 (한 번만 돈다)
                if (!docStartScripts && adBlockEnabled) view.evaluateJavascript(AdBlocker.COSMETIC_START_JS, null)
                if (adBlockEnabled) view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                if (tab.desktop) view.evaluateJavascript(desktopViewportJs(), null)
                if (effectiveZoom(tab) != 100) view.evaluateJavascript(pageZoomJs(tab), null)
                if (tab.rate != 1f) view.evaluateJavascript(speedJs(tab.rate), null)
                if (needCssDark()) view.evaluateJavascript(forceDarkJs(true), null)
                if (tab.restoreScrollPending) restoreHandoffScroll(tab, view)
                // (저장은 백그라운드 스레드에서 — 메인 스레드에서 JSON을 읽고 쓰면 페이지 전환이 버벅인다)
                if (tab.errorUrl != null && url != tab.errorUrl) tab.errorUrl = null
                if (url.startsWith("http") && !url.startsWith(LOCAL_BASE) && tab.errorUrl == null && !tab.incognito) {
                    val title = view.title
                    io.execute { prefs.addHistory(url, title) }
                }
                if (tab === current) {
                    updateUi()
                    pageScrollBar.bind(if (tab.isHome) null else view)
                    view.post { pageScrollBar.refresh() }
                    view.postDelayed({ pageScrollBar.refresh() }, 350)
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            // 영상 로딩 중 WebView 기본 포스터(회색 바탕 + 늘어난 거대한 재생 아이콘)가 보이는 문제:
            // 1x1 투명 비트맵으로 바꿔서 기본 포스터가 그려지지 않게 한다.
            private var blankPoster: Bitmap? = null
            override fun getDefaultVideoPoster(): Bitmap? {
                return blankPoster ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
                    .also { it.eraseColor(0); blankPoster = it }
            }

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                tab.progress = if (tab.isHome) 100 else newProgress
                // 페이지 자체 로딩 바가 있는지 두 번만 살핀다 (진행 20%, 60% 때). 있으면 브라우저 로딩 바를 숨긴다.
                if (!tab.isHome && !tab.ownProgressBar &&
                    ((newProgress >= 20 && tab.ownBarChecks == 0) || (newProgress >= 60 && tab.ownBarChecks == 1))
                ) {
                    tab.ownBarChecks++
                    view.evaluateJavascript(OWN_BAR_JS, null)
                }
                // 진행률 이벤트마다 JS를 실행하면 로딩이 느려지므로 페이지당 한 번만 넣는다. (끝날 때 한 번 더 확인)
                if (adBlockEnabled && newProgress >= 30 && !tab.cosmeticInjected) {
                    tab.cosmeticInjected = true
                    view.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
                }
                if (needCssDark() && newProgress >= 20 && !tab.darkInjected) {
                    tab.darkInjected = true
                    view.evaluateJavascript(forceDarkJs(true), null)
                }
                if (tab.desktop && newProgress >= 25 && !tab.desktopInjected) {
                    tab.desktopInjected = true
                    view.evaluateJavascript(desktopViewportJs(), null)
                }
                if (newProgress >= 25 && !tab.zoomInjected && effectiveZoom(tab) != 100) {
                    tab.zoomInjected = true
                    view.evaluateJavascript(pageZoomJs(tab), null)
                }
                if (tab === current) {
                    if (newProgress >= 100) webContainer.endRefresh()
                    showProgress(newProgress)
                }
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: android.webkit.JsResult): Boolean {
                if (!jsDialogAllowed(tab)) { result.confirm(); return true }
                showJsDialog(url, message, 0, null, result)
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: android.webkit.JsResult): Boolean {
                if (!jsDialogAllowed(tab)) { result.cancel(); return true }
                showJsDialog(url, message, 1, null, result)
                return true
            }

            override fun onJsPrompt(
                view: WebView, url: String?, message: String?, defaultValue: String?,
                result: android.webkit.JsPromptResult
            ): Boolean {
                if (!jsDialogAllowed(tab)) { result.cancel(); return true }
                showJsDialog(url, message, 2, defaultValue, result)
                return true
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                handleWebPermissionRequest(request)
            }

            override fun onPermissionRequestCanceled(request: android.webkit.PermissionRequest) {
                webPermDialog?.dismiss()
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String, callback: android.webkit.GeolocationPermissions.Callback
            ) {
                handleGeolocationRequest(origin, callback)
            }

            override fun onGeolocationPermissionsHidePrompt() {
                webPermDialog?.dismiss()
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                // 이전 선택창이 남아 있으면 취소 처리 (콜백을 안 부르면 이후 업로드가 먹통이 됨)
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    // 허용 형식(accept)을 처리하는 선택창이 없으면 모든 파일 선택창으로 다시 시도한다
                    try {
                        val any = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                            if (fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                            }
                        }
                        fileChooserLauncher.launch(Intent.createChooser(any, fileChooserParams.title ?: "파일 선택"))
                        true
                    } catch (e2: Exception) {
                        fileChooserCallback = null
                        filePathCallback.onReceiveValue(null)
                        toast("파일 선택 화면을 열 수 없어요")
                        false
                    }
                }
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                scheduleStripRefresh()
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap?) {
                // 홈(새 탭) 화면에선 뒤에 남은 이전 페이지가 보내는 아이콘을 받지 않는다
                if (!tab.isHome) tab.favicon = icon
                scheduleStripRefresh()
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.resetTransform()
                browserUi.animate().cancel()
                browserUi.alpha = 1f
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.keepScreenOn = true
                fullscreenContainer.visibility = View.VISIBLE
                browserUi.visibility = View.GONE
                setFullscreenBackdrop(true)
                setSystemBarsVisible(false)
                refreshPipParams()
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message
            ): Boolean {
                // 사용자 동작 없이 열리는 팝업(팝업 광고)은 차단
                if (!isUserGesture && !recentTouch()) return false
                val newTab = createTab(null, opener = tab)
                newTab.scriptPopup = true
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = newTab.webView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val target = tabs.firstOrNull { it.liveWebView === window } ?: return
                ui.post { closeTab(target) }
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            // 사용자가 화면을 만지지 않았는데 시작된 다운로드는 자동 다운로드로 보고 차단
            if (blockAutoDownload && !recentTouch(DOWNLOAD_TOUCH_MS)) {
                toast("자동 다운로드를 차단했습니다")
            } else if (url.startsWith("blob:") || url.startsWith("data:")) {
                // 페이지 안에서 만든 파일(blob/data)은 페이지에서 읽어와 저장한다
                requestNotificationPermission()
                toast("다운로드 시작")
                localDownload.handle(wv, url, contentDisposition, mimeType)
            } else {
                startDownload(url, userAgent, contentDisposition, mimeType)
            }
        }

        wv.setOnLongClickListener {
            val result = wv.hitTestResult
            val extra = result.extra
            when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (extra != null) showLinkMenu(extra, null)
                    extra != null
                }
                WebView.HitTestResult.IMAGE_TYPE -> {
                    if (extra != null) showLinkMenu(null, extra)
                    extra != null
                }
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    if (extra != null) {
                        val msg = Handler(Looper.getMainLooper()) { m ->
                            showLinkMenu(m.data.getString("url"), extra)
                            true
                        }.obtainMessage()
                        wv.requestFocusNodeHref(msg)
                    }
                    extra != null
                }
                else -> false
            }
        }
    }

    // ───────────────────────── 주소창 / 빠른 검색 ─────────────────────────

    private fun setupUrlBar() {
        suggestAdapter = SuggestAdapter(this, suggestItems)
        suggestAdapter.onRemove = { q ->
            prefs.removeRecentSearch(q)
            showRecentSearches()
        }
        suggestAdapter.onClearAll = {
            prefs.clearRecentSearches()
            showRecentSearches()
        }
        urlBar.setAdapter(suggestAdapter)
        urlBar.threshold = 1
        // 추천 / 최근 검색 창: 메뉴 팝업과 같은 연한 면 + 둥근 모서리 + 얇은 테두리, 주소창과 살짝 띄운다
        // 블러가 켜져 있으면 뒤가 비치는 반투명 유리 + 팝업 뒤 블러, 아니면 예전처럼 불투명
        suggestAdapter.onShown = { v -> Blur.behindRootOf(v, this, 10) }
        urlBar.setDropDownBackgroundDrawable(GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Blur.surface(this@MainActivity, com.google.android.material.R.attr.colorSurfaceContainer, Blur.supported(this@MainActivity)))
            setStroke(
                dp(1),
                ColorUtils.setAlphaComponent(
                    MaterialColors.getColor(urlBar, com.google.android.material.R.attr.colorOutlineVariant), 0x99
                )
            )
        })
        urlBar.dropDownVerticalOffset = dp(6)
        // 이미 입력창에 들어와 있을 때 빈 칸을 다시 누르면 최근 검색을 다시 보여 준다
        urlBar.setOnClickListener {
            if (urlBar.hasFocus() && !urlBar.isPopupShowing && urlBar.text.isNullOrBlank()) showRecentSearches()
        }

        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadFromInput(urlBar.text.toString())
                true
            } else {
                false
            }
        }

        urlBar.setOnItemClickListener { _, _, position, _ ->
            suggestAdapter.getItem(position)?.let { loadFromInput(it) }
        }

        urlBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                setBarsHidden(false)
                // 입력할 때는 전체 주소를 보여주고 전체 선택
                setUrlText(
                    if (current?.isHome == true) ""
                    else current?.webView?.url?.takeIf { it != "about:blank" && it != HOME_URL } ?: ""
                )
                urlBar.post {
                    urlBar.selectAll()
                    showRecentSearches()
                }
            } else {
                urlBar.dismissDropDown()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(urlBar.windowToken, 0)
                updateUi()
            }
        }

        urlBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher || !urlBar.hasFocus()) return
                suggestRunnable?.let { ui.removeCallbacks(it) }
                val q = s?.toString()?.trim().orEmpty()
                if (q.isEmpty()) {
                    showRecentSearches()
                    return
                }
                val r = Runnable { requestSuggestions(q) }
                suggestRunnable = r
                ui.postDelayed(r, 150)
            }
        })
    }

    /** 주소창에 평소 보여줄 짧은 주소 (https://www. 를 뗀 도메인) */
    private fun displayUrl(url: String?): String {
        if (url.isNullOrBlank() || url == "about:blank" || url == HOME_URL) return ""
        // 기기에서 연 HTML 파일은 긴 주소 대신 파일 이름을 보여 준다
        if (url.startsWith("content://") || url.startsWith("file://")) {
            return localFileNames[url] ?: runCatching { Uri.parse(url).lastPathSegment }.getOrNull() ?: url
        }
        if (url.startsWith(LOCAL_BASE)) return Uri.decode(url.removePrefix(LOCAL_BASE).substringBefore('?').substringBefore('#'))
        if (!url.startsWith("http")) return url
        val host = try { Uri.parse(url).host } catch (e: Exception) { null }
        return host?.removePrefix("www.") ?: url
    }

    /** 주소창 왼쪽 아이콘: https 면 자물쇠, 아니면 지구본 */
    private fun updateSecurityIcon(url: String?, incognito: Boolean = false) {
        val blank = url.isNullOrBlank() || url == "about:blank" || url == HOME_URL
        val secure = url?.startsWith("https://") == true
        val res = when {
            blank && incognito -> R.drawable.ic_incognito
            blank -> R.drawable.ic_search
            secure -> R.drawable.ic_lock
            else -> R.drawable.ic_globe
        }
        val icon = ContextCompat.getDrawable(this, res)?.mutate()
        icon?.setBounds(0, 0, dp(18), dp(18))
        icon?.setTint(
            if (incognito) incognitoTextColor
            else MaterialColors.getColor(urlBar, com.google.android.material.R.attr.colorOnSurfaceVariant)
        )
        urlBar.setCompoundDrawablesRelative(icon, null, null, null)
    }

    private fun setUrlText(text: String) {
        suppressWatcher = true
        suggestItems.clear()
        urlBar.setText(text)
        suppressWatcher = false
    }

    @Volatile private var latestSuggestQuery = ""

    private fun requestSuggestions(q: String) {
        latestSuggestQuery = q
        // 북마크를 먼저, 그다음 방문 기록
        val marks = prefs.bookmarks()
            .filter { it.url.contains(q, true) || it.title.contains(q, true) }
            .map { it.url }
            .take(2)
        val local = (marks + prefs.history()
            .filter { it.first.contains(q, true) || it.second.contains(q, true) }
            .map { it.first })
            .distinct()
            .take(4)
        setSuggestions(local)

        io.execute {
            // 그 사이 글자가 더 쳐졌으면 이 요청은 쓸모없다 (빨리 칠 때 요청이 줄줄이 밀려 느려지던 것을 막는다)
            if (latestSuggestQuery != q) return@execute
            try {
                val remote = Suggest.fetch(q)
                ui.post {
                    if (urlBar.text.toString().trim() == q) {
                        setSuggestions((local + remote.filter { it !in local }).take(8))
                    }
                }
            } catch (e: Exception) {
                // 자동완성 실패는 무시
            }
        }
    }

    /** 주소창에 들어오거나 입력을 모두 지웠을 때: 최근에 직접 검색한 글자를 보여 준다 (시크릿 탭에서는 보여 주지 않는다) */
    private fun showRecentSearches() {
        if (!urlBar.hasFocus()) return
        val items = if (current?.incognito == true) emptyList() else prefs.recentSearches().take(8)
        suggestAdapter.recentMode = items.isNotEmpty()
        suggestItems.clear()
        suggestItems.addAll(items)
        suggestAdapter.notifyDataSetChanged()
        if (items.isEmpty()) urlBar.dismissDropDown() else urlBar.showDropDown()
    }

    /** 주소가 아니라 검색어로 처리될 입력인가 (resolveInput 과 같은 기준) */
    private fun isSearchQuery(input: String): Boolean {
        if (input.startsWith("http://") || input.startsWith("https://")) return false
        val parts = input.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2 && SearchEngines.shortcuts.containsKey(parts[0].lowercase())) return true
        val isLocal = input.startsWith("localhost") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(input)
        if (!input.contains(" ") && (isLocal || input.contains("."))) return false
        return true
    }

    private fun setSuggestions(items: List<String>) {
        suggestAdapter.recentMode = false
        suggestItems.clear()
        suggestItems.addAll(items)
        suggestAdapter.notifyDataSetChanged()
        // 맨 위 추천이 주소면 사용자가 고르기 전에 도메인 조회를 해 둔다
        items.firstOrNull()?.let { if (it.startsWith("http")) prefetchDns(it) }
        if (items.isNotEmpty() && urlBar.hasFocus()) urlBar.showDropDown()
    }

    private fun resolveInput(input: String): String {
        if (input.startsWith("http://") || input.startsWith("https://")) return input

        // 빠른 검색 단축어 (예: "yt 노래", "n 날씨")
        val parts = input.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2) {
            SearchEngines.shortcuts[parts[0].lowercase()]?.let { return it + Uri.encode(parts[1]) }
        }

        val isLocal = input.startsWith("localhost") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(input)
        if (!input.contains(" ") && isLocal) return "http://$input"
        if (!input.contains(" ") && input.contains(".")) return "https://$input"

        return prefs.currentEngine().url(input)
    }

    private fun loadFromInput(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val tab = current
        // 직접 검색한 글자는 최근 검색으로 남긴다 (시크릿 탭 제외)
        if (tab?.incognito != true && isSearchQuery(input)) prefs.addRecentSearch(input)
        val wasHome = tab?.isHome == true
        tab?.isHome = false
        // 홈 화면에서 연 주소는 홈을 그대로 보여 준 채 로딩하고, 새 페이지의 첫 화면이 그려지면 넘어간다
        // (예전에는 로딩 시작과 동시에 빈 웹뷰로 바뀌었다)
        if (tab != null && wasHome) {
            tab.awaitCommit = true
            ui.postDelayed({
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                }
            }, 12000)
        }
        var target = resolveInput(input)
        // HTTPS 우선: 직접 입력한 http 주소도 https 로 먼저 연결한다
        upgradeUrl(target)?.let {
            current?.upgradedFrom = target
            target = it
        }
        prefetchDns(target)
        current?.stoppedByHome = false
        current?.webView?.loadUrl(target)
        updateUi()
        urlBar.dismissDropDown()
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ───────────────────────── 컨트롤 / 뒤로가기 / UI ─────────────────────────

    private fun setupControls() {
        val goBack = { navBack(); Unit }
        val goForward = { navForward(); Unit }
        val reload = {
            val c = current
            if (c != null) {
                if (c.progress in 1..99) c.webView.stopLoading() else reloadTab(c)
            }
            Unit
        }
        val goHome = {
            // 홈도 하나의 기록으로 남긴다: 홈 → 뒤로가기 = 보던 페이지, 다시 앞으로가기 = 홈
            val custom = prefs.homepage
            if (custom.isNotEmpty()) {
                // 직접 정한 홈 페이지가 있으면 그 주소를 연다
                current?.let { it.webView.loadUrl(custom) }
            } else {
                current?.let { if (!it.isHome) loadHome(it) }
            }
            Unit
        }

        btnBack.setOnClickListener { goBack() }
        tbBack.setOnClickListener { goBack() }
        btnForward.setOnClickListener { goForward() }
        tbForward.setOnClickListener { goForward() }
        // 뒤로/앞으로 버튼을 꾹 누르면 기록 목록 → 누르면 그 페이지로 이동
        listOf(btnBack, tbBack).forEach {
            it.setOnLongClickListener { v -> showNavHistory(forward = false, anchor = v); true }
        }
        listOf(btnForward, tbForward).forEach {
            it.setOnLongClickListener { v -> showNavHistory(forward = true, anchor = v); true }
        }
        btnRefresh.setOnClickListener { reload() }
        btnHome.setOnClickListener { goHome() }
        tbHome.setOnClickListener { goHome() }
        tbDesktop.setOnClickListener { toggleDesktopSite() }
        tbAi.setOnClickListener { assistant?.show(tbAi) }
        btnTabs.setOnClickListener { openTabSwitcher() }
        btnBottomTabs.setOnClickListener { openTabSwitcher() }
        // 탭 버튼을 꾹 누르면 새 탭 추가
        listOf(btnTabs, btnBottomTabs, findViewById<View>(R.id.btnStripTabList)).forEach {
            it.setOnLongClickListener { v ->
                if (switcherOpen) return@setOnLongClickListener false
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                openNewTabAndFocus()
                true
            }
        }
        btnMenu.setOnClickListener { showMenu(it) }
        tbMenu.setOnClickListener { showMenu(it) }
        findViewById<View>(R.id.btnStripNewTab).setOnClickListener { openNewTabAndFocus() }
        // + 버튼은 32dp 라서 작은 팝업 창에서 누르기 어렵다. 버튼을 감싼 자리(가로 44dp · 탭 줄 높이 전체)도 같이 눌리게 한다
        findViewById<View>(R.id.stripPlusHolder)?.apply {
            isClickable = true
            setOnClickListener { openNewTabAndFocus() }
        }
        // + 는 마지막 탭 옆을 따라가다 오른쪽 끝에서 멈춘다 (위치만 연속으로 바뀜)
        val stripLayoutWatcher = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateStripPlus() }
        tabStripScroll.addOnLayoutChangeListener(stripLayoutWatcher)
        tabStrip.addOnLayoutChangeListener(stripLayoutWatcher)
        tabStripScroll.setOnScrollChangeListener { _, _, _, _, _ -> updateStripPlus() }
        // 탭 줄 폭이 바뀌면(창 크기 조절·접이식 펼침·분할 화면) 탭 폭을 다시 계산한다
        tabStripScroll.addOnLayoutChangeListener { v, l, _, r, _, _, _, _, _ ->
            val w = r - l
            if (w != lastStripViewportW) {
                lastStripViewportW = w
                if (expanded && w > 0) scheduleStripRefresh()
            }
        }
        updateStripPlus()
        findViewById<View>(R.id.btnStripTabList).setOnClickListener { openTabSwitcher() }
        setupFindBar()
        listOf<View>(
            btnBack, btnForward, btnRefresh, btnHome, btnTabs, btnBottomTabs, btnMenu,
            tbBack, tbForward, tbHome, tbMenu, tbDesktop, tbAi,
            findViewById(R.id.btnStripNewTab), findViewById(R.id.btnStripTabList)
        ).forEach { addPressAnim(it) }
    }

    /**
     * 상단 탭 줄의 새 탭(+) 위치. + 는 하나만 두고 translationX 로 움직인다.
     *  - 탭이 적으면 마지막 탭 바로 옆
     *  - 탭이 많아 넘치면 오른쪽 끝에 멈춰 스크롤해도 항상 보임
     * 보이기/숨기기 전환이 없고 탭 폭 애니메이션·스크롤 중에도 매 프레임 연속으로 따라가므로 깜박이거나 튀지 않는다.
     */
    private var stripPlusBg: android.graphics.drawable.ColorDrawable? = null

    private fun updateStripPlus() {
        val holder = findViewById<View>(R.id.stripPlusHolder) ?: return
        val fade = findViewById<View>(R.id.stripPlusFade) ?: return
        val viewport = tabStripScroll.width
        if (viewport <= 0) return

        if (stripPlusBg == null) {
            val tv = android.util.TypedValue()
            theme.resolveAttribute(com.google.android.material.R.attr.colorSurfaceContainerHighest, tv, true)
            val c = if (tv.resourceId != 0) getColor(tv.resourceId) else tv.data
            stripPlusBg = android.graphics.drawable.ColorDrawable(c)
            holder.background = stripPlusBg
            fade.background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(c and 0x00FFFFFF, c)
            )
        }

        // 따라가는 위치(마지막 탭 옆)와 오른쪽 끝 멈춤 위치 중 더 왼쪽
        val follow = tabStripScroll.paddingStart + tabStrip.width - tabStripScroll.scrollX
        val rightStop = viewport - holder.width
        val x = minOf(follow, rightStop).coerceAtLeast(0)
        holder.translationX = x.toFloat()
        fade.translationX = (x - fade.width).toFloat()
        if (captionActive) updateCaptionTouchRegion()

        // 멈춤 위치를 넘어 탭이 + 밑으로 들어오기 시작하면 배경·그라데이션을 부드럽게 켠다
        val covered = ((follow - rightStop) / dp(16).toFloat()).coerceIn(0f, 1f)
        stripPlusBg?.alpha = (255 * covered).toInt()
        fade.alpha = covered
    }

    // ───────────────────────── 페이지 내 찾기 ─────────────────────────

    /** 지금 찾기 결과를 칠해 둔 WebView (탭을 옮기거나 닫을 때 이 뷰의 표시를 지운다) */
    private var findWebView: WebView? = null

    private fun setupFindBar() {
        etFind.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = runFind(s?.toString().orEmpty())
        })
        etFind.setOnEditorActionListener { _, actionId, ev ->
            val enter = ev?.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                findStep(!(ev?.isShiftPressed ?: false))
                true
            } else false
        }
        findViewById<View>(R.id.findNext).setOnClickListener { findStep(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { findStep(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }
        listOf<View>(
            findViewById(R.id.findNext), findViewById(R.id.findPrev), findViewById(R.id.findClose)
        ).forEach { addPressAnim(it) }
    }

    private fun openFind() {
        val tab = current ?: return
        if (tab.isHome) {
            toast("웹 페이지를 연 뒤에 찾을 수 있어요")
            return
        }
        // 위쪽 바가 스크롤로 숨겨져 있으면 찾기 바도 같이 올라가 버리므로 먼저 되돌린다.
        setBarsHidden(false)
        findBar.visibility = View.VISIBLE
        findWebView = tab.webView
        etFind.requestFocus()
        etFind.selectAll()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(etFind, InputMethodManager.SHOW_IMPLICIT)
        runFind(etFind.text.toString())
    }

    private fun closeFind() {
        if (findBar.visibility != View.VISIBLE) return
        findWebView?.let {
            // 탭이 닫히며 WebView가 이미 정리된 뒤일 수 있다
            try { it.clearMatches(); it.setFindListener(null) } catch (_: Exception) {}
        }
        findWebView = null
        findBar.visibility = View.GONE
        findCount.text = ""
        etFind.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etFind.windowToken, 0)
        current?.webView?.requestFocus()
    }

    private fun runFind(query: String) {
        val wv = findWebView ?: return
        if (query.isEmpty()) {
            wv.clearMatches()
            findCount.text = ""
            return
        }
        wv.setFindListener { active, total, _ ->
            findCount.text = if (total == 0) "없음" else "${active + 1}/$total"
        }
        wv.findAllAsync(query)
    }

    private fun findStep(forward: Boolean) {
        if (etFind.text.isNullOrEmpty()) return
        findWebView?.findNext(forward)
    }

    private fun setupHome() {
        // 위쪽에 연한 초록빛이 번지는 배경
        val base = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorSurfaceContainer)
        val tint = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorPrimaryContainer)
        homeView.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(androidx.core.graphics.ColorUtils.blendARGB(base, tint, 0.65f), base, base)
        )
        refreshHomeShortcuts()
        // 창 크기가 바뀔 때마다(분할 화면·플로팅 창 등) 홈 폭을 다시 맞춘다.
        homeView.addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
            if (right - left != oldRight - oldLeft) homeContent.post { applyHomeWidth() }
        }
        homeContent.post { applyHomeWidth() }
    }

    /** 넓은 창에서는 560dp 로 가운데 정렬, 그보다 좁으면 창 폭에 꽉 맞춰 양쪽이 잘리지 않게 한다. */
    private fun applyHomeWidth() {
        val parentW = homeView.width
        if (parentW <= 0) return
        val lp = homeContent.layoutParams as? FrameLayout.LayoutParams ?: return
        val target = if (parentW > dp(560)) dp(560) else ViewGroup.LayoutParams.MATCH_PARENT
        if (lp.width != target) {
            lp.width = target
            lp.gravity = Gravity.CENTER_HORIZONTAL
            homeContent.layoutParams = lp
        }
    }

    // ───────────────────────── 홈 즐겨찾기 ─────────────────────────

    /** 저장된 즐겨찾기로 홈 타일을 다시 그린다. 누르면 열고, 길게 누르면 편집·삭제·이동. */
    private fun refreshHomeShortcuts() {
        val box = findViewById<LinearLayout>(R.id.homeShortcuts)
        box.removeAllViews()
        val list = prefs.homeShortcuts()

        val onSurface = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorOnSurface)
        val surface = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorSurface)
        val muted = MaterialColors.getColor(homeView, com.google.android.material.R.attr.colorOnSurfaceVariant)
        // 즐겨찾기 아이콘은 흑백: 면은 테마 글자색을 연하게 섞고, 글자는 테마 글자색 그대로

        fun tile(
            glyph: String, label: String, accent: Int?,
            onClick: () -> Unit, onLong: (() -> Unit)?
        ): View {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
                if (onLong != null) setOnLongClickListener {
                    it.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    onLong()
                    true
                }
            }
            val face = FrameLayout(this).apply {
                // 타일 면: 라이트 모드는 흰색, 다크 모드는 검은색. 글자·아이콘은 면과 대비되는 색
                val night = systemNight()
                // 라이트: 흰 면 / 다크: 검은색 대신 아주 어두운 청록빛 초록 면
                val faceColor = if (night) 0xFF123A31.toInt() else android.graphics.Color.WHITE
                val lineColor = androidx.core.graphics.ColorUtils.setAlphaComponent(muted, if (night) 0x40 else 0x33)
                val bg = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(22).toFloat()
                    if (accent != null) {
                        setColor(faceColor)
                        setStroke(dp(1), androidx.core.graphics.ColorUtils.setAlphaComponent(muted, 0x22))
                    } else {
                        // '추가' 칸: 비어 있는 자리처럼 보이게 점선 테두리만
                        setColor(android.graphics.Color.TRANSPARENT)
                        setStroke((1.5f * resources.displayMetrics.density).toInt(), lineColor, dp(5).toFloat(), dp(4).toFloat())
                    }
                }
                if (accent != null) elevation = dp(3).toFloat()
                val fg: Int = when {
                    // 글자·아이콘: 검은색 대신 청록이 섞인 연두색
                    night -> if (accent != null) 0xFF7CE6B8.toInt() else 0xFF9AA0A6.toInt()
                    else -> if (accent != null) 0xFF17A673.toInt() else 0xFF5F6368.toInt()
                }
                background = bg
                if (accent != null) {
                    addView(TextView(context).apply {
                        text = glyph
                        gravity = Gravity.CENTER
                        textSize = 22f
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        setTextColor(fg)
                    }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                } else {
                    addView(ImageView(context).apply {
                        setImageResource(R.drawable.ic_add)
                        imageTintList = android.content.res.ColorStateList.valueOf(fg)
                        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
                }
            }
            col.addView(face, LinearLayout.LayoutParams(dp(62), dp(62)))
            col.addView(
                TextView(this).apply {
                    text = label
                    textSize = 12.5f
                    maxLines = 1
                    gravity = Gravity.CENTER
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(muted)
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(9)
                    marginStart = dp(2); marginEnd = dp(2)
                }
            )
            addPressAnim(col)
            return col
        }

        val tiles = ArrayList<View>()
        list.forEachIndexed { i, sc ->
            val glyph = sc.glyph.ifBlank { sc.name.trim().take(1).uppercase() }.ifBlank { "•" }
            tiles.add(tile(glyph, sc.name, onSurface, { loadFromInput(sc.url) }, { showShortcutMenu(i) }))
        }
        if (list.size < MAX_HOME_SHORTCUTS) {
            tiles.add(tile("+", "추가", null, { showShortcutDialog(null, -1) }, null))
        }
        val perRow = 4
        tiles.chunked(perRow).forEachIndexed { r, rowTiles ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowTiles.forEach { line.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
            repeat(perRow - rowTiles.size) { line.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            box.addView(
                line,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (r > 0) topMargin = dp(24)
                }
            )
        }
    }

    private fun showShortcutMenu(index: Int) {
        val list = prefs.homeShortcuts()
        val sc = list.getOrNull(index) ?: return
        val items = mutableListOf<Popup.Item>()
        items.add(Popup.Item(R.drawable.ic_edit, "편집", sc.url) { showShortcutDialog(sc, index) })
        if (index > 0) {
            items.add(Popup.Item(R.drawable.ic_back, "앞으로 옮기기") {
                val m = list.toMutableList()
                m.add(index - 1, m.removeAt(index))
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
            })
        }
        if (index < list.size - 1) {
            items.add(Popup.Item(R.drawable.ic_forward, "뒤로 옮기기") {
                val m = list.toMutableList()
                m.add(index + 1, m.removeAt(index))
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
            })
        }
        items.add(Popup.Item(R.drawable.ic_delete, "삭제", danger = true) {
            prefs.saveHomeShortcuts(list.filterIndexed { i, _ -> i != index })
            refreshHomeShortcuts()
        })
        Popup.menu(this, sc.name, items = items)
    }

    /** 추가(existing == null) 또는 편집 창. 주소에 https:// 가 없으면 붙여 준다. */
    private fun showShortcutDialog(existing: HomeShortcut?, index: Int) {
        val v = layoutInflater.inflate(R.layout.dialog_shortcut, null)
        val etName = v.findViewById<EditText>(R.id.etScName)
        val etUrl = v.findViewById<EditText>(R.id.etScUrl)
        val til = v.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilScUrl)
        if (existing != null) {
            etName.setText(existing.name)
            etUrl.setText(existing.url)
        }
        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "즐겨찾기 추가" else "즐겨찾기 편집")
            .setView(v)
            .setPositiveButton("저장", null)
            .setNegativeButton("취소", null)
        if (existing == null) builder.setNeutralButton("기본값으로", null)
        val dlg = builder.create()
        dlg.setOnShowListener {
            dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var url = etUrl.text.toString().trim()
                if (url.isEmpty() || url.contains(' ')) {
                    til.error = "올바른 주소를 입력해 주세요"
                    return@setOnClickListener
                }
                if (!Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(url)) url = "https://$url"
                val host = Uri.parse(url).host?.removePrefix("www.")
                if (host.isNullOrBlank()) {
                    til.error = "올바른 주소를 입력해 주세요"
                    return@setOnClickListener
                }
                val name = etName.text.toString().trim().ifEmpty { host }
                val glyph = if (existing != null && existing.name == name) existing.glyph else ""
                val m = prefs.homeShortcuts().toMutableList()
                val sc = HomeShortcut(name, url, glyph)
                if (existing != null && index in m.indices) m[index] = sc else m.add(sc)
                prefs.saveHomeShortcuts(m)
                refreshHomeShortcuts()
                dlg.dismiss()
            }
            if (existing == null) {
                dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    prefs.resetHomeShortcuts()
                    refreshHomeShortcuts()
                    dlg.dismiss()
                    toast("기본 즐겨찾기로 되돌렸어요")
                }
            }
        }
        dlg.show()
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    switcherOpen -> closeTabSwitcher()
                    findBar.visibility == View.VISIBLE -> closeFind()
                    customView != null -> hideCustomView()
                    navBack() -> Unit
                    tabs.size > 1 -> current?.let { closeTab(it) }
                    else -> {
                        // 더 이동할 기록이 없을 때: 한 번만 눌러서 앱이 꺼지지 않게, 2초 안에 한 번 더 눌러야 종료
                        val now = android.os.SystemClock.uptimeMillis()
                        if (now - lastExitBackAt < 2000L) {
                            // 종료(홈으로 나가기) 동작을 시스템에 넘기되, 앱이 살아 있는 채로 돌아올 수 있으니
                            // 바로 다시 켜 둔다. (꺼진 채로 두면 이후 뒤로가기가 전부 앱 종료로 처리된다)
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        } else {
                            lastExitBackAt = now
                            toast("한 번 더 누르면 앱이 종료돼요")
                        }
                    }
                }
            }
        })
    }

    /** 마지막으로 "종료하려고 뒤로가기"를 누른 시각 (두 번 눌러야 종료) */
    private var lastExitBackAt = 0L

    private fun updateUi() {
        val tab = current ?: return
        val wv = tab.webView
        if (!urlBar.hasFocus()) {
            setUrlText(if (tab.isHome) "" else displayUrl(wv.url))
        }
        applyIncognitoUi(tab.incognito)
        updateSecureFlag()
        updateSecurityIcon(if (tab.isHome) null else wv.url, tab.incognito)
        updateDesktopButton()
        // 홈 화면은 웹 기록의 한 항목이라 이전 페이지는 이미 내려가 있다 (영상·소리도 같이 멈춘다).
        if (tab.isHome) {
            tab.awaitCommit = false
            wv.visibility = View.INVISIBLE
        } else {
            wv.visibility = if (tab.awaitCommit) View.INVISIBLE else View.VISIBLE
            if (tab.paused) {
                tab.paused = false
                wv.onResume()
            }
            if (tab.stoppedByHome) {
                tab.stoppedByHome = false
                reloadTab(tab)
            }
        }
        if (tab.isHome || tab.awaitCommit) {
            if (homeView.visibility != View.VISIBLE) {
                hideKeyboard()
                homeView.alpha = 1f
                homeView.visibility = View.VISIBLE
                (homeContent as? ViewGroup)?.let { Motion.stagger(it, 0, 55, 330) }
            }
        } else {
            homeView.visibility = View.GONE
        }
        showProgress(tab.progress)
        val canBack = canNavBack(tab)
        val canForward = canNavForward(tab)
        listOf(btnBack, tbBack).forEach {
            it.isEnabled = canBack
            it.alpha = if (canBack) 1f else 0.35f
        }
        listOf(btnForward, tbForward).forEach {
            it.isEnabled = canForward
            it.alpha = if (canForward) 1f else 0.35f
        }
        updateTabCount()
        refreshPipParams()
    }

    private var loadingIcon = false

    /** 두 주소가 같은 문서인지: http/https 와 www., 끝 슬래시, #조각은 무시하고 주소·경로·쿼리를 비교한다 */
    private fun sameDoc(a: String?, b: String?): Boolean {
        if (a == null || b == null) return false
        if (a == b) return true
        return runCatching {
            val x = Uri.parse(a); val y = Uri.parse(b)
            fun host(u: Uri) = u.host.orEmpty().lowercase().removePrefix("www.")
            fun path(u: Uri) = (u.path ?: "").trimEnd('/')
            host(x).isNotEmpty() && host(x) == host(y) && path(x) == path(y) && x.query == y.query
        }.getOrDefault(false)
    }

    /** 뒤로 갈 때 '스스로 되돌려 보내는 페이지'를 건너뛰어 도착할 기록의 상대 위치 (없으면 0). */
    private fun backTarget(tab: BrowserTab): Int {
        val list = tab.webView.copyBackForwardList()
        var i = list.currentIndex - 1
        // 차단 옵션을 끄면 예전에 기록해 둔 '튕기는 페이지'도 건너뛰지 않고 그냥 한 칸씩 간다
        if (prefs.blockBackRedirect) {
            while (i >= 0 && tab.redirectSources.contains(list.getItemAtIndex(i).url)) i--
        }
        return if (i >= 0) i - list.currentIndex else 0
    }

    private fun canGoBackSmart(tab: BrowserTab): Boolean = backTarget(tab) != 0

    /** 홈 항목을 불러온다 (새 탭 화면). 웹 기록에 한 칸으로 남는다. clear 면 다 불러온 뒤 기록을 비운다. */
    private fun loadHome(tab: BrowserTab, clear: Boolean = false) {
        tab.errorUrl = null
        tab.isHome = true
        tab.awaitCommit = false
        tab.clearAtHome = clear
        tab.webView.loadDataWithBaseURL(HOME_URL, HOME_HTML, "text/html", "utf-8", HOME_URL)
        if (tab === current) {
            pageScrollBar.bind(null)
            updateUi()
        }
    }

    /** 기록 이동으로 도착할 항목(target)이 홈인지에 맞춰, 홈 화면 덮개를 바로 켜거나 끈다 */
    private fun applyHomeFor(tab: BrowserTab, target: String?) {
        val toHome = target == HOME_URL
        if (toHome == tab.isHome) return
        tab.isHome = toHome
        if (!toHome) {
            // 홈에서 페이지로 돌아가는 중: 새 페이지의 첫 화면이 그려질 때까지 홈을 보여 준다
            tab.awaitCommit = true
            ui.postDelayed({
                if (tab.awaitCommit) {
                    tab.awaitCommit = false
                    if (tab === current) updateUi()
                }
            }, 12000)
        }
        if (tab === current) {
            pageScrollBar.bind(if (toHome) null else tab.webView)
            updateUi()
        }
    }

    /** 뒤로가기. 새 탭(홈) 화면도 웹 기록의 한 칸이라서, 페이지 → 뒤로 → 홈 → 앞으로 → 페이지 로 오갈 수 있다. */
    private fun navBack(): Boolean {
        val c = current ?: return false
        if (!canGoBackSmart(c)) return false
        goBackSmart(c)
        return true
    }

    /** 앞으로 가기 (홈 항목 포함) */
    private fun navForward(): Boolean {
        val c = current ?: return false
        val wv = c.webView
        if (!wv.canGoForward()) return false
        val list = wv.copyBackForwardList()
        val target = list.getItemAtIndex(list.currentIndex + 1)?.url
        wv.goForward()
        applyHomeFor(c, target)
        return true
    }

    private fun canNavBack(tab: BrowserTab): Boolean = canGoBackSmart(tab)

    private fun canNavForward(tab: BrowserTab): Boolean = tab.webView.canGoForward()

    /** 같은 페이지인지 비교하는 열쇠: 추적/세션용 주소 꼬리표는 무시한다 (구글 검색은 검색어만 본다). */
    private fun historyKey(url: String): String {
        val u = runCatching { Uri.parse(url) }.getOrNull() ?: return url
        val host = (u.host ?: return url.substringBefore('#').trimEnd('/')).lowercase().removePrefix("www.")
        val path = (u.path ?: "").trimEnd('/')
        if (host.startsWith("google.") || host.contains(".google.")) {
            if (path == "/search") return "google-search:" + (u.getQueryParameter("q") ?: "")
            if (path == "/webhp" || path.isEmpty()) return "google-home"
        }
        val noise = setOf(
            "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
            "fbclid", "gclid", "sxsrf", "ved", "ei", "iflsig", "sca_esv", "source",
            "uact", "oq", "gs_lp", "sclient", "biw", "bih", "dpr", "fbs", "si", "sa"
        )
        val query = runCatching { u.queryParameterNames }.getOrNull().orEmpty()
            .filter { it !in noise }.sorted()
            .joinToString("&") { "$it=${u.getQueryParameter(it).orEmpty()}" }
        return "$host$path" + if (query.isEmpty()) "" else "?$query"
    }

    /** 기록 목록에 보여줄 짧은 주소: 사이트 + 경로만, 검색은 검색어만, 너무 길면 …로 줄인다. */
    private fun shortUrl(url: String): String {
        val u = runCatching { Uri.parse(url) }.getOrNull() ?: return url.take(48)
        val host = u.host?.removePrefix("www.") ?: return url.removePrefix("https://").removePrefix("http://").take(48)
        val path = (u.path ?: "").trimEnd('/')
        val q = u.getQueryParameter("q") ?: u.getQueryParameter("query") ?: u.getQueryParameter("search_query")
        val tail = when {
            !q.isNullOrBlank() -> "  ·  검색: $q"
            u.query.isNullOrEmpty() -> ""
            else -> "?…"
        }
        val full = host + path + tail
        return if (full.length <= 48) full else full.take(47) + "…"
    }

    /** 뒤로/앞으로 버튼을 꾹 눌렀을 때: 이 탭의 이동 기록을 목록으로 보여주고, 고르면 그 페이지로 이동한다. */
    private fun showNavHistory(forward: Boolean, anchor: View? = null) {
        val tab = current ?: return
        val wv = tab.webView
        val list = try { wv.copyBackForwardList() } catch (e: Exception) { return }
        val cur = list.currentIndex
        // 뒤로: 가까운(최근) 기록부터 / 앞으로: 가까운 기록부터
        val indices = if (forward) (cur + 1 until list.size).toList() else (cur - 1 downTo 0).toList()
        if (indices.isEmpty()) {
            toast(if (forward) "앞으로 갈 기록이 없어요" else "뒤로 갈 기록이 없어요")
            return
        }
        // 중복 정리: 지금 보는 페이지와 같거나, 앞에서 이미 나온 페이지는 건너뛴다 (가장 가까운 것만 남김)
        val seen = HashSet<String>()
        list.getItemAtIndex(cur)?.url?.let { seen.add(historyKey(it)) }
        val items = ArrayList<Popup.Item>()
        for (i in indices) {
            if (items.size >= 30) break
            val entry = list.getItemAtIndex(i) ?: continue
            val url = entry.url ?: continue
            if (!seen.add(historyKey(url))) continue
            val isHomeEntry = url == HOME_URL
            val host = runCatching { Uri.parse(url).host }.getOrNull()
            val label = if (isHomeEntry) (if (tab.incognito) "시크릿 탭" else "새 탭")
                else entry.title?.takeIf { it.isNotBlank() } ?: host ?: url
            items.add(
                Popup.Item(
                    icon = if (isHomeEntry) R.drawable.ic_leaf_pixel else R.drawable.ic_globe,
                    label = label,
                    sub = if (isHomeEntry) null else shortUrl(url),
                    compactSub = true
                ) {
                    val offset = i - wv.copyBackForwardList().currentIndex
                    if (offset != 0) wv.goBackOrForward(offset)
                    applyHomeFor(tab, url)
                    updateUi()
                }
            )
        }
        if (items.isEmpty()) {
            toast(if (forward) "앞으로 갈 기록이 없어요" else "뒤로 갈 기록이 없어요")
            return
        }
        val title = if (forward) "앞으로 가기 기록" else "뒤로 가기 기록"
        val icon = if (forward) R.drawable.ic_forward else R.drawable.ic_back
        val tablet = expanded
        if (tablet && anchor != null && anchor.isShown) {
            // 태블릿: 누른 뒤로/앞으로 버튼 바로 아래에 붙여서 띄운다
            Popup.menuAnchored(
                this, anchor,
                title = title,
                subtitle = "누르면 그 페이지로 이동해요",
                headerIcon = icon,
                items = items
            )
        } else {
            Popup.menu(
                this,
                title = title,
                subtitle = "누르면 그 페이지로 이동해요",
                headerIcon = icon,
                items = items
            )
        }
    }

    private fun goBackSmart(tab: BrowserTab) {
        val offset = backTarget(tab)
        if (offset == 0) return
        tab.backAt = android.os.SystemClock.uptimeMillis()
        tab.backTouchMark = lastTouchAt
        val list = tab.webView.copyBackForwardList()
        val target = list.getItemAtIndex(list.currentIndex + offset)?.url
        tab.backTargetUrl = target
        tab.backLeftUrl = list.currentItem?.url
        tab.webView.goBackOrForward(offset)
        applyHomeFor(tab, target)
    }

    private fun hasPage(tab: BrowserTab): Boolean =
        tab.webView.url?.let { it != "about:blank" && it != HOME_URL } == true

    /** 로딩 바를 부드럽게 채우고, 끝나면 서서히 사라지게. 로딩 중에는 새로고침 버튼이 X(중지)로 바뀐다. */
    private val OWN_BAR_JS = """
        (function(){try{
          var vw=innerWidth||document.documentElement.clientWidth, found=false;
          var q='[role=progressbar],#nprogress,.nprogress,yt-page-navigation-progress,[id*=progress i],[class*=progress i],[class*=loading-bar i],[class*=loadingbar i],[class*=topbar i],[class*=top-bar-loading i],[class*=page-loader i],[class*=pageloader i]';
          var els=document.querySelectorAll(q);
          for(var i=0;i<els.length&&i<200&&!found;i++){
            var e=els[i]; var cs=getComputedStyle(e);
            if(cs.display==='none'||cs.visibility==='hidden'||parseFloat(cs.opacity)===0) continue;
            var r=e.getBoundingClientRect();
            // 맨 위에 붙은 가는 막대 (높이 8px 이하, 폭이 조금이라도 있음)
            if(r.height>0&&r.height<=8&&r.width>=8&&r.top>=-2&&r.top<=8&&(cs.position==='fixed'||cs.position==='absolute'||cs.position==='sticky'||r.width>=vw*0.2)){found=true;}
            // 막대를 감싼 바깥 틀이 얇고, 그 안의 자식이 막대인 경우 (NProgress 의 .bar 등)
            if(!found&&r.top<=8&&r.height>0&&r.height<=8){found=true;}
          }
          if(found&&window.EvMedia&&EvMedia.ownBar)EvMedia.ownBar(true);
        }catch(e){}})();
    """.trimIndent()

    private fun showProgress(p: Int) {
        if (isInPictureInPictureModeCompat() && customView == null) return   // PiP 에서는 로딩 바도 숨긴 채로 둔다
        val loading = p in 1..99
        if (current?.ownProgressBar == true) {
            // 페이지가 자기 로딩 바를 가지고 있으면 브라우저 로딩 바는 안 보인다 (새로고침↔중지 아이콘은 그대로 바뀐다)
            progressBar.animate().cancel()
            progressBar.visibility = View.GONE
        } else if (loading) {
            progressBar.animate().cancel()
            progressBar.alpha = 1f
            progressBar.visibility = View.VISIBLE
            progressBar.setProgress(p, true)
        } else if (progressBar.visibility == View.VISIBLE) {
            progressBar.setProgress(100, true)
            progressBar.animate().alpha(0f).setStartDelay(150).setDuration(250).withEndAction {
                progressBar.visibility = View.GONE
                progressBar.progress = 0
                progressBar.animate().setStartDelay(0)
            }.start()
        }
        if (loading != loadingIcon) {
            loadingIcon = loading
            val res = if (loading) R.drawable.ic_close else R.drawable.ic_refresh
            btnRefresh.setImageResource(res)
        }
    }

    /** 버튼을 누르면 쏙 들어갔다가 탄성 있게 튀어 돌아오는 효과 (스프링) */
    private fun addPressAnim(v: View) {
        Motion.pressable(v, 0.86f)
    }

    private fun hideCustomView() {
        val view = customView ?: return
        fullscreenContainer.resetTransform()
        fullscreenContainer.removeView(view)
        fullscreenContainer.keepScreenOn = false
        fullscreenContainer.visibility = View.GONE
        browserUi.visibility = View.VISIBLE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        setFullscreenBackdrop(false)
        setSystemBarsVisible(true)
        refreshPipParams()
    }

    /**
     * 동영상 전체화면 동안 창 뒤 배경을 검정으로 바꾼다. 상태표시줄/노치/내비게이션 바 자리는 인셋 여백으로 남는데,
     * 그 아래로 앱 면 색(흰색)의 루트 배경이 비쳐 상단이 하얗게 보이던 문제를 막는다.
     */
    private fun setFullscreenBackdrop(on: Boolean) {
        val surface = getColor(R.color.ev_surface)
        try {
            window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(if (on) android.graphics.Color.BLACK else surface))
        } catch (_: Throwable) {}
        statusBand?.let { b ->
            bandAnim?.cancel()
            if (on) {
                b.base = android.graphics.Color.BLACK
                b.band = android.graphics.Color.BLACK
            } else {
                b.base = surface
                b.band = surface
            }
            b.invalidateSelf()
        }
        if (!on) updateStatusBarColor()
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
            // 전체화면 영상이 끝나면, 스크롤로 바가 숨겨진 상태일 때 상태표시줄도 다시 숨김
            statusBarHiddenByScroll = false
            if (customView == null) applyStatusBarForScroll(barsTarget == 1f)
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ───────────────────────── 메뉴 ─────────────────────────

    /**
     * 메뉴. 폰에서는 아래에서 올라오는 시트, 태블릿(최소 폭 600dp 이상)에서는 누른 버튼 바로 아래에 뜨는 팝업.
     * @param anchor 눌린 메뉴 버튼 (태블릿 팝업을 붙일 기준)
     */
    private var menuAnchorRight = -1
    private var menuAnchorBottom = -1
    private var menuAnchorWinRight = -1
    private var menuAnchorWinBottom = -1
    /** 태블릿 메뉴를 띄운 버튼 (목록 팝업의 ← 로 돌아올 때 메뉴를 같은 자리에 다시 띄우려고) */
    private var menuAnchorRef: java.lang.ref.WeakReference<View>? = null

    /** 목록 팝업(다운로드 / 방문 기록 / 북마크)을 여는 intent. 태블릿이면 메뉴가 떠 있던 자리를 같이 넘긴다. */
    private fun listIntent(cls: Class<*>): Intent = Intent(this, cls).apply {
        if (expanded && menuAnchorRight > 0 && menuAnchorBottom > 0) {
            putExtra(ListUi.EXTRA_ANCHOR_RIGHT, menuAnchorRight)
            putExtra(ListUi.EXTRA_ANCHOR_BOTTOM, menuAnchorBottom)
            if (menuAnchorWinRight > 0 && menuAnchorWinBottom > 0) {
                putExtra(ListUi.EXTRA_ANCHOR_WIN_RIGHT, menuAnchorWinRight)
                putExtra(ListUi.EXTRA_ANCHOR_WIN_BOTTOM, menuAnchorWinBottom)
            }
        }
    }

    private var menuReopenAnchor: java.lang.ref.WeakReference<View>? = null

    /** 북마크·방문 기록·다운로드 화면에서 뒤로 나오면 그 화면을 열었던 메뉴를 다시 연다. */
    private fun reopenMenuAfterList() {
        // 태블릿: 목록 팝업의 ←/뒤로가기가 ListUi.reopenMenu 를 켜 두면 onResume 이 메뉴를 다시 띄운다
        // (바깥을 눌러 닫은 경우는 일부러 메뉴 없이 닫힌다). 여기서 또 열면 메뉴가 두 번 뜬다.
        if (expanded) return
        ui.post {
            if (isFinishing || isDestroyed) return@post
            val a = menuReopenAnchor?.get()?.takeIf { it.isAttachedToWindow }
                ?: (if (tbMenu.isShown) tbMenu else btnMenu)
            showMenu(a)
        }
    }

    /**
     * 메뉴 맨 위 미디어 플레이어. 웹에서 재생 중이거나 방금 멈춘 미디어가 있을 때만 보이고,
     * 재생/일시정지 · 10초 이동 · 위치 이동을 한다. (조작은 페이지 스크립트로 보낸다)
     */
    private fun bindMediaCard(view: View, dismiss: () -> Unit) {
        val card = view.findViewById<View>(R.id.mediaCard)
        val seek = view.findViewById<SeekBar>(R.id.mediaSeek)
        val posText = view.findViewById<TextView>(R.id.mediaPos)
        val durText = view.findViewById<TextView>(R.id.mediaDur)
        val playBtn = view.findViewById<ImageButton>(R.id.mediaPlay)

        fun fresh(p: MediaProg, now: Long) =
            if (p.playing) now - p.at < 5000L else now - p.at < 10 * 60_000L

        /** 떠 있는 모든 창 (이 창이 먼저). 미디어 카드는 다른 창에서 재생 중인 것도 같이 보여 준다 */
        fun wins(): List<MainActivity> =
            listOf(this) + instances.filter { it !== this && !it.isFinishing && !it.isDestroyed }
        fun ownerOf(t: BrowserTab): MainActivity? = wins().firstOrNull { t in it.tabs }
        /** 이 창의 탭 → 다른 창의 탭 순서 (각 창에서는 지금 보는 탭이 먼저) */
        fun orderedTabs(): List<BrowserTab> =
            wins().flatMap { w -> listOfNotNull(w.current) + w.tabs.filter { it !== w.current } }

        fun pickMedia(): Pair<BrowserTab, String>? {
            val now = android.os.SystemClock.uptimeMillis()
            val order = orderedTabs()
            // 1) 재생 중인 것 (지금 보는 탭 먼저)
            for (t in order) {
                if (t.liveWebView == null || t.mediaFrames.isEmpty()) continue
                val e = t.mediaProg.entries
                    .filter { it.key in t.mediaFrames && it.value.playing && fresh(it.value, now) }
                    .maxByOrNull { it.value.at }
                if (e != null) return t to e.key
                // 아직 진행 보고가 안 왔으면 재생 중이라는 사실만으로 먼저 보여 준다
                if (t.mediaProg.keys.none { it in t.mediaFrames }) return t to t.mediaFrames.keys.first()
            }
            // 2) 방금 멈춘 것
            for (t in order) {
                if (t.liveWebView == null) continue
                val e = t.mediaProg.entries.filter { fresh(it.value, now) }.maxByOrNull { it.value.at }
                if (e != null) return t to e.key
            }
            return null
        }

        /** 넘겨 볼 수 있는 미디어 전체: 탭 순서 → 프레임 순서로 고정 (재생 상태가 바뀌어도 순서는 그대로) */
        fun candidates(): List<Pair<BrowserTab, String>> {
            val now = android.os.SystemClock.uptimeMillis()
            val out = ArrayList<Pair<BrowserTab, String>>()
            for (t in orderedTabs()) {
                if (t.liveWebView == null) continue
                for (fid in t.mediaFrames.keys.sorted()) {
                    val p = t.mediaProg[fid]
                    if (p == null || fresh(p, now)) out.add(t to fid)
                }
            }
            return out
        }

        var sel = pickMedia() ?: return
        val motionOn = Motion.enabled(this)
        card.visibility = View.VISIBLE
        // 카드가 아래에서 살짝 떠오르며 나타난다 (스프링)
        Motion.enter(card, 60, 14f)
        val ctl = view.findViewById<ViewGroup>(R.id.mediaControls)
        if (motionOn) {
            // 조작 버튼이 카드보다 살짝 늦게, 가운데부터 통통 튀며 나타난다
            // 칸 순서: 0 이전, 1 뒤로, 2 재생, 3 앞으로, 4 다음 → 재생이 먼저, 바깥쪽 버튼이 나중
            for ((i, c) in listOf(2, 1, 3, 0, 4).map { ctl.getChildAt(it) }.withIndex()) {
                c.scaleX = 0.5f; c.scaleY = 0.5f; c.alpha = 0f
                c.postDelayed({
                    Motion.spring(c, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 400f, 1f)
                    Motion.spring(c, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 420f, 0.45f)
                    Motion.spring(c, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 420f, 0.45f)
                }, 150L + i * 45L)
            }
        }
        var dragging = false
        var curDur = -1.0
        var lastPlaying: Boolean? = null
        var seekAnim: android.animation.ObjectAnimator? = null

        /** 재생↔일시정지 아이콘이 바뀔 때: 살짝 비틀리며 작아졌다가 탄력 있게 돌아온다 */
        fun setPlayIcon(playing: Boolean) {
            playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            playBtn.contentDescription = if (playing) "일시정지" else "재생"
            val prev = lastPlaying
            lastPlaying = playing
            if (prev == null || prev == playing || !motionOn) return
            playBtn.rotation = if (playing) -70f else 70f
            playBtn.scaleX = 0.78f
            playBtn.scaleY = 0.78f
            Motion.spring(playBtn, androidx.dynamicanimation.animation.DynamicAnimation.ROTATION, 0f, 380f, 0.62f)
            Motion.spring(playBtn, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 420f, 0.5f)
            Motion.spring(playBtn, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 420f, 0.5f)
        }

        /** −10/+10 을 누르면 가는 방향으로 살짝 밀렸다가 제자리로 돌아온다 */
        fun nudge(v: View, dir: Int) {
            if (!motionOn) return
            v.translationX = dir * dp(7).toFloat()
            Motion.spring(v, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.45f)
        }

        fun fmt(sec: Double): String {
            if (sec.isNaN() || sec < 0) return "--:--"
            val s = sec.toInt()
            val h = s / 3600
            val m = (s % 3600) / 60
            val ss = s % 60
            return if (h > 0) String.format("%d:%02d:%02d", h, m, ss) else String.format("%d:%02d", m, ss)
        }

        /**
         * 재생 위치 막대: 페이지가 1초마다 알려 주는 위치를 기다리지 않고, 마지막 보고에서 흐른 시간만큼
         * 화면 프레임마다 직접 계산해서 그린다(외삽). 그래서 지연·끊김 없이 실제 재생과 함께 움직인다.
         * 위치를 크게 옮긴 경우(막대 이동, ±10초)만 짧게 감속하며 따라간다.
         */
        val SM = 10000
        fun estPos(): Double {
            val p = sel.first.mediaProg[sel.second] ?: return 0.0
            var x = p.pos
            if (p.playing) x += (android.os.SystemClock.uptimeMillis() - p.at) / 1000.0
            if (p.dur > 0) x = x.coerceAtMost(p.dur)
            return x.coerceAtLeast(0.0)
        }
        fun progFor(x: Double): Int = if (curDur > 0) (x / curDur * SM).toInt().coerceIn(0, SM) else 0
        var lastShownSec = -1
        fun paintSeek() {
            if (dragging || seekAnim?.isRunning == true) return
            val x = estPos()
            seek.progress = progFor(x)
            val sec = x.toInt()
            if (sec != lastShownSec) { lastShownSec = sec; posText.text = fmt(x) }
        }
        var frameOn = false
        val frame = object : Runnable {
            override fun run() {
                if (!view.isAttachedToWindow || card.visibility != View.VISIBLE) { frameOn = false; return }
                paintSeek()
                if (sel.first.mediaProg[sel.second]?.playing == true) view.postOnAnimation(this) else frameOn = false
            }
        }
        fun kickFrame() {
            if (frameOn || !view.isAttachedToWindow) return
            frameOn = true
            view.postOnAnimation(frame)
        }
        fun moveSeek(target: Int, first: Boolean) {
            val cur = seek.progress
            if (first || !motionOn || cur == target) {
                seekAnim?.cancel()
                seek.progress = target
                return
            }
            if (kotlin.math.abs(target - cur) <= SM / 40) return   // 작은 차이는 프레임 갱신이 알아서 맞춘다
            seekAnim?.cancel()
            seekAnim = android.animation.ObjectAnimator.ofInt(seek, "progress", cur, target).apply {
                duration = 200L
                interpolator = android.view.animation.DecelerateInterpolator(1.8f)
                start()
            }
        }
        var firstRender = true

        fun sendTo(target: Pair<BrowserTab, String>, a: String, v: Double = 0.0) {
            val (t, f) = target
            t.liveWebView?.evaluateJavascript(
                "window.postMessage({__ev:'cmd',f:${JSONObject.quote(f)},a:'$a',v:$v},'*');", null
            )
        }
        fun send(a: String, v: Double = 0.0) = sendTo(sel, a, v)

        val swipeCard = card as SwipeCardLayout
        var goTo: (Int) -> Unit = {}
        val dotsRow = view.findViewById<LinearLayout>(R.id.mediaDots)
        val dotViews = ArrayList<View>()
        var dotIndex = -1
        val dotSmall = (6 * resources.displayMetrics.density).toInt()
        val dotBig = (18 * resources.displayMetrics.density).toInt()
        val primary = themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)

        fun sizeDot(v: View, w: Int) {
            v.layoutParams = (v.layoutParams as LinearLayout.LayoutParams).also { it.width = w }
        }

        /** 페이지 점: 현재 것은 길쭉한 알약 모양, 나머지는 작은 점. 바뀔 때 늘어나고 줄어든다 */
        fun updateDots(count: Int, index: Int, onPick: (Int) -> Unit) {
            if (count <= 1) {
                dotsRow.visibility = View.GONE
                dotViews.clear(); dotsRow.removeAllViews(); dotIndex = -1
                return
            }
            dotsRow.visibility = View.VISIBLE
            if (dotViews.size != count) {
                dotsRow.removeAllViews(); dotViews.clear()
                for (i in 0 until count) {
                    val d = View(this)
                    d.background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dotSmall / 2f
                        setColor(primary)
                    }
                    val lp = LinearLayout.LayoutParams(dotSmall, dotSmall)
                    lp.marginStart = dotSmall / 2; lp.marginEnd = dotSmall / 2
                    d.layoutParams = lp
                    d.alpha = 0.3f
                    d.setOnClickListener { onPick(i) }
                    dotsRow.addView(d); dotViews.add(d)
                }
                dotIndex = -1
            }
            if (index == dotIndex) return
            val old = dotIndex
            dotIndex = index
            for ((i, d) in dotViews.withIndex()) {
                val on = i == index
                val toW = if (on) dotBig else dotSmall
                val toA = if (on) 1f else 0.3f
                if (!motionOn || old < 0) { sizeDot(d, toW); d.alpha = toA; continue }
                if (i != index && i != old) continue
                val fromW = d.layoutParams.width
                android.animation.ValueAnimator.ofInt(fromW, toW).apply {
                    duration = 240
                    interpolator = android.view.animation.DecelerateInterpolator(1.5f)
                    addUpdateListener { sizeDot(d, it.animatedValue as Int) }
                    start()
                }
                d.animate().alpha(toA).setDuration(240).start()
            }
        }

        val iconView = view.findViewById<View>(R.id.mediaIconBox)
        val iconImg = view.findViewById<ImageView>(R.id.mediaIcon)
        val badgeImg = view.findViewById<ImageView>(R.id.mediaBadge)
        val subText = view.findViewById<TextView>(R.id.mediaSub)
        val prevBtn = view.findViewById<View>(R.id.mediaPrev)
        val nextBtn = view.findViewById<View>(R.id.mediaNext)
        val backBtn = view.findViewById<View>(R.id.mediaBack)
        val fwdBtn = view.findViewById<View>(R.id.mediaFwd)
        val dp1 = resources.displayMetrics.density

        /** 재생 중엔 아이콘이 천천히 숨 쉬듯 커졌다 작아지고, 멈추면 살짝 작아진 채 가만히 있는다 */
        var pulse: android.animation.ValueAnimator? = null
        fun setPulse(on: Boolean) {
            if (!motionOn) return
            if (on) {
                if (pulse?.isRunning == true) return
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 300f, 0.7f)
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 300f, 0.7f)
                pulse = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 1500
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    repeatMode = android.animation.ValueAnimator.REVERSE
                    interpolator = android.view.animation.AccelerateDecelerateInterpolator()
                    addUpdateListener {
                        val k = 1f + 0.07f * (it.animatedValue as Float)
                        iconView.scaleX = k
                        iconView.scaleY = k
                    }
                    start()
                }
            } else {
                pulse?.cancel()
                pulse = null
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 0.9f, 300f, 0.6f)
                Motion.spring(iconView, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 0.9f, 300f, 0.6f)
            }
        }

        /** 재생/일시정지 버튼 모양: 재생 중엔 둥근 네모, 멈추면 동그라미로 부드럽게 바뀐다 */
        val playFill = ((playBtn.background.mutate() as? android.graphics.drawable.RippleDrawable)
            ?.findDrawableByLayerId(R.id.media_play_fill) as? android.graphics.drawable.GradientDrawable)
        var playRadius = 32f * dp1
        var radiusAnim: android.animation.ValueAnimator? = null
        fun setPlayShape(playing: Boolean, animate: Boolean) {
            val g = playFill ?: return
            val target = (if (playing) 22f else 32f) * dp1
            radiusAnim?.cancel()
            if (!animate || !motionOn) { playRadius = target; g.cornerRadius = target; return }
            radiusAnim = android.animation.ValueAnimator.ofFloat(playRadius, target).apply {
                duration = 320
                interpolator = android.view.animation.OvershootInterpolator(1.4f)
                addUpdateListener { playRadius = it.animatedValue as Float; g.cornerRadius = playRadius }
                start()
            }
        }

        var renderRef: () -> Unit = {}
        var switching = false

        val content = view.findViewById<View>(R.id.mediaContent)
        swipeCard.content = content

        /**
         * 다른 미디어로 넘긴다. 카드 바탕과 점은 가만히 있고 안쪽 내용만 움직인다:
         * 지금 내용이 손가락이 밀던 방향으로 흘러 나가며 흐려지고(손가락 위치에서 이어서),
         * 새 내용이 반대쪽에서 미끄러져 들어와 자리를 잡는다.
         */
        fun goToImpl(i: Int) {
            val list = candidates()
            val cur = list.indexOf(sel)
            if (i !in list.indices || i == cur || switching) { swipeCard.springBack(); return }
            val dir = if (i > cur) 1 else -1
            val swap = {
                sel = list[i]
                firstRender = true   // 막대·버튼 모양은 애니메이션 없이 새 미디어 상태로 바로 맞춘다
                renderRef()
            }
            if (!motionOn) { swap(); return }
            switching = true
            Motion.cancel(content)
            val dist = card.width * 0.28f
            val dm = androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X
            content.animate().translationX(-dir * dist).alpha(0f).setDuration(130)
                .setInterpolator(android.view.animation.AccelerateInterpolator(1.1f))
                .withEndAction {
                    swap()
                    content.translationX = dir * dist
                    content.alpha = 0f
                    Motion.spring(content, dm, 0f, 520f, 0.86f)
                    Motion.spring(content, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 600f, 1f)
                    switching = false
                }.start()
        }
        goTo = { i -> goToImpl(i) }

        fun render() {
            if (ownerOf(sel.first) == null || (sel.first.mediaProg[sel.second] == null && sel.second !in sel.first.mediaFrames)) {
                val n = pickMedia()
                if (n == null) {
                    if (motionOn) {
                        card.animate().cancel()
                        card.animate().alpha(0f).setDuration(160)
                            .withEndAction { card.visibility = View.GONE }.start()
                    } else {
                        card.visibility = View.GONE
                    }
                    return
                }
                sel = n
            }
            val (t, f) = sel
            val p = t.mediaProg[f]
            val url = t.liveWebView?.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val host = url?.let { displayUrl(it) }.orEmpty()
            val mm = t.mediaMeta[f]
            view.findViewById<TextView>(R.id.mediaTitle).text =
                mm?.title?.takeIf { it.isNotBlank() }
                    ?: t.liveWebView?.title?.takeIf { it.isNotBlank() } ?: host.ifBlank { "재생 중" }
            val playing = p?.playing ?: true
            val owner = ownerOf(t)
            val status = when {
                owner != null && owner !== this && playing -> "${owner.windowLabel}에서 재생 중"
                owner != null && owner !== this -> "${owner.windowLabel} · 일시정지됨"
                t !== current && playing -> "다른 탭에서 재생 중"
                t !== current -> "다른 탭 · 일시정지됨"
                playing -> "재생 중"
                else -> "일시정지됨"
            }
            val tail = mm?.artist?.takeIf { it.isNotBlank() } ?: host
            subText.text = if (tail.isBlank()) status else "$status · $tail"
            val isVideo = t.mediaFrames[f]?.video != false
            val fav = t.favicon
            if (fav != null && !fav.isRecycled) {
                // 사이트 아이콘이 있으면 그걸 크게, 없으면 종류 아이콘
                iconImg.imageTintList = null
                iconImg.setPadding(dp(9), dp(9), dp(9), dp(9))
                iconImg.setImageBitmap(fav)
            } else {
                iconImg.imageTintList = android.content.res.ColorStateList.valueOf(
                    themeColor(com.google.android.material.R.attr.colorOnPrimaryContainer, R.color.ev_accent_on_soft)
                )
                iconImg.setPadding(dp(12), dp(12), dp(12), dp(12))
                iconImg.setImageResource(if (isVideo) R.drawable.ic_movie else R.drawable.ic_music)
            }
            badgeImg.setImageResource(if (isVideo) R.drawable.ic_movie else R.drawable.ic_music)
            setPlayIcon(playing)
            setPlayShape(playing, !firstRender)
            setPulse(playing)
            val all = candidates()
            updateDots(all.size, all.indexOf(sel)) { i -> goTo(i) }
            curDur = p?.dur ?: -1.0
            val canSeek = curDur > 0
            seek.isEnabled = canSeek
            backBtn.alpha = if (canSeek) 1f else 0.4f
            fwdBtn.alpha = if (canSeek) 1f else 0.4f
            if (!dragging) {
                moveSeek(if (canSeek && p != null) progFor(estPos()) else 0, firstRender)
                val x = estPos()
                lastShownSec = x.toInt()
                posText.text = fmt(x)
                if (playing) kickFrame()
            }
            durText.text = if (canSeek) fmt(curDur) else if (p != null) "라이브" else "--:--"
            firstRender = false
        }

        view.findViewById<View>(R.id.mediaHead).setOnClickListener {
            val t = sel.first
            val owner = ownerOf(t) ?: return@setOnClickListener
            if (owner !== this) {
                // 다른 창에서 재생 중이면 그 창으로 넘어가 그 탭을 보여 준다
                dismiss()
                if (owner.current !== t) owner.selectTab(t)
                bringWindowToFront(owner)
            } else if (t !== current) {
                dismiss()
                selectTab(t)
            }
        }
        playBtn.setOnClickListener {
            val (t, f) = sel
            val p = t.mediaProg[f]
            // 멈추는 순간의 위치로 고정해서 막대가 되돌아가거나 튀지 않게 한다
            if (p != null) t.mediaProg[f] = MediaProg(estPos(), p.dur, !p.playing, android.os.SystemClock.uptimeMillis())
            send("toggle")
            render()
        }
        prevBtn.setOnClickListener { send("prev"); nudge(it, -1) }
        nextBtn.setOnClickListener { send("next"); nudge(it, 1) }
        view.findViewById<View>(R.id.mediaBack).setOnClickListener {
            if (curDur > 0) { send("skip", -10.0); nudge(it, -1) }
        }
        view.findViewById<View>(R.id.mediaFwd).setOnClickListener {
            if (curDur > 0) { send("skip", 10.0); nudge(it, 1) }
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser && curDur > 0) posText.text = fmt(progress / SM.toDouble() * curDur)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                seekAnim?.cancel()
                // 옮기는 동안 현재 시간이 커지고 포인트 색이 된다
                posText.pivotX = 0f
                posText.setTextColor(themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent))
                if (motionOn) {
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1.25f, 500f, 0.6f)
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1.25f, 500f, 0.6f)
                }
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                if (curDur > 0) { send("seek", sb.progress / SM.toDouble() * curDur); lastShownSec = -1 }
                posText.setTextColor(themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted))
                if (motionOn) {
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, 1f, 400f, 0.7f)
                    Motion.spring(posText, androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, 1f, 400f, 0.7f)
                }
            }
        })
        listOf(playBtn, prevBtn, backBtn, fwdBtn, nextBtn).forEach { Motion.pressable(it, 0.92f) }

        // 메뉴가 떠 있는 동안 0.5초마다 위치를 새로 그린다
        val tick = object : Runnable {
            override fun run() {
                if (!view.isAttachedToWindow || card.visibility != View.VISIBLE) return
                render()
                ui.postDelayed(this, 500)
            }
        }
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                ui.removeCallbacks(tick)
                ui.post(tick)
                frameOn = false
                kickFrame()
            }

            override fun onViewDetachedFromWindow(v: View) {
                ui.removeCallbacks(tick)
                frameOn = false
                pulse?.cancel()
                pulse = null
                radiusAnim?.cancel()
            }
        })
        renderRef = { render() }
        swipeCard.ignoreView = seek
        swipeCard.canSwipe = { dir ->
            val list = candidates()
            val i = list.indexOf(sel)
            i >= 0 && (i + dir) in list.indices
        }
        swipeCard.onSwipe = { dir ->
            val i = candidates().indexOf(sel)
            goTo(i + dir)
        }
        render()
    }

    /**
     * 메뉴 맨 위 링크 공유 카드. 지금 보는 탭의 미리보기 · 제목 · 주소를 보여 주고,
     * 메뉴가 떠 있는 동안 0.4초마다 확인해서 탭 전환 / 주소 이동 / 제목 변경이 있으면 바로 다시 그린다.
     */
    private fun bindShareCard(view: View, dismiss: () -> Unit) {
        val card = view.findViewById<View>(R.id.shareCard)
        val info = view.findViewById<View>(R.id.shareInfo)
        val thumb = view.findViewById<ImageView>(R.id.shareThumb)
        val titleV = view.findViewById<TextView>(R.id.shareTitle)
        val hostV = view.findViewById<TextView>(R.id.shareHost)
        val lock = view.findViewById<ImageView>(R.id.shareLock)
        val motionOn = Motion.enabled(this)
        var shownTab: BrowserTab? = null
        var shownUrl: String? = null
        var shownTitle: String? = null
        var shownVisible = false
        var first = true
        var thumbRetry: Runnable? = null
        var latestUrl: String? = null

        fun capture() {
            if (isFinishing || isDestroyed) return
            setThumb(thumb, captureContent())
        }

        fun render() {
            val t = current
            val url = t?.webView?.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val visible = t != null && !t.isHome && url != null
            if (!visible) {
                latestUrl = null
                if (shownVisible) {
                    shownVisible = false; shownTab = null; shownUrl = null; shownTitle = null
                    if (motionOn) {
                        card.animate().cancel()
                        card.animate().alpha(0f).setDuration(140).withEndAction { card.visibility = View.GONE }.start()
                    } else card.visibility = View.GONE
                }
                return
            }
            latestUrl = url
            val title = t!!.webView.title?.takeIf { it.isNotBlank() } ?: displayUrl(url!!)
            val tabChanged = t !== shownTab
            val urlChanged = url != shownUrl
            if (shownVisible && !tabChanged && !urlChanged && title == shownTitle) return

            val wasVisible = shownVisible
            shownVisible = true
            shownTab = t; shownUrl = url; shownTitle = title
            val animate = motionOn && wasVisible && !first && (tabChanged || urlChanged)

            fun apply() {
                titleV.text = title
                hostV.text = displayUrl(url!!)
                lock.setImageResource(if (url.startsWith("https://")) R.drawable.ic_lock else R.drawable.ic_globe)
            }
            if (!wasVisible) {
                card.animate().cancel()
                card.visibility = View.VISIBLE
                card.alpha = 1f
                apply()
                capture()
                if (!first) Motion.enter(card, 0, 10f)
            } else if (animate) {
                // 글자는 아래에서 살짝 떠오르며 바뀌고, 미리보기는 통통 튀며 바뀐다
                info.alpha = 0f
                info.translationY = dp(8).toFloat()
                apply()
                Motion.spring(info, androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 1f, 300f, 1f)
                Motion.spring(info, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_Y, 0f, 300f, 0.75f)
                capture()
                Motion.pop(thumb, 0.82f)
            } else {
                apply() // 제목만 바뀐 경우(로딩 중)는 조용히 글자만 갈아 끼운다
            }
            first = false
            // 탭을 바꾸거나 이동한 직후엔 아직 그려지는 중일 수 있어서, 잠시 뒤 미리보기를 한 번 더 갱신한다
            if (tabChanged || urlChanged) {
                thumbRetry?.let { ui.removeCallbacks(it) }
                thumbRetry = Runnable { capture() }.also { ui.postDelayed(it, 900) }
            }
        }

        view.findViewById<View>(R.id.btnShareLink).setOnClickListener {
            val u = latestUrl ?: return@setOnClickListener
            dismiss()
            shareText(u)
        }
        card.visibility = View.GONE
        val tick = object : Runnable {
            override fun run() {
                if (!view.isAttachedToWindow) return
                render()
                ui.postDelayed(this, 400)
            }
        }
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                ui.removeCallbacks(tick); ui.post(tick)
            }

            override fun onViewDetachedFromWindow(v: View) {
                ui.removeCallbacks(tick)
                thumbRetry?.let { ui.removeCallbacks(it) }
            }
        })
        render() // 처음 모습은 메뉴가 뜨기 전에 바로 채워 둔다
    }

    private fun showMenu(anchor: View? = null, settings: Boolean = false) {
        menuReopenAnchor = anchor?.let { java.lang.ref.WeakReference(it) }
        val tabletPopup = anchor != null && anchor.isShown &&
            expanded
        if (tabletPopup) menuAnchorRef = java.lang.ref.WeakReference(anchor)
        val sheet = if (tabletPopup) null else BottomSheetDialog(this)
        var popup: PopupWindow? = null
        var closedByUs = false
        fun dismissMenu() {
            closedByUs = true
            sheet?.dismiss()
            popup?.dismiss()
        }
        val view = layoutInflater.inflate(R.layout.dialog_menu, null)
        val list = view.findViewById<LinearLayout>(R.id.menuList)
        // 손잡이는 아래에서 올라오는 시트에만 (태블릿 카드 팝업에는 필요 없다)
        if (sheet == null) view.findViewById<View>(R.id.sheetHandle).visibility = View.GONE
        view.findViewById<View>(R.id.btnCloseMenu).setOnClickListener { dismissMenu() }
        if (settings) {
            view.findViewById<TextView>(R.id.menuTitle).text = "설정"
            view.findViewById<View>(R.id.btnMenuBack).apply {
                visibility = View.VISIBLE
                setOnClickListener {
                    dismissMenu()
                    showMenu(anchor)
                }
            }
        }

        // 맨 위: 지금 보는 페이지의 링크 공유 카드 (미리보기 · 제목 · 주소 · 공유 버튼)
        // 메뉴가 열려 있는 동안 탭을 바꾸거나 페이지가 이동·로딩되면 카드도 실시간으로 따라 바뀐다.
        if (!settings) bindShareCard(view) { dismissMenu() }

        // 웹에서 미디어가 재생 중이면 공유 카드 위에 미디어 플레이어를 보여 준다
        if (!settings) bindMediaCard(view) { dismissMenu() }

        // 항목들은 제목(머리말) 아래 둥근 카드 안에 묶어서 보여 준다.
        var card: LinearLayout? = null
        fun currentCard(): LinearLayout {
            card?.let { return it }
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                tag = "menuCard"
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setColor(MaterialColors.getColor(list, com.google.android.material.R.attr.colorSurface, 0))
                }
                clipToOutline = true
            }
            list.addView(
                c,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(14), 0, dp(14), dp(4)) }
            )
            card = c
            return c
        }

        // 누르면 다른 화면이나 선택창이 열리는 항목에는 오른쪽에 화살표를 붙인다.
        val navTitles = setOf(
            "설정", "북마크", "방문 기록", "다운로드 목록", "검색 엔진", "웹 페이지 다크 모드", "글자 크기",
            "재생 속도", "광고 차단 현황", "직접 선택한 광고 관리", "자동완성 서비스"
        )

        fun newRow(icon: Int, title: String, sub: String?): View {
            val parent = currentCard()
            val row = layoutInflater.inflate(R.layout.item_menu_row, parent, false)
            val iconView = row.findViewById<ImageView>(R.id.rowIcon)
            iconView.setImageResource(icon)
            row.findViewById<TextView>(R.id.rowTitle).text = title
            val st = row.findViewById<TextView>(R.id.rowSub)
            if (sub != null) {
                st.text = sub
                st.visibility = View.VISIBLE
            }
            if (title in navTitles) row.findViewById<View>(R.id.rowChevron).visibility = View.VISIBLE
            // 지우는 항목은 붉은 색으로 눈에 띄게
            if (title.endsWith("삭제")) {
                iconView.backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.ev_danger_soft))
                iconView.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.ev_danger))
                row.findViewById<TextView>(R.id.rowTitle).setTextColor(getColor(R.color.ev_danger))
            }
            parent.addView(row)
            return row
        }

        fun addHeader(text: String) {
            val h = layoutInflater.inflate(R.layout.item_menu_header, list, false) as TextView
            h.text = text
            list.addView(h)
            card = null   // 다음 항목부터 새 카드
        }

        fun addRow(icon: Int, title: String, sub: String? = null, action: () -> Unit) {
            val row = newRow(icon, title, sub)
            row.setOnClickListener {
                dismissMenu()
                action()
            }
        }

        // 스위치 행: 시트를 닫지 않고 바로 켜고 끈다.
        fun addToggle(
            icon: Int,
            title: String,
            sub: () -> String?,
            checked: Boolean,
            action: () -> Boolean
        ) {
            val row = newRow(icon, title, sub())
            val sw = row.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.rowSwitch)
            sw.visibility = View.VISIBLE
            sw.isChecked = checked
            row.contentDescription = title
            row.setOnClickListener {
                row.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                sw.isChecked = action()
                row.findViewById<TextView>(R.id.rowSub).text = sub()
            }
        }

        if (!settings) {
            // 메뉴 = 지금 바로 쓰는 것(탭 · 이 페이지 · 동영상 · 보관함). 바꿔 두고 쓰는 것은 모두 설정으로 보낸다.
            val onPage = current?.isHome != true

            addHeader("탭")
            addRow(R.drawable.ic_add, "새 탭") { openNewTabAndFocus() }
            addRow(R.drawable.ic_incognito, "새 시크릿 탭", "방문 기록과 쿠키가 남지 않아요") { openNewTabAndFocus(incognito = true) }
            addRow(R.drawable.ic_tab, "새 창", "앱을 한 개 더 띄워 나란히 사용합니다") { openNewWindow() }
            addRow(R.drawable.ic_folder, "현재 탭을 새 그룹으로") { groupCurrentTab() }

            addHeader(if (onPage) "이 페이지" else "도구")
            if (onPage) {
                val bookmarked = currentBookmark() != null
                addRow(
                    if (bookmarked) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border,
                    if (bookmarked) "북마크 수정" else "북마크에 추가"
                ) { bookmarkCurrent() }
                addRow(R.drawable.ic_search, "페이지에서 찾기", "이 페이지 안의 글자를 찾아 표시합니다") { openFind() }
                addRow(
                    R.drawable.ic_globe, "페이지 번역",
                    "API 키 없이 한국어로 번역해요 · 번역된 페이지에서 다시 누르면 원문으로"
                ) { assistant?.togglePageTranslation() }
                addRow(
                    R.drawable.ic_text, "화면 확대/축소",
                    "현재: ${current?.let { effectiveZoom(it) } ?: 100}%" + if (current?.pageZoom != null) " (이 탭만)" else ""
                ) { showPageZoomDialog() }
            }
            addRow(
                R.drawable.ic_ai, "AI 어시스턴트",
                if (prefs.geminiKey.isBlank()) "Gemini API 키를 넣으면 요약·번역·질문을 할 수 있어요"
                else "${GeminiModels.byId(prefs.geminiModel).label} · 이 페이지 요약, 번역, 질문"
            ) { assistant?.show(if (tbAi.isShown) tbAi else null) }
            addToggle(
                R.drawable.ic_desktop, "데스크톱 사이트",
                { "켜면 PC용 화면으로 다시 불러옵니다" },
                current?.desktop == true
            ) {
                toggleDesktopSite()
                current?.desktop == true
            }
            addToggle(
                R.drawable.ic_shield, "광고 차단",
                { "이 페이지 ${current?.adBlocked?.get() ?: 0}건 · 오늘 ${adBlocker.stats(0).today}건 차단됨" },
                adBlockEnabled
            ) {
                toggleAdBlock()
                adBlockEnabled
            }
            if (onPage) {
                addRow(
                    R.drawable.ic_edit, "광고 직접 선택",
                    "페이지에서 차단할 광고를 직접 눌러 고릅니다"
                ) { startAdPicker() }

                addHeader("동영상")
                addRow(R.drawable.ic_pip, "동영상 PiP", "재생 중인 동영상을 작은 창으로 띄웁니다") { startPipFromMenu() }
                val ytHere = isYouTubeUrl(current?.liveWebView?.url)
                if (!ytHere) {
                    addRow(R.drawable.ic_play, "내장 플레이어로 재생", "페이지의 영상을 앱 안의 플레이어로 엽니다") { openInternalPlayer() }
                }
                addRow(R.drawable.ic_movie, "페이지의 영상 파일 찾기") { findVideos() }
            }

            addHeader("보관함")
            addRow(R.drawable.ic_bookmark, "북마크", "${prefs.bookmarks().size}개") { openBookmarks() }
            addRow(R.drawable.ic_history, "방문 기록", "${prefs.historyItems().size}개") { openHistory() }
            addRow(R.drawable.ic_download, "다운로드 목록") { openDownloads() }

            addHeader("더 보기")
            addRow(R.drawable.ic_settings, "설정", "검색 엔진 · 화면 · 재생 · 광고 차단 · 보안 · 개인정보") {
                showMenu(anchor, settings = true)
            }
        } else {
            addHeader("일반")
            addRow(R.drawable.ic_search, "검색 엔진", "현재: ${prefs.currentEngine().name}") { showEngineDialog() }
            addRow(R.drawable.ic_home, "홈 페이지", prefs.homepage.ifEmpty { "기본 (새 탭 화면)" }) { showHomepageDialog() }

            addHeader("화면")
            addRow(R.drawable.ic_dark, "웹 페이지 다크 모드", "현재: ${darkModeLabel()}") { showDarkModeDialog() }
            addRow(R.drawable.ic_text, "글자 크기", "현재: ${textZoom}%") { showTextSizeDialog() }

            addHeader("탭")
            addToggle(
                R.drawable.ic_tab, "탭을 끌어서 새 창 열기",
                { if (prefs.dragTabToWindow) "탭 줄 밖으로 끌어내 놓으면 팝업 창으로 열려요" else "꺼져 있어요 · 다른 창이 열려 있으면 탭 메뉴의 \"탭을 다른 창으로 이동\"으로 옮길 수 있어요" },
                prefs.dragTabToWindow
            ) {
                prefs.dragTabToWindow = !prefs.dragTabToWindow
                prefs.dragTabToWindow
            }

            addHeader("재생")
            addRow(R.drawable.ic_play, "재생 속도", "현재: ${current?.rate ?: 1f}x") { showSpeedDialog() }
            addToggle(
                R.drawable.ic_play, "백그라운드 재생",
                { "앱을 나가거나 화면을 꺼도 소리가 계속 나옵니다" },
                prefs.backgroundAudio
            ) {
                prefs.backgroundAudio = !prefs.backgroundAudio
                onMediaChanged()
                prefs.backgroundAudio
            }
            addToggle(
                R.drawable.ic_play, "시스템 미디어 플레이어에 표시",
                { "알림창·잠금화면의 미디어 컨트롤에서 웹 미디어를 조작할 수 있어요" },
                prefs.mediaControls
            ) {
                prefs.mediaControls = !prefs.mediaControls
                mediaKey = ""
                pushKey = ""
                if (prefs.mediaControls) requestNotificationPermission()
                onMediaChanged()
                prefs.mediaControls
            }
            addToggle(
                R.drawable.ic_play, "전체화면에서 아래로 밀어 나가기",
                { if (prefs.swipeDownExit) "전체화면 영상의 가운데를 아래로 밀면 빠져나가요" else "꺼져 있어요 · 뒤로 가기나 영상의 전체화면 버튼으로 나가요" },
                prefs.swipeDownExit
            ) {
                prefs.swipeDownExit = !prefs.swipeDownExit
                prefs.swipeDownExit
            }
            addToggle(
                R.drawable.ic_pip, "영상 아래 버튼 표시",
                { if (prefs.videoButtons) "영상 아래에 '내장 플레이어로 열기'와 'PiP로 보기' 버튼이 떠요" else "꺼져 있어요 · 메뉴의 내장 플레이어·PiP 항목은 그대로 쓸 수 있어요" },
                prefs.videoButtons
            ) {
                prefs.videoButtons = !prefs.videoButtons
                prefs.videoButtons
            }

            addHeader("광고 차단")
            addToggle(
                R.drawable.ic_shield, "광고 차단",
                { "이 페이지 ${current?.adBlocked?.get() ?: 0}건 · 오늘 ${adBlocker.stats(0).today}건 차단됨" },
                adBlockEnabled
            ) {
                toggleAdBlock()
                adBlockEnabled
            }
            addToggle(
                R.drawable.ic_shield, "유튜브 광고 건너뛰기 자동 클릭",
                { if (prefs.ytAutoSkip) "건너뛰기 버튼이 나오면 자동으로 눌러요" else "꺼져 있어요 · 건너뛰기는 직접 눌러야 해요" },
                prefs.ytAutoSkip
            ) {
                prefs.ytAutoSkip = !prefs.ytAutoSkip
                prefs.ytAutoSkip
            }
            addRow(
                R.drawable.ic_shield, "광고 차단 현황",
                "오늘 ${adBlocker.stats(0).today}건 · 전체 ${adBlocker.stats(0).total}건 차단"
            ) { showAdBlockStats() }
            addRow(
                R.drawable.ic_delete, "직접 선택한 광고 관리",
                if (adBlocker.userRuleCount == 0) "아직 직접 고른 광고가 없어요" else "${adBlocker.userRuleCount}개 · 보기 · 삭제"
            ) { showUserAdRules() }
            addRow(
                R.drawable.ic_refresh, "광고 차단 목록 업데이트",
                "마지막 업데이트: ${AdBlockStatsUi.agoText(adBlocker.lastUpdated)}"
            ) { updateAdBlockList() }

            addHeader("보안")
            addToggle(
                R.drawable.ic_shield, "악성 사이트 접속 알림",
                { "위험한 사이트에 접속하면 경고하고 막습니다" },
                malwareWarning
            ) {
                toggleMalwareWarning()
                malwareWarning
            }
            addToggle(
                R.drawable.ic_lock, "HTTPS 우선 연결",
                { "http 주소도 먼저 보안 연결로 시도하고, 안 되면 허락을 구합니다" },
                httpsFirst
            ) {
                toggleHttpsFirst()
                httpsFirst
            }
            addToggle(
                R.drawable.ic_download, "자동 다운로드 차단",
                { "직접 누르지 않은 파일 다운로드를 막습니다" },
                blockAutoDownload
            ) {
                toggleBlockAutoDownload()
                blockAutoDownload
            }
            addToggle(
                R.drawable.ic_back, "뒤로가기 중 자동 이동 차단",
                { "뒤로가기 직후 페이지가 스스로 다른 곳으로 보내는 것을 막습니다" },
                prefs.blockBackRedirect
            ) {
                prefs.blockBackRedirect = !prefs.blockBackRedirect
                toast(if (prefs.blockBackRedirect) "뒤로가기 중 자동 이동 차단 켜짐" else "뒤로가기 중 자동 이동 차단 꺼짐")
                prefs.blockBackRedirect
            }

            addHeader("개인정보")
            addToggle(
                R.drawable.ic_shield, "트래커 차단 (엄격)",
                {
                    if (strictTrackers) "필요한 트래커만 허용 · ${trackerBlocker.blockedCount.get()}건 차단됨"
                    else "필요한 것 외 모든 트래커 차단 · 맞춤 광고가 줄어듭니다"
                },
                strictTrackers
            ) {
                toggleStrictTrackers()
                strictTrackers
            }
            addToggle(
                R.drawable.ic_lock, "캡차 건너뛰기",
                { "인증 데이터로 추적하지 못하게 함 · 자동 인증 지원 사이트에서만" },
                skipCaptchaTracking
            ) {
                toggleSkipCaptcha()
                skipCaptchaTracking
            }
            addToggle(
                R.drawable.ic_lock, "비밀번호·자동완성",
                { "로그인 정보 저장과 입력을 기기의 자동완성 서비스에 맡깁니다 · 시크릿 탭에서는 쓰지 않아요" },
                autofillEnabled
            ) {
                toggleAutofill()
                autofillEnabled
            }
            addRow(R.drawable.ic_phone, "자동완성 서비스", autofillServiceStatus()) { openAutofillSettings() }
            addRow(R.drawable.ic_delete, "방문 기록·캐시·쿠키 삭제") { clearBrowsingData() }
        }

        // 카드의 마지막 항목 아래 구분선은 지운다
        for (i in 0 until list.childCount) {
            val c = list.getChildAt(i) as? LinearLayout ?: continue
            if (c.tag != "menuCard" || c.childCount == 0) continue
            c.getChildAt(c.childCount - 1).findViewById<View>(R.id.rowDivider)?.visibility = View.GONE
        }

        if (sheet != null) {
            if (settings) {
                sheet.onBackPressedDispatcher.addCallback(sheet, object : OnBackPressedCallback(true) {
                    override fun handleOnBackPressed() {
                        dismissMenu()
                        showMenu(anchor)
                    }
                })
            }
            // 바깥(흐린 배경)을 눌러 닫아도 메뉴로 (뒤로가기는 위 콜백이 처리하고 dismiss 라서 여기로 오지 않는다)
            if (settings) sheet.setOnCancelListener { showMenu(anchor) }
            sheet.setContentView(view)
            sheet.behavior.maxWidth = dp(600)
            Motion.stagger(list, 90, 32, 360)
            // 뒤 페이지를 흐리게 + 시트를 반투명 유리처럼 (Android 12+ 에서 지원될 때만)
            // 시트 색은 태블릿 메뉴 팝업과 같은 colorSurfaceContainer 로 맞춘다 (블러 여부와 상관없이)
            val glass = Blur.behind(sheet.window, this)
            sheet.setOnShowListener {
                sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
                // 시트가 처음 배치될 때 기본 배경을 입히므로, 그 뒤에 같은 색의 배경으로 바꾼다
                sheet.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.let { v ->
                    v.post {
                        val r = dp(28).toFloat()
                        v.background = if (glass) {
                            Blur.glass(
                                this, com.google.android.material.R.attr.colorSurfaceContainer, r, topOnly = true
                            )
                        } else {
                            GradientDrawable().apply {
                                setColor(Blur.surface(this@MainActivity, com.google.android.material.R.attr.colorSurfaceContainer, false))
                                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                            }
                        }
                    }
                }
            }
            sheet.show()
            return
        }

        // 태블릿: 버튼 바로 아래, 버튼의 오른쪽 끝에 맞춰 뜨는 둥근 카드 팝업
        val anchorView = anchor ?: return
        // 팝업 창·프리폼 창에서도 맞도록 위치는 창 안 좌표(getLocationInWindow)와 창 크기로 계산한다
        val screenW = anchorView.rootView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val screenH = anchorView.rootView.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        val width = minOf(dp(360), screenW - dp(16))
        val loc = IntArray(2)
        anchorView.getLocationInWindow(loc)
        val locScreen = IntArray(2)
        anchorView.getLocationOnScreen(locScreen)
        val below = loc[1] + anchorView.height
        val maxH = (screenH - below - dp(12)).coerceAtLeast(dp(240))
        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val height = minOf(view.measuredHeight, maxH)
        val bg = Popup.anchoredBackground(this, view)
        val pw = PopupWindow(view, width, height, true).apply {
            setBackgroundDrawable(bg)
            isOutsideTouchable = true
            elevation = dp(Popup.ANCHORED_ELEVATION_DP).toFloat()
            animationStyle = R.style.Evergreen_MenuPopupAnim
        }
        popup = pw
        if (settings) {
            // 설정 팝업이 우리가 닫은 게 아니면(뒤로가기·바깥 누름) 메뉴로 돌아간다
            pw.setOnDismissListener {
                if (!closedByUs && !isFinishing && !isDestroyed && !isChangingConfigurations) showMenu(anchor)
            }
        }
        // 북마크 / 방문 기록 / 다운로드 팝업이 이 메뉴와 같은 자리에 뜨도록 기억해 둔다
        menuAnchorRight = locScreen[0] + anchorView.width   // 다른 창(목록 팝업)에 넘기는 값이라 화면 좌표
        menuAnchorBottom = locScreen[1] + anchorView.height
        menuAnchorWinRight = loc[0] + anchorView.width      // 앱 창 안 좌표 (목록 팝업의 위치 계산용)
        menuAnchorWinBottom = loc[1] + anchorView.height
        // 버튼의 오른쪽 끝에 맞추되 화면 밖으로는 나가지 않게
        val wantLeft = (loc[0] + anchorView.width - width).coerceIn(dp(8), (screenW - width - dp(8)).coerceAtLeast(dp(8)))
        Popup.prepareAnchoredEnter(view, loc[0] + anchorView.width / 2f - wantLeft, width)
        pw.showAsDropDown(anchorView, wantLeft - loc[0], dp(4))
        Blur.behindPopup(pw, this)
        Popup.playAnchoredEnter(view, list)
    }

    /**
     * UA 문자열과 Client Hints(Sec-CH-UA)를 함께 바꾼다.
     * WebView 는 UA 에서 "wv"를 지워도 Sec-CH-UA / navigator.userAgentData 에 "Android WebView" 브랜드를 실어 보내서,
     * 구글이 "브라우저 또는 앱이 안전하지 않을 수 있습니다"로 로그인을 막는다. 브랜드를 일반 Chrome 으로 맞춘다.
     */
    private fun applyUserAgent(wv: WebView, desktop: Boolean) {
        wv.settings.userAgentString = if (desktop) desktopUserAgent() else mobileUserAgent()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) return
        try {
            val full = Regex("Chrome/([\\d.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
            val major = full.substringBefore('.')
            val brands = listOf(
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Not)A;Brand").setMajorVersion("99").setFullVersion("99.0.0.0").build(),
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Chromium").setMajorVersion(major).setFullVersion(full).build(),
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Google Chrome").setMajorVersion(major).setFullVersion(full).build()
            )
            val md = androidx.webkit.UserAgentMetadata.Builder()
                .setBrandVersionList(brands)
                .setFullVersion(full)
                .setPlatform(if (desktop) "Linux" else "Android")
                .setPlatformVersion(if (desktop) "6.5.0" else (Build.VERSION.RELEASE + ".0.0"))
                .setMobile(!desktop)
                .setModel(if (desktop) "" else Build.MODEL)
                .setArchitecture(if (desktop) "x86" else "")
                .setBitness(if (desktop) 64 else 0)
                .build()
            WebSettingsCompat.setUserAgentMetadata(wv.settings, md)
        } catch (e: Exception) {
            // 지원하지 않는 WebView 면 UA 문자열 변경만 적용
        }
    }

    private fun mobileUserAgent(): String =
        baseUserAgent.replace("; wv", "").replace(" Version/4.0", "")

    private fun desktopUserAgent(): String {
        val ver = Regex("Chrome/([\\d.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$ver Safari/537.36"
    }

    /** PC용 화면 폭으로 레이아웃되도록 viewport 를 덮어쓴다. (UA 만 바꿔서는 모바일 폭으로 그려지는 사이트가 많음) */
    private fun desktopViewportJs(): String {
        val w = maxOf(resources.configuration.screenWidthDp, 1024)
        return "(function(){var m=document.querySelector('meta[name=viewport]');" +
            "if(!m){m=document.createElement('meta');m.name='viewport';" +
            "(document.head||document.documentElement).appendChild(m);}" +
            "m.setAttribute('content','width=$w');})();"
    }

    /** m.example.com / en.m.wikipedia.org 같은 모바일 전용 주소를 PC 주소로 바꾼다. */
    private fun toDesktopUrl(url: String): String {
        val host = Uri.parse(url).host ?: return url
        val newHost = when {
            host.startsWith("m.") -> {
                val rest = host.removePrefix("m.")
                if (rest.count { it == '.' } >= 2) rest else "www.$rest"
            }
            host.contains(".m.") -> host.replaceFirst(".m.", ".")
            else -> host
        }
        return if (newHost == host) url else url.replaceFirst(host, newHost)
    }

    /** 태블릿 툴바의 데스크톱/모바일 버튼: 지금 모드가 아니라 '누르면 바뀔 모드'를 아이콘으로 보여준다. */
    private fun updateDesktopButton() {
        val desktop = current?.desktop == true
        tbDesktop.setImageResource(if (desktop) R.drawable.ic_phone else R.drawable.ic_desktop)
        tbDesktop.contentDescription = if (desktop) "모바일 사이트로 보기" else "데스크톱 사이트로 보기"
    }

    private fun toggleDesktopSite() {
        val tab = current ?: return
        val on = !tab.desktop
        // 한 번 켜면 모든 탭·새 탭·앱을 다시 켠 뒤에도 유지된다 (끄기 전까지).
        prefs.desktopSite = on
        for (t in tabs) {
            t.desktop = on
            t.desktopInjected = false
            t.liveWebView?.let { applyUserAgent(it, on) }
        }
        updateDesktopButton()

        val url = tab.webView.url
        if (tab.isHome || url == null || url == "about:blank" || url == HOME_URL) {
            toast(if (tab.desktop) "데스크톱 모드: 이 탭에서 여는 페이지부터 적용됩니다" else "모바일 모드로 돌아갑니다")
            return
        }
        val target = if (tab.desktop && url.startsWith("http")) toDesktopUrl(url) else url
        if (target != url) tab.webView.loadUrl(target) else reloadTab(tab)
        toast(if (tab.desktop) "데스크톱 사이트로 다시 불러옵니다" else "모바일 사이트로 다시 불러옵니다")
    }

    private fun groupCurrentTab() {
        val tab = current ?: return
        showGroupEditor(null) { name, color ->
            moveToGroup(tab, createGroup(name, color))
            // 상단 탭줄(그룹 알약·색 막대)과 탭 전환 화면을 다시 그린다
            scheduleStripRefresh()
            if (switcherOpen) refreshSwitcher(false)
            toast("'$name' 그룹에 추가했습니다")
        }
    }

    // ───────────────────────── 스크롤 시 바 숨김 ─────────────────────────

    private fun onPageScroll(tab: BrowserTab, y: Int, oldY: Int) {
        if (tab === current) pageScrollBar.refresh()
        // 창 크기가 바뀌는 중에 내용이 다시 배치되며 생기는 스크롤은 '사용자가 옮긴 위치'가 아니므로 기록하지 않는다
        if (resizeBurst) return
        tab.scrollRatio = scrollRatioOf(tab.liveWebView)
        if (!hideBarsOnScroll || tab !== current || switcherOpen || urlBar.hasFocus() ||
            findBar.visibility == View.VISIBLE) return
        // 손가락으로 스크롤하는 동안은 바가 손가락을 따라가므로 여기서 건드리지 않는다
        if (barsGestureActive) return
        // 위로 스크롤해서(관성 포함) 맨 위에 닿으면 바를 다시 보여 준다
        if (y <= dp(8) && y < oldY) {
            scrollAcc = 0
            setBarsHidden(false)
        }
    }

    private class BarsGeom(
        val first: View,
        val other: View,
        val flp: LinearLayout.LayoutParams,
        val olp: LinearLayout.LayoutParams,
        val blp: LinearLayout.LayoutParams,
        val frame: View,
        val topH: Int,
        val bh: Int
    )

    private var imeVisible = false
    private var barsViewportReady = true
    private var barsWaitToken = Any()

    /**
     * 웹 영역을 키운 뒤, 페이지의 viewport(window.innerHeight)가 실제로 새 높이가 될 때까지 기다렸다가 block 실행.
     * 고정된 지연(120~180ms) 대신 확인하므로 느린 페이지에서도 하단에 흰 줄이 보이지 않는다. 최대 700ms 까지만 기다린다.
     * @param minHeightPx 레이아웃이 다시 잡혔다고 볼 수 있는 WebView 최소 높이
     */
    private fun whenViewportMatches(wv: WebView?, minHeightPx: Int, block: () -> Unit) {
        val token = Any()
        barsWaitToken = token
        if (wv == null || wv.parent !== webContainer) { block(); return }
        val start = android.os.SystemClock.uptimeMillis()
        fun check() {
            if (barsWaitToken !== token) return
            if (android.os.SystemClock.uptimeMillis() - start > 700) { block(); return }
            if (wv.height < minHeightPx) { wv.postDelayed({ check() }, 30); return }
            @Suppress("DEPRECATION")
            val scale = wv.scale.takeIf { it > 0f } ?: resources.displayMetrics.density
            val expected = wv.height / scale
            wv.evaluateJavascript("window.innerHeight") { r ->
                if (barsWaitToken !== token) return@evaluateJavascript
                val h = r?.trim('"')?.toFloatOrNull()
                if (h != null && h >= expected * 0.97f) block() else wv.postDelayed({ check() }, 40)
            }
        }
        check()
    }
    private var barsSizeListenerRef: View.OnLayoutChangeListener? = null
    private var barsSyncedTopH = -1

    /** 태블릿 + 키보드 없음 (스크롤 숨김 설정과 무관) → 웹 영역을 처음부터 전체 화면 크기로 고정한다. */
    private fun barsFullWanted(): Boolean = false   // 항상 전체 크기로 두면 바가 보일 때 페이지 아래가 잘려서 사용하지 않는다

    /** 전체 크기 고정 레이아웃을 맞춘다 (바 높이가 바뀌었을 때, 설정·키보드 상태가 바뀌었을 때 호출). */
    private fun barsSyncFullLayout() {
        val g = barsGeom() ?: return
        if (g.topH <= 0) return
        if (barsFullWanted()) {
            if (barsLayoutHidden && barsSyncedTopH == g.topH) return
            barsEnterHidden(g)
            barsApply(g, barsFraction)
            barsSyncedTopH = g.topH
            homeView.setPadding(0, 0, 0, g.topH)   // 홈 화면은 보이는 영역 가운데에 오도록
            barsResync()
        } else {
            homeView.setPadding(0, 0, 0, 0)
            barsSyncedTopH = -1
            if (barsLayoutHidden && barsFraction == 0f && barsAnim?.isRunning != true && !barsGestureActive) {
                barsEnterShown(g)
            }
        }
    }

    private fun barsGeom(): BarsGeom? {
        val stripShown = tabStripBar.visibility == View.VISIBLE
        val first: View = if (stripShown) tabStripBar else toolbarView
        val other: View = if (stripShown) toolbarView else tabStripBar
        val flp = first.layoutParams as? LinearLayout.LayoutParams ?: return null
        val olp = other.layoutParams as? LinearLayout.LayoutParams ?: return null
        val blp = bottomBar.layoutParams as? LinearLayout.LayoutParams ?: return null
        val frame = webContainer.parent as? View ?: return null
        val topH = (if (stripShown) tabStripBar.height else 0) + toolbarView.height
        val bh = if (bottomBar.visibility == View.VISIBLE) bottomBar.height else 0
        return BarsGeom(first, other, flp, olp, blp, frame, topH, bh)
    }

    /** '숨김 형태' 레이아웃에서의 표시 상태. f = 0 보임, 1 숨김. 바와 웹 영역이 같은 만큼 함께 움직인다. */
    private fun barsApply(g: BarsGeom, f: Float) {
        barsFraction = f
        val ty = g.topH * (1f - f)
        g.first.translationY = ty
        g.other.translationY = ty
        progressBar.translationY = ty
        g.frame.translationY = ty
        bottomBar.translationY = -g.bh * (1f - f)
    }

    /** 웹 영역을 화면 전체 크기로 키운다. 눈에 보이는 모습은 그대로이고 늘어난 부분은 화면 밖(아래)에 있다. */
    private fun barsEnterHidden(g: BarsGeom) {
        g.olp.topMargin = 0
        g.flp.topMargin = -g.topH
        g.blp.bottomMargin = -g.bh
        g.first.layoutParams = g.flp
        g.other.layoutParams = g.olp
        bottomBar.layoutParams = g.blp
        barsLayoutHidden = true
    }

    /** 바가 완전히 보이는 보통 레이아웃으로 되돌린다 (웹 영역이 줄어드는 쪽이라 빈 영역이 생기지 않는다). */
    private fun barsEnterShown(g: BarsGeom) {
        if (barsFullWanted()) {
            // 태블릿: 웹 영역은 항상 화면 전체 크기. 바가 보일 때는 아래로 밀기만 한다 (크기 변화 없음 → 흰 줄 없음)
            barsApply(g, 0f)
            barsLayoutHidden = true
            barsResync()
            return
        }
        g.olp.topMargin = 0
        g.flp.topMargin = 0
        g.blp.bottomMargin = 0
        g.first.layoutParams = g.flp
        g.other.layoutParams = g.olp
        bottomBar.layoutParams = g.blp
        g.first.translationY = 0f
        g.other.translationY = 0f
        progressBar.translationY = 0f
        g.frame.translationY = 0f
        bottomBar.translationY = 0f
        barsFraction = 0f
        barsLayoutHidden = false
        barsViewportReady = true
        barsResync()
    }

    private fun barsResync() {
        browserUi.requestLayout()
        webContainer.requestLayout()
        browserUi.invalidate()
        webContainer.invalidate()
        pageScrollBar.refresh()
        current?.webView?.let { wv ->
            wv.requestLayout()
            wv.invalidate()
            wv.post {
                if (wv.parent === webContainer) {
                    wv.requestLayout()
                    wv.invalidate()
                    wv.postInvalidateOnAnimation()
                    pageScrollBar.refresh()
                }
            }
        }
    }

    private fun barsAnimateTo(g: BarsGeom, to: Float) {
        barsAnim?.cancel()
        val duration = (220f * kotlin.math.abs(to - barsFraction)).toLong().coerceAtLeast(120L)
        barsAnim = android.animation.ValueAnimator.ofFloat(barsFraction, to).apply {
            this.duration = duration
            interpolator = android.view.animation.PathInterpolator(0.4f, 0f, 0.2f, 1f)
            var cancelled = false
            addUpdateListener { barsApply(g, it.animatedValue as Float) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationCancel(a: android.animation.Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (cancelled || barsGestureActive) return
                    if (to == 0f) barsEnterShown(g) else barsResync()
                }
            })
            start()
        }
    }

    /**
     * 메뉴바를 숨기거나 되돌린다 (탭 전환·맨 위 도달 등 손가락 스크롤이 아닐 때).
     * 손가락으로 스크롤할 때는 onBarsPreScroll 이 바를 손가락에 맞춰 직접 움직인다.
     *
     * 웹 영역의 크기를 애니메이션 도중에 바꾸면 WebView 가 늘어난 영역을 바로 못 그려서 하단에
     * 흰 네모가 보인다. 그래서 크기가 바뀌는 순간은 항상 화면 밖에서 일어나게 한다.
     *  - 숨길 때: 웹 영역을 먼저 '전체 크기'로 키우고(늘어난 부분은 화면 밖), WebView 가 새 크기로
     *    그려질 시간을 준 뒤 바와 웹 영역을 함께 위로 밀어 올린다.
     *  - 보일 때: 바와 웹 영역을 함께 내린 다음, 끝난 뒤에 웹 영역을 줄인다.
     */
    private fun setBarsHidden(hide: Boolean) {
        val target = if (hide) 1f else 0f
        if (barsTarget == target) return
        barsTarget = target
        barsGestureActive = false   // 탭 전환 등으로 손가락 스크롤이 끊겼을 때 상태가 남지 않게
        barsAnim?.cancel()
        barsStartRunnable?.let { webContainer.removeCallbacks(it) }
        barsStartRunnable = null
        val g = barsGeom() ?: return
        applyStatusBarForScroll(hide)
        if (hide) {
            if (!barsLayoutHidden) {
                val heightBefore = current?.webView?.height ?: 0
                barsEnterHidden(g)
                barsApply(g, 0f)
                if (!Motion.enabled(this)) {
                    val wv0 = current?.webView?.takeIf { it.parent === webContainer }
                    whenViewportMatches(wv0, heightBefore + g.topH - dp(6)) {
                        if (barsTarget == 1f) { barsApply(g, 1f); barsResync() }
                    }
                    return
                }
                val starter = object : Runnable {
                    override fun run() {
                        if (barsStartRunnable !== this) return
                        barsStartRunnable = null
                        if (barsTarget == 1f) barsAnimateTo(g, 1f)
                    }
                }
                barsStartRunnable = starter
                val wv = current?.webView?.takeIf { it.parent === webContainer }
                whenViewportMatches(wv, heightBefore + g.topH - dp(6)) { webContainer.post(starter) }
            } else if (!Motion.enabled(this)) {
                barsApply(g, 1f)
                barsResync()
            } else {
                barsAnimateTo(g, 1f)
            }
        } else {
            if (!barsLayoutHidden) return
            if (!Motion.enabled(this)) barsEnterShown(g) else barsAnimateTo(g, 0f)
        }
    }

    // ───────────────────────── 손가락을 따라가는 메뉴바 ─────────────────────────

    private fun barsGestureAllowed(): Boolean {
        if (!hideBarsOnScroll || switcherOpen || urlBar.hasFocus() || findBar.visibility == View.VISIBLE) return false
        val c = current ?: return false
        return !c.isHome
    }

    private fun onBarsGestureStart() {
        barsGestureActive = true
        barsGestureDy = 0
        barsLastDir = 0
        barsAnim?.cancel()
        barsStartRunnable?.let { webContainer.removeCallbacks(it) }
        barsStartRunnable = null
    }

    /** 손가락이 dy 만큼 움직일 때 바가 먼저 쓰고 남은 만큼을 페이지가 스크롤한다. 쓴 양을 돌려준다. */
    private fun onBarsPreScroll(dy: Int): Int {
        if (dy == 0 || !barsGestureAllowed()) return 0
        barsGestureDy += dy
        barsLastDir = if (dy > 0) 1 else -1
        val g = barsGeom() ?: return 0
        val travel = maxOf(1, g.topH).toFloat()
        val now = android.os.SystemClock.uptimeMillis()
        if (dy > 0) {
            if (!barsLayoutHidden) {
                // 살짝 스친 정도로는 크기를 바꾸지 않는다
                if (barsGestureDy < dp(8)) return 0
                // 웹 영역을 먼저 키우고 WebView 가 새 크기로 그려질 시간을 준 뒤부터 바가 움직인다
                val wv = current?.webView?.takeIf { it.parent === webContainer }
                val heightBefore = wv?.height ?: 0
                barsEnterHidden(g)
                barsApply(g, 0f)
                barsViewportReady = false
                whenViewportMatches(wv, heightBefore + g.topH - dp(6)) {
                    barsViewportReady = true
                    if (!barsGestureActive) barsStartRunnable?.let { webContainer.post(it) }
                }
                return 0
            }
            if (!barsViewportReady) return 0
            val avail = ((1f - barsFraction) * travel + 0.5f).toInt()
            val c = minOf(dy, avail)
            if (c <= 0) return 0
            barsApply(g, minOf(1f, barsFraction + c / travel))
            return c
        } else {
            if (!barsLayoutHidden || barsFraction <= 0f || !barsViewportReady) return 0
            val avail = (barsFraction * travel + 0.5f).toInt()
            val c = maxOf(dy, -avail)
            if (c >= 0) return 0
            barsApply(g, maxOf(0f, barsFraction + c / travel))
            return c
        }
    }

    /** 손가락을 떼면 움직이던 방향으로 끝까지 숨기거나 보여 준다. */
    private fun onBarsGestureStop() {
        if (!barsGestureActive) return
        barsGestureActive = false
        if (!barsLayoutHidden) return
        val g = barsGeom() ?: return
        val hide = when {
            barsFraction >= 1f -> true
            barsLastDir > 0 -> true
            barsLastDir < 0 -> false
            else -> barsFraction >= 0.5f
        }
        barsTarget = if (hide) 1f else 0f
        applyStatusBarForScroll(hide)
        if (!Motion.enabled(this)) {
            if (hide) { barsApply(g, 1f); barsResync() } else barsEnterShown(g)
            return
        }
        if (hide && !barsViewportReady) {
            // 빠르게 튕긴 경우: WebView 가 새 크기로 그려질 때까지 조금 기다렸다가 올린다
            val starter = object : Runnable {
                override fun run() {
                    if (barsStartRunnable !== this) return
                    barsStartRunnable = null
                    if (barsTarget == 1f && !barsGestureActive) barsGeom()?.let { barsAnimateTo(it, 1f) }
                }
            }
            barsStartRunnable = starter   // 렌더링 확인이 끝나면 whenViewportMatches 콜백이 실행한다
        } else {
            barsAnimateTo(g, if (hide) 1f else 0f)
        }
    }

    /** 스크롤 숨김과 함께 상태표시줄도 숨기거나 되돌린다. 전체화면 영상 중에는 건드리지 않는다. */
    private fun applyStatusBarForScroll(hide: Boolean) {
        if (customView != null) return
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (hide && hideStatusBarOnScroll) {
            if (statusBarHiddenByScroll) return
            statusBarHiddenByScroll = true
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.statusBars())
        } else if (statusBarHiddenByScroll) {
            statusBarHiddenByScroll = false
            controller.show(WindowInsetsCompat.Type.statusBars())
        }
    }

    /** 탭의 웹뷰에 보안 설정(Safe Browsing, 서드파티 쿠키)을 적용한다. */
    private fun applySecurity(wv: WebView, tab: BrowserTab? = null) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
            WebSettingsCompat.setSafeBrowsingEnabled(wv.settings, malwareWarning)
        }
        // 서드파티 쿠키를 막으면 인증(캡차) 제공업체가 사이트 간에 나를 따라다니며 추적하기 어렵다.
        cookieManagerFor(tab).setAcceptThirdPartyCookies(wv, !skipCaptchaTracking)
    }

    private fun toggleStrictTrackers() {
        strictTrackers = !strictTrackers
        prefs.strictTrackers = strictTrackers
        toast(if (strictTrackers) "트래커 차단(엄격) 켜짐" else "트래커 차단(엄격) 꺼짐")
        current?.let { reloadTab(it) }
    }

    private fun toggleSkipCaptcha() {
        skipCaptchaTracking = !skipCaptchaTracking
        prefs.skipCaptchaTracking = skipCaptchaTracking
        tabs.forEach { t -> t.liveWebView?.let { applySecurity(it, t) } }
        toast(if (skipCaptchaTracking) "캡차 건너뛰기 켜짐 (지원 사이트에서만 동작)" else "캡차 건너뛰기 꺼짐")
    }

    private fun toggleMalwareWarning() {
        malwareWarning = !malwareWarning
        prefs.malwareWarning = malwareWarning
        tabs.forEach { t -> t.liveWebView?.let { applySecurity(it, t) } }
        toast(if (malwareWarning) "악성 사이트 알림 켜짐" else "악성 사이트 알림 꺼짐")
    }

    private fun toggleBlockAutoDownload() {
        blockAutoDownload = !blockAutoDownload
        prefs.blockAutoDownload = blockAutoDownload
        toast(if (blockAutoDownload) "자동 다운로드 차단 켜짐" else "자동 다운로드 차단 꺼짐")
    }

    private fun toggleAdBlock() {
        adBlockEnabled = !adBlockEnabled
        prefs.adBlock = adBlockEnabled
        toast(if (adBlockEnabled) "광고 차단 켜짐" else "광고 차단 꺼짐")
        current?.let { reloadTab(it) }
    }

    private fun showAdBlockStats() {
        val tab = current
        AdBlockStatsUi.show(
            ctx = this,
            blocker = adBlocker,
            enabled = adBlockEnabled,
            pageBlocked = if (tab == null || tab.isHome) null else tab.adBlocked.get(),
            trackerBlocked = if (strictTrackers) trackerBlocker.blockedCount.get() else null,
            onUpdate = { updateAdBlockList() }
        )
    }

    /** 설정 > 광고 직접 선택: 지금 보는 페이지를 선택 모드로 바꾼다 */
    private fun startAdPicker() {
        val tab = current
        if (tab == null || tab.isHome || tab.errorUrl != null) {
            toast("먼저 광고가 있는 페이지를 열어 주세요")
            return
        }
        if (!adBlockEnabled) {
            toast("광고 차단을 먼저 켜 주세요")
            return
        }
        // 메뉴는 이미 닫혔다. 페이지 안에 선택 화면(안내 막대)이 뜨고, 누르는 요소가 빨갛게 표시된다
        tab.webView.evaluateJavascript(AdScripts.PICKER_JS, null)
        toast("차단할 광고를 눌러 주세요")
    }

    private fun showUserAdRules() {
        AdBlockUserRulesUi.show(this, adBlocker, false) {
            // 삭제한 규칙은 새로 불러와야 화면에 되살아난다
            current?.let { if (!it.isHome) reloadTab(it) }
        }
    }

    private fun updateAdBlockList() {
        toast("차단 목록을 내려받는 중…")
        io.execute {
            try {
                val n = adBlocker.update()
                ui.post { toast("차단 목록 적용 완료 (${n}개 도메인)") }
            } catch (e: Exception) {
                ui.post { toast("업데이트 실패: ${e.message}") }
            }
        }
    }

    private fun showEngineDialog() {
        val engines = prefs.allEngines()
        val selected = engines.indexOfFirst { it.key == prefs.engineKey }.coerceAtLeast(0)
        val hasCustom = engines.any { it.custom }
        val labels = ArrayList<String>()
        engines.forEach { labels.add(if (it.custom) it.name + "  (직접 추가)" else it.name) }
        labels.add("＋ 검색엔진 추가")
        if (hasCustom) labels.add("추가한 검색엔진 삭제…")
        MaterialAlertDialogBuilder(this)
            .setTitle("검색 엔진")
            .setSingleChoiceItems(labels.toTypedArray(), selected) { d, which ->
                d.dismiss()
                when {
                    which < engines.size -> {
                        prefs.engineKey = engines[which].key
                        refreshSettingsAfterEngine()
                    }
                    which == engines.size -> showAddEngineDialog()
                    else -> showRemoveEngineDialog()
                }
            }
            .show()
    }

    /** 홈 버튼을 눌렀을 때 열 홈 페이지를 정한다. 비워 두고 저장하면 기본(새 탭 화면)으로 돌아간다 */
    private fun showHomepageDialog() {
        val et = EditText(this).apply {
            setText(prefs.homepage)
            hint = "https://www.example.com"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSelection(text.length)
        }
        val cb = android.widget.CheckBox(this).apply {
            text = "새 탭에서도 이 페이지 열기"
            isChecked = prefs.homepageOnNewTab
        }
        val help = TextView(this).apply {
            text = "홈 버튼을 누르면 이 주소가 열려요. 비워 두면 기본 새 탭 화면을 써요."
            textSize = 12f
            alpha = 0.7f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(et)
            addView(help, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
            addView(cb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        fun save() {
            var u = et.text.toString().trim()
            if (u.isNotEmpty() && !u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
            prefs.homepage = u
            prefs.homepageOnNewTab = cb.isChecked && u.isNotEmpty()
            toast(if (u.isEmpty()) "홈 페이지: 기본 (새 탭 화면)" else "홈 페이지를 저장했어요")
        }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("홈 페이지")
            .setView(box)
            .setNegativeButton("취소", null)
            .setNeutralButton("기본값") { _, _ ->
                prefs.homepage = ""
                prefs.homepageOnNewTab = false
                toast("홈 페이지: 기본 (새 탭 화면)")
            }
            .setPositiveButton("저장") { _, _ -> save() }
            .create()
        et.setOnEditorActionListener { _, _, _ -> save(); dlg.dismiss(); true }
        dlg.show()
        et.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** 설정 화면이 떠 있어도 '현재: …' 글자가 바뀌어 보이게 한다 */
    private fun refreshSettingsAfterEngine() {
        toast("검색 엔진: ${prefs.currentEngine().name}")
    }

    /** 검색엔진 직접 추가: 이름 + 검색 주소. 주소에서 검색어 자리는 %s 로 적는다 */
    private fun showAddEngineDialog() {
        val etName = EditText(this).apply {
            hint = "이름 (예: 쿠팡)"
            setSingleLine()
            filters = arrayOf(android.text.InputFilter.LengthFilter(20))
        }
        val etUrl = EditText(this).apply {
            hint = "https://www.coupang.com/np/search?q=%s"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val help = TextView(this).apply {
            text = "검색 주소에서 검색어가 들어갈 자리를 %s 로 적어 주세요.\n" +
                "(예: https://www.google.com/search?q=%s)\n" +
                "사이트에서 아무거나 검색한 뒤 주소창의 주소를 복사해서, 검색어 부분만 %s 로 바꾸면 돼요."
            textSize = 12f
            alpha = 0.7f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(etName)
            addView(etUrl)
            addView(help, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("검색엔진 추가")
            .setView(box)
            .setNegativeButton("취소", null)
            .setPositiveButton("추가", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = etName.text.toString().trim()
                var url = etUrl.text.toString().trim()
                val err = when {
                    name.isEmpty() -> "이름을 입력해 주세요"
                    url.isEmpty() -> "검색 주소를 입력해 주세요"
                    else -> null
                }
                if (err != null) { toast(err); return@setOnClickListener }
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                // %s / {searchTerms} / {q} 중 어느 것으로 적어도 받아 준다
                val marker = listOf("%s", "{searchTerms}", "{query}", "{q}").firstOrNull { url.contains(it) }
                if (marker == null) { toast("검색어가 들어갈 자리를 %s 로 적어 주세요"); return@setOnClickListener }
                val idx = url.indexOf(marker)
                val prefix = url.substring(0, idx)
                val suffix = url.substring(idx + marker.length)
                val host = Uri.parse(url.replace(marker, "x")).let { u ->
                    if (u.scheme != null && !u.host.isNullOrEmpty()) "${u.scheme}://${u.host}" else null
                }
                if (host == null) { toast("주소 형식이 올바르지 않아요"); return@setOnClickListener }
                val key = "custom_" + System.currentTimeMillis()
                prefs.addCustomEngine(SearchEngine(key, name, prefix, host, suffix, true))
                prefs.engineKey = key
                dlg.dismiss()
                toast("검색엔진을 추가했어요: $name")
            }
        }
        dlg.show()
        etName.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** 직접 추가한 검색엔진 지우기 */
    private fun showRemoveEngineDialog() {
        val customs = prefs.customEngines()
        if (customs.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("삭제할 검색엔진")
            .setItems(customs.map { it.name }.toTypedArray()) { _, which ->
                val e = customs[which]
                Popup.confirm(this, "검색엔진 삭제", "'${e.name}' 검색엔진을 삭제할까요?", "삭제", danger = true) {
                    prefs.removeCustomEngine(e.key)
                    toast("삭제했어요")
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    /** 삭제하기 전에 한 번 더 물어본다 */
    private fun clearBrowsingData() {
        Popup.confirm(
            this,
            "방문 기록·캐시·쿠키 삭제",
            "방문 기록, 캐시, 쿠키와 사이트 저장 데이터를 모두 삭제할까요?\n\n" +
                "로그인된 사이트에서 로그아웃될 수 있고, 삭제한 데이터는 되돌릴 수 없어요.",
            "삭제", danger = true
        ) { doClearBrowsingData() }
    }

    private fun doClearBrowsingData() {
        tabs.forEach {
            it.liveWebView?.clearCache(true)
            it.liveWebView?.clearHistory()
            it.redirectSources.clear()
        }
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies(null)
        prefs.clearHistory()
        toast("삭제했습니다")
    }

    // ───────────────────────── 영상 재생 속도 ─────────────────────────

    private fun speedJs(rate: Float): String = """
        (function(r){
          window.__sbRate = r;
          function apply(){
            document.querySelectorAll('video,audio').forEach(function(v){
              if (v.playbackRate !== window.__sbRate) v.playbackRate = window.__sbRate;
            });
          }
          apply();
          if (window.__sbRateTimer) { clearInterval(window.__sbRateTimer); window.__sbRateTimer = null; }
          if (r !== 1) window.__sbRateTimer = setInterval(apply, 800);
        })($rate);
    """.trimIndent()

    // ───────────────────────── HTTPS 우선 연결 ─────────────────────────

    private var httpsFirst = true

    /** 이번 실행 동안 http 로 열기로 허락받은 사이트 */
    private val httpAllowed: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** http 주소를 https 로 올린 주소를 돌려준다. 올리지 않을 주소(이미 https, 내부망·IP, 허락받은 사이트)는 null */
    private fun upgradeUrl(url: String): String? {
        if (!httpsFirst || !url.startsWith("http://")) return null
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return null
        val internal = !host.contains('.') || host == "localhost" || host.endsWith(".local") ||
            host.endsWith(".lan") || host.endsWith(".internal") || host.endsWith(".home") ||
            Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host) || host.contains(':')
        if (internal || host in httpAllowed) return null
        return "https://" + url.removePrefix("http://")
    }

    private fun askHttpFallback(tab: BrowserTab, view: WebView, httpUrl: String) {
        if (isFinishing || isDestroyed || tab !in tabs || tab !== current) return
        val host = runCatching { Uri.parse(httpUrl).host }.getOrNull() ?: return
        MaterialAlertDialogBuilder(this)
            .setTitle("보안 연결(HTTPS)을 쓸 수 없어요")
            .setMessage("$host\n\n이 사이트는 보안 연결을 지원하지 않는 것 같아요. 보안되지 않은 연결(http)로 계속하면 주고받는 내용이 다른 사람에게 보일 수 있어요.")
            .setPositiveButton("http로 계속") { _, _ ->
                httpAllowed.add(host.lowercase())
                tab.upgradedFrom = null
                view.loadUrl(httpUrl)
            }
            .setNegativeButton("취소") { _, _ -> tab.upgradedFrom = null }
            .setOnCancelListener { tab.upgradedFrom = null }
            .show()
    }

    private fun toggleHttpsFirst() {
        httpsFirst = !httpsFirst
        prefs.httpsFirst = httpsFirst
        toast(if (httpsFirst) "HTTPS 우선 연결 켜짐" else "HTTPS 우선 연결 꺼짐")
    }

    // ───────────────────────── 비밀번호 · 자동완성 ─────────────────────────

    private var autofillEnabled = true

    /**
     * 웹뷰의 로그인 폼을 안드로이드 자동완성 프레임워크(Google·삼성 패스·Bitwarden 등)에 연결한다.
     * 시크릿 탭은 저장·입력 대상에서 뺀다.
     */
    private fun applyAutofill(tab: BrowserTab) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        tab.webView.importantForAutofill =
            if (autofillEnabled && !tab.incognito) View.IMPORTANT_FOR_AUTOFILL_YES
            else View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
    }

    private fun toggleAutofill() {
        autofillEnabled = !autofillEnabled
        prefs.autofill = autofillEnabled
        tabs.forEach { applyAutofill(it) }
        if (!autofillEnabled && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            // 입력 중이던 폼이 있으면 저장 안내가 뜨지 않도록 취소
            getSystemService(android.view.autofill.AutofillManager::class.java)?.cancel()
        }
        toast(if (autofillEnabled) "비밀번호·자동완성 켜짐" else "비밀번호·자동완성 꺼짐")
    }

    private fun autofillServiceStatus(): String {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) {
            return "Android 8.0 이상에서 지원됩니다"
        }
        val afm = getSystemService(android.view.autofill.AutofillManager::class.java)
        return when {
            afm == null || !afm.isAutofillSupported -> "이 기기에서는 자동완성을 쓸 수 없어요"
            afm.hasEnabledAutofillServices() -> "사용 중인 서비스가 있어요 · 눌러서 바꾸기"
            else -> "선택된 서비스가 없어요 · 눌러서 비밀번호 관리자 고르기"
        }
    }

    /** 기기의 자동완성 서비스 선택 화면을 연다 (없으면 설정 앱의 일반 화면) */
    private fun openAutofillSettings() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        val intent = Intent(android.provider.Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE)
            .setData(Uri.parse("package:$packageName"))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
                toast("설정 화면을 열 수 없어요")
            }
        }
    }

    // ───────────────────────── 웹 화면: 다크 모드 · 글자 크기 ─────────────────────────

    /** 0 = 끔, 1 = 기기가 다크 모드일 때만, 2 = 항상 */
    private var darkMode = 1
    private var textZoom = 100

    private fun systemNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** 기기가 밝은 모드인데 "항상 켜기"인 경우: 시스템 기능으로는 안 되므로 CSS 로 색을 뒤집는다 */
    private fun needCssDark(): Boolean = darkMode == 2 && !systemNight()

    private fun darkModeLabel(): String = when (darkMode) {
        0 -> "끄기"
        2 -> "항상 켜기"
        else -> "기기가 다크 모드일 때"
    }

    private fun forceDarkJs(on: Boolean): String = if (on) {
        "(function(){if(document.getElementById('ev-dark'))return;var s=document.createElement('style');" +
            "s.id='ev-dark';s.textContent='html{background:#fff!important;filter:invert(1) hue-rotate(180deg)!important}" +
            "img,picture,video,canvas,iframe{filter:invert(1) hue-rotate(180deg)!important}';" +
            "(document.head||document.documentElement).appendChild(s)})()"
    } else {
        "(function(){var s=document.getElementById('ev-dark');if(s)s.remove()})()"
    }

    /** 웹뷰에 글자 크기와 다크 모드를 적용한다 */
    private fun applyWebAppearance(wv: WebView) {
        wv.settings.textZoom = textZoom
        val dark = darkMode != 0 && systemNight()
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(wv.settings, dark)
            } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                @Suppress("DEPRECATION")
                WebSettingsCompat.setForceDark(
                    wv.settings,
                    if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
                )
            }
        } catch (e: Exception) {
            // 지원하지 않는 WebView 면 그대로 둔다
        }
    }

    private fun showDarkModeDialog() {
        val labels = arrayOf("끄기", "기기가 다크 모드일 때", "항상 켜기")
        MaterialAlertDialogBuilder(this)
            .setTitle("웹 페이지 다크 모드")
            .setSingleChoiceItems(labels, darkMode) { d, which ->
                darkMode = which
                prefs.webDarkMode = which
                tabs.forEach { t ->
                    t.liveWebView?.let { applyWebAppearance(it) }
                    t.darkInjected = false
                    // 지금 열려 있는 페이지에도 바로 반영 (CSS 방식은 켜고 끄기를 스크립트로)
                    if (!t.isHome) t.liveWebView?.evaluateJavascript(forceDarkJs(needCssDark()), null)
                    if (needCssDark()) t.darkInjected = true
                }
                d.dismiss()
                toast("다크 모드: ${darkModeLabel()}")
            }
            .show()
    }

    // ───────────────────────── 페이지 확대/축소 (50% ~ 500%) ─────────────────────────

    private fun effectiveZoom(tab: BrowserTab): Int = (tab.pageZoom ?: prefs.pageZoom).coerceIn(50, 500)

    /**
     * 핀치 줌이 아니라 페이지 자체를 키우고 줄인다 (PC 브라우저의 Ctrl +/- 와 같은 방식).
     * 레이아웃 뷰포트 너비를 (화면 너비 ÷ 배율) 로 바꿔서, 글자·이미지·여백이 함께 커지고 줄이 다시 나뉜다.
     * 100% 면 원래 뷰포트로 되돌린다. 사이트가 뷰포트 설정을 다시 바꾸면 곧바로 다시 덮어쓴다.
     */
    private fun pageZoomJs(tab: BrowserTab, zoom: Int? = null): String {
        val z = (zoom ?: effectiveZoom(tab)).coerceIn(50, 500)
        if (z == 100) return PAGE_ZOOM_OFF_JS
        val wv = tab.liveWebView
        val dp = if (wv != null && wv.width > 0) (wv.width / resources.displayMetrics.density).toInt()
        else resources.configuration.screenWidthDp
        val base = if (tab.desktop) maxOf(dp, 1024) else maxOf(dp, 1)
        val w = (base * 100f / z).coerceAtLeast(1f)
        return "(function(){var W=${"%.2f".format(java.util.Locale.US, w)};" + PAGE_ZOOM_ON_JS + "})();"
    }

    private fun applyPageZoom(tab: BrowserTab) {
        if (tab.isHome) return
        tab.zoomInjected = true
        tab.liveWebView?.evaluateJavascript(pageZoomJs(tab), null)
    }

    /** 확대/축소·글자 크기 팝업이 함께 쓰는 게이지 영역 (큰 배율 숫자 + 게이지바 + 양 끝 값) */
    private class GaugeParts(val label: TextView, val gauge: ZoomGauge, val ends: View)

    private fun themeColor(attr: Int, fallback: Int) =
        MaterialColors.getColor(this, attr, ContextCompat.getColor(this, fallback))

    private fun gaugeParts(min: Int, max: Int, step: Int, value: Int, desc: String): GaugeParts {
        val cPrimary = themeColor(com.google.android.material.R.attr.colorPrimary, R.color.ev_accent)
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val cTrack = themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill)
        val label = TextView(this).apply {
            textSize = 44f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(cPrimary)
            setPadding(0, dp(4), 0, dp(12))
        }
        val gauge = ZoomGauge(this).apply {
            this.min = min; this.max = max; this.step = step; defaultValue = 100
            activeColor = cPrimary
            inactiveColor = cTrack
            dotOnActiveColor = android.graphics.Color.WHITE
            this.value = value
            contentDescription = desc
        }
        fun endLabel(t: String) = TextView(this).apply {
            text = t
            textSize = 12f
            setTextColor(cMuted)
        }
        val ends = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, 0)
            addView(endLabel("${min}%"))
            addView(android.view.View(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(endLabel("${max}%"))
        }
        setPercentLabel(label, value)
        return GaugeParts(label, gauge, ends)
    }

    private fun setPercentLabel(label: TextView, v: Int) {
        val sp = android.text.SpannableString("${v}%")
        sp.setSpan(android.text.style.RelativeSizeSpan(0.5f), sp.length - 1, sp.length,
            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        label.text = sp
    }

    private fun showPageZoomDialog() {
        val tab = current ?: return
        val zMin = 50
        val zMax = 500
        val zStep = 10
        var applied = false

        val cOnSurface = themeColor(com.google.android.material.R.attr.colorOnSurface, R.color.ev_text)
        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        val cTrack = themeColor(com.google.android.material.R.attr.colorSurfaceContainerHighest, R.color.ev_pill)

        var zoom = (Math.round((effectiveZoom(tab) - zMin) / zStep.toFloat()) * zStep + zMin).coerceIn(zMin, zMax)
        val parts = gaugeParts(zMin, zMax, zStep, zoom, "화면 확대/축소")

        // 다른 팝업의 항목(popup_item)과 같은 안쪽 여백: 목록 8dp + 12dp = 머리말 글자와 같은 20dp
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }

        // '이 탭에만 적용': 한 줄 (제목 + 설명 / 스위치)
        val tabOnly = com.google.android.material.materialswitch.MaterialSwitch(this).apply {
            isChecked = tab.pageZoom != null
        }
        val tabOnlyTitle = TextView(this).apply {
            text = "이 탭에만 적용"
            textSize = 15f
            setTextColor(cOnSurface)
        }
        val hint = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(1), 0, 0)
            setTextColor(cMuted)
        }
        fun refreshHint() {
            hint.text = if (tabOnly.isChecked) "다른 탭은 전체 설정(${prefs.pageZoom}%)을 따라요"
            else "모든 탭과 새 탭에 적용돼요"
        }
        refreshHint()
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
            isClickable = true
            isFocusable = true
            setOnClickListener { tabOnly.toggle() }
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(tabOnlyTitle)
                addView(hint)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(tabOnly)
        }
        tabOnly.setOnCheckedChangeListener { _, _ -> refreshHint() }

        // 실시간 미리보기: 움직이는 동안 지금 보는 페이지에 바로 반영한다 (저장은 '적용'을 눌러야)
        val handler = Handler(Looper.getMainLooper())
        val previewRun = Runnable {
            if (!tab.isHome) tab.liveWebView?.evaluateJavascript(pageZoomJs(tab, zoom), null)
        }
        parts.gauge.onValueChange = { v ->
            zoom = v
            setPercentLabel(parts.label, v)
            handler.removeCallbacks(previewRun)
            handler.postDelayed(previewRun, 60L)
        }

        box.addView(parts.label)
        box.addView(parts.gauge)
        box.addView(parts.ends)
        box.addView(android.view.View(this).apply { setBackgroundColor(cTrack) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(16) })
        box.addView(tabRow)

        // 다른 팝업과 같은 공통 틀(Popup.panel). 뒤 페이지가 바뀌는 걸 봐야 해서 미리보기 모드로 띄운다
        val dialog = Popup.panel(
            this,
            title = "화면 확대/축소",
            subtitle = "페이지의 글자와 이미지가 함께 커지고 작아져요",
            headerIcon = R.drawable.ic_text,
            widthDp = 340,
            secondaryLabel = "취소",
            onSecondary = { d -> d.dismiss() },
            closeLabel = "적용",
            onClose = { d ->
                applied = true
                val z = zoom
                if (tabOnly.isChecked) {
                    tab.pageZoom = z
                    applyPageZoom(tab)
                } else {
                    prefs.pageZoom = z
                    tab.pageZoom = null
                    // 이 탭만 따로 정해 둔 탭은 그 값을 유지하고, 나머지 탭에 새 값을 적용한다
                    tabs.filter { it.pageZoom == null }.forEach { applyPageZoom(it) }
                }
                toast("화면 확대/축소: ${z}%" + if (tabOnly.isChecked) " (이 탭만)" else "")
                d.dismiss()
            },
            preview = true
        ) { list, _ -> list.addView(box) }
        dialog.setOnDismissListener {
            handler.removeCallbacks(previewRun)
            // 적용을 누르지 않고 닫았다면 미리보기를 걷어내고 원래 배율로 되돌린다
            if (!applied) applyPageZoom(tab)
        }
    }

    private fun showTextSizeDialog() {
        val tMin = 50
        val tMax = 200
        val tStep = 10
        var applied = false

        val cMuted = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, R.color.ev_muted)
        var size = (Math.round((textZoom - tMin) / tStep.toFloat()) * tStep + tMin).coerceIn(tMin, tMax)
        val parts = gaugeParts(tMin, tMax, tStep, size, "글자 크기")

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        val sample = TextView(this).apply {
            text = "가나다라 ABC abc 123"
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
            setTextColor(cMuted)
            textSize = 16f * size / 100f
        }
        parts.gauge.onValueChange = { v ->
            size = v
            setPercentLabel(parts.label, v)
            sample.textSize = 16f * v / 100f
            // 보고 있는 페이지에 바로 반영해서 미리 볼 수 있게
            current?.webView?.settings?.textZoom = v
        }
        box.addView(parts.label)
        box.addView(parts.gauge)
        box.addView(parts.ends)
        box.addView(sample)

        fun commit(z: Int) {
            applied = true
            textZoom = z
            prefs.textZoom = z
            tabs.forEach { it.liveWebView?.settings?.textZoom = z }
        }
        val dialog = Popup.panel(
            this,
            title = "글자 크기",
            subtitle = "웹 페이지 글자만 크게 또는 작게 보여요",
            headerIcon = R.drawable.ic_text,
            widthDp = 340,
            secondaryLabel = "기본값",
            onSecondary = { d -> commit(100); d.dismiss() },
            closeLabel = "적용",
            onClose = { d -> commit(size); d.dismiss() },
            preview = true
        ) { list, _ -> list.addView(box) }
        dialog.setOnDismissListener {
            // 적용/기본값을 누르지 않고 닫았다면 원래 크기로 되돌린다
            current?.webView?.settings?.textZoom = textZoom
        }
    }

    private fun showSpeedDialog() {
        val tab = current ?: return
        val rates = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
        val labels = rates.map { "${it}x" }.toTypedArray()
        val selected = rates.indexOfFirst { r -> r == tab.rate }.let { if (it < 0) 2 else it }
        MaterialAlertDialogBuilder(this)
            .setTitle("재생 속도")
            .setSingleChoiceItems(labels, selected) { d, which ->
                tab.rate = rates[which]
                tab.webView.evaluateJavascript(speedJs(tab.rate), null)
                d.dismiss()
            }
            .show()
    }

    // ───────────────────────── 다운로드 ─────────────────────────

    private val errorTemplate: String by lazy {
        assets.open("error.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun htmlEscape(t: String) =
        t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** 불러오지 못했을 때 보여 주는 오류 화면 (찢어져 바닥에 떨어진 도트 나뭇잎) */
    private fun errorPageHtml(url: String, code: Int, desc: String): String {
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.takeIf { it.isNotBlank() } ?: url
        val (title, msg) = when (code) {
            WebViewClient.ERROR_HOST_LOOKUP ->
                "사이트를 찾을 수 없어요" to "주소가 맞는지 확인하거나, 잠시 뒤에 다시 시도해 보세요."
            WebViewClient.ERROR_CONNECT, WebViewClient.ERROR_IO, WebViewClient.ERROR_TIMEOUT ->
                "연결할 수 없어요" to "서버가 응답하지 않거나 인터넷 연결이 불안정해요."
            WebViewClient.ERROR_FAILED_SSL_HANDSHAKE ->
                "보안 연결에 실패했어요" to "이 사이트와 안전하게 연결할 수 없어요."
            WebViewClient.ERROR_REDIRECT_LOOP ->
                "페이지가 계속 다른 곳으로 이동해요" to "사이트 설정에 문제가 있을 수 있어요. 쿠키를 지우고 다시 시도해 보세요."
            WebViewClient.ERROR_BAD_URL ->
                "주소가 올바르지 않아요" to "주소를 다시 확인해 주세요."
            else ->
                "웹페이지를 사용할 수 없어요" to "페이지를 불러오는 중 문제가 생겼어요."
        }
        return errorTemplate
            .replace("__TITLE__", htmlEscape(title))
            .replace("__MSG__", htmlEscape(msg))
            .replace("__HOST__", htmlEscape(host))
            .replace("__CODE__", htmlEscape(desc))
            .replace("__URL_JSON__", JSONObject.quote(url))
    }

    /** 오류 화면을 보여 주는 중이면 그 주소를 다시 불러오고, 아니면 보통 새로고침 */
    private fun reloadTab(tab: BrowserTab) {
        if (tab.isHome && tab.errorUrl == null) return
        val err = tab.errorUrl
        if (err != null) {
            tab.errorUrl = null
            tab.webView.loadUrl(err)
        } else {
            tab.webView.reload()
        }
    }

    /** 차단한 요청에 돌려줄 빈 403 응답. 종류에 맞는 MIME 을 달아 두면 페이지 스크립트가 덜 깨진다. */
    private fun blockedResponse(uri: Uri, subResource: Boolean = false): WebResourceResponse {
        // WebResourceResponse 는 3xx 상태 코드를 허용하지 않는다(IllegalArgumentException).
        // 하위 요청도 403 으로 막는다: img/script 는 onerror, CORS fetch/XHR 은 네트워크 오류로 실패한다.
        val p = uri.path?.lowercase().orEmpty()
        val mime = when {
            p.endsWith(".js") || p.contains("/js/") -> "application/javascript"
            p.endsWith(".css") -> "text/css"
            p.endsWith(".gif") || p.endsWith(".png") || p.endsWith(".jpg") || p.endsWith(".jpeg") || p.endsWith(".webp") -> "image/gif"
            else -> "text/plain"
        }
        val headers = if (subResource) mapOf("Cache-Control" to "no-store") else emptyMap()
        return WebResourceResponse(mime, "utf-8", 403, "Blocked", headers, ByteArrayInputStream(ByteArray(0)))
    }

    /** 경로 끝의 확장자(점 뒤, 소문자). 확장자가 없거나 너무 길면 null — 문자열을 통째로 복사하지 않는다 */
    private fun extOf(path: String): String? {
        val d = path.lastIndexOf('.')
        if (d < 0 || path.length - d > 7) return null
        return path.substring(d + 1).lowercase()
    }

    /** 주소 뒤쪽(쿼리)에 스트리밍 목록을 가리키는 표시가 있는지 (예: ?file=index.m3u8, ?format=m3u8, ?type=mpd) */
    private fun queryLooksLikeManifest(q: String?): Boolean {
        if (q == null) return false
        return q.contains("m3u8", ignoreCase = true) || q.contains(".mpd", ignoreCase = true) ||
            q.contains("=mpd", ignoreCase = true) || q.contains("manifest(format=mpd", ignoreCase = true)
    }

    private fun looksLikeMediaUrl(path: String): Boolean {
        val ext = extOf(path)
        if (ext != null && ext in SNIFF_MEDIA_EXTS) return true
        return path.endsWith(".ism/manifest", ignoreCase = true)
    }

    /** 영상 파일 / HLS / DASH 요청이면 내장 플레이어 후보로 기억해 둔다. (백그라운드 스레드에서, 모든 하위 요청마다 불림 → 할당을 최소화) */
    private fun sniffMedia(tab: BrowserTab, uri: Uri, headers: Map<String, String>? = null) {
        val path = uri.path ?: return
        val ext = extOf(path)
        if (ext != null && ext in SNIFF_SUB_EXTS) {
            synchronized(tab.sniffedSubs) {
                if (tab.sniffedSubs.size >= 12) tab.sniffedSubs.remove(tab.sniffedSubs.first())
                tab.sniffedSubs.add(uri.toString())
            }
            return
        }
        val isMedia = looksLikeMediaUrl(path) || run {
            // 확장자가 주소 뒤쪽(쿼리)에 붙어 있는 스트리밍 주소도 잡는다 (예: ...?file=index.m3u8, ?format=m3u8)
            queryLooksLikeManifest(uri.encodedQuery)
        } || path.contains(".m3u8", ignoreCase = true) || path.contains(".mpd", ignoreCase = true)
        // 확장자가 없는 영상 주소(예: /stream/abc, /video?id=3): <video> 가 처음 보내는 요청은 Range: bytes=0- 로 시작한다.
        // 파일 이름만으로는 영상인지 알 수 없어도, 이 모양의 첫 요청이면 영상 후보로 기억해 둔다.
        val isRangeMedia = !isMedia && headers != null && run {
            val rng = headers["Range"] ?: headers["range"]
            if (rng == null || !rng.startsWith("bytes=0-")) return@run false
            val last = path.substringAfterLast('/')
            if (last.contains('.') && last.substringAfterLast('.').lowercase() !in DYNAMIC_MEDIA_EXTS) return@run false
            val acc = (headers["Accept"] ?: headers["accept"])?.lowercase()
            acc == null || acc.startsWith("*/*") || acc.startsWith("video/") || acc.startsWith("audio/")
        }
        if (!isMedia && !isRangeMedia) return
        val u = uri.toString()
        synchronized(tab.sniffed) {
            if (tab.sniffed.size >= SNIFF_MAX) tab.sniffed.remove(tab.sniffed.first())
            tab.sniffed.add(u)
        }
    }

    /** 영상 후보 한 개: 주소 / 재생 중이던 위치(ms) / 지금 재생 중인지 */
    private class MediaCand(val url: String, val posMs: Long, val playing: Boolean = false)

    /**
     * 지금 페이지에서 영상 후보를 모은다 (내장 플레이어와 '영상 저장하기'가 같이 쓴다).
     * 페이지 안을 직접 훑은 것(재생 중인 것이 앞) + 페이지가 실제로 주고받은 요청에서 잡아 둔 것(최근 것이 앞, 스트리밍 목록 우선).
     * blob 주소는 재생에는 못 쓰므로 따로(blobs) 돌려준다.
     */
    private fun gatherMediaCands(
        tab: BrowserTab,
        done: (cands: List<MediaCand>, blobs: List<MediaCand>, title: String, subsJson: String?) -> Unit
    ) {
        val wv = tab.webView
        wv.evaluateJavascript(MediaScripts.FIND_MEDIA) { raw ->
            val cands = ArrayList<MediaCand>()
            val blobs = ArrayList<MediaCand>()
            var pageTitle = wv.title.orEmpty()
            var subsJson: String? = null // 페이지의 <track> 자막 (있으면 플레이어에 같이 넘긴다)
            try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner != null) {
                    val o = JSONObject(inner)
                    pageTitle = o.optString("title", pageTitle)
                    subsJson = o.optJSONArray("subs")?.takeIf { it.length() > 0 }?.toString()
                    val a = o.getJSONArray("items")
                    for (i in 0 until a.length()) {
                        val e = a.getJSONObject(i)
                        cands.add(MediaCand(e.getString("u"), (e.optDouble("t", 0.0) * 1000).toLong(), e.optBoolean("p", false)))
                    }
                    val b = o.optJSONArray("blobs")
                    if (b != null) {
                        for (i in 0 until b.length()) {
                            val e = b.getJSONObject(i)
                            blobs.add(MediaCand(e.getString("u"), 0L, e.optBoolean("p", false)))
                        }
                    }
                }
            } catch (e: Exception) {
                // 페이지에서 못 찾으면 요청 목록만 사용
            }
            // 페이지가 자바스크립트로 따로 불러온 자막 파일도 같이 넘긴다 (<track> 태그가 없는 플레이어용)
            val extraSubs = synchronized(tab.sniffedSubs) { tab.sniffedSubs.toList() }
            if (extraSubs.isNotEmpty()) {
                try {
                    val arr = JSONArray(subsJson?.takeIf { it.isNotBlank() } ?: "[]")
                    val known = HashSet<String>()
                    for (i in 0 until arr.length()) known.add(arr.getJSONObject(i).optString("u"))
                    for (u in extraSubs) {
                        if (arr.length() >= 8) break
                        if ((u.startsWith("http://") || u.startsWith("https://")) && known.add(u)) {
                            arr.put(JSONObject().put("u", u).put("l", "").put("g", ""))
                        }
                    }
                    if (arr.length() > 0) subsJson = arr.toString()
                } catch (e: Exception) { }
            }
            val have = cands.map { it.url }.toHashSet()
            // 요청 기록은 최근 것이 앞에 오게 뒤집고(가장 최근에 틀어진 영상일 가능성이 높다), 스트리밍 목록을 파일보다 앞에 둔다
            val sn = synchronized(tab.sniffed) { tab.sniffed.toList() }.asReversed()
            sn.sortedBy {
                val p = it.lowercase()
                if (p.contains(".m3u8") || p.contains(".mpd")) 0 else 1
            }.forEach { if (it !in have) cands.add(MediaCand(it, 0L)) }
            // 영상 파일 주소를 바로 연 탭이면 그 주소 자체가 영상이다
            wv.url?.let { u ->
                if (u !in have && (looksLikeMediaUrl(Uri.parse(u).path.orEmpty()) || u.lowercase().contains(".m3u8"))) {
                    cands.add(0, MediaCand(u, 0L))
                }
            }
            val list = cands.filter { it.url.startsWith("http://") || it.url.startsWith("https://") }.take(MEDIA_CAND_MAX)
            done(list, blobs, pageTitle, subsJson)
        }
    }

    private fun isYouTubeUrl(url: String?): Boolean {
        val h = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return false
        return h == "youtu.be" || h == "youtube.com" || h.endsWith(".youtube.com") || h == "youtube-nocookie.com"
    }

    /** 지금 페이지의 영상을 앱 안의 플레이어로 연다. 재생 중이던 위치에서 이어서 재생한다. */
    private fun openInternalPlayer(
        preferUrl: String? = null,
        preferPosMs: Long = 0L,
        fromVideoButton: Boolean = false
    ) {
        val tab = current ?: return
        val wv = tab.webView
        // 유튜브는 내장 플레이어를 쓰지 않는다 (페이지의 플레이어로만 재생)
        if (isYouTubeUrl(wv.url)) {
            toast("유튜브는 내장 플레이어로 열 수 없어요")
            return
        }
        gatherMediaCands(tab) { list, _, pageTitle, subsJson ->
            fun launch(c: MediaCand) {
                PlayerActivity.start(
                    this, c.url, pageTitle, wv.url, wv.settings.userAgentString,
                    cookieManagerFor(tab).getCookie(c.url), c.posMs, subsJson
                )
                pauseAllMedia()
                if (customView != null) hideCustomView()
            }

            // 영상 아래 버튼으로 연 경우: 그 영상의 주소를 바로 연다.
            if (preferUrl != null && (preferUrl.startsWith("http://") || preferUrl.startsWith("https://"))) {
                launch(MediaCand(preferUrl, preferPosMs))
                return@gatherMediaCands
            }
            // MSE/HLS 플레이어는 video.currentSrc 가 blob: 일 수 있어 직접 주소를 얻지 못한다.
            // 이때 버튼을 누른 사용자의 의도는 현재 영상 재생이므로 선택 팝업을 띄우지 않고
            // 재생 상태가 확인된 후보, 없으면 최근에 수집된 첫 후보를 자동으로 연다.
            if (fromVideoButton) {
                val target = list.firstOrNull { it.playing } ?: list.firstOrNull()
                if (target != null) {
                    launch(MediaCand(target.url, preferPosMs, target.playing))
                    return@gatherMediaCands
                }
            }
            when {
                list.isEmpty() -> MaterialAlertDialogBuilder(this)
                    .setTitle("재생할 영상을 찾지 못했어요")
                    .setMessage(
                        "영상을 먼저 한 번 재생한 뒤 다시 눌러 보세요.\n\n" +
                            "암호화(DRM)된 영상이나 blob 방식으로만 재생되는 영상은 열 수 없습니다."
                    )
                    .setPositiveButton("확인", null)
                    .show()
                list.size == 1 -> launch(list[0])
                // 지금 재생 중인 영상이 있으면 고르게 하지 않고 바로 그 영상을 연다 (이어서 재생)
                list.any { it.playing } -> launch(list.first { it.playing })
                else -> {
                    val names = list.map {
                        val host = runCatching { Uri.parse(it.url).host }.getOrNull().orEmpty()
                        val file = it.url.substringBefore('?').substringAfterLast('/').ifBlank { "영상" }
                        "$host · $file"
                    }.toTypedArray()
                    MaterialAlertDialogBuilder(this)
                        .setTitle("내장 플레이어로 재생")
                        .setItems(names) { _, i -> launch(list[i]) }
                        .setNegativeButton("취소", null)
                        .show()
                }
            }
        }
    }

    /**
     * 페이지의 영상을 찾아 기기에 저장한다.
     * 일반 파일(mp4 등)뿐 아니라 HLS(m3u8) 스트리밍(Android 10+, 조각을 받아 mp4 로 묶음),
     * 페이지가 만들어 둔 blob 파일, 주소에 확장자가 없는 영상, 다른 도메인 iframe 안에서 재생된 영상까지 후보에 올린다.
     * (내장 플레이어가 영상을 찾는 방식과 같다)
     */
    private fun findVideos() {
        val tab = current ?: return
        val wv = tab.webView
        gatherMediaCands(tab) { list, blobs, pageTitle, _ ->
            class Item(val url: String, val label: String, val kind: Int) // kind: 0 파일, 1 HLS, 2 blob
            val hlsOk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
            var skippedStream = false
            val files = ArrayList<Item>()
            val streams = ArrayList<Item>()
            for (c in list) {
                val low = c.url.lowercase()
                val host = runCatching { Uri.parse(c.url).host }.getOrNull().orEmpty()
                val file = c.url.substringBefore('?').substringAfterLast('/').ifBlank { "영상" }
                when {
                    // DASH / 스무스 스트리밍은 영상과 소리가 따로 쪼개져 있어 파일 하나로 받을 수 없다
                    low.contains(".mpd") || low.contains(".ism/") || low.substringBefore('?').endsWith(".ism") -> skippedStream = true
                    HlsDownload.looksLikeHls(c.url, null) || low.contains(".m3u8") ->
                        if (hlsOk) streams.add(Item(c.url, "[스트리밍] $host · $file", 1)) else skippedStream = true
                    else -> files.add(Item(c.url, "$host · $file", 0))
                }
            }
            val items = ArrayList<Item>()
            items.addAll(files)
            items.addAll(streams)
            blobs.forEachIndexed { i, b -> items.add(Item(b.url, "[페이지 안의 파일] 영상 ${i + 1}", 2)) }
            val shown = items.take(MEDIA_CAND_MAX)

            if (shown.isEmpty()) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("저장할 영상을 찾지 못했어요")
                    .setMessage(
                        (if (skippedStream) "이 페이지는 mpd(DASH)나 안드로이드 10 미만에서 받을 수 없는 스트리밍 영상만 있어요.\n\n" else "") +
                            "영상을 먼저 한 번 재생한 뒤 다시 눌러 보세요.\n\n" +
                            "보호(DRM)된 영상과 mpd 방식 영상은 저장할 수 없습니다."
                    )
                    .setPositiveButton("확인", null)
                    .show()
                return@gatherMediaCands
            }
            val names = shown.map { it.label }.toTypedArray()
            MaterialAlertDialogBuilder(this)
                .setTitle("저장할 영상 선택")
                .setItems(names) { _, i ->
                    val it0 = shown[i]
                    when (it0.kind) {
                        1 -> enqueueDownload(
                            it0.url, wv.settings.userAgentString, null, "application/x-mpegURL",
                            pageTitle, cookieManagerFor(tab).getCookie(it0.url)
                        )
                        2 -> {
                            requestNotificationPermission()
                            toast("다운로드 시작")
                            localDownload.handle(wv, it0.url, null, null)
                        }
                        else -> enqueueDownload(
                            it0.url, wv.settings.userAgentString, null, null,
                            null, cookieManagerFor(tab).getCookie(it0.url)
                        )
                    }
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }

    // ───────────────────────── AI 어시스턴트 ─────────────────────────

    /** 지금 보는 페이지의 제목·주소·본문·선택한 글을 모아 AI 에게 넘긴다. 열린 페이지가 없으면 null. */
    private fun fetchPageForAssistant(cb: (PageSnapshot?) -> Unit) {
        val tab = current
        if (tab == null || tab.isHome || !hasPage(tab)) {
            cb(null)
            return
        }
        tab.webView.evaluateJavascript(PAGE_TEXT_JS) { raw ->
            val snap: PageSnapshot? = try {
                val inner = JSONTokener(raw ?: "null").nextValue() as? String
                if (inner == null) {
                    null
                } else {
                    val o = JSONObject(inner)
                    PageSnapshot(
                        o.optString("url"), o.optString("title"),
                        o.optString("text"), o.optString("sel")
                    )
                }
            } catch (e: Exception) {
                null
            }
            cb(snap)
        }
    }

    /** 지금 보는 페이지에서 JS 를 실행한다. 열린 페이지가 없으면 null 을 돌려준다. */
    private fun runJsOnCurrentPage(js: String, cb: (String?) -> Unit) {
        val tab = current
        if (tab == null || tab.isHome || !hasPage(tab)) {
            cb(null)
            return
        }
        tab.webView.evaluateJavascript(js) { raw -> cb(raw) }
    }

    private val downloadCard by lazy { DownloadProgressCard(this) { openDownloads() } }

    private val localDownload by lazy { LocalDownload(applicationContext) { msg -> toast(msg) } }

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("blob/data 형식 주소는 직접 다운로드할 수 없습니다")
            return
        }
        // 시크릿 탭의 로그인 쿠키는 앱 기본 저장소에 없으므로, 그 탭의 쿠키를 같이 넘긴다
        enqueueDownload(url, userAgent, contentDisposition, mimeType, null, cookieManagerFor(current).getCookie(url))
    }

    private fun enqueueDownload(
        url: String, userAgent: String?, contentDisposition: String?, mimeType: String?,
        title: String? = null, cookie: String? = null
    ) {
        val referer = current?.webView?.url?.takeIf { it.startsWith("http") }

        // Android 10 이상: 여러 연결로 나눠 받는 빠른 다운로드
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            requestNotificationPermission()
            try {
                DownloadService.start(this, url, userAgent, contentDisposition, mimeType, referer, title, cookie)
                // 시스템 알림 말고도 앱 안에서 진행 상황을 보여 준다
                downloadCard.begin()
                return
            } catch (e: Exception) {
                // 서비스를 시작하지 못하면 시스템 다운로더로
            }
        }
        systemDownload(url, userAgent, contentDisposition, mimeType, referer)
    }

    private fun systemDownload(
        url: String, userAgent: String?, contentDisposition: String?, mimeType: String?, referer: String?
    ) {
        val name = SystemDownload.enqueue(this, url, userAgent, contentDisposition, mimeType, referer)
        toast(if (name != null) "다운로드 중: $name" else "다운로드에 실패했습니다")
    }

    /** Android 13+ 에서 다운로드 진행 알림을 보이려면 알림 권한이 필요하다. (거부해도 다운로드는 진행됨) */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || askedNotificationPermission) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotificationPermission = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private var adListTryAt = 0L

    /**
     * 차단 목록이 없거나 3일이 지났으면 내려받는다.
     * 실패해도 일주일을 기다리지 않고, 앱을 다시 열 때(30분 간격 이상) 또 시도한다.
     */
    private fun autoUpdateAdBlockList() {
        val now = System.currentTimeMillis()
        val threeDays = 3L * 24 * 60 * 60 * 1000
        if (now - adBlocker.lastUpdated < threeDays) return
        if (now - adListTryAt < 30L * 60 * 1000) return
        adListTryAt = now
        prefs.adblockLastTry = now
        // 자동완성과 같은 스레드를 막지 않도록 별도 스레드에서 실행
        Thread {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            try {
                adBlocker.update()
            } catch (e: Exception) {
                // 실패하면 다음에 앱을 열 때 다시 시도
            }
        }.apply { isDaemon = true }.start()
    }

    /** 앱 안의 다운로드 목록 화면 (폴더로 정리 가능) */
    private fun openDownloads() {
        bookmarksLauncher.launch(listIntent(DownloadsActivity::class.java))
    }

    // ───────────────────────── 북마크 ─────────────────────────

    /** 지금 보고 있는 웹페이지 주소 (홈 화면이거나 웹페이지가 아니면 null) */
    private fun currentPageUrl(): String? {
        val tab = current ?: return null
        if (tab.isHome) return null
        return tab.webView.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun currentBookmark(): Bookmark? = currentPageUrl()?.let { prefs.findBookmark(it) }

    /** 현재 페이지를 북마크에 추가하거나, 이미 있으면 수정/삭제 대화상자를 연다. */
    private fun bookmarkCurrent() {
        val url = currentPageUrl()
        if (url == null) {
            toast("북마크할 웹페이지가 없습니다")
            return
        }
        val title = current?.webView?.title.orEmpty()
        ListUi.showBookmarkEditor(this, prefs, prefs.findBookmark(url), url, title) { msg -> toast(msg) }
    }

    private fun openHistory() {
        bookmarksLauncher.launch(listIntent(HistoryActivity::class.java))
    }

    private fun openBookmarks() {
        bookmarksLauncher.launch(listIntent(BookmarksActivity::class.java))
    }

    private fun showLinkMenu(link: String?, image: String?) {
        fun isWeb(u: String?) = u != null && (u.startsWith("http://") || u.startsWith("https://"))
        val webLink = link?.takeIf { isWeb(it) }
        val webImage = image?.takeIf { isWeb(it) }
        if (webLink == null && webImage == null) return

        val target = webLink ?: webImage!!
        val items = mutableListOf<Popup.Item>()
        if (webLink != null) {
            items.add(Popup.Item(R.drawable.ic_add, "새 탭에서 열기") { createTab(webLink, opener = current) })
            items.add(Popup.Item(R.drawable.ic_copy, "링크 주소 복사") { copyToClipboard(webLink) })
            items.add(Popup.Item(R.drawable.ic_share, "링크 공유") { shareText(webLink) })
            items.add(Popup.Item(R.drawable.ic_download, "링크 파일 다운로드") {
                startDownload(webLink, current?.webView?.settings?.userAgentString, null, null)
            })
        }
        if (webImage != null) {
            items.add(Popup.Item(R.drawable.ic_download, "이미지 저장") {
                startDownload(webImage, current?.webView?.settings?.userAgentString, null, null)
            })
            items.add(Popup.Item(R.drawable.ic_image, "새 탭에서 이미지 열기") { createTab(webImage, opener = current) })
            if (webLink != null) items.add(Popup.Item(R.drawable.ic_copy, "이미지 주소 복사") { copyToClipboard(webImage) })
        }
        window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        Popup.menu(
            this,
            title = Uri.parse(target).host?.removePrefix("www.") ?: if (webLink != null) "링크" else "이미지",
            subtitle = target,
            headerIcon = if (webLink != null) R.drawable.ic_globe else R.drawable.ic_image,
            items = items
        )
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        try {
            startActivity(Intent.createChooser(send, "공유"))
        } catch (e: Exception) {
            toast("공유할 수 있는 앱이 없습니다")
        }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", text))
        toast("복사했습니다")
    }

    /** 앱 자체 알림을 띄울 때 창 아래에서 띄울 높이. 아래 막대(뒤로/홈/탭)가 보이면 그 바로 위, 아니면 0 */
    fun toastLift(): Int {
        var lift = 0
        if (::bottomBar.isInitialized && bottomBar.isShown && bottomBar.height > 0) {
            val l = IntArray(2)
            bottomBar.getLocationInWindow(l)
            lift = (window.decorView.height - l[1]) + dp(12)
        }
        return lift
    }

    private fun toast(msg: String) {
        AppToast.show(this, msg, toastLift())
    }

    companion object {
        /** 시스템 미디어 플레이어(알림)를 눌렀을 때 열 탭의 번호 */
        internal const val EXTRA_OPEN_TAB = "evergreen.open_media_tab"
        private const val EXTRA_WINDOW_NO = "evergreen.window_no"
        private const val EXTRA_RESTORE = "evergreen.restore_tabs"
        private const val EXTRA_HANDOFF = "evergreen.tab_handoff"

        /** 새 창을 여는 방식: 기본(옆에 붙이기) / 팝업(떠 있는 창) */
        private const val WIN_DEFAULT = 0
        private const val WIN_POPUP = 1

        /** 새 창이 뜨는 동안 옮겨 갈 탭의 상태를 잠깐 맡아 두는 곳 (같은 프로세스라 Bundle 을 그대로 넘긴다) */
        private val handoffs = HashMap<Long, TabHandoff>()
        private var handoffSeq = 0L
        /** 새 탭(홈) 화면이 웹 기록에 남을 때 쓰는 주소 */
        const val HOME_URL = "evergreen://home"
        /** 기기에서 연 HTML 파일을 불러올 때 쓰는 가짜 주소 (주소창에는 파일 이름만 보인다) */
        const val LOCAL_BASE = "https://local.evergreen/"
        private const val HOME_HTML =
            "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>html,body{margin:0;background:transparent}</style></head><body></body></html>"

        /** 지금 떠 있는 창(인스턴스)들. 앱을 여러 창으로 띄울 수 있어서, 하나만 가진 자원은 이걸로 조율한다 */
        private val instances = ArrayList<MainActivity>()

        /** 지금 떠 있는 창들 (런처 진입점이 새 창을 띄울지 정하는 데 쓴다) */
        internal fun runningWindows(): List<MainActivity> = instances.toList()
        private var primary: MainActivity? = null

        /** 기기에서 연 HTML 파일의 이름 (주소 → 파일 이름) */
        private val localFileNames = HashMap<String, String>()

        /** 탭을 시스템 드래그로 끌고 있는 창 (다른 창의 탭 줄이 받을 수 있는지 판단하는 데 쓴다) */
        private var sysDragSource: MainActivity? = null

        /** 탭 화면의 카드 줄(가로 한 줄) 표시용 태그 */
        private const val CARD_ROW_TAG = "cardRow"

        /** 웹 페이지가 이동할 수 없게 막는 주소 형식 */
        private val BLOCKED_NAV_SCHEMES = setOf("file", "content", "javascript", "data", "filesystem")

        private const val MAX_HOME_SHORTCUTS = 8

        /** 뒤로가기 후 이 시간(ms) 안에 일어나는 '사용자 동작 없는' 페이지 이동은 자동 리다이렉트로 보고 막는다 */
        private const val BACK_GUARD_MS = 4000L
        private const val DOWNLOAD_TOUCH_MS = 15_000L

        /** AI 어시스턴트에 넘길 페이지 내용 (본문은 3만 자까지) */
        private const val PAGE_TEXT_JS = """(function(){
var t=(document.body&&document.body.innerText)||'';
var s='';try{s=String(window.getSelection())}catch(e){}
return JSON.stringify({url:location.href,title:document.title||'',text:t.slice(0,30000),sel:s.slice(0,4000)});
})()"""

        private const val FIND_VIDEO_JS =
            "(function(){var r=[];document.querySelectorAll('video,video source,audio source')" +
                ".forEach(function(e){var u=e.currentSrc||e.src;if(u&&/^https?:/.test(u))r.push(u);});" +
                "return JSON.stringify(Array.from(new Set(r)));})()"
    }
}

/** 입력한 글자와 상관없이 전달받은 목록을 그대로 보여주는 자동완성 어댑터 */
class NoFilterAdapter(context: Context, private val data: MutableList<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, data) {

    private val noFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): Filter.FilterResults =
            Filter.FilterResults().also {
                it.values = data
                it.count = data.size
            }

        override fun publishResults(constraint: CharSequence?, results: Filter.FilterResults?) {
            if (data.isNotEmpty()) notifyDataSetChanged() else notifyDataSetInvalidated()
        }
    }

    override fun getFilter(): Filter = noFilter
}

/** 페이지 확대/축소: 뷰포트 너비를 W 로 바꾼다 (W = 화면 너비 ÷ 배율). 위에서 `var W=...;` 를 먼저 붙여 쓴다. */
private const val PAGE_ZOOM_ON_JS = """
var d=document,h=d.head||d.documentElement;
var m=d.querySelector('meta[name=viewport]');
if(!window.__evZ){window.__evZ={}}
var Z=window.__evZ;
Z.w=W;
Z.fix=function(){
 var mm=d.querySelector('meta[name=viewport]');
 var c='width='+Z.w+',minimum-scale=0.05,maximum-scale=10,user-scalable=yes';
 if(!mm){mm=d.createElement('meta');mm.name='viewport';mm.setAttribute('data-ev-added','1');(d.head||d.documentElement).appendChild(mm)}
 if(mm.getAttribute('data-ev-orig')===null&&!mm.hasAttribute('data-ev-added'))mm.setAttribute('data-ev-orig',mm.getAttribute('content')||'');
 if(mm.getAttribute('content')!==c)mm.setAttribute('content',c);
};
Z.fix();
if(!Z.obs){
 Z.obs=new MutationObserver(function(){
  var mm=d.querySelector('meta[name=viewport]');
  if(!mm||mm.getAttribute('content')!=='width='+Z.w+',minimum-scale=0.05,maximum-scale=10,user-scalable=yes'){
   if(mm&&mm.getAttribute('data-ev-orig')===null&&!mm.hasAttribute('data-ev-added'))mm.setAttribute('data-ev-orig',mm.getAttribute('content')||'');
   Z.fix();
  }
 });
 Z.obs.observe(d.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['content','name']});
}
"""

/** 페이지 확대/축소 해제: 원래 뷰포트로 되돌린다 */
private const val PAGE_ZOOM_OFF_JS = """
(function(){
 var Z=window.__evZ; if(!Z)return;
 if(Z.obs){Z.obs.disconnect();Z.obs=null}
 var mm=document.querySelector('meta[name=viewport]');
 if(mm){
  if(mm.hasAttribute('data-ev-added')){mm.remove()}
  else if(mm.getAttribute('data-ev-orig')!==null){mm.setAttribute('content',mm.getAttribute('data-ev-orig'));mm.removeAttribute('data-ev-orig')}
 }
 window.__evZ=null;
})();
"""

/** 하위 요청에서 영상으로 보는 확장자 / 자막 확장자 (요청마다 목록을 새로 만들지 않도록 한 번만 만든다) */
private val SNIFF_MEDIA_EXTS = hashSetOf(
    "m3u8", "mpd", "mp4", "webm", "m4v", "mov", "mkv", "avi", "flv", "3gp", "3g2", "f4v", "m2ts", "mts",
    "ogv", "ogm", "wmv", "asf", "ismv", "mpg", "mpeg"
)
/** 탭마다 기억해 두는 영상 후보 주소 최대 개수 / 한 번에 보여 주는 후보 최대 개수 */
private const val SNIFF_MAX = 60
private const val MEDIA_CAND_MAX = 25
private val SNIFF_SUB_EXTS = hashSetOf("vtt", "srt", "ass", "ssa", "ttml", "dfxp")
/** 파일이 아니라 프로그램이 영상을 내려 주는 주소의 확장자 (예: video.php?id=3) */
private val DYNAMIC_MEDIA_EXTS = hashSetOf("php", "asp", "aspx", "jsp", "cgi", "do", "action", "ashx")
