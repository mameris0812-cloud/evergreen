# evergreen v2.2

WebView 기반의 안드로이드 브라우저 앱입니다.

## 작업 규칙

### 업데이트 로그 (`Changelog.kt`) 작성 규칙
업데이트 로그는 **일반 사용자가 읽는 글**입니다. 개발자용 내용은 넣지 않고, 사용자가 체감하는 굵직한 변화만 적습니다.

- **넣는 것**: 새로 생긴 기능, 눈에 띄게 달라진 동작·화면, 사용자가 겪던 문제를 고친 것
- **빼는 것**: 빌드 오류 수정 · 클래스/함수/파일 이름 · 내부 원인 설명 · 수치 튜닝(스프링 강성·ms·dp 등) · 리팩터링 · 권한/설정 파일 변경 · 롤백 같은 개발 과정 이야기
- **쓰는 법**: 항목은 한두 문장, 쉬운 말로 "무엇이 어떻게 달라졌는지"만 적습니다. 사용자에게 보이는 변화가 없으면 항목을 만들지 않습니다.
- 정리된 규칙 외 상세한 기술 내용은 이 README 에 남깁니다.
- 이 규칙을 만들거나 고치는 것처럼 앱 기능과 무관한 작업은 **버전을 올리지 않고, 업데이트 로그에도 넣지 않습니다.**

### 둘러보기 · 신기능 안내 (`Tutorial.kt`) 규칙
- 새 버전에서 사용자에게 소개할 기능이 생기면 `Tutorial.CURRENT_LEVEL` 을 1 올리고, `Tutorial.TOUR` 에 `since = 올린 값` 으로 한 단계를 더합니다. 업데이트한 사용자에게 "새 기능을 둘러볼까요?"를 물을 때 아직 안 본 차수(`Prefs.tourLevel` 보다 큰 것)만 보여 줍니다.
- 단계는 화면의 뷰 id 로 안내할 자리를 찾습니다(`ids`). 폰/태블릿 id 가 다르면 `wide` 로 나누고, 그 뷰가 지금 안 보이면 단계는 자동으로 건너뜁니다.
- 소개할 기능이 없는 버전에서는 건드리지 않습니다.

### 테스트
단위 테스트는 `app/src/test` 에 두고 `./gradlew :app:testDebugUnitTest` 로 돌린다(JUnit 4, 기기 불필요). 앱 동작을 바꾸지 않으므로 버전·업데이트 로그는 건드리지 않는다.
- `AgentFrameBridgeTest`: iframe 조작 스크립트(`AgentPageTools.frameBridgeScript`)가 `eval` 을 안 쓰고(iframe CSP), 본문에서는 아무 일도 안 하고, 치환하다 만 자리표시가 없고, 일곱 동작(read · aim · info · click · fill · drag · scroll)을 다 싣고 있는지. 글만 확인하고 스크립트를 돌리지는 않는다.
- `GeminiKeyPoolTest`: 키 한도(429)·키 거부 처리. 한도 응답 판별(`isQuota`), 한도 종류별 쉬는 시간(분당=알려 준 시간·없으면 60초·5초~5분으로 보정, 하루=10분, 한도 0=30분, 범위 모를 때=30초), 키 전체가 아니라 (키, 모델) 짝만 쉬는지, 키 거부 시 키를 쉬게 하지 않는지, 번갈아 쓰기·다른 키/모델 찾기, 설정 화면 상태 글, 키 바뀜 알림(3초 제한). 풀이 싱글톤이라 `@Before` 에서 리플렉션으로 비우고, 실제 시계를 쓰므로 남은 시간은 범위로 확인한다.

## 기능

**AI 창 버튼 글자 접힘 다듬기 · 사고 과정 카드 더 연하게 (v4.3.26)**
- `toolPill` 의 글자(`pillLabels`)가 폭이 좁아질 때 `maxLines=1` 이어도 공백에서 줄바꿈되어 「대화 기록」→「대화」, 「새 대화」→「새」 처럼 단어째 떨어지던 것을 `setHorizontallyScrolling(true)` 로 한 줄에 묶어 오른쪽부터 잘리게 했다. 투명도는 `f²` 로 폭과 함께 서서히 변하고, 알약 안쪽 여백도 정수 잘림 대신 반올림으로 계단 없이 움직인다. 스프링은 튀지 않게 stiffness 320 · 감쇠 1.0. `THOUGHT_CARD` 알파를 0x2B→0x16 으로 낮춰 사고 과정 카드를 더 연하게 했다. 컴파일 · 실기기 시험 못 함.

**AI 답변 말풍선 투명 · 사고 과정 반투명 회색 (v4.3.25)**
- `AssistantUi.bubbleDrawable` 의 받은(AI) 말풍선(`user=false`, 색 지정 없음)을 채움·테두리 없는 투명으로 바꿨다(오류 말풍선은 그대로 `errorBg`). 배경이 없어져 `ReplyBubble` · `addBubble` 의 AI 쪽 여백을 좌우 4dp · 상하 6dp 로 줄였다. 사고 과정 카드(`ThoughtView`)는 `THOUGHT_CARD`(회색 0x8A8A8A, 알파 약 17%)를 채우고 테두리를 없앴다. 카드 안 흐려지는 창(`ThoughtClip`)의 위쪽 페이드 색은 이 회색을 바탕(밝은 면=흰색 · 어두운 면=`bubbleBg`) 위에 얹은 색으로 맞췄다. 코드 블록·표는 그대로 불투명 카드. 컴파일 · 실기기 시험 못 함.

**대화 기록 ✕ 지우기 확인 (v4.3.24)**
- `AssistantUi.showChatHistory` 의 줄 ✕(`onDelete`)가 바로 지우던 것을 `confirmDeleteChat` 으로 한 번 물어본 뒤 지우게 했다(그 줄에 붙는 카드 팝업 `showCardPopup`, 못 띄우면 대화상자). 「모두 삭제」 는 원래 확인이 있었다. 컴파일 · 실기기 시험 못 함.

**AI 창 버튼 글자가 부드럽게 접힘 (v4.3.23)**
- v4.3.22 의 아이콘 전환을 애니메이션으로 바꿨다. 글자 폭 · 투명도 · 알약 안쪽 여백을 하나의 비율(`labelFrac`, 1=글자 포함 · 0=아이콘만)로 묶어 `Motion.springValue`(stiffness 380 · 감쇠 0.9, 살짝 여운)로 움직인다. 글자 폭(`labelFull`)은 처음 한 번 `UNSPECIFIED` 로 재어 두고, 접힌 뒤 다시 펴려면 12dp 더 넓어야 하는 여유(히스테리시스)로 경계에서 깜빡이지 않게 했다. 창을 처음 열 때와 시스템 애니메이션이 꺼져 있을 때는 바로 맞춘다. 컴파일 · 실기기 시험 못 함.

**AI 창 좁을 때 아이콘만 (v4.3.22)**
- `AssistantUi` 머리글의 `tools` 에 레이아웃 변경 리스너를 달아, 버튼 자리 폭(`w`)이 글자 포함 폭(`need`: 알약을 `UNSPECIFIED` 로 재어 더한 값)보다 좁으면 알약 글자(`pillLabels`)를 숨기고 아이콘만 남긴다(여백 9dp). 넓어지면 다시 글자를 보인다. 폭이 바뀔 때만 계산한다. 컴파일 · 실기기 시험 못 함.

**AI 창 머리글 정리 (v4.3.21)**
- `AssistantUi` 창 머리글에서 「AI 어시스턴트」 제목 글자와 아래 줄의 「대화 지우기」 알약을 없앴다. 제목 자리(가중치 1)에 「대화 기록」 · 「새 대화」 알약(`tools`)을 놓고, 아래 별도 줄은 없앴다. 머리글은 로고 · 대화 기록 · 새 대화 · 모델 칩 · 닫기 순서. `confirmClearChat` 은 남아 있지만 지금은 부르는 곳이 없다. `AppGuide` 의 AI 창 설명도 맞춰 고쳤다.
- 컴파일 · 실기기 시험 못 함.

**AI 가 앱 기능 · 경로를 안내 + 결과 카드 스위치 (v4.3.20)**
- `AppGuide.kt` 의 `text()` 를 `AssistantUi.buildSystem` 이 모든 AI 요청(일반 채팅 · 에이전트)의 시스템 안내에 붙인다. 메뉴(⋮) · 설정(큰 묶음 → 소제목 → 항목, `MainActivity.showMenu` 의 `big/sub/reg` 와 같은 이름) · 탭/창/그룹 · 길게 누르기 메뉴 · 북마크/기록/다운로드 · 영상 · 번역 · 확장 프로그램 · 광고 차단 · 보안 · AI 설정 · 에이전트를 경로와 함께 적었다. 「어디서/어떻게」 처럼 방법을 묻는 말에는 도구를 쓰지 않고 안내로 답하고 「켜 줘」 처럼 시킬 때만 도구를 쓰게 했다(`AgentRouting` 이 「다크」 「설정」 같은 낱말로 에이전트로 보내기 때문). 안내에 없는 기능은 지어내지 않게 했다.
- 앱에 기능이 생기거나 메뉴 · 설정 위치가 바뀌면 `AppGuide.BODY` 도 같이 고친다. `AppGuideTest` 가 필수 항목(설정 큰 묶음 · 핵심 규칙)과 `$` 없음을 확인한다.
- `AgentProgressCard.settingSwitch` 를 `android.widget.Switch` + 직접 칠한 색 대신 설정 화면과 같은 `MaterialSwitch` 로 바꾸고 `ThemeColors.skin` 으로 테마 색을 입힌다.
- 컴파일 · 실기기 시험 못 함.

**확장 프로그램 안의 AI · evergreenAI (v4.3.19)**
- `ext_shim.js` 가 확장 페이지 · 백그라운드 · 콘텐츠 스크립트에 전역 `evergreenAI` (= `chrome.evergreenAI`)를 만든다: `available()` · `ask(prompt, {system, json, quality})` · `chat(messages, {system, json, quality})`. `json:true` 면 JSON 으로 읽은 값을 돌려주고, `quality` 는 `fast`(LITE, 기본) · `smart`(HYDROGEN).
- 네이티브 `ExtensionManager.Bridge.aichat` 이 설정의 Gemini 키로 `GeminiClient` 를 부른다. 확장이 켜져 있어야 하고, 확장마다 1분에 20번까지(`extAiCalls`). 답은 페이지와 백그라운드 둘 다에 보낸다(`respondAi`). 키는 확장 코드에 노출되지 않는다. 기존 Summarizer 흉내(`B.ai`)는 그대로다.
- `ExtensionForge.systemPrompt` 에 "AI 기능" 규칙을 더했다: 사용자가 요약 · 번역 · 분류 같은 AI 작업을 요청했을 때만 `evergreenAI` 로 넣고, 외부 AI 서버 · 키 직접 사용은 금지. `validate` 는 `DIRECT_AI` 로 외부 AI 주소 · 키 모양을 막고, `DryRun` 의 PRELUDE 에 `evergreenAI` 대역을 넣어 시험 실행이 ReferenceError 로 실패하지 않게 했다. `features(mj, files)` 가 `evergreenAI` 를 쓰는 확장에 '푸른 칩 「AI 기능」'을 붙인다(미리보기 카드 · 편집 · 설치된 확장).
- 컴파일 · 실기기 시험 못 함.

**확장 프로그램 카드: AI 별 아이콘 · AI로 고치기를 편집 안으로 (v4.3.18)**
- `ExtensionsUi` 카드 아랫줄의 'AI 제작' 알약을 AI 어시스턴트 제목 옆과 같은 별(`GradientImageView` + `ic_ai`) 아이콘 버튼으로 바꿨다. 누르면 토스트만 뜬다.
- 카드의 'AI로 고치기' 칩을 빼고 '직접 편집' 칩은 '편집'으로 바꿨다. `ExtensionForgeUi.showManualEdit` 맨 위에 'AI로 고치기' 줄을 넣어 누르면 `showEdit` 로 넘어간다(손으로 고친 게 있으면 저장 안 된다고 먼저 묻는다).

**AI 거절 더 완화 (v4.3.17)**
- `AssistantUi.buildSystem` 의 안내를 "성인 · 선의로 보고 민감한 주제도 주제만으로 거절하지 않기, 경고 · 훈계 · 되묻기 없이 답하기, 곤란한 부분만 빼고 계속 돕기, 심각한 피해(무기 · 대량 피해 · 아동 학대 등)만 짧게 거절" 로 고쳤다.

**AI 에이전트 허락 줄이기 (v4.3.16)**
- `AgentRunner.changeApproved` 의 처음 값을 true 로 해서 "변경" 단계 도구는 확인 카드 없이 실행한다. 위험(DANGER) · `alwaysAsk` 도구는 그대로 매번 묻는다(웹 페이지 글이 에이전트를 속여 삭제 · 결제 · 보안 해제를 시키는 걸 막는 마지막 확인). 한도: `MAX_STEPS` 10→30, `MAX_STEPS_AUTO` 30→60, `MAX_CHANGES_AUTO` 25→50, `MAX_CALLS_PER_STEP` 6→10.

**AI 거절 줄이기 (v4.3.15)**
- `GeminiSafety.apply` 가 일반 답변(`Gemini.kt`)과 에이전트(`GeminiAgentClient.kt`) 요청에 `safetySettings`(괴롭힘 · 혐오 · 선정성 · 위험 콘텐츠)를 `BLOCK_ONLY_HIGH` 로 넣는다. 구글이 항상 막는 분류는 그대로다. `AssistantUi.buildSystem` 에 "일반 질문에는 불필요한 거절 · 경고 · 훈계 없이 답하고, 타인에게 심각한 피해를 주는 일만 짧게 거절" 한 줄을 더했다. 앱 조작 확인 카드 · 단계 한도는 건드리지 않았다.

**진행 카드도 맨 위로 (v4.3.13)**
- `DownloadProgressCard` 는 카드를 `TYPE_APPLICATION` 별도 창에 그린다(못 띄우면 예전처럼 decorView 안). 400ms 마다 도는 `update` 가 창 초점이 있다가 없어지는 순간(`wasFocused`)을 보고 `raiseWindowCard` 로 카드 창을 다시 띄워 새로 열린 대화상자 위로 올린다. 대화상자 위에 또 대화상자가 열리는 경우는 초점이 계속 없어서 못 알아챈다. `occupiedHeight` 는 별도 창 카드(`windowCard`)도 센다. 컴파일·실기기 시험 못 함.

**알림이 별도 창 위에도 (v4.3.12)**
- `AppToast.showNow` 는 액티비티 창이 입력 초점을 잃었을 때(`!act.hasWindowFocus()` = 바텀시트 · Dialog · 초점 받는 팝업이 떠 있음) 알림을 `TYPE_APPLICATION` 창(NOT_FOCUSABLE · NOT_TOUCH_MODAL · LAYOUT_IN_SCREEN)으로 새로 띄워 그 위에 그린다(뒤에 추가된 창이 위). 초점이 있으면 예전처럼 decorView 안에 그린다. 다운로드 진행 카드(`DownloadProgressCard`)는 아직 이 창 안에만 그려진다. 컴파일·실기기 시험 못 함.

**AI로 고치기가 요청을 못 따르던 문제 (v4.3.11)**
- 원인 후보: ① 프롬프트 맨 앞에 처음 설명(`만들 것`)이 오고 이번 요청은 뒤에 짧게 붙어 모델이 처음 설명대로 되돌림 ② 이번 요청 500자 한도(진단 로그가 붙으면 더 일찍 잘림) ③ 앞의 결과 JSON 을 3만 자에서 잘라 긴 코드는 뒷부분을 못 봄. `ExtensionForge.userPrompt` 가 고치기일 때 이번 요청을 맨 앞에 두고(`FEEDBACK_MAX`=1500, `PREV_MAX`=250000), `sameAsPrev` 로 결과가 앞과 같으면 문제로 보고 다시 시킨다(최대 `MAX_FIX`). 컴파일·실기기 시험·실제 AI 응답 시험 못 함.

**지금까지 목록 줄이기 (v4.3.10)**
- `ExtensionForgeUi.showEdit` 의 「지금까지」 는 최근 3판만 보여 주고(앞은 「…(앞의 N개)」), 요청이 20자를 넘으면 `…` 를 붙인다. 글을 누르면 `histOpen` 으로 전부 펼치고 다시 누르면 접는다. 컴파일·실기기 시험 못 함.

**진단 로그 줄임표 (v4.3.9)**
- AI로 고치기에 붙는 최근 진단 로그는 줄당 200자까지이고, 넘는 줄은 `…` 를 붙여 자른다. 프롬프트의 바꿀 점도 500자를 넘으면 `…` 를 붙인다. 컴파일·실기기 시험 못 함.

**AI로 고치기 결과에 고친 내용 (v4.3.8)**
- 모델 JSON 에 `changes`(이번에 바꾼 점 1~4줄)를 더 받아 `Draft.changes` 에 담고, 결과 카드(`ExtensionForgeUi` 미리보기)의 「고친 내용 · vA → vB」 칸에 보여 준다. 그 아래에 `ExtensionForge.fileChanges` 가 앞 판(`prevSource.files`)과 견준 파일별 +줄 −줄 · 새 파일 · 지운 파일을 덧붙인다. 처음 만들 때(`prevSource` 없음)는 칸이 없다. 컴파일·실기기 시험 못 함.

**직접 편집은 버전을 올리지 않는다 (v4.3.7)**
- `applyManualEdit` 는 version 을 안 정하면(null) 지금 버전 그대로 저장한다(요청 기록에만 「직접 편집: …」 추가, 기록 파일은 같은 버전 항목을 갈아씀). 이미 있는 버전을 고르면 그 번호가 된다. AI로 고치기(`stamp`)만 +1. 컴파일·실기기 시험 못 함.

**직접 편집에서 이미 있는 버전으로 바꾸기 (v4.3.6)**
- 「직접 편집」 맨 위 버전 목록에서 「지금 버전」 또는 이전 버전을 고른다. 이전 버전을 고르면 그 판의 설명 · 적용 범위(`ExtensionForge.scopeOf`) · 코드가 폼에 불러와지고, 「고치기」(예전 「저장」)가 `applyManualEdit(..., version)` 으로 그 버전 번호 그대로 새로 설치한다(지금 판이면 version=null 로 자동 +1). 이전 판 소스는 `evergreen_ai_history.json` 의 `revs[].snap`({manifest, files})에 최근 10개까지 남고(같은 버전 이름은 가장 새것만), 이 판 이전에 만든 기록에는 snap 이 없어 목록에 안 나온다. 컴파일·실기기 시험 못 함.

**빌드 오류 수정 (v4.3.5)**
- `ExtensionForge.kt` 의 KDoc 주석 안에 `/*` 가 들어 있으면 Kotlin 이 중첩 주석으로 읽어 파일 끝까지 주석이 된다. 주석에는 패턴 글(슬래시+별표)을 쓰지 않는다.

**확장 추가 메뉴 (v4.3.4)**
- 「＋ 추가」(`Popup.panel*` 의 보조 버튼)를 누르면 창을 닫지 않고 그 버튼(`Popup.secondaryView` → `ExtensionsUi.addAnchor`, 창 닫는 함수는 `addClose`)에서 `MainActivity.showExtAddChooser` 메뉴가 펼쳐진다. 태블릿은 `menuAnchored`(compact; 버튼 아래 공간이 200dp 미만이면 버튼 위 점 기준), 폰은 `Popup.menu(origin=버튼)` 의 펼침 애니메이션. 항목(아이콘 ic_chrome_mono · ic_ai)을 고르면 창을 닫고 동작한다. 버튼을 못 쓰면 예전처럼 창을 닫고 가운데에 뜬다. 컴파일·실기기 시험 못 함.

**AI 확장 직접 편집 · 아이콘 (v4.3.3)**
- 직접 편집: AI 제작 확장 카드의 「직접 편집」(`ExtensionsUi.manualEdit` → `MainActivity.showManualExtensionEdit` → `ExtensionForgeUi.showManualEdit`). 설명 · 적용 범위(지정한 사이트만 / 모든 사이트) · 제외할 사이트(`Scope.excludes` → 콘텐츠 스크립트 `exclude_matches`) · 코드 파일(js · css · html · json)을 고친다. 이름은 id 를 정하므로 바꿀 수 없다. 저장은 `ExtensionForge.applyManualEdit` 이 새 판(버전 +1, 요청 기록에 「직접 편집: …」)을 만들어 `installDraft` 로 덮어쓴다. 코드를 바꿨을 때만 문법 · 권한 · 시험 실행 검사를 하고, 문제가 있으면 「그래도 저장」을 물어본다. 주소 글 ↔ 패턴 변환은 `parseSites` · `patternsToText`.
- 아이콘: 모델이 JSON 의 `icon`(SVG, viewBox 0 0 128 128, 도형만 · text/image/use/style/script/외부 주소 금지, 6천 자 이하)을 적는다. 앱이 `ExtensionForge.IconRender` 로 숨은 웹뷰 canvas 에 그려 PNG 48 · 128 을 만들고(너무 비어 있으면 거부) `icons/icon48.png` · `icons/icon128.png` · `icons/icon.svg` 로 확장 폴더에 넣는다. 매니페스트 `icons` · `action.default_icon` 은 앱이 덮어쓴다. SVG 가 잘못되면 다른 검사 오류와 같은 자동 수정 고리로 모델에게 돌려주고, 끝내 못 고치거나 그리는 도구가 못 돌면 이름 첫 글자 + 이름에서 정한 색의 아이콘(`fallbackIcon`)으로 대신한다. 고칠 때 모델이 `icon` 을 안 적으면 앞의 아이콘을 그대로 쓴다. `draftOf` 가 PNG · SVG 를 되읽는다.
- 컴파일·실기기 시험이 안 되는 환경이라 코드만 검토했다.

**AI 확장 기록 · 코드 요약 (v4.3.1)**
- 기록: 설치할 때 확장 폴더에 `evergreen_ai_history.json`(`ExtensionForge.HISTORY_FILE`)을 함께 넣는다. `revs`(판 번호 · 날짜 · 요청 · 파일 목록 · 검사 통과 여부, 최근 20판)와 `prev`(고치기 직전 판의 소스 한 판)가 든다. `Draft.revs` · `prevSource` 가 고치는 동안 이어지고, `draftOf` 가 되읽는다(이 파일은 모델에게 소스로 보내지 않는다). `prev` 로 되돌리는 화면은 아직 없다.
- 코드 요약: 모델이 JSON 의 `summary`(한국어 2~4줄)를 적고, 미리보기 카드가 그 줄들과 파일별 줄 수를 「코드 요약」으로 보여 준다. 모델이 안 적으면 파일별 줄 수만 나온다. 요약은 설치 뒤에는 저장하지 않는다(카드에서만 쓴다).

**AI 확장 고치기 (v4.3.0, 3단계)**
- 진입점: AI 제작 확장 카드의 「AI로 고치기」(`ExtensionsUi.aiEdit` → `MainActivity.showAiExtensionEdit` → `ExtensionForgeUi.showEdit`), 어시스턴트의 `edit_extension` 도구(`risk = DANGER`).
- `ExtensionManager.draftOf` 가 설치된 폴더(js · css · html · json, 8개·6만 자 이하)와 매니페스트에서 `Draft` 를 되읽고, 적용 범위는 `content_scripts[0].matches`(없으면 `host_permissions`)에서 복원한다. `ExtensionForge.generate(previous, feedback)` 는 앞 결과를 모델에게 주고 바꿀 점만 반영하게 하며, 이름은 `forceName` 으로 고정해 같은 id 로 덮어쓴다(`stamp`: version 1.0 → 2.0, `evergreen_ai.requests` 에 요청 기록).
- 확장 카드 진단 로그(`diagLines`)의 마지막 6줄이 있으면 요청 뒤에 `[최근 진단 로그]` 로 함께 보낸다. 고친 결과도 같은 검증 · 시험 실행 · 미리보기 카드를 거치고 「적용」을 눌러야 바뀐다.
- 한계: 진단 로그는 사용자가 「AI로 고치기」를 열 때만 쓴다(오류가 났다고 저절로 고치지는 않는다). 읽을 수 없는 큰 파일(6만 자 초과)이 있는 확장은 고칠 수 없다.

**AI 확장 시험 실행 (v4.2.1, 2단계)**
- `ExtensionForge.DryRun`: 정적·문법 검사를 통과하면 숨은 웹뷰에서 백그라운드(service_worker) → 콘텐츠 스크립트 순서로 한 번 돌리고 1.5초 동안 오류를 모은다(`onStep("run")`). 오류가 있으면 1단계와 같은 자동 수정 고리(최대 2번)로 모델에게 돌려준다.
- `chrome.*`/`browser.*` 는 무엇을 불러도 조용히 받는 가짜(Proxy)다. 그래서 잡는 것은 코드 자체의 오류(정의 안 된 변수 · null 읽기 등)뿐이고, 앱 shim 과의 실제 호환(미구현 메서드)은 못 잡는다. 콘텐츠 스크립트는 빈 페이지에서 돌리므로 ReferenceError · SyntaxError 만 문제로 센다.
- 만드는 중 화면은 4단계(코드 작성 · 문법과 권한 검사 · 시험 실행 · 미리보기 준비)이고, 「오류 고치는 중 n/2」는 시험 실행 칸에 뜬다.
- 아직 안 한 것(3단계): 후속 수정 대화(「버튼 색 바꿔줘」), 설치 뒤 확장 카드 진단 로그(`diagLog`)를 이용한 자동 수정.

**AI로 확장 프로그램 만들기 (v4.2.0, 1단계)**
- 진입점: 확장 프로그램 창의 `＋ 추가` → 「크롬 웹스토어에서 추가 / AI로 만들기」(`MainActivity.showExtAddChooser` → `showAiExtensionMaker`), 그리고 AI 어시스턴트의 `create_extension` 도구(`risk = DANGER`, 실행마다 확인 카드 + 미리보기 카드). 둘 다 같은 엔진 `ExtensionForge` 와 같은 카드(`ExtensionForgeUi.previewCard`)를 쓴다.
- 엔진(`ExtensionForge.generate`): ① 4 Hydrogen(`GeminiModels.HYDROGEN`, 한도 등으로 막히면 `GeminiClient` 가 다른 모델로 대신)에게 시스템 프롬프트(허용 API · 금지 API · 형식)와 요청을 보내 `{name, description, manifest, files}` JSON 을 받는다. ② 검증 → 실패하면 오류 목록을 모델에게 돌려줘 최대 `MAX_FIX`(2)번 고친다. ③ 그래도 남은 문제는 `Draft.problems` 로 카드에 「일부 기능이 동작하지 않을 수 있어요」로 보여 준다.
- 검증: 매니페스트가 가리키는 파일 존재 · 실행 코드 유무 · 금지 패턴(`eval` · `new Function` · 문자열 `setTimeout` · 원격 코드 · 외부 주소로 요청 · `document.cookie`) · 금지 `chrome.*` 이름공간(`BLOCKED_NS`) · 숨은 웹뷰에서 `new Function()` 으로 하는 JS 문법 검사(코드는 실행하지 않음; 모듈 백그라운드는 import/export 줄을 빼고 검사).
- 허용 API 목록(`ALLOWED_NS` · `ALLOWED_PERMS`)은 ext_shim.js 가 구현한 것 가운데 AI 확장에 맞는 것만 **손으로 고른 목록**이다(자동 추출 아님). shim 에 새 API 가 늘면 여기에도 더해야 프롬프트에 실린다.
- 적용 범위는 모델이 아니라 사용자가 정한다(`Scope`: 이 사이트만 / 모든 사이트 / 직접 입력). 만든 매니페스트의 `content_scripts[].matches` 와 `host_permissions` 를 앱이 덮어쓰고, 허용 목록에 없는 권한 · `key` · `update_url` · `externally_connectable` · CSP 등은 지운다. 모든 사이트면 카드에 노란 경고 + 노란 칩.
- 설치는 `ExtensionManager.installDraft`(zip 으로 묶어 기존 `installBytes` 로 설치). 사용자가 카드에서 「적용」을 눌러야 한다. 매니페스트에 `evergreen_ai` 키가 있으면 `isAiMade` → 확장 카드에 「AI 제작」 칩. 같은 이름으로 다시 만들면 같은 id 로 덮어쓴다(`makeId` 가 이름으로 정함).
- 아직 안 한 것(2단계 이후): 백그라운드 시험 실행(숨은 웹뷰에서 서비스 워커를 한 번 돌려 시작 오류 잡기) · 시작 오류 로그의 자동 수정 · 후속 수정 대화(「버튼 색 바꿔줘」) · 카드 「코드 보기」 대신 미리보기 펼치기. 지금 검사는 정적 검사 + 문법 검사까지다.
- 컴파일·실기기 시험이 안 되는 환경(안드로이드 SDK 없음)이라 코드만 검토했다. 빌드에서 오류가 나면 알려 주면 바로 고친다.

**AI 모델에서 3.8 Flash 제거 (v4.1.57)**
- `GeminiModels` 의 `PRO` 칸(gemini-3.8-flash)을 없애 모델은 `LITE`(3.5 Flash-Lite) · `HYDROGEN`(4 Hydrogen) 두 칸이다. 설정의 모델 카드도 자동 · Flash-Lite · Hydrogen 셋이다.
- 사진 읽기(`GeminiAuto.VISION` · `AgentModels.VISION`: 채팅 사진 · 이미지 번역 · 실시간 자막 · 에이전트 화면 보기)는 Flash-Lite 가 맡는다. 자동 선택(`forChat`)은 사진이면 Flash-Lite, 깊은 추론이면 Hydrogen 이다. 모델이 한도 등으로 막혔을 때의 대체 순서(`fallbacks`)는 Flash-Lite ↔ Hydrogen 이다.
- 에이전트 `web_search` 는 HYDROGEN → LITE 순으로 시도한다 (v4.1.58 에서 순서를 바꿈. 검색 도구를 못 받는 모델은 기존대로 건너뛴다).
- 저장돼 있던 모델 선택이 `PRO` 이면 `Prefs.assistantModel` 이 모르는 값으로 보고 「자동」으로 바꾼다. 옛 `gemini-N-flash` 이름이 남아 있으면 `GeminiModels.successor` 가 Flash-Lite 로 잇는다. 기본 모델 목록(`baseKey`)이 바뀌어 저장해 둔 모델 교체 결과(`GeminiModelSync`)는 한 번 버려진다.
- 컴파일·실기기 시험이 안 되는 환경이라 코드만 검토했다.

**AI 의 iframe(외부 임베드) 조작 (v4.1.40)**
- 문제: 앱의 웹뷰 `evaluateJavascript` 는 주 프레임에서만 돈다. 그래서 `read_page` · `click_element` 가 iframe(영상 · 결제 · 로그인 · 댓글 위젯 등, 특히 다른 출처)의 안쪽을 못 봤다 (`iframes: n` 개수만 나왔다).
- 구조: 웹뷰를 만들 때 ① `addWebMessageListener(wv, "EvFrame", {"*"}, FrameListener)` ② `addDocumentStartJavaScript(wv, AgentPageTools.frameBridgeScript(), {"*"})` 를 붙인다(`WEB_MESSAGE_LISTENER` + `DOCUMENT_START_SCRIPT` 를 지원하는 웹뷰에서만. 아니면 예전처럼 본문만). 스크립트는 **iframe 안에서만** 돌고(본문은 즉시 반환), 자기 이름표(`tok`, 무작위)를 `hi` 로 앱에 알린다. 앱은 `BrowserTab.frameRecs`(이름표 → `FrameRec`: 프레임 번호 · 그 프레임에만 말을 거는 `JavaScriptReplyProxy`)에 올리고, 페이지가 새로 열리면(`onPageStarted`) 비운다. 프레임이 사라지면(`pagehide` → `bye`) 내리고, 응답이 없으면(한 번도 답 못 한 프레임은 바로, 답하던 프레임은 연달아 두 번) 뺀다.
- 동작 요청: `AgentPageTools.runOp(frame, op, P)` 가 `frame == 0` 이면 예전처럼 본문에서 `wrap()` 으로 돌리고, 아니면 `AgentHost.frameScript` → `MainActivity.agentRunFrameScript` 가 그 프레임의 reply proxy 로 `{t:'run', id, op, p}` 를 보낸다. 프레임은 미리 들어 있는 같은 코드(`ALL_OPS`)로 돌린 뒤 `{t:'res', id, tok, r}` 로 답하고, 앱은 **요청 때 정한 이름표와 같은 프레임의 답만** 받는다(다른 프레임이 남의 답을 꾸미지 못하게). 5초 안에 답이 없으면 실패.
- 모든 스크립트(`READ` · `AIM` · `INFO` · `CLICK` · `FILL` · `DRAG` · `SCROLL`)는 이제 문자열 치환(`__ID__` …) 대신 값 객체 `P`(`wrap(body, fx, p)` 가 `var P={...};` 로 넣는다)를 읽는다. 본문과 iframe 이 같은 코드를 쓴다. **`eval` · `new Function` 을 쓰지 않아서** iframe 의 CSP(`script-src` 에 `unsafe-eval` 없음)에 막히지 않는다.
- 요소 번호: iframe 안 요소는 `프레임번호 × 1000 + 프레임 안 번호`(2003 = 2번 iframe 의 3번 요소). `frameOf` · `localOf` 가 나눠서 알아서 그 프레임으로 보낸다. 마지막 `read_page` 결과에서만 유효한 건 본문과 같다.
- `read_page`: 본문을 읽은 뒤 등록된 iframe 들에 한꺼번에(스레드) 같은 읽기를 시켜 `mergeFrames` 가 합친다. 요소에 `frame` 이 붙고, `frames` 목록에 프레임별 `url` · `size` · `shown` · `total` · `text`(600자) 가 든다. 40px 미만이거나 비어 있는 프레임(광고 · 추적용)은 건너뛰고, 합친 요소는 최대 120개(프레임당 30개). 화면 밖 iframe(프레임 안 `IntersectionObserver` 로 판단)은 viewport 읽기에서 `offscreen: true` 로 자리만 알려 주니 `scroll_page` 로 가까이 간 뒤 다시 읽는다. 본문 결과에는 `iframe_boxes`(src · 크기 · 위치 · 화면 안 여부)도 들어 AI 가 어느 iframe 인지 짐작할 수 있다. 안을 못 읽으면 `iframe_note` 로 이유를 알린다.
- `scroll_page`: `element` 가 iframe 안 요소면 iframe 안 + 바깥 페이지를 함께 맞춘다(프레임 안 `scrollIntoView({block:'nearest'})` 가 다른 출처 부모까지 스크롤한다). `frame` 을 주면 그 iframe 안(자체 스크롤)을 스크롤한다. 그 밖의 동작도 요소를 건드리기 전에 `safeScroll` 이 같은 일을 해서, 화면 밖 iframe 안 버튼도 눌린다.
- 안전: 위험 버튼 확인(`RISKY` · 제출 · 내려받기), 비밀번호/카드/인증번호 칸 금지, 새 탭 링크 · 앱 부르는 링크 금지는 iframe 안에서도 그대로다. 확인 카드에는 「· iframe(호스트)」 가 붙는다. 더해서 iframe 주소가 결제 · 인증 서비스처럼 보이면(`PAYF`: stripe · paypal · adyen · toss · portone · kakaopay · naverpay · nicepay · inicis · kcp · payment · billing · `pay.` 등) 그 안의 글자 입력칸은 전부 `secret` 으로 본다(카드 입력칸을 가리는 레이블이 iframe 밖에 있어 속성만으로는 못 알아볼 수 있어서). 시크릿 탭 허용 여부는 본문과 같은 검사를 거친다.
- 한계: 끌기는 같은 프레임 안에서만(다른 프레임 사이 끌기는 실패로 알림). `sandbox` 로 스크립트가 막힌 iframe 은 목록에 안 올라온다. 가짜 클릭이라 사용자 제스처가 필요한 동작(팝업 · 파일 선택 · 전체 화면)은 사이트가 막을 수 있다. 시험: 이 환경에서 컴파일은 `AgentPageTools` 만 확인했고(나머지는 안드로이드 SDK 가 없어 못 함), 프레임 스크립트는 크롬 + Playwright 로 다른 출처 iframe · 2중 iframe · CSP · 결제 호스트 · 화면 밖 iframe 을 시험했다. `MainActivity` 쪽(등록 · 메시지 주고받기)은 코드만 검토했고 실기기 시험은 못 했다.

**조작 커서의 별 (v4.1.36)**
- 별 구조: `star`(스프링 이동) > `sPop`(도착·클릭 팝 + 뒤 빛무리 `sGlow`) > `sb`(숨쉬기: 위아래 · 크기, 2.4초) > `sSpin`(360도 계속 회전 5.2초). 한 바퀴를 돌아야 그라데이션 방향이 처음과 같아 반복 때 색이 튀지 않는다(이전엔 180도 왕복이라 반복마다 색이 뒤집혔다).
- 따라오기: WAAPI 로 화살표와 같은 곡선을 시간차만 두던 것을 rAF 스프링(`stepStar`, 강성 170 · 감쇠 20)으로 바꿨다. 이동 중 새 목표가 와도 취소 · 스냅 없이 이어서 쫓아가고, `setCur`(요소가 움직여 자리를 고칠 때)도 별은 스냅하지 않고 스프링으로 따라간다.
- 화살표 `moveTo` 는 이제 직전 목표가 아니라 지금 화면에 보이는 자리(`curNow`, computed transform)에서 출발해, 이동 도중 새 이동이 시작돼도 튀지 않는다.
- 속도 반응: 별 속도에 따라 회전 `playbackRate` 가 1~7배로 변하고(연속), 일정 거리마다 작은 별가루(`spark`, 동시 최대 20개)를 흘린다. 도착(40px 이상 이동 뒤 멈춤) 시 `popStar`. 입력 중(`type`)에는 기본 회전이 2.4배(`busy`).
- 클릭(`ripple`): 누른 자리에서 별가루 6개가 퍼지고 별이 크게 한 번 반짝인다. 숨겨진 동안(`hide` 300ms 뒤)에는 반복 애니메이션을 멈춰 배터리를 아낀다. `API.v` 16.
- 4.1.37: 과하지 않게 낮춤 — 숨쉬기 크기 1.06배 · 빛무리 투명도 .2~.45 · 회전 7초/바퀴 · 속도 반응 회전 최대 +2.5배 · 별가루는 속도 420px/s 이상에서 24px마다 최대 8개(작고 옅게) · 도착 팝 1.1배(90px 이상 이동 때만) · 클릭 별가루 4개 · 입력 중 회전 1.6배. `API.v` 17.
- 4.1.38: 더 깔끔하게 — 별가루(트레일 · 클릭) · 빛무리 · 숨쉬기 · 속도 반응 회전 · 입력 중 가속을 모두 뺐다. 남은 것: 스프링 따라오기, 7초/바퀴 일정 회전(`sSpin`), 클릭 때 1.12배 팝(`popStar`). 구조는 `star` > `sPop` > `sSpin`. `API.v` 18.
- 4.1.39: 별 회전(`sSpin` 의 360도 애니메이션)을 없앴다. 별은 돌지 않고 스프링으로 따라오기만 하며 클릭 때 1.12배 팝만 남는다. `API.v` 19.

**읽기 표시: 배경 빛 + 이름표 (v4.1.34, 4.1.35 에서 더 움직이게)**
- `marks()`(read_page): 알갱이 · 요소 빛 · 상자 · 띠 없이, 아래쪽에서 번지는 큰 배경 빛 3개(`radial-gradient`, 자리 · 크기 · 색 시작점/방향 무작위)가 무한 왕복(`alternate`)으로 천천히 일렁이고, 아래 이름표 "페이지 읽는 중…" 이 뜬다. 길이 1.9~2.9초 뒤 0.8초 동안 서서히 사라진다.
- 연장: 빛이 남아 있을 때(`washBox`) 또 읽으면 새로 만들지 않고 같은 빛을 유지한 채 사라질 시각(`wtimer`)만 늦춘다. `clearMarks()` 는 요소를 0.28초 서서히 투명하게 한 뒤 지운다. `API.v` 15. 4.1.35: 빛덩이 이동폭을 가로 ±14~26vw · 세로 ±8~18vh(왕복 4.2~6초)로 키우고 표시 길이를 2.4~3.4초로 늘려 읽는 동안 눈에 띄게 흐른다.

**웹 조작 표시 정확도 (v4.1.25)**
- 스크롤 영역에 가려진 요소: `safeScroll` 이 화면 안에 있어도 조상의 `overflow` 영역 밖(`clipped`)이면 그 영역을 먼저 스크롤한다. 영역 스크롤은 `scrollTo({behavior:'instant'})` 로 해서 CSS `scroll-behavior:smooth` 에도 위치가 바로 맞는다. (이전에는 가려진 자리를 커서가 가리켰다.)
- 커서 추적: 짚은 요소가 도착 뒤에 움직이면(`place()` 의 `aimPtF`) 커서도 따라간다.
- 끌기: 시작 요소 짚기 → `F.dragTo(…, dur)` 가 커서를 옮기는 동안 같은 시간·곡선(smoothstep)으로 `setTimeout` 단계마다 `…move` 를 보낸다. 슬라이더는 값에서 구한 손잡이 자리에서 출발해 단계마다 값을 바꾸고 끝에 `change`. 결과의 `ms` 만큼 Kotlin 이 기다린다. 표시가 꺼져 있으면 예전처럼 즉시 보낸다. `API.v` 5.
- 확인: 데스크톱 Chromium(playwright)에서 스크롤 영역 안 요소를 커서가 정확히 짚는지, 슬라이더 값과 커서 위치가 같이 가는지 확인. Kotlin 은 컴파일 못 함.

**웹 조작: 끌기 `drag_element` (v4.1.24)**
`AgentPageTools` 에 도구 추가(위험도 CHANGE, 요청당 한 번 확인). 인자: `element`(끌 요소) + `to_element`(그 위에 놓기) 또는 `dx`·`dy`(픽셀). 스크립트 `DRAG`:
- `input[type=range]` 는 도착 x 위치를 min~max 값으로 바꿔 직접 넣고 `input`·`change` 를 보낸다(왼쪽→오른쪽 막대만 가정).
- 그 밖에는 `pointerdown/mousedown/touchstart` → 14단계 `…move`(느림-빠름-느림 곡선) → `…up`. `draggable=true` 요소는 `dragstart/dragenter/dragover/drop/dragend`(DataTransfer 포함)도 보낸다.
- 시작 요소가 가려져 있거나 도착 요소가 화면 밖이면 실패 이유를 돌려준다. `isTrusted` 를 검사하는 사이트에서는 안 먹을 수 있다. (4.1.25 부터 이벤트를 커서와 같은 시간에 걸쳐 단계마다 보낸다.)
- 표시: `aim(kind=drag)` 로 시작 요소를 짚은 뒤 `F.dragTo()` 가 커서·별을 도착 자리까지 옮기고 「끄는 중」 이름표를 띄운다(`API.v` 4).
- 확인: 데스크톱 Chromium(playwright)에서 같은 코드로 슬라이더 · 마우스 끌기 · HTML5 끌어다 놓기가 동작함을 확인했다. Kotlin 은 컴파일 못 함.

**별 더 가깝게 (v4.1.23)**
커서 옆 별 위치를 `(+9, -12)` → `(+6, -9)` 로 좁혔다(위쪽에서는 y 2px 고정). 화살표 윗변과는 흰 테두리 포함해 겹치지 않는 선까지만. JS 는 `node --check` 만 확인.

**별 크기 조금 줄임 (v4.1.22)**
커서 옆 별을 22px → 19px 로 줄이고 위치는 `(+9, -12)` 로 맞췄다(위쪽에서는 y 2px 고정). JS 는 `node --check` 만 확인.

**별 흰 테두리 (v4.1.21)**
커서 옆 별에 화살표와 같은 흰 테두리(`stroke:#fff`, 2.4, `paint-order:stroke`)를 둘렀다. JS 는 `node --check` 만 확인.

**별 크기 · 거리 (v4.1.20)**
커서 옆 별을 16px → 22px 로 키우고 위치를 오른쪽 위 `(+9, -14)` 로 좁혔다(위쪽에서는 y 2px 고정). 화살표 윗변과 겹치지 않는 선까지만 붙였다. JS 는 `node --check` 만 확인.

**커서 곡선 · 별 위치 (v4.1.19)**
`FXLIB` 의 `ARROW` 를 모서리가 둥근 곡선 포인터로 바꾸고, 따라다니는 별을 오른쪽 위(`+15, -18`, 화면 위쪽에서는 y 2px 로 고정)로 옮겼다. 짚는 테두리 둥글기(`rad` 12~30) · 번호 상자(11px) 도 키웠다. JS 는 `node --check` 만 확인.

**화살표 커서에 그라데이션 (v4.1.18)**
`FXLIB` 의 화살표 포인터를 흰색 대신 `AiGradient.STOPS` 그라데이션으로 채우고(`evgA`), 흰 테두리(`paint-order:stroke`)로 어느 배경에서도 보이게 했다. JS 는 `node --check` 로 문법만 확인(컴파일·실기기 시험 불가).

**웹 조작 표시 · 보내기 버튼 · 첫 화면 다듬기 (v4.1.17)**
컴파일·실기기 시험은 못 했고, `FXLIB` JS 는 `node --check` 로 문법만 확인했다.
- 웹 조작 커서: 별 하나 대신 **화살표 포인터 + 오른쪽 아래를 조금 늦게 따라오는 그라데이션 별**. 별 꼬리(trail) · 옆의 작은 별은 없앴다. 그라데이션은 커서 별과 이름표 안의 작은 별에만 쓴다.
- 이름표 · 테두리 · 번호 상자 · 클릭 물결 · 스크롤 막대: 흐르는 그라데이션을 없애고 단색(`ACC` = `STOPS[2]`)으로. 이름표는 어두운 단색 알약(확인 대기=주황, 실패=빨강). `API.v` 3.
- 보내기 버튼(`AssistantUi`): `OrbDrawable` 구슬 대신 `AiGradient.ACCENT` 단색 동그라미 + 흰 화살표. 답을 받는 동안 색이 흐르던 것도 뺐다(중지 아이콘만 바뀜).
- 첫 화면 「무엇을 도와드릴까요?」 위: 동그라미(구슬)를 빼고 `GradientImageView` 로 그라데이션 별만 둔다(숨쉬듯 커졌다 작아지는 움직임은 유지).

**웹 조작 표시를 그라데이션 별로 (v4.1.16)**
v4.1.15 의 「AI」 글자 커서를 `AiGradient.STOPS`(초록→청록→파랑→보라, 테마 대표색에 맞춰 바뀜) 색의 4점 별로 바꿨다. `wrap()` 이 `gradJs()` 로 색을 만들어 `FXLIB` 의 `__GRAD__` 자리에 넣는다(페이지에 한 번 깔리므로 이미 열린 페이지는 테마를 바꿔도 다음 페이지부터 반영).
- 커서: 회전하는 그라데이션 별 + 옆의 반짝이는 작은 별. 포인터 자리에서 오른쪽 아래로 비켜 앉아 대상 글자를 가리지 않고, 이동 경로에 작은 별 꼬리가 남는다.
- 이름표 · 테두리: 색이 옆으로 흐르는 그라데이션(마스크로 만든 그라데이션 테두리). 확인 대기는 주황, 실패는 빨강→보라 계열로 구분한다. 번호 상자는 화면 위치에 따라 그라데이션 색을 입고, 스캔 띠 · 클릭 물결 · 스크롤 막대도 같은 색을 쓴다.
- 주의: 하이라이트 면(`tint`)에 `opacity` 애니메이션을 걸면 숨김(`opacity:0`)을 덮어써서 잔상이 남으니 걸지 않는다.

**에이전트 웹 조작 시각화 (v4.1.15)**
컴파일·실기기 시험이 안 되는 환경이라 Kotlin 쪽은 코드만 검토했고, 페이지에 주입되는 JS 는 데스크톱 Chromium 에서 앱과 같은 코드를 그대로 돌려 동작·화면을 확인했다.
AI 가 웹을 읽고 · 누르고 · 입력하고 · 스크롤하는 걸 사용자가 볼 수 있게 페이지 위에 표시를 띄운다 (`AgentPageTools.FXLIB`).
- 표시: read_page = 보이는 요소마다 번호 상자 + 위→아래로 훑는 띠 + 「페이지 읽는 중 · 요소 N개」 / click_element = 「AI」 커서가 요소로 이동 → 테두리 + 「누르는 중 · 「버튼」」 → 클릭 물결 + 「✓ 눌렀어요」 / fill_field = 커서 이동 → 쓸 글이 한 글자씩 써지는 이름표 → 「✓ 입력했어요」(선택 상자 · 체크 상자는 각각 고르는 중 · 체크 바꾸는 중) / scroll_page = 오른쪽 가장자리 위치 막대 + 「↓ 아래로 스크롤 · N%」 / 실패 = 빨간 이름표에 이유(「다른 요소가 가리고 있어요」 등).
- 순서: 누르기 · 입력 전에 `aim()` 이 `AIM` 스크립트로 커서를 먼저 보내고 도착할 만큼(250~1800ms) 기다린 뒤 실제 동작 스크립트를 돈다. 그래서 표시와 동작이 같이 보인다.
- 확인 카드: `ask` 에서 `aim(kind=ask, wait=false)` 로 대상 요소를 주황 테두리로 짚어 둔다(15초). 이어지는 조작이나 read_page 가 오면 바로 대체된다.
- 진행 카드 글: read_page 결과의 번호 → 이름을 `seenLabels` 에 기억해 두고 「3번 요소를 누르는 중…」 대신 「로그인 누르는 중…」 으로 보여 준다.
- 안전: 표시는 닫힌 shadow root 안, `html` 바로 아래 `position:fixed; pointer-events:none` 이라 페이지 레이아웃 · read_page 요소 목록 · `innerText` · `elementFromPoint` 에 잡히지 않는다. 사이트 CSP 에 막히지 않게 `<style>` · `innerHTML` 없이 CSSOM · `createElementNS` · Web Animations 만 쓴다. 표시 코드가 실패해도 조작은 계속된다(전부 try/catch). 비밀번호 칸은 쓸 글을 표시하지 않고 「직접 입력해 주세요」 로 짚는다.
- 설정: `Prefs.agentFx`(기본 켜짐) = 설정 > 에이전트 > 「웹 조작 표시」. 끄면 `AgentHost.showActions()` 가 false 라 표시도 기다림도 없다.
- 주의: `FXLIB` 는 코틀린 raw string 이라 JS 안에 달러 기호 템플릿 · 큰따옴표 세 개를 쓰지 않는다.

**에이전트 웹 조작 뒤 레이아웃이 이상해지던 문제 (v4.1.12)**
코드만 읽고 고쳤다(컴파일·실기기 시험 불가, 원인은 추정). `AgentPageTools` 의 입력·클릭 스크립트가 `scrollIntoView` 를 써서, `overflow:hidden` 인 바깥 칸(채팅형 고정 레이아웃 등)까지 같이 밀어 화면이 어긋났을 것으로 봤다.
- `safeScroll(el)` 로 교체: 요소가 이미 화면에 다 보이면 아예 안 움직이고, 아니면 스크롤이 허용된 조상 칸과 문서만 가운데로 맞춘다. click_element · fill_field · scroll_page(element) 모두 적용.
- 글쓰기 가능한 div(contenteditable)에는 `focus({preventScroll:true})` 로 포커스가 화면을 끌고 가지 않게 했다.

**에이전트가 닫힌 창으로 탭을 못 옮기던 문제 (v4.1.11)**
코드만 읽고 고쳤다(컴파일·실기기 시험 불가, 원인은 추정). 열린 창·수동 이동은 이미 되고 에이전트 경로(`agentMoveTabsToWindow`)에서만 막히는 지점을 손봤다.
- 창 지정: `agentWindowNumberOf` 로 「창 2」 「창2」 「2번 창」 「#2」 「창 2 (닫힌 창)」 를 번호로 읽고(괄호 설명은 떼고), 번호로 못 찾으면 이름 맞추기로 넘어간다. 「닫힌 창」 이라고만 하면 닫힌 창이 하나일 때 그 창으로, 여러 개면 번호를 묻는다.
- 실패 이유: `closedMoveWhy` 에 닫힌 창 저장이 막힌 이유(http/https 가 아닌 주소 · 저장분 없음 · 40개 꽉 참 · 오류)를 적어 에이전트에게 그대로 돌려준다. 예전엔 「닫히는 중이거나 가득 찼을 수 있어요」 하나뿐이었다.
- 라우팅: `AgentRouting.toolWords`/`actionWords` 에 닫힌 창 · 열린 창 · 번 창 · 창에 · 옮겨 를 더해 「닫힌 창에 넣어 줘」 같은 말이 도구 없는 채팅으로 새지 않게 했다.
- 안내: `move_tabs_to_window` 설명과 에이전트 안내문에 「닫힌 창(open=false)도 창을 열지 말고 window_number 로 바로 옮긴다」 를 더했다.
- 테스트: `AgentRoutingTest` 에 닫힌 창 · 창 번호 말을 더했다.

**AI 첫 화면 구슬 색을 옅게 (v4.1.10)**
`OrbDrawable` 에 `soften`(흰 막 진하기, 기본 0)을 더했다. 빈 화면의 큰 구슬(`AssistantUi` hero)만 `soften = 0.32f` 로 흰 막을 덮어 파스텔 느낌으로 만들었고, 보내기 버튼 구슬은 그대로다.

**웹 페이지 조작이 안 된다고 답하던 문제 (v4.1.9)**
웹 조작 도구(`AgentPageTools`: read_page · scroll_page · click_element · fill_field)는 있었지만, v4.1.8 의 `toolWords` 에 페이지 안 동작 낱말이 모자라 「장바구니에 담아 줘」 「좋아요 눌러 줘」 「구독해 줘」 같은 말이 도구 없는 일반 채팅으로 새고, 거기서 모델이 「웹 조작은 안 된다」고 답했다. 또 웹 조작 중에 「응 그걸로 해」 처럼 짧게 이어 말하면 낱말에 안 걸려 같은 길로 샜고, 앞선 「못 한다」 답이 기록에 남아 에이전트가 그걸 따라 하기도 했다. 컴파일·실기기 시험이 안 되는 환경이라 코드만 검토했다.
- `AgentRouting.toolWords`/`actionWords` 에 누르(다) · 터치 · 담아 · 장바구니 · 좋아요 · 구독 · 재생해 · 더보기 · 펼쳐 · 검색창 · 입력창 · 예약/신청/주문/결제/구매/가입 · 건너뛰 · 팝업 · 웹 조작 · 대신 해 등을 더했다. 「이 페이지에서 …」 같은 구는 요약·질문과 겹쳐서 넣지 않았다.
- `AgentRouting.isFollowUp(question, lastWasAgent)`: 바로 앞 답이 에이전트였고 이번 말이 40자 이하의 짧은 이어 말하기(사진 낱말·인사·고마움 제외)면 에이전트로 보낸다. `AssistantUi.lastWasAgent` 는 매 질문마다 갱신하고 새 대화·대화 지우기·대화 불러오기 때 false.
- `agentGuide` 에 「웹 조작은 되는 기능이다. 앞선 대화에서 못 한다고 했어도 먼저 read_page 로 시도하고, 실패했을 때만 도구가 준 이유를 전하라」 를 더했다. `buildSystem(chatOnly = true)` 안내에도 웹 조작이 된다는 말과 페이지 조작 예시를 더했다.
- 테스트: `AgentRoutingTest` 에 웹 조작 말 → 에이전트, 이어 말하기 규칙을 더했다.

**에이전트가 되는 기능을 「지원 안 한다」고 답하던 문제 (v4.1.8)**
원인은 에이전트 자체가 아니라 **길 가르기**였다. `AssistantUi.generate` 가 `AgentRouting.needsTools`(낱말 목록)에 걸린 질문만 에이전트(도구 있음)로 보내고 나머지는 도구도 없고 앱 기능도 모르는 일반 채팅으로 보내서, 목록에 없는 말투(「구글 열어봐」 「데스크톱 사이트로 바꿔」 「새 창으로 옮겨」 등)나 사진 낱말이 섞인 말(「이 이미지 다운로드해 줘」)은 일반 채팅 모델이 「그건 지원하지 않아요」 라고 답했다. 컴파일·실기기 시험이 안 되는 환경이라 코드만 검토했다.
- `AgentRouting.toolWords` 를 도구·`change_setting` 설정에 맞춰 넓혔다(창 · 시크릿 · 열어/들어가/접속 · 폴더 · 확대/축소/줌 · 데스크톱 · 상/하단바 · 켜 주/꺼 주/켜기/끄기/해제 · 웹스토어 · 맨 위/아래 · 로그인/제출 등). 「번역」 「광고」 「보안」 처럼 일반 질문에도 흔한 낱말은 한 낱말로 넣지 않고 「항상 번역」 「광고 차단」 같은 구로만 넣었다.
- `AgentRouting.useAgent` = 도구가 필요한 말 && (사진 낱말이 없거나 `hasAction`). 사진 낱말(`seeWords`)만 있으면 무조건 일반 채팅으로 보내던 것을, 「다운로드 · 북마크 · 탭 · 설정 …」 같은 앱 조작이 분명한 말(`actionWords`)이 함께 있으면 에이전트로 보내도록 바꿨다. 「이 사진 뭐야?」 처럼 사진을 읽어야 하는 말은 그대로 일반 채팅이다. 꾹 눌러 고른 사진을 붙인 질문(`attach`)도 그대로 일반 채팅.
- 그래도 일반 채팅으로 새는 말을 위해 `buildSystem(chatOnly = true)` 가 안내를 붙인다. 에이전트가 켜져 있으면 「앱 조작은 되지만 이 대화엔 도구가 없다. 지원 안 한다고 말하지 말고 한 문장으로 다시 말해 달라고 안내」, 꺼져 있으면 「AI 설정에서 AI 에이전트를 켜면 된다」. 에이전트 쪽 시스템 문장(`buildSystem(snap, false)`)에는 붙이지 않는다.
- 테스트: `AgentRoutingTest` (앱 조작 말 → 에이전트, 사진 낱말+앱 조작 → 에이전트, 사진 읽기·잡담 → 일반 채팅).

**AI 웹 검색이 조용히 꺼지거나 검색한 척 답하던 문제 (v4.1.7)**
`google_search` 도구는 `GeminiSearch.apply` 가 붙이는데, 세 군데에서 검색이 소리 없이 빠졌다. 컴파일·실기기 시험이 안 되는 환경이라 코드만 검토해 고쳤다.
- `GeminiSearch.rejected`: 400 본문에 `google_search`·`googlesearch`·`tool` 만 있으면 그 모델을 **영구히** "검색 못 받는 모델"(`unsupported` 집합)로 기억했다. 구글 오류 글은 모델마다 달라(「Search Grounding is not supported」 등) 못 알아보면 400 오류로 그대로 끝났고, 알아본 뒤엔 앱을 껐다 켜기 전까지 그 모델은 검색이 꺼졌다. 이제 `blamesSearch` 가 `grounding`·`search as a tool` 도 검색 탓으로 보고(API 키 오류는 제외), 기억은 10분 뒤 풀린다(`unsupported` 를 모델 → 풀리는 시각 맵으로 바꿨다. `isUnsupported`·`clearUnsupported`).
- `GeminiClient.once` 에 `requireSearch`(= `!searchOptional`)·`onSearchDropped` 를 더했다. 검색이 꼭 필요한 요청(에이전트 `web_search`)에서 모델이 검색 도구를 거부하거나 거부한 걸로 기억돼 있으면, 검색 없이 다시 보내 지어낸 답을 성공으로 돌려주던 것을 그만두고 `Round.searchRejected` 로 알린다. `stream` 은 이 경우 `retryable` 로 보고 다른 모델로 바꿔 보낸다(검색 못 받는 걸로 알려진 모델은 후보에서 뺀다). 구글이 준 설명 글(영어)은 안내 끝에 「구글 응답: …」 로 붙는다. `Round.code` 는 0 으로 둬서 Hydrogen 이 400 으로 "없는 모델" 취급(`hydrogenDenied`)되지 않게 했다.
- 검색이 꼭 필요하지 않은 채팅은 예전처럼 검색 없이 다시 보내되, 이제 `onSearchDropped` 로 「○○ 은(는) 웹 검색을 못 써서 검색 없이 답했어요」 토스트를 띄운다(한도 때의 토스트와 따로).
- 에이전트 `web_search`: 검색을 켜도 모델이 검색을 건너뛰고 아는 대로 답하면 응답은 200 인데 `groundingMetadata`(검색한 말·출처)가 없다. 이 답을 「웹 검색을 마쳤어요」 성공으로 돌려주던 것을 고쳤다. 검색한 말·출처가 하나도 없으면(`grounded` false) PRO → LITE 순으로 한 번 더 시도하고, 그래도 없으면 실패로 알린다(한도 오류는 모델을 바꿔도 같아서 더 시도하지 않는다). 시스템 문장도 「반드시 구글 검색을 실행하고 검색 결과에 있는 사실만 정리」 로 강하게 바꿨다. 중지(`ctx.cancelled`)하면 다음 모델로 넘어가지 않는다.
- 테스트: `blamesSearch`, `rejected`·`isUnsupported`·`clearUnsupported` (`GeminiKeyPoolTest`).

**사고 과정 「번역됨」 표시 (v4.1.6)**
`ThoughtView`(`AssistantUi`)에 `translatedTag`(지구본 아이콘 + 「한국어로 번역됨」, 11sp)를 생각 글(`thoughtClip`) 아래에 더했다. 한 문단이라도 `koCache` 로 옮겨 보이고 있으면(`koView(shownThought) != shownThought`) 보이고, 새 문단이 옮겨질 때마다 `refreshTranslatedTag()` 로 갱신한다. 생각이 끝나 한국어 글이 기록에 남을 때(`onTranslated`) `ChatMsg.thoughtTranslated` 를 true 로 두고 `ChatStore` 에 `"tt"` 로 저장해서, 저장한 대화를 다시 열어도(이미 한국어 글이라 `needsKo` 가 false 여도) `setTranslated(true)` 로 표시가 유지된다. 예전에 저장된 대화는 플래그가 없어 표시가 없다.

**AI 버튼은 AI 창이 열려 있을 때만 색이 변함 (v4.1.5)**
`GradientImageButton` 에 `setActive(on)` 을 더했다. 꺼져 있으면 `super.onDraw` 그대로(바 tint 색), 켜지면 그라데이션을 SRC_IN 으로 입힌다(220ms 로 두 레이어를 `saveLayerAlpha` 로 섞어 바뀜). `AssistantUi` 에 `onOpenChanged` 콜백을 더하고 `dialog`·`popup`·`splitPanel` 의 setter 에서 `isOpen()` 이 바뀔 때만 알린다. `MainActivity.aiActive`/`applyAiActive()` 가 `tbAi`·`topBarExtra("ai")`·`bottomExtra("ai")` 에 반영하고, 새로 만든 버튼도 현재 상태로 시작한다(애니메이션 없이).

**상·하단바 AI 버튼 별 모양 (v4.1.4)**
바 버튼은 `ic_ai.xml` 이 아니라 `MorphIconDrawable`(`kind="ai"`)이 직접 그리는데, 여기에는 v4.1.1 이전의 「큰 별 + 작은 별」 모양(`STAR_BIG`·`STAR_SMALL`, 선만)이 남아 있어 AI 창의 별과 모양이 달랐다. `buildBigStar` 를 `ic_ai.xml` 과 같은 24 격자 한가운데 4갈래 별(꼭짓점 3.5~20.5)로 바꾸고(m=1 별 ↔ m=0 원, 오므라들었다 피어나는 동작은 그대로), 작은 별과 `STAR_*` 상수를 없앴다. 속을 채운 뒤 선(1.8)을 덧그린다. 색은 v4.1.3 의 `GradientImageButton` 이 입힌다.

**상·하단바 AI 버튼 그라데이션 (v4.1.3)**
AI 창 제목 옆 별은 `GradientImageView`(그라데이션), 상·하단바 AI 버튼은 단색 tint 라 색이 달랐다. `AiGradient.kt` 에 `GradientImageButton`(ImageButton + `AiGradient.STOPS` 를 SRC_IN 으로 입힘, 흐르지 않고 정지, 대표색이 바뀌면 shader 재생성)을 더해 `activity_main.xml` 의 `tbAi`(태블릿 상단바)와 `topBarExtra("ai")` · `bottomExtra("ai")`(폰 하단바·사용자 배치)에 썼다. 다른 바 버튼은 그대로 tint. 버튼 편집 화면의 미리보기 아이콘은 단색 그대로.

**AI 로고 속 채우기 (v4.1.2)**
`ic_ai.xml` 의 `fillColor` 를 투명에서 검정(tint 로 색을 입힘)으로 바꿔 별 속을 채웠다. 선(1.8)은 그대로 둬서 모서리가 둥글다.

**AI 로고 4갈래 별 (v4.1.1)**
`res/drawable/ic_ai.xml` 을 큰 별 + 작은 별 두 개짜리 경로에서 24dp 격자 한가운데의 4갈래 별 하나(선 1.8, 둥근 끝)로 바꿨다. AI 로고는 모두 이 드로어블을 쓰므로(`AssistantUi` · `TopBarConfig` · `MainActivity` · `activity_main.xml`) 한 곳에서 바뀐다.

**모델 자동 선택에서 AI 판단 제거 (v4.1.0)**
`GeminiAuto.decide`·`decideSystem`·`decideInput`·`tierModel`·`prewarm`·`Prefs.assistantAutoModel` 과 설정의 「질문의 뜻을 읽고 고르기」 스위치를 없앴다. 자동은 `forChat` 의 낱말·길이 규칙만 쓰므로 질문마다 나가던 Flash-Lite 판단 요청이 없다(한도 절약, 첫 글자까지 빠름). 모델 칩을 꾹 누르면 `noteRule` 이 남긴 이유(「낱말·길이 규칙으로 … 선택」)가 보인다. 직접 고른 모델·한도 때 모델 바꾸기는 그대로.

**AI 설정 회색 바탕 · 흰 카드 (v4.0.9)**
`showSettings`: 바탕(`box` · 카드 팝업 배경)을 회색(라이트 0xF0F1F3, 어두운 표면 0x1E1F22)으로, `panelBg()` 카드를 라이트는 흰색·어두운 표면은 0x2C2D31 단색으로 바꿨다(이전엔 `backdropColors` 그라데이션 바탕 + 글자색 투명 틴트 카드).

**모델 직접 선택 · 3.1 Flash-Lite 제거 · AI 설정 다듬기 · 납작한 구슬 (v4.0.8)**
- `Prefs.assistantModel`: "auto"(기본) 또는 칸 이름("LITE"·"PRO"·"HYDROGEN"). 칸 이름으로 저장해 구글이 모델을 바꿔도(`GeminiModelSync`) 따라간다. `AssistantUi.generate` 는 직접 고른 모델이면 `forChat`·판단 1단계(`decide`)를 건너뛰고 그 모델로 보낸다(`GeminiAuto.noteChat`, 이유는 「설정에서 직접 고른 모델」). 한도·오류 때는 예전처럼 다른 모델로 바꿔 보낸다(`fallbacks`). 에이전트의 계획 모델(`AgentModels.PLANNER`)은 고른 모델과 상관없이 Hydrogen. 모델 칩은 자동이면 「자동 · 모델」, 직접 골랐으면 모델 이름만 보인다(`refreshModelChip`).
- `GeminiModels.LITE31`(3.1 Flash-Lite) 칸 제거: `DEFAULT_IDS`·`FAMILY`·`all`·`fallbacks`·`GeminiModelSync` 에서 뺐다. 판단 1단계는 `LITE`(3.5 Flash-Lite)가 맡는다(판단 호출이 답변용 `LITE` 의 한도를 한 번씩 쓴다). 기본 모델 목록이 바뀌어 `baseKey()` 가 달라지므로 저장된 모델 교체 결과는 한 번 버려지고 다시 받는다.
- AI 설정(`showSettings`): 모델 칸을 「자동 / 3.5 Flash-Lite / 3.8 Flash / 4 Hydrogen」 라디오 카드로 바꿨다(누르면 바로 저장, 고른 카드는 대표색 틴트+테두리). 「질문의 뜻을 읽고 고르기」(`assistantAutoModel`) 스위치는 「자동」일 때만 보인다. 옵션은 체크박스 대신 `MaterialSwitch` 로, 「답변」(웹 검색·사고 과정·대화 저장)과 「에이전트」(에이전트·자율 모드·시크릿 탭) 두 묶음으로 나누고 줄 사이에 얇은 구분선을 둔다.
- `OrbDrawable(ctx, depth)`: 하이라이트(0x66)·아래 그늘(0x2A)의 진하기에 `depth` 를 곱한다. 빈 화면의 큰 구슬은 0.2, 보내기 버튼의 구슬은 기본 1.

**웹 검색 한도가 채팅 전체를 막던 문제 (v4.0.7)**
채팅(`GeminiClient.stream`)은 설정이 켜져 있으면(`assistantSearch` 기본 켜짐) 모든 요청에 `google_search` 도구를 붙이는데, 에이전트(`GeminiAgentClient`)는 붙이지 않는다(웹 검색은 `web_search` 도구가 따로 한 번 묻는다). 구글은 검색 연결(grounding)의 한도를 채팅 한도와 따로 세므로, 검색 한도가 먼저 차면 채팅은 어느 모델·어느 키로 보내도 429 가 나고 에이전트만 됐다. 게다가 그 429 를 모델 한도로 보고 `onLimit` 이 (키, 모델) 짝을 30초~30분 쉬게 해서, 같은 모델을 쓰는 번역·요약·판단 호출까지 "한도"가 됐다.
- `GeminiClient.stream`: 검색을 붙인 요청이 한도 429 를 받으면 `onLimit` 을 부르기 전에 같은 모델·키로 검색만 빼고 한 번 더 보낸다(`probing`, 모델마다 한 번 — `probed`). 성공하면 검색 한도였다는 뜻이라 `GeminiSearch.rest(5분)` 으로 한동안 처음부터 검색을 빼고 보내고(`GeminiSearch.resting()`), `onSearchSkipped` 로 알린다(채팅 화면은 「웹 검색 한도에 걸려서 검색 없이 답했어요」 토스트). 검색을 빼도 막히면 검색 탓이 아니므로 다음 모델에는 검색을 다시 붙이고 예전처럼 모델·키 한도로 처리한다.
- `searchOptional`(기본 true): 에이전트의 `web_search` 는 false — 검색이 그 도구의 일이라 검색 없이 지어낸 답을 돌려주지 않고 「웹 검색 한도에 걸려서…」 로 실패를 알린다.
- 최종 한도 오류에 `GeminiKeyPool.quotaName` 이 읽은 한도 이름(`quotaId`, 없으면 `quotaMetric` 끝 이름)을 「한도 종류: …」 로 덧붙인다. 앞으로 어느 한도(분당·하루·검색 등)인지 바로 알 수 있다.
- 테스트: `quotaName`, `GeminiSearch.rest/resting/clearRest`.

**AI 창 다크 모드 다듬기 (v4.0.6)**
`AssistantUi.backdropColors` 의 어두운 표면 갈래: 블러(glass)일 때 바탕 알파를 0xD6 → 0xF0 으로 올려 밝은 웹 페이지가 비쳐 뿌옇게 보이지 않게 하고, 주색 틴트는 0x70/0x50 → 0x38/0x2A 로 옅게 해서 오로라 빛과 겹쳐 탁해지는 것을 줄였다. `AuroraDrawable` 은 표면이 어두우면(`colorSurface` 밝기 < 0.5) 빛 세기를 0.72 배로 줄인다(어두운 바탕에서는 같은 알파가 훨씬 환해 제목을 가렸다). 라이트 모드 동작은 v4.0.5 그대로.

**AI 창 라이트 모드 흰 배경 (v4.0.5)**
`AssistantUi.backdropColors` 가 앱 표면색(`colorSurface`)이 밝으면(`lightSurface`, 밝은 크롬 테마 포함) 주색을 얹지 않은 순백 단색을 돌려준다(블러가 켜져 있으면 알파 0xF5). 폰 바텀시트·태블릿 팝업·분할 패널·AI 안 확인 팝업이 모두 이 함수를 쓰므로 한 곳에서 바뀐다. 어두운 표면은 예전 그대로(표면색 + 주색 틴트). 흰 배경에서도 말풍선(`colorSurfaceContainerHigh`)·입력줄·카드는 회색 계열이라 구분되고, 대화 영역 패널(`colorSurfaceContainerLow` = 라이트에서 흰색)은 가는 테두리로 구분된다. `AuroraDrawable` 은 18초에 한 바퀴 도는 느린 빛이라 30fps 로만 다시 그린다(그리기 부담·배터리 절약).

**첫 질문의 판단 1단계 (v4.0.4)**
`GeminiAuto.decide` 의 제한 시간이 4초 고정이라, 앱을 켜고 처음 부르는 판단은 서버 연결(DNS·TLS)을 여느라 시간 안에 못 끝나 규칙 선택으로 넘어갈 수 있었다. 처음(`decideWarm` 이 false)에는 9초까지 기다리고 한 번 성공하면 4초로 줄인다. `prewarm()` 이 질문을 보낼 때 페이지를 읽는 동안 연결을 미리 연다. 판단이 안 됐을 때의 이유(시간 초과·한도·호출 오류·빈 답·읽기 실패)를 `lastReason` 에 구분해 남기고, 모델 칩을 꾹 누르면 보인다.

**오류가 난 질문 말풍선 치우기 (v4.0.3)**
AI 답이 오류·빈 답으로 끝나면(`send` 의 `onError`·`onDone`, 에이전트 `toolsRan == 0`) 대화 기록에서 빠진 질문이 화면에 말풍선으로 남아 입력창의 되돌린 질문과 겹쳐 보였다. `removeFailedQuestion` 이 그 말풍선(과 앞의 사진 줄 `ai_thumbs`)을 화면에서 치운다. 오류 말풍선과 「다시 시도」는 그대로다.

**키 전체 휴식 제거 (v4.0.2)**
`GeminiKeyPool.cooldown(key)` 를 부르는 곳을 모두 없앴다(함수는 남아 있으나 쓰지 않는다). 429 는 `coolModel["키|모델"]`, 키 거부(401/403)는 쉬게 하지 않고 호출한 쪽의 `triedKeys` 로 이번 요청에서만 다른 키로 바꾼다. 거부된 키는 다음 요청에서 다시 시도된다.

**한도로 키 전체를 쉬게 하지 않음 (v4.0.1)**
`GeminiKeyPool.onLimit` 의 마지막 갈래(모델 정보 없는 한도)도 `cooldown(key)` 대신 `coolModel["키|모델"]` 만 쉬게 한다(대기 시간 없으면 30초). 429 로는 키 전체를 쉬게 하는 경우가 없고, 키 전체 휴식(`cooldown`)은 401/403 거부(`badKey`, 모델 문제가 아닌 경우)에만 쓴다.

**모델 한도 범위 · 판단 1단계 개선 · 팝업 크기 손잡이 (v4.0.0)**
- 한도(`GeminiKeyPool.onLimit`): Gemini 쿼터는 대부분 모델별이라(quotaId 의 `PerModel`, `quotaDimensions.model`) 분당 한도도 (키, 모델) 짝만 쉬게 한다(알려 준 `retryDelay`, 없으면 60초). 하루 한도는 10분, 한도 0 은 30분. 모델을 가리지 않는 한도만 키 전체를 쉬게 한다. 예전엔 분당 한도가 키 전체를 쉬게 해서 멀쩡한 다른 모델·키까지 "한도"로 보였고, 한 번도 안 쓰이던 `anyUsable` 때문에 쉬는 걸 알면서도 매번 그 모델로 먼저 보냈다.
- `GeminiKeyPool.usable(model)` · `GeminiAuto.usableOrFallback(model)`: 쉬는 모델이면 시작부터 `fallbacks` 중 쉬지 않는 모델로 보낸다(`GeminiClient.stream`·`GeminiAgentClient.step`). 실패 뒤 다음 모델을 고를 때도 쉬지 않는 모델을 먼저 쓴다. 최종 오류에 `restingSummary()`(쉬는 모델과 남은 시간)를 덧붙인다.
- `GeminiClient.stream` 에 `switchModel`(false 면 모델을 바꿔 다시 보내지 않음)·`onModel`(실제 모델이 바뀔 때 알림) 인자를 더했다. 판단 호출(`decide`)은 `switchModel=false` — 예전엔 3.1 Flash-Lite 가 막히면 판단 호출이 3.5·3.8·Hydrogen 으로 번져 답변용 한도를 갉아먹었다. 판단 모델이 쉬는 중이면 호출 자체를 건너뛴다. 채팅 화면은 `onModel` 로 모델 칩을 실제 모델로 맞춘다.
- 판단 지시문(`decideSystem`)은 모델 이름·역할·못하는 일·판단 순서·예시·"한도로 쉬는 중인 tier 는 고르지 말 것"을 담고, 답은 `{"tier","reason"}`. 이유는 `GeminiAuto.lastReason` 에 남고 AI 창 모델 칩을 꾹 누르면 토스트로 보인다(규칙으로 골랐으면 `noteRule`). 판단이 lite 라고 했는데 질문에 코드 모양(`CODE_SHAPE`)이 뚜렷하면 Hydrogen 으로 바로잡는다.
- 팝업 크기 손잡이(`AssistantUi` 의 `makeGrip`): 예전엔 내용 여백(좌우 16dp·아래 10dp) 안쪽에 36×20dp 로 떠 있었다. 이제 음수 여백(−16/−16/−10dp)으로 창 모서리 끝에 붙이고 56×30dp, 위 여백 −6dp 로 세로 차지 높이는 14dp 그대로.

**내 메시지 편집 · 답변 아래 아이콘 축소 (v3.9.102)**
`AssistantUi` 에 `MessageEditor`(inner class)를 더했다. 내 말풍선 바로 아래 `ai_edit_row`(연필 `actionButton`)를 누르면(`startEdit`) 말풍선(`ai_user`)이 GONE 이 되고 같은 자리에 편집 상자(`box`: 같은 그라데이션 배경 + 대표색 테두리, `ChatInput` + 힌트·취소·보내기 줄)가 들어간다. 열린 정도 하나(`render(p)`, `Motion.springValue` 0→1, 강성 360·감쇠 0.8)가 폭(말풍선 폭 → 목록 폭 − 12dp)·버튼 줄 높이(0 → 42dp)·버튼 줄 투명도·테두리 투명도를 함께 움직인다. 끝나면 폭을 MATCH_PARENT 로 바꾼다. 이 메시지 뒤의 뷰들은 알파 0.3 으로 흐려진다(지워질 것이라는 표시).
- 화면 말풍선 ↔ `history` 연결은 뷰 순서로 한다(`userMessageIndex`: 목록에서 `ai_user` 가 몇 번째인지 = 글이 있는 user 메시지 몇 번째인지). `attachImagesToLastQuestion` 이 `ChatMsg` 를 `copy` 로 바꿔치기 하므로 뷰에 ChatMsg 를 쥐여 두지 않는다.
- 취소: 고친 글을 원래 글로 되돌리고 같은 스프링을 0 으로 돌려 말풍선 폭으로 오므린다. 뒤로가기(`handleChatBack`)도 편집만 취소한다. 보내기 전에는 `history` 를 건드리지 않는다.
- 보내기(`commit`): `history` 를 이 질문까지만 남기고 질문 글을 바꾼 새 `ChatMsg`(보낸 사진은 그대로)로 교체, `saveChat()`. 말풍선 글을 새 글로 바꿔 새 폭을 재고(`measureBubbleWidth`) 편집 상자가 그 폭으로 오므라드는 동안 뒤의 뷰들이 접힌다(`collapseViews`: 높이·위 간격·알파를 한 `ValueAnimator` 로). 둘 다 끝나면 `generate(새 글)` 로 답을 받는다(꾹 눌러 고른 사진은 `regenerate` 처럼 다시 붙인다). 첫 질문(`mi == 0`)을 고치면 `GeminiAuto.resetChat()`.
- 답을 만드는 중에는 편집 버튼이 흐려지고 눌려도 안내만 뜬다(`refreshEditButtons`, `setGenerating` 에서 부른다). 창이 닫히면(`onClosed`) 편집기를 정리하고, 보내기를 눌러 둔 질문은 그대로 답을 받는다(`dropEditor(flush = true)`). 다른 대화를 불러오거나 지우면 `flush = false`.
- 태블릿 팝업(포커스 없는 `PopupWindow`)은 편집 글상자를 누르면 입력창처럼 포커스를 가져가고(`editFocusHook` → `gainFocus(target)`) 끝나면 놓는다(`editReleaseHook` → `releaseFocus`).
- 답변 아래 작은 버튼(복사·다시 생성·사진 보기, 새로 생긴 편집)은 `actionButton` 한 곳에서 만든다. 예전엔 `ImageButton` 기본 `scaleType=center` 라서 24dp 아이콘이 그대로 그려졌다. 이제 `FIT_CENTER` + 누르는 자리 30dp(예전 34dp) + 안쪽 여백 7dp → 아이콘 16dp.

**사고 과정 닫을 때 폭 튐 · 다시 열림 (v3.9.101)**
`ThoughtView.setExpanded` 의 움직임 끝(`onAnimationEnd`)에서 말풍선의 원래 폭(WRAP)을 다시 재기 전에 `content.visibility` 를 최종 상태로 먼저 맞춘다. 예전엔 가시성을 폭 측정 뒤에 바꿔서, 닫는 중인 칸이 아직 보이는 채로 재어 넓은 폭(`realW`)이 나왔고 그만큼 폭이 늘어났다 줄었다. 끝에서 상태를 `expanded` 기준으로 쓰고 `post { settleState }` 로 한 번 더 바로잡는다. 헤더 탭은 마지막으로 받아들인 탭 뒤 450ms 안이면(움직임이 끝난 직후여도) 무시한다.

**Decision 1 제거 · 모델 목록 정렬 (v3.9.98)**
`GeminiAuto.decide` 에서 Decision 1(`decideByDecision1`·`DECISION_MODEL`·`decisionDead`)을 통째로 없앴다. 판단 1단계는 3.1 Flash-Lite JSON 판단(v3.9.94~95 방식) → 실패하면 null(낱말·길이 규칙). 설정 모델 목록은 버전 순: 3.1 Flash-Lite(모델 고르기) → 3.5 Flash-Lite(가벼운 질문·번역·페이지 읽기) → 3.8 Flash → 4 Hydrogen. 「모델 자동 선택」 설명도 맞춰 고쳤다. 아래 v3.9.96 의 Decision 1 설명은 지난 기록이다.

**AI 에이전트: 탭을 다른 창으로 옮기기 (v3.9.97)**
도구 두 개를 더했다(`AgentAppTools`). `list_windows`(읽기): `AgentHost.windows()` → `MainActivity.agentWindows()` 가 열린 창(`instances`, 이 AI 가 떠 있는 창은 `current`)과 닫혀 있지만 탭이 저장된 창(`closedWindowNos`)을 번호·이름·탭 수로 돌려준다. 열린 다른 창은 탭 제목 6개까지(시크릿 탭 제목은 뺀다). `move_tabs_to_window`(변경, 확인 카드): `AgentHost.moveTabsToWindow(numbers, window, mode)` → `agentMoveTabsToWindow`. `window` 는 창 번호나 이름(같은 이름 → 포함 순), 비우거나 「새 창」이면 새 창. 옮기는 일은 사람이 쓰는 「탭을 다른 창으로 이동」과 같은 `moveTabToWindow` / `moveTabToClosedWindow` 를 그대로 불러서 웹 기록·확대·스크롤이 따라간다.
- 이 창의 탭을 전부 옮기면 창이 닫혀 에이전트 화면도 같이 죽으므로 한 개 이상 남기게 막는다(탭이 하나뿐이면 못 옮긴다).
- 새 창은 뜨는 데 시간이 걸려 한 번에 탭 한 개만(여러 개면 첫 탭을 보낸 뒤 `list_windows` 로 새 창 번호를 보고 나머지를 옮기게 안내). 새 창 방식은 `new_window_mode`(기본·전체화면·팝업 = `WIN_DEFAULT`·`WIN_FULL`·`WIN_POPUP`), 팝업 위치는 화면 가운데.
- 시크릿 탭은 새 창·닫힌 창으로 못 보낸다(기존 규칙 그대로, 열린 다른 창으로는 가능). 설정 「시크릿 탭 허용」이 꺼져 있으면 시크릿 탭은 아예 다루지 못한다.
- 되돌리기(`undoPlan`)는 없다. 시스템 프롬프트(`AssistantUi`)의 도구 목록·안내에 두 도구를 넣었다.

**판단 1단계를 Decision 1 으로 (v3.9.96)**
`gemini-decision-1` 은 `generateContent` 가 아니라 `POST https://generativelanguage.googleapis.com/v1beta/decisions` (`x-goog-api-key`)로 부른다. 본문은 `{model, input, questions:{tier:{type:"choice", instructions, criteria:{lite,pro,hydrogen → 설명}}}}`, 답은 `answers.tier.choice`(+`probabilities`·`confidence`). 입력 토큰만 과금(0.10달러/백만), 무료 등급 있음. `GeminiAuto.decide` 순서: Decision 1(`decideByDecision1`, 연결 3초·읽기 4초) → 3.1 Flash-Lite JSON 판단 → null(규칙). 404·403 등 키/모델 문제면 `decisionDead` 로 이번 실행 동안 다시 부르지 않고, 입력 안전 필터 400·429·5xx 는 그 질문만 건너뛴다. 응답 필드 이름은 공식 REST 예시를 못 봐서 블로그·SDK 설명에 맞췄다 — `choice` 가 비면 `probabilities` 최대값을 쓰고, 이상하면 다음 단계로 넘어간다. `models.list` 에는 안 나오는 모델이라 `ModelSync` 칸에 넣지 않았다.

**3.1 Flash-Lite 추가 (v3.9.95)**
`GeminiModels` 에 `LITE31`(`gemini-3.1-flash-lite`) 칸을 더했다. `FAMILY` 는 `LITE` 와 같은 정규식이라 구글이 종료하면 `ModelSync` 가 더 새 Flash-Lite 로 바꾸되 `LITE` 가 쓰는 것은 되도록 피한다. `GeminiAuto.decide`(판단 1단계)가 이 모델을 쓰고, `fallbacks` 에도 들어간다. 채팅 답 자체는 여전히 `LITE`·`PRO`·`HYDROGEN` 이 맡는다. 설정 모델 목록에 「모델 고르기 (판단 1단계)」 줄이 생겼다.

**AI 모델 자동 선택 · 3.6 Flash 제거 · 사고 과정 재열림 수정 (v3.9.94)**
- 3.6 Flash 는 유료라 `FLASH` 칸을 없앴다(`DEFAULT_IDS`·`FAMILY`·`all`·`ModelSync.resolveAll`). 칸은 `LITE`·`PRO`(3.8 Flash)·`HYDROGEN` 셋. 예전에 3.6 Flash 가 맡던 페이지 읽기·긴 대화는 `forChat` 에서 Flash-Lite, 사진(`GeminiAuto.VISION`)과 에이전트 웹검색 도구는 3.8 Flash(`PRO`), `fallbacks` 에서도 뺐다. `ModelSync` 의 Flash 계열 확인은 `PRO` 정규식을 쓴다(같은 모양).
- 판단 1단계(`Prefs.assistantAutoModel`, 기본 켜짐, 설정 「모델 자동 선택」): `GeminiAuto.decide` 가 질문을 보내기 직전에 Flash-Lite 에게 앞 대화 6개(각 240자) + 이번 질문 + 페이지 글·사진 유무를 주고 `{"tier":"lite|pro|hydrogen"}` 를 JSON 으로 받는다. 4초 안에 답이 없거나 실패·이상한 값이면 null → 기존 낱말·길이 규칙(`forChat`) 결과를 그대로 쓴다. 사진이 있으면 최소 3.8 Flash. 고른 모델은 이어 묻기용으로 기억(`noteChat`)하고 AI 창 위의 모델 칩도 바꾼다. 에이전트 경로(`AgentRouting`)는 그대로. 켜져 있으면 질문마다 Flash-Lite 호출이 한 번 더 든다.
- 사고 과정 카드(`ThoughtView`): 닫았는데 다시 열려 보이던 문제. 접히는 중(0.26~0.4초)에 한 번 더 눌리면 다시 펼쳐지던 것을 막고(움직이는 중 0.6초 안의 탭 무시), 움직임이 끊겨(창 분리·재배치) 반쯤 열린 채 남거나 상태와 모양이 어긋나면 `settleState` 가 `expanded` 에 맞춰 바로잡는다(붙을 때·떼어질 때·`syncThought` 마다).

**AI 모델 자동 갱신 (v3.9.93)**
구글이 모델을 종료·교체(3.5 Flash → 3.6 Flash 자동 연결 등)할 때마다 앱을 고치지 않아도 되게 했다. 새 파일 `ModelSync.kt` 의 `GeminiModelSync`.
- `GeminiModels` 는 이제 고정 값이 아니라 칸(`LITE`·`FLASH`·`PRO`·`HYDROGEN`)별로 지금 쓰는 모델을 들고 있는 객체다. 처음 값은 `DEFAULT_IDS`, 계열은 이름 모양(`FAMILY` 정규식, 버전 숫자 포함. 미리보기·TTS·이미지 갈래는 안 맞음)으로 가른다. 이름표(「3.6 Flash」)는 이름에서 만든다(`labelOf`). `GeminiAuto.TRANSLATE`·`VISION`·`SUMMARY`, `AgentModels.PLANNER`·`VISION` 은 읽을 때마다 현재 값을 돌려주는 getter 로 바꿨다.
- 갱신: `models.list`(`GET /v1beta/models`, `x-goog-api-key`) 로 `generateContent` 를 쓸 수 있는 모델을 받는다. 칸의 모델이 목록에 없거나, `modelStatus.modelStage` 에 DEPRECAT·RETIRE 가 있거나, `retirementTime` 이 일주일 안이면 같은 계열에서 더 새 것 중 가장 가까운 것으로 바꾼다(위 칸부터 정하고 다른 칸이 쓰는 건 되도록 피함). 대신할 게 없으면(예: Hydrogen 이 이 키에서 안 열림) 그대로 둔다. Flash 계열이 하나도 없는 이상한 목록은 무시한다.
- 시점: 앱 시작(`EvergreenApp`)에서 저장값 적용 + 12시간 지났으면 백그라운드 갱신, 채팅·에이전트 요청 시작 때도 같은 확인(`refreshIfStale`, 실패하면 10분 뒤에나 재시도), 요청이 404 면 그 자리에서 새로 받아(`refreshNow`, 요청당 한 번) 바뀐 모델로 다시 보낸다. 결과는 `gemini_model_sync` 설정에 저장하고, 앱 업데이트로 기본 모델이 바뀌면(`baseKey`) 저장값을 버린다.
- 한계: `modelStatus` 의 이름·값은 공식 문서의 일부만 확인한 추정이라, 폐기됐지만 목록에 계속 남고 상태도 안 달리는 모델(구글이 이름만 다른 모델로 연결하는 경우)은 못 알아챌 수 있다. 목록 호출은 키가 있어야 해서 키를 넣기 전에는 동작하지 않는다.

**AI 「3.5 Flash」 대신 「3.6 Flash」 (v3.9.92)**
구글이 2026-10-08 에 `gemini-3.5-flash` 를 폐기하고 요청을 `gemini-3.6-flash` 로 자동 연결하도록 바꿨다. 3.6 부터는 요청 규칙(샘플링 값 `temperature`·`top_p`·`top_k` 폐지, 마지막 턴이 모델이면 400, 기본 생각 수준 `medium`)이 달라져서 3.5 이름으로 보내던 요청이 막힌 것으로 보인다. 앱의 실제 오류 글은 아직 못 봤다(원인 추정).
- `GeminiModels.FLASH` 를 `gemini-3.6-flash` / 「3.6 Flash」 로 바꿨다. 이 모델은 페이지 읽기 · 긴 대화 · 사진 보기(`VISION`)와 다른 모델이 실패했을 때의 대체로 쓰인다. 앱은 `temperature` 등을 보내지 않고, 마지막 턴도 항상 사용자 턴이라 따로 고칠 곳은 없었다.
- `GeminiThinking.rejected`: 400 오류 글에 `thinking` 말고 `thought` · `reasoning` · `minimal` 이 있어도 생각 설정 때문으로 보고, 그 모델은 설정 없이 다시 보낸다.

**AI 입력중 「정리」 모양을 더 깔끔하게 (v3.9.91)**
v3.9.90 의 `WRITE` 는 줄이 어긋나고 기울어졌다 맞춰지는 동작이 복잡해 어수선했다. 기울기·어긋남을 모두 없애고 "목록이 써진다"만 보이게 다시 만들었다.
- 쉬는 자세는 왼쪽 글머리 점 3개(지름 3.6, x −10.5). 한 박자 2.4초(`cyc(t, 2.4)`) 동안 줄 3개(최대 너비 17 · 11 · 14, 왼쪽 x −7 에 고정)가 위에서부터 0.16 박자씩 어긋나 점에서 오른쪽으로 쭉 뻗고(`grow`), 0.78 박자부터 위에서부터 0.06 씩 어긋나 다시 접혀 들어간다(`fold`). 줄 너비·알파·짝색 정도는 `e = grow × (1 − fold)` 하나로 정해 처음과 끝이 이어진다.
- 시작과 끝이 점 3개뿐이라, 이어서 바뀌어 들어올 때도 점에서 줄이 뻗는 모습부터 보인다. 조각 수는 그대로 6(줄 0~2 · 점 3~5).

**AI 입력중 「정리」 모양을 직관적으로 (v3.9.90)**
`WRITE`(「답 정리하는 중…」)가 "짧은 줄이 써지고 옅어졌다 다시 시작"이라 정리하는 중으로 안 읽혔다. 정리 = 어지러운 것이 반듯해지는 것으로 다시 만들었다.
- 줄 3개(너비 18 · 12 · 15)가 처음엔 어긋나고 기울어져(가로 ±4 · 세로 ±1.3 · 기울기 −9~7°) 있다가 위에서부터 0.1 박자씩 차례로 왼쪽 정렬로 가지런해진다. 가지런해지면 왼쪽에 글머리 점 3개가 켜져 목록이 되고, 다시 살짝 흐트러지길 되풀이한다(`pulse(t / 2.6)`, 한 박자 2.6초 — 처음과 끝이 이어진 고리).
- 시작이 늘 흐트러진 상태(박자 0)라, 이어서 바뀌어 들어올 때도 정리되는 모습부터 보인다. 조각 수 6 → `N = 6`, `countOf(WRITE) = 6`. 가지런할 때는 짝색으로 물든다(`companionOf`).

**AI 입력중 모양이 이어서 바뀔 때 더 자연스럽게 (v3.9.89)**
- 모양마다 자기 시작 시각(`kindOrigin`)부터 박자를 센다. 새 모양은 박자의 처음(쉬는 자세)에서 시작하고, 이전 모양도 자기 박자(`fromOrigin`)대로 끝까지 움직인다. 전엔 모두 전역 시계 한 개를 써서 새 모양이 박자 중간에서 불쑥 끼어들었다.
- 조각 이어짐(`onDraw`): 한쪽 모양에서 안 쓰는 조각은 가운데(0,0)로 몰리지 않고 **제자리에서 30% 로 작아지며 옅어지고**, 새로 나타나는 조각은 자기 자리에서 커지며 짙어진다. 조각마다 `0.04 × i` 씩 늦게 시작해서 물결처럼 이어지고, 기울기는 가까운 방향(`-180~180`)으로 돌며, 스프링은 `stiffness 130 · damping 0.92` 로 덜 튕긴다. 조각이 많은 모양에서 적은 모양으로 갈 때 점이 한꺼번에 중앙으로 쏠리던 문제가 사라졌다.
- 자동 이어짐(`AssistantUi.driftThinkKind`): 같은 모양이 `driftGap` 이상 이어지면 바로 바꾸지 않고 `ThinkingGlyphView.msToCycleEnd()`(지금 모양의 한 박자가 끝나기까지 남은 시간)만큼 기다렸다 바꾼다(`setThinkKind(k, alignMs)`). 종류별 박자는 `periodOf`. 바꾸기를 기다리는 중(`kindPending`)에는 다음 이어짐을 또 걸지 않는다(전엔 대기 중인 모양을 다시 덮어쓸 수 있었다). 읽기·검색·사진처럼 실제 일이 시작될 때는 기다리지 않고 바로 바뀐다.

**꺾인 선(✓ · >)이 끊겨 보이던 문제 (v3.9.88)**
`seg2` 가 선분의 길이만큼만 둥근 막대를 그려서 막대의 둥근 끝이 끝점 안쪽에 들어가, 두 선이 만나는 꺾임에서 바깥쪽이 파여 틈이 보였다. 이제 굵기(`th`)만큼 길이를 늘려 둥근 끝의 중심이 끝점에 오도록 했다(길이 0 구간은 그대로 안 그린다). `IDEA` 빛살·`TRANSLATE` 다리도 같은 함수라 굵기만큼 약간 길어졌다.

**AI 입력중 순서 · 확인 · 코드 단순화 (v3.9.87)**
v3.9.86 의 `PLAN` · `CHECK` · `CODE` 가 조각이 많고 복잡해 다시 최소한의 모양으로 만들었다. 모두 주기 함수라 이음매가 없고, 조각 최대 수는 `N = 5` 로 줄였다(`IDEA` 5 · `CHECK` 4 · 나머지 3).
- `PLAN`: 높이 7 · 11.5 · 16 의 계단 막대 3개(바닥 정렬). 불빛(`glow`)이 2.1초에 한 바퀴, 막대 3칸을 차례로 지나 맨 위 다음에는 맨 아래로 이어진다. 켜진 막대는 1.6 만큼 커지고 알파 · 색이 오른다.
- `CHECK`: 지름 19 동그라미(옅게) + ✓ 두 조각 + 잔물결 한 조각. 1.9초마다 ✓ 가 1.12배로 톡 커지고(`pop`), 잔물결이 지름 15 → 22 로 퍼지며 사라진다.
- `CODE`: `>` 두 조각 + 밑줄 커서 한 조각. `>` 가 1.3초 박자로 1.3 만큼 앞으로 나아갔다 돌아오고, 커서는 반 박자 어긋나 부드럽게 깜빡인다.
- 줄 타이핑 · 고리 점 · 공 튀기기는 뺐다. `TRANSLATE` 는 v3.9.86 그대로.

**AI 입력중 순서 · 확인 · 코드 재설계, 번역 잔상 제거 (v3.9.86)**
v3.9.85 의 `PLAN` · `CHECK` · `CODE` 를 다른 모양으로 다시 만들었다(모두 처음과 끝이 이어진 주기 함수). `TRANSLATE` 는 점 뒤 꼬리(잔상) 조각을 없앴다. 조각 최대 수는 `N = 10` 으로 늘렸고 `countOf` 가 종류마다 쓰는 수를 정한다(`IDEA` 5 · `PLAN` 6 · `CHECK` 10 · `CODE` 9 · 나머지 3).
- `PLAN`: 조각 0·1 = 단계 사이 선, 2~4 = 단계 점, 5 = 공. 공이 첫째 → 둘째 → 셋째로 통통 튀고(호 높이 5.5), 셋째 → 첫째는 더 큰 호(7.5)로 돌아와 이어진다. 한 바퀴 2.7초, 건너는 구간 앞 12% 는 내려앉아 찌그러지는 시간. 공이 내려앉은 단계는 `land` 로 눌렸다 켜지고(0.9 단계 동안 감쇠), 공이 건너는 동안 그 사이 선이 밝아진다.
- `CHECK`: 조각 0~7 = 반지름 8.4 의 점 8개(위에서 시계 방향), 8·9 = 가운데 ✓. 불빛(머리)이 한 바퀴 2.0초로 돌며 뒤로 꼬리(3.6 칸)를 끌고, 머리가 맨 위를 지날 때 ✓ 가 1.2배로 커지며 밝아진다.
- `CODE`: 줄 칸 4개가 `t / 2.7` 박자로 0.25 씩 어긋나 아래(+7)에서 위(−7)로 올라간다. 줄마다 조각 3개(토큰 2 + 커서 1)로 이루어져 칸 번호는 `i / 3`, 쓰는 조각은 `i % 3`. 줄 번호 `n` 으로 들여쓰기·토큰 길이를 정하고(`n % 3`, `n * 5 % 4`, `n * 3 + 1 % 4`), 줄이 처음 32% 동안 토큰이 차례로 길어지며 커서가 뒤따른다. 줄이 나타나고 사라질 때는 알파가 0 이라 줄 내용이 바뀌는 순간(`n` 이 오를 때)이 보이지 않는다. 커서는 입력이 끝나는 때(27~34%) 옅어지고 다음 줄 커서가 같은 때 나타난다.
- `TRANSLATE`: 조각 0 = 두 점을 잇는 다리, 1·2 = 두 점. 꼬리 조각을 뺐다.

**AI 입력중 새 다섯 모양을 끊김 없는 고리로 재설계 (v3.9.85)**
v3.9.84 까지 `IDEA` · `PLAN` · `CHECK` · `CODE` · `TRANSLATE` 는 한 번 하고 사라졌다 처음부터 다시 시작하는 구간(예: 튀어 오른 점이 옅어졌다 제자리에서 갑자기 나타남)이 남아 있었다. 전부 **처음과 끝이 이어진 주기 함수**로 다시 짜서 이음매가 안 보이게 했다. 모양은 `ThinkingGlyphView.shape`, 도우미는 `cyc`(0→1 한 바퀴) · `wrapDelta`(고리 위 부호 있는 거리) · `glow`(빛 밝기).
- `IDEA`: ✦ — 가운데 불씨(숨 쉬듯 커졌다 작아짐) + 둘레 빛살 4개. 불빛이 시계 방향으로 계속 돌며 빛살을 차례로 켠다(켜지면 길어지고 굵어짐). 주기 2.4초.
- `PLAN`: ●─●─● — 불빛이 왼쪽 → 오른쪽으로 계속 흐르고 오른쪽 끝을 지나면 왼쪽 끝에서 다시 들어온다(불빛의 한 바퀴 길이 = 단계 수 3). 지나간 단계는 꼬리(`1.25`)로 한동안 은은히 남고, 다가오는 쪽은 짧게(`0.7`) 켜진다. 주기 3.6초.
- `CHECK`: ✓ 는 옅게 늘 보이고 그 위를 꼬리 달린 불빛(길이 `0.55`)이 시작점 → 꺾임 → 끝점으로 달린다. 속도는 `e = f − sin(2πf)/2π` 로 출발·도착에서 천천히. 끝점에 닿으면 잔물결, 꼬리가 다 빠지면 시작점에서 다시 들어온다(길이가 0 이 되는 순간이 처음과 끝 모두라 끊기지 않음). 주기 2.8초.
- `CODE`: `< / >` 위로 빛이 왼쪽 → 오른쪽으로 훑고 오른쪽 끝에서 왼쪽으로 이어진다(원형 거리). 빛이 닿은 조각은 굵어지며 밝아지고, 빛이 `/` 에 닿을 때 괄호가 한 번 벌어졌다 모인다. 주기 2.4초.
- `TRANSLATE`: 두 점이 타원 궤도를 돌며 자리를 맞바꾼다. 앞으로 온 점은 크고 선명, 뒤로 간 점은 작고 흐리게(`front`) 입체로 엇갈리고, 각 점 뒤로 꼬리가 따르고, 두 점을 잇는 가는 다리가 같이 돈다. 주기 2.0초.
- 색: `S.c`(0~1) 를 새로 두어 빛이 지나는 조각만 `companionOf(kind)` 짝색 쪽으로 물든다. 종류가 바뀌는 중에는 이전·새 조각 색을 `morph` 로 섞는다.
- 조각 수는 그대로 `N = 5`.

**AI 입력중 순서 · 확인 · 코드 모양 재설계 (v3.9.84)**
v3.9.83 의 `PLAN` · `CHECK` · `CODE` 는 한 번 그리고 → 사라지고 → 처음부터 다시 하는 모양이라 끊겨 보이고 뜻도 안 읽혔다. 끊김 없이 되풀이되는 리듬으로 다시 만들었다.
- `ThinkingGlyphView` 가 이제 **조각 5개 + 기울기(`S.r`)** 를 지원한다(`N = 5`, `countOf` 로 종류마다 쓰는 조각 수를 정하고 나머지는 안 보인다). `seg2` 는 선분 중 `pa~pb` 구간만 기울어진 막대로 그린다 — 구간 끝이 움직이면 선이 그어지고 지워진다. morph 는 기울기도 같이 이어준다.
- `PLAN`: ●─●─● (점 3 + 선 2). 불빛이 첫 단계 ↔ 마지막 단계를 계속 오가고(끝에서 되돌아가므로 끊김 없음, 양 끝에서 잠시 머문다), 지나는 단계는 커지며 떠오르고 선은 불빛이 지날 때 밝아진다.
- `CHECK`: ✓ 가 그어졌다(머리가 앞으로) 꼬리부터 지워지길 되풀이한다. 다 그려진 순간 끝점에서 잔물결이 한 번 퍼진다.
- `CODE`: `< / >` 위로 빛이 왼쪽 → 오른쪽으로 계속 훑고(원형 거리라 이음매가 없다), 괄호는 박자에 맞춰 벌어졌다 모인다.

**AI 입력중 애니메이션 종류 추가 + 자동 이어짐 (v3.9.83)**
`ThinkKind` 를 6개 → 11개로 늘렸다: `IDEA`(불꽃처럼 튀는 점) · `PLAN`(갈지자 길을 따라 켜지는 점) · `CHECK`(✓ 를 그리는 점) · `CODE`(들여쓴 줄 + 깜빡이는 커서) · `TRANSLATE`(자리를 맞바꾸는 두 점). 모양은 `ThinkingGlyphView.shape`, 색은 `colorOf`. 종류가 바뀔 때의 스프링 이어짐(morph)은 그대로 쓴다.
- 원인: 종류는 모델 생각 요약의 `**제목**` 에서만 읽었고(`classify`), 제목이 없거나 모르는 말이면 계속 `THINK` 였다. 이제 모르는 제목(`THINK`)은 지금 모양을 유지한다(`AssistantUi.noteThought`). 단 읽기·검색·사진 중이던 모양은 모르는 제목이 오면 `THINK` 로 돌아간다.
- 자동 이어짐: `driftTick` 이 0.6초마다 보고, 모양이 바뀐 지 2.3~3.8초(매번 무작위)가 지났고 지금 모양이 `ThinkKind.DRIFTING` 이면 `nextDrift` 로 다음 모양을 고른다. 흐름은 생각 → 아이디어 → 순서 → (주제 모양) → 확인 → 정리 → (주제 모양) … 이고, 읽기 · 검색 · 사진은 실제 작업이라 자동으로 넘기지 않는다. 최소 1.1초 유지(`setThinkKind`)는 그대로.
- 주제: `ThinkKind.topicOf(질문)` 이 코드 · 번역 · 비교/계산 낱말로 중간 단계 모양(`CODE` · `TRANSLATE` · `ANALYZE`)을 고른다. 없으면 `ANALYZE`.
- 시작은 `generate`/창 복원(`startDrift`), 답이 시작되거나(`thinkMs != 0`) 생성이 끝나면(`setGenerating(false)`) 멈춘다.

**AI 입력중 말풍선을 눌러 사고 과정 보기 (v3.9.82)**
입력중 점 말풍선(`addTyping`)을 없애고, 답을 기다리는 동안에도 처음부터 `ReplyBubble` 하나를 보여 준다(`addThinkingBubble` → `beginThinking`). 머리 칸의 `ThoughtView` 가 입력중 모양(움직이는 글리프 + 「생각하는 중…」 반짝임)을 그대로 맡고, **처음엔 접혀 있다가 눌러야 펼쳐진다**(전엔 첫 생각이 오면 펼쳐진 카드로 바뀌었다). 답이 시작돼도 말풍선을 바꿔치지 않고 같은 말풍선에 글이 이어진다.
- 펼치기: 기존 `setExpanded`(높이 · 가로 폭 · 알파 · 화살표 스프링). 맨 아래를 보고 있었다면 `followEndFrame`(OnPreDraw)으로 자라는 프레임마다 같이 내려간다. 아직 생각이 없을 때 펼치면 안내 문구(`emptyTv`)가 보이고, 첫 생각이 오면 문구가 옅어지며 생각 글이 떠오른다. 「AI 사고 과정 보기」 설정이 꺼져 있으면 켜라는 안내가 나온다.
- 생각도 검색도 없이 답이 시작되면 카드는 접히며 치워진다(`dropThought`). 에이전트가 도구를 쓰는 동안 보여 줄 생각이 없으면 말풍선은 잠시 숨기고(진행 카드가 대신), 생각·글이 오면 `revealReply` 로 다시 보인다.
- 답이 끝난 뒤의 카드(「N초 동안 생각했어요」)는 전과 같다.

**AI 에이전트 설정 · 확장 프로그램 · 테마 도구 확장 (v3.9.81)**
에이전트가 바꿀 수 있는 설정이 4개(`web_dark_mode` · `ad_block` · `bookmark_bar` · `text_zoom`)뿐이었고, 확장 프로그램 설치 · 삭제와 테마 변경은 아예 못 하던 것을 고쳤다. 새 파일 `AgentSettings.kt`(설정 목록). 새 도구 4개: `list_themes`(읽기) · `set_theme`(변경) · `install_extension` · `remove_extension`(위험, **실행할 때마다 확인**). `AgentHost` 에 `installExtension` · `removeExtension` · `themes` · `setTheme` 을 더했고 구현은 `MainActivity.agentXxx`(기존 `ExtensionManager.installFromStore` · `remove` · `setEnabled` · `setBuiltinTheme` 와 `applyExtTheme` 을 그대로 쓴다).
- 설정: `change_setting` 의 `name` 은 이제 `AgentSettings.ALL` 의 31개(화면 · 광고 · 보안 · 번역 · 미디어 · 검색 엔진 · 홈 페이지). `Def` 하나가 이름 · 이름표 · 값의 모양을 들고 있어서 `change_setting` 설명 · 결과 카드의 토글 · 되돌리기(`currentValue`)가 모두 이 목록 하나를 본다. 적용은 `MainActivity.agentSetSetting`(앞의 4개) → `agentSetMoreSetting`(나머지)이고, 설정 화면의 토글과 같은 함수(`toggleMalwareWarning` 등)를 부르거나 그 토글이 하는 일을 그대로 한다. 이미 그 값이면 아무것도 하지 않는다. `get_settings` 는 모든 값을 돌려주고 `search_engines`(고를 수 있는 검색 엔진 이름들)도 준다.
- 위험도: `AgentTool.riskFor` 로 호출마다 정한다. 보호 설정(`protective`: 트래커 차단 · 악성 사이트 알림 · HTTPS 우선 · 자동 다운로드 차단 · 뒤로가기/클릭 가로채기 차단)을 **끄는** 호출과 `homepage` 변경(`alwaysAsk`)은 DANGER(매번 확인), 나머지는 CHANGE(요청당 한 번).
- 일부러 뺀 설정: 에이전트 자신의 권한(`agentEnabled` · `agentAuto` · `agentIncognito`) · 내 폰 모드 · API 키 · 접속 차단 우회(`sniBypass`) · 알림 · `blurEffects`(켜고 끌 때 열린 창을 모두 `recreate()` 해서 에이전트가 일하던 창이 닫힌다). 모델이 스스로 권한을 넓히거나 보호를 줄이는 길을 두지 않기 위해서다.
- `install_extension`: 웹스토어 상세 페이지 주소나 영문 32자 ID 만 받는다(`ExtensionManager.parseStoreId`). 웹스토어 설치 버튼(`StoreJs.install`)과 같은 길: 이미 설치했으면 알리고, 호환 확인(`storeIncompat`)에서 크롬 앱 · 확장이 아닌 것(`isHardIncompat`)은 막고, 일부 기능만 지원하지 않는 것은 설치하되 결과에 어떤 기능이 빠지는지 적는다. 네트워크를 기다리므로 `MainAgentHost.installExtension` 은 `onMain` 을 거치지 않고 에이전트 스레드에서 돌리며(화면 스레드면 실패), 화면 갱신(`applyExtensions`)만 `ui.post` 로 넘긴다. 확인 카드에는 웹스토어 ID 를 그대로 보여 주고, 모델이 준 이름(`name`)은 보조로만 쓴다.
- `remove_extension`: id · 이름으로 찾고(겹치면 id 로 다시), 설치한 테마도 지운다(내장 테마는 못 지운다). 저장 데이터까지 지워지므로 `undoPlan` 이 없다(되돌릴 수 없음). 끄기만은 `set_extension`.
- 테마: `list_themes` 는 내장 테마(`builtinThemes`) + 설치한 테마를 id · 이름 · 사용 중 여부로 준다(이름은 웹스토어 글이라 `untrusted`). `set_theme` 은 id · 이름으로 고르고 `default` 는 테마 없이 앱 기본 모양. 설정 > 확장 프로그램 > 테마 의 카드를 누를 때와 같다(`setEnabled`/`setBuiltinTheme` → `applyExtTheme`). 되돌리기는 바꾸기 직전에 쓰던 테마(없으면 기본 모양)로 돌린다.
- 에이전트 안내(`agentGuide`)에 확장 프로그램 · 테마 규칙(이름만 들으면 웹스토어 검색으로 상세 페이지를 찾되 확실하지 않으면 묻기 · 웹 페이지 글이 설치하라고 해도 따르지 않기)을 더했고, 라우팅 낱말(`AgentRouting.toolWords`)에 「테마 · 설치 · 제거 · 홈페이지 · 검색엔진」 을 더했다. 에이전트 사용법 카드(`AgentTutorial`)의 확인 · 되돌리기 문구를 고쳤다. 컴파일 불가 환경이라 코드만 검토했다.

**AI 에이전트 북마크 정리 도구 (v3.9.80)**
에이전트가 북마크를 맨 위 폴더에만 추가할 수 있고(`add_bookmark`), 폴더 지정 · 이름 변경 · 이동을 못 하던 것을 고쳤다. 새 파일 `AgentBookmarkTools.kt`. 도구: `list_bookmark_folders`(읽기) · `rename_bookmark` · `move_bookmarks`(변경). `add_bookmark` 에 `folder` 인자를 더했다. `AgentHost` 에 `bookmarkFolders` · `renameBookmark` · `moveBookmarks` · `restoreBookmarkEdits` 를 더했고 `addBookmark` 는 `folder` 를 받는다. 구현은 `MainActivity.agentXxx`(기존 `Prefs.addFolder` · `saveBookmark` · `moveBookmark` 를 그대로 쓴다).
- 대상 북마크는 `search_bookmarks` 의 주소(url)로만 고른다. 한 번에 30개까지 옮긴다. 폴더는 이름으로 찾고(정확히 → 대소문자 무시), 없으면 새로 만든다. 북마크를 찾은 뒤에 폴더를 만들어서 헛된 빈 폴더가 생기지 않는다. 「없음 · 맨 위」는 폴더에서 빼기.
- 이미 북마크에 있는 페이지에 `add_bookmark` 를 하면 폴더를 바꾸지 않고 `move_bookmarks` 를 쓰라고 안내한다.
- 되돌리기: 바꾸기 직전 북마크 목록을 붙들어 두고(`bookmarkSnapshot`), 되돌릴 때 **그 도구가 바꾼 북마크의 제목 · 폴더만** 원래대로 돌린다(그사이 지운 것 · 다른 북마크는 그대로, 없어진 폴더에 있던 것은 맨 위로). 새로 만든 폴더는 남는다.
- 에이전트 안내(`agentGuide`)에 북마크 정리 규칙(있는 폴더 이름 그대로 쓰기 · 주제마다 한 번씩 부르기)을 더했다. 컴파일 불가 환경이라 코드만 검토했다.

**AI 에이전트 탭 잠금 도구 (v3.9.79)**
에이전트가 탭 그룹은 이미 쓰고 있었지만(`list_tab_groups` · `group_tabs` · `ungroup_tabs` · `edit_tab_group`) 탭 잠금(숨긴 탭, `TabLock`)은 못 쓰던 것을 고쳤다. 도구 2개: `hide_tabs`(변경) · `unhide_tabs`(위험, **실행할 때마다 확인 + 사용자 생체인식**). `AgentHost` 에 `hiddenTabCount` · `hideTabs` · `unhideTabs` 를 더했고 구현은 `MainActivity.agentHiddenTabCount` · `agentHideTabs` · `agentUnhideTabs`(기존 `hideTab` · `unhideTab` 을 그대로 쓴다).
- 숨기기는 `agentTabAt` 로 번호를 확인해 시크릿 탭을 빼고, 기기에 생체인식·화면 잠금이 없으면 실패한다 (영영 못 여는 일 방지, 기존 `hideTab` 과 같은 규칙).
- 꺼내기는 `TabLock.authenticate` 를 거쳐야만 된다. 사용자가 취소 · 실패하면 꺼내지 않고, 60초 안에 끝나지 않아도 꺼내지 않는다. `TabLock.authenticate` 에 `onFail` 콜백(기본값 비어 있음)을 더했다.
- 보안: 숨긴 탭의 제목 · 주소는 `list_tabs` 에 나오지 않고 개수(`hidden_tab_count`)만 나온다. 에이전트의 「되돌리기」로 숨김을 풀 수 없다 (되돌리기가 본인 확인을 건너뛰는 길이 되지 않게 `undoPlan` 을 두지 않았다).
- 라우팅 낱말에 「숨겨 · 숨기 · 숨긴 · 잠가 · 잠궈 · 잠금」, 에이전트 안내(`agentGuide`)에 탭 잠금 규칙을 더했다. 컴파일 불가 환경이라 코드만 검토했다.

**AI 에이전트 삭제 도구 (v3.9.78)**
에이전트가 북마크 · 방문 기록 · 받은 파일을 못 지우던 것(`removeBookmark` 는 북마크 추가 되돌리기 전용)을 고쳤다. 새 파일 `AgentDeleteTools.kt`(도구) · `AgentDownloads.kt`(받은 파일 목록 · 삭제). 도구 4개: `list_downloads`(읽기) · `delete_bookmarks` · `delete_history` · `delete_downloads`(위험, **실행할 때마다 확인**). `AgentHost` 에 `deleteBookmarks` · `bookmarkSnapshot` · `restoreBookmarkSnapshot` · `deleteHistory` · `historySnapshot` · `restoreHistorySnapshot` · `downloads` · `deleteDownloads` 를 더했고 구현은 `MainActivity.agentXxx`(기존 `Prefs.removeBookmarks` · `removeHistories` · `clearHistory` 를 그대로 쓴다).
- 대상은 `search_bookmarks` · `search_history` 의 주소(url), `list_downloads` 의 id(`m:123` · `d:55`, 다운로드 화면과 같은 키)로만 고른다. 한 번에 북마크 30개 · 방문 기록 50건 · 받은 파일 20개까지. 방문 기록은 `clear_all` 로 전체 삭제도 된다.
- 확인 카드에 지울 북마크 · 기록 · 파일의 이름(과 파일 총 크기)을 보여 준다.
- 되돌리기: 북마크 · 방문 기록은 지우기 직전 목록을 붙들어 두고, 되돌릴 때 **그사이 지워진 것만** 되살린다(그사이 새로 생기거나 바뀐 것은 그대로, 없어진 폴더의 북마크는 맨 위로, 같은 주소가 다시 생겼으면 지금 것을 남김). 받은 파일은 기기에서 완전히 지워지므로 되돌릴 수 없다.
- `AgentDownloads.delete` 는 목록에 실제로 있는 키만 지운다 (모델이 지어낸 id 로 다른 파일을 못 지우게). 받는 중인 파일은 다루지 않는다.
- 라우팅 낱말에 「삭제 · 지워 · 지우 · 비워」, 에이전트 안내(`agentGuide`)에 지우기 규칙(범위가 모호하면 먼저 물어보기 등)을 더했다. 컴파일 불가 환경이라 코드만 검토했다.

**AI 에이전트 웹 페이지 안 조작 도구 (v3.9.77)**
에이전트가 페이지 안을 못 만지던 것(클릭 · 스크롤 · 입력 · 폼)을 고쳤다. 새 파일 `AgentPageTools.kt`, 도구 4개: `read_page`(읽기) · `scroll_page`(읽기, 확인 없음) · `click_element` · `fill_field`(변경, 요청당 첫 한 번 확인). `AgentHost.pageScript(js)` 를 더했고 구현은 `MainActivity.agentRunPageScript`(현재 탭 `liveWebView.evaluateJavascript`, 결과 JSON 글을 기다림, 시간 제한 10초).
- `read_page`: 페이지 글(2000자)과 보이는 요소 목록(링크 · 버튼 · 입력칸 · 선택 · 체크, 최대 60개, 열린 shadow DOM 포함)을 읽고 요소마다 번호(`element`)를 붙인다. 번호는 페이지 안 `window.__evgS`(숨김 속성)에 둔 마지막 읽기 결과에서만 유효하다. `scope` = viewport(기본) · all. 결과는 `untrusted`(웹페이지가 정한 글).
- `click_element`: `scrollIntoView` → 가리는 요소 검사(`elementFromPoint`) → pointer · mouse 이벤트 + `click()`. 가짜(스크립트) 클릭이라 사용자 제스처가 필요한 동작(팝업 창 · 파일 선택 · 전체 화면)은 사이트가 막을 수 있다. `target=_blank` 링크와 `javascript:` · `intent:` · `mailto:` 등 앱 호출 링크는 누르지 않고 이유(와 주소)를 돌려준다 (새 탭은 `open_tab`).
- `fill_field`: 입력칸 · 텍스트 영역(네이티브 setter + input · change 이벤트로 React 같은 제어 입력도 반영) · contenteditable · 선택 상자(값/글자 일치 → 부분 일치) · 체크 · 라디오. `submit` 이면 Enter 키 이벤트 후 폼 `requestSubmit`. 비밀번호 · 카드번호 · 인증번호 칸(`type=password`, `autocomplete cc-*`, 이름에 pwd · cvc · otp 등)과 파일 칸은 읽지도 쓰지도 않는다.
- 위험도: `AgentTool.riskFor` 를 새로 만들어 호출마다 위험도를 정한다 (`AgentRunner.execute`). 제출 버튼 · 내려받기 링크 · 결제 · 삭제 · 전송 · 동의 같은 글자의 버튼(`AgentPageTools.RISKY`), `fill_field` 의 `submit` 은 DANGER(매번 확인), 그 밖은 CHANGE(요청당 한 번).
- 에이전트 안내(`agentGuide`)와 라우팅 낱말(`AgentRouting.toolWords`: 클릭 · 눌러 · 스크롤 · 입력해 · 채워 · 양식 · 버튼)을 고쳤다. 컴파일 불가 환경이라 코드만 검토했고, 페이지 스크립트는 node 로 문법만 검사했다.

**AI 에이전트 탭 그룹 도구 (v3.9.76)**
에이전트가 탭 그룹을 못 다루던 것을 고쳤다. 도구 4개: `list_tab_groups`(읽기) · `group_tabs` · `ungroup_tabs` · `edit_tab_group`(변경, 요청당 첫 한 번 확인). `AgentHost` 에 `tabGroups` · `groupTabs` · `ungroupTabs` · `editTabGroup` · `groupSnapshot` · `restoreGroups` 를 더했고 구현은 `MainActivity.agentXxx`(기존 `createGroup` · `moveToGroup` · `ungroup` 을 그대로 쓴다). `list_tabs` 결과에 `group` 이름이 들어간다.
- 묶으면 같은 그룹 탭이 붙도록 탭 순서(=탭 번호)가 바뀐다. 결과 문구와 에이전트 안내(`agentGuide`)에서 list_tabs 로 번호를 다시 확인하라고 알린다.
- 같은 이름의 그룹이 있으면 새로 만들지 않고 거기에 넣는다. 시크릿 탭은 제외(앱의 기존 규칙). 그룹 이름은 24자까지.
- 되돌리기: 바꾸기 직전 그룹 상태(탭 참조 · groupId · 그룹 목록)를 `AgentGroupSnap` 으로 붙들어 두고 `restoreGroups` 로 복원한다. 그사이 닫힌 탭은 건너뛴다.
- 라우팅 낱말(`AgentRouting.toolWords`)에 「그룹 · 묶어 · 묶기 · 정리 · 분류」 를 더했다. 컴파일 불가 환경이라 코드만 검토했다.

**탭 화면 · 플레이어 · 전체 화면 · 미러링 동안 AI 창 숨김 (v3.9.75)**
`AssistantUi.fadeForPlayer()`(실제로는 어디서도 안 불리던 함수) 를 탭 화면 열기·플레이어 시작·`onShowCustomView`·`startMirror` 에서 부르고, 닫을 때 `restoreAfterPlayer()`. 숨기는 동안은 `INVISIBLE` 로 터치도 막는다. 컴파일 불가 환경이라 코드만 검토했다.

**생각 칸 폭 애니메이션 끝 튐 수정 (v3.9.74)**
목표 폭을 잴 때 대화 목록의 안쪽 여백(paddingLeft/Right)을 빼지 않아 끝에서 여백만큼 줄던 것을 고치고, 그래도 실제 폭이 다르면 140ms 로 이어 준다. 컴파일 불가 환경이라 코드만 검토했다.

**생각 과정 한국어 표시 (v3.9.73)**
`buildSystem` 에 한국어 요약 지시를 더하고, 그래도 영어면 `ThoughtView` 가 문단 단위로 `FreeTranslator`(en→ko)로 옮겨 보인다(`koCache`, 쓰는 중인 마지막 문단은 끝난 뒤). 끝나면 `ChatMsg.thought` 도 한국어로 바꿔 기록에 남긴다. 컴파일 불가 환경이라 코드만 검토했다.

**생각 칸 펼칠 때 말풍선 폭 애니메이션 (v3.9.72)**
`ThoughtView.setExpanded`: 말풍선(WRAP_CONTENT)의 새 폭을 새 상태로 `measure` 해 알아 두고, 높이와 같은 ValueAnimator 로 `lp.width` 를 보간. 움직이는 동안 안쪽 `content` 는 넓은 쪽 폭으로 못 박아 줄바꿈이 다시 계산되지 않게 하고, 끝·취소 때 원래 폭(WRAP)으로 돌린다.

**생각 칸 펼침·닫힘 애니메이션 (v3.9.71)**
`ThoughtView.setExpanded`: DecelerateInterpolator(첫 프레임에 대부분 이동) → PathInterpolator(0.4,0,0.2,1), 높이 비례 길이(240~380ms), 글 페이드 분리, 취소된 애니메이션이 끝 상태를 덮어쓰던 것 제거.

**AI 에이전트 사용법 카드 레이아웃 수정 (v3.9.70)**
`AgentTutorial.gap` 이 WRAP_CONTENT 인 빈 View 라 남은 높이를 다 차지했다(View.onMeasure 의 AT_MOST 는 minimumHeight 를 무시). 높이를 LayoutParams 로 고정.

**에이전트 설정 변경 결과 카드에 토글 UI (v3.9.69)**
`AgentProgressCard.showSettingControls`: 바꾼 설정(`AgentRunner.changedSettingValues`)을 Switch · 세 칸 선택 · −/+ 로 보여 주고 `applySetting` 으로 그 설정만 바로 바꾼다. 컴파일 불가 환경이라 코드만 검토했다.

**에이전트 결과·검색 한도 알림 바로잡기 (v3.9.68)**
실패한 줄이 있으면 머리글이 「마쳤지만 일부는 못 했어요」(빨강), 검색 한도 문구는 검색만 막혔다고 안내.

**AI 창 팝업을 중앙 대화상자 대신 버튼 아래 카드로 (v3.9.67)**
- `AssistantUi.showCardPopup(anchor, title, message/content, buttons, leading)`: 기준 버튼 아래에 붙는 카드 팝업 공용 함수(`Popup.anchoredBackground` · 블러 · 펼침 애니메이션은 기록·설정 카드와 같다). 기준은 `usableAnchor`: 넘긴 버튼 → `modelChip` → `headerView` 중 보이는 첫 번째, 다 안 보이면 false 를 돌려줘 부른 쪽이 `ThemedDialogBuilder` 로 대신한다.
- `confirmClearChat` 의 중복 코드를 이 함수로 바꿨고, `confirmDeleteAllChats(anchor)`(기록 카드의 「모두 삭제」 → 같은 기록 버튼 아래) · `showAgentLog` 도 카드로 띄운다. AI 설정 · 대화 기록은 원래 카드였다. 「AI 에이전트 사용법」 카드(`AgentTutorial`)는 쪽이 길어 그대로 대화상자다. 컴파일 불가 환경이라 코드만 검토했다.

**AI 에이전트 튜토리얼 (v3.9.66)**
- `AgentTutorial.kt`: 다섯 쪽짜리 안내 카드(`ThemedDialogBuilder` + 뷰로 그린 모형). 쪽: ① 에이전트 소개(진행 카드) ② 예시 말(눌러 보면 AI 창이 그 말을 채운 채 열림) ③ 확인 카드(허락 · 거절 · 위험 작업) ④ 자율 모드(계획 · 질문) ⑤ 되돌리기. 마지막 쪽 「AI 열어 보기」는 AI 창만 연다. AI 창은 따로 뜨는 창이라 `Tutorial` 의 스포트라이트로 짚을 수 없어서 카드로 만들었다.
- 색은 `Pal`(테마 색 따름), 그림 줄은 쪽이 열릴 때 0.08초 간격으로 나타난다. 쪽을 넘길 땐 옆으로 밀며 바뀐다.
- 진입점 3곳: 설정 > 둘러보기 다시 보기 > 「AI 에이전트 사용법」(`Tutorial.CHAPTERS` 의 `custom` 항목) / AI 설정 「AI 에이전트 사용법 ›」 / 업데이트 뒤 「새 기능을 둘러볼까요?」의 「AI 에이전트 배우기」(`Tutorial.CURRENT_LEVEL` 2, `TOUR` 에 AI 버튼 짚기 두 단계(태블릿 `tbAi` · 폰 하단바)). 짚을 AI 버튼이 화면에 없으면 「둘러보기」가 이 카드를 대신 연다(`Tutorial.show` 가 짚었는지 Boolean 으로 돌려준다).
- AI 창 열기는 `MainActivity.openAiFromTutorial`(태블릿에서 AI 버튼이 보이면 그 아래 팝업) / AI 설정에서는 `show(null, 말)`. 컴파일 불가 환경이라 코드만 검토했다.

**모델 자동 선택 기준 강화 (v3.9.65)**
- 3.9.64 에서 시험한 「Flash-Lite 가 질문 유형을 판별하는 2차 선택」은 질문마다 요청이 하나 더 나가 무료 한도를 더 쓰므로 없앴다(`GeminiRouter` · `modelPicker` · `Prefs.aiSmartRoute` · 설정 항목 모두 제거). 대신 `GeminiAuto.forChat` 의 낱말 규칙을 점수 방식으로 강화했다. 추가 요청 없음.
- 순서(먼저 맞는 것): ① 감사 · 맞장구(15자 이하) → Flash-Lite ② 코딩 → Hydrogen: 코드 모양(```` ``` ```` · `fun x(` · `def x(` · `import` · `class` · 태그 · `Exception` 등) 또는 확실한 낱말(`CODE_STRONG`: 코딩 · 디버그 · python · sql · html …) 하나, 또는 흔한 낱말(`CODE_WEAK`: 코드 · 함수 · 버그 · 프로그램 · api …) 둘 이상, 또는 흔한 낱말 하나 + 작업 말(`CODE_ACTION`: 작성 · 만들어 · 고쳐 …) ③ 사진 · 깊은 추론 → 3.8 Flash: 확실한 낱말(`HEAVY_STRONG`) 하나, 평범한 낱말(`HEAVY_WEAK`: 분석 · 비교 · 왜 …) 둘 이상, 400자 초과, 계산식 둘 이상, 물음표 셋 이상, 여섯 줄 이상 ④ 링크가 든 질문 · 페이지 글 · 7턴 이상 · 120자 초과 · 50자 넘는 요약/번역/설명 → 3.5 Flash ⑤ 나머지 → Flash-Lite.
- 링크 주소는 모든 판정과 글자 수에서 뺀다. 영어 낱말은 낱말 경계로만 맞춘다(`hasWord`).
- 이어 묻기(30자 이하, 첫 질문 아님): 바로 앞 채팅 질문의 모델을 기억(`lastChat`)해 같은 모델로 보낸다. 새 대화 · 불러오기 · 지우기에서 `GeminiAuto.resetChat()` 으로 비운다. 컴파일 불가 환경이라 코드만 검토했다(규칙은 파이썬으로 옮겨 예시 18개로 확인).

**모델 자동 선택 오판 수정 (v3.9.63)**
- `GeminiAuto.forChat`: 질문 전체에서 `codingWords`(api · css · html · java · github 등)를 `contains` 로 찾아서, 링크 주소나 "capital" 같은 낱말 속 글자에도 코딩으로 판정돼 Hydrogen 이 골라졌다. 이제 (1) `https://…` · `www.…` 는 판정과 길이(400자) 계산에서 뺀다 (2) 영어 단어는 낱말 경계(`hasWord`, 복수 s 허용)로만 맞춘다. 한글 단어는 기존대로 포함 여부. 컴파일 불가 환경이라 코드만 검토했다.

**429 구분: 진짜 한도 vs 서버 혼잡 (v3.9.62)**
- Gemini 는 서버가 붐빌 때도 HTTP 429(`RESOURCE_EXHAUSTED`, "Resource has been exhausted")를 준다. 이전에는 429 를 전부 「요청 한도」로 보고 키를 60초 쉬게 하고(설정 화면 「한도 도달」 표시) 다른 키로 바꿨다.
- `GeminiKeyPool.isQuota(body)`: 본문에 quota 상세(`QuotaFailure` · `quota_metric` · `quotaId` · `retryDelay` · "exceeded your current quota" · per minute/day)가 있으면 진짜 한도. 없으면 서버 혼잡으로 본다.
- 한도가 아닌 429: 키를 쉬게/바꾸지 않고(`Gemini.kt` · `GeminiAgentClient.kt` · `LiveCaption.kt`), 다른 모델로 넘기고, 그래도 안 되면 같은 모델로 1.5초 · 3초 뒤 두 번 다시 보낸다(`busyRetries`; 에이전트는 기존 `SAME_MODEL_RETRIES`). 안내 문구는 「Gemini 서버가 지금 붐벼서… 한도 문제는 아니에요 (429)」. 「등록한 키 N개가 모두 지금은 한도예요」도 진짜 한도일 때만 붙는다.
- 컴파일 불가 환경이라 코드만 검토했다.

**AI 창 대화 버튼 줄 분리 (v3.9.61)**
- `AssistantUi` 머리글은 로고 · 제목 · 모델 칩 · 닫기만 남기고, 「대화 기록」 · 「새 대화」 · 「대화 지우기」는 머리글 아래 `tools` 줄(`toolPill`: 아이콘 + 글자, 테두리 알약)로 옮겼다. 기록 · 지우기 카드 팝업은 이제 왼쪽에 있는 버튼의 왼쪽 끝에 맞춰 뜬다. 컴파일 불가 환경이라 코드만 검토했다.

**대화 기록 카드 팝업 (v3.9.60)**
- `AssistantUi.showChatHistory(anchor)`: 기록 버튼(`ic_history`)이 보이면 `PopupWindow` 카드로 버튼 아래·오른쪽 끝에 맞춰 띄운다(폭 320dp, 높이는 내용에 맞추고 남는 공간을 넘으면 목록만 스크롤). 이전에는 `ThemedDialogBuilder` 대화상자라 화면 중앙·테마 폭(큰 화면에서 가로로 길게)으로 떴다. 버튼이 안 보이면 기존 대화상자로 대체. 하단 「모두 삭제」 · 「닫기」, 줄을 지우면 `fit()` 으로 높이를 다시 맞춘다. 컴파일 불가 환경이라 코드만 검토했다.

**AI 대화 저장 · 대화 기록 (v3.9.59)**
- `ChatStore.kt`: 대화 하나 = `filesDir/ai_chats/<id>.json` 한 파일(임시 파일에 쓴 뒤 바꿔치기). 질문 · 답 · 생각 요약 · 검색어 · 출처만 저장하고 보낸 사진과 에이전트 진행 카드는 저장하지 않는다. 최대 `MAX_CHATS`=100개(넘으면 오래된 것부터 삭제). id 는 `[a-z0-9]{4,24}` 만 허용해서 경로 조작을 막는다.
- `AssistantUi`: 질문을 보낼 때(`send`)와 답이 끝날 때(`setGenerating(false)` — 중지 · 실패 포함) `saveChat()`. 파일 입출력은 전용 스레드 `storeIo` 에서 한다(에이전트가 확인을 기다리며 `io` 를 붙들어도 안 밀리게). 제목은 첫 질문 40자.
- 헤더에 「대화 기록」(`ic_history`) · 「새 대화」(`ic_add`) 버튼. 기록 창에서 누르면 불러오고(`loadChat` → `renderChat`), ✕ 로 하나씩, 「모두 삭제」로 전부 지운다. 답을 만드는 중에는 불러오기 · 새 대화를 막는다. 「대화 지우기」는 저장본도 같이 지운다. 설정 「대화 자동 저장」(`Prefs.aiChatSave`, 기본 켜짐)으로 끌 수 있다.
- 컴파일 불가 환경이라 `ChatStore` 는 스텁으로 타입 검사만, `AssistantUi` 는 문법만 확인했다.

**AI 에이전트 4단계: 자율 모드 (v3.9.58)**
- 3단계(페이지 조작)는 이 코드에 아직 없다. 4단계는 1~2단계 도구(탭 · 설정 · 북마크 · 확장 · 다운로드 · 웹 검색) 위에서만 동작하고, 페이지 도구가 생기면 그대로 같이 쓴다.
- 진입: `AgentRouting.wantsAuto`(「알아서 · 자율 · 끝까지 · 스스로 · 목표」 등)가 맞고 `Prefs.agentAuto`(기본 켜짐, AI 설정 「에이전트 자율 모드」)면 `AssistantUi.startAgent(auto=true)`. 아니면 기존 에이전트(10단계)다.
- 루프(`AgentRunner.run(auto=true)`): 모델 호출 한도 `MAX_STEPS_AUTO`=30, 앱을 바꾸는 도구 총 `MAX_CHANGES_AUTO`=25회. 계획 전에는 읽기 도구만 허용(바꾸는 도구는 "먼저 make_plan" 으로 거절). 바꾼 뒤 읽기 도구로 확인 없이 끝내려 하면 한 번만 "확인하고 보고하라" 고 일러 준다(`dirty` · `nudged`).
- 도구(`AgentAutoTools.kt`): `make_plan`(CHANGE + `alwaysAsk`: 계획을 확인 카드로 보여 주고 허락받으면 그 요청의 CHANGE 는 더 안 묻는다. DANGER 는 그대로 매번 확인), `plan_step`(`quiet` 도구: 진행 카드에 줄 없이 계획 체크 표시만), `ask_user`(한 번에 `MAX_ASKS`=3번, 선택지 + 직접 입력 + 건너뛰기. 120초 · 중지 · 건너뛰기는 null → 도구 실패로 모델에게 돌려줘 멈추고 알리게 한다).
- 되돌리기: `AgentTool.undoPlan` 이 실행 직전 상태를 붙들고 실행 뒤 `AgentUndo` 를 만든다. 대상은 open_tab(연 탭 닫기) · close_tab(주소로 다시 열기, 시크릿 제외) · switch_tab · go_to(뒤로) · page_nav(back↔forward) · add_bookmark(`AgentHost.removeBookmark`, 원래 있던 건 안 지움) · change_setting(이전 값 복원) · set_extension(이전 상태 복원). download_file · reload · stop 은 되돌릴 수 없다. 탭은 번호 + 주소로 다시 찾고, 바뀌었으면 건드리지 않고 "못 함" 으로 알린다. `AgentRunner.undoAll()` 은 최근 것부터 되돌리며 실행 기록에도 남긴다. 진행 카드는 끝난 뒤(중지 · 오류 포함) 「되돌리기」 버튼을 단다.
- UI(`AgentUi.kt`): `AgentProgressCard.setPlan/markPlan/showUndo/setUndoResult`, `AgentAskCard`. 컴파일 불가 환경이라 코드만 검토했다.

**오류 메시지 영어 제거 (v3.9.57)**
- `GeminiClient.describeError` · `GeminiAgentClient.describeError` 가 한국어 안내 뒤에 구글 응답의 `error.message`(영어)를 덧붙이던 것을, 그 글에 한글이 있을 때만 붙이도록 바꿨다. 그래서 오류 말풍선에는 한국어 안내(+ 키 개수 안내)만 보인다. 원문은 `Round.body` 로 그대로 남아 키 전환 판단에는 영향 없다. 코드만 검토(컴파일 불가).

**오류 말풍선 폭 (v3.9.56)**
- 한도 오류 말풍선이 좁게 접혀 보였다(`ReplyBubble` 이 `WRAP_CONTENT` 라 글이 몇 글자 폭에서 줄바꿈). `ReplyBubble.showError` 가 말풍선 레이아웃 폭을 `MATCH_PARENT`(오른쪽 여백 24dp 는 그대로)로 바꾸고, 다시 답이 채워질 때(`setMarkdown`)는 `WRAP_CONTENT` 로 되돌린다(`setBubbleWidth`). 좁아진 정확한 원인은 코드만으로는 확정 못 했고(기기 확인 필요), 폭을 고정해 해결했다. 컴파일 불가 환경이라 코드만 검토했다.

**API 키 전환 표시 (v3.9.55)**
- 키 전환 로직(한도 429 · 키 거부 시 다른 키로 재요청)은 이전부터 `GeminiKeyPool` + `GeminiClient.stream` / `GeminiAgentClient.step` / `LiveCaption.request` 에 있었고, 이번에는 그 전환을 화면에 보이게만 했다.
- `GeminiKeyPool.notifySwitch(from, to, bad)` → `onEvent(KeySwitchEvent)`: 키가 바뀔 때 3초에 한 번만(번역 병렬 요청 대비) 불린다. 리스너는 `MainActivity`(onResume 에 등록, onDestroy 에서 자기 것이면 해제) · `PlayerActivity`(onStart). 둘 다 `AppToast` 로 알리고, MainActivity 는 `AssistantUi.onKeyEvent` 도 불러 AI 창 위 칩을 노랗게 반짝인다.
- `GeminiKeyPool.used(key)`: 실제로 요청을 보내는 키 기록 → AI 창 칩에 「키 n/m」(키 2개 이상일 때). `statusOf(key)`: 설정 키 목록의 상태 문구(전체 한도 · 거부 · 특정 모델만 한도 · 남은 시간).
- 클래스 이름이 `KeySwitchEvent` 인 이유: `android.view.KeyEvent` 와 겹치지 않게. 컴파일 불가 환경이라 코드만 검토했다.

**AI 에이전트 2단계: 앱 조작 (v3.9.54)**
- 도구 추가(`AgentAppTools.kt`): 읽기 4(`search_history` · `search_bookmarks` · `get_settings` · `list_extensions`), 변경 8(`open_tab` · `close_tab` · `switch_tab` · `go_to` · `page_nav` · `add_bookmark` · `change_setting` · `set_extension`), 위험 1(`download_file`). 1단계의 `list_tabs` · `web_search` 는 `Agent.kt` 에 그대로.
- `AgentHost` 에 메서드 추가, 구현은 `AgentHostImpl.kt`(메인 스레드로 넘김) → `MainActivity` 의 `agentXxx()` 묶음(`agentTabs` 아래). 쓰기는 기존 함수(`createTab` · `closeTabUndoable` · `selectTab` · `loadFromInput` · `navBack` …)를 그대로 불러 쓴다. 결과는 `AgentOutcome`(ok · message · 탭 번호 · 탭 수).
- 위험도(`AgentRunner.execute`): READ 는 바로, CHANGE 는 한 요청(= `AgentRunner` 한 개) 안에서 처음 한 번만 확인(`changeApproved`, 허락하면 그 요청 동안 CHANGE 는 다시 안 묻는다), DANGER(다운로드)는 매번 확인. 거절되면 실패 결과로 돌려줘서 모델이 알린다. 도구의 확인 문구는 `AgentTool.ask`.
- 확인 카드(`AgentConfirmCard`, AgentUi.kt): `AssistantUi.askAgentConfirm` 이 AI 창의 진행 카드 아래에 붙이고, 에이전트 스레드는 래치로 기다린다(최대 `CONFIRM_WAIT_SEC`=120초, 시간 초과 · 중지 · 창 닫힘은 거절). 이 때문에 확인을 기다리는 동안 `io` 실행기가 묶인다.
- 실행 기록: `Prefs.addAgentLog` · `agentLog()` (최근 200줄, "시각|내용"). 변경·위험 도구의 허락/거절/완료/실패만 남기고 읽기는 남기지 않는다. AI 설정 맨 아래 「에이전트 실행 기록 보기」 에서 보고 지울 수 있다.
- 안전: 시크릿 탭은 `agentIncognito` 가 꺼져 있으면 목록 · 닫기 · 전환 · 이동 · 열기 모두 거부, 시크릿 탭은 북마크 불가. `javascript:` · `data:` · `file:` · `content:` · `intent:` 등 주소는 열지 않는다(`agentBadScheme`). 설정은 `web_dark_mode` · `ad_block` · `bookmark_bar` · `text_zoom` 4개만 바꾼다(나머지는 읽기만). 테마 확장은 켜고 끄지 않는다. 기록 · 북마크 · 확장 이름은 웹에서 온 글이라 `untrusted` 로 표시한다. 탭을 닫으면 번호가 당겨지니 모델이 `list_tabs` 로 다시 확인하도록 안내했다.
- 라우팅: `AgentRouting.toolWords` 에 앱 조작 말(열어 · 닫아 · 북마크 · 설정 · 다운로드 …)을 더했다. 도구가 늘면 같이 늘릴 것.
- 아직 안 한 것: 북마크 · 기록 삭제, 방문 기록 지우기 같은 삭제 도구(3단계 이후 DANGER 로), 페이지 조작(3단계), 자율 모드(4단계). 컴파일 불가 환경이라 코드만 검토했다. 확인 포인트: 확인 카드가 진행 카드 아래에 붙는지, 허락 뒤 도구가 이어지는지, 중지 · 창 닫기가 대기를 푸는지, `refreshTopBarButtons`/`applyExtensionsSoon` 이 확장 토글 뒤 잘 도는지.

**에이전트 라우팅 좁히기 (v3.9.53)**
- 3.9.50 은 에이전트가 켜져 있으면 사진 질문 외 모든 채팅을 Hydrogen 에이전트로 보내서 "ㅎㅇ" 에도 Hydrogen 이 골라졌다. `AgentRouting.needsTools`(탭·검색·에이전트 키워드)에 걸릴 때만 에이전트로 가고, 나머지는 `GeminiAuto.forChat` 으로 돌아간다. 도구가 늘면 `toolWords` 를 늘릴 것. 위 3.9.50 "알려 둔 선택" 항목은 이 버전부터 해당 없음.

**API 키 입력칸 자동 채우기 끄기 (v3.9.52)**
- AI 설정 API 키칸 · GitHub 토큰칸이 `TYPE_TEXT_VARIATION_PASSWORD` 라서 삼성 패스가 떴다. 일반 글 칸(`VISIBLE_PASSWORD` + `NO_SUGGESTIONS`)에 `PasswordTransformationMethod` 로 가림만 입히고 `importantForAutofill=NO_EXCLUDE_DESCENDANTS` 로 바꿨다. 삼성 패스는 입력 타입으로 비밀번호 칸을 찾으므로 타입을 바꾸는 게 핵심. 코드만 검토(컴파일 불가).

**API 키 추가 · 한도(429) 처리 수정 (v3.9.51)**
- 「추가」 무반응 원인: 키 모양 검사(`[A-Za-z0-9_-]{20,}`)가 점(.)이 든 새 형식 키(`AQ.…`)를 거절했고, 그 안내 토스트가 설정 팝업(별도 창) 뒤에 가려져 아무 일도 없는 것처럼 보였다. 이제 보이는 ASCII 20자 이상이면 받고, 결과·오류는 입력칸 아래 `noticeTv` 에도 띄운다(`notice()`).
- 한도 처리: `GeminiKeyPool.onLimit(key, model, body, badKey)` 로 통일(Gemini · 에이전트 · 실시간 자막). 429 본문이 한도 0 · 일일/모델 단위면 (키, 모델) 짝만 쉬게 하고, 그 밖에는 `retryDelay`(없으면 60초) 만큼 키를 쉬게 한다. 모델 한정 403(권한 없음)도 키 전체를 10분 쉬게 하지 않는다. 모델을 바꿀 때 `forModel` 로 그 모델에서 막히지 않은 키를 고르고, 키 대체는 `alternative(exclude, model)`.
- 배경: 3.9.50 부터 채팅이 Hydrogen 에이전트로 가는데, 새 무료 키는 Hydrogen 한도가 0 인 경우가 있어 키 전체가 쉬는 걸로 처리돼 "새 키도 한도 초과" 로 보였다.
- 컴파일 불가 환경이라 코드만 검토.

**AI 에이전트 1단계: 뼈대 (v3.9.50)**
- 목표: 말로 시키면 AI 가 앱 기능(도구)을 골라 실행하고, 결과를 보고 다음 단계를 스스로 이어간다. 1단계는 뼈대만 — 도구는 읽기 2개(`list_tabs`, `web_search`). 쓰기·페이지 조작·자율 모드는 2~4단계.
- 새 파일: `Agent.kt`(도구 타입 · `AgentHost` · `AgentTools` · `AgentRunner` 루프) · `GeminiAgentClient.kt`(함수 호출 스트리밍) · `AgentHostImpl.kt`(`MainAgentHost`) · `AgentUi.kt`(진행 카드).
- 루프(`AgentRunner.run`): 모델 호출 → `functionCall` 이 있으면 도구 실행 → `functionResponse` 로 돌려줌 → 반복. 호출 횟수 한도 `MAX_STEPS`=10, 한 번에 실행하는 도구 `MAX_CALLS_PER_STEP`=6, 같은 호출 연속 `REPEAT_LIMIT`=3 초과 시 막고 모델에 실패로 알림. 한도에 닿으면 `toolConfig.mode=NONE` 으로 한 번 더 불러 "한 일·남은 일" 을 정리하게 한다(`AgentEnd.LIMIT`).
- 대화(`contents`)는 글이 아니라 JSON 그대로 이어 간다. 모델이 보낸 parts 는 `thoughtSignature` 까지 그대로 되돌려 보낸다(생각 요약 `thought:true` 만 뺀다). 서명이 모델마다 달라서 모델 바꿔 재시도는 첫 단계에서만 한다(`canSwitchModel`). 이후 단계의 429/5xx 는 키 교체 → 같은 모델 재시도(최대 2번).
- `AgentHost`: 도구가 MainActivity 를 직접 건드리지 않게 하는 얇은 문. 구현(`MainAgentHost`)이 메인 스레드로 넘겨 결과를 기다린다(8초). MainActivity 쪽에는 `agentTabs()` 한 함수만 열어 뒀다. 쓰기 도구가 늘면 이 인터페이스에 메서드를 더한다.
- 모델: 에이전트는 Hydrogen(`AgentModels.PLANNER`). 사진·화면을 봐야 하는 질문(`AgentRouting.needsVision` 키워드)이나 꾹 눌러 첨부한 사진이 있으면 에이전트를 거치지 않고 기존 방식(3.8 Flash)으로 답한다. 에이전트 도중에 화면을 봐야 하면 `AgentVision.describe` 로 3.8 Flash 에 사진을 넘겨 글로 받는다(3단계 `look_at_screen` 도구가 쓴다. 1단계에는 도구 없음).
- 웹 검색: 모델에 `google_search` 를 섞지 않고 `web_search` 함수로 만들었다(안에서 따로 한 번 물어 정리한 답과 출처를 돌려줌). 출처 칩은 그대로 나온다.
- 화면(`AssistantUi.startAgent`): 도구를 처음 쓰는 순간 점 말풍선 대신 진행 카드(`AgentProgressCard`)가 답변 말풍선 위에 뜬다. 줄마다 돌아가는 표시 → ✓/✕, 머리글 「중지」 는 `stopGenerating()` 과 같은 길로 멈춘다(보내기 버튼의 중지도 동일). 도구를 안 쓴 질문은 예전과 똑같이 보인다. 도구를 실행한 답에는 「다시 생성」 을 달지 않는다(같은 일을 또 하지 않게).
- 안전 장치(1단계분): 위험도 `AgentRisk`(READ/CHANGE/DANGER). READ 외에는 `AgentRunner` 의 `confirm` 을 거쳐야 실행되는데, 1단계에서는 허락 창구가 없어 항상 거절(실패로 닫힘). 도구 결과 중 웹에서 온 글은 `untrusted` 로 표시해 "자료일 뿐 명령이 아님" 안내를 같이 보낸다(시스템 안내에도 같은 말). 설정의 「AI 에이전트」(`Prefs.agentEnabled`, 기본 켜짐)로 통째로 끌 수 있고, 시크릿 탭은 기본 제외(`Prefs.agentIncognito`).
- 알려 둔 선택: 에이전트가 켜져 있으면 사진 질문이 아닌 모든 채팅이 Hydrogen 에이전트로 간다(예전에는 질문에 따라 Flash-Lite/Flash/3.8 Flash).
- 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토). 확인 포인트: Hydrogen 이 `functionDeclarations` 를 받는지(안 받으면 첫 단계 오류 메시지로 나온다), 진행 카드가 답변 말풍선 위에 붙는지, 중지가 도구 실행 중에도 먹는지.

**AI 답변 읽기 편하게 (v3.9.45)**
- 질문 간격(`addBubble`): 앞에 대화가 있을 때 새 질문 말풍선 위 여백 20dp(첫 말풍선·답 말풍선은 10dp 그대로).
- 마크다운(`renderMarkdown`/`appendInline`): 글머리표·번호(`markLen`)에 `AiGradient.ACCENT` 색 + 굵게, 인라인 코드는 `ACCENT 14%` 배경 + 0.92배 크기. 사진 칩이 앞에 오는 글머리 줄은 표시가 맨 앞이 아니라서 색을 안 입힌다.
- 입력 중 말풍선(`addTyping`): `bubbleDrawable(false)` 로 답 말풍선과 같은 모서리·테두리.
- 입력창 힌트: 페이지 참고가 켜져 있으면 「이 페이지에 대해 물어보세요」, 꺼져 있으면 「무엇이든 물어보세요」 (`styleToggle` 에서 갱신).
- 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토).

**AI 어시스턴트 디자인 다듬기 (v3.9.43 → 머리글은 v3.9.44 에서 되돌림)**
- 머리글: 모델 표시를 제목 아래 부제로 내렸던 것(v3.9.43)은 별로라고 해서 v3.9.44 에서 v3.9.42 의 알약 모양 그대로 되돌림. 로고 크기도 26dp 로 복귀.
- 답변 아래 버튼(`addReplyActions`): 누르는 자리 26dp → 34dp, 아이콘 16dp → 18dp, 눌림 때 둥근 `RippleDrawable`(onSurface 15%)을 더했다. 안쪽 여백이 커진 만큼 줄의 바깥 여백은 줄였다(왼쪽 6→2dp, 위 6→2dp).
- 코드 블록(`makeCodeView`): 머리줄에 `onSurface 6%` 색 띠(위쪽 모서리만 둥글게), 복사는 주색 10% 알약, 코드 글자 12.5sp · 줄 간격 1.2. 띠가 테두리선을 덮지 않도록 상자 안쪽 여백을 선 두께만큼 둔다.
- 표(`makeTableView`/`fillTable`): 12dp 둥근 모서리로 잘라(`clipToOutline`) 코드 블록과 맞췄고, 본문 줄은 한 줄 걸러 `onSurface 4%` 색을 입힌다(머리줄은 기존 주색 틴트).
- 빈 화면 인사말: 19sp, 머리글 제목과 같은 `AiGradient.textShader`.
- 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토). 시각 확인 포인트: 모델명이 긴 경우 부제가 말줄임으로 잘리는지, 태블릿 팝업·분할 머리글 드래그가 두 줄 머리글에서도 잡히는지.

**AI 어시스턴트 보조 애니메이션 개선 (v3.9.42)**
- 새 파일 `StreamFx.kt`: `FadeInSpan`(새로 붙은 글자가 300ms 동안 알파 0.12→1 로 떠오름, 그릴 때마다 `uptimeMillis` 로 계산하는 `CharacterStyle`) · `BlinkCursorSpan`(글 끝 ▍ 을 1.1초 주기 코사인으로 알파 0.22~1) · `ThoughtClip`(생각 요약 고정 높이 창).
- 글 떠오름·커서: `ReplyBubble.fill` 의 live 블록에서만. 글이 다시 그려질 때마다(60ms) 아직 300ms 안 지난 구간(`liveFades`/`liveBirths`)만 다시 입힌다. `liveClock`(1.1초 반복 `ValueAnimator`)이 받는 동안만 `liveTv.invalidate()` 를 불러 스팬을 다시 그리게 하고, `setMarkdown(streaming=false)`·`showError`·분리 때 멈춘다. 애니메이션을 끈 기기는 시계를 안 돌린다(커서는 정지). 마크다운 변환으로 앞쪽 글자 위치가 밀리면 떠오름 구간이 300ms 동안 어긋날 수 있다. 링크·코드처럼 자체 색 스팬이 있는 글자는 떠오름이 약할 수 있다.
- 받는 도중 새 블록(문단·코드·표)이 생기면 `Motion.enter`(rise 8dp)로 떠오른다 — 첫 블록(i=0)과 이미 받은 답을 복원할 때는 제외.
- `ThoughtClip`: 생각 중에는 88dp 로 높이를 고정하고, 자식(`thoughtRow`)을 위에서부터 놓은 뒤 `translationY=-shift` 로 맨 아래 글이 보이게 한다. 글이 늘 때마다 `shift` 를 스프링(140/1.0)으로 새 목표에 맞춘다. 맨 위 27dp 는 카드색(`onSurface 5%` 를 `bubbleBg` 위에 합성한 불투명색)으로 옅어진다. `ThoughtView.finish` 가 `release(animate && userToggled)` 로 제한을 푼다: 직접 펼쳐 둔 경우만 240ms 로 전체 높이까지 늘고, 자동으로 접히는 경우는 바로 푼다(접힘 애니메이션이 현재 높이에서 시작).
- 오류 말풍선(`showError`): `translationX` 9dp 에서 스프링(700/0.22)으로 0 까지 떨리다 멈춘다.
- 복사: 답변 아래 복사 아이콘이 `ic_check`(주색)로 바뀌며 `Motion.pop`, 1.4초 뒤 되돌아온다(`actionButton` 의 콜백이 버튼을 받는다). 코드 블록 「복사」 는 「복사됨 ✓」 + 팝, 1.4초 뒤 복귀.
- 출처 칩(`buildSourceRow(animate)`): 칩마다 `Motion.enter` 를 90ms + 55ms×순서 지연으로 걸어 왼쪽부터 차례로 뜬다. 복원할 때는 안 움직인다.
- 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토).

**AI 입력중 애니메이션 종류별 변화 · API 「추가」 버튼 (v3.9.41)**
- 사고 과정의 종류 `ThinkKind`(ThinkingGlyph.kt): `THINK`(점 물결) · `READ`(글줄이 위에서 아래로 읽힘) · `LOOK`(조리개처럼 모였다 퍼지는 점) · `SEARCH`(꼬리 달린 점이 원을 훑음) · `ANALYZE`(오르내리는 막대) · `WRITE`(왼쪽에서 오른쪽으로 써지는 줄). 종류마다 색도 다르다(`AiGradient.STOPS` 기준: 생각 0 · 읽기 1 · 검색 2 · 분석 3 · 사진 `at(0.78)` · 정리 `at(0.2)`).
- `ThinkingGlyphView`: 둥근 사각형 세 개(`shape(kind, i, t)` 가 종류별 중심·너비·높이·투명도를 돌려줌 — 점은 너비=높이, 줄은 너비>높이, 막대는 높이>너비)를 하나의 시계(`ts`, 초)로 계속 돌린다. 종류가 바뀌면 이전 모양과 새 모양을 **같은 시계로 둘 다 계산해** 스프링(`Motion.springValue`, 170/0.78)으로 섞어서(`morph` 0→1, 살짝 넘칠 수 있음) 움직임이 끊기지 않고 점이 줄로, 줄이 막대로 흘러 바뀐다. 색은 `blendARGB`. 애니메이션을 끈 기기는 시계를 세우고(`ts=0`) 모양만 그린다. 안 보이면(`onVisibilityChanged`) 시계를 세운다.
- 종류 판별: ① 요청 단계는 앱이 안다 — 페이지 참고를 켰으면 `READ` 로 시작, 요청을 보낼 때 사진을 붙였으면 `LOOK`, 아니면 `THINK`. ② 생각 요약(`reply.thought`)이 오면 `ThinkKind.classify` 가 **가장 마지막 「**제목**」 토막**의 낱말(영어·한글)로 고른다(search/검색 → SEARCH, draft·refine·정리 → WRITE, image·사진 → LOOK, read·page·읽 → READ, analy·compar·분석 → ANALYZE, 그 외 THINK). 제목이 아직 없으면 지금 모양 유지. ③ 생각 요약을 끈 설정이면 `onGrounding`(검색한 말이 옴)이 유일한 단서라 그때 `SEARCH`.
- 깜빡임 방지: `AssistantUi.setThinkKind` 는 한 모양을 최소 1.1초 보여 준다(`kindChangedAt`). 바뀐 직후에 또 바뀌면 `kindPending` 에 두었다가 남은 시간 뒤에 적용한다(`applyKind`). 생성이 끝나면 대기 중인 변경은 버린다.
- 표시 자리: ① 점 말풍선(`addTyping`) — 예전 `TypingDotsView`(삭제함) 대신 `ThinkingGlyphView` + 한마디(「페이지 읽는 중…」 등). 글이 바뀔 때 `ThinkText.swap` 이 위로 옅어졌다가 아래에서 올라오고, 말풍선 너비가 부드럽게 늘고 준다. ② 사고 과정 카드 `ThoughtView` 머리줄 — 아이콘 자리에 같은 움직임(0.8배)이 있고 제목도 종류 글로 바뀐다. 끝나면(`finish`) 움직임이 0.6배로 줄며 옅어지고 반짝이 아이콘이 0.6→1배로 떠오른다. 점 말풍선에서 카드로 넘어갈 때 현재 종류(`thinkKind`)를 이어받아 모양이 튀지 않는다. 창을 닫았다 열어도 `thinkKind` 로 이어진다.
- API 「추가」 버튼(`AssistantUi.showSettings`): 입력칸 오른쪽에 주색 알약 「추가」. 칸이 비면 흐리게(0.4), 글이 있으면 선명하게(스프링). 누르면(또는 키보드 완료) `addKeysNow` 가 **저장을 거치지 않고 바로** `prefs.geminiKeys` 에 더한다. 공백·쉼표·줄바꿈으로 여러 개를 한 번에 넣을 수 있고, `[A-Za-z0-9_-]{20,}` 모양이 아닌 글이 섞여 있으면 아무것도 더하지 않고 알린다. 이미 있는 키는 「이미 추가된 키예요」, 삭제 예정으로 표시해 둔 키를 다시 넣으면 되돌린다. 더해진 키는 카드로 아래에서 떠오르며 붙고(`addKeyRow(animate=true)`), 「API 키 · N개」 제목·「모두 삭제」 버튼·카드 높이(`onKeysChanged`, `pw.update`)가 맞춰진다. 입력칸에 쓰고 「추가」 없이 「저장」을 눌러도 예전처럼 더해진다. 삭제는 여전히 저장 때 적용된다.
- 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토).

**AI 출처 칩 · 사고 과정 UI (v3.9.40)**
- 검색: `GeminiSearch`(Gemini.kt) 가 요청 본문에 `tools:[{google_search:{}}]` 를 넣는다(모델이 필요할 때만 검색). `GeminiClient.stream` 에 `search`·`includeThoughts`·`onThought`·`onGrounding` 인자를 더했고(기본값이 있어 번역·확장 요약·자막 호출부는 그대로), `json=true` 요청에는 검색 도구를 붙이지 않는다. 모델이 도구 때문에 400 을 내면 그 모델을 기억해 두고 검색 없이 한 번 더 보낸다(`GeminiSearch.rejected`, 생각 설정 `GeminiThinking.rejected` 와 같은 방식). 응답 조각의 `candidates[0].groundingMetadata` 에서 `webSearchQueries`(검색한 말)·`groundingChunks[].web`(제목=사이트 도메인, uri=구글 중계 주소)을 모아 `onGrounding` 으로 넘긴다.
- 사고 과정: `GeminiThinking.apply(..., includeThoughts)` 가 `thinkingConfig.includeThoughts=true` 를 넣고, 이전엔 버리던 `thought:true` 파트의 글을 `onThought` 로 넘긴다(답 글에는 섞이지 않는다). 채팅 요청만 켠다(`Prefs.assistantThoughts`). 생각 수준은 그대로 `low` 라 쉬운 질문엔 요약이 없을 수 있고, 그땐 카드를 만들지 않는다.
- 데이터: `ChatMsg` 에 `thought`·`thinkMs`·`searchQueries`·`sources`(`SearchSource(title,url)`) 를 본문 변수로 더했다(생성자·equals 는 그대로, 모델에 다시 보내는 기록에는 실리지 않는다). 창을 닫았다 열어도 `history` 에서 카드와 칩을 되살린다.
- UI(`AssistantUi`): `ReplyBubble` 을 위(사고 과정 `head`)·가운데(글 `body`)·아래(출처 `foot`) 세 칸으로 나눴고 글 블록은 `body` 에만 쌓인다. `ThoughtView` — 생각하는 동안 펼쳐진 채 요약이 흘러 들어오고(제목 「생각하는 중…」 위로 빛이 지나감, 아이콘 ic_ai), 첫 답 글자가 오면 「N초 동안 생각했어요」(검색했으면 「…생각하고 검색했어요」)로 접힌다(높이 240ms 감속, 화살표 스프링 회전). 직접 눌러 펼쳤으면 자동으로 접지 않는다. 펼치면 생각 요약(마크다운, 왼쪽 색 줄)과 「검색한 말」 알약이 보이고, 알약을 누르면 구글 검색을 새 탭으로 연다. `buildSourceRow`/`sourceChip` — 말풍선 아래 가는 줄 + 「웹 검색 출처 · N」 + 가로로 밀리는 사이트 칩(`Favicons.apply` 로 도메인 아이콘, 못 구하면 지구본), 누르면 `openUrl` 후 채팅 창을 닫는다. 첫 생각이 오면 점 말풍선 자리에 카드가 든 말풍선이 나타난다.
- 시스템 프롬프트(`buildSystem`)에 검색 안내를 더했다: 필요할 때만 검색하고 답 안에 [1] 같은 출처 표기는 쓰지 않는다(칩이 대신함).
- 설정: AI 설정에 「답변 표시」 구역(웹 검색 · 출처 칩 / AI 사고 과정 보기 체크, 누르면 바로 저장). `Prefs.assistantSearch`·`assistantThoughts` 기본 켜짐.
- 알아 둘 것: 답 글 안의 문장별 인라인 인용([1])은 넣지 않았다(`groundingSupports` 의 위치가 UTF-8 바이트 기준이라 한글 글자 위치로 바꾸는 작업이 필요). Google 검색 연결을 쓰면 약관상 검색어 제안(`searchEntryPoint`) 표시 의무가 있는데, 지금은 「검색한 말」 알약으로 대신한다. 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토).

**AI 설정 카드 UI 개선 (v3.9.39)**
- `AssistantUi.showSettings` 의 내용을 구역으로 나눴다: 「API 키」(저장된 키마다 둥근 패널 카드 — 상태 점 초록=사용 가능/주황=`GeminiKeyPool.resting` 한도 차서 쉬는 중, 마스킹된 키, 빨간 「삭제」 ↔ 「되돌리기」 토글로 저장 전까지 취소 가능, 삭제 예정 카드는 알파 0.45) → 키 추가 입력칸 → 키 발급 링크 → 「모델 · 자동으로 골라요」 패널(가벼운 질문·번역 / 페이지 읽기·긴 대화 / 사진·복잡한 질문 별 모델과 색 점) → 안내 문구. 동작(저장·모두 삭제)은 v3.9.38 그대로. 빌드·실기기 확인 전.

**API 키 여러 개 (v3.9.38)**
- 저장: `Prefs.geminiKeys`(`gemini_keys`, 키마다 `KeyVault` 로 암호화한 JSON 배열). 예전 `gemini_key` 하나는 읽을 때 그대로 이어받고, 저장하면 새 형식으로 바뀐다. `Prefs.geminiKey` 는 읽기 전용으로 바뀌어 `GeminiKeyPool.pick` 이 고른 키 하나를 돌려준다(없으면 ""), 그래서 기존 `isNotBlank()` 확인과 호출부는 그대로 동작한다.
- `GeminiKeyPool`(Gemini.kt): 쉬는 중이 아닌 키를 번갈아 고른다. 429 → 그 키 60초, 키 거부(401/403, 400 'API key') → 10분 쉬게 하고 `alternative` 로 다른 키에 같은 요청을 다시 보낸다(`GeminiClient.stream`, `LiveCaptioner.request`). 키를 모두 써 본 뒤에야 모델 대체(`GeminiAuto.fallbacks`)로 넘어가고, 모델을 바꾸면 써 본 키 목록을 비운다.
- AI 설정: 저장된 키를 「키 1  AIza…xxxx · 삭제」로 나열(삭제는 저장 때 적용), 입력칸은 키 추가(공백·쉼표·줄바꿈으로 여러 개 한 번에 가능), 「모두 삭제」 버튼. 빌드·실기기 확인 전.

**Gemini 모델 자동 선택 (v3.9.36)**
- 설정의 모델 라디오와 `Prefs.geminiModel` 을 없앴다. `GeminiAuto`(Gemini.kt) 가 일에 맞춰 고른다: 채팅 `forChat` — 사진 첨부·긴 질문(400자 초과)·분석/비교/코드 같은 낱말 → 3.8 Flash, 페이지 본문 참고·대화 7턴 이상 → 3.5 Flash, 그 외 가벼운 질문 → Flash-Lite. 페이지 글 번역·확장 요약 → Flash-Lite, 사진 속 글자 번역·실시간 자막(소리) → 3.5 Flash.
- 모델 ID: `gemini-3.5-flash-lite`(새로 추가, ID 는 추정 — 실제와 다르면 404 로 `markDead` 되어 다른 모델로 넘어간다), `gemini-3.5-flash`, `gemini-3.8-flash`.
- `GeminiClient.stream` 은 글자를 하나도 받기 전에 404/429/5xx 가 나면 `GeminiAuto.fallbacks` 순서로 다른 모델에 같은 요청을 다시 보낸다. 404 난 모델은 앱이 켜져 있는 동안 건너뛴다.
- AI 창 위쪽 칩은 「자동 · 고른 모델」을 보여 준다(`lastModelLabel`). 메뉴 항목 부제는 「모델 자동 선택」. 빌드·실기기 확인 전.

**Gemini 응답 속도 개선 (v3.9.35)**
- 원인: `generationConfig` 에 `thinkingConfig` 가 없어 Gemini 3.x 가 매 요청마다 기본(동적) 추론을 길게 하고 나서야 첫 글자를 보냈다.
- `GeminiThinking`(Gemini.kt) 이 `thinkingConfig.thinkingLevel` 을 넣는다. 채팅(`AssistantUi.generate`)은 `low`, 번역·확장 프로그램·실시간 자막(`LiveCaption.request`)은 `minimal`(`GeminiClient.stream` 의 `thinking` 기본값). 모델이 이 설정 때문에 400 을 내면 그 모델을 기억해 두고(`GeminiThinking.rejected`) 설정 없이 같은 요청을 한 번 다시 보낸다. 빌드·실기기 확인 전.

**창 칩 잠금 표시·애니메이션 개선 (v3.9.34)**
- 잠긴 창은 칩 부제의 「· 잠금」 글자 대신 번호 배지 오른쪽 아래에 작은 자물쇠 핀(`windowLockPip`, `ic_lock_fill`, 주색 원 + 칩 바탕색 테두리로 파낸 모양)이 붙는다. 글자가 빠져 잠그고 풀 때 칩 너비가 변하지 않는다. 잠긴 칩은 접근성 설명에 「잠긴 창」이 붙는다. 배지는 `item_window_chip.xml` 에서 `FrameLayout`(33dp)로 감쌌다.
- `toggleWindowLock` 은 토스트 대신 `pendingLockAnim`(창 번호 → 잠금 여부)을 두고 칩 줄을 다시 그린다. 다시 그릴 때 그 칩은 바뀌기 전 모양(잠글 땐 핀 없음, 풀 땐 핀 있음)으로 그려 두고, 메뉴가 칩으로 접힌 뒤(300ms) `playLockAnim` 이 바뀐 모양으로 움직인다.
- 잠금: 핀이 -42° 기울어진 채 0에서 튀며 커져 딸깍 제자리(스프링 560/0.4 · 회전 480/0.35), 번호 배지는 0.84배로 눌렸다 돌아옴, 햅틱 CONFIRM(API 30 미만은 LONG_PRESS), 칩에 물결 한 번. 풀기: 핀이 38° 기울며 작아지고 옅어져 사라지고 배지가 1.12배에서 돌아옴. 애니메이션을 끈 기기는 연출 없이 바로 바뀐다. 빌드·실기기 확인 전.

**간이 창(커스텀 탭) 기능 삭제 (v3.9.33)**
- v3.9.27~3.9.32 에서 넣었던 `CustomTabActivity` · `LinkEntryActivity` · `EvergreenCustomTabsService`, `androidx.browser` 의존성, 설정의 「간이 창 연결 확인」, `MainActivity` 의 커스텀 탭 분기를 모두 지우고 http/https VIEW 필터를 `MainActivity` 로 되돌렸다. 구글 앱(서클투서치)이 크롬/삼성 인터넷만 골라 evergreen 이 뽑히지 않는 등 효과가 제한적이어서 뺐다.

**창 잠금 (v3.9.26)**
- 창 칩 메뉴(`showWindowMenu`)에 「창 잠금 / 창 잠금 해제」(`toggleWindowLock`, 본인 확인 없이 바로 토글). 상태는 `Prefs.isWindowLocked/setWindowLocked`(`locked_windows` 번호 집합). 잠긴 창은 메뉴에서 「창 삭제」 항목을 뺀다(열린 창·닫힌 창 모두). 칩 부제에 「· 잠금」. 열기·닫기·이동에는 영향 없음. 빌드·실기기 확인 전.

**열린 창 칩 메뉴도 「창 삭제」 (v3.9.23)**
- `showWindowMenu` 에서 열려 있는 다른 창(1번 제외)의 「창 닫기」를 「창 삭제」로 바꿨다. 누르면 `confirmDeleteOpenWindow(w)` 가 확인 후 `w.discardOnClose = true` → `clearSavedTabsFor` + 이름·순서 정리 → `w.finishAndRemoveTask()`. `saveTabs()` 는 `discardOnClose` 면 바로 반환해서, 창이 닫히며(onPause/onStop) 지운 탭을 다시 저장하지 않는다. 1번 창은 삭제 불가라 열려 있어도 기존 「창 닫기」(`confirmCloseWindow`). 빌드·실기기 확인 전 (컴파일 불가 환경 — 코드만 검토).

**창 칩 꾹 누름 → 메뉴, 이름 변경은 메뉴가 그대로 변함 (v3.9.22)**
- 창 칩(`bindWindowDrag`)을 꾹 눌러 끌지 않고 떼면(또는 450ms 가만히 있으면) 이름 바꾸기 AlertDialog 대신 `showWindowMenu(chip, no)` 가 칩에서 펼쳐진 메뉴(MorphDialog)를 띄운다. 항목: 이름 변경(전부) · 창 닫기(열려 있는 다른 창, 기존 `confirmCloseWindow`) · 창 삭제(닫힌 창, 1번 창 제외 — `clearSavedTabsFor` + 이름·순서 정리). 지금 보는 창은 이름 변경만. 닫힌 창만 진짜 '삭제'(저장된 탭까지 지움), 열린 창은 기존대로 창만 닫는다(탭은 남아 목록에서 다시 열림)라서 이름을 「창 닫기」로 했다.
- 이름 변경: `Popup.Item(keepOpen = true)` 로 메뉴를 닫지 않고 `Popup.input(from = 메뉴)` 를 부른다. `MorphDialog.transformTo(newCard, widthPx)` 가 같은 창·같은 면에서 옛 카드 → 새 카드로 바꿔 끼운다: 면(rect)이 옛 카드 크기에서 새 카드 크기로 스프링(360/0.9)으로 이어서 변하고, 옛 내용은 0~0.3 구간에 옅어지며, 새 내용은 머리말 → 입력칸 → 버튼 순서로 떠오른다. 뒤 화면 어두워짐·블러는 그대로 이어진다. 다 바뀌면 `card` 가 새 카드로 교체돼 이후 닫기는 원래 눌렀던 칩 자리로 접힌다(저장해서 칩이 다시 그려져도 `rebindOrigin` 으로 새 칩을 이어받는다 — `windowMenuDialog`/`windowMenuNo`). 바꾸는 도중에 닫으면 `abortTransition()` 이 끝난 모습으로 맞춘 뒤 닫는다.
- 카드를 자르는 규칙을 `cardOutline` 하나로 모아(`rect` 기준) 옛·새 카드가 함께 쓴다. `Popup.create` 에서 카드 뷰 만드는 부분을 `buildCard` 로 빼서 창 없이 카드만 만들 수 있게 했다. 키보드가 올라와도 가려지지 않게 창을 `ADJUST_RESIZE` 로. 애니메이션을 끈 기기·바꿔 끼우기 불가 상태에서는 메뉴를 걷고 일반 카드 팝업으로 뜬다. 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토).

**팝업이 접힐 때 모서리 굴곡이 버튼과 다르던 것 수정 (v3.9.21)**
- 원인: `MorphDialog` 의 `originRadiusDp` 가 모든 호출에서 기본값 24dp 로 고정이라, `styled()` 로 18dp 모서리를 준 창 칩으로 접힐 때 끝 굴곡이 어긋났다(면 → 칩으로 바뀌는 순간 모서리가 툭 변함).
- 수정: `readOriginLook()` 에서 카드 배경(리플이면 안쪽 면)이 `GradientDrawable` 이고 `cornerRadius > 0` 이면 그 값을 dp 로 바꿔 `originRadius` 로 쓴다. 읽지 못하면(유리 배경 등) 예전처럼 24dp. 빌드·실기기 확인 전.

**팝업이 접힐 때 회색이 남던 것 수정 (v3.9.20)**
- 원인: 탭 화면의 「＋ 새 창」 칩 배경은 `styled()` 가 만든 `RippleDrawable`(눌림 물결 0x22000000 + 면 + 마스크)이다. 칩을 살짝 꾹 눌렀다 떼면 클릭이 나는 순간 물결이 아직 번져 있는데, `MorphDialog.readOriginLook()` 이 이 배경을 통째로 작은 그림에 그려 `startColor`(접혀 들어갈 면 색)를 읽어서 회색 낀 색이 도착 색이 됐다. 바깥을 눌러 닫으면 접히는 면이 그 색으로 변해 끝에 회색이 남았다.
- 수정: 배경이 `RippleDrawable` 이면 물결을 빼고 안쪽 면(첫 번째 층)만 읽는다(유리 배경을 감싼 경우는 예전처럼 통째로). 또 `restoreOrigin()` 에서 칩을 되살릴 때 `jumpDrawablesToCurrentState()` 로 숨은 동안 돌던 물결을 끝낸다. 빌드·실기기 확인 전 (원인 추정).

**닫힌 창 칩으로 탭 카드 끌어 옮기기 · 창 칩 위아래 잘림 · 선택지 양옆 잘림 (v3.9.19)**
- 닫힌 창 칩(`addClosedChip`)이 드롭 대상에 빠져 있었다(`windowChips` 에 안 넣음). 이제 `(칩, null)` 로 넣고 `closedChipNos`(칩 → 창 번호)로 「＋ 새 창」 칩과 가른다. 끌 때 `SwitcherDrag.winClosedNo` 에 번호를 두고, 놓으면 `moveTabToClosedWindow(tab, no)` (창을 열지 않고 저장된 탭 목록 끝에 더함 — 메뉴의 「탭을 다른 창으로 이동」 닫힌 창 항목과 같은 경로) 후 카드가 칩으로 빨려 드는 효과. 닫힌 창 칩 위에서는 새 창 선택창이 열리지 않는다(`winClosedNo == 0` 일 때만). 그룹 카드를 끄는 쪽은 `second != null` 만 받으니 그대로.
- 창 칩 위아래 잘림의 진짜 원인: `windowStripList`(LinearLayout)에 위·아래 padding 이 있고 `clipToPadding` 기본값(true)이라, `clipChildren=false` 여도 padding 안쪽(= 칩 자리)으로 자식을 자른다. v3.9.15 에서 padding 을 늘린 건 효과가 없었고(자르는 영역도 같이 커짐), `clipToPadding=false` + `clipChildren=false` 로 풀었다. 끌어 올린 칩의 1.07배·그림자가 칩 자리 밖으로도 보인다.
- 새 창 선택창에서 손가락 밑 선택지는 1.025배로 키웠는데 목록(스크롤 영역)이 양옆을 잘라 가장자리가 잘려 보였다 → 키우지 않고 덮개 색(+눌림)만 남김. 빌드·실기기 확인 전.

**팝업이 접힐 때 어색하던 것 수정 (v3.9.18)**
- 원인 1: `MorphDialog` 는 닫기를 시작할 때 도착할 칩 자리(`src`)를 한 번만 재고, `rebindOrigin` 은 닫히는 중이면 무시했다. 탭을 옮기면 칩 줄(`refreshWindowStrip`)이 다시 그려져 옛 칩이 화면에서 떨어지는데, 접히는 팝업은 옛 자리로 가거나 제자리에서 줄어들었다. → 접히는 동안 매 프레임 `relocateSrc()` 로 칩의 현재 자리를 다시 재고, 닫히는 중에도 `rebindOrigin` 으로 새 칩을 이어받는다.
- 원인 2: 끌다가 칩에서 벗어나 선택창이 접히는 중에 다시 칩에 닿으면 새 선택창이 겹쳐 열렸다. 새 창은 `originPrevVisibility` 를 이미 숨겨진 칩(INVISIBLE)에서 읽어 닫힌 뒤에도 칩이 안 보였다. → `syncNewWinMenu` 는 이전 선택창이 다 접힐 때까지 60ms 간격으로 기다렸다 열고, 놓을 때 접히는 중인 게 있으면 `dismissNow()` 로 걷은 뒤 연다. 빌드·실기기 확인 전.

**탭 카드를 「＋ 새 창」 칩에 끌면 새 창 선택창이 열리고, 끌어서 고를 수 있음 (v3.9.17)**
- 전에는 카드를 「＋ 새 창」 칩에 놓으면 곧바로 분할(옆에 붙이기)로 새 창이 열렸다. 이제 칩에 닿고 `NEW_WIN_MENU_DELAY_MS`(140ms) 머물면 `chooseNewWindowMode` 의 선택창(전체 화면 · 분할 화면 · 팝업 창)이 칩에서 펼쳐진다(끄는 중 `updateSwitcherDrag` → `syncNewWinMenu` → `openNewWinMenu`).
- 선택창은 별도 창이라 끄는 터치를 못 받는다. 그래서 `Popup.menu(handle = Popup.DragHandle())` 로 항목 뷰·카드 뷰를 넘겨받아, 끄는 쪽이 화면 좌표(`rawX/rawY`)로 `indexAt` 을 물어 손가락 밑 항목을 `highlight`(연한 주색 덮개 + 눌림 + 1.025배) 한다. 선택창이 펼쳐지는 동안 칩은 `INVISIBLE` 이라 `windowChipAt` 이 못 찾으므로, 손가락이 칩 자리와 카드를 함께 감싼 영역(`newWinMenuHolds`) 안이면 계속 칩 위로 본다(폰은 카드가 화면 가운데라 칩에서 카드로 가는 길에 닫히지 않게). 영역을 벗어나면 선택창을 접는다.
- 놓을 때(`endSwitcherDrag`): 선택지 위 → 그 `NewWinChoice` 방식으로 `moveTabToWindow(tab, null, mode, …, adjacent)` (카드가 칩으로 빨려 드는 효과는 그대로). 선택지 밖 → 탭은 옮기지 않고 카드는 제자리로, 선택창은 열린 채 남아 눌러서 고른다(아직 안 열렸으면 그때 연다). 취소(ACTION_CANCEL)면 선택창도 닫는다. 시크릿 탭은 선택창 없이 예전처럼 「시크릿 탭은 새 창으로 옮길 수 없어요」 안내만.
- `moveTabToWindow` 에 `adjacent`(기본 true) 추가: 전체 화면·팝업 창을 고르면 `FLAG_ACTIVITY_LAUNCH_ADJACENT` 를 빼려고 `openNewWindow` 로 넘긴다. 선택지 목록은 `newWindowChoices()` 한 곳에서 만들어 메뉴 항목과 놓을 때의 번호 매핑이 어긋나지 않게 했다.
- 그룹 카드를 끄는 쪽(`swGDrag`)은 원래 「새 창」 칩에 못 놓으니 그대로. 빌드·실기기 확인 전 (이 환경에서는 컴파일 불가 — 코드만 검토).

**탭 카드를 창 칩으로 끌 때 카드가 가려지던 것 수정 (v3.9.16)**
- 원인: `liftCard` 가 카드의 조상들(카드 줄 · `tabList` · `tabScroll`)의 `clipChildren` 은 풀었지만, `tabScroll` 을 담은 FrameLayout 의 부모인 `tabSwitcher` 루트(LinearLayout)는 기본값(true)이라 FrameLayout 영역 밖 — 곧 위쪽 창 칩 줄 — 으로 올라간 카드가 잘렸다(칩 줄이 FrameLayout 앞 형제라 그리는 순서는 문제없음).
- `liftCard` 가 `tabSwitcher.clipChildren` 도 같이 끄고(`lift`), 끌기가 끝나 풀 때 켠다. 다른 카드·그룹 끌기가 아직 진행 중(`swDrag`/`swGDrag`)이면 켜지 않음. 카드·그룹 끌기가 둘 다 `liftCard` 를 쓰니 그룹 끌기도 같이 고쳐짐. 빌드·실기기 확인 전.

**창 칩: 진행 막대 제거 · 자동 열림 시간 단축 · 끌 때 잘림 수정 (v3.9.15)**
- v3.9.14 의 꾹 누르는 진행 막대(`windowHold`, `showWindowHold`/`hideWindowHold`/`prepHold`)를 통째로 뺌. 칩은 번호 배지·테두리·「현재」 알약 디자인만 그대로.
- `AUTO_MENU_MS` 700 → 450ms: 길게 누르기가 인식된 뒤 손을 안 떼고 이만큼 가만히 있으면 메뉴가 열림(탭·그룹·숨긴 탭·창 칩 공통). 시스템 길게 누르기 시간 자체는 그대로.
- 잘림: 칩을 끌면 1.07배로 커지고 `translationZ` 8dp 그림자가 생기는데, 목록(`windowStripList`) 위·아래 여백이 2/8dp 뿐이라 `HorizontalScrollView` 경계에서 잘렸음. 여백을 8/14dp 로 늘리고 `windowStrip` 에 `clipChildren=false` 추가. 빌드·실기기 확인 전.

**창 칩 디자인 개선 + 꾹 누르는 진행 막대 (v3.9.14)**
- `item_window_chip.xml` 을 FrameLayout(높이 56dp)으로 바꿈: 안쪽 가로 줄에 번호 배지(`windowBadge` 28dp 동그라미) · 제목(`windowTitle`, maxWidth 130dp) + 「현재」 알약(`windowNow`) · 부제(`windowSub`) · 닫기 버튼, 그 위에 칩 아래쪽에 깔리는 진행 막대(`windowHold` 3dp). 「현재」는 이름 뒤에 `· 현재` 로 붙이지 않고 따로 알약으로.
- `refreshWindowStrip` 의 `styled` 에 테두리 추가(코너 18dp): 보통 칩 = `colorOnSurface` 14% 헤어라인, 지금 창 = `colorPrimary` 1.5dp 테두리 + `colorPrimaryContainer` 바탕, 닫힌 창·「새 창」 = 점선(`setStroke` dash 5/3dp). 배지: 지금 창은 `colorPrimary` 바탕·`colorOnPrimary` 글자, 다른 창은 `colorPrimaryContainer`, 닫힌 창은 점선 고리만 있는 빈 동그라미, 「새 창」은 `+`. 닫힌 창 칩의 흐림은 0.7 → 0.85(점선이 구분을 맡음). 테마 새 탭 배경(유리 바탕)이면 바탕은 그대로 유리이고 테두리만 빠짐.
- 진행 막대: `startWindowDrag`(길게 누르기 시작) 에서 `showWindowHold` 가 `AUTO_MENU_MS` 동안 `scaleX` 0→1 로 선형으로 채움 — 다 차는 때가 v3.9.13 의 자동 열림(`showRenameWindow`) 시점. `touchSlop`(8dp) 넘게 움직이면(`wsHoldX` 기준) `hideWindowHold` 로 페이드, `endWindowDrag` 에서도 숨김. 모션 끔 상태면 채우지 않고 꽉 찬 막대만 보임. 빌드·실기기 확인 전.

**창 칩도 꾹 눌러 가만히 있으면 이름 바꾸기 창이 자동으로 열림 (v3.9.13)**
- v3.9.11 에서 창 칩(`bindWindowDrag`)만 `autoOpenMs = 0` 으로 꺼 뒀던 것을 풀어서 다른 탭·그룹 메뉴와 똑같이 길게 누른 뒤 `AUTO_MENU_MS`(700ms) 안에 `touchSlop` 넘게 움직이지 않으면 손을 떼지 않아도 `showRenameWindow` 가 열린다(`endWindowDrag(false, false)`). 움직이면 예전처럼 끌어서 순서 바꾸기. 이제 `bindDragGesture` 를 쓰는 곳은 전부 자동 열림이 켜져 있다. 그 밖의 길게 누르기(북마크 바 · 뒤로/앞으로 기록 · 고정 확장 해제 · 기록/북마크/다운로드 선택)는 원래 길게 누르는 순간 바로 열려서 손을 뗄 필요가 없다. 빌드·실기기 확인 전.

**「탭을 다른 창으로 이동」에 닫힌 창도 선택 가능 (v3.9.12)**
- 닫힌 창 = 열려 있는 창이 없고 `savedTabCount(n) > 0` 인 저장된 창(창 칩의 "닫힌 창"과 같은 기준, `closedWindowNos()`). 탭 메뉴와 탭 화면의 선택한 탭 이동 둘 다 열린 창과 닫힌 창을 창 칩 순서(`windowOrder`)대로 섞어 보여 주고, 닫힌 창은 `탭 N개 · 닫힌 창` 으로 표시. 갈 창이 열린 창 하나나 닫힌 창 하나뿐이면 고르는 창 없이 바로 옮기고, 메뉴 설명에 그 창 이름이 나옴.
- 닫힌 창은 열지 않는다. `moveTabToClosedWindow` → `appendTabToSavedWindow` 가 그 창의 저장 JSON(`saved_tabs_w<N>`, 1번은 `saved_tabs`) 의 `tabs` 끝에 `saveTabs` 와 같은 모양으로 항목을 더하고(`group` 0, `hidden` false), 웹 기록은 `tabstate/w<N>/<sid>.bin` 에 `writeTabState` 와 같은 방식(Parcel 로 Bundle 직렬화)으로 씀. `setSavedTabsFor` 가 '열려 있음' 표시를 하므로 바로 `markWindowClosed` 로 되돌림. 그 창을 열면 `restoreTabs` 가 맨 끝에 있는 이 탭까지 되살림.
- 한계: 시크릿 탭은 저장되지 않으니 닫힌 창으로 못 옮김(선택한 탭에 시크릿이 섞여도 닫힌 창은 안 보임). `saveTabs` 가 저장하지 않는 주소(http(s) 아님, 앱 내부 주소)와 이미 40개 찬 창은 거부함. 확대 비율·음소거·재생 속도·스크롤 비율은 저장 형식에 없어 이어지지 않음(웹 기록에 든 스크롤 위치는 따름). 고르는 사이 그 창이 다시 열렸으면 열린 창으로 옮김. 탭을 창 칩에 끌어다 놓는 동작은 이번에 안 건드림(열린 창만). 빌드·실기기 확인 전.

**꾹 눌러 뜨는 메뉴: 손을 안 떼도 자동으로 열림 (v3.9.11)**
- `bindDragGesture` 에 `autoOpenMs`(기본 `AUTO_MENU_MS` = 700ms, 0 이면 끔) 추가. 길게 눌러 끌기가 시작(`onStart` 가 true)된 뒤 이 시간 안에 `touchSlop` 넘게 움직이지 않으면, 손가락이 눌려 있어도 `onEnd(false, false)` 를 불러 "끌지 않고 뗀 것"과 똑같이 마무리한다(탭 메뉴 · 그룹 메뉴 · 숨긴 탭 메뉴). 그때 틱 진동을 한 번 주고, 이후 같은 터치의 이동은 무시하며 떼면(`ACTION_UP`) 아무 일도 없다(`autoFired`).
- 움직이면(`moved`) 예약을 취소하고 예전처럼 끌기. 떼거나 취소돼도 예약을 지움. 다시 누를 때마다 처음부터 센다.
- 적용: 상단 탭 줄 탭·그룹, 탭 화면 탭 카드·그룹 카드·숨긴 탭. 창 칩(`bindWindowDrag`)은 메뉴가 아니라 이름 바꾸기 창이라 `autoOpenMs = 0` 으로 끔. 길게 누르는 시간 자체(시스템 값)는 그대로이고 그 뒤 0.7초 더 누르면 열림. 빌드·실기기 확인 전.

**탭 메뉴: 다른 창이 하나뿐이면 창 이름 표시 (v3.9.10)**
- 「탭을 다른 창으로 이동」은 다른 창이 딱 하나면 고르는 창 없이 바로 옮기는데, 어느 창으로 가는지 알 수 없었다. 그 경우 항목 설명을 `'<windowLabel>'(으)로 지금 상태 그대로 옮깁니다` 로 바꿈(이름을 바꾼 창은 그 이름, 아니면 "창 N"). 창이 둘 이상이면 예전처럼 고르는 팝업과 기존 설명. 탭 화면의 여러 탭 옮기기는 옮긴 뒤 토스트에 창 이름이 나옴(그대로). 빌드·실기기 확인 전.

**업데이트 설치 확인 창이 두 번 뜨던 것 수정 (v3.9.9)**
- 원인: `install()` 이 `commitSession` 으로 설치 세션을 넘기면 시스템 확인 창이 떠서 앱이 `onStop` 되는데, 그때 `installReadyInBackground` 가 받아 둔 APK 가 아직 있다고 보고 세션을 한 번 더 넘겼다(`lastCommitAt` 은 백그라운드 경로에서만 갱신됐음). 그래서 두 번째 확인 창/알림(7701)이 따라와 "또 업데이트하라고 묻는" 것처럼 보였다.
- `commitSession` 을 한 번에 하나만 가게 함: `sessionAt`(넘긴 시각)이 10분 안이면(`SESSION_HOLD_MS`) 건너뜀. 설치기 결과(성공·취소·실패)가 오면 `ResultReceiver` 가 `sessionAt` 을 풀고 알림 7701 을 지움. 새 세션을 만들기 전에 이 앱의 남은 세션을 `abandonSession` 으로 정리.
- `install()` 에서 `readyPrompted = true`, `lastCommitAt` 갱신 → 설치 확인 창에서 돌아왔을 때 "업데이트 준비됨" 창이 또 뜨지 않음. 설치가 진행 중(`sessionInFlight`)이면 그 창도 건너뜀. 실기기 확인 전.

**확장 프로그램 팝업: 오른쪽 빈 공간 수정 · 태블릿은 버튼 아래에 붙음 (v3.9.8)**
- 원인: 카드 폭을 `max(360dp, scrollWidth)` 로 잡았는데 `documentElement.scrollWidth` 는 보이는 폭(`clientWidth`)보다 작게 나오지 않는다. 그래서 `body{width:324px}` 처럼 폭이 정해진 좁은 팝업 페이지(예: Entry Sync)는 카드가 360dp 밑으로 못 줄고 오른쪽 36dp 가 비었다(`html` 배경색만 보임). 주석에는 "짧으면 짧게 맞춘다"고 돼 있었지만 구현되지 않았음.
- 폭 재기: 가로로 넘치면(`scrollWidth > clientWidth`) 넘치는 폭, 아니면 `min(body 오른쪽 끝+오른쪽 마진, html 오른쪽 끝)`. 폭이 흐르는(fluid) 페이지는 이 값이 지금 폭과 같아 줄지도 늘지도 않고, 폭이 정해진 페이지만 그 폭으로 줄어든다. 가운데 정렬(`margin: 0 auto`)된 고정 폭 페이지는 마진이 자동이라 폭이 안 줄고 카드 안에서 가운데에 놓인다.
- 폭 결정: 넓어지는 쪽은 바로, 좁아지는 쪽은 페이지가 다 불러와진 뒤(`onProgressChanged` 100 또는 1.5초) 첫 측정은 바로, 이후는 연달아 3번 같은 결과일 때만(흔들림 방지). 카드 폭은 180ms 애니메이션.
- 구조 변경: 창을 카드 폭으로 줄이던(`window.setLayout(w, WRAP)`) 방식 → 창은 화면 전체를 덮는 투명한 틀(`root`)이고 카드가 그 안에서 폭·자리를 가짐. 바깥(`root`) 클릭으로 닫고, 카드는 `isClickable` 로 클릭을 삼킴. 폰은 `Gravity.CENTER`(기존과 같은 자리·등장 모션), 태블릿(`screenWidthDp >= 600`)은 `TOP|START` + 마진.
- 태블릿 자리: `ExtensionPopup.show(..., anchor)` 의 버튼 아래, 버튼이 화면 오른쪽 절반이면 버튼 오른쪽 끝에·왼쪽이면 왼쪽 끝에 맞춤(화면 밖으론 안 나감). 좌표는 `getLocationOnScreen` 끼리 빼서 창 안 좌표로 환산(분할·떠 있는 창 대응). 버튼을 못 쓰면 `MainActivity.listAnchorInfo()`(상단바 메뉴 버튼) 아래, 그것도 없으면 오른쪽 위. 호출부: 상단바 고정 버튼(`launchPinnedExt(e, btn)`), 확장 프로그램 목록(`extAnchorRef`). 등장은 버튼 가운데 아래에서 펼쳐지는 `Popup.prepareAnchoredEnter/playAnchoredEnter`, 닫을 때는 `Evergreen.MenuPopupAnim`.
- 높이 한도(`maxBody`)는 창이 가장 컸을 때(`baseH`) 기준: 폰은 86%, 태블릿은 버튼 아래부터 화면 아래까지. 키보드가 올라와 창이 줄어도 내용을 덩달아 줄이지 않음. 사이드 패널은 그대로. 빌드·실기기 확인 전.

**자동 스크롤: 맨 아래 판정을 스크롤 위치 기준으로 (v3.9.6)**
- 기존 `endSince` 는 `scrollBy` 후 `scrollY` 가 안 바뀔 때만 쌓여서, 맨 아래에서 페이지 길이가 계속 늘어나는 페이지(광고 · 지연 로딩)는 1px 씩 움직여 영영 `stop()` 에 못 갔다.
- `onFrame` 에 `bottomSince` 추가: `contentHeight * scale - height - scrollY <= 4dp`(맨 아래) 상태가 `END_HOLD_MS` 이어지면 이동 여부와 상관없이 `stop(null)`. 한 번이라도 움직인 뒤(`everMoved`)에만 판정. 조작 막대 유무와 무관. 실기기 확인 전.

**(v3.9.5 의 '웹툰 끝 확인 뒤 맨 아래에 닿으면 끄기' 변경은 증상과 달라서 v3.9.7 에서 되돌림. 그 갈래는 v3.9.4 와 같이 `finishWebtoonEnd()`)**

**자동 스크롤: 페이지 끝에서 끄기 (v3.9.4)**
- `AutoScroller.onFrame`: 더 못 내려가는 채로 `END_HOLD_MS` 가 지나면, 예전에는 조작 막대가 있을 때 `pauseAtEnd`(일시정지)였지만 이제는 `stop()` 으로 끄고 막대도 닫는다. 웹툰 마지막 컷에서의 일시정지(`autoScrollPauseAtWebtoonEnd`)는 그대로.

**둘러보기 중 창 크기·비율 변경 대응 (v3.9.3)**
- `Overlay` 가 `wide`(폰/태블릿)를 시작 때 값으로 굳히지 않고 `MainActivity.isWideLayout()` 으로 매번 읽는다. 단계 목록은 전부 담아 두고 `live()`(그 버튼이 지금 보이는가)로 보여 줄 때마다 거른다 → 단계 번호(n / N)와 문구도 새 모드에 맞게 바뀐다.
- `onSizeChanged` 에서 안내를 감추고 0.25초 뒤 같은 단계를 다시 그린다(`relayout`). 버튼이 아직 자리를 못 잡았으면 0.2초 간격으로 최대 8번 다시 본 뒤에야 건너뛴다(레이아웃이 바뀌는 중에 안내가 끝나 버리지 않게).

**둘러보기 AI 챕터 폰 대응 (v3.9.2)**
- 폰의 AI 버튼은 하단바에 동적으로 만들어져 id 가 없어서, `Spec.desc` 로 `bottomBar` 안에서 contentDescription("AI 어시스턴트")이 같은 뷰를 찾는다. 챕터 목록은 항상 다 보여 주고, 안내할 버튼이 없으면 `Chapter.hint` 를 토스트로 알린다.
- 메뉴 안 항목(번역 · PiP 등)을 직접 짚지 않는 이유: 메뉴는 폰 BottomSheetDialog · 태블릿 PopupWindow 라 별도 창이라서, 액티비티 위에 얹는 오버레이가 못 가린다. 직접 짚으려면 메뉴 창 안에 오버레이를 넣어야 한다.

**둘러보기 기능별 선택 안내 (v3.9.1)**
- `Tutorial.CHAPTERS`: 탭 다루기(태블릿은 `btnStripNewTab` · `tabStripBar` · `btnStripTabList`, 폰은 `btnBottomTabs`) · 메뉴 속 기능(메뉴 버튼에 번역 · PiP · 북마크/기록 · 설정 설명) · AI 어시스턴트(`tbAi` 가 보일 때만). 가리킬 버튼이 하나도 안 보이는 챕터는 선택 목록에서 빠짐.
- 설정 > 「둘러보기 다시 보기」가 이제 `Tutorial.chooser` 대화상자(처음 둘러보기 + 챕터)를 연다.

**처음 켰을 때 둘러보기 · 업데이트 뒤 신기능 안내 (v3.9.0)**
- 새 파일 `Tutorial.kt`: 화면 위에 어두운 막(`Path` EVEN_ODD 로 안내할 버튼만 뚫음)을 덮고 말풍선을 붙이는 스포트라이트 오버레이. 밝은 곳을 누르면 다음 단계, '건너뛰기'로 종료. 안내 버튼 id 는 폰(`urlBar` · `btnBottomTabs` · `btnMenu`) / 태블릿(`tabStripBar` · `tbMenu`)이 다르고, 홈 카드(`homeShortcuts` · `homeAdCard`)는 공통. 안 보이는 단계는 건너뜀.
- 새로 설치한 경우(`firstInstallTime` 과 `lastUpdateTime` 차이 1분 미만)에만 처음 둘러보기를 자동으로 띄움 (`Prefs.tutorialDone`). 업데이트로 들어온 사용자는 `tutorialDone` 을 true 로 두고 `TOUR` 중 안 본 것만 "새 기능을 둘러볼까요?"로 물음 (`Prefs.tourLevel`). 어떤 답을 해도 다시 묻지 않음.
- 첫 창(1번)에서 직접 켠 경우에만 실행. 링크·공유로 열렸거나 창이 다시 만들어진 경우(다크 모드 전환 등)는 건너뛰고 다음 실행에 다시 시도.
- 설정 > 앱 정보 > 「둘러보기 다시 보기」(홈이 아니면 새 홈 탭을 열고 시작).

**홈 검색 위젯 제거 (v3.8.97)**
- `SearchWidgetProvider`, 위젯 레이아웃·정보 xml·배경 드로어블(`widget_*`), 위젯 문자열, 매니페스트의 receiver 를 모두 삭제. 새 탭 홈 화면용 `bg_home_widget` 은 위젯이 아니라 남김. 이전 위젯 설명(v3.8.94~96)은 더 이상 해당 없음. 빌드 전.

**위젯 모서리 곡률을 시스템 값으로 (v3.8.96)**
- 고정 28dp/24dp/18dp 였던 모서리가 One UI 창 애니메이션 곡률과 달랐음 → `drawable-v31/` 에 `widget_bg`(`system_app_widget_background_radius`), `widget_search_bg`·`widget_btn_bg`(`system_app_widget_inner_radius`) 를 두어 안드로이드 12+ 는 런처가 정한 곡률을 따름. 12 미만은 기존 값. 실기기 확인 전.

**홈 검색 위젯 레이아웃 되돌림 (v3.8.95)**
- v3.8.94 의 고정 높이(56+48dp)가 태블릿 셀 높이보다 커서 잘렸을 것으로 보고, 높이를 다시 비율(weight 1.2 : 1)로 나눔. 늘어남은 `maxResizeHeight` 200dp 상한으로 막음. 기본 높이 120dp, 버튼 줄은 100dp 미만이면 숨김. 실기기 확인 전.

**홈 검색 위젯 크기·전환 개선 (v3.8.94)**
- 태블릿 홈 격자에서 위젯이 너무 작았음 → 기본 크기 4x2 → 5x2(`minWidth` 320dp · `minHeight` 140dp), 검색창 56dp · 버튼 줄 48dp 고정 높이, 글자·아이콘 키움.
- 크게 늘리면 내용까지 과하게 늘어났음(weight 로 높이를 나눴음) → 고정 높이 + 가운데 정렬, `maxResizeWidth` 520dp · `maxResizeHeight` 200dp 로 상한. 버튼 줄은 높이 128dp 미만이면 숨김.
- 위젯을 눌러 열 때 런처가 위젯 모양을 창 크기로 부풀리던 전환 → `PendingIntent` 에 페이드 `ActivityOptions` 지정. 런처(One UI Home)가 자체 전환을 우선하면 완전히 바뀌지 않을 수 있음. 실기기 확인 전.

**자동 업데이트가 안 되던 것 수정 (v3.8.93)**
- 원인 1: `autoCheck` 가 확인 시각을 먼저 저장해서, 오프라인·403 으로 확인이 실패해도 6시간 동안 다시 확인하지 않았음 → 간격 30분(`AUTO_INTERVAL_MS`), 실패 시 5분 뒤 재시도(`RETRY_MS`, 시계를 `now - 간격 + 5분` 으로 돌려 둠). 프로세스당 한 번만 확인하던 `autoChecked` 는 없애고 `onResume` 마다 간격만 따짐('업데이트 준비됨' 창만 프로세스당 한 번, `readyPrompted`).
- 원인 2: 조용히 받는 동안 앱을 떠나면 `onStop` 의 `installReadyInBackground` 가 이미 지나가서 아무도 설치하지 않았음 → `downloadQuietly` 가 다 받은 뒤 `AppForeground.current() == null` 이면 직접 `installReadyInBackground`. 동시 다운로드는 `quietBusy` 로 막음, 같은 설치는 1분 안에 다시 걸지 않음(`lastCommitAt`).
- 원인 3: '이 출처 허용'(`canRequestPackageInstalls`)이 꺼져 있으면 `installReadyInBackground` 가 말없이 반환 → 새 버전마다 한 번 `askInstallPermission` 으로 이유를 알리고 허용 화면으로 안내(`KEY_PERM_ASKED`, 허용하러 가면 확인 시계를 0 으로).
- 원인 4: 설치기가 `STATUS_PENDING_USER_ACTION` 을 알릴 때 `ResultReceiver` 가 뒤에서 `startActivity` 했는데 안드로이드 10+ 는 막음 → 앱이 화면에 있을 때만 직접 열고, 아니면 알림(채널 `app_update`, id 7701)의 눌러서 열기로 알림.
- 원인 5: 수동 설치(`install`)가 `ACTION_VIEW` 라 설치자가 시스템 설치기로 남아 안드로이드 12+ 의 `USER_ACTION_NOT_REQUIRED`(확인 없는 업데이트)가 영영 적용 안 됐음 → `commitSession`(설치기 세션)으로 바꿔 이 앱이 설치자가 되게 함. 세션이 예외를 내면 예전 `installViaView` 로 폴백.
- 첫 업데이트는 여전히 한 번 확인이 필요할 수 있음(설치자가 이 앱으로 바뀌는 때). 실기기 확인 전.

**설정: 다른 설정에 반응하는 항목이 바로바로 바뀜 (v3.8.92)**
- `showMenu` 안에 `syncers`/`syncSettings()` 추가. `addToggle`·`addKeepRow` 가 줄을 만들 때 그 줄의 '지금 값'(스위치 상태 · 부제 글자)을 다시 읽는 함수를 약한 참조로 등록하고, 스위치를 누른 뒤 `syncSettings()` 가 등록된 줄 전부를 새로 읽음. 줄이 지워져(검색 결과 등) 참조가 비면 목록에서 빠짐.
- `addToggle` 의 `checked` 를 `Boolean` → `() -> Boolean` 으로 바꿔 호출부 48곳 모두 `{ prefs.xxx }` 꼴로 변경(값을 등록 시점에 굳히지 않고 매번 읽기 위함).
- 이로써 바로 바뀌는 것: 스마트 자동 스크롤 → 「자동 스크롤 속도」 설명, 조작 막대 → 「웹툰 끝에서 일시정지」 설명, 같은 설정을 두 군데에서 보여 주는 스위치(악성 사이트 경고 알림 ↔ 악성 사이트 접속 알림, 시스템 미디어 플레이어에 표시 ↔ 미디어 컨트롤 알림), 보안 스위치 → 「보안 현황」 요약, 광고 차단 스위치 → 광고 차단 현황 숫자.
- 「유튜브 광고 미리 지우기」는 `ytAdPrune()` 이 `ytAdBlock && ytAdPrune` 일 때만 동작하므로, 「유튜브 광고 차단」이 꺼져 있으면 설명을 「지금은 쓰이지 않아요」로 바꿔 보여 줌.
- 번역 설정처럼 별도 팝업(저장 버튼)으로 열리는 설정은 대상 아님. 실기기 확인 전.

**홈 화면 검색 위젯 추가 (v3.8.91)**
- `SearchWidgetProvider`(AppWidgetProvider) + `res/xml/search_widget_info.xml` + `res/layout/widget_search.xml`. 4×2 칸 기본, 가로·세로 크기 조절 가능(`minResizeHeight` 56dp). 위젯 이름은 `widget_label`(evergreen 검색).
- 위쪽 알약 검색창 → `WEB_SEARCH`, 아래 버튼 셋 → `NEW_TAB` · `NEW_INCOGNITO` · `BOOKMARKS`. 런처 바로가기(shortcuts.xml)와 같은 액션이라 `MainActivity.handleAppShortcut` 을 그대로 탐(콜드 스타트는 `onCreate`, 실행 중이면 `onNewIntent` → `handleIncomingIntent`). 위젯 쪽은 `setClassName` + `FLAG_ACTIVITY_NEW_TASK`, `PendingIntent` 는 `FLAG_IMMUTABLE`, 버튼마다 requestCode 가 다름(1~4).
- 위젯은 `?attr` 를 못 쓰므로 `widget_bg`/`widget_search_bg`/`widget_btn_bg` 는 `@color/ev_*` 만 사용 → `values-night` 로 다크 모드 자동 대응. 아이콘은 `android:tint`.
- 높이가 90dp 미만으로 줄면 `onAppWidgetOptionsChanged` 에서 버튼 줄(`widget_actions`)을 숨기고 검색창만 남김. `updatePeriodMillis=0`(내용이 변하지 않음).
- 미리보기: 안드로이드 12+ 는 `previewLayout`, 그 미만은 `widget_preview` 정적 그림. 아직 실기기 확인 전.

**상/하단바 AI 버튼 애니메이션 새로 만듦: 피어남 (v3.8.90)**
- 이전 안(큰 별이 오므라들었다 부풀며 작은 별·작은 반짝임 둘이 뜸, 3.8.88 로 내려보내지 않고 폐기)을 버리고 `MorphIconDrawable` 의 `ai` 를 다시 설계. v3.8.89 에 있던 바깥으로 퍼지는 파동은 요청으로 뺌.
- 누르는 동안(`holdLevel` 0.5): 별이 12% 작아지며 둥글게 오므라듦(`buildBigStar(m)`: 별 ↔ 같은 네 꼭짓점의 타원, 곡선 조절점을 `m` 으로 섞음, `m` > 1 이면 꼭지가 더 뾰족).
- 떼면(`play`): `swap`(0→1, `AI_MS`=900ms 시계)이 흐름을 정함 — 0~0.16초 씨앗(크기 0.3, 타원)으로 모임(세제곱 가속), 이후 감쇠 진동 `x = 1 − e^-6.5τ·cos 10τ` 으로 크기(0.3→1)와 모양(`m`)이 같이 피어나며 최대 13% 넘침, 속이 최대 18% 로 채워졌다 빔(glow), 작은 별은 0.14~0.7초에 `sin(π·u^0.55)` 로 톡 튀어 올랐다 천천히 돌아옴(최대 55%).
- 피어나는 중에 또 누르면 모양은 건드리지 않고(`press` 가드) 떼면 처음부터 다시. 돌거나 기울지 않는 규칙은 그대로. 작은 반짝임 둘과 파동은 없음.

**AI 어시스턴트 버튼: 열려 있으면 닫기 (v3.8.87)**
- `AssistantUi.show` 의 토글 조건을 `splitPanel != null` → `isOpen()`(분할 패널·팝업·시트) 으로 넓힘. 팝업은 바깥 터치가 AI 버튼까지 전달돼서 `show()` 가 `closeChat(false)` 후 다시 열기만 했음. `anchor != null && prefill 없음` 일 때만 닫으므로 「AI에게 물어보기」·모드 전환 재열기(`closeNow()` 뒤라 `isOpen()` 거짓)는 그대로. 닫는 중(`closingPopup`)에 또 눌러도 `closeChat` 이 그대로 둬서 다시 열리지 않음.

**자동 스크롤 웹툰 끝 멈춤 추가 거리 32dp → 310dp (v3.8.86)**
- v3.8.84 의 `END_EXTRA_DP` 를 310 으로. 실기기 화면(네이버 웹툰, 태블릿)에서 기존 멈춤 자리(마지막 컷 크레딧이 보이는 자리)와 원하는 자리(별점·좋아요 칸이 위로 올라온 자리)의 차이가 화면 453px ≈ 310dp(탭 줄 44dp = 64px 로 환산, 밀도 ≈ 1.45)였음. 끝 확인 시점부터 이만큼 더 내려간 뒤 멈춤.

**팝업 창에서 메뉴 「새 창」 설명의 '분할' 글씨 제거 (v3.8.85)**
- 메뉴의 `newWindowRow` 부제를 `isFloatingWindow()` 이면 "전체 · 팝업 중에 골라 한 개 더 띄웁니다", 아니면 기존 "전체 · 분할 · 팝업 …" 으로 표시 (선택 팝업의 분할 항목은 v3.8.83 에서 이미 뺌).

**자동 스크롤 웹툰 끝 멈춤: 조금 더 아래에서 멈춤 (v3.8.84)**
- 끝 감지(`probeWebtoonEnd`)가 두 번 연속 끝으로 읽히면 바로 `pauseAtEnd` 하던 것을, `endExtraPx = dp(END_EXTRA_DP=32)` 만큼 더 내려간 뒤 `finishWebtoonEnd()` 로 멈추게 변경. `onFrame` 에서 실제로 스크롤된 거리만큼 `endExtraPx` 를 깎고, 더 못 내려가면(페이지 끝) 남은 거리를 기다리지 않고 바로 멈춤. 위로 `END_REARM_PX` 이상 올라가거나 사용자가 일시정지/이어가기·새 페이지 이동 시 대기 중인 거리는 0 으로 초기화.
**팝업 창에서는 새 창 선택에 분할 항목을 뺌 (v3.8.83)**
- v3.8.82(팝업 창을 저장 후 전체 화면으로 다시 열고 옆에 새 창을 붙이는 `splitFromFloatingWindow`)는 창을 다시 여는 방식이라 영상·입력이 끊겨 제거. 떠 있는 창(`isFloatingWindow()`: 멀티윈도우 + `floatingWindowBounds() != null`)에서는 `LAUNCH_ADJACENT` 가 무시돼 분할이 안 되므로 `chooseNewWindowMode` 가 「분할 화면」 항목을 목록에서 뺌(전체 화면·팝업 창만). 실기기 확인 전
**분할 화면에서도 새 창 전체 화면·팝업이 고른 방식으로 열림 (v3.8.81)**
- 창이 분할(멀티윈도우)일 때 `startActivity` 로 `ADJACENT` 없이 열면 시스템이 새 작업을 출발 작업과 같은 분할 칸에 넣어서, `windowingMode`(전체 1·자유 창 5) 요청이 무시되고 분할로 열렸음. `openNewWindow` 에서 `mode` 가 `WIN_FULL`·`WIN_POPUP` 이고 `isInMultiWindowMode` 이면 `applicationContext.startActivity(NEW_TASK 추가)` 로 열어 출발 작업을 없앰(분할 칸 상속 방지). 예외가 나면 예전처럼 `startActivity`. 기기가 자유 창을 지원하지 않으면 팝업은 여전히 전체로 열릴 수 있음. 실기기 확인 전
**탭 화면 「＋ 새 창」 팝업: 바깥을 눌러 닫을 때 새 칩으로 접힘 (v3.8.80)**
- v3.8.78(고른 뒤 접힘이 끝나야 새 창을 여는 방식)은 되돌림. 진짜 원인은 `refreshWindowStrip()` 이 `box.removeAllViews()` 로 칩을 전부 다시 만들어, 팝업이 떠 있는 동안 눌렀던 「＋ 새 창」 칩(`origin`)이 화면에서 떨어져 나가는 것. 그러면 `MorphDialog.locateOrigin()` 이 접혀 들어갈 자리를 못 찾아 '제자리에서 90%로 줄며 사라지는' 대체 동작으로 빠졌음.
- `MorphDialog.origin` 을 `var` 로 바꾸고 `rebindOrigin(newOrigin)` 추가(옛 칩 복원 → 새 칩을 이어받아 INVISIBLE). `MainActivity.newWindowDialog` 로 떠 있는 팝업을 기억해 두고, `refreshWindowStrip()` 이 새 「＋ 새 창」 칩을 만든 직후 호출. 닫히는 중(`closing`)이면 건드리지 않음. 실기기 확인 전. (v3.8.79 는 `origin` 을 `var` 로 바꾼 뒤 `snapshotOrigin()` 의 스마트 캐스트 컴파일 오류로 빌드 실패 → 지역 변수 `o` 로 한 번만 읽도록 고쳐 v3.8.80)
**새 창 선택 팝업 줄 곁 배치는 태블릿(screenWidthDp ≥ 600)에서만 (v3.8.77)**
- v3.8.76 의 `nearOrigin` 을 `Popup.create` 에서 `nearOrigin && isTablet(ctx)` 로 제한. 폰은 v3.8.75 처럼 줄에서 출발해 가운데로 펼쳐짐. 실기기 확인 전
**새 창 선택 팝업이 누른 줄 곁에 뜸 (v3.8.76)**
- v3.8.75 의 모핑 팝업이 줄에서 출발해 화면 '가운데'로 펼쳐지던 것을, 누른 줄 곁에서 끝나게 변경. `MorphDialog(nearOrigin = true)`: 카드를 `TOP|START` + 마진으로 놓고, 첫 레이아웃 뒤 `placeNearOrigin()` 이 줄의 가로 가운데 · 줄 윗변부터 아래로 자리를 잡음(아래가 모자라면 줄 아랫변에 맞춰 위로, 시스템바 안쪽 12dp 여백으로 clamp). `Popup.menu/create` 에 `nearOrigin` 추가, `chooseNewWindowMode` 만 true. 새 탭 개인정보 카드 팝업은 그대로 가운데. 실기기 확인 전
**새 창 선택: 누른 줄이 팝업으로 변형 (v3.8.75)**
- v3.8.74 의 `menuAnchored`(점에서 펼쳐짐)를 `Popup.menu(origin = 눌린 줄)` → `MorphDialog`(컨테이너 트랜스폼: 크기·위치·모서리·색이 한 스프링으로 변하고 닫을 때 그 줄로 접힘)로 교체. `Popup.menu` 에 `origin` 매개변수 추가(주면 태블릿 앵커 팝업·`Motion.stagger` 는 건너뜀). 애니메이션을 끄거나 줄을 못 쓰면 가운데 팝업. 실기기 확인 전
**새 창 선택이 누른 자리에서 펼쳐지는 팝업 (v3.8.74)**
- v3.8.73 의 가운데 대화상자를 `Popup.menuAnchored`(누른 점에서 카드째 펼쳐지고 접히는 기존 팝업)로 교체. 메뉴의 「새 창」 줄은 메뉴를 닫지 않고 그 줄 자리에서 팝업을 띄우고, 고르면 메뉴를 닫은 뒤 새 창을 연다. 아래 공간이 모자라면 위로 뜬다. 창 목록의 「＋ 새 창」도 같은 방식. 앵커를 못 쓰면 `Popup.menu`(가운데 팝업). 아이콘 `ic_window_full`, `ic_window_split` 추가, 팝업은 `ic_pip`. 실기기 확인 전
**새 창 열기 방식 선택: 전체 · 분할 · 팝업 (v3.8.73)**
- 메뉴 > 새 창(과 창 목록의 「＋ 새 창」)을 누르면 `chooseNewWindowMode()` 대화상자. 전체 = `WIN_FULL`(ADJACENT 없이, 전체 화면 모드 요청), 분할 = 기존 기본(ADJACENT), 팝업 = `WIN_POPUP`(화면 중앙 자유 창). 시스템이 모드 요청을 무시하면 평소처럼 열림. 실기기 확인 전
**창 최대 5개, 넘으면 가장 먼저 연 창 자동 정리 (v3.8.72)**
- `MainActivity.MAX_WINDOWS = 5`. 새 창이 만들어질 때(`onCreate`) 떠 있는 창이 5개를 넘으면 `openSeq`(연 순서)가 가장 작은 창을 `finishAndRemoveTask()` 로 닫고 안내 토스트를 띄움. 닫힌 창의 탭은 기존 창 닫기와 같이 보존. 대표(primary) 창이 정리 대상이면 새 창이 대표를 이어받음. `openSeq` 는 `onSaveInstanceState` 로 보존. 실기기 확인 전
**작업 표시줄 새 창: 크롬과 같은 진입점 구조 (v3.8.71)**
- 크롬 158 APK 매니페스트 분석: 런처 진입점이 중계 창이 아니라 `activity-alias`(`Main`) 로 실제 화면(`ChromeTabbedActivity`)을 바로 가리키고, 그 화면은 `launchMode=singleTask` + 메타데이터 `android.activity.launch_mode=singleInstancePerTask`, 멀티 인스턴스 속성은 별칭·화면 양쪽에 있음.
- 같은 구조로 변경: `LauncherActivity` 중계 창 삭제, 같은 이름의 `activity-alias` 가 `MainActivity` 를 바로 가리킴(이미 고정한 아이콘 호환). `MainActivity` 는 singleTask + singleInstancePerTask 메타데이터. 바로가기(shortcuts) 메타데이터는 별칭으로 이동. 실기기 확인 전
**작업 표시줄 새 창: 놓은 쪽에 새 창 (v3.8.70)**
- 영상 확인: 작업 표시줄에서 아이콘을 오른쪽에 놓으면 시스템이 떠 있던 작업을 오른쪽으로 옮기고 새 창은 반대쪽(왼쪽)에 열렸음. `LauncherActivity` 가 기존 작업 위에 만들어지는(`isTaskRoot` false) 경우, 새 창을 `LAUNCH_ADJACENT` 없이 같은 자리에 별개 작업으로 띄우고, 떠 있던 창은 `NEW_TASK|LAUNCH_ADJACENT` 로 반대쪽에 붙여 앞으로 가져옴. 실기기 확인 전
**작업 표시줄 새 창: 중계 창이 직접 새 창을 띄움 (v3.8.68, 버전만 3.8.69 로 올림)**
- 문서(Android 15 멀티 인스턴스)상 시스템 UI 는 런처 MAIN 인텐트를 NEW_TASK/MULTIPLE_TASK/LAUNCH_ADJACENT 로 새 작업에 요청하는 방식. v3.8.67 은 떠 있는 창(`host.openNewWindow()`)을 거쳐 새 창을 열어, 시스템이 방금 만든 작업 대신 기존 창이 움직이는 것처럼 보일 수 있었음. 이제 `LauncherActivity` 가 `MainActivity.openWindowFromLauncher(this)` 로 자기 컨텍스트에서 `BrowserWindowActivity` 를 NEW_DOCUMENT|MULTIPLE_TASK|LAUNCH_ADJACENT 로 직접 띄움 (실패 시 기존 방식으로 대체). 실기기 확인 전
**작업 표시줄 새 창: 플래그 없이도 새 창 (v3.8.67)**
- v3.8.66 에서 "이미 실행 중" 메시지는 사라졌지만 새 창 대신 기존 창이 움직임. 삼성 작업 표시줄이 MULTIPLE_TASK/LAUNCH_ADJACENT 플래그 없이 런처를 실행해 `LauncherActivity` 가 `MainActivity` 를 같은 작업에 열었기 때문. 이제 중계 창이 만들어졌을 때 떠 있는 창이 있으면(평범한 아이콘 탭은 시스템이 중계 창 없이 기존 작업을 앞으로 가져옴) 플래그와 무관하게 `openWindowFromLauncher()` 로 새 창을 띄움. 실기기 확인 전

**런처 중계 창 `LauncherActivity` (v3.8.66)**
- 크롬·삼성 인터넷은 되는데 에버그린만 작업 표시줄에서 끌어다 놓을 때 "이미 실행 중입니다" 가 떠서, 런처 진입점(MAIN/LAUNCHER)을 실제 화면 `MainActivity` 에서 화면 없는 중계 창 `LauncherActivity` 로 옮김. 중계 창은 `onCreate` 에서 바로 끝남: 새 창 요청(MULTIPLE_TASK/LAUNCH_ADJACENT)이고 떠 있는 창이 있으면 `MainActivity.openWindowFromLauncher()` 로 새 창을 옆에 띄우고, 아니면 `MainActivity` 를 연다. 이미 떠 있을 때 아이콘 탭은 시스템이 기존 작업을 앞으로 가져옴. 바로가기·공유·링크 열기는 그대로 `MainActivity`. 실기기 확인 전

**작업 표시줄 끌어다 놓기 "이미 실행 중입니다" 재시도 (v3.8.65)**
- 시스템(삼성)이 앱에 닿기 전에 막는 메시지라 앱 코드로는 못 고침. 매니페스트만 보강: MainActivity 에 `launchMode="standard"` 명시, 삼성 멀티 인스턴스 메타데이터 키 변형(`com.samsung.android.multiwindow.multi_instance`, `...multiwindow.multiinstance.enable`)과 `android.allow_multiple_resumed_activities` 추가. 실기기(One UI 8 / Android 16) 확인 전

**꾹 누르기 메뉴 동안 자동 스크롤 멈춤 (v3.8.64)**
- `AutoScroller.holdForMenu(hold)` + `menuHold` 플래그. `showLinkMenu` 가 메뉴를 띄울 때 true, 메뉴 `setOnDismissListener` 에서 false. 메뉴가 떠 있는 동안은 손을 뗀 뒤에도 `onFrame` 이 스크롤·웹툰 끝 감지를 건너뛰고, 닫히면 `RESUME_DELAY_MS` 뒤 이어서 흐름. 자동 스크롤이 안 돌 땐 무시. 빌드 전

**웹툰 끝 서서히 정지 (v3.8.63)**
- 조작 막대(`pill`) 없이 웹툰 끝 감지 시 `endFadeStart` 로 `END_FADE_MS`(900ms) 동안 속도를 (1-t)² 로 줄인 뒤 `stop(null)`. 정지 토스트 제거(웹툰 끝·페이지 끝 정지 모두; "자동 스크롤할 수 없어요"는 유지). 화면을 만지면 감속 취소. 빌드 전

**조작 막대 꺼짐 시 웹툰 끝 정지 (v3.8.62)**
- 동작은 v3.8.60 부터 이미 그랬음(`probeWebtoonEnd`: `pill` 없으면 `stop`). 설정 토글 설명만 조작 막대 꺼짐일 때 "일시정지 대신 정지"로 보이게 수정.

**웹툰 끝 일시정지 옵션 (v3.8.61)**
- `Prefs.autoScrollPauseAtWebtoonEnd`(기본 true) + 설정 > 자동 스크롤 「웹툰 끝에서 일시정지」 토글. 꺼지면 `AutoScroller.onFrame` 이 `probeWebtoonEnd` 를 돌리지 않아 웹툰 끝 감지·일시정지를 건너뜀. 페이지 맨 끝(스크롤 더 못 내려감)에서의 일시정지/정지는 그대로. 빌드·실기기 확인 전

**웹툰 끝 자동 멈춤이 안 되던 문제 (v3.8.60)**
- `END_PROBE_JS`: (1) 아직 안 불러온 지연 로딩 그림이 페이지 어디에든 있으면 9999 를 돌려 끝으로 못 보던 것 → 본문 끝 `b` 에서 400px 이내(+화면 중간보다 아래)의 미로딩 그림만 센다(`P` 배열). 댓글·추천 썸네일이 data-src/lazy 면 영원히 안 멈추던 원인. (2) 컷 폭 기준 `W*0.6` → `TW=min(W*0.6, 480)`: PC 모드(창 폭이 큰 페이지)에서 컷이 60% 미만이라 웹툰으로 안 보던 것 보정.
- `AutoScroller.onFrame`: 끝 감지를 조작 막대(`pill`) 유무와 상관없이 돌리고, 막대가 없으면 일시정지 대신 `stop`. 노드로 JS 문법만 확인, 실기기 확인 전
**AI 버튼이 계속 분할로 열리던 문제 (v3.8.59)**
- 원인: 분할 패널을 끌어 떼면(`lift`) `split=false` 로 바뀌는데, 놓을 때 터치가 CANCEL 로 끊기면 `splitDragListener` 가 `zone = side` 로 `dockSplit` 을 호출해 `split=true` 로 되돌렸음 → 다음 AI 버튼이 `showSplit`. CANCEL 은 이제 `undockToPopup`. 또 `snapZone` 이 지난 끌기 값으로 남아 그냥 눌렀다 떼도 붙을 수 있어 `lift`·팝업 끌기 DOWN 에서 0 으로 초기화. 실기기 확인 전
**「AI에게 물어보기」 바로 전송 (v3.8.58)**
- `AssistantUi.show(..., autoSend: Boolean = false)` 추가. `autoSend` 이고 `prefill` 이 있으면 창을 연 뒤 `ui.post { send(prefill) }`. 사진 첨부는 `send` 안의 `attachLoading` 대기 로직으로 다 받은 뒤 전송됨. Gemini 키가 없으면 `send` 가 설정 안내를 띄우고 질문은 입력창에 남음. 꾹 누르기 메뉴(링크·이미지)와 글자 선택 팝업 두 호출부(`MainActivity`)에서 `autoSend = true`. 빌드·실기기 확인 전

**글자 선택 메뉴 '웹 검색' (v3.8.57)**
- `NestedWebView.onWebSearch` + `AskAiCallback` 에 `WEB_SEARCH_ID` 항목 추가(「AI에게 물어보기」 옆). 누르면 선택한 글을 JS 로 읽어 `MainActivity` 가 `prefs.currentEngine().url(query)` 를 새 탭(`createTab`, 현재 탭이 시크릿이면 시크릿 유지)으로 연다. 300자까지. 실기기 확인 전

**웹툰 끝 감지 보강 (v3.8.56)**
- `END_PROBE_JS` 재작성: 폭 60%↑·높이 40px↑ 의 img/canvas(없으면 배경그림 요소 최대 1500개)를 세로 간격 250px 이내로 묶어 가장 큰 덩어리(3장↑ 또는 화면 3배↑)의 아래 끝을 본문 끝으로 봄. 높이 200px 미만 얇은 컷·긴 그림 1장·배경그림 뷰어도 감지. 아래에 아직 안 불러온 그림이 있으면 9999 를 돌려 끝으로 보지 않음. 끝이 -300~900px 이내면 확인 주기를 200ms 로 줄여 지나침을 줄임(`endNextMs`).
- `AutoScroller.onPageNavigate`: 일시정지 중 새 페이지로 넘어가면 `stop` 대신 끝 상태만 초기화하고 막대 유지(`MainActivity.onPageStarted`). 흐르는 중이면 전처럼 stop. 실기기 확인 전

**웹툰 끝 감지 후 일시정지 (v3.8.55)**
- `AutoScroller.probeWebtoonEnd`: 0.4초마다 `END_PROBE_JS` 로 폭 60%↑·높이 200px↑ 큰 그림이 3장 이상인 페이지(웹툰 뷰어)의 '마지막 컷 아래 끝 − 화면 아래 끝'(CSS px)을 읽어, 12px 이내가 두 번 연속이면 `pauseAtEnd`. 한 번 멈춘 뒤엔 300px 넘게 멀어질 때까지 재감지 안 함(`endHandled`). 기존 페이지 끝(`END_HOLD_MS`) 일시정지는 보조로 유지. 조작 막대(`pill`)가 있을 때만 동작. 지연 로딩·광고 배너 오감지는 실사이트 확인 필요
**자동 스크롤 끝에서 일시정지 (v3.8.54)**
- `AutoScroller.onFrame`: 더 못 내려가는 상태가 `END_HOLD_MS` 지속되면, 한 번이라도 움직였고 조작 막대(`pill`)가 있을 때는 `stop()` 대신 `userPaused = true` + `refreshPauseButton` 으로 일시정지(▶ 표시). 막대가 없으면(설정에서 끔) 이전처럼 `stop()`. 이어가기는 기존 `togglePause()` 그대로. 실기기 확인 전
**악성 사이트 경고 알림을 '보안'으로 이동 (v3.8.53)**
- 설정 > 알림에서 `악성 사이트 경고 알림`(`toggleMalwareWarning`) 행을 '백그라운드' 앞 `sub("보안")` 끝으로 옮김. 동작 변경 없음, 검색 그룹 목록만 갱신. 실기기 확인 전
**알림 설정 '보안' 항목 (v3.8.52)**
- 설정 > 알림에 `sub("보안")` 신설: `notifyAutoDlBlocked`(자동 다운로드 차단 토스트, `setDownloadListener`), `notifyBackBlocked`(뒤로가기 자동 이동 차단 토스트), 기존 `notifyRedirectBlocked`(이동 차단 안내)를 '앱 안 안내'에서 이 항목으로 옮김. 기본 켜짐. 꺼도 차단 자체와 보안 현황 집계(`SecurityStats`)는 그대로고 안내만 숨김. 설정 검색 키워드·그룹 목록 갱신.
**AI 답변 알림 설정 즉시 반영 (v3.8.51)**
- `AiKeepAliveService`: 알림 채널(`CH`/`CH_HIDDEN`)을 서비스 시작 때 한 번만 골라서, 답을 받는 도중 토글을 바꿔도 다음 질문부터 적용되던 것을 `running` 플래그 + `refresh()` 로 토글 즉시 `onStartCommand` 를 다시 불러 알림을 다시 올림(꺼져 있으면 아무 것도 안 함, 웨이크락은 중복 획득 안 함). 실기기 확인 전
**알림 설정이 안 먹던 문제 수정 (v3.8.50)**
- `DownloadService`: 서비스 유지용 알림이 `notifyDownloadProgress` 와 상관없이 `CH_SERVICE`(MIN)로 항상 보이던 것을, 진행 알림을 끄면 `CH_SERVICE_HIDDEN`(IMPORTANCE_NONE)으로 보냄. 받는 도중 설정이 바뀌면 `notifyProgress` 가 `svcHidden` 과 비교해 서비스 알림을 다시 올림.
- `DownloadNotifier.postSystemDone`: `notifyDownloadDone` 이 꺼져 있으면 그냥 return 해서 ongoing 진행 알림(같은 id)이 영원히 남던 것을 `cancel(id)` 후 return.
- 시스템 `DownloadManager` 대체 다운로드: 알림 가시성을 설정에 맞춤(진행+완료=NOTIFY_COMPLETED, 진행만=VISIBLE, 완료만=NOTIFY_ONLY_COMPLETION, 둘 다 꺼짐=HIDDEN). HIDDEN 때문에 `DOWNLOAD_WITHOUT_NOTIFICATION` 권한 추가.
- `requestNotificationPermission`: 이미 한 번 물어서 거절됐거나 시스템 설정에서 앱 알림이 꺼져 있으면(`areNotificationsEnabled()==false`) 세션당 한 번 '설정' 버튼이 달린 안내를 띄워 `ACTION_APP_NOTIFICATION_SETTINGS` 로 보냄. 실기기 확인 전
**탭 화면 카드 폭 맞춤 (v3.8.49)**
- 3.8.48 의 고정 폭(176dp)은 남는 폭이 오른쪽에 빈 자리로 남아 폐기. 열 수를 `round((화면폭dp-24)/188)`(최소 2, 상한 없음)로 정하고 카드는 예전처럼 가중치로 폭을 나눠 가짐 → 빈 자리 없이 채우면서 카드 폭은 목표(약 176dp)의 ±(0.5/열 수) 안에 머묾(8열이면 ±6%).

**"+N" 알약 크기 고정 (v3.8.47)**
그룹/숨긴 탭 카드 그림(400×320 비트맵)이 FIT_CENTER 로 카드 크기에 따라 같이 커져 알약도 커지던 것을, `bindPreview` 가 레이아웃 후 표시 배율을 재서 알약 높이를 24dp 로 맞춰 다시 그리게 함 (글자 0.625배, 폭 최소 1.35배).

**"+N" 알약 크기 줄임 (v3.8.46)**
글자 44→30px, 알약 높이 72→48px, 최소 폭 96→64px.

**탭 화면 그룹 카드 "+N" 표시 개선 (v3.8.45)**
네 번째 칸의 까만 막과 큰 글씨를 없애고, 실제 탭 그림 위에 밝은 반투명 막 + 둥근 "+N" 알약을 올림 (숨긴 탭 카드도 동일, 흐림 처리 뒤에 그려 글자는 또렷함).

**새 탭 '개인정보' 제목 숨기기 (v3.8.44)**
- `layout_home.xml`: `homeWidgetHeader`(텍스트 '개인정보')에 `visibility="gone"`. 코드(`styleHomeTexts`·`alignWidgetToTiles`·테마 색 적용)가 이 뷰를 찾아 색·패딩을 만지므로 삭제하지 않고 숨김만 함(findViewById null 방지). 제목이 빠진 자리에 맞춰 `homeAdCard` 윗 여백 12dp→32dp (즐겨찾기 줄과 카드 사이가 붙지 않게).

**광고 차단 아이콘 작대기: 살짝 줄이고 두껍게 (v3.8.43)**
- `ic_shield_person`: 작대기 반폭 0.62→0.85, 상자와의 틈 반폭 1.32→1.55(보이는 틈 0.7 은 그대로), 작대기 끝은 중심에서 축마다 ±9.6→±8.8(상자 밖으로 삐져나온 길이 약 3→2). 상자·글자는 v3.8.42 와 같음.

**광고 차단 아이콘: 상자 줄이고 작대기 늘리기 (v3.8.42)**
- `ic_shield_person`: v3.8.41 의 `<group>` 0.85배 축소를 없애고 24×24 좌표에서 직접 다시 계산. 상자 (3.5,5.25)-(20.5,18.75) 반지름 2.2, 글자 배율 1.2(전엔 1.5×0.85), 작대기 반폭 0.62·틈 반폭 1.32(보이는 굵기는 v3.8.41 과 같음), 작대기 끝은 중심에서 축마다 ±9.6(전엔 약 ±8) → 상자 밖으로 약 3 더 삐져나옴. 36dp ImageView·tint 규칙은 그대로.

**광고 차단 아이콘 크기 줄이기 (v3.8.41)**
- `ic_shield_person`: 그림 전체를 `<group>` 으로 감싸 중심(12,12) 기준 0.85배로 축소. layout 의 36dp ImageView 와 `applyHomeGlassToWidgets` tint 규칙은 그대로라 레이아웃·카드 높이 변화 없음. 보안 카드 아이콘(방패 폭 16)과 크기를 맞추는 정도(상자 폭 21 → 약 17.9).

**광고 차단 아이콘을 AD 상자 + 대각선 작대기로 (v3.8.40)**
- `ic_shield_person`: 'AD' 글자가 evenOdd 로 뚫린 큰 둥근 상자(1.5,3.5)-(22.5,20.5) 가운데로 좌상→우하(x=y) 대각선 작대기(반폭 0.72, 둥근 끝)를 긋고, 작대기 양옆 반폭 1.55 를 상자에서 비워 띠 모양 틈을 둠. 틈은 vector `clip-path` 대신 꼭짓점을 직접 잘라 계산(반평면 클리핑)해서 가장자리가 계단지지 않음 → 두 반쪽 path(evenOdd) + 작대기 path(nonZero) 로 구성. 글자는 v3.8.39 의 A·D 윤곽을 1.5배 키워 상자 중앙에 둠. v3.8.39 의 '금지 표시 고리' 방식 대체.

**광고 차단 아이콘 다시 만들기 (v3.8.39)**
- `ic_shield_person`: 'AD' 글자가 evenOdd 로 뚫린 광고 배너(1.5,2.5)-(19,14.5) + 오른쪽 아래 금지 표시(중심 18,18 · 바깥 5.5 · 안쪽 3.7 고리 + 대각선 띠). 배너 오른쪽 아래는 금지 표시 둘레 1.2 간격으로 둥글게 파서(반지름 6.7 호) 겹치지 않음 → v3.8.38 의 '글자를 대각선으로 가르는' 방식(글자가 작고 읽기 어려웠음)을 대체. 배너·금지 표시는 별도 `<path>`(배너 evenOdd, 금지 표시 nonZero). 실기기 확인 전

**(바뀜) 광고 차단 아이콘 / 보안 아이콘 원복 (v3.8.38)**
- `ic_shield_person`(광고 카드): 'AD' 광고 금지 표시. 고리(바깥 CW · 안쪽 CCW) + 대각선(좌상→우하) 띠 + 글자 A(왼쪽 아래 반쪽)·D(오른쪽 위 반쪽)를 대각선이 가르도록 배치. 겹치는 도형이 합쳐지게 nonZero 로 채움(구멍은 반대 방향). 글자가 대각선과 겹치면 뭉개져서 반쪽씩 나눠 둠.
- `ic_shield_check_filled`(보안 카드): v3.8.35 의 체크 방패(evenOdd)로 원복. 실기기 확인 전

**(바뀜) 새 탭 개인정보 카드 아이콘을 광고·보안 내용에 맞게 (v3.8.37)** (v3.8.36 의 방패 두 톤 + 44dp 받침 디자인은 되돌림: 레이아웃·`applyHomeGlassToWidgets` 는 v3.8.35 와 동일)
- `ic_shield_person`(광고 차단 카드): 'AD' 글자가 evenOdd 로 뚫린 둥근 광고 배너. `ic_shield_check_filled`(보안 현황 카드): 자물쇠(몸통·걸쇠)가 뚫린 방패. 파일 이름은 그대로(레이아웃 참조 유지), 단색 면 + tint 방식도 그대로.
- 카드 첫 자식은 36dp ImageView 여야 함(`applyHomeGlassToWidgets` 가 tint). 실기기 확인 전

**(되돌림) 새 탭 개인정보 카드 아이콘 방패 두 톤 + 받침 (v3.8.36)**
- 아이콘 모양을 내용(광고·보안)과 상관없이 방패로 꾸미는 쪽이어서 v3.8.37 에서 되돌림.

**탭 화면 아래 버튼 그림자·테두리 (v3.8.35)**
- `applyAppChromeColors`: `btnNewIncognito`/`btnNewTab` 에 `stateListAnimator=null` + `elevation=5dp`(Material 버튼 기본 눌림 elevation 제거, 그림자 고정). `btnNewIncognito` 는 `strokeWidth=1dp` · `strokeColor=primary α0x59`(선택 막대 `applySelectBarColors` 와 동일). `switcherBottom` 에 `clipChildren=false`/`clipToPadding=false` 로 그림자가 잘리지 않게 함. 실기기 확인 전

**그룹 밖으로 끌어낼 때 순서 바꾸기와 같은 동작 (v3.8.34)**
- `updateOutPreview`/`resetOutPreview`: `leaving` 중 손가락(카드 중심)이 그룹에 속하지 않은 탭 카드 위에 있으면 그 카드부터 뒤 카드들이 한 칸씩 비켜 줌(맨 뒤 카드는 같은 줄 오른쪽 / 다음 줄 왼쪽의 추정 칸). 놓으면 그 카드 바로 앞(`tabs.indexOf`)에 삽입, 어느 카드 위도 아니면 v3.8.33 의 `dropIndexAt`(가장 가까운 칸 앞/뒤). 그룹 안으로 돌아오거나 다른 그룹·창 칩 위·취소면 카드들을 제자리로. 실기기 확인 전

**그룹에서 끌어낸 탭을 놓은 자리에 두기 (v3.8.33)**
- `endSwitcherDrag` 의 `leaving` 분기: 예전엔 그 그룹 바로 뒤(`indexOfLast{groupId}+1`)에 고정. 이제 `SwitcherDrag.dropX/dropY`(카드 중심, `updateSwitcherDrag` 가 갱신)로 `dropIndexAt` 가 가장 가까운 칸(그룹에 속하지 않은 탭 카드 / 그룹 상자·접힌 카드)을 찾아 앞(위·왼쪽)이면 첫 탭 자리, 뒤면 마지막 탭 뒤에 삽입. 칸이 없으면 예전 위치로. 탭 줄(상단) 드래그는 건드리지 않음. 실기기 확인 전

**숨긴 탭 카드 제스처 (v3.8.32)**
- 펼친 숨긴 탭 카드에 `bindDragGesture` 적용(일반 탭 카드와 동일): 옆으로 밀기 → `closeHiddenTab`, 꾹 눌렀다 끌지 않고 떼기 → `showTabMenu(hidden=true)`. 순서 바꾸기 끌기는 없음(`onStart` 는 true 만 반환, `onMove` 비움). 이 호출이 `setOnLongClickListener`·터치 리스너를 설정하므로 같은 카드의 `Motion.pressable` 호출은 제거. 실기기 확인 전

**숨긴 탭 메뉴에서 탭 닫기 제거 (v3.8.31)**
- v3.8.30 의 `showTabMenu(hidden=true)` 에서 「탭 닫기」 항목 삭제(일반 탭 메뉴에도 없음). 닫기는 카드 X(`closeHiddenTab`). 실기기 확인 전

**숨긴 탭 꾹 누르기 메뉴 (v3.8.30)**
- `showTabMenu(tab, anchor, hidden=true)`: 일반 탭 메뉴 재사용. 숨긴 탭은 `tabs` 밖이라 「탭 숨기기」·창 이동·그룹 항목은 빼고(그룹 이동은 `tabs` 에 다시 넣어 버림) 음소거·북마크 + 「숨김 해제」「탭 닫기」만. v3.8.29 의 임시 2항목 메뉴를 대체. 실기기 확인 전

**숨긴 탭 삭제 (v3.8.29)**
- 탭 화면에서 펼친 숨긴 탭 카드: X(`tabClose`)를 「숨김 해제」→「탭 닫기」로 바꿈(`closeHiddenTab`: hiddenTabs 에서 제거 · 웹뷰 destroy · saveTabs). 숨김 해제는 카드 탭(해제하고 열기) 또는 꾹 누르기 메뉴([숨김 해제 / 탭 닫기]).
- 숨긴 탭이 「최근 닫은 탭」(`rememberClosed`)에 남아 되돌리기로 노출되지 않게 기억하지 않음 → 되돌리기 없음. 실기기 확인 전

**새 탭 버튼 줄 플로팅 (v3.8.28)**
- `layout_tab_switcher.xml`: `switcherBottom`(시크릿 탭/새 탭)도 `tabScroll` 과 같은 `FrameLayout` 안 `bottom` 으로 옮겨 목록 위에 겹침(`switcherBottomHost` 삭제). `tabScroll` 아래 패딩을 항상 88dp 로(평소·선택 모드 공통)하고 v3.8.26 의 `swapBottom` 패딩 코드는 제거. 버튼 모양·여백·교대 애니메이션은 그대로. 실기기 확인 전

**웹페이지 꾹 누르기 메뉴 깜빡임 수정 (v3.8.27)**
- 원인 추정: `Popup.menuAnchored` 가 `Blur.behindPopup` 으로 창 뒤 블러(FLAG_BLUR_BEHIND / 대체 BackdropView·RenderEffect)를 거는데, 뒤가 WebView 라 깜빡임(태블릿은 이미 같은 이유로 블러 제외 — `Blur.tablet` 주석). 재현·실기기 확인 전.
- 수정: `menuAnchored(blurBehind=false)` 추가 → 블러를 걸지 않고 카드 바탕은 불투명(`anchoredBackground(glass=false)`). `showLinkMenu` 의 꾹 누르기 메뉴만 `blurBehind=false`. 다른 메뉴·팝업은 그대로.

**선택 막대 플로팅 (v3.8.26)** (v3.8.25 의 알약·그림자 디자인 변경은 되돌림: 막대 디자인은 v3.8.24 와 동일)
- `layout_tab_switcher.xml`: `tabScroll` 과 `selectBar` 를 `FrameLayout`(weight 1)로 묶고 `selectBar` 를 `bottom|center_horizontal` 로 목록 위에 겹침(이전: 아래 자리 `switcherBottomHost` 안). 아래 자리에는 [시크릿 탭/새 탭] 버튼만 남음.
- `swapBottom`: 선택 모드 동안 `tabScroll` 아래 패딩 88dp(평소 8dp) → 마지막 카드도 막대 위로 스크롤 가능. 실기기 확인 전

**탭 화면 전환 중 스크롤 시 카드 위치 어긋남 수정 (v3.8.24)**
- 원인: `openTabSwitcher` 가 morph 도착 사각형(`rectInRoot(thumb)`)을 시작 시점에 한 번만 계산해, 전환 중 `tabScroll` 이 움직이면 도착점과 실제 카드 위치가 달라짐(끝에서 카드가 튀는 듯 보임).
- 수정 1: `runMorph` 에 `toLive` 인자 추가 → 매 프레임 `rectInRoot(thumb)` 로 도착 사각형을 다시 구해 따라감(열 때만 사용).
- 수정 2: `dispatchTouchEvent` 에서 `switcherBusy` 중 `tabScroll` 영역에서 시작한 터치는 끝(UP/CANCEL)까지 삼킴(열고 닫는 전환 모두). 실기기 확인 전

**하단 내비게이션 바 투명 처리 롤백 (v3.8.23)**
- v3.2.71 의 `makeNavBarTransparent()`(navigationBarColor 투명 · `isNavigationBarContrastEnforced=false` · navigationBarDividerColor 투명)와 호출 2곳(`installCaptionIntegration`, `enableCaptionEdgeToEdge`)을 삭제하고, `values`·`values-night` `themes.xml` 의 `navigationBarColor`/`navigationBarDividerColor`/`enforceNavigationBarContrast` 항목도 삭제(Material3 기본값으로 복귀). 실기기 확인 전
- 인셋 처리(`setDecorFitsSystemWindows(false)` 등)는 건드리지 않음.

**선택 막대 테두리 (v3.8.22)**
- `applySelectBarColors`: 막대 바탕에 `setStroke(1dp, colorPrimary α0x59)` 추가(테마 색을 따라감). 실기기 확인 전

**로딩 안 된 탭 전환: 잎사귀 빼기 (v3.8.21)**
- v3.8.20 은 카드(잎사귀 포함)를 `drawToBitmap` 으로 찍어 펼쳐서 잎사귀가 커졌음. 이제 `colorSurface` 로 칠한 8×8 단색 비트맵을 morph 이미지로 사용(잎사귀 없음). 끝에서 `hideMorph(fade=true)` 는 그대로. 실기기 확인 전

**로딩 안 된 탭 열 때 전환 애니메이션 (v3.8.20)**
- 원인: `closeTabSwitcher` 의 morph 조건에 `tab.thumb != null` 이 있어, 미리보기 사진이 없는 탭(지연 복원된 탭, 카드엔 잎사귀 자리표시)은 morph 를 건너뛰고 기본 폴백(브라우저 0.95배 + alpha)으로 바로 넘어감.
- 수정: `thumb` 이 없으면 카드의 `tabThumb`(자리표시)을 `drawToBitmap` 으로 찍어 morph 이미지로 쓰고, 끝날 때 `hideMorph(fade = true)` 로 진짜 화면 위에서 서서히 걷음(자리표시는 실제 화면과 달라 겹쳐 보이지 않음). 사진이 있는 탭은 기존 그대로. 실기기 확인 전

**선택 막대 디자인을 앱 컨셉에 맞춤 (v3.8.19)**
- 문제: 떠 있는 상자(elevation 6dp + 테두리 + 모서리 22dp, 바탕 `colorSurfaceContainerHighest`) · 아이콘 20dp · 글자 11sp 라서 같은 자리의 「새 탭/시크릿 탭」 버튼 줄(톤 면 · 14dp · 가장자리 여백 18dp)과 모양이 달랐고, 테마 색도 따르지 않았음.
- `layout_tab_switcher.xml` `selectBar`: 여백 14→18dp(버튼 줄과 같은 폭), elevation 제거, minHeight 56dp, 항목 아이콘 `@dimen/ev_icon`(24dp)·글자 12sp·위아래 padding 8dp, 항목 배경은 새 `bg_select_item`(10dp 둥근 리플).
- `applySelectBarColors()`(`setupSelectBar`·`applyAppChromeColors` 에서 호출): 막대 바탕 = `colorSecondaryContainer`(모서리 14dp, 테두리 없음), 아이콘·글자 = `colorOnSecondaryContainer`, 닫기만 `ev_danger`(Popup 의 danger 항목과 같음). 실기기 확인 전

**「이동」 아이콘 화살표 키움 (v3.8.18)**
- `ic_window_move`: 창 윤곽을 x3~14 로 줄이고 화살표를 별도 path(선 2.2, 샤프트 8.5→21, 머리 16.5~21 × 8~17)로 키움. v3.8.17 은 20dp 에서 화살표가 작고 가늘어 잘 안 보였음. 실기기 확인 전

**선택 막대 「이동」 아이콘 교체 (v3.8.17)**
- 새 `ic_window_move`(창 윤곽 + 오른쪽으로 나가는 화살표, 24dp·선 1.8)로 `ic_folder_move` 를 대체. `layout_tab_switcher.xml` 의 `selectMove` 와 `moveSelectedTabs` 팝업 `headerIcon` 두 곳에 적용, 옛 `ic_folder_move.xml` 삭제(「그룹」 `ic_folder_plus` 와 둘 다 폴더 모양이라 헷갈렸음). 실기기 확인 전

**탭 화면 「새 탭」 애니메이션 수정 (v3.8.16)**
- 원인: 탭 화면(switcherOpen)에서 새 탭을 만들면 `selectTab`/`updateUi` 가 등장 애니메이션(`playNewTabEnter`)을 건너뛰고 `homeContent` 순차 등장(stagger)만 탭 화면 뒤에서 먼저 재생됨 → 이어서 `closeTabSwitcher()` 는 새 탭 카드·썸네일이 없어 기본 폴백(브라우저 전체 0.95배 + alpha 0→1)을 탐.
- `openNewTabFromSwitcher`: 탭 화면의 「새 탭」·「시크릿 탭」·그룹 메뉴 「이 그룹에 새 탭」이 사용. `newTabFromSwitcher` 플래그로 `updateUi` 의 stagger 를 미루고 `closeTabSwitcher(newTabEnter = true)` 호출.
- `closeTabSwitcher(newTabEnter)`: morph 끔, 상·하단 막대는 그대로 두고 새 화면(홈 또는 웹뷰)에 `playNewTabEnter` + 홈 stagger(60ms 지연), 탭 화면은 stiffness 650 으로 걷음. 실기기 확인 전

**펼친 그룹 상자 끌기 개선 (v3.8.15)**
- `updateSwitcherGroupDrag`: 상자(isBox) 드래그는 translationX=0(세로만), 자리 판정점을 가운데 대신 손가락 위치로(큰 상자는 가운데 기준이면 한참 끌어야 비켜 줬음). 카드 드래그는 v3.8.10 그대로. 실기기 확인 전

**접힌 그룹 속 탭의 탭 화면 전환 애니메이션 (v3.8.14)**
- `switcherCardFor(tab)`: `switcherRows[tab]` 이 없으면(접힌 그룹) `switcherGroupCells[group.id]` 카드를 돌려줌. `openTabSwitcher`/`closeTabSwitcher` 의 morph 대상·시작 카드에 사용(전엔 카드가 null 이라 페이드만 됐음). 실기기 확인 전

**선택 막대 축소 (v3.8.13)**
- 아이콘 26→20dp, 글자 12.5→11sp, 위아래 padding 10→6dp, 아이콘-글자 간격 6→3dp, 모서리 32→22dp, 태블릿 폭 520→400dp. 실기기 확인 전

**접힌 그룹 카드 끌기 = 탭 카드와 동일 (v3.8.12)**
- `SwGroupDrag.winChip/winTarget`: 접힌 그룹 카드(!isBox)가 창 칩 위로 가면 0.62배·alpha 0.85·칩 강조(탭 끌기와 같음), 놓으면 소속 탭을 모두 `moveTabToWindow` 로 옮기고 칩으로 빨려 들어감. 「새 창」 칩(target=null)은 그룹엔 무시(탭마다 새 창이 열리는 걸 막음). 칩 위에서는 순서를 원래대로 돌려 둠. 실기기 확인 전

**그룹 끌기 앞쪽 이동 버그 · 밖으로 끌 때 안 보임 (v3.8.11)**
- v3.8.10 의 `updateSwitcherGroupDrag` 에서 카드끼리 past=true 로 두어 뒤로(앞쪽으로) 가는 이동(ok=!past)이 막히던 것: 카드끼리는 방향 상관없이 ok. 
- `syncLeaveGhost`: 그룹 안 탭이 자기 상자 밖으로 나가면(leaving) 카드 비트맵을 `tabSwitcher.overlay` 에 띄우고 진짜 카드는 alpha 0 (상자·줄에 가려지거나 잘리는 걸 피함). 끝/칩 위/뷰 사라짐 때 정리. 원인은 코드만으로 확정 못 함 — 실기기 확인 필요

**탭 화면: 그룹 탭 밖으로 빼기 · 그룹 끌기 타이밍 (v3.8.10)**
- `SwitcherDrag.ownBox/leaving`: 그룹 안 탭의 가운데가 자기 상자 밖(다른 상자·창 칩 위가 아닐 때)이면 leaving(카드 alpha 0.8, 햅틱). 놓으면 `groupId=0` 으로 빼서 그 그룹 마지막 탭 바로 뒤에 둔다. 접힌 그룹은 탭이 안 보여 해당 없음.
- `updateSwitcherGroupDrag`: 판정점을 손가락→끄는 덩어리 가운데로, 카드끼리는 중심 넘기 조건 없이 바로 자리 바꿈(상자가 끼면 기존 조건 유지). 실기기 확인 전

**탭 줄 그룹 끌 때 불투명 (v3.8.9)**
- `startStripGroupDrag` 에서 그룹 소속 탭 칩의 `bg.alpha=255`(개별 탭 끌기와 동일), 끝/취소 때 `applyChipSelection` 으로 복원. 실기기 확인 전

**탭 그룹 카드 미리보기 양옆 여백 (v3.8.8)**
- 접힌 그룹 카드 `tabThumb` scaleType CENTER_CROP→FIT_CENTER (숨긴 탭 카드와 동일, v3.8.7). 실기기 확인 전

**숨긴 탭 카드 미리보기 양옆 여백 (v3.8.7)**
- 숨긴 탭 카드 `tabThumb` 의 scaleType 을 CENTER_CROP→FIT_CENTER 로(400×320 비트맵이 넓은 카드에서 좌우가 잘리던 것). 실기기 확인 전

**숨긴 탭 카드 가운데 자물쇠 축소 (v3.8.6)**
- `hiddenPreviewBitmap`(400×320 비트맵) 가운데 배지 원 반지름 62→42(20 줄임), 아이콘 68→46px. 오른쪽 위 작은 자물쇠는 그대로. 실기기 확인 전

**태블릿 선택 막대 폭 제한 (v3.8.3)**
- `selectBar` 폭을 `@dimen/select_bar_width` 로(기본 -1px=match_parent, `values-sw600dp` 에서 520dp) + `layout_gravity=center_horizontal`. 실기기 확인 전

**선택 막대 「잠금」→「숨기기」 (v3.8.2)**
- `selectHide` 의 글자를 숨기기, 아이콘을 `ic_visibility_off` 로 변경(동작은 그대로 `hideSelectedTabs`). 실기기 확인 전

**선택 막대 개편: 이동·그룹·잠금·공유·닫기 (v3.8.1)**
- `selectBar` 를 아이콘(위)+글자(아래) 5칸 균등 막대로 교체(`selectMove/Group/Hide/Share/Delete`, id 는 기존 이름 재사용). 전체 선택은 제목줄 `btnSelectAll`(선택 모드에서만 보임, 문구는 전체 선택/선택 해제). 새 아이콘 `ic_folder_move`·`ic_folder_plus`·`ic_tab_close`. 잠금=`hideSelectedTabs`, 그룹=`groupSelectedTabs`, 닫기=`confirmCloseSelected`(기존 확인창), 이동=`moveSelectedTabs`(다른 창이 하나면 바로, 여럿이면 `Popup.menu` 로 선택, 없으면 토스트. 새 창으로 여러 탭 보내기는 없음), 공유=`shareSelectedTabs`(주소 있는 탭만, 제목+주소 줄바꿈 연결). 고른 게 없으면 alpha 0.38 + 반응 없음. 예전 삭제 알약·전체 선택 체크 코드는 제거(`delPill*`, `selAllCheck` 필드는 남아 있으나 안 씀). 실기기 확인 전

**선택 모드: 숨김·그룹 (v3.8.0)**
- 선택 막대(`selectBar`)에 `selectHide`(눈 꺼짐)·`selectGroup`(폴더) 아이콘 버튼 추가(고른 게 없으면 alpha 0.38 + 눌러도 반응 없음). `hideSelectedTabs`: 시크릿 제외, 현재 탭은 마지막에, `hideTab(quiet=true)` 로 토스트·다시 그리기 없이 숨기고 마지막에 한 번만 갱신. `groupSelectedTabs`: `Popup.menu`(새 그룹 → `showGroupEditor`, 기존 그룹 추가, 그룹에서 빼기)로 고른 뒤 `moveToGroup`. 둘 다 끝나면 선택 모드를 끔. 폭이 아주 좁은 폰(<~330dp)에서는 막대가 빡빡할 수 있음. 실기기 확인 전

**숨긴 탭 블러를 칸마다 따로 (v3.7.99)**
- `groupPreviewBitmap(blurEach=true)`: 2×2 칸을 각각 별도 비트맵에 그려 칸마다 4×3 → 16×12 → 원래 크기로 뭉갠 뒤 합침(이전엔 합친 그림 전체를 6×5 로 줄여 네 탭 색이 섞였음). `hiddenPreviewBitmap` 은 이것을 쓰고 자물쇠 배지만 올림. 칸 안 흐림 정도는 이전보다 약간 약해 보일 수 있음(칸이 작아서 같은 비율로 줄이면 오히려 더 뭉개짐). 실기기 확인 전

**탭 화면 그룹 끌기: 실시간 자리 비킴 (v3.7.98)**
- v3.7.97 의 '놓을 대상 강조 + 놓을 때 이동' 을 탭 카드 끌기와 같은 방식으로 교체. `SwGroupDrag` 가 덩어리(`SwUnit`: 탭 카드/접힌 그룹 카드/펼친 상자) 순서 `order` 를 들고, 손가락이 다른 덩어리 위로 가서 앞으로는 중심을 넘으면·뒤로는 중심 앞이면 `order` 에서 위치를 옮기고 `previewSwitcherGroupOrder` 로 나머지를 새 자리로 미끄러뜨림(되돌아가며 깜빡이지 않게 중심 기준 비대칭). 카드(정사각)·상자(가로 전체) 크기가 달라 `simulateSwitcher` 가 cols 열 격자를 흉내 내 자리를 계산하고, 처음 순서로 계산한 자리와의 차이만 translation 으로 씀. 숨긴 탭 카드/상자는 맨 끝에 고정으로 끼워 계산. 놓으면 `tabs` 를 `order` 대로 다시 채우고 `refreshSwitcher(false)`. 실기기 확인 전(자리 계산이 실제 레이아웃과 어긋나는지 확인 필요)

**탭 화면 그룹 끌어서 순서 바꾸기 (v3.7.97)**
- 접힌 그룹 카드(`addGroupCell`)·펼친 그룹 줄(`addGroupHeader`, 숨긴 탭 제외·선택 모드 제외)에 `bindDragGesture` 연결 → `startSwitcherGroupDrag`. 끄는 뷰는 접힌 카드면 그 카드, 펼쳤으면 상자(`switcherBoxes`) 전체. 놓을 수 있는 대상은 `tabUnits` 의 다른 덩어리(탭 카드/그룹 카드/상자)이고 손가락이 올라간 덩어리가 1.04배로 강조됨. 놓으면 `moveGroupUnitNextTo`(대상이 원래 앞이면 앞, 뒤면 뒤)로 `tabs` 순서를 바꾸고 `refreshSwitcher(false)`. 덩어리 크기가 달라 다른 카드들이 미리 비켜 주지는 않음(놓은 뒤 기존 glide 로 이동). 자동 스크롤은 `swAutoScroll` 공유. 끌지 않고 떼면 접힌 카드만 그룹 메뉴. 실기기 확인 전

**그룹 알약 끌어서 순서 바꾸기 (v3.7.96)**
- 상단 탭 줄의 그룹 알약(`bindStripPill`)에 `bindDragGesture` 연결(길게 누름 → `startStripGroupDrag`). 알약 + 펼쳐진 그룹 탭들(`groupStripViews`)이 같이 `translationX` 로 손가락을 따라가고, 이웃 덩어리(`tabUnits` 기준 탭 하나/그룹)의 가운데를 넘으면 `reorderGroupUnit` + `swapStripGroupDrag` 로 데이터·뷰 순서를 바꿈(이웃은 미끄러지듯 이동). 가장자리 자동 스크롤은 기존 `stripAutoScroll` 공유. 끌지 않고 떼면 기존처럼 `showGroupMenu`. 새 창으로 끌어내기는 그룹에는 없음. 접힌 그룹도 알약만 같은 방식으로 이동. 실기기 확인 전

**숨긴 탭이 그룹처럼 펼쳐짐 (v3.7.95)**
- 숨긴 탭 카드를 누르면 `openHiddenTabs`(생체인식) 뒤 `toggleSwitcherGroup(hiddenGroup, true)` 로 그룹과 같은 펼침 애니메이션. `hiddenGroup`(id=`HIDDEN_GID`=-1)은 `TabGroup` 을 흉내 낸 가짜 그룹이라 `groups` 에 안 들어감. 상자는 `switcherBoxes` 가 아니라 `switcherHiddenBox` 에 둠(탭을 끌어다 넣는 대상에 안 끼게). 펼침 상태 `hiddenOpen` 은 저장 안 하고 탭 화면을 열고 닫을 때·`onStop` 에서 false(다시 잠김)
- 펼친 상자: 헤더(「숨긴 탭」·개수·메뉴: 「모두 숨김 해제」「다시 잠그기」) + 숨긴 탭 카드(`switcherRows` 에 등록해서 열 때 미리보기가 펼쳐지는 전환이 됨). 카드 누름 → `unhideTab` + `closeTabSwitcher(tab)`, X 자리(눈 꺼짐 모양)는 숨김만 해제. 끌기·밀어서 닫기는 없음. 선택 모드에서는 숨긴 탭 카드·상자 모두 안 보임. 실기기 확인 전

**숨긴 탭 카드 블러 강화 (v3.7.93)**
- `hiddenPreviewBitmap` 의 뭉개기를 16×13 → 64×52 에서 6×5 → 24×20 으로 더 줄여 모양이 남지 않게 함(구형 기기에서도 같은 가짜 블러). 실기기 확인 전

**숨겨도 미리보기 유지 (v3.7.92)**
- `hideTab` 이 더 이상 `tab.thumb` 를 지우지 않음. 현재 탭을 숨길 때는 웹뷰를 떼기 전에 `captureContent()` 로 지금 모습을 `thumb` 에 남김(탭 화면이 열려 있으면 이미 찍혀 있음). 그래서 숨긴 탭 카드(`hiddenPreviewBitmap`)의 흐린 모자이크에 실제 페이지가 비침. `thumb` 는 메모리에만 있어서 앱을 다시 켜면 사라지고 그땐 아이콘 색 덩어리만 흐리게 보임. 숨긴 탭은 탭 목록에 없어 미리보기가 따로 노출되는 곳은 없음. 실기기 확인 전

**숨긴 탭 카드: 블러 + 자물쇠 (v3.7.91)**
- 숨긴 탭 카드의 미리보기 자리를 `hiddenPreviewBitmap` 으로 그림: `groupPreviewBitmap`(숨긴 탭 아이콘 2×2 모자이크)을 16×13 → 64×52 → 원래 크기로 줄였다 키워 뭉갠(구형 기기에서도 되는 가짜 블러) 뒤, 가운데에 `colorSurface` 원 배지 + `ic_lock` 을 얹음. 숨길 때 `thumb` 를 지우므로 실제 페이지 모습이 아니라 아이콘 색 덩어리만 흐리게 보임(내용 노출 없음). 실기기 확인 전

**숨긴 탭을 그룹 카드처럼 맨 끝 한 칸으로 (v3.7.90)**
- `refreshSwitcher` 맨 끝의 전체 폭 잠금 줄을 없애고, `hiddenTabs` 가 있으면(선택 모드 제외) `item_tab` 을 재사용한 격자 카드 한 칸(`addCell`)을 마지막 탭/그룹 카드 뒤에 놓음: 제목 「숨긴 탭 · N」, 점선 테두리, 미리보기 자리와 X 자리에 자물쇠. 누르면 기존처럼 `openHiddenTabs`(생체인식 → 숨긴 탭 메뉴). 끌어서 순서 바꾸기·밀어서 닫기 대상 아님. 실기기 확인 전

**탭 화면: 그룹 펼침·접힘 애니메이션 (v3.7.89)**
- 그룹 카드/그룹 줄/그룹 메뉴의 펼치기·접기가 모두 `toggleSwitcherGroup(g, expand)` 하나로 모임(모션이 꺼져 있으면 예전처럼 바로 `refreshSwitcher`). 목록은 그대로 다시 그린 뒤, `OnPreDrawListener` 에서 막 레이아웃된 뷰에 애니메이션을 입힘
- 펼침: 접힌 카드 모양의 둥근 구멍(`ViewOutlineProvider` + `clipToOutline`)이 그룹 상자 전체로 자라고(`springValue`), 멤버 카드는 그룹 카드 중심에서 0.72배·투명으로 출발해 차례로(최대 192ms) 제자리로 스프링(`settleHome`), 헤더는 살짝 늦게 위에서 내려옴. 사라지는 그룹 카드는 `drawToBitmap` 스냅샷을 오버레이로 잠깐 얹어 크로스페이드(`GroupFxDrawable`). 일반 `Motion.enter` 는 이 그룹 멤버에게는 건너뜀(`refreshSwitcher(skipEnterGroup)`)
- 접힘: 접기 직전 상자(그림 대신 같은 색의 둥근 사각형)·헤더·멤버 카드를 스냅샷으로 떠 두고, 목록을 다시 그린 뒤 스냅샷들이 새 그룹 카드 자리로 모이며(상자는 줄고 카드는 0.8배로 작아지며 사라짐) 새 그룹 카드가 늦게 떠오름. 아래 카드는 기존 `glideFrom` 으로 같이 올라감
- 애니메이션 중에는 `groupToggling` 으로 다른 탭 조작을 막고, 끝나면(또는 1.3초 안전 타이머) 오버레이·윤곽을 원래대로 되돌림. 실기기·컴파일 확인 전 (이 환경엔 Kotlin 빌드 도구가 없음)
**탭 화면: 그룹을 카드 한 칸으로 (v3.7.88)**
- `TabGroup.swExpanded`(기본 false, 저장 안 함) 추가 — 탭바의 접힘(`collapsed`)과 따로 둠. `refreshSwitcher` 가 `swExpanded` 가 false 인 그룹을 `addGroupCell` 로 탭 카드와 같은 격자 한 칸에 그림(`item_tab` 재사용: 그룹 색 테두리, 안에 든 탭 미리보기 2×2 `groupPreviewBitmap`, 5개 이상이면 네 번째 칸 「+N」, 현재 탭이 든 그룹은 테두리 3dp). 누르면 `swExpanded = true`, 길게 누르면 그룹 메뉴(탭 화면에선 「펼치기/한 칸으로 접기」가 `swExpanded` 를 바꿈)
- 펼친 그룹은 예전 그룹 상자(헤더 + 탭 카드) 그대로이고, 헤더를 누르면 접힘 애니메이션 후 다시 한 칸. 헤더의 접힘 미리보기·화살표 회전은 제거(펼친 상태만 있음). 선택 모드에서는 그룹이 항상 펼쳐져 탭을 하나씩 고를 수 있음
- 한계: 접힌 그룹 카드는 끌어서 순서 바꾸기·밀어서 닫기·탭을 끌어다 넣기가 안 됨(펼친 뒤에 가능). 실기기 확인 전

**탭 숨기기 (v3.7.87)**
- 탭 메뉴(탭바·탭 화면에서 길게 누름)의 「탭 숨기기」 → `hideTab`: `tabs` 에서 빼서 `hiddenTabs` 에 보관(웹뷰는 그대로, 그룹은 해제, 재생 중 미디어는 멈춤, 미리보기 `thumb` 지움). 그래서 탭바·탭 화면·탭 개수·탭 넘기기·닫을 때 다음 탭 고르기에 자연히 안 잡힘. 시크릿 탭은 숨길 수 없음(시크릿 프로필 정리 로직과 충돌). 기기에 생체인식·화면 잠금이 없으면 숨기지 않음(영영 못 여는 일 방지)
- 탭 화면 맨 끝에 「숨긴 탭 N개」 잠금 줄(선택 모드에선 안 보임) → `openHiddenTabs` → `TabLock.authenticate`(androidx.biometric 1.1.0, `BIOMETRIC_WEAK | DEVICE_CREDENTIAL`: 지문·얼굴, 없으면 PIN·패턴) 성공 시 `showHiddenTabsMenu` 에서 탭을 고르면 `unhideTab`(목록 맨 뒤로) 후 열림, 「모두 숨김 해제」도 있음
- 저장: `saveTabs` 가 `tabs + hiddenTabs` 를 함께 저장하고 각 항목에 `hidden` 표시, `restoreTabs` 가 `hidden` 항목을 `hiddenTabs` 로 옮김(보이는 탭이 없으면 새 탭 생성, 현재 탭이 숨김이면 첫 보이는 탭). 숨긴 탭도 복원 때 웹뷰를 미루고(lazy) 만든다
- 한계: 숨긴 탭이 있다는 사실(잠금 줄)은 탭 화면에서 보임. 탭 단위 잠금이지 앱 잠금은 아님. 실기기 확인 전

**탭 닫기(X) 색이 제목 색을 따름 (v3.7.86)**
- `applyChipSelection` 이 제목 색(`stripFgUnsel`↔`stripFgSel` 를 선택 비율로 섞은 값)을 계산해 `stripClose` 의 `imageTintList` 에도 같이 적용. `styleStripChip` 의 고정 틴트(`stripFgUnsel`만)는 제거. 실기기 확인 전

**시스템 미디어 플레이어 로딩 표시 (v3.7.85)**
- 페이지 미디어 스크립트(`MediaScripts` 의 `prog`)가 `readyState<3 && (!paused || seeking)` 일 때를 로딩으로 보고 바뀔 때만 `EvMedia.loading(fid, ld)` 로 알림(`waiting`·`stalled`·`seeking`·`canplay` 이벤트에도 `prog` 호출). 앱은 `MediaProg.buffering` 에 담아 `MediaService.start(buffering=)` 로 넘기고, `showControls` 가 `PlaybackState.STATE_BUFFERING` 으로 세션을 갱신 → Android 13+ 미디어 패널이 재생/일시정지 버튼 자리에 로딩 고리를 그림
- 로딩 중엔 재생 위치가 안 흘러서 `updateMediaSession` 의 위치 어긋남(drift) 검사에서 예상 위치를 앞당기지 않음(`pushBuffering`). Android 12 이하 알림 버튼에는 로딩 표시가 없음. 실기기 확인 전

**탭 아이콘이 이전 사이트 걸로 바뀌던 것 (v3.7.84)**
- 원인: 새 페이지로 넘어가는 동안 웹뷰가 이동 전 페이지의 아이콘을 `onPageStarted` 의 `favicon` 인자나 뒤늦은 `onReceivedIcon` 으로 넘겨, 탭 아이콘이 잠깐 이전 사이트 것이 되고(저장 아이콘 파일도 새 주소로 잘못 저장될 수 있음) 
- 수정: `BrowserTab.iconHost`(현재 `favicon` 이 속한 호스트) 추가. `onPageStarted` 는 같은 사이트일 때만 넘어온 아이콘을 쓰고 아니면 저장 아이콘/새로 받기, `onReceivedIcon` 은 `view.url` 호스트가 이동 중인 호스트(`curHost`)와 다르면 아이콘 반영·저장을 모두 건너뜀, 비동기 `Favicons.fetch` 결과도 호스트가 같을 때만 반영. 실기기 확인 전

**미디어 패널 버튼 5개 (v3.7.83)**
- Android 13+ 의 시스템 미디어 패널(삼성 One UI 등)은 알림의 `addAction` 이 아니라 세션의 `PlaybackState` 로 버튼을 그림: 이전·재생/일시정지·다음 3칸만 기본이고 `ACTION_FAST_FORWARD/REWIND` 같은 표준 동작엔 칸이 없음 → `MediaService.showControls` 에서 `PlaybackState.CustomAction` 두 개(`CA_REW` 10초 뒤로 `ic_rewind_10`, `CA_FF` 10초 앞으로 `ic_forward_10`)를 추가, `MediaSession.Callback.onCustomAction` 에서 `skip ∓SKIP_MS` 처리
- 칸 배치: 첫 커스텀 = 왼쪽 끝, 두 번째 = 오른쪽 끝, 가운데 이전·재생·다음 → ⏪ ⏮ ⏯ ⏭ ⏩. (Android 12 이하는 알림 버튼 5개가 그대로 쓰임.) 기기·제조사 UI 에 따라 칸 배치가 다를 수 있음. 실기기 확인 전

**「번역 해제」 아이콘 (v3.7.82)**
- `res/drawable/ic_globe_off.xml` 신설(`ic_globe` 에 빗금 한 줄, 24dp 격자·선 1.8·tint). `showLinkMenu` 의 「번역 해제」 항목이 `ic_close` 대신 사용

**이미지 번역: 영어 남음 줄이기 + 「번역 해제」 (v3.7.81)**
- 영어가 남던 원인: ① 키 없는 번역이 `sl=auto` 라 짧은 이름 줄(「Written by Huma Raza」)의 언어를 잘못 감지(→ 「Race Power」) ② Google 이 이름·브랜드를 그대로 두고 원문을 괄호로 덧붙임(「…(Arbhylle Artiaga)의 그림」) ③ `IMG_SYSTEM` 이 이름·브랜드를 한글로 쓰라고 하지 않음
- 수정: `ImageOcr.Result.lang`(latin/ja/zh-CN)으로 `FreeTranslator.translate(…, source)` 의 `sl` 을 지정(라틴은 페이지 lang 이 비었거나 en·ko·ja·zh 일 때만 `en`, 그 외 auto. 번역 캐시 키에 source 포함). `tidyImgText` 가 한글이 있는 번역에서 영문 2글자 이상 괄호(`(Race Power)`)를 지움. `IMG_SYSTEM` 에 「이름·브랜드·영어 단어는 한글 음차, 알파벳·괄호 병기 금지, TV·OK·CD 같은 약어만 유지, 로고 조각·잡음은 그대로 반환」 추가
- 한계: 키 없는 Google 번역은 브랜드·이름을 영어로 두는 일이 남음(Gemini 번역을 켜면 음차). 영어 안의 단어도 Google 이 그대로 둘 수 있음
- 제목+로고가 한 상자로 합쳐지던 것: 열린 바탕 덩어리를 줄로 나누는 조건(`splitLines`)을 단색 여백뿐 아니라 줄 높이 1.6배 이상 차이·줄 사이가 줄 높이 1.2배보다 큰 경우까지 넓힘(가로쓰기만, 세로쓰기는 한 문장으로 봄)
- 꾹 누른 메뉴(`showLinkMenu`): 이미지에 덮개가 이미 있으면(`PageTranslator.isImageTranslated` — 같은 주소 `img.__evHas`) 「이미지 번역」 대신 「번역 해제」(`untranslateImage` → 페이지 `__evImgClearOne`, 그 이미지 덮개만 걷음). 메뉴는 페이지에 한 번 물어본 뒤 뜸(수 ms). 실기기 확인 전

**이미지 번역: v3.7.79 검토 보완 (v3.7.80)**
- 열린 바탕 판별(`bubbleRect` 의 창 가장자리 두 변 이상 닿음)을 실제 만화(「In My Next Life」)로 확인: 말풍선 4개는 윤곽선 안(넓힘), 머리말 제목·크레딧·자막은 열린 바탕(안 넓힘)으로 갈림
- 줄 나누기는 열린 바탕 **이면서 단색(`flatRatio` 0.6 이상)** 일 때만. 그림 위에 쓴 여러 줄 글은 예전처럼 한 문장으로 합쳐 번역(줄마다 번역하면 문장이 끊겨 어색)
- `separate` 의 글자 범위(`cores`)에서 가장자리 여유(3px)를 뺌 — 여유까지 넣으면 줄 간격이 촘촘한 줄끼리 글자 범위가 겹쳐 갈라 내지 못하고 건너뜀. 실기기 확인 전

**이미지 번역: 말풍선이 아닌 글은 줄 모양 지키기 (v3.7.79)**
- 증상(영어 만화 「In My Next Life」): 머리말의 제목·로고·크레딧(흰 여백 위 글)이 한 덩어리로 합쳐져 큰 상자 하나에 한 문장으로 번역됨 → 줄 위치·글자 크기 같은 원래 형식이 사라짐. 원인: 흰 여백은 `bubbleRect` 채우기가 끝없이 번져 넓힌 범위끼리 30% 이상 겹쳐 `mergeBubbles` 가 합쳤고, v3.7.78 의 「간격 6px 이하」 합치기도 크레딧 줄을 붙임
- 수정: ① `bubbleRect` 가 `Bub(rect, open)` 을 돌려줌 — 채운 바탕이 탐색 창 가장자리 두 변 이상에 닿으면 윤곽선으로 막힌 말풍선이 아니라 열린 바탕(`open`)으로 보고 넓히지 않음(원래 글자 범위만) ② 열린 바탕의 여러 줄 덩어리는 줄마다(`Raw.lines`) 따로 번역 상자를 만듦 ③ 합치기는 글자 범위끼리 10% 넘게 겹칠 때와 윤곽선 안 말풍선(넓힌 범위 30% 겹침)만 — v3.7.78 의 간격 6px 규칙은 뺌
- 한계: 윤곽선이 끊어진 말풍선·윤곽선 없는 단색 상자도 열린 바탕으로 봐 글자 범위만 덮음(원문 조각이 남을 수 있음). 열린 바탕의 여러 줄 문단은 줄마다 번역돼 문장이 어색할 수 있음. 실기기 확인 전

**이미지 번역: 한 말풍선 안 조각 합치기 (v3.7.78)**
- 증상: 한 말풍선 안에서 「ー..」·「0」 같은 작은 조각이 따로 읽혀 각자 번역 상자가 되어 번역 글자끼리 겹침 (덮개를 못 넓힌 경우 `mergeBubbles` 의 30% 겹침 기준이 안 걸림)
- 수정: `mergeBubbles` 합치기 조건에 ① 읽은 글자 범위(`kept` rect)끼리 조금이라도 겹침 ② 간격 6px 이하이고 바탕색 차이 합 60 이하 를 추가(`rectGap`·`colorClose`). v3.7.77 `separate` 는 서로 다른 말풍선 덮개용으로 그대로 둠. 실기기 확인 전

**이미지 번역: 덮개끼리 겹침 풀기 (v3.7.77)**
- 증상: 이웃한 말풍선의 번역 상자가 서로 겹쳐 글이 가려짐 (말풍선 덮개를 넓히는 `bubbleRect`·세로쓰기 가로 넓히기·가장자리 여유 때문에, 넓힌 범위가 30% 미만 겹치는 말풍선은 `mergeBubbles` 에서 합쳐지지 않고 따로 남아 겹침)
- 수정: `ImageOcr.separate` — 모든 덩어리를 원본 좌표로 만든 뒤, 겹치는 쌍마다 겹침이 작은 축(좌우/위아래)으로 맞닿는 가장자리를 겹침 가운데에서 서로 잘라 냄(사이 1샘플 간격). 실제로 읽은 글자 범위(`Grp.core` + 가장자리 3px)는 안쪽으로 자르지 않아 원문은 계속 덮임. 글자 범위끼리 두 축 모두 갈라 낼 수 없는 쌍은 그대로 둠. 최대 3번 반복(3개 이상 연쇄 겹침 대비)
- 번역문 글자 크기는 잘린 상자에 맞춰 `fit` 이 다시 맞춤. 실기기 확인 전

**이미지 꾹 눌러 「이미지 번역」 (v3.7.76)**
- 이미지(또는 사진 링크)를 꾹 누르면 나오는 메뉴(`showLinkMenu`)의 「새 탭에서 이미지 열기」 아래에 「이미지 번역」 추가 → `PageTranslator.translateImage(url)`
- 흐름: 번역 표식(`window.__evId`)을 새로 만들고 `IMG_COLLECT_JS` 로 페이지 이미지를 모은 뒤, 눌러 둔 주소(`#` 뒤 제외)와 같은 것 하나를 골라 기존 `runImages` 로 처리(글자 읽기 → 번역 → 덮기). 본문 글은 번역하지 않고, 「이미지 속 글자도 번역」 설정이 꺼져 있어도 동작. 끝나면 「원문 보기」 로 되돌릴 수 있음(페이지 번역과 같은 되돌리기)
- 번역 중에 다시 누르면 멈춤. 이미 번역한 이미지(`__evHas`)·화면에 없는 이미지·작은 이미지(120x60 미만)는 「이미지를 찾지 못했어요」. 빌드·실기기 확인 전

**이미지 번역 정확도: 읽는 순서 + 만화용 지시문 (v3.7.75)**
- `PageTranslator.readingOrder`: 글자 덩어리를 줄(띠, 높이 중앙값 기준)별로 위→아래, 한 줄 안에서는 세로쓰기가 많으면 오른쪽→왼쪽·아니면 왼쪽→오른쪽으로 정렬해 번역 묶음에 넣음(`i` 번호는 그대로라 결과 짝짓기는 같음)
- `IMG_SYSTEM`: 이미지용 번역 지시문 — 연속 대사의 말투·이름 일관성, OCR 오인식(ー→1/l/|, 한자·작은 가나) 문맥으로 바로잡기, 말풍선에 들어갈 짧은 말, 효과음은 한글 의성어. 이미지 번역만 씀(웹 글 번역은 `TRANSLATE_SYSTEM` 그대로)
- Gemini 번역일 때 효과가 큼. 키 없는 번역(`FreeTranslator`)은 덩어리별 번역이라 순서·지시문 영향이 거의 없음. 실기기 확인 전

**이미지 번역: 일본어 대사 누락 완화 (v3.7.74)**
- `rawBlocks` 에서 가나가 2글자 이상 읽힌 덩어리는 확신도 기준을 낮춤(덩어리 0.4→0.25, 줄 0.25→0.12). 그 외(가나 없는 한자·라틴)는 그대로라 그림 속 무늬를 글자로 읽는 오탐은 늘리지 않음
- 대상: 「いや」「え—…やだよ めんどくさい」 처럼 세로쓰기·색 말풍선에서 확신이 낮게 나와 버려지던 대사(원인 추정, 실기기 확인 전). 「撫子」 같은 이름·한자 오인식은 그대로

**이미지 번역: 장음 기호(ー)를 1로 읽던 것 수정 (v3.7.73)**
- 원본(만화)에서 확인: 「勿体ねー」 의 ー 를 인식기가 `1` 로 읽어 번역이 「물론 1」 처럼 됨 (세로쓰기에서는 선 하나라 `1`·`l`·`I`·`|` 로 읽힘)
- 수정: `ImageOcr.fixLongMark` — 히라가나·가타카나 바로 뒤에 붙은 `1 l I | ｜ 丨` 중 뒤에 숫자가 이어지지 않는 것을 ー 로 되돌림. 줄마다 `rawBlocks` 에서 적용(번역 전). 가나 뒤가 아닌 숫자(「第1話」 등)는 건드리지 않음
- 아직 못 고침: 「え—…やだよ めんどくさい」·「いや」 가 번역 안 되고 남는 것, 「撫子」 같은 이름·한자 오인식(원인 확정 전, 실기기 확인 전)

**이미지 번역 어색함 손질 (v3.7.72)**
- 스크린샷(만화 말풍선: 파랑·분홍 말풍선, 세로쓰기 일본어)에서 본 문제: ① 긴 한글 번역문이 세로로 한 글자씩 세워져 어색함 ② 그림 위 글자용 흐림 상자가 투명(0.4)해 원문 일본어가 비쳐 번역 안 된 것처럼 보임 ③ 일부 말풍선 글자는 번역 안 되고 남음 ④ 세로쓰기를 잘못 읽어 엉뚱한 번역('무코가 오지 않니? 메이크업', '물론 1', '뭐')
- 수정: `fit()` 에서 세로 쓰기는 번역문이 공백 뺀 6글자 이하일 때만 고름(그 외는 가로로 줄바꿈). 흐림 상자 배경 알파 0.4→0.78, 블러 7→9px
- 아직 안 고침(원인 추정만): ③ 은 `rawBlocks` 의 확신도 거르기(MIN_CONF 0.4/LINE_MIN_CONF 0.25)나 번역문이 원문과 같을 때 건너뛰는 처리(`processImage`) 때문일 수 있음, ④ 는 일본어 인식기가 세로쓰기·색 말풍선을 잘못 읽은 것으로 보임 — 같은 이미지로 확인이 필요함

**폰↔태블릿·분할 화면에서 페이지가 확대돼 보이던 것 수정 (v3.7.71)**
- 증상: 폰 화면에서 태블릿 UI 로 바뀌거나(창을 넓힘·접이식 펼침) 분할 화면·AI 분할로 웹 영역 폭이 바뀌면 웹페이지가 확대돼 보임
- 추정 원인(실기기 확인 전): 웹뷰가 페이지 배율(화면에 맞춤 배율)을 옛 폭 기준으로 들고 있음. 기존 `REFIT_VIEWPORT_JS` 는 viewport 메타가 있는 모바일 페이지만 다시 맞추고, 사이트 모드가 바뀌어 다시 불러온 페이지는 이전 배율을 물려받을 수 있음
- 수정: `refitPageScale` — `WebView.setInitialScale(1)` 후 곧바로 `setInitialScale(0)` 으로 처음 배율을 한 번 재설정해 현재 폭·뷰포트 기준으로 다시 계산하게 함. 호출 시점: ① `webRelayout`(창 크기 변경 160ms 뒤, 뷰포트 JS 다시 쓴 다음) ② AI 분할 등으로 웹 영역 폭이 멈춘 뒤 420ms(`areaRefit`) ③ 폰↔태블릿으로 사이트 모드가 바뀌어 다시 불러온 페이지의 `onPageFinished`(80ms·600ms 두 번) ④ 안 보이는 동안 폭이 바뀐 탭을 선택할 때(`BrowserTab.refitPending`). PiP·전체화면 영상 중에는 안 함
- 핀치로 확대해 둔 상태는 폭이 바뀌면 화면에 맞춤으로 되돌아감

**이미지 속 글자 번역 (v3.7.60)**
- 설정 > 브라우저 > 번역 > 「이미지 속 글자 번역」(또는 번역 설정 창의 같은 이름 체크박스). 기본은 꺼짐. 켜면 「페이지 번역」·「항상 번역」·AI 어시스턴트의 번역 칩이 본문 글 번역이 끝난 뒤 이어서 이미지도 번역함
- 흐름: 페이지 JS(`PageTranslator.IMG_COLLECT_JS`)가 `document.images` 중 보이고 120x60 이상인 것을 화면에 보이는 순서로 최대 40장 골라 줌(lazy 로딩 `data-src` 계열 포함, svg·blob 주소 제외) → 앱이 웹뷰와 같은 UA·쿠키·Referer 로 내려받고(`AssistantImages.fetchBytes`) → `ImageOcr` 가 기기 안(ML Kit, 모델 포함)에서 글자를 읽고 → 기존 번역 경로(Google 번역 / Gemini, `translateBatch`)로 번역 → 페이지의 `__evImgApply` 가 이미지 위에 번역문 상자를 얹음
- 인식 언어: 영문 · 일본어 · 중국어(한글은 이미 한국어라 건너뜀). 페이지 `lang` 으로 시도 순서를 정하고, 라틴 → 일본어 → 중국어 순으로 결과가 맞는지 보며 고름. 가나가 없고 한자만 있으면 중국어로도 읽어 더 많이 읽은 쪽을 씀
- 세로로 긴 이미지(웹툰)는 2200px 높이 조각(2000px 간격)으로 나눠 읽고, 조각 경계에 걸린 글은 중심이 속한 조각에서만 씀. 가로는 2000px 이하로 줄여 읽음
- 덮는 방식: 글자 덩어리 둘레 색(가장 많은 색)을 배경으로, 밝기에 따라 검정/흰 글자를 씀. 상자 안에 들어가도록 글자 크기를 맞추고, 스크롤·크기 변화·레이아웃 이동을 따라감(문서 맨 끝 `#__ev_img_root` 층, 포인터 이벤트 없음). 세로쓰기처럼 좁고 긴 글은 번역문이 들어가게 가로로 조금 넓힘
- **이미지 효과 (v3.7.70)**: 번역 중 효과(v3.7.61~69 의 스캔 띠·무지개 테두리·별 등)는 모두 없앰 — `__evImgBusy` 는 호출만 받고 아무것도 그리지 않음. 남긴 것은 번역이 끝나 번역문을 덮을 때(`__evImgApply`)의 등장 효과뿐: 번역 상자가 흐림(blur 8px)·확대(1.06)에서 또렷하게(0.48초, 상자마다 70ms 간격) 나타남. 글자를 못 읽은 이미지는 아무 변화 없음. 「원문 보기」는 `__evRestore` + `__evImgClear`
- **말풍선 덮기 (v3.7.67)**: 글자 덩어리마다 둘레 바탕색(`sampleBg`)에서 색이 이어진 곳을 퍼 올려(채우기, 색 차이 합 60 이하, 창은 글자 범위 +0.8배+24px·최대 200px) 말풍선 안쪽 사각형까지 넓힘 → 글자로 못 읽은 작은 글자·말끝·후리가나도 같은 색 상자로 덮임. 넓힌 범위가 겹치는(30% 이상) 덩어리는 한 말풍선으로 보고 읽는 순서(세로쓰기는 오른쪽 줄부터, 가로쓰기는 위 줄부터)대로 이어 한 문장으로 번역. 넓힌 상자는 윤곽선에 닿지 않게 2px 안쪽으로 줄이고 글자 범위는 항상 포함, 넓힌 상자에는 가장자리 여유(3px)와 세로쓰기 가로 넓히기를 적용하지 않음. 번역문 글자 크기는 원래 글자 크기(`fs`)의 1.5배를 넘지 않게 함. 글자 인식 확신 기준은 덩어리 0.4·줄 0.25 로 낮춰 흘림체 말풍선 글자도 잡음
- **그림 위 글자는 블러 (v3.7.68)**: 글자 덩어리 바로 바깥 둘레(3·6px) 중 바탕색과 비슷한 곳(색 차이 합 48 이하)이 60% 미만이고 말풍선 확장도 거의 없으면(넓힌 넓이가 글자 넓이의 1.5배 미만) 그림 위 글자로 봄(`Block.blur`, JSON `bl`). 이때는 바탕색 상자 대신 상자에 `backdrop-filter: blur(7px)` + 바탕색 40% 막을 깔아 원문을 뭉개고, 번역문에는 바탕색 후광(text-shadow)을 줌. 말풍선·단색 바탕은 기존처럼 같은 색 상자로 덮음
- **세로쓰기 (v3.7.69)**: 읽는 순서는 이미 세로쓰기(오른쪽 줄부터)를 따름. 번역문 글자는 기본 가로쓰기이고, 상자가 세로로 길고 좁을 때(높이 > 너비 1.5배) 가로 크기와 세로쓰기(`writing-mode: vertical-rl`, `text-orientation: upright`) 크기를 모두 맞춰 보고 세로쓰기가 15% 넘게 더 크면 세로쓰기로 씀(`fit`). 말풍선으로 넓어진 상자는 대개 가로쓰기가 이김
- 「원문 보기」는 본문 글과 이미지 덮개를 함께 되돌림(`__evRestore` + `__evImgClear`)
- 한계: CSS 배경 이미지·canvas·blob 주소 이미지는 못 읽음. 말풍선이 아닌 그림 위 글자는 배경색이 어색할 수 있음. 이미지가 많으면 시간이 걸림(한 번에 40장까지, 번역 서버가 막으면 멈춤). 글자 인식 모델(영·일·중)이 들어가 APK 가 수 MB 커짐
- 의존성: `com.google.mlkit:text-recognition(-japanese/-chinese):16.0.1`, `play-services-tasks:18.2.0`

**탭 / 빠른 검색**
- 멀티 탭 (하단 숫자 버튼 → 탭 목록, 탭 닫기, 새 탭)
- 새 탭을 열면 주소창이 바로 활성화됨
- **탭 그룹**: 탭 목록에서 탭의 ⋮ 버튼(또는 길게 누르기) → 새 그룹에 추가 / 다른 그룹으로 이동 / 그룹에서 제거
  - 그룹 헤더를 누르면 접기/펼치기, ⋮ → 이름·색상 변경, 그룹 해제, 그룹의 탭 모두 닫기, 그룹에 새 탭 추가
  - 링크·팝업으로 연 탭은 연 탭 옆에 같은 그룹으로 열림
  - 메뉴 → "현재 탭을 새 그룹으로" 로 한 번에 그룹 만들기
  - 탭이 모두 사라진 그룹은 자동 삭제
- 검색어 자동완성 (방문 기록 + Google 추천어)
- 단축어: `g 검색어`(Google) `n`(네이버) `d`(DuckDuckGo) `b`(Bing) `yt`(YouTube) `w`(위키백과) `map`(지도)
- 검색 엔진 선택 (메뉴 → 검색 엔진)

**태블릿 UI** (화면 최소 폭 600dp 이상, 분할 화면·접이식 펼침에도 자동 전환)
- 상단 가로 탭 스트립: 파비콘·제목·닫기 버튼, 선택한 탭 강조, 그룹 색 밑줄 + 그룹 이름 칩(눌러서 접기/펼치기, 길게 눌러 메뉴)
- 툴바에 뒤로·앞으로·새로고침·홈 + 주소창 + 메뉴 (하단 바는 숨김)
- 키보드 단축키: Ctrl+T 새 탭 / Ctrl+W 탭 닫기 / Ctrl+L 주소창 / Ctrl+R·F5 새로고침 / Ctrl+Tab(+Shift) 탭 전환 / Ctrl+1~9 탭 선택 / Alt+←→ 뒤로·앞으로
- 앱을 켤 때 1번 창이 비어 있고 다른 창에 탭이 남아 있으면, 탭이 있는 창이 먼저 열림
- 이미 켜져 있을 때 시스템 작업 표시줄에서 에버그린 아이콘을 끌어다 화면 옆에 놓으면 새 창이 옆에 열림 (멀티태스킹). 앱의 launchMode 를 standard 로 두어 시스템이 "이미 실행 중입니다" 로 막지 않게 함
- 메뉴 → "데스크톱 사이트" 로 탭별 데스크톱 모드 전환
- 뒤로가기: 페이지 기록이 있으면 페이지 뒤로 → 없으면 (링크로 연 탭은) 연 탭으로 돌아가며 닫힘 → 마지막 탭이면 앱 종료

**광고 차단**
- 광고/트래커 도메인 차단 (내장 목록 + 메뉴에서 목록 업데이트)
- 화면에 남는 광고 영역 숨김(CSS)
- 주소 경로 규칙(`||example.com/ads/` 형태)으로도 차단, 차단 목록은 여러 개를 동시에 내려받아 업데이트
- 설정 > 광고 차단 현황: 이 페이지·오늘·전체 차단 건수, **최근 7일 막대그래프(날짜별 차단 건수, 오늘 강조)**, 종류별 건수, 많이 막은 사이트, 차단 목록 상태
  - 그래프는 보안 현황과 같은 7일 기록(광고·팝업 차단)을 쓰며 「통계 초기화」로 함께 지워짐
- 새 탭 화면 「개인정보」 위젯: 광고 차단 카드 아래에 **보안 현황 카드**(보호 수준 · 오늘 차단 수). 누르면 카드가 펼쳐져 보안 현황 창이 됨
- 사용자 동작 없이 열리는 팝업 / 외부 앱·스토어 자동 이동 차단
- 한계: YouTube 등 영상 서비스가 광고를 자기 도메인에서 직접 내려주는 경우는 막을 수 없음

**영상 재생**
- 하드웨어 가속, 자동재생 허용, 전체화면 재생(화면 켜짐 유지)
- 전체화면 재생 중 홈으로 나가면 PiP(작은 창)로 계속 재생
- 재생 속도 조절 0.5x ~ 3x (메뉴 → 재생 속도)
- **내장 플레이어로 열 수 있는 영상 확대 (v2.4.19)**: 페이지 안의 video 태그뿐 아니라 shadow DOM 안 영상, 여러 겹 iframe,
  `data-*` 설정(video.js 등)·인라인 스크립트(JW Player 등)에 적힌 영상 주소, 미리 불러오기 링크, `<video>` 가 불러온 확장자 없는 주소,
  fetch/XHR 응답 종류(Content-Type)가 m3u8/mpd 인 주소, `?format=m3u8` 같은 쿼리, f4v·m2ts·ogm·asf 등 더 많은 확장자를 후보에 올림.
  후보는 탭마다 60개까지 기억하고 최근 것이 먼저, 한 번에 25개까지 보여 줌
- **영상 아래 버튼 (v2.4.20)**: 웹페이지에서 크게 보이는 영상 바로 아래 오른쪽에 「내장 플레이어로 열기」「PiP로 보기」 버튼이 뜸 (아래에 자리가 없으면 영상 안쪽 위 오른쪽). 나타나고 사라질 때 부드러운 애니메이션, 스크롤 중에도 끊김 없이 따라다님(문서 좌표 + transform). 영상이 전체화면이거나 PiP 중이면 숨김
- **유튜브 내장 플레이어 (v2.4.21)**: 유튜브 영상 페이지(m.youtube.com / youtu.be / shorts / 다른 사이트에 임베드된 유튜브)에서도 「내장 플레이어로 열기」가 됨. 페이지 영상은 blob 이라 주소를 못 쓰므로, 영상 번호만 뽑아 유튜브 앱용 내부 API(안드로이드 VR → iOS 순)로 재생 주소를 직접 받음. 최대 1080p DASH(화질 선택 가능) → HLS → 일반 mp4(360p) 순으로 시도하고, 라이브는 HLS. 로그인이 필요한 영상(나이 제한·비공개·멤버십)과 유튜브가 봇 확인을 요구하는 경우는 안 열릴 수 있음. 유튜브 영상은 저장 불가. 유튜브가 내부 API 를 바꾸면 `YouTube.kt` 의 clientVersion/UA 를 올려야 함
- **미러링 화면 컨트롤 (내장 플레이어 스타일)**: 내장 플레이어가 못 여는 영상을 「화면 그대로 보기」로 창 가득 볼 때, 영상 위에 앱 컨트롤을 얹음 (페이지의 기본 조작은 끔)
  - 위: 닫기 · 제목/사이트 · 화면 비율(맞추기/채우기/늘리기) · 작은 창(PiP) · 회전
  - 아래: 재생/일시정지 · 10초 뒤로/앞으로 · 시간 · 진행 막대(끌면 이동 시간 표시) · 배속(눌러서 순환, 메뉴의 재생 속도와 같은 값)
  - 제스처: 한 번 탭 = 컨트롤 보이기/숨기기, 두 번 탭 = ±10초(연달아 하면 누적), 길게 누르기 = 2배속, 가로로 쓸기 = 시간 이동
  - 한계: 화질·음성 선택, 자막 번역, 실시간 자막, 영상 저장은 파일 주소를 알 수 없는 영상이라 옮기지 못함
- **PiP 작은 창의 재생/일시정지 버튼**: 웹 영상 PiP·내장 플레이어 PiP 모두 시스템이 그려 주는 재생/일시정지 버튼이 뜸
- 메뉴의 미디어 플레이어는 곡·영상이 바뀌면 제목·아티스트(페이지가 알려 주는 정보)와 길이를 바로 갱신함
- 유튜브는 영상을 틀 때마다 자막이 저절로 켜지지 않게 새 영상 시작 직후 한 번만 꺼 줌 (그 뒤에 직접 켜는 자막은 그대로 유지)
- 메뉴 맨 위 미디어 플레이어는 여러 창을 쓸 때 다른 창에서 재생 중인 미디어도 함께 보여 주고, 재생/일시정지·이동·넘기기를 그대로 조작할 수 있음 (제목 부분을 누르면 그 창으로 이동)

**다운로드**
- **빠른 다운로드** (Android 10+, 직접 연결일 때): 서버가 구간 요청을 지원하면 파일을 조각내 최대 8개 연결로 동시에 받음
  - 끊기면 받은 곳부터 이어받기, 서버가 동시 연결을 거부하면 연결 수를 줄여 계속, 끝까지 실패하면 시스템 다운로더로 자동 전환
  - 진행률·속도 알림과 취소 버튼 (Android 13+ 는 알림 권한 필요), 앱을 나가도 계속 받음
  - Android 9 이하는 기존 시스템 다운로더 사용
- 다운로드 중에는 화면 아래에 **진행 카드**(파일명·퍼센트·속도·진행 막대·취소)가 뜨고, 누르면 다운로드 목록이 열림 (빠른 다운로드 한정)
- 파일 다운로드, 이미지 길게 눌러 저장, 링크 길게 눌러 새 탭/복사
- 메뉴 → "페이지의 영상 파일 찾기": 내장 플레이어가 영상을 찾는 방식 그대로 페이지의 영상을 찾아 저장 (v2.4.19 확대)
  - 일반 파일(mp4·webm·mkv·flv·f4v·m2ts 등), 주소에 확장자가 없는 영상, 다른 도메인 iframe 안에서 재생된 영상
  - **HLS(m3u8) 스트리밍** (Android 10+): 조각을 여러 개 동시에 받아 이어 붙이고, 가능하면 mp4 로 다시 묶어 저장 (재인코딩 없음)
    - 마스터 목록이면 가장 화질 좋은 것을 고름, 영상·소리가 따로 있어도 하나로 묶음, AES-128 암호화 조각은 키를 받아 풀어서 저장
    - 코덱이 mp4 에 맞지 않으면 이어 붙인 원본(.ts)을 그대로 저장, 아직 방송 중인 목록은 지금까지 올라온 조각까지 저장
  - 페이지가 만들어 둔 blob 파일(URL.createObjectURL)
- 내장 플레이어의 저장 버튼도 같은 방식: 직접 파일은 재생에 쓴 쿠키·Referer 로 받고, HLS 는 영상 제목을 파일 이름으로 저장
- 지원하지 않는 것: DRM 보호 영상(SAMPLE-AES, Widevine 등), mpd(DASH)·ism 스트리밍, MediaSource 로만 만들어지는 blob 영상
  (저작권·서비스 약관을 지켜서 사용하세요)

**다운로드 목록 (앱 안)**
- 메뉴 → "다운로드 목록" (다운로드 알림을 눌러도 열림): 받은 파일을 최근 순으로 표시, 누르면 열기
- 받는 중인 파일은 맨 위에 진행률·속도와 함께 표시, ⋮ → 다운로드 취소
- 파일 ⋮ (또는 길게 누르기) → 열기 / 공유 / 폴더로 이동 / 삭제
- **폴더**: 위쪽 칩의 "＋ 폴더"로 폴더를 만들고 파일을 옮겨 정리. 폴더 칩을 길게 누르면 이름 변경 / 삭제
  (폴더는 앱 안에서만 쓰는 분류이며 실제 파일 위치는 그대로입니다. 폴더를 지워도 파일은 남습니다)
- Android 10+ 는 이 앱이 받은 파일이, Android 9 이하는 시스템 다운로더로 받은 파일이 표시됩니다

**북마크**
- 메뉴 → "북마크에 추가" (Ctrl+D): 이름·주소·폴더를 정해 저장. 이미 북마크한 페이지는 "북마크 수정"(삭제 가능)
- 메뉴 → "북마크": 목록에서 누르면 현재 탭에서 열기, ⋮ → 새 탭에서 열기 / 수정 / 폴더로 이동 / 주소 복사 / 삭제
- **북마크 폴더**: 칩의 "＋ 폴더"로 만들고, 길게 눌러 이름 변경 / 삭제 (폴더를 지워도 북마크는 남음)
- 주소창 자동완성에 북마크가 먼저 나타남

**크롬 확장 프로그램 (v2.7.1 · 백그라운드 v2.7.2 · 팝업/바 버튼 v2.7.3 · 지원 범위 확대 v2.8.0 · 큰 확장 설치 v2.8.1 · 리다이렉트 규칙 v2.8.2 · webRequest · 헤더 고치기 · 우클릭 메뉴 v2.8.3 · 글자 선택 메뉴 · onAuthRequired v2.8.4 · 팝업 개선 v2.8.5 · 목록 화면 v2.8.6)**
- 설정 > 확장 프로그램 > ＋ 추가: **크롬 웹스토어에서 추가**(웹스토어 주소 또는 영문 32자 ID 를 넣으면 구글 업데이트 서버에서 .crx 를 받아 설치) 또는 .zip · .crx 파일에서 추가
- 웹스토어 확장 프로그램 상세 페이지(chromewebstore.google.com/detail/… · chrome.google.com/webstore/detail/…)를 열면 '설치' 알림이 뜸 (시크릿 탭 제외, `offerStoreInstall`)
- 웹스토어의 「Chrome에 추가」 버튼은 안드로이드 웹뷰에서 동작하지 않아서, 위 방식으로 대신함
- **백그라운드 (v2.7.2)**: `ExtensionManager.syncBackground` 가 background(service worker · scripts)를 눈에 안 보이는 웹뷰의 일반 페이지(`https://ext.evergreen.invalid/<id>/__evx_bg.html`)로 돌림 (service worker 는 `type=module` 도 지원, `importScripts` 는 동기 XHR 로 흉내)
- **팝업 · 바 버튼 (v2.7.3)**: `ExtensionPopup` 이 action 팝업을 앱 안 카드(`ExtensionManager.newPopupView` 웹뷰, 폭 360dp · 내용 높이에 맞춰 자동 조절)로 띄움. 상/하단바 편집에 `extensions` 버튼(`TopBarConfig`)이 추가돼 바에서 `ExtensionsUi` 를 바로 열 수 있음
  - 메시지: 콘텐츠 스크립트·팝업 → 백그라운드 `runtime.sendMessage`(콜백/Promise, `return true` 비동기 응답), 백그라운드 → 보고 있는 탭 `tabs.sendMessage`, `tabs.query/get/create`, `chrome.alarms`, `onInstalled/onStartup`
  - 백그라운드의 `fetch` 는 manifest 의 host 권한에 맞는 http(s) 주소만 앱(HttpURLConnection)이 대신 요청해 CORS 없이 돌려줌 (최대 15MB, Referer·Origin 은 안 보내고 쿠키는 `credentials: 'include'` 일 때만 보냄). XMLHttpRequest 는 대신해 주지 않음
  - **지원 범위 확대 (v2.8.0)**:
    - 포트: `runtime.connect` / `onConnect`(콘텐츠 스크립트 · 팝업 ↔ 백그라운드), `tabs.connect`(백그라운드 → 보고 있는 탭). 열기 · 메시지 · 닫기를 `__evxPort` 봉투 메시지로 주고받음 (`ext_shim.js` 의 `mkPort` / `handlePort`)
    - `storage.onChanged` 를 창 사이에 공유: 쓰는 쪽이 `Bridge.sbcast` 로 알리면 백그라운드 · 팝업 · 이 확장이 적용된 탭이 받음. 영역별 `storage.local.onChanged` 등도 지원
    - 탭에 스크립트 넣기: `scripting.executeScript`(func + args · files) · `insertCSS` · `removeCSS`, `tabs.executeScript` · `insertCSS` · `removeCSS` · `update` · `reload` · `goBack` · `goForward` (보고 있는 탭만, host 권한 또는 `activeTab` 필요)
    - 요청 차단: `declarativeNetRequest` 의 `block` · `allow` · `allowAllRequests` 규칙을 정적(`rule_resources`) · 동적(`updateDynamicRules`, 파일에 저장) · 세션(`updateSessionRules`, 메모리) 모두 적용. 조건은 `urlFilter`(`||` · `|` · `*` · `^`) · `regexFilter` · `resourceTypes` · `domainType` · initiator/request 도메인. 우선순위가 높은 규칙이 이기고 같으면 허용이 이김. `MainActivity.shouldInterceptRequest` 에서 `ExtensionManager.dnrBlocks` 로 검사 (요청 종류는 확장자 · Accept 로 추정). `updateEnabledRulesets` · `getEnabledRulesets` 도 지원
    - `chrome.cookies`(get · getAll · set · remove, host 권한 필요, 앱의 CookieManager 사용 — 이름·값만 알 수 있고 HttpOnly·만료는 알 수 없음), `chrome.windows` 기본 동작
    - 백그라운드 `fetch` 는 `credentials: 'include'` 일 때 쿠키를 붙이고 `Set-Cookie` 를 저장. 백그라운드의 `runtime.sendMessage` 는 열린 팝업 · 옵션 페이지로 전달
    - 같은 페이지의 콘텐츠 스크립트 묶음들이 `runtime.onMessage` · `onConnect` · `storage.onChanged` 리스너를 함께 씀. `include_globs` · `exclude_globs` 지원
    - 보안: 메시지 · 답장 · 저장소 알림은 이 확장의 콘텐츠 스크립트가 적용되는 주소의 페이지나 확장 자신의 페이지에만 보냄 (`ExtensionManager.canReach`)
  - **큰 확장 설치 (v2.8.1)**: 파일 160MB · 압축 해제 1GB 까지 설치 가능, 카드의 백그라운드 제한 안내 문구 제거
  - **리다이렉트 규칙 (v2.8.2)**: `declarativeNetRequest` 의 `redirect`(url · extensionPath · regexSubstitution · transform) · `upgradeScheme` 적용 (`ExtensionManager.dnrRedirect`, 하위 리소스는 `dnrRedirectResponse` 가 대신 받아 돌려줌, 최상위 문서는 `loadUrl`). 우선순위는 허용 > 차단 > 리다이렉트
  - **webRequest · 헤더 고치기 · 우클릭 메뉴 (v2.8.3)** (`ExtensionManager.netIntercept` · `contextMenuEntries`):
    - 백그라운드가 `webRequest.onXxx.addListener` 로 등록하면(`Bridge.wrreg`) 앱이 요청마다 백그라운드 웹뷰의 `__evxWr` 를 불러 줌. 막는(blocking) 리스너는 `Bridge.wrres` 로 결과를 돌려주고, 요청 스레드가 최대 1.5초 기다림 (늦으면 그 확장 프로그램은 20초 동안 건너뜀)
    - 요청·응답 헤더를 보거나 고쳐야 하면(헤더 리스너, `modifyHeaders` 규칙) 앱이 HttpURLConnection 으로 대신 받아 돌려줌 (GET 만, 쿠키는 CookieManager 로 주고받음, 최상위 문서의 3xx 는 loadUrl 로 이동)
    - `contextMenus`: 항목은 파일(`cm_items.json`)에 저장돼 앱을 다시 켜도 남고, 링크 · 이미지 길게 누르기 메뉴에 `page` · `link` · `image` · `all` 컨텍스트 항목이 나타남. 누르면 `onClicked`
  - **v2.8.4**: `selection` 컨텍스트 항목을 글자 선택 팝업(`NestedWebView.extSelectionTitles`)에 끼워 넣음, `onAuthRequired`(`ExtensionManager.netAuth`, `onReceivedHttpAuthRequest` 에서 먼저 물어봄)
  - **v2.8.5 팝업**: 높이 측정을 개선(줄어들 수 있음)하고 폭이 넓은 팝업은 카드를 넓힘, `window.close()` → `Bridge.popclose` 로 팝업 닫기, 팝업 · 옵션 페이지의 `fetch` 는 `Bridge.pfetch` 로 앱이 대신 받음(host 권한 필요), 키보드 `ADJUST_RESIZE`
  - **v2.8.6 목록 화면**(`ExtensionsUi`): 켜짐/꺼짐 구역 나누기, 기능 꼬리표, 삭제는 아이콘 버튼
  - 안 되는 것: POST 요청 본문 보기 · 본문/헤더 고치기(웹뷰가 본문을 안 줌), 팝업 창(「팝업 열기」로 새 탭에서 열림). 시크릿 탭에서는 확장을 쓰지 않음. 여러 창을 쓰면 창마다 백그라운드가 따로 돎

**보안**
- 뒤로가기 리다이렉트 차단: 뒤로가기 직후 페이지가 스스로 다른 곳으로 보내면 막고, 그런 페이지는 건너뛰어 그 앞 페이지로 돌아감
- 기기 백업에 북마크·방문 기록이 들어가지 않음 (allowBackup 끔), 다른 앱은 앱 전용 저장소를 읽을 수 없음
- Google Safe Browsing(위험 사이트 경고) 사용, WebView 파일 접근 차단, 사용자 동작 없는 팝업·외부 앱 이동 차단
- 빠른 다운로드는 https → http 로 넘어가는 리다이렉트와 http/https 가 아닌 주소를 따라가지 않음

**앱 아이콘**: 연두색 배경 + 작게 줄인 나뭇잎 (Android 8+ 적응형 아이콘, 테마 아이콘 지원 / 7.x 는 PNG)

**속도**
- 광고 숨김 스크립트를 페이지당 1번만 실행, 방문 기록 저장을 백그라운드로 이동
- 광고 차단 목록 주 1회 자동 업데이트
- v2.4.18 속도 개선
  - **릴리스 APK**(`evergreen-release-apk`)를 같이 만듭니다: R8 최적화로 디버그 APK 보다 시작·동작이 빠릅니다 (같은 키로 서명, 그대로 덮어써서 설치)
  - 터치할 때마다 DOM 전체를 훑던 광고 막 검사를 가볍게 바꿈 (큰 페이지에서 터치당 약 6.5ms → 0.3ms)
  - 방문 기록·북마크·즐겨찾기·최근 검색어 JSON 을 매번 다시 읽지 않고 기억해 둠 (자동완성이 메인 스레드에서 도는 비용 감소), 방문 기록 저장은 한 번만 읽고 씀
  - 광고 목록 읽기를 자동완성 스레드와 분리하고 낮은 우선순위로, 파일을 줄 단위로 읽고 써서 메모리 사용·GC 감소
  - 자동완성은 이미 낡은 글자의 네트워크 요청을 건너뜀, 스크롤 이벤트당 스크롤바 중복 갱신 제거, WebView 를 앱 시작 때 미리 불러오기


## APK 만드는 법 (GitHub Actions)

1. GitHub에서 새 저장소를 만들고 이 폴더의 내용을 전부 push 합니다.
   ```bash
   git init
   git add .
   git commit -m "init"
   git branch -M main
   git remote add origin https://github.com/<아이디>/<저장소>.git
   git push -u origin main
   ```
2. 저장소의 **Actions** 탭에서 `Build APK` 워크플로가 자동 실행됩니다.
   (수동 실행: Actions → Build APK → Run workflow)
3. 빌드가 끝나면 실행 결과 페이지 아래쪽 **Artifacts**에서
   `evergreen-debug-apk`를 내려받아 압축을 풀면 `app-debug.apk`가 나옵니다.
4. 폰으로 옮겨서 설치합니다. ("출처를 알 수 없는 앱 설치" 허용 필요)
   - 앱은 `app/evergreen.keystore` 고정 키로 서명되므로, 이후 버전은 **지우지 않고 그대로 덮어써서** 업데이트됩니다.
     (키 서명을 바꾼 첫 한 번만 기존 앱을 지우고 설치해야 합니다. `versionCode` 는 올리기만 해야 합니다.)
   - 이 키스토어 파일을 바꾸거나 지우면 다시 "패키지 충돌"이 납니다.

## 설정 바꾸기

- 광고 차단 도메인: `AdBlocker.kt`의 `BUILTIN`
- 단축어/검색엔진: `Prefs.kt`의 `SearchEngines`
- 앱 이름: `res/values/strings.xml`의 `app_name`
- 패키지명: `app/build.gradle.kts`의 `applicationId`와 `namespace`

## 애니메이션
- 스프링(물리 기반) 애니메이션 사용 (`Motion.kt`, androidx.dynamicanimation): 버튼 눌림, 탭 전환, 탭 카드 등장·닫기·재배치, 메뉴 시트 항목, 홈 화면 요소
- 시스템 설정에서 애니메이션을 끄면 자동으로 꺼짐
- **상/하단바 버튼 애니메이션 (v2.4.43~50)**: 메인 브라우저 바의 버튼 동작(누르면 쏙 들어가고, 탭하면 아이콘 모양이 변했다 돌아옴)을 내장 플레이어·미러링 화면·탭 화면에도 같게 적용
  - 플레이어 위쪽 바: 뒤로(화살촉이 쏨) · 작은 창(안쪽 창이 커짐) · 회전(폰이 기울었다 돌아옴), 아래 줄: 10초 뒤로/앞으로(원형 화살표가 해당 방향으로 한 바퀴) · 설정(톱니 회전) · 배속/CC/자막 칩(눌림)
  - 재생/일시정지 버튼은 탭할 때 따로 튀지 않고 재생 상태에 따라 삼각형 ↔ 두 막대로 모양이 변함. 예전에는 눌림 스프링과 상태 변경 때의 크기 애니메이션이 같은 scale 을 두고 부딪쳐 버튼이 떨렸고, media3 가 상태마다 아이콘을 갈아 끼워 모양이 풀렸음 (`LockableImageButton` 이 media3 의 아이콘 교체를 막음)
  - v2.4.44: 10초 버튼의 원형 화살표 중심이 격자 (12, 13) 이라 회전 축을 맞추고(링이 흔들리던 문제), 가운데 "10" 도 같은 중심에 오게 1.75dp 내림
  - v2.4.45: **탭 버튼** — 누르는 동안 앞 카드가 왼쪽 아래로 움츠리고, 떼면 뒤 카드가 오른쪽 위로 튀어 올랐다 출렁이며 제자리 (뒤 카드는 앞 카드에 가려지는 부분을 잘라 내 겹쳐 보이지 않음). 숫자를 아이콘(`MorphIconDrawable`)이 직접 그려 카드와 같이 움직이고, 탭 개수가 바뀌면 숫자가 위/아래로 굴러 바뀌며(늘면 위로, 줄면 아래로) 카드가 한 번 출렁임. 예전에는 숫자가 카드와 따로 놀고 개수가 바뀔 때 버튼 전체가 커졌다 작아졌음
  - v2.4.45: **플레이어 버튼**(내장 플레이어로 재생) — 재생/일시정지 모양으로 갈라졌다 돌아오던 효과(열기 버튼에는 어울리지 않음)를 새 동작(`openplayer`)으로 교체: 누르는 동안 삼각형이 뒤로 물러나고, 떼면 오른쪽으로 날아가며 사라지고 새 삼각형이 왼쪽에서 들어와 살짝 넘어갔다 자리를 잡음. 플레이어 화면 안의 재생/일시정지 버튼(`player`)은 그대로
  - v2.4.46: 빌드 오류 수정 — 탭 버튼 숫자 연결에서 TextView 형변환이 빠졌던 것(`MorphIcon.kt`), `Motion.flyAway` 가 `onEnd` 를 속도 자리에 넘기던 것(`Motion.kt`)
  - v2.4.47: 10초 뒤로/앞으로 버튼 — 한 방향으로 한 바퀴만 돎 (되감기 = 반시계, 빨리감기 = 시계). 예전에는 돌다가 도로 풀리며 반대로 돌아오는 것처럼 보였음. 도는 중에 또 누르면 한 바퀴 더 이어서 돎
  - v2.4.50: AI 어시스턴트 버튼 — 반짝이는 동작. 큰 별이 제자리에서 오므라들고(기울지도 돌지도 않음), 작은 별이 커졌다 작아지고, 작은 반짝임 두 개(오른쪽 아래·왼쪽 위)가 차례로 떴다 사라짐
  - v2.4.51~52: 방문 기록 버튼 — 누르는 동안 시계 바늘이 반시계 방향으로 살짝 감기고, 떼면 분침이 **시계 방향**으로 한 바퀴 돌며(흐릿한 꼬리가 뒤따라 돎) 살짝 넘었다가 자리를 잡음. 시침은 1/12 만큼만 갔다가 제자리. 예전에는 바늘이 돌다가 도로 풀리며 반대로 돌아오는 것처럼 보였음(v2.4.51 은 반시계로 돌았고 v2.4.52 에서 시계 방향으로 바꿈). 도는 중에 또 누르면 한 바퀴 더 이어서 돎
  - v2.4.55~56: **플레이어 버튼**(내장 플레이어로 열기) 새로 만듦 — 누르면 삼각형이 작아지고, 떼면 앞으로 튀어 오르며 삼각형이 세로 조각 세 개로 갈라져 **그대로 이퀄라이저 막대로 변함**(왼쪽부터 차례로 벌어지고, 막대가 출렁이다 오른쪽부터 차례로 다시 합쳐져 삼각형이 됨, 1.2초). v2.4.55 는 삼각형이 사라지고 막대가 따로 나타나는 방식이었음. 예전의 날아가고 들어오는 동작(v2.4.45~53)·윤곽 퍼짐(v2.4.54)은 없앰
  - 탭 화면: 위쪽 뒤로·더보기는 모양 변화, 선택·시크릿 탭·새 탭·전체 선택은 눌림(넓은 버튼은 4%만 줄어듦)
- **탭 화면(전체 화면)**: 탭 버튼을 누르면 현재 페이지가 탭 카드의 미리보기 크기로 줄어들며 탭 화면이 나타나고, 카드를 누르면 그 카드가 펼쳐져 페이지가 됨 (뒤로가기·닫기도 동일). 탭 카드에는 페이지 미리보기가 표시됨
- 방문 기록의 날짜 펼침·접힘 (`HistoryActivity.morph`): 날짜 줄을 누르면 그 날의 기록이 날짜 줄 밑에서 위에서부터 차례로 펼쳐져 나오고, 아래 날짜 줄들은 순간이동하지 않고 밀려 내려감. 접을 때는 기록이 날짜 줄 쪽으로 말려 올라가며 사라진 뒤 아래 줄이 올라와 빈자리를 메움. 펼친 기록이 화면 아래로 넘치면 날짜 줄이 가려지지 않는 선까지 스르르 스크롤. 모션 끔 설정이면 애니메이션 없이 바로 바뀜
- 북마크·방문 기록·다운로드 목록의 선택 삭제: 선택 모드에서 제목줄이 "n개 선택됨"으로 바뀌고 오른쪽 버튼은 '취소', 아래 막대는 [전체 선택 / 삭제 (n)]. 북마크·방문 기록은 묻지 않고 바로 지우며 알림의 '실행 취소'로 되돌리고, 다운로드는 파일이 지워지므로 용량 합계를 보여 주는 확인을 유지
- 탭 화면의 탭 일괄 닫기: 제목줄 '선택' → 카드를 눌러 체크(그룹 줄을 누르면 그 그룹의 탭이 모두 선택·해제, 접혀 있어도 됨) → 아래 막대의 [전체 선택 / 삭제 (n)]. 선택 모드에서는 제목줄이 "n개 선택됨"으로 바뀌고 '선택'은 '취소', '모두 닫기'는 숨겨지며, 밀어서 닫기·길게 눌러 순서 바꾸기는 꺼짐. 아래 막대는 [시크릿 탭 / 새 탭] 줄과 같은 자리에서 교대로 나타나(목록 높이 변화 없음), 고른 탭이 없으면 '삭제'는 회색으로 비활성, 개수가 바뀌면 알약이 톡 튐. 뒤로 가기(화살표 포함)는 선택 모드부터 끔. 탭은 닫으면 되살릴 수 없어 "탭 n개를 닫을까요?" 확인을 한 번 거치고, 전부 고르면 '모두 닫기'처럼 빈 새 탭 하나만 남음. 지금 보던 탭은 맨 마지막에 닫아 이어서 볼 탭이 이미 닫힌 탭으로 뽑히지 않게 함
- **AI 어시스턴트 사진 읽기 (v2.4.92)**: 어시스턴트가 페이지 안의 사진도 보고 답함. 지금 화면에 보이는 사진부터 최대 6장을 골라(아이콘 크기 이하는 제외) 웹뷰와 같은 쿠키·Referer 로 내려받아 긴 변 1280px JPEG 로 줄여 Gemini 에 이미지로 보냄. 웹툰처럼 세로로 아주 긴 사진은 화면에 보이는 부분만 잘라 보내고, `blob:`·`data:` 사진도 처리(`AssistantImages.kt`). 채팅 창에 「✓ 사진도 읽어요」 알약(끄면 글만 보냄, 페이지 참고가 꺼져 있으면 함께 꺼짐)과 「사진 설명」 칩 추가. 사진은 이번 질문에만 붙이고(이전 질문마다 다시 보내지 않음), 사진을 못 받았으면 AI 가 못 봤다고 말하게 함. 설정 안내문에 사진도 Google 서버로 전송된다고 표시
- **빌드 진행 창에 경과 시간 표시 (v2.4.93)**: 「빌드 중」 창에 빌드가 시작된 뒤 지난 시간(`경과 시간 2:05`)이 1초마다 올라감. GitHub 의 `run_started_at` 을 기준으로 하고 시간 표시는 요청 없이 앱 안에서만 갱신(요청 한도에 영향 없음). 빌드가 끝나면 취소·실패 알림에 걸린 시간도 함께 표시 (`BuildStatus.kt`)
- **빌드 진행 알림 (v2.4.94)**: 「빌드 중」 창을 띄우면 `BuildWatchService`(포그라운드 서비스)가 함께 시작돼 앱이 화면 밖에 있어도 알림에 진행률과 경과 시간(시스템 스톱워치)을 보여 줌. 15초마다 GitHub 를 확인(같은 ETag 캐시를 써서 304 는 한도에 안 들어감)하고, 빌드가 끝나면 「빌드 완료/실패/취소 + 걸린 시간」 알림으로 바뀌고 서비스는 내려감. 진행 창이 끝을 직접 처리하면 서비스와 완료 알림을 함께 치움. 알림의 「그만 보기」로 중지, 40분 뒤 자동 종료
- **AI 어시스턴트 새 디자인 (v2.4.95)**: Gemini 같은 파랑 → 보라 → 분홍 그라데이션(`AiGradient.kt`). 창 위쪽에 오로라 빛이 번져 천천히 떠다니고(답을 만드는 동안 더 환해짐), 제목 글자·로고·보낸 말풍선·보내기 버튼·빈 화면 로고·점 세 개·질문 칩에 그라데이션을 입힘. 입력창은 글을 쓰거나 답을 받는 동안 그라데이션 테두리가 켜져 흐름. 위쪽 칩 줄을 없애고 **입력창 바로 위에 뜨는 「바로 물어보기」 카드**로 옮김(칩 + 페이지·사진 참고 알약): 열릴 때 입력창 쪽에서 통통 튀며 떠오르고 칩이 물결처럼 이어서 나타나며, 화살표로 접고 펼 수 있고 키보드가 올라오면 저절로 접혔다가 내려가면 펴짐(`CollapseLayout`, 스프링). 애니메이션은 모두 스프링 기반으로 다듬음: 보내기↔중지 버튼이 돌며 전환, 칩 흐려짐·'맨 아래로' 버튼이 부드럽게 나타나고 사라짐, 점 세 개의 튀는 곡선을 부드럽게. 시스템의 「애니메이션 끄기」를 따름
- **AI 어시스턴트: 대표색 그라데이션 + 설정 알약 위치 (v2.4.96)**: 그라데이션이 앱 대표색(초록, `colorPrimary`)에서 시작해 청록 → 파랑 → 보라로 이어지도록 바꿈(`AiGradient.setBase`: 대표색의 색상을 돌려 나머지 색을 만들고, 보낸 말풍선은 흰 글자가 읽히게 더 짙게). 오로라 빛·제목·로고·보내기 버튼·입력창 테두리·칩 색이 모두 이 흐름을 따름. 「현재 페이지를 참고해요 / 사진도 읽어요」는 질문 칩이 아니라 보내는 내용 설정이라 「바로 물어보기」 카드 밖, 카드와 입력창 사이로 되돌림(카드가 접혀도 늘 보임)
- **AI 어시스턴트: 보내기 화살표 + 그라데이션 순하게 (v2.4.97)**: 보내기 버튼 아이콘을 종이비행기에서 위쪽 화살표(`ic_arrow_up`)로. 그라데이션을 덜 진하게: 두 번째 색부터는 채도를 낮추고 밝게, 오로라 빛·입력창 테두리(가늘게, 최대 67%)·카드 테두리·칩 틴트의 투명도를 낮추고, 보낸 말풍선은 대표색 → 파랑이 옅게 비치는 틴트에 원래 글자색으로
- **AI 어시스턴트 애니메이션 자연스럽고 유기적으로 (v2.4.98)**: ① 태블릿 팝업이 열리고 닫힐 때 틀(배경·그림자)이 먼저 통째로 보이고 그 안에서 내용만 커지던 어색함을 고쳐, 틀과 내용이 한 덩어리로 AI 버튼 자리에서 펼쳐지고 같은 점으로 접히며 사라짐(`popupFrame`). ② 말풍선은 보낸 말은 오른쪽 아래, 받은 말은 왼쪽 아래 모서리에서 자라며 떠오름(`Motion.bubbleIn`, 크기가 정해진 뒤 모서리를 기준점으로, 튕김은 약하게). ③ 점 세 개 말풍선이 답 말풍선으로 바로 자라나 점이 글로 바뀌는 느낌. ④ 글이 쏟아지는 동안·새 말풍선이 생길 때 맨 아래로 뚝 떨어지지 않고 감속하며 부드럽게 따라가고, 손가락으로 만지면 바로 멈춤(`glideToEnd`). ⑤ 복사·다시 생성 버튼이 살며시 떠오름. ⑥ 창을 끌어 옮길 때 들어 올림/내려놓음을 스프링으로(끊겨도 이어짐), 열릴 때 카드·칩의 튕김을 줄임. 시스템의 「애니메이션 끄기」를 따름
- **AI 어시스턴트 빈 화면 동그라미 수정 (v2.4.99)**: 빈 화면 로고 동그라미가 커질 때 가장자리가 잘리던 것을 고침 — 동그라미를 여백(16dp)이 있는 틀 안에 넣고 부모들의 `clipChildren`/`clipToPadding` 을 꺼서 어디에서도 잘리지 않게 함. 움직임도 새로 바꿈: 하나의 시계(4.2초)로 동그라미가 사인 곡선으로 숨 쉬듯 커졌다 작아지고(±4.5%), 반짝이 아이콘이 아주 살짝 기울며, 뒤에서 은은한 빛이 한 번 숨 쉴 때마다 퍼져 나가며 사라짐. 예전의 일정한 왕복 확대(8%)는 제거
- **AI 어시스턴트 빈 화면 동그라미 그라데이션 교체 (v2.4.100)**: 일직선으로 흐르던 띠 그라데이션(청록·파랑·초록이 세로 줄처럼 갈라져 보임)을 구슬(`OrbDrawable`)로 교체 — 색 덩어리 세 개가 서로 다른 속도·방향으로 구슬 안을 돌며 부드럽게 섞이고, 위 왼쪽 하이라이트와 아래 가장자리 그늘로 입체감을 줌(9초 주기). 뒤에서 퍼지는 빛도 같은 구슬
- **AI 어시스턴트 빈 화면 동그라미: 파동 효과 제거 (v2.4.101)**: 뒤에서 퍼지던 빛(파동)을 없앰. 구슬 안의 색 섞임과 은은한 숨 쉬기(±4.5%)만 남음
- **AI 입력창 높이를 보내기 버튼에 맞춤 (v2.4.102)**: 한 줄일 때 입력창이 보내기 버튼(46dp)보다 낮아 어긋나던 것을 고침 — 입력창 최소 높이를 46dp 로 하고 모서리 둥글기를 23dp(완전한 알약)로 맞춤. 여러 줄이 되면 입력창만 위로 늘어나고 버튼은 아래에 남음
- **AI 설정을 모델 버튼 아래 팝업으로 (v2.4.103)**: AI 창 위쪽의 모델 버튼(칩)을 누르면 화면 가운데 대화상자 대신 버튼 바로 아래에 붙는 카드 팝업으로 뜸(API 키·모델·저장/취소/키 삭제). 버튼 아래에서 틀과 내용이 함께 펼쳐지고, 아래 공간이 모자라면 가운데 내용만 스크롤됨. 버튼이 안 보일 때는 예전 대화상자로 열림
- **꾹 누르기 메뉴에 「AI에게 물어보기」 (v2.4.104)**: 웹페이지의 링크·이미지를 꾹 눌러 뜨는 메뉴 맨 아래에 「AI에게 물어보기」 추가. 누르면 AI 창이 열리면서 입력창에 질문(링크: 「이 링크가 어떤 내용인지 설명해 주세요: 주소」 / 이미지: 「이 페이지의 이 이미지가 무엇인지 설명해 주세요: 주소」)이 미리 채워져, 고쳐서 보낼 수 있음. AI 는 링크를 직접 열어 보지 못하고 주소와 현재 페이지 내용만 참고함
- **글자 선택 팝업에 「AI에게 물어보기」 (v2.4.105)**: 웹페이지에서 글자를 선택하면 뜨는 시스템(네이티브) 팝업(복사·전체 선택 등)에 「AI에게 물어보기」 추가 (`NestedWebView.startActionMode` 을 감싸 항목을 끼워 넣음). 누르면 선택한 글을 읽은 뒤 팝업을 닫고, AI 창이 열리면서 입력창에 「이 내용을 설명해 주세요: > 선택한 글(최대 2000자)」 가 미리 채워짐. 보내기 전에 고칠 수 있음. 기기에 따라 항목이 「⋮」 더보기 안에 들어갈 수 있음
- **보낸 사진을 내 메시지에 표시 (v2.4.106)**: 질문과 함께 페이지 사진을 AI 에게 보냈다면(설정의 「사진도 읽어요」), 내가 보낸 말풍선 바로 위에 그 사진이 작은 썸네일(76dp, 둥근 모서리, 오른쪽 정렬)로 뜸. 최대 4장, 더 있으면 마지막 칸에 「+N」. 사진이 준비되는 대로 말풍선과 같이 떠오르고, 다시 생성하면 새로 바뀌고, AI 창을 닫았다 다시 열어도 대화 기록에서 같이 복원됨. 이전 질문의 사진은 AI 에게 다시 보내지 않음(기존과 같음)
- **키보드를 열 때 AI 창이 부드럽게 움직임 (v2.4.107)**: AI 창을 켜 둔 채 입력창을 눌러 키보드가 올라오면, 태블릿 팝업이 시스템에 의해 툭 밀려 올라가고 높이가 한 번에 줄던 것을 고쳐서, 키보드 위로 위치·높이가 부드럽게 미끄러져 맞춰짐(끌어서 옮기거나 크기를 조절하는 중에는 손가락을 바로 따라감). 폰 바텀시트도 키보드가 올라오는 만큼 조금씩 따라 올라가고, 100dp 를 넘을 때 한 번에 튀지 않음
- **AI 창 분할 보기 (v2.4.109)**: 태블릿에서 떠 있는 AI 창의 머리글(위쪽 막대)을 잡고 화면 왼쪽 또는 오른쪽 가장자리로 끌어가면 붙을 자리가 반투명하게 미리 보이고(창은 반투명해짐), 거기서 놓으면 창이 있던 자리에서 옆 패널로 커지며 붙는 분할 보기가 됨. 웹 영역은 패널 너비만큼 좁아져 페이지와 AI 를 나란히 볼 수 있고, 패널의 움직임과 웹 영역이 좁아지는 것이 한 진행도로 함께 움직임(닫을 때도 같음). 반대로 패널 머리글을 끌어 가장자리에서 떼면 패널이 손가락을 따라오는 떠 있는 창이 되고, 가운데에 놓으면 그 자리에 떠 있는 창으로, 반대쪽 가장자리에 놓으면 그쪽으로 옮겨 붙음. 페이지 쪽 가장자리를 끌어 너비 조절(320dp ~ 화면의 60%, 기억함). 고른 모드·쪽은 기억되어 다음에도 그렇게 열림. 분할 보기가 열려 있을 때 AI 버튼을 다시 누르면 패널이 닫힘. 폰(바텀시트)에는 해당 없음
- **대화 지우기 재확인 (v2.4.110)**: AI 창 머리글의 휴지통 버튼을 누르면 바로 지우지 않고 「지금까지 나눈 메시지 N개를 모두 지울까요?」 확인 창이 먼저 뜸. 「지우기」를 눌러야 지워지고, 「취소」면 그대로 남음. 지울 대화가 없으면 확인 없이 「지울 대화가 없어요」 안내만 나옴
- **내장 플레이어로 열 때 영상이 확대되며 열림 (v2.4.111)**: 영상 아래 「내장 플레이어로 열기」(또는 메뉴·위쪽 바의 내장 플레이어)를 누르면 플레이어가 아래에서 뜨는 대신, 웹페이지 속 영상이 있던 그 자리에서 화면 가득(영상 비율 그대로) 커지면서 열림. 영상 자리를 PixelCopy 로 복사해 브라우저 창 위에 얹고(`PlayerZoom`), 모서리가 각지며 커지는 동안 뒤 페이지는 어두워짐. 거의 다 커지면 플레이어 창이 짧은 페이드로 겹치고, 플레이어는 같은 정지 그림을 덮어 두었다가 영상 첫 화면이 그려지면 서서히 걷어 내 끊김 없이 이어짐. iframe 안 영상도 위 프레임에 위치를 올려 보내 iframe 자리를 더해 계산. 영상 위치를 모르거나(전체화면 등) 시스템 애니메이션이 꺼져 있으면 예전 열기 방식 그대로
- **영상 확대 전환을 더 자연스럽게 (v2.4.112)**: ① 고정 시간 곡선 대신 앱의 다른 움직임과 같은 스프링(`Motion.springValue`)으로 확대 — 빠르게 붙었다가 부드럽게 자리를 잡고, 도중에 끊기거나 겹쳐도 속도가 이어짐. ② 확대하는 동안 뒤 페이지가 살짝 물러나며(0.94배) 어두워져 깊이감이 생김(어둡기도 확대 진행에 맞춰 부드럽게). ③ 확대가 시작되는 순간 페이지 영상을 멈춰, 플레이어가 뜰 때 소리가 겹치던 것을 없앰. ④ 영상 자리 복사 대기 50ms → 30ms 로 줄여 누른 뒤 반응이 빨라짐. ⑤ 플레이어 창은 확대가 80% 진행했을 때 열어 끝나자마자 이어짐
- **확대 전환에서 두 영상이 겹쳐 비치던 것 수정 (v2.4.113)**: 확대 도중 플레이어 창이 140ms 페이드로 겹치면서 움직이는 영상과 페이드되는 영상이 동시에 비쳐 어색하던 것을 고침. 이제 플레이어 창은 확대가 92% 진행했을 때(남은 움직임이 거의 없을 때) 페이드 없이 바로 뜨고, 같은 그림이 같은 자리에 놓여 끊김 없이 이어짐. 스프링 감쇠를 0.95 로 올려 끝에서 넘치지 않게 했고, 정지 그림이 걷히는 시간도 240ms → 160ms 로 줄임
- **확대 전환: 스프링 복원 + 뒤 배경 축소 제거 (v2.4.114)**: ① 스프링을 다시 살려(강성 240 · 감쇠 0.72) 살짝 넘쳤다가 돌아오며 자리를 잡는 맛을 되찾음. ② 확대하는 동안 뒤 페이지를 작게 만들던 효과를 없애고 크기는 그대로 두고 어둡게만 가림. ③ 스프링이 넘쳐도 창이 바뀔 때 튀지 않게, 플레이어 창이 뜬 뒤에도 같은 스프링 값(`PlayerZoom` 이 한곳에서 계산)으로 덮개 그림이 같은 움직임을 이어서 그림 — 두 창이 같은 식으로 그리므로 영상이 겹쳐 비치지도, 어긋나지도 않음. 뒤가 완전히 가려지는 시점(진행 80%)에 플레이어 창을 페이드 없이 열고, 움직임이 끝난 뒤 정지 그림을 걷음. 화면이 돌아가면 덮개를 바로 최종 배치로
- **빌드 오류 수정 (v2.4.115)**: 모드 전환 때 AI 어시스턴트를 닫는 `AssistantUi.closeNow()` 가 없어 릴리스 빌드가 `Unresolved reference: closeNow` 로 실패하던 것을 고침. 애니메이션 없이 바로 닫는 함수를 추가함
- **알림 설정 추가 (v2.4.116)**: 설정에 「알림」 묶음을 새로 만듦. ① 다운로드 진행 알림 ② 다운로드 완료 알림(앱이 백그라운드일 때의 시스템 알림) ③ 빌드 결과 알림을 각각 켜고 끌 수 있고(기본 켜짐, 꺼도 앱 안 진행 카드·안내는 그대로), ④ 「시스템 알림 설정」 줄이 휴대폰의 이 앱 알림 설정 화면(소리·팝업·채널)을 열며 알림이 막혀 있으면 그 상태를 보여 줌. 설정 검색에서도 찾을 수 있음
- **알림 켜기/끄기를 더 다양하게 (v2.4.117)**: 설정의 알림을 세 묶음으로 나눠 켜고 끌 수 있게 함(기본은 모두 켜짐). ① 다운로드 알림: 진행 · 완료(시스템) · 완료 안내(앱 안) · 실패 ② 앱 안 안내: 탭 닫기 되돌리기 · 삭제 실행 취소 · 이동 차단 안내 ③ 백그라운드 알림: 빌드 진행 · 빌드 결과 · AI 답변 받는 중 · 미디어 컨트롤 · 악성 사이트 경고 · 시스템 알림 설정 바로가기. 진행·AI 알림은 서비스가 알림 객체를 꼭 가져야 해서, 끄면 알림창에 안 보이는 '알림 끔' 채널로 보냄
- **빌드 진행을 Now Bar에도 표시 (v2.4.118)**: 안드로이드 16(삼성 One UI 8)의 Live Updates 를 써서 빌드 진행 알림을 Now Bar·상태표시줄 칩에 올려 달라고 요청함(칩에는 진행 % 가 짧게 보임). 설정 「빌드 진행을 Now Bar에도 표시」로 끄고 켤 수 있음(기본 켜짐, 「빌드 진행 알림」이 꺼져 있으면 같이 안 뜸). 매니페스트에 `POST_PROMOTED_NOTIFICATIONS` 권한을 추가함. 빌드 설정(compileSdk 35 · AGP 8.5.2)을 건드리지 않으려고 안드로이드 16 전용 클래스 대신 알림 extras 로 요청하며, 지원하지 않는 기기에서는 무시되고 일반 알림으로만 뜸. 기기에 따라 개발자 옵션의 '모든 앱에 라이브 알림'을 켜야 보일 수 있음
- **버전 2.5.00**: 기능 변경 없이 버전만 2.4.132 → 2.5.00 으로 올림
- **v2.4.130 롤백 (v2.4.132)**: 보내기 ↔ 중지(X) 전환을 아이콘 모양 변형(`SendStopIcon`)으로 바꿨던 것을 되돌려, 예전처럼 버튼이 돌며 아이콘이 바뀜(v2.4.131의 구슬 그라데이션은 그대로)
- **AI 보내기 버튼 그라데이션 모양·애니메이션 개선 (v2.4.131)**: ① 모양: 비스듬한 띠가 평평하게 흐르던 동그라미 대신, 입체감 있는 구슬(OrbDrawable — 색 덩어리가 구슬 안에서 섞이고 위쪽 하이라이트·아래쪽 그늘)로 바꿈. ② 애니메이션: 답을 받는 동안 2.2초 주기로 띠가 빠르게 훑고 지나가 번쩍이던 것을, 구슬이 약 0.3초에 걸쳐 천천히 빨라지며 돌고 끝나면 천천히 느려져 멈추도록 함(켜고 끌 때 속도가 갑자기 바뀌지 않음). 시작 때 위치가 튀지 않고 이어서 돎
- **분할 미리보기 영역에만 블러 (v2.4.129)**: AI 창을 가장자리로 끌 때 뜨는 분할 미리보기 안에, 붙을 자리 뒤의 웹 화면을 흐리게 깔아 줌(그 자리만, 상·하단 바·나머지 화면은 그대로). 웹뷰를 다시 그리지 않고 그 영역만 작게 한 번 찍어 와서 깜빡이지 않음. 설정에서 블러 효과를 끄면 예전처럼 색·테두리만 보임
- **AI 창을 가장자리로 끌 때 뜨는 분할 미리보기가 상·하단 바를 덮던 것 수정 (v2.4.128)**: 미리보기 틀이 화면 전체 높이로 그려져 상·하단 바까지 덮었음 → 실제 분할 패널처럼 바 사이의 웹 영역 옆에만 그려짐
- **AI 어시스턴트: 사진도 읽어요가 켜져 있어도 내 말풍선에 사진 안 보이게 (v2.4.127)**: 페이지 사진을 함께 보내도 내가 보낸 메시지 아래에 사진 미리보기가 붙지 않음. 사진은 그대로 AI 에게 전달됨
- **미러링(창 가득 보기)도 영상이 커지며 열리도록 (v2.4.126)**: 미러링은 페이지의 영상을 그대로 창 가득 키워 보여 주는데, 전에는 한 번에 확 바뀌었음. 이제 영상이 원래 있던 자리에서 창 가득으로 스프링처럼 커짐(실제 영상이 커지므로 정지 그림 없음, 모서리는 커질수록 각지게). 켜질 때만 동작하고 애니메이션을 끄면 예전처럼 바로 바뀜. 영상이 iframe 안에 있거나 화면 밖이면 전환 없이 바로 열림
- **내장 플레이어 열기: 그림이 아니라 실제 영상이 커지도록 (v2.4.125)**: 전에는 영상 자리를 캡처한 정지 그림만 커지다가, 자리를 잡은 뒤에야 실제 영상으로 바뀌었음. 이제 첫 화면이 그려졌을 때 확대가 아직 움직이는 중이면, 정지 그림은 제자리에서 서서히 걷히고 그 아래의 **실제 영상(재생 화면)이 같은 스프링 움직임을 이어받아 계속 커짐**(영상 비율 그대로 처음 칸 안에서 시작해 플레이어의 영상 자리로). 커지는 동안은 컨트롤을 숨기고 자리를 잡으면 보여 줌. 화면 방향이 바뀌거나 화면에 맞추기가 아니면 예전 방식으로 동작
- **내장 플레이어 열기: 확대 뒤 멈춤·크기 튐 개선 (v2.4.124)**: ① 플레이어 창을 확대가 80% 진행된 뒤에야 열어서, 확대가 끝난 뒤 창이 뜰 때까지 카드가 가만히 서 있었음 → 확대가 30% 진행되어 뒤가 가려지면 바로 열도록 앞당김(창이 뜨는 시간이 확대 움직임과 겹침). ② 확대하던 그림은 페이지의 영상 칸(제목·좋아요 줄까지 찍힘, 영상과 다른 비율)이고 플레이어는 영상 원래 비율로 보여 줘서, 그림을 걷을 때 폭과 그림이 한 번에 튀었음 → 걷는 동안 그림도 플레이어의 실제 영상 자리·크기로 함께 맞춰 감
- **내장 플레이어 열기 애니메이션에서 AI 창이 밝게 남던 문제 (v2.4.123)**: 페이지 영상이 커지며 내장 플레이어가 열릴 때, 확대 오버레이는 앱 창 안에 깔려서 별도 창인 AI 팝업을 덮지 못했음. 그래서 화면은 어두워지는데 AI 창만 밝게 떠 있다가 플레이어가 뜨는 순간 갑자기 사라졌음. 이제 확대가 시작되면 AI 창도 함께 서서히 사라지고, 플레이어에서 돌아오면(또는 5초 안에 플레이어가 안 열리면) 원래대로 돌아옴
- **AI 대화 지우기 확인 창이 삭제 버튼 아래에 (v2.4.122)**: AI 어시스턴트 머리글의 휴지통 버튼을 누르면 화면 가운데 대화상자가 뜨던 것을, 버튼 바로 아래에 붙는 카드 팝업으로 바꿈(AI 설정 팝업과 같은 모양, 버튼 오른쪽 끝에 맞추고 화면 밖으로는 안 나감). 버튼이 보이지 않는 경우에만 예전 대화상자를 씀
- **AI 분할 패널과 팝업이 같이 뜨지 않게 (v2.4.121)**: 분할 보기 패널과 떠 있는 팝업이 동시에 화면에 남을 수 있었음. 이제 분할 패널·팝업·시트 중 하나를 열 때마다 남아 있는 다른 AI 창을 먼저 모두 치워서 항상 하나만 보임
- **AI 분할 보기에 창 상단 멀티태스킹 바 표시 (v2.4.120)**: AI 어시스턴트를 옆 패널(분할 보기)로 붙이면 떠 있는 창 맨 위에 있던 작은 끌기 막대가 사라져 있었음. 이제 분할 보기 패널 맨 위에도 막대가 보이고, 머리글뿐 아니라 이 막대를 잡고 끌어도 패널을 떼어 낼 수 있음
- **AI 분할 보기가 상·하단 바를 침범하지 않게 (v2.4.119)**: AI 어시스턴트를 옆 패널(분할 보기)로 붙이면 패널이 화면 높이 전체를 차지해 탭 줄·주소창 옆까지 올라오고, 바들도 같이 좁아졌음. 이제 상단 바와 하단 바는 폭이 그대로이고, 패널은 두 바 사이의 웹 영역 옆에만 붙고 웹 영역만 좁아짐. 찾기 줄이 열리는 등 웹 영역의 위·아래 끝이 바뀌면 패널도 따라감. 분할 보기 중에는 스크롤로 상·하단 바가 숨지 않으며(패널과 어긋나지 않게), 닫으면 다시 숨음. 패널을 끌어 떼어 떠 있는 창으로 만들 때는 예전처럼 창 전체 범위에서 움직임
- **설정의 알림을 「알림」 하나로 (v2.5.01)**: 설정에 따로 있던 「다운로드 알림」·「앱 안 안내」·「백그라운드 알림」 세 묶음을 「알림」 한 묶음으로 합침(벨 아이콘 `ic_bell`). 안에서 소제목 「다운로드」·「앱 안 안내」·「백그라운드」로 나뉘고, 항목·동작·설정 검색은 그대로
- **분할 미리보기 블러를 실시간으로, 위치도 정확하게 (v2.5.02)**: AI 창을 가장자리로 끌 때 뜨는 분할 미리보기의 블러가 한 번 찍은 정지 그림이라 페이지가 바뀌어도 안 따라가고, 미리보기 여백(6dp) 때문에 그림이 어긋나 있었음(분할 패널을 끌 때는 끌고 있는 패널까지 찍혀 번져 보임). 이제 `Blur.liveBackdrop` 이 웹 영역(바 사이 칸)만 매 프레임 미리보기 자리에 다시 그려 흐림(스크롤·영상이 바뀌면 같이 바뀜). 위치는 화면 좌표로 맞춰 여백이 있어도 1:1 이고, 상·하단 바·끌고 있는 창·미리보기 자신은 흐린 그림에 섞이지 않음. 미리보기는 크기 애니메이션 없이 서서히 나타남. 설정에서 블러를 끄면 색·테두리만 보임
- **영상 아래 「내장 플레이어로 열기」·「PiP로 보기」가 첫 탭에 눌리게 (v2.5.03)**: 여러 번 눌러야 열리던 것을 고침. 버튼 누름을 `click` 에만 맡기지 않고 직접 감지함 — 손가락이 버튼 위(여유 5px)에 닿았다가 거의 안 움직이고 떨어지면 그 버튼을 누른 것으로 보고 바로 실행하며, 이 터치는 페이지에 전달하지 않음(페이지가 터치를 가로채거나 `preventDefault` 해서 click 이 사라지던 경우, 누르는 순간 페이지 컨트롤이 바뀌며 버튼이 밀리던 경우 대비). 누르는 동안엔 버튼 위치·표시를 고정해 움직이거나 숨지 않고, 누른 순간의 영상을 그대로 사용. 마우스·키보드용 `click` 은 중복 실행 없이 그대로 둠
- **업데이트 받기 서버 오류 대응 (v2.5.26)**: 릴리스 APK 를 받을 때 공개 주소로 먼저 받고, 실패(예: 비공개 저장소 404)하면 저장된 GitHub 토큰으로 API 자산 주소(`assets[].url`)로 다시 받음. 오류 문구에 원인 안내(404·403·5xx) 추가
- **AI 어시스턴트 로딩 애니메이션 개선 (v2.5.30)**: 답을 기다리는 점 세 개가 멈춤 없이 이어지는 물결로 떠올랐다 가라앉도록 변경 (빛 번짐·색 변화 없음, 점 색은 앱 대표색으로 통일, 속도 빠르게)
- **사진 칩 아래 글에 글머리표 (v2.5.31)**: AI 답변의 목록 항목에서 사진 칩은 글머리표 없이 두고, 칩 아래 설명 글 맨 앞에 글머리표(•)를 붙임
- **태블릿 어시스턴트 창 위쪽 모서리 정리 (v2.5.34)**: 태블릿 UI에서만 대화 영역 패널의 테두리선·잘라내기를 없애 모서리에 검은 선이 비치지 않게 하고, 머리글 아래 선을 없애고 패널 위 여백과 첫 말풍선 안쪽 여백을 늘림 (폰은 그대로)
- **태블릿 어시스턴트 창 크기 조절 손잡이 모양 제거 (v2.5.36)**: 팝업 아래 왼쪽·오른쪽 모서리의 크기 조절 표시(대각선 줄)는 보이지 않게 하고, 모서리를 끌어서 크기를 바꾸는 기능은 그대로 유지
- **어시스턴트 로고 색 흐름 끊김 수정 (v2.5.37)**: 답을 만드는 동안 창 왼쪽 위 로고에 흐르는 색이 한 바퀴 돌 때마다 툭 튀던 문제를, 거울 반복의 한 주기에 맞춰 이어지게 고침 (흐르는 속도는 그대로)
- **꾹 누르기 메뉴에 「자동 스크롤」 + 설정 (v2.5.38)**: 웹페이지의 링크·이미지를 꾹 눌러 뜨는 메뉴에 「자동 스크롤」(흐르는 중에는 「자동 스크롤 멈추기」) 추가. 지금 보는 페이지가 설정한 속도로 저절로 내려가며, 화면 아래에 느리게(−)/빠르게(+)/정지 막대가 뜸. 설정 > 자동 스크롤에서 속도(1~20단계, 1단계 = 초당 25dp, 기본 6), 화면을 만졌을 때(만지는 동안만 멈췄다가 이어서 / 완전히 멈춤), 조작 막대 표시를 바꿀 수 있음. 다른 탭·탭 화면·전체화면·새 페이지로 이동·앱 나가기에서는 저절로 멈추고, 페이지 끝에 닿은 채 1.5초가 지나도 멈춤
- **사진을 꾹 눌러 AI에게 물어보면 사진을 첨부 (v2.5.39)**: 링크 없이 이미지만 꾹 눌러 「AI에게 물어보기」를 고르면 주소 대신 그 사진을 내려받아 AI 창 입력창 위에 알약(눌러서 빼기)으로 붙이고, 질문을 보내면 내 말풍선 위에 사진이 보임(대화를 다시 열어도 유지, 다시 생성해도 같은 사진). 이때는 페이지의 다른 사진 대신 고른 사진만 보냄. 사진을 보낸 질문에서 내 말풍선 위 사진이 안 뜨던 것도 함께 고침
- **폰 AI 창 머리글 아래 얇은 선 제거 (v2.5.39)**: 폰 바텀시트에서 머리글과 둥근 대화 패널 사이에 가로선이 남아 모서리 위로 틈이 보이던 것을 없애고, 패널 위 여백과 첫 말풍선 안쪽 여백을 태블릿과 같게 맞춤
- **AI 사진 칩: 대표 사진은 한 줄, 문장 속 참조는 글 사이 (v2.5.39)**: 문단·항목 맨 앞의 [[사진N]] 은 칩이 한 줄을 차지하고 설명은 아래 줄(칩이 여러 개면 한 줄에 나란히), 문장 중간·끝의 [[사진N]] 은 줄을 바꾸지 않고 글 사이에 놓임. AI 안내문도 이 두 쓰임을 나눠 알려 줌
- **클릭 가로채기 차단이 안 먹히던 것 수정 (v2.5.40)**: 「재생」「다운로드」처럼 생긴 버튼을 눌렀는데 엉뚱한 사이트로 보내거나 새 창을 여는 것을 놓치던 원인 세 가지를 고침. ① 눌린 것이 링크이기만 하면 무조건 통과시키던 것을, 링크가 가리키는 사이트와 가는 곳이 다르면(주소가 `#`·`javascript:` 인 버튼 포함) 가로채기로 보도록 바꿈. 눌린 곳과 그 링크 주소는 페이지 스크립트(캡처 단계, 가짜 클릭 무시)가 터치 순간부터 앱에 알려 줘서 웹뷰의 늦고 부정확한 판정에 기대지 않음 ② 손을 떼기 전(touchstart·mousedown)에 바로 이동시키는 경우는 누른 시각이 아직 없어 놓치던 것을, 손이 닿는 순간부터 누르는 중으로 봄 ③ 버튼이 `window.open` 으로 연 새 창은 첫 이동이 이동 검사를 거치지 않는 경우가 있어, 새 창의 첫 요청도 한 번 더 검사해 막고 창을 닫음. 서버 리다이렉트 예외는 「방금 통과시킨 이동에 곧바로 이어지는 것」만 인정(스크립트가 location 을 바꾸는 이동은 리다이렉트 표시가 붙어도 검사). 공유 버튼(share/sharer/intent)은 정상 이동으로 통과. 막은 뒤 알림의 「이동」을 누르면 그 사이트는 이번 실행 동안 허용
- **클릭 가로채기 차단 보강 (v3.7.28)**: ① 눌린 곳을 알리는 `HIJACK_TAP_JS` 의 리스너를 `document` 가 아니라 `window` 캡처 단계에 달아, 페이지가 window 캡처 처리기에서 `stopPropagation` 으로 막아도 눌린 곳 보고가 빠지지 않게 함 ② `market://` · 플레이 스토어를 가리키는 `intent://` 는 `http(s)` 와 달리 이동 검사를 거치지 않고 제스처만 있으면 열리던 것을, 링크(http · market · intent 주소)가 아닌 곳을 누른 직후(2.5초)에는 막도록 함(`isHijackedStoreOpen`). 결제 앱 등 다른 외부 앱 연결은 건드리지 않으며, 누른 곳을 스크립트가 알려 준 경우에만 판단. 막으면 알림의 「열기」 로 열 수 있음
- **클릭 가로채기 차단 구멍 막기 (v3.7.29)**: ① 사용자가 한 번도 안 만진 스크립트 팝업이 같은 사이트 주소를 한 번 거친 뒤 광고로 넘어가면, 팝업 자기 탭에는 누른 기록이 없어 통과하던 것을 연 탭에서 누른 곳(링크가 아닌 곳, 5초 안)으로 판단해 막고 그 팝업 탭을 닫음 (`isUntouchedPopup`, 링크를 눌러 연 팝업은 단축 주소가 흔해서 링크 주소와 비교하지 않음) ② 링크가 아닌 곳을 누른 직후 통과한 이동은 `lastHopAt` 을 갱신하지 않아, 같은 사이트 → 광고 서버 리다이렉트가 '이어지는 리다이렉트' 예외로 통과하던 것을 막음(`nonLinkTapRecent`), 리다이렉트 검사 시간은 4초로 늘림 ③ `siteKey` 가 github.io · pages.dev · blogspot.com · tistory.com 같은 공유 호스팅을 통째로 한 사이트로 보던 것을, 서브도메인 하나가 한 사이트가 되게 함(`SHARED_HOST_SUFFIXES`) ④ 로그인·결제 예외(`looksLikeSignInOrPay`)가 주소 글자 일부만 닮아도(`pay` · `sso` · `share` 등) 통과하던 것을 주소의 칸·길 단위로만 보게 좁힘. 눌린 곳 판정은 `tapInfo` 로 한곳에 모음
- **직접 고른 광고가 앱 재시작 후 돌아오던 문제 (v3.7.30)**: 직접 고른 광고 규칙(`adblock_user_rules.json`)을 `load()` 맨 끝에서 읽었는데, `load()` 는 큰 차단 목록을 읽느라 백그라운드에서 수 초 걸려서 그동안 처음 열린 페이지(복원된 탭)가 `aduser` · `adcss` 를 부를 때 규칙이 비어 있었음. `AdBlocker` 생성 때(`init`) 바로 읽도록 옮기고 `load()` 안의 다시 읽기는 뺌(방금 추가한 규칙을 옛 파일로 덮어쓸 수 있음). 저장은 임시 파일에 쓴 뒤 바꿔 끼움
- **광고 직접 선택: 값이 매번 바뀌는 광고 대응 (v3.7.31)**: `PICKER_JS` 의 선택자 만들기를 보강. ① `looksRandom` 으로 해시·뒤섞은 글자 같은 이름(`xK9fQ`, `Header_box__3xK9a`, 문자·숫자가 번갈아 나오는 긴 이름)은 클래스·아이디 선택자에 쓰지 않음 ② `data-ad-slot` 같은 광고 서비스 속성은 값이 아니라 속성 이름으로 고름 ③ 다른 사이트(등록 도메인이 다름)에서 온 iframe/embed/object 는 `src*="광고서버"` 로 고르고, 앱에는 경로 없는 origin 을 넘겨 `AdBlocker.shouldBlock` 이 그 origin 의 요청을 모두 막음(`originOf`). 같은 사이트가 직접 내려주는 이미지·영상은 예전처럼 전체 주소(경로까지)로 막음. 이미 저장된 규칙은 그대로라서 다시 고르면 새 방식이 적용됨
- **현황 창 열고 닫을 때 카드 블러 깜빡임 (v3.7.42)**: `MorphDialog` 가 닫기 끝에서 창의 면·유리(`surface.hide()`)를 지우는 것과 카드(`restoreOrigin()`, 다른 창)를 되살리는 것을 같은 프레임에 했는데, 두 창은 같은 프레임에 합성된다는 보장이 없어 한 프레임 동안 블러 없는 배경이 비쳤음. 유리 카드(`glassOrigin`)일 때는 `holdGlassOnly()` 로 글자·면·테두리만 지우고 유리는 남긴 채 카드를 되살리고, 두 프레임 뒤에 유리를 지운다(유리는 불투명한 흐린 그림이라 겹쳐도 같은 모양, 단색 카드는 겹치면 진해져서 예전 방식 유지). 열 때도 같은 이유로 카드 숨김을 두 프레임 늦춘다
- **태블릿 메뉴 ↔ 목록 팝업 전환 (v3.7.41)**: 메뉴 카드와 목록 팝업 카드는 같은 자리·같은 크기인데, 메뉴는 축소+페이드로 닫히고 목록은 처음부터 불투명하게 떠서 카드가 깜빡이고 뒤 화면이 비쳤음(영상 프레임 분석). ① 메뉴→목록: `dismissMenu(toList=true)` 는 메뉴를 바로 닫지 않고 `ListUi.pendingMenuDismiss` 에 맡겨, 목록 팝업의 첫 화면이 그려진 두 프레임 뒤에 애니메이션 없이(`animationStyle=0`) 걷어낸다(700ms 안전 타이머). ② 목록→메뉴: 닫는 모션을 축소+페이드(`menu_pop_out`)에서 제자리 페이드(`list_fade_out`, 창·액티비티 둘 다)로 바꿔 메뉴 카드 위에서 내용만 교차한다. ③ `bindMediaCard(view, instant)` 로 즉시 모드(`menuEnterInstant`)에서는 카드 등장·버튼 팝을 건너뜀(카드 칸이 비었다가 튀어나오던 문제).
- **새 탭 카드 블러 어긋남 + 새 탭 → 웹페이지 전환 (v3.7.39)**: ① `ThemeGlassDrawable` 이 화면 1/10 크기(한 칸≈10px)의 흐린 그림에서 잘라 올 자리를 `toInt()` 로 칸 단위에 맞춰 그려서, 카드가 몇 px 움직이거나 크기가 바뀌면 블러가 한 칸(≈10px)씩 툭 튀고 늘어나는 비율도 어긋났음. 이제 흐린 그림 전체를 `BitmapShader`(CLAMP) + 로컬 행렬(루트 크기 대비 실수 배율, 이동량은 실수 좌표)로 그려 자리·비율이 정확함. 그릴 때마다 새 셰이더를 만든다(기록된 그리기 목록과 공유 금지). `paintAt`(MorphDialog 가 카드를 팝업으로 펼칠 때)도 같은 방식. ② `crossfadeHomeToPage` 가 `withEndAction` 을 썼는데 취소되면 끝 동작이 안 불려 `homeFading` 이 true 로 남아 이후 전환이 계속 건너뛰어질 수 있었음 → `AnimatorListenerAdapter` 로 end·cancel 모두 처리. 연출도 키워서 페이지가 아래 28dp·0.96배에서 떠올라 제자리로 오고(스프링), 홈은 불투명한 채 1.05배까지 커짐(460ms)
- **웹페이지 → 새 탭 전환 보강 (v3.7.38)**: v3.7.37 은 새 탭 버튼 경로(`selectTab`)에만 적용됐고, 고스트(떠나는 화면 사진)가 알파로 사라지는 동시에 새 탭도 알파 0→1 이라 중간에 둘 다 반투명해 뒤 바탕이 비쳤음(3.7.36 과 같은 문제). 고스트를 **홈 바로 아래**(`area.indexOfChild(homeView)`)에 깔고 알파는 그대로 둔 채 크기 0.95·위로 14dp 만 물러나게 해, 새 탭이 위에서 떠오르며 덮는 크로스디졸브로 바꿈. 홈 알파가 0.985 이상이면(또는 1초 뒤) 제거. 또 같은 탭에서 페이지 → 홈(뒤로가기·홈 버튼·마지막 탭 닫기)도 `updateUi` 에서 웹뷰를 숨기기 전에 `capturePixels()` 로 찍어 같은 효과를 냄(`inSelectTab` 으로 탭 선택 중엔 건너뜀). 캡처는 PixelCopy 성공 때만 사용(실패 시 빈 화면이 깔리지 않게 효과 생략)
- **웹페이지 → 새 탭 전환 애니메이션 추가 (v3.7.37)**: `selectTab` 이 이전 탭의 웹뷰를 바로 떼어 내서 새 탭 홈만 아래에서 떠오르고 떠나는 페이지는 뚝 사라졌음. 새 탭(홈)으로 넘어가는 경우(`newTabAnimFor===tab`, 탭 화면 닫힘, 이전 탭이 홈 아님)에만 떼기 전에 `captureContent(pixels=true)` 로 화면을 찍어 `playLeavingGhost` 가 웹 영역 맨 위에 ImageView 로 겹치고, 알파 1→0 · 크기 1→0.94 · 위로 20dp 스프링으로 내보냄(끝나거나 900ms 뒤, 또는 다른 탭 선택 시 `removeLeavingGhost` 로 제거). 찍은 이미지는 탭 화면 미리보기(thumb)로도 재사용
- **새 탭 → 웹페이지 전환이 허옇게 뜨던 것 수정 (v3.7.36)**: `crossfadeHomeToPage` 가 홈(알파 1→0, 220ms 감속)과 페이지(알파 0→1, 스프링)를 동시에 반투명으로 겹쳐서, 중간(약 0.1초)에 홈 약 15%·페이지 약 50% 라 덮이지 않은 약 40% 로 뒤 바탕(흰색)이 비쳤음. 홈 알파는 1 로 두고(확대 1.025 만 유지) 페이지만 위에서 떠오르게(스프링 420) 해 두 장이 서로 녹아 섞이는 크로스디졸브로 바꿈. 끝나면 홈을 숨김(300ms)
- **목록 창이 뜰 때 뒤 상단바·탭바 색이 바뀌던 것 수정 (v3.7.35)**: 테마에 `frame_inactive` 가 있으면 메인 창이 포커스를 잃고 250ms 뒤 `focusFrameTask` 가 탭바·상태표시줄 밴드를 비활성 색으로 바꿈. 북마크·방문 기록·다운로드 창이 포커스를 가져가는 것도 비활성으로 취급해서, 팝업이 뜬 뒤 0.25초 만에 뒤 상단바 색이 튀고 닫으면 다시 튀었음(영상에서 상태표시줄 자리 색이 팝업 시작 약 0.3초 뒤·닫힘 직후 한 프레임에 바뀜). `MainActivity.ownListOpen`(`listIntent` 에서 true, `onResume` 에서 false)이 켜져 있으면 비활성으로 보지 않음
- **태블릿 메뉴 ↔ 목록 팝업(북마크·방문 기록·다운로드) 전환 다듬기 (v3.7.34)**: 화면 녹화를 프레임 단위로 보면 ① 메뉴→목록: 메뉴 팝업이 사라지는 120ms 동안 새 목록 창이 알파 0 에서 올라와 반투명 두 장이 겹쳐 뒤가 비쳤음 ② 목록→메뉴: 닫히는 목록 창 뒤로 새 메뉴 면만 먼저 비어 회색 면으로 보였음(메뉴 내용은 알파 0 에서 시작) ③ 창 테마의 어두움(dim)이 한 프레임에 켜지고 꺼졌음. 수정: ① `ListUi.buildTabletPopup` — 메뉴에서 온 팝업(`fromMenu`)은 면을 알파 1·배율 1 로 시작하고 항목만 떠오름 ② `MainActivity.menuEnterInstant` — 목록에서 돌아와 `showMenu` 를 다시 부를 때 `prepareAnchoredEnter`/`playAnchoredEnter` 를 건너뜀 ③ `ListUi.fadeTabletDim` — 시작 때 dim 0 에서 220ms 로 올리고, 끝날 때(`onActivityPaused` + `isFinishing`)는 120ms 로 내림
- **테마 새 탭 카드 색이 반투명이면 블러 적용 (v3.7.33)**: `homeGlassFor` 가 테마의 `ntpSection` 색이 있으면 단색 `GradientDrawable` 만 돌려줘서, 반투명 색이면 바로가기 버튼·카드가 뒤 배경이 선명하게 비치기만 했음. 이제 색의 알파가 255 미만이고 흐린 배경 그림(`homeGlassBmp`)이 있으면 `ThemeGlassDrawable(tint = ntpSection, 테두리 없음)` 으로 그려 그 색 아래 배경이 흐리게 보임. 불투명 색이면 예전처럼 단색
- **카드 팝업이 열리고 닫힐 때 흰 창이 튀던 것 수정 (v3.7.32)**: `MorphDialog` 의 면 출발 색이 늘 불투명한 `colorSurface` 라서, 반투명 새 탭 카드가 열리면 한 프레임 만에 흰 창으로 바뀌고 닫을 때는 흰 창이 반투명 카드로 툭 바뀌었음(화면 녹화를 프레임 단위로 확인). ① `readOriginLook()` 이 카드 배경을 작은 그림(12x4)에 그려 면 색(투명도 포함)과 테두리 유무를 읽어 시작 색·시작 테두리 짙기(`startStrokeAlpha`)로 씀. 테마 색 카드(`ntpSection`·하늘색)는 테두리가 없어 테두리가 갑자기 생기지 않음. 유리 카드(`ThemeGlassDrawable`)는 유리가 그려지므로 면이 투명에서 시작 ② 닫기가 끝나 카드가 돌아오는 순간 `MorphSurface.hide()` 로 면·그림을 같은 때 지워, 반투명 카드 위에 면이 한 프레임 겹쳐 진해 보이던 것을 없앰
- **자동 스크롤 조작 막대 개선 (v2.5.41)**: ① 막대 배경을 「상/하단바 다시 보이기」 버튼과 같은 유리(블러) 모양으로 바꿈: 블러가 켜져 있고 안드로이드 12 이상이면 막대 바로 뒤의 웹 페이지 색이 흐리게 비치고(스크롤을 따라 실시간으로 바뀜), 아니면 예전처럼 반투명 면. 새 `BlurPillLayout` 이 `GlassBackdrop` 을 알약 모양으로 잘라 씀 ② 막대를 아래로 끌어 내리거나(또는 왼쪽 ⌄ 버튼) 누르면 막대가 화면 아래로 내려가 숨고 작은 ⌃ 탭만 남음. 탭을 누르거나 위로 끌면 다시 올라옴. 숨겨도 자동 스크롤은 계속 흐르고, 새로 시작하면 막대는 다시 보임 ③ 막대 위에서 시작한 세로 끌기는 버튼이 아니라 막대가 받음(버튼을 그냥 누르는 것은 그대로)
- **자동 스크롤 조작 막대: 숨기면 아무것도 안 남게, 제스처만으로 (v2.5.42)**: ⌄ 숨기기 버튼과 숨긴 뒤 남던 ⌃ 탭을 없앰. 막대(위쪽 가는 손잡이 포함, 버튼 위에서 시작해도 됨)를 아래로 끌어 내리면 완전히 사라지고, 다시 보려면 웹 화면 아래 가운데(시스템 제스처 영역 바로 위)에서 위로 쓸어 올림(이때는 자동 스크롤이 멈추지 않고 만지는 동안만 쉼). 처음 숨길 때 한 번만 이 방법을 알려 줌. 막대 모양도 다듬음: 위에 끌 수 있다는 표시인 손잡이, 속도는 작은 「속도」 이름 아래 큰 숫자, 속도를 바꿀 때 짧은 진동, 가장 느림/빠름에서는 −/+ 가 흐려짐
- **자동 스크롤 조작 막대 다듬기: 블러 제거 · 닫기/일시정지 (v2.5.43)**: ① 막대의 블러(유리) 배경을 없애고 불투명한 알약 모양으로 바꿈(`BlurPillLayout` 삭제 → 블러 없는 `DragPillLayout`). 가는 테두리선으로 웹 페이지와 구분 ② 왼쪽에 X 버튼(자동 스크롤을 끝내고 막대 닫기), 오른쪽 ▮▮ 버튼은 막대를 연 채로 일시정지 ↔ ▶ 이어가기(일시정지 중에는 화면을 만져도 아무 일 없고 직접 스크롤해서 볼 수 있음) ③ 속도 숫자 아래에 1~20단계 막대, 숫자가 바뀔 때 통통 튀고 −/+ 는 꾹 누르면 계속 바뀜(끝 단계에서 자동으로 멈춤) ④ −/+/닫기/일시정지 버튼은 동그란 물결과 눌림 반응, 일시정지 버튼은 강조 바탕 ⑤ 막대가 나타날 때·끌어 내릴 때(점점 옅어짐)·놓았을 때 스프링 움직임으로 부드럽게
- **자동 스크롤 일시정지 버튼 애니메이션 (v2.5.44)**: ▮▮ ↔ ▶ 가 아이콘 교체 대신 모양이 이어서 변함(두 막대가 각각 삼각형의 왼쪽·오른쪽 조각으로). 스프링으로 살짝 튕기며 기울었다 돌아오고, 버튼도 한 번 출렁임
- **자동 스크롤 막대: 「속도」 글자와 숫자 아래 막대 제거 (v2.5.45)**: 속도 칸에는 숫자만 남김(글자 크기 20). 위 v2.5.43 ③ 의 단계 막대는 없어짐
- **자동 스크롤 막대 숨기기/다시 보기 제스처가 멀티윈도우에서 안 먹히던 것 수정 (v2.5.46)**: 터치 위치(`rawX/rawY`, 화면 좌표)와 웹 화면·막대 영역(창 안 좌표)을 비교해서, 분할 화면·팝업 창처럼 창이 화면 (0,0) 이 아닐 때 어긋나던 것을 영역을 화면 좌표로 바꿔 맞춤. 다시 보기 쓸어올리기 자리도 넓힘(가로 ±110dp, 창 아래 120dp~6dp)하고 인식 기준을 살짝 완화(위로 40dp, 세로 우세 1.2배)
- **일시정지 버튼 모핑을 더 자연스럽게 (v2.5.47)**: 변하는 동안 기울어지던 것을 없애고, 거의 튕기지 않는 부드러운 스프링(강성 420·감쇠 0.82)으로 ▮▮ ↔ ▶ 가 이어서 변함. 버튼 전체 출렁임도 약하게
- **꾹 누르기 메뉴의 자동 스크롤 아이콘 변경 (v2.5.48)**: 「자동 스크롤」은 아래로 이어 흐르는 겹쳐진 쐐기 두 개(새 `ic_auto_scroll`), 「자동 스크롤 멈추기」는 조작 막대의 끝내기 버튼과 같은 X(`ic_close`)
- **자동 스크롤 막대의 X 버튼 다시 만들기 (v2.5.49)**: 맨 왼쪽 X 를 옅은 회색 동그라미 바탕(34dp)에 작은 X 로 바꿔 −/+ 와 구분되고 눈에 덜 띄게 함
- **꾹 누르기 메뉴 「자동 스크롤 멈추기」 아이콘 변경 (v2.5.50)**: 일반 X 대신 원 안의 작은 X(새 `ic_stop_circle`)로 바꿔 조작 막대의 동그란 X 버튼과 모양을 맞춤
- **자동 스크롤 막대 X 버튼 원 크기를 일시정지 버튼과 맞춤 (v2.5.51)**: X 버튼 바탕 동그라미를 34dp → 40dp 로 키워 일시정지 버튼과 같은 크기로(X 모양 크기 16dp 는 그대로)
- **자동 스크롤 설정을 「브라우저」 안으로 이동 (v2.5.52)**: 설정 첫 화면의 별도 「자동 스크롤」 카테고리를 없애고, 속도 · 화면을 만졌을 때 · 조작 막대 세 항목을 「브라우저」 카테고리의 새 소제목 「자동 스크롤」(번역 아래)로 옮김. 설정 값(`auto_scroll_*`)과 동작은 그대로
- **자동 스크롤 최대 속도 30단계로 확대 (v2.5.53)**: 속도 범위를 1~20단계 → 1~30단계로 늘림(1단계당 25dp/초 그대로라 최대 500 → 750dp/초). 기존에 저장된 1~20단계 값과 기본값(6단계)은 그대로
- **GitHub 올리기 「Update is not a fast forward」 수정 (v2.5.54)**: 확인 창을 띄울 때 읽어 둔 저장소 끝(head)을 「올리기」 때 그대로 부모로 써서, 그 사이 빌드 봇 등이 커밋하면 GitHub 가 거부하던 것을 고침. 이제 올리는 순간 최신 head 를 다시 읽어 그 위에 쌓고, 또 거부되면 처음부터 다시 쌓음(최대 3번)
- **자동 스크롤 막대 X 버튼 바탕 원을 더 밝게 (v2.5.55)**: 바탕 동그라미 투명도를 밝은 테마 10%(0x1A) → 6%(0x0F)로 낮춰 더 옅게, 어두운 테마는 10% → 17%(0x2B)로 올려 더 밝게
- **자동 스크롤 막대 여백 6dp 로 통일 (v2.5.56)**: 좌우·아래 여백, 손잡이(맨 위 작대기) 위 여백, 손잡이와 버튼 사이, 버튼 사이(X·−·숫자·+·일시정지) 간격을 모두 `GAP`=6dp 한 값으로 맞춤(전에는 10/6/6/2/4/0/0/8 제각각). 막대 크기 약 232×58dp → 236×62dp
- **자동 스크롤 막대 여백을 v2.5.55 로 되돌림 (v2.5.57)**: v2.5.56 의 6dp 통일을 취소하고 여백·간격을 이전 값(좌우 10 · 아래 6 · 손잡이 위 6 · 손잡이 아래 2 · X 뒤 4 · +/− 사이 0 · 일시정지 앞 8)으로 복원
- **탭 화면 창 전환이 멀티윈도우 상태를 이어받게 (v2.5.58)**: 지금 창이 분할 화면·떠 있는 창이었는데 탭 화면의 창 목록에서 다른 창을 고르면, 선택한 창을 앞으로 가져오며 분할이 깨지고 전체 화면으로 뜨던 것을 고침. 이제 지금 창이 멀티윈도우일 때는 선택한 창의 탭을 저장하고 그 창을 닫은 뒤, 지금 창이 있던 자리(분할 칸, 떠 있는 창이면 위치·크기까지)에 같은 창 번호로 다시 열고 지금 창을 닫음(`switchToWindow` · `openInPlaceOfThisWindow`). 닫힌 창을 누를 때도 같은 방식. 예외로 예전처럼 앞으로 가져오는 경우: 선택한 창에 시크릿 탭이 있을 때(저장되지 않아 사라지므로) · 선택한 창이 이미 옆 칸에 보이고 있을 때 · PiP
- **미러링·내장 플레이어 전환 애니메이션 제거 (v2.5.59)**: 미러링을 켤 때 페이지 영상이 원래 자리에서 창 가득 커지던 움직임(`MIRROR_ON_OWN_ANIM`)을 없애고 바로 창 가득 보여 줌. 내장 플레이어가 열리고 닫힐 때의 떠오르기·사라지기 전환(`player_in` / `player_out`)도 없애 바로 뜨고 바로 닫힘(`overridePendingTransition(0, 0)`). 시스템 애니메이션 설정과 무관하게 항상 적용
- **오류 화면 주소가 data:text/html... 로 뜨던 것 수정 (v2.5.60)**: 연결할 수 없어요 같은 오류 화면은 웹 기록에 실패한 주소로 남지만, 저장했다 되살린 탭·다른 창으로 옮긴 탭에서는 기록 항목이 `data:text/html;charset=utf-8;base64,` 로 바뀌어 주소창에 알 수 없는 글자가 뜨고 원래 주소는 보이지 않았음. 이제 주소창·보안 아이콘·북마크·공유 등은 오류 화면일 때 실패한 원래 주소(`errorUrl`)를 쓰고(`pageUrlOf`), `data:` 주소는 주소창에 보이지 않게 함. 되살린 탭이 오류 화면이면 빈 화면 대신 원래 주소를 다시 불러오고, 뒤로 가기는 남은 빈 오류 항목을 건너뜀
- **연결 실패 화면에 「다음 번호」 버튼 (v2.5.61)**: 오류 화면(연결할 수 없어요·404 등)의 「이전으로 · 다시 시도」 아래에 「다음 번호 (N)」 버튼을 추가. 누르면 실패한 주소의 마지막 번호를 1 늘린 주소를 바로 엶(`nextNumberUrl` · `errNext`). 경로의 마지막 번호를 먼저 보고 없으면 쿼리(`?page=3`)의 번호를 씀. 도메인·파일 확장자(`.mp4`)·`%XX` 인코딩 안의 숫자는 제외하고, `009 → 010` 처럼 앞의 0 자릿수를 지킴. 주소에 올릴 번호가 없으면 버튼은 숨김
- **「다음 번호」: 도메인 이름의 번호를 먼저 올림 (v2.5.62)**: `blacktoon145.com` → `blacktoon146.com` 처럼 도메인 이름 칸(.com 앞, `co.kr` 은 한 칸 더 앞)의 번호를 먼저 올리고 버튼에는 새 도메인을 표시(`다음 번호 (blacktoon146.com)`). 도메인에 번호가 없으면 v2.5.61 처럼 경로 → 쿼리의 번호를 올림. 서브도메인(`s3.`)·IP 주소의 숫자는 제외
- **미러링을 끄면 사이트의 영상이 사라지던 것 수정 (v2.5.63)**: 미러링 종료 때 영상의 인라인 `left·top·width·height·border-radius·transition` 을 통째로 지워서, 영상의 크기·자리를 인라인 스타일로 잡는 사이트(유튜브 등)에서 영상이 사라져 보였음(`mirrorIntroClear`). 이제 미러링이 처음 건드리기 전의 값을 저장해 두었다가 그대로 되돌림. 또 끌 때 페이지에 `resize` 를 알리고, 내장 플레이어에서 돌아올 때처럼 영상을 두 번 다시 그리게 함(`repaintPageVideos`)
- **영상 아래 「내장 플레이어로 열기」·「PiP로 보기」 버튼 글자 선택 막기 (v2.5.64)**: 두 버튼(과 그 바깥 상자)에 `user-select:none`·`-webkit-touch-callout:none` 을 주고, `selectstart`·`contextmenu`·`dragstart` 를 막아 길게 눌러도 글자가 선택되거나 선택 메뉴가 뜨지 않음
- **영상 아래 「PiP로 보기」 버튼에 아이콘 추가 (v2.5.65)**: 「▶ 내장 플레이어로 열기」처럼 「PiP로 보기」 앞에도 아이콘을 붙임. 앱 안 `ic_pip` 과 같은 모양(바깥 화면 + 오른쪽 아래 작은 창)을 SVG 요소로 그려 글자색(`currentColor`)을 따름. 유튜브처럼 Trusted Types 로 `innerHTML` 이 막힌 사이트에서도 보이도록 `createElementNS` 로 만듦
- **「PiP로 보기」 버튼 글자 높이 맞춤 (v2.5.66)**: 아이콘 때문에 줄 높이가 늘어 글자가 「내장 플레이어로 열기」보다 아래로 처지던 것을, 버튼을 `inline-flex` + `align-items:center` 로 바꿔 두 버튼 글자 높이를 맞춤
- **영상 아래 버튼을 누르면 중앙으로 줄어들게 (v2.5.67)**: 누르는 모양(`scale(.93)`)이 나타날 때 쓰던 `transform-origin:100% 100%`(오른쪽 아래 모서리)를 그대로 따라 모서리 쪽으로 쪼그라들던 것을, 나타난 뒤에는 `50% 50%`(중앙)로 바꿔 제자리에서 줄었다 돌아오게 함. 나타나는 동안 원점이 튀지 않도록 `transform-origin` 도 같이 전환(`.32s`), 두 번째 버튼의 전환 지연도 4개 값으로 맞춤
- **PiP 에서 전체 창으로 돌아오면 상태표시줄 자리가 하얘지던 것 수정 (v2.5.68)**: 전체화면 영상·미러링 중 PiP 에 다녀오면 창 크기 변경 알림으로 `updateStatusBarColor()` 가 불려 상태표시줄 자리를 평소 앱 면 색(흰색)으로 칠했음. 전체화면 영상·미러링 중에는 검정(`videoFull`)으로 두고, `onPictureInPictureModeChanged` 에서 뒤 배경을 다시 검정으로 칠하고 시스템 바를 다시 숨김
- **「PiP로 보기」로 갔다 돌아오면 상태표시줄 자리가 하얘지던 것 수정 (v2.5.69)**: 일반 페이지에서 PiP 로 갔다 전체 창으로 돌아올 때 시스템이 상태표시줄 인셋을 다시 알려 주지 않으면 위 여백이 PiP 때 값(0)으로 남아 흰 주소창이 상태표시줄 자리까지 올라왔음. `onPictureInPictureModeChanged(false)` 에서 바로·150ms·500ms 뒤 세 번 `requestApplyInsets` + 상태표시줄 숨김·색 다시 적용(`resync`)
- **PiP 에서는 AI 어시스턴트 창을 숨김 (v2.5.70)**: 작은 창(PiP)이 되면 열려 있던 AI 어시스턴트 창(시트·태블릿 팝업·분할 패널)을 닫아 두고(`aiReopenAfterPip`), 전체 창으로 돌아오면 다시 엶. PiP 로 창 크기가 바뀌며 폰↔태블릿 모드 전환 처리(`closeWindowsForModeChange`)가 AI 창을 다시 열던 것도 PiP 중에는 열지 않고 돌아올 때로 미룸
- **미러링 컨트롤에 「화질」 선택 추가 (v2.5.71)**: 미러링(페이지 영상을 창 가득 보기) 아래 줄의 배속 칩 옆에, 페이지 플레이어가 화질 목록을 알려 주면 현재 화질 칩(`자동`·`720p` 등)이 나타나고 누르면 화질 창이 열려 고를 수 있음. 유튜브(`#movie_player.setPlaybackQualityRange`, 자동 = `tiny~highres`)와 JW Player(`setCurrentQuality`)를 지원하고, 바꾼 화질이 바로 적용되게 유튜브는 지금 위치로 한 번 다시 찾아 감. 목록은 JS 가 `EvMedia.mquals` 로 알려 주고(`mqRep`), 고른 화질은 `mcmd` `q` 로 보냄(`MediaScripts.mirrorQuality`). 화질 목록을 알 수 없는 사이트에서는 칩이 나타나지 않음
- **미러링 컨트롤을 내장 플레이어와 같은 구성으로 + 유튜브 자막·번역 (v2.5.72)**: ① 위쪽 바는 `닫기 · 제목 · 자막 번역 칩 · 작은 창 · 회전`(화면 비율 버튼은 설정으로 이동), 아래 줄은 `재생 · ±10초 · 시간 · 배속 · CC · 톱니`. 자막을 켜 두면 위쪽에 「자막 번역」 칩이 나타나 누를 때마다 번역 끔 → 자막 번역 → 번역+원문(`cycleSubTranslate`). 톱니는 내장 플레이어 설정처럼 `화질 · 자막 · 재생 속도 · 화면 비율` 창을 열고(`settings`/`quality`/`speed`/`fit` 쪽), 앞서 따로 두었던 화질 칩은 이 안으로 옮김. ② 유튜브는 자막이 영상의 `textTracks` 가 아니라 플레이어 안에 있어 미러링에서 자막·번역이 안 됐음: 플레이어(`getOption('captions','tracklist')`)에서 자막 목록을 받아 번호 1000~ 로 CC 목록에 넣고, 고르면 `setOption('captions','track')` 으로 켜서 `.ytp-caption-segment` 글을 읽어 앱에 보냄(`ytCue`). 자동 생성 자막은 한 단어씩 늘어나므로 260ms 멈춘 뒤 보내 번역이 한 줄에 한 번만 되게 함. 번역·모양은 기존 앱 자막과 같음. 실시간(소리 인식) 자막은 미러링에 넣지 않음
- **미러링 화질 목록 표시 + 화면 비율 렉 수정 (v2.5.73)**: ① 화질은 유튜브·JW Player 만 목록이 떠서 그 밖의 사이트에서는 설정에 '화질' 줄이 아예 안 보였음 → 페이지에 걸린 hls.js·shaka·dash.js·video.js(VHS)·Plyr 플레이어를 찾아(`mqFind`/`mqDuck`, 영상 요소·윗대 요소·전역 객체를 훑음, 못 찾으면 2초에 한 번만 다시 찾음) 화질 목록을 앱에 알리고 고른 화질로 바꿈(`mqListX`/`mqSetX`, 자동 포함). 영상 파일 하나(mp4 등)처럼 화질 목록 자체가 없는 영상은 여전히 화질 줄이 안 보임. ② 화면 비율을 바꿀 때마다 스타일 시트(`__ev_pip_style`) 전체를 다시 써서 문서 전체 스타일이 다시 계산돼 렉이 걸렸음 → 비율은 영상에만 인라인 `object-fit` 으로 걸고(`mfitApply`, 끌 때 원래 값 복구), 스타일 시트는 내용이 같으면 다시 쓰지 않음(PiP·회전 뒤 `nudgeMirrorLayout` 도 가벼워짐)
- **이전/다음 영상 버튼 (v2.5.74)**: 내장 플레이어와 미러링 컨트롤 아래 줄에 `⏮ 이전 영상` · `⏭ 다음 영상` 버튼 추가. ① 내장 플레이어: 플레이어는 영상 주소 하나만 재생하므로, 누르면 원래 페이지에서 '이전·다음 영상' 버튼(유튜브식 `.ytp-next-button`, `aria-label`/`title` 이 Next·다음 인 것 등)을 대신 눌러(`MediaScripts.pageSkip`) 새로 잡힌 영상 주소(누르기 전에 없던 것)를 최대 8초 찾고, 찾으면 열려 있는 플레이어를 그 영상으로 바꿈(`MainActivity.playerSkip` → `PlayerActivity.switchTo/loadOther`). 이전 버튼은 3초 넘게 봤으면 처음부터. 페이지에 버튼이 없으면 '버튼을 찾지 못했어요' 알림. 세로처럼 폭이 430dp 보다 좁으면 10초 버튼을 숨겨 아래 줄이 넘치지 않게 함(더블탭 10초 이동은 그대로). ② 미러링: 같은 버튼이 페이지 버튼을 누르고(`mSkipDo`), 없으면 이전은 처음부터·다음은 끝으로 보내 사이트가 다음 영상을 잇게 함. 영상이 든 iframe 안에 버튼이 없으면 바깥 페이지에서도 찾음(`mskipUp`). 아래 줄이 좁아지지 않게 재생 시간은 진행 막대 오른쪽 끝으로 옮김
- **가로로 밀어서 재생 위치 바꾸기 제거 (v2.5.75)**: 내장 플레이어와 미러링 화면에서 좌우로 쓸어 시간 이동하던 제스처(`onScroll`)를 없앰. 시간 이동은 진행 막대·10초 버튼·더블탭으로만 함. 더블탭 10초·길게 눌러 2배속·탭으로 컨트롤 보이기/숨기기는 그대로
- **더블탭 가운데 = 재생/일시정지 + 더블탭 애니메이션 개선 (v2.5.76)**: 내장 플레이어·미러링 화면을 3등분해 왼쪽 더블탭 = 10초 뒤로, 가운데 = 재생/일시정지, 오른쪽 = 10초 앞으로(`onDoubleTap`). 효과는 새 `DoubleTapFx` 뷰가 그림(터치는 통과): 좌우는 그 쪽 화면이 곡선 모양으로 밝아지고 탭한 자리에서 물결이 번지며 화살표 세 개가 차례로 밝아지고 누적 초(10→20→30초)가 톡 튐, 가운데는 검은 동그라미 안의 재생/일시정지 아이콘이 커졌다 사라짐. 예전의 글자 표시(‹‹ 10초)는 없앰
- **빌드 오류 대비 정리 (v2.5.77)**: GitHub 빌드가 `:app:compileReleaseKotlin` 의 Internal compiler error 로 실패. 가장 의심되는 코드(이전/다음 영상 찾기 `playerSkip` 안의 람다 속 재귀 지역 함수 + 바뀌는 지역 변수 캡처)를 일반 멤버 함수(`playerSkipPoll`)로 풀어 컴파일러가 다루기 쉽게 함. 원인이 이것이 아니면 로그 앞쪽의 `File being compiled` 줄로 파일을 확인해야 함
- **빌드 오류 원인 확정·수정 (v2.5.78)**: 로그의 `File being compiled: MediaScripts.kt` / `UTF8 string too large` — `MediaScripts.INJECT` 문자열 상수가 약 66KB 라 JVM 상수 한계(UTF-8 65535바이트)를 넘어 컴파일러가 죽었음(v2.5.77 의 `playerSkip` 정리는 원인이 아니었음). `INJECT` 를 4조각(`INJECT_1`~`INJECT_4`, 각 약 16KB)으로 나누고 `val INJECT = INJECT_1 + … ` 로 런타임에 이어 붙임(const 로 두면 상수 접기로 다시 합쳐져 넘침). 스크립트 내용은 그대로. **주의**: 한 `const val` 문자열은 UTF-8 로 65535바이트를 넘기면 안 됨
- **이전/다음 영상 버튼이 PiP 아이콘으로 보이던 문제 수정 (v2.5.79)**: 두 버튼의 눌림 효과 종류를 `"pip"` 로 줬는데, `Motion.barButton` → `MorphIconDrawable.install` 이 `"pip"` 종류에는 PiP 모양을 직접 그려 버튼 아이콘을 덮어써서 `ic_skip_prev/next` 가 가려졌음. 종류를 `"skip"` 으로 바꿈(`MorphIconDrawable.KINDS` 에 없는 종류라 아이콘은 XML 그대로, 눌림 크기 효과만 적용 — `Motion.barFx` 에 0.88 로 등록). 대상: `PlayerActivity`(ev_prev/ev_next), `MirrorOverlay`(이전/다음). **주의**: `barButton` 의 종류 이름은 모양 변하는 아이콘 이름이기도 하니, 다른 아이콘 버튼에 `pip`·`rotate` 같은 이름을 빌려 쓰지 말 것
- **다음 영상을 누르면 유튜브 광고 건너뛰기 (v2.5.80)**: 미러링(유튜브는 내장 플레이어 대신 미러링)의 「다음 영상」을 눌렀을 때 ① 광고 중(`.ad-showing` 등)이면 영상 이동 대신 광고부터 건너뜀 — '건너뛰기' 버튼이 보이면 누르고, 건너뛸 수 없는 광고는 광고 영상을 끝으로 보냄(`MediaScripts.mAdSkip`). ② 광고가 아니면 평소처럼 다음 영상으로 가고, 그 직후 새 영상 앞에 붙는 광고도 약 8초 동안 0.3초마다 살펴 건너뜀(`mAdWatch`). 설정의 '광고 자동 건너뛰기'와 상관없이 버튼을 눌렀을 때는 항상 동작. 유튜브 주소(youtube.com / youtube-nocookie.com)에서만 동작
- **페이지가 다시 불러와져도 보던 영상 위치로 이어보기 (v2.5.81)**: PiP 로 오래 보다 돌아오면 시스템이 웹뷰 렌더러·앱을 종료해 페이지가 새로 로드되고 본 위치가 사라지던 문제. 재생 보고(`EvMedia.progress`)마다 영상 위치를 탭에 적어 두고(`noteResume`: 60초 이상 영상, 10초~끝 10초 전 구간만), ① 렌더러 종료 복구(`recoverRenderer`) ② 앱이 종료됐다 탭이 복원될 때(`saveTabs` 의 `rp`/`ru`) 같은 페이지(유튜브는 `v=` 값 비교)가 다시 로드를 마치면 영상이 준비되는 대로 그 위치로 한 번 옮김(`resumeJs`: 광고 중이면 기다리고, 이미 5초 넘게 재생됐으면 건드리지 않음, 최대 45초). 시크릿 탭은 제외. 최상위 문서의 video 만 대상(iframe 안 플레이어는 못 이어감)
- **유튜브 광고 자동 건너뛰기가 안 되던 문제 수정 (v2.5.82)**: 미러링·PiP 는 영상 말고 모든 요소를 `visibility:hidden` 으로 가리는데, 건너뛰기 버튼이 '보이는지' 를 `visibility` 로 검사해서 숨겨진 것으로 판단하고 한 번도 누르지 않았음. 이제 크기(>0)와 `display` 로만 판단. 또 유튜브가 `click()` 하나로는 눌림으로 안 치는 때가 있어 pointerdown·mousedown·pointerup·mouseup·click 을 순서대로 보냄(`tap`). '다음 영상' 의 광고 건너뛰기(`mAdSkip`)도 같은 검사를 고침. **주의**: 미러링·PiP 중인 페이지에서 요소가 '보이는지' 를 `visibility` 로 판단하지 말 것
- **미러링 제목이 영상이 바뀌어도 고정되던 문제 수정 (v2.5.83)**: 미러링 위쪽 제목은 `addMirrorOverlay` 에서 시작할 때 한 번만 정해져서, 유튜브처럼 같은 페이지 안에서 다음 영상으로 넘어가도 처음 제목이 남았음. 이제 `mirrorTitleFor`(페이지가 알려 준 지금 영상 제목(mediaSession) → 탭 제목 순)로 정하고, 탭 제목이 바뀔 때(`onReceivedTitle`)와 영상 제목 보고(`EvMedia.meta`)가 올 때마다 `refreshMirrorTitle` 로 다시 반영
- **AI 창을 팝업 모드로 바꿨는데 AI 버튼을 다시 누르면 분할로 열리던 문제 보완 (v2.5.84)**: 분할 패널의 머리글을 끌어 떼어 내면 패널이 떠 있는 창 모양으로 바뀌지만, '팝업 모드' 설정(`ai_popup_size` 의 `split`)은 손가락을 뗄 때(`undockToPopup`)에야 false 로 바뀌었음. 그 전에 터치가 끊기거나 앱이 전환되면 설정이 true 로 남아 다음에 AI 버튼을 누르면 분할로 열렸음. 이제 떼어 내는 순간(`lift`)에 바로 false 로 저장하고, 가장자리에 놓으면 `dockSplit` 이 다시 true 로 바꿈. **원인을 한 가지로 확정하지 못함** — 그래도 같은 증상이면 어떤 순서로 눌렀는지(떼어 낸 뒤 놓은 위치, 버튼을 누른 때) 확인할 것
- **PiP 작은 창에 「백그라운드로 재생」 헤드셋 버튼 추가 (v2.5.85)**: 웹 영상 PiP(`MainActivity.pipParams`)와 내장 플레이어 PiP(`PlayerActivity.pipParams`) 의 시스템 버튼에 헤드셋 아이콘(`ic_pip_headset`)을 넣음. 누르면 작은 창을 닫고(`moveTaskToBack`) 소리만 계속 재생하며, 멈춰 있던 영상이면 이어서 재생함. 설정의 「백그라운드 재생」 이 꺼져 있어도 이번에는 재생하도록 임시 값(`bgForced` / `bgRequested`)을 써서 설정 자체는 바꾸지 않고, 앱 화면으로 돌아오면 해제됨. 웹 PiP 는 작은 창에 둘 수 있는 버튼 수(`maxNumPictureInPictureActions`)가 4개 미만인 기기에서는 「이전 영상」 을 빼고 「재생 · 다음 · 헤드셋」 으로 보여 줌
- **PiP·백그라운드에서 「다음 영상」 으로 넘어간 뒤 앱을 다시 켜면 재생 시간이 사라지고 새로고침되던 문제 수정 (v2.5.86)**: 탭 상태(`saveTabs`: 주소·앞뒤 기록·이어보기 위치)는 앱을 나갈 때 한 번만 저장돼서, 그 뒤 PiP·알림에서 다음 영상으로 주소가 바뀌고 시스템이 앱을 종료하면 옛 주소·옛 위치로 복원됐음. 이제 앱이 안 보이거나 PiP 인 동안 재생 보고(`EvMedia.progress`)가 올 때 주소가 바뀌었거나 10초가 지났으면 저장함(`saveTabsWhileAway`). **원인을 앱 종료(프로세스 종료)로 추정한 수정** — 종료 없이도 새로고침된다면 그때 상황(어디서 눌렀는지, 사이트)을 알려 줄 것
- **이어보기 한계 풀기 (v2.5.87)**: v2.5.86 의 한계였던 ① 60초 미만 영상은 기록 안 함 ② 처음 10초·끝 10초는 기록 안 함 ③ 위치가 최대 10초 전으로 돌아감 을 모두 완화. 이제 10초 이상 유한 길이 영상이면 3초~끝 5초 전 구간을 기록하고(`noteResume`, 라이브는 제외), 앱이 안 보이거나 PiP 인 동안은 재생 위치만 작은 설정 파일(`evergreen_resume`, `saveResumeLight`)에 2초마다 적음. 주소가 바뀔 때는 기존처럼 탭 전체를 저장하고(`saveTabsWhileAway`, 같은 주소면 30초 간격), 앱 복원 때 탭 번호표(`sid`)로 가벼운 저장분이 더 최근이면 그 값을 씀. 이어가는 조건도 완화(`resumeJs`: 영상 길이 > 위치+2초, 이미 위치 근처까지 재생됐으면 건드리지 않음). iframe 안 플레이어는 여전히 못 이어감
- **PiP 헤드셋(백그라운드로 재생) 버튼을 누르면 영상이 처음부터 재생되던 문제 보완 (v2.5.88)**: **원인을 코드만으로 확정하지 못해** 증상을 막는 보호를 넣음. 버튼을 누르는 순간의 재생 위치를 적어 두고(웹 PiP: `bgGuardPos`, 내장 플레이어: `guardPosition`), 그 뒤 20초(웹)/약 8초(내장) 안에 위치가 3초 넘게 뒤로 튀면 누른 위치로 되돌림. 내장 플레이어는 버튼을 누르는 즉시 `savePosition()` 도 해서 창이 다시 만들어져도 그 위치에서 이어짐. 같은 증상이면 웹 PiP 인지 내장 플레이어 PiP 인지, 어떤 사이트인지 확인할 것
- **유튜브에서 PiP 헤드셋 버튼 후 처음부터 재생되는 경우 보완 (v2.5.89)**: 영상 사이트는 유튜브(미러링/웹 PiP 경로)로 확인됨. v2.5.88 의 위치 되돌리기(`bgGuard*`)에 더해, 버튼을 누른 뒤 20초 동안은 페이지가 새로 로드돼도 누른 위치로 이어가도록 이어보기(`resumeApply`)를 켜 둠. **원인은 아직 확정 못 함** — 같은 증상이면 누른 직후 화면(앱이 열리는지/소리만 처음부터 나는지)과 영상이 처음부터 시작되는 시점을 알려 줄 것
- **웹 PiP 버튼 4개 모두 넣기 (v2.5.90)**: v2.5.85 는 버튼 수 한도(`maxNumPictureInPictureActions`)가 4 미만이면 「이전 영상」 을 뺐음. 이제 한도와 상관없이 「이전 · 재생 · 다음 · 헤드셋」 4개를 항상 넘김. 시스템이 그릴 수 있는 개수보다 많으면 시스템이 **뒤쪽(헤드셋)부터** 자르므로, 3개만 보이는 기기에서는 헤드셋이 안 보일 수 있음 (앱에서 풀 수 없는 OS 한도)
- **「이전 영상」 이 현재 영상을 처음으로 돌리던 문제 수정 (v2.5.91)**: 유튜브 단일 영상처럼 페이지에 재생 목록 「이전」 버튼이 없으면 예전에는 항상 현재 영상 `currentTime=0` 이었음. 이제 재생 목록 「이전」 버튼이 있으면 시간과 상관없이 그걸 누르고, 없으면 `EvMedia.prevPage()` 로 웹 기록에서 바로 앞 페이지가 다른 영상 페이지(/watch, /shorts/, v= 등)일 때 그곳으로 돌아감(`MediaJs.prevPage`). 갈 곳이 없을 때만 현재 영상을 처음부터 재생. 앞 페이지가 영상이 아니면(검색 결과 등) 돌아가지 않음
- **유튜브에서 미디어 플레이어 제목이 옛 영상 제목으로 남던 문제 수정 (v2.5.92)**: 시스템 미디어 패널·메뉴 플레이어·미러링 제목은 페이지가 `navigator.mediaSession` 에 넣어 준 제목을 그대로 썼는데, 유튜브는 다음 영상으로 넘어가거나 앱이 화면 밖에 있는 동안 이 값이 늦게 갱신돼 화면의 영상은 "정치 대상"인데 패널에는 이전 영상 제목이 남았음. 이제 유튜브에서는 플레이어가 지금 틀고 있는 영상 정보(`getVideoData()` 의 제목·채널·video_id, `MediaScripts.ytNow`)를 `meta()` 에서 먼저 확인해, mediaSession 제목과 다르면 플레이어 값으로 바꿔 보고함. 아티스트는 채널 이름, 그림은 그 영상의 썸네일(`i.ytimg.com/vi/<id>/hqdefault.jpg`)로 함께 바뀌어 옛 영상 그림이 남지 않음. 광고 재생 중(`.ad-showing`)에는 광고 정보라서 건드리지 않음. 유튜브가 아닌 사이트는 기존 그대로
- **PiP·백그라운드 재생 뒤 앱을 다시 열면 페이지가 새로 불러와지던 문제 보완 (v2.5.93)**: **원인을 코드만으로 확정하지 못해** 가능성이 큰 두 갈래를 막음. ① 웹뷰 렌더러 우선순위: 기본값(`setRendererPriorityPolicy(IMPORTANT, waivedWhenNotVisible=true)`)은 화면에 안 보이면 낮은 우선순위라, PiP·백그라운드 재생으로 가려진 동안 메모리가 모자라면 렌더러가 먼저 종료되고 앱을 열 때 `recoverRenderer` 가 페이지를 다시 불러왔음. 이제 소리가 나는 탭이 있고 백그라운드 재생이 켜져 있거나 PiP 중이면 안 보여도 중요한 렌더러로 취급(`applyRendererPriority`, 새 웹뷰·미디어 상태 변경·PiP 전환 때 적용). ② 창 재생성: `configChanges` 에 없던 `keyboard|navigation|touchscreen|colorMode|uiMode` 가 바뀌면(키보드 커버·마우스 연결, 화면 색 모드 변경 등) 시스템이 창을 다시 만들어 탭이 복원·재로딩됐음. 메인·추가 창은 이 값들을 직접 받게 하고(`uiMode` 는 다크 모드가 실제로 바뀔 때만 `recreate()`, `onConfigurationChanged`), 내장 플레이어는 `uiMode` 를 뺀 나머지를 추가. 같은 증상이 남으면 다시 연 직후 「메모리가 부족해 페이지가 종료되어 다시 불러옵니다」 안내가 떴는지(렌더러 종료) 아니면 안내 없이 앱이 처음부터 시작됐는지(앱 프로세스 종료)를 알려 줄 것
- **PiP 에서 전체화면 버튼을 누르면 페이지가 새로 불러와지던 문제 수정 (v2.5.94)**: 넓은 화면에서는 데스크톱 사이트, 폰 화면에서는 모바일 사이트로 자동 전환하는데(`syncSiteModeWithLayout`), PiP 에서 전체 창으로 돌아오는 순간 시스템이 'PiP 아님' 을 먼저 알리고 창 폭은 아직 PiP 때의 작은 값으로 읽히는 때가 있어 '폰 화면' 으로 판단 → 사이트가 모바일로 바뀌며 페이지를 다시 불러오고, 폭이 제대로 오면 다시 데스크톱으로 바뀌며 또 불러왔음(앱을 다시 연 직후 "안내 없이 새로고침" 증상과 일치). 이제 PiP 중이거나 방금 나온 뒤 1.5초 동안(`pipSettling`)은 이 자동 전환을 하지 않고, 창 크기가 자리 잡은 뒤(1.7초) 실제 폭으로 한 번만 다시 판단함(`siteModeSettle`, 폭이 그대로면 아무것도 바뀌지 않음). 진짜로 화면 모양이 바뀐 경우(폰↔태블릿)는 그 뒤에 그대로 전환됨. 앞서 v2.5.93 에서 넣은 렌더러 우선순위·`configChanges` 보완은 그대로 둠(원인이 이것이 아니었더라도 해롭지 않은 안전장치). 코드로 확정한 것이 아니라 증상(안내 없이 새로고침, PiP 전체화면 버튼)에서 좁힌 원인이므로, 같은 증상이 남으면 알려 줄 것
- **모바일↔데스크톱 사이트를 바꿔도 보던 영상 위치에서 이어 재생 (v2.5.95)**: 사이트 모드를 바꾸면(상단바 버튼 `toggleDesktopSite`, 창 크기에 따른 자동 전환 `syncSiteModeWithLayout`) 페이지를 다시 불러오는데, 영상 위치를 이어 주는 이어보기(`resumeApply`)는 렌더러 종료·앱 복원 때만 켜져서 처음부터 다시 재생됐음. 이제 다시 불러오기 직전에 재생 보고(`mediaProg`)에서 지금 위치를 적어 두고(`carryPlaybackPosition`: 길이 10초 이상, 3초~끝 5초 전 구간, 재생 중이면 마지막 보고 뒤 흐른 시간을 더함) 새 페이지에서 영상이 준비되면 그 위치로 옮김(`resumeJs`). 유튜브는 모바일(m.)↔데스크톱(www.)으로 넘어가면 주소 앞머리가 달라 같은 영상으로 못 알아보던 것도 `m.`·`www.` 를 무시하고 비교하도록 보완(`resumeHost`). 일시정지해 둔 영상이라도 다시 불러오면 사이트가 자동 재생하는 동작은 그대로
- **「모바일/데스크톱 자동 전환」 설정 추가 (v2.5.96)**: 설정 > 브라우저 > 일반에 켜고 끄는 스위치(`Prefs.autoSiteMode`, 기본 켜짐)를 추가. 켜져 있으면 지금까지처럼 창이 넓으면 데스크톱 사이트, 좁으면 모바일 사이트로 자동 전환(바뀔 때 페이지를 다시 불러오고 보던 영상 위치는 이어 감). 끄면 창 크기·분할 화면·PiP 로 폭이 바뀌어도 사이트 모드를 건드리지 않고 직접 고른 모드를 유지하며, 상단바/메뉴의 데스크톱 버튼으로만 바꿈(`syncSiteModeWithLayout` 맨 앞에서 확인). 다시 켜면 지금 창 크기에 맞춰 바로 판단함. 폰↔태블릿 **화면 구성(바·탭 줄 배치)** 전환은 이 설정과 상관없이 그대로 창 크기를 따름. 설정 검색에도 등록(pc·데스크탑·분할 화면 등으로 찾아짐)
- **분할·팝업 창에서 미러링 영상이 창 가득 안 차던 것 수정 (v2.5.97)**: 미러링은 페이지 영상을 `100vw`×`100vh`(레이아웃 뷰포트)로 키우는데, 분할 화면·팝업 창으로 창 크기가 바뀌면 페이지 배율이 새 창에 다시 맞춰지지 않아 이 크기가 실제로 보이는 영역의 약 80% 만 되어, 영상이 왼쪽 위에 작게 붙고 오른쪽·아래가 비었음(창 크기가 바뀌는 것을 미러링은 PiP 진입·복귀 때만 알아챘음). ① 영상 칸을 `max(100vw, 보이는 영역 CSS px)`(`--ev_mw`/`--ev_mh`, `mSizeOn`/`mSizeSync`)로 잡고, `resize`·`visualViewport.resize` 때마다 다시 잼. ② 창 크기가 바뀔 때(`onConfigurationChanged`·`onMultiWindowModeChanged`·웹 영역 가로/세로 크기 변화) 미러링 중이면 크기가 멎은 뒤(0.3초) `nudgeMirrorLayout` 이 앱이 잰 보이는 영역(웹뷰 px ÷ 페이지 배율)을 페이지에 알려(`MediaScripts.mirrorResize`) 영상을 다시 창 가득 맞춤(0.4초 뒤 한 번 더). 미러링을 끄면 이 값들은 지움. 내장 플레이어(`PlayerActivity`)는 해당 없음
- **탭 화면 전환 애니메이션의 미리보기에서 사진이 찌그러지고 배치가 달라지던 것 수정 (v2.5.98)**: 탭 버튼을 눌러 페이지가 탭 카드로 줄어드는 그림을 웹뷰를 소프트웨어 캔버스에 0.6배로 다시 그려(`View.draw`) 만들었는데, 이 방식은 웹뷰가 실제 화면과 다르게(사진이 눌리고 배치가 조금 다르게) 그려질 수 있었음. 이제 탭 화면을 열 때는 화면에 이미 그려진 픽셀을 PixelCopy 로 그대로 복사해 와서(`capturePixels`, 보통 수십 ms 기다림, RGB_565 로 줄여 보관) 그 그림으로 줄어듦·카드 미리보기를 만듦. 탭 화면을 닫을 때(카드 → 페이지)는 탭 화면이 위에 떠 있어 다시 복사할 수 없으므로, 열 때 찍어 둔 그림이 지금 페이지 영역과 같은 비율이면 그 그림을 그대로 쓰고 비율이 달라졌을 때만 예전처럼 다시 그림. 시크릿 탭(FLAG_SECURE)·복사 실패 때는 예전 방식으로 대신함. 탭을 바꿀 때 남기는 미리보기(`selectTab`)는 메뉴·팝업의 흐림 효과가 같이 찍힐 수 있어 그대로 둠
- **내장 플레이어 재생/일시정지 버튼 애니메이션을 자연스럽게 (v2.5.99)**: 내장 플레이어(`PlayerActivity`)와 미러 오버레이(`MirrorOverlay`)의 버튼은 재생 삼각형 ↔ 일시정지 막대로 모양이 바뀔 때 스프링(감쇠 0.62)을 써서 목표를 넘나들며 출렁였고, 막대가 늘어났다 줄어드는 식으로 모양이 일그러져 보였음. 이제 `MorphIconDrawable.settle` 이 `player` 종류에는 스프링 대신 `SmoothClock` + `PathInterpolator(0.4, 0, 0.2, 1)` 곡선으로 300ms 동안 넘치지 않고 매끄럽게 변하고, 변하는 중간에는 최대 6% 작아졌다 돌아와 숨 쉬듯 이어짐(도중에 상태가 또 바뀌면 지금 모양에서 남은 거리만큼만 시간을 써서 되돌아감). 메뉴창의 미디어 플레이어(`MainActivity` 의 `setPlayIcon`)는 이미지를 통째로 바꾼 뒤 버튼을 비틀어 튕기던 방식이어서 어색했는데, 같은 `player` 모양 변하는 아이콘으로 바꿔 세 플레이어가 똑같이 움직임. 모션 끄기 설정이면 바로 바뀜. PiP 작은 창의 버튼은 시스템이 그려서 그대로 둠
- **내장 플레이어·미러링 플레이어 컨트롤 버튼 배치 정리 (v2.5.100)**: 예전에는 재생 · 이전 · 10초 뒤로 · 10초 앞으로 · 다음 순서로 왼쪽에 몰려 있어 이전/다음이 10초 버튼 양옆으로 갈라져 보였고, 세로 화면(폭 430dp 미만)에서는 10초 버튼을 아예 숨겼음. 이제 아래 컨트롤을 세 줄로 나눠 1줄: 이전 · 10초 뒤로 · 재생/일시정지(가장 크게, 가운데) · 10초 앞으로 · 다음을 가운데 정렬로 좌우 대칭 배치, 2줄: 진행 막대, 3줄: 시간(왼쪽) … 배속 · CC · 설정(오른쪽). 줄이 나뉘어 좁은 화면에서도 넘치지 않으므로 10초 버튼 숨김 코드를 없앰. 위·아래 어두운 막은 늘어난 높이에 맞춰 200dp 로 키움(`ev_player_controls.xml`, `MirrorOverlay`). 메뉴창 미디어 플레이어는 이미 이전 · 10초 · 재생 · 10초 · 다음이 같은 간격으로 대칭이라 그대로 둠
- **플레이어 재생·이전·다음·10초 버튼을 화면 한가운데로 (v2.5.101)**: v2.5.100 에서 아래 한 줄로 모아 둔 이전 · 10초 뒤로 · 재생/일시정지 · 10초 앞으로 · 다음 버튼을 영상 한가운데로 옮김(`ev_player_controls.xml`, `MirrorOverlay`). 아래에는 진행 막대 + 시간 · 배속 · CC · 설정 두 줄만 남아 아래 어두운 막을 150dp 로 줄임. 밝은 영상 위에서도 가운데 버튼이 보이게 컨트롤이 떠 있는 동안 영상을 살짝(20%) 어둡게 함(`ev_dim`). 가운데에 버튼이 생겨서 이동 시간·배속·이어서 재생 같은 가운데 안내(OSD)는 위쪽 바 바로 아래 가운데로 옮김
- **10초 이동 버튼을 숫자가 들어간 화살표 모양으로 (v2.5.102)**: 내장 플레이어 · 미러링 플레이어 · 메뉴창 미디어 플레이어의 10초 뒤로/앞으로 버튼을 Tabler 의 `rewind-backward-10` / `rewind-forward-10` 모양(꺾이는 화살표 + 숫자 10, 선 2)으로 바꿈(`ic_rewind_10`, `ic_forward_10`). 숫자가 그림 안에 들어가서 따로 얹던 "10" 글자(`TextView`·`IconNumberView`)는 없앰. 버튼을 누르면 숫자는 그대로 있고 화살표만 가는 방향(되감기 = 왼쪽, 빨리감기 = 오른쪽)으로 쏘았다가 돌아옴(`MorphIconDrawable` 의 `skipback`/`skipfwd`). 이전·다음 버튼 아이콘도 같은 크기(24dp)로 맞춤
- **자막 번역 속도 높이기 (v2.6.00)**: 예전에는 자막 줄이 화면에 뜬 뒤에야 한 줄씩 번역을 요청해서, 번역이 올 때까지 원문이 흐리게 보였음. 이제 영상에 딸려 온 자막 파일(VTT/SRT/ASS/TTML)을 재생 시작 때 통째로 받아서 지금 위치부터 30줄씩 미리 번역해 둠(`PlayerActivity.startSubPrefetch`, 별도 스레드·별도 `FreeTranslator`, 줄 사이 0.12초 간격, 번역 서버가 막으면 멈추고 줄 단위 번역으로 이어감). 번역 기억(`subCache`)은 600 → 4000 줄. `FreeTranslator.post` 는 성공한 연결을 끊지 않아 다음 요청이 같은 연결을 재사용. 영상 안에 들어 있는 자막(파일이 따로 없는 경우)은 미리 받을 수 없어 예전처럼 뜨는 순간 번역
- **컨트롤이 떠 있으면 가운데 더블탭 효과 숨기기 (v2.6.01)**: 내장 플레이어(`PlayerActivity`)와 미러링 플레이어(`MirrorOverlay`)에서 재생/일시정지 버튼이 있는 컨트롤이 보이는 동안 화면 가운데를 더블탭하면, 재생·일시정지는 그대로 되지만 가운데 동그라미 효과(`DoubleTapFx.center`)는 띄우지 않음. 컨트롤이 숨어 있을 때만 효과가 뜸. 좌우 더블탭(10초 이동) 효과는 그대로
- **재생바를 끌 때 막대·손잡이 애니메이션을 부드럽게 (v2.6.02~v2.6.03)**: 새 파일 `SmoothSeek.kt`. 끌기 시작하면 막대가 굵어지고(4→7dp) 손잡이가 톡 커지고(7→13dp, 살짝 넘쳤다 돌아옴), 놓으면 부드럽게 원래대로 돌아옴(`PressAnim`: 누를 때 `OvershootInterpolator`, 뗄 때 `DecelerateInterpolator`). ① 내장 플레이어: `DefaultTimeBar` 대신 직접 만든 `SmoothTimeBar`(미디어 컨트롤의 `TimeBar` 구현, `ev_player_controls.xml` 의 `exo_progress`)를 씀 — 처음 누른 자리로 손잡이가 순간이동하지 않고 0.14초 동안 미끄러져 가고, 손을 떼면 놓은 자리에 머물러 예전 위치로 튕기지 않음 ② 미러링 플레이어: `MirrorSeekBar` 의 굵기·크기 변화가 즉시 바뀌던 것을 같은 애니메이션으로 ③ 메뉴창 미디어 카드: `SmoothSeekTrack`(막대 6→9dp) · `SmoothSeekThumb`(손잡이 14→22dp)를 `mediaSeek` 에 코드로 끼움(손잡이 자리 크기는 14dp 그대로라 누를 때 높이가 출렁이지 않음)
- **재생바 손잡이 둘레의 은은한 빛 없앰 (v2.6.03)**: v2.6.02 에서 끌 때 손잡이 둘레에 퍼지던 옅은 빛(halo)을 내장 플레이어(`SmoothTimeBar`)와 미러링 플레이어(`MirrorSeekBar`)에서 뺌. 막대 굵기·손잡이 크기 애니메이션은 그대로
- **메뉴창 미디어 카드의 이전·10초 뒤로·10초 앞으로·다음 버튼 뒤 동그라미 없앰 (v2.6.04)**: `dialog_menu.xml` 의 `mediaPrev` · `mediaBack` · `mediaFwd` · `mediaNext` 에서 `bg_share_btn` 배경을 뺌. 아이콘만 보이고, 누를 때 살짝 줄어드는 눌림 효과(`Motion.pressable`)는 그대로. 재생/일시정지 버튼의 동그라미는 그대로
- **내장 플레이어·미러링 화면도 가운데를 아래로 밀어 나가기 (v2.6.05)**: 전체화면 영상에 있던 「아래로 밀어 나가기」(`FullscreenSwipeLayout`)를 내장 플레이어(`PlayerActivity`)와 미러링 화면(`MirrorOverlay`)에도 씀. 화면 가운데에서 아래로 밀면 화면이 손가락을 따라 내려오며 작아지고, 충분히(화면 높이의 22%) 또는 빠르게 밀고 놓으면 닫힘(내장 플레이어는 `finish()`, 미러링은 `stopMirror()`), 모자라면 탄성 있게 제자리로 돌아옴. 같은 설정(`swipeDownExit`)으로 한꺼번에 켜고 끔. 진행 막대를 끄는 터치와 겹치지 않게 `FullscreenSwipeLayout.startFilter` 를 새로 넣어 컨트롤이 떠 있을 때 막대 위에서 시작한 터치는 뺌. PiP 중 · 확대 전환 중 · 미러링 자막 패널이 열려 있을 때는 꺼짐
- **미러링에서 아래로 밀어 나갈 때 영상도 같이 내려감 (v2.6.06)**: 미러링은 영상이 컨트롤 UI(`MirrorOverlay`) 뒤쪽 웹뷰 안에 있어서, 예전엔 밀면 컨트롤 UI 만 내려가고 영상은 제자리에 남았음. `FullscreenSwipeLayout` 에 `companions` 를 새로 넣어 미러링에서는 웹뷰 영역(`webContainer` 의 부모)도 컨트롤과 같은 위치·크기·투명도로 움직이게 함(끌기 · 나가기 · 되돌아가기 모두). 미러링을 닫을 때 `removeMirrorOverlay()` 가 `resetTransform()` 으로 웹뷰 영역 변형을 원래대로 돌려 놓음
- **미러링 밀어 내리기: 드러나는 바탕을 검정으로 (v2.6.07)**: v2.6.06 에서 웹뷰 영역이 작아지며 내려가면, 그 뒤의 앱 루트 뷰 배경(`colorSurface`, 밝은 테마에서는 흰색)이 드러나 번쩍였음. `addMirrorOverlay()` 가 미러링 동안만 루트 뷰 배경을 검정으로 바꾸고 `removeMirrorOverlay()` 가 원래 배경으로 되돌림
- **내장 플레이어: 일시정지 중에도 PiP (v2.6.08)**: `PlayerActivity.pipParams()` 의 자동 진입(`setAutoEnterEnabled`, Android 12+)과 `onUserLeaveHint()` (Android 11 이하)가 재생 중일 때만 켜져 있어서, 멈춘 영상은 홈으로 나가도 작은 창이 되지 않았음. 이제 플레이어가 준비돼 있고 닫히는 중이 아니면 멈춰 있어도 들어감. `onStart()` 에서도 `updatePipParams()` 를 불러 멈춘 채 열어도 자동 진입이 켜지게 함
- **미러링: 일시정지 중에도 PiP 버튼 (v2.6.09)**: 미러링 화면의 PiP 버튼(`startPipFromMenu`)은 `pipWanted()` 가 참일 때만 들어가는데, 영상을 멈추면 재생 정보(`mediaFrames`)가 비워져서 거짓이 되어 「재생 중인 동영상이 없어요」 가 떴음. 미러링 중(`mirrorActive`)에는 항상 참으로 둠. (홈으로 나갈 때 자동 진입은 `autoPipWanted()` 가 이미 `mirrorActive` 로 처리하고 있었음)
- **PiP 로 들어간 창이 사라지는 문제 진단 기록 (v2.6.10)**: 새 파일 `PipDiag.kt`. `enterPip()` 로 PiP 를 시작하면 창 종류·작업 번호·미러링 여부·멀티윈도우 여부를 적고, 이어서 `onPictureInPictureModeChanged` · `onPause` · `onStop` · `finish()` / `finishAndRemoveTask()` (부른 곳의 호출 스택 포함) · `onDestroy` 를 기록함. 창이 PiP 도중 파괴됐다면 다음에 앱 화면이 보일 때 「PiP 진단 기록」 창을 한 번 띄워 복사할 수 있게 함. 원인을 찾으면 이 기록 기능은 걷어 낼 것
- **모든 내장 플레이어에 영상 로딩 표시 (v2.6.11)**: 새 파일 `VideoLoadingView.kt` — 재생 버튼을 감싸며 도는 고리(길이가 늘었다 줄었다 하는 호, 앱 강조색). 250ms 안에 끝나는 짧은 끊김에는 나타나지 않고, 터치는 통과함. ① 내장 플레이어(`PlayerActivity`): media3 기본 버퍼링 표시(재생 중일 때만 나왔음)를 끄고 `syncLoading()` 이 처음 불러오는 중(IDLE, 오류 없음)·버퍼링(BUFFERING)·멈춘 채 이동하는 중에도 고리를 켬. 오류 상자가 뜨거나 오류가 나면 끔. ② 미러링(`MirrorOverlay`): 페이지 스크립트(`mrep`)가 `!ended && readyState<3 && (!paused || seeking)` 일 때 `EvMedia.mload()` 로 알려 오면 고리를 켬(바뀔 때만 보냄). `waiting`·`stalled`·`seeking`·`canplay`·`emptied` 이벤트를 더 들어 빨리 반응함
- **영상 로딩 고리 등장·퇴장을 더 자연스럽게 (v2.6.12)**: `VideoLoadingView` — 나타날 때 0.82배 크기·투명에서 시작해 320ms 동안 감속하며 커지고 떠오름(호는 가장 짧은 길이에서 시작해 늘어남), 사라질 때 240ms 동안 가속하며 0.92배로 작아지며 흐려짐. 사라지던 중 다시 로딩이 시작되면 끊김 없이 다시 또렷해짐
- **영상 로딩 고리 회전 애니메이션을 더 자연스럽게 (v2.6.13)**: `VideoLoadingView` — 예전 계산은 한 바퀴가 끝나고 다시 시작할 때 호 길이가 230°→40°로 튀었음. 이제 머리·꼬리가 각자 감속 곡선(`PathInterpolator(0.4,0,0.2,1)`)으로 움직이는 머티리얼식 방식(주기 1333ms, 호가 24°~약 200°로 늘고 줄며 매 주기 290°씩 앞으로 나아감, 고리 전체는 1600ms에 한 바퀴)으로 바꾸고, 시간은 애니메이터 값 대신 흘러간 시간으로 직접 계산해 경계에서 끊기지 않게 함
- **메뉴 미디어 카드: 일시정지 버튼과 10초 이동 버튼 사이 여백 확대 (v2.6.14)**: `dialog_menu.xml` — `mediaPlay` 의 좌우 margin 을 4dp → 16dp 로 늘려 일시정지·10초 뒤로/앞으로 버튼이 덜 붙어 보이게 함
- **유튜브 광고 차단을 광고 차단에서 분리해 별도 설정으로 (v2.6.16)**: 설정 「광고 차단」 묶음에 「유튜브 광고 차단」 토글(`Prefs.ytAdBlock`, 기본 켜짐) 추가. 유튜브 전용 처리(광고 칸 숨김 CSS · 광고 재생 중 16배속·음소거로 끝까지 넘기기 · 오버레이 닫기 클릭)를 `AdBlocker.COSMETIC_START_JS` 에서 `AdBlocker.YT_AD_START_JS` 로 옮겨, 일반 「광고 차단」 켜짐/꺼짐과 무관하게 이 토글만으로 동작하고, 바꾸면 페이지를 새로 불러오지 않아도 0.5초 안에 반영됨. 「유튜브 광고 건너뛰기 자동 클릭」·「다음 영상」 때의 광고 건너뛰기는 그대로
- **영상이 끝나면 '다음 영상' 카드 (v2.6.18)**: 새 `UpNextCard` — 유튜브 미러링에서 영상이 끝나면(`MediaScripts.mNextScan`이 끝 화면 `.ytp-videowall-still`·자동 재생 카드 `.ytp-autonav-endscreen-upnext-*`를 읽어 `EvMedia.mnext`로 전달) 큰 카드(썸네일·제목·채널·길이·자동 재생 카운트다운)와 추천 영상 가로 줄, '다시 보기'·'취소'·'다음 영상' 버튼을 띄움. 항목을 못 읽는 사이트와 일반 내장 플레이어(`PlayerActivity`)는 '다시 보기'·'다음 영상' 버튼만
- **'다음 영상' 카드 디자인 개선 (v2.6.19)**: 첫 영상 썸네일을 흐리게 깐 배경, 둥근 큰 카드(썸네일·제목·채널·길이) + 자동 재생 남은 초 알약("5초 후 자동 재생")·카운트다운 고리, '이어서 볼 영상' 목록(세로 화면은 가로 줄, 가로 화면은 왼쪽 큰 카드 + 오른쪽 세로 목록), 카드·줄 눌림 효과와 순서대로 떠오르는 등장 효과, 회전·분할 화면 때 다시 배치. 고리가 이미 붙어 있다는 오류(두 번째 표시 때)도 막음
- **'다음 영상' 카드 태블릿 화면 개선 (v2.6.20)**: 짧은 변이 600dp 이상이면 글자·카드·버튼을 1.3배, 840dp 이상이면 1.5배로 키움. 세로 화면은 카드 폭 확대, 가로 화면은 큰 카드 + 오른쪽 '이어서 볼 영상'을 두 줄(격자)로 배치
- **유튜브 광고 차단을 켜면 미러링(내장 플레이어)이 로딩만 돌던 문제 보완 (v2.6.21)**: ① 광고를 끝으로 넘기면 광고 영상이 `ended` 가 되는데 이때 '다음 영상' 카드가 떠서 본 영상을 가렸음 → 유튜브 광고 중(`ad-showing`)에는 끝 화면 목록을 보내지 않음(`MediaScripts.ytAdOn`). ② 유튜브가 광고→본 영상으로 넘어가며 `<video>` 를 새로 만들면 표시한 영상(`__ev_pip`)이 사라져 화면이 까맣고 로딩 고리만 남던 것 → 새 영상에 미러링을 다시 붙이고, 못 찾으면 로딩 고리를 걷음(`mrep`). ③ 광고 넘기기(`YT_AD_START_JS`)의 16배속이 본 영상에 남으면 되돌림. **원인은 코드만으로 확정 못 함** — 같은 증상이면 그때 화면(까만지/광고/카드)과 광고 구간에서만 그런지 알려 줄 것
- **유튜브 '사이트 방문' 끝 카드 광고가 안 넘어가던 문제 수정 (v2.6.22)**: 광고 영상이 끝난 뒤 '사이트 방문'·'건너뛰기' 끝 카드만 남는 광고는 영상 길이가 있어서 `YT_AD_START_JS` 가 건너뛰기 버튼을 누르지 않고 끝으로 넘기기만 반복했음. 이제 건너뛰기 버튼이 보이면 광고 상태와 상관없이 누르고(`skipBtn`: 알려진 클래스 + 광고 영역 안 '건너뛰기/Skip' 글자 버튼, 크기·display 로만 판단), 포인터·마우스 이벤트를 차례로 보냄(`tap`). 이미 끝난 영상은 다시 끝으로 보내지 않음
- **유튜브 광고 차단: 영상 없는 광고도 숨김 (v2.6.17)**: `YT_AD_START_JS` — 숨기는 목록을 모바일(`ytm-`·`ad-slot-renderer`)·데스크톱(`ytd-`) 피드 광고 카드, 스폰서·배너·브랜드 영상, 광고 슬롯을 품은 피드 항목(`:has()`), 플레이어 위 이미지/글자/유료 광고 오버레이까지 넓힘. 광고 중인데 영상 길이가 없는 경우(이미지 광고)에는 건너뛰기 버튼을 눌러 봄
- **사진 팝업: 확대 제거 + 사라짐 애니메이션 (v2.5.25)**: 팝업의 사진을 눌러도 전체 화면으로 확대되지 않고 닫히기만 함. 닫힐 때(바깥 터치·뒤로가기·사진 터치) 칩 쪽으로 살짝 작아지며 흐려지는 애니메이션(150ms) 추가
- **사진 칩 항목은 글머리표 제거 (v2.5.24)**: 사진 칩이 붙은 목록 항목은 「•」 없이 칩부터 시작하고 들여쓰기도 맞춤
- **사진 칩 아래 줄에 설명 글 (v2.5.23)**: 사진 칩 뒤에 이어지는 설명 글을 같은 줄이 아니라 칩 아래 줄에서 시작하도록 줄바꿈(목록 안에서는 들여쓰기 유지)
- **AI 사진 바로가기 칩 자연스럽게 (v2.5.22)**: 칩이 글보다 커서 첫 줄이 들뜨고 줄 간격이 벌어지던 것을, 칩을 작게(높이 20dp·썸네일 16dp·글자 11) 하고 글줄 높이를 건드리지 않은 채 글자 가운데 높이에 맞춰 그리도록 수정(`CenteredImageSpan`)
- **AI 사진 바로가기: 버튼 아래 팝업으로 표시 (v2.5.21)**: 「사진 N」 칩을 누르면 전체 화면 대신 그 칩 바로 아래(공간이 모자라면 위)에 사진이 작은 팝업으로 뜸. 사진을 누르면 전체 화면 보기, 바깥을 누르거나 뒤로 가면 닫힘(`showPhotoPopup`)
- **AI 사진 바로가기 UI 개선 (v2.5.20)**: 「🖼 사진 N」 글자 링크 대신, 둥근 사진 썸네일 + 「사진 N」이 들어간 알약 모양 칩(강조색 테두리)으로 표시. 누르면 그 사진을 크게 보여 줌(`photoChipDrawable`)
- **AI 사진 바로가기를 설명하는 글마다 배치 (v2.5.19)**: AI 가 사진을 설명할 때 사진마다 설명 글 맨 앞에 [[사진N]] 표시를 달게 하고, 앱이 그 자리를 「🖼 사진 N」 바로가기로 바꿔 누르면 그 사진을 크게 보여 줌(`ReplyBubble.images`, `photoMarkRe`). 답변 아래의 「사진 보기」 버튼은 AI 가 표시를 달지 않았을 때만 대신 나타남. 답변 복사 시에는 「사진 N」 글자로 바뀜
- **빌드 알림이 Now Bar에 안 뜨던 것 수정 (v2.5.18)**: v2.5.13에서 넣은 colorized(바탕 채움)가 Live Updates 승격 조건(colorized 금지)에 걸려 Now Bar에 올라가지 못했음 → colorized 해제, 강조색(`ev_accent`)만 지정하고 카테고리를 진행(progress)으로 지정
- **새 탭 화면에서 AI 「바로 물어보기」 칩 비활성 (v2.5.17)**: 현재 탭이 새 탭(홈) 화면이면 칩(이 페이지 요약·핵심 3줄·선택한 글 설명·사진 설명)을 흐리게 하고 눌러도 동작 대신 안내 토스트만 표시. 탭 전환·홈↔페이지 전환 때 바로 갱신(`refreshChips`)
- **AI 보내기 버튼 애니메이션 중 잘림 수정 (v2.5.16)**: 보내기 버튼이 눌림·튕김으로 커질 때 입력줄과 패널 안쪽 여백(clipToPadding)에 잘리던 것을 해제
- **AI 어시스턴트 칩 버튼 애니메이션 중 잘림 수정 (v2.5.15)**: 칩 줄(가로 스크롤)이 떠오르는·눌림 튕김 동작의 위아래를 잘라내던 것을, 위아래 여유 칸(8dp, 바깥 여백으로 상쇄)과 clipToPadding/clipChildren 해제로 해결
- **AI 분할 열고 닫을 때 웹 영역이 느리게 변하던 것 개선 (v2.5.14)**: 열림·닫힘 애니메이션 동안 웹 영역 너비를 매 프레임 바꾸던 것(웹뷰가 매번 다시 배치돼 버벅임)을, 시작할 때 한 번에 최종 너비로 바꾸고 패널만 미끄러지게 변경. 애니메이션도 약간 짧게(열기 220/260ms, 닫기 200ms). 패널 너비를 끌어 조절할 때는 기존처럼 실시간
- **Now Bar 배경색 (v2.5.13)**: 빌드 진행을 Now Bar·상태표시줄 칩에 올릴 때 알림 색을 앱 초록(`ev_accent`)으로 칠하고 colorized 로 바탕을 채움
- **AI 분할: 웹 영역 너비를 실시간 반영 + 모바일↔데스크톱 자동 전환 (v2.5.12)**: AI 분할 패널의 너비를 끄는 동안 웹 영역 너비가 바뀔 때마다(약 0.07초 간격) 페이지 뷰포트(데스크톱 사이트 폭·페이지 확대 기준)를 새 폭에 맞춰 다시 배치(`onWebAreaResized`, `webAreaWidthDp`). 분할로 웹 영역이 600dp 미만이 되면 모바일 사이트로, 560dp 이상이 되면 데스크톱 사이트로 자동 전환(0.3초 뒤 확정, 경계에서 깜빡이지 않게 히스테리시스). 분할을 닫으면 창 너비 기준으로 복귀. 직접 누른 모바일/데스크톱 버튼은 다음 전환 전까지 우선
- **AI 「응답이 없어요」 화면 개선 (v2.5.11)**: 빈 답일 때 회색 글자 대신 붉은 오류 말풍선(「AI가 답을 주지 않았어요」)으로 안내하고, 질문을 입력창에 되돌림. 오류·빈 답 말풍선에 「↻ 다시 시도」 버튼 추가(실패한 질문·오류를 치우고 같은 질문을 다시 보냄)
- **「설명한 사진 보기」 버튼 문구 변경 (v2.5.10)**: 「사진 보기」로 바꿈
- **AI 사진 설명: 말풍선 위 사진 제거 (v2.5.09)**: 내 말풍선 위에 사진을 띄우지 않음. 사진은 답변 아래 「사진 보기」 버튼으로만 크게 볼 수 있음
- **AI 사진 설명: 사진 크게 보기 바로가기 (v2.5.08)**: 내 말풍선 위 사진을 누르면 전체 화면으로 보여 줌(여러 장이면 누를 때마다 다음 사진). 사진을 보낸 질문의 답변 아래에도 「설명한 사진 보기」 버튼이 생김
- **AI 어시스턴트가 사진을 설명할 때 그 사진을 보여 줌 (v2.5.07)**: 질문과 함께 AI 에게 보낸 사진을 내 말풍선 위에 보여 줌(한 장이면 크게, 여러 장이면 작게 최대 4장 + 나머지는 +N). 대화를 다시 열어도 유지됨
- **AI 어시스턴트 「핵심 3줄」 아이콘 변경 (v2.5.06)**: 체크 표시 대신 세 줄 목록 아이콘(`ic_lines3`)으로 바꿈
- **탭 화면 창 전환 시 분할 대신 교체 (v2.5.05)**: 탭 화면의 창 목록에서 다른 창(열린 창·닫힌 창)을 누르면 옆에 붙여 분할로 열지 않고, 선택한 창을 연 뒤 지금 창은 닫음(탭은 남아 창 목록에서 다시 열 수 있음). 「＋ 새 창」은 기존처럼 옆에 붙여 열림
- **내장 플레이어 확대 전환 제거 + 닫은 뒤 페이지 영상 다시 그리기 (v2.5.04)**: ① 영상 아래 「내장 플레이어로 열기」(·메뉴·위쪽 바의 내장 플레이어)를 누르면 페이지 영상이 커지며 열리던 전환(`PlayerZoom`)을 쓰지 않고 바로 플레이어를 엶(영상 자리 알림·버튼 숨김·AI 창 사라짐도 함께 없어짐). ② 플레이어를 닫고 돌아오면 웹페이지의 영상이 비어 보이던 것을 고침 — 돌아온 직후와 0.6초 뒤 두 번, 페이지(iframe 포함)의 영상마다 합성 층을 새로 만들고 멈춘 영상은 같은 자리를 다시 찾아 장면을 다시 그리게 함(`MediaScripts.REPAINT`). 미러링의 확대는 그대로
- **확장 프로그램 로그인 (v3.5.7)**: `chrome.identity.launchWebAuthFlow` / `getAuthToken` 지원. 전체 화면 웹뷰 로그인 창(`ExtensionManager.showAuthFlow`)을 띄우고(UA 에서 `; wv` 제거), 주소가 `https://<확장 id>.chromiumapp.org/…` 에 닿으면 그 주소를 확장에 돌려줌. `getAuthToken` 은 manifest `oauth2.client_id`·`scopes` 로 구글 implicit 흐름(`response_type=token`)을 같은 창으로 돌려 토큰을 받음(메모리 캐시). 크롬 앱용 클라이언트는 리디렉션 `https://<id>.chromiumapp.org/` 를 허용하므로 스토어에서 받은 확장(같은 id)이면 동작. 팝업·사이드 패널·백그라운드 웹뷰는 서드파티 쿠키 허용(v3.5.6). 한계: Firebase `signInWithPopup` 처럼 `window.open` + postMessage 로 하는 로그인은 아직 미지원
