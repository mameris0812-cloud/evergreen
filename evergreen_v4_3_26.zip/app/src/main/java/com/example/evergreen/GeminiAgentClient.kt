package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini 도구 호출(function calling)용 스트리밍 클라이언트. 반드시 백그라운드 스레드에서 부른다.
 *
 * [GeminiClient] 는 글만 주고받지만, 에이전트는 모델이 "이 도구를 이 인자로 불러 줘" (functionCall) 라고 답하고
 * 앱이 실행한 결과를 "functionResponse" 로 돌려주는 대화를 이어 간다. 그래서 대화(contents)를 글이 아니라 JSON 그대로 다룬다.
 * 모델이 보낸 부분(parts)은 생각 서명(thoughtSignature) 까지 그대로 다시 보내야 다음 단계가 이어진다.
 *
 * 한 번 쓰고 버리는 객체다 (한 번의 에이전트 실행 = 하나). [cancel] 은 진행 중인 요청을 끊고, 이후의 요청도 바로 멈춘다.
 */
class GeminiAgentClient {
    companion object {
        private const val MAX_OUTPUT_TOKENS = 16384
        private const val SAME_MODEL_RETRIES = 2

        /** 글(과 사진) 한 줄을 대화 JSON 으로 */
        fun content(m: ChatMsg): JSONObject {
            val parts = JSONArray()
            // 사진은 글보다 앞에 둔다 (Gemini 권장 순서)
            for (img in m.images) parts.put(img.toPart())
            parts.put(JSONObject().put("text", m.text))
            return JSONObject().put("role", m.role).put("parts", parts)
        }

        /** 글도 도구 호출도 없이 끝난 응답을 사람이 읽을 말로 */
        fun emptyMessage(s: Step): String = when {
            s.blocked.isNotEmpty() -> "요청이 안전 정책에 의해 차단되었어요 (${s.blocked})"
            s.finish == "MALFORMED_FUNCTION_CALL" -> "AI가 도구를 잘못 불러서 멈췄어요. 다시 시도해 주세요"
            s.finish.isNotEmpty() && s.finish != "STOP" -> "응답이 비어 있어요 (${s.finish})"
            else -> "응답이 비어 있어요"
        }
    }

    /** 모델이 부르려는 도구 하나 */
    class Call(val name: String, val args: JSONObject, val id: String)

    /**
     * 한 단계의 결과. [parts] 는 모델이 보낸 내용 그대로(다음 요청에 되돌려 보낸다), [calls] 는 그중 도구 호출.
     * [error] 가 있으면 실패다.
     */
    class Step(
        val parts: JSONArray,
        val calls: List<Call>,
        val finish: String,
        val blocked: String,
        val error: String?
    )

    private class Once(val step: Step, val code: Int, val badKey: Boolean, val body: String)

    @Volatile
    private var conn: HttpURLConnection? = null

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
        try {
            conn?.disconnect()
        } catch (e: Exception) {
            // 이미 끝난 연결
        }
    }

    /**
     * 모델을 한 번 부른다. 받는 글은 [onText], 생각 요약은 [onThought] 로 흘려 보낸다.
     * [allowCalls] 가 false 면 도구 선언은 그대로 두되 모델이 도구를 부르지 못하게 한다 (마무리 정리용).
     * [canSwitchModel] 은 모델·서버 문제일 때 다른 모델로 바꿔 다시 보내도 되는지 (이미 이어 온 대화는 모델을 바꿀 수 없다).
     * 아무것도 받기 전의 일시적인 오류(한도·서버)는 키를 바꾸거나 잠깐 뒤에 다시 보낸다.
     */
    fun step(
        apiKey: String,
        model: String,
        system: String,
        contents: JSONArray,
        decls: JSONArray,
        thoughts: Boolean,
        allowCalls: Boolean,
        canSwitchModel: Boolean,
        onText: (String) -> Unit,
        onThought: (String) -> Unit
    ): Step {
        // 이미 한도로 쉬는 걸 아는 모델이면 처음부터 쓸 수 있는 모델로 보낸다 (이어 온 대화는 모델을 못 바꾼다)
        var curModel = if (canSwitchModel) GeminiAuto.usableOrFallback(GeminiAuto.live(model)) else GeminiAuto.live(model)
        var curKey = apiKey
        val tried = mutableSetOf(curModel)
        val triedKeys = mutableSetOf<String>()
        var delivered = 0
        var sameRetries = 0
        var modelSynced = false
        GeminiModelSync.refreshIfStale(apiKey)
        while (true) {
            GeminiKeyPool.used(curKey)
            val o = once(
                curKey, curModel, system, contents, decls, thoughts, allowCalls,
                { t ->
                    delivered += t.length
                    onText(t)
                },
                { t ->
                    delivered += t.length
                    onThought(t)
                }
            )
            if (cancelled || o.step.error == null) return o.step
            // 이미 화면에 흘려 보낸 게 있으면 다시 보내면 글이 겹친다
            if (delivered > 0) return o.step

            val code = o.code
            // 한도가 아닌 429 는 서버가 붐비는 것이라 키를 쉬게 하거나 바꾸지 않고 모델 전환 · 재시도로 넘긴다
            if ((code == 429 && GeminiKeyPool.isQuota(o.body)) || o.badKey) {
                GeminiKeyPool.onLimit(curKey, curModel, o.body, o.badKey)
                triedKeys.add(curKey)
                val alt = GeminiKeyPool.alternative(triedKeys, curModel)
                if (alt != null) {
                    GeminiKeyPool.notifySwitch(curKey, alt, o.badKey)
                    curKey = alt
                    continue
                }
            }
            // 모델이 없어졌다(404): 구글의 모델 목록을 새로 받아 같은 계열의 새 모델로 바꿔 다시 보낸다 (요청당 한 번)
            if (code == 404 && !modelSynced) {
                modelSynced = true
                if (GeminiModelSync.refreshNow(curKey)) {
                    val sub = GeminiModels.successor(curModel)
                    if (sub != curModel && sub !in tried) {
                        tried.add(sub)
                        curModel = sub
                        triedKeys.clear()
                        continue
                    }
                }
            }
            val gone = code == 404 || (curModel == GeminiModels.HYDROGEN.id && modelUnavailable(code, o.body))
            if (gone) GeminiAuto.markDead(curModel)
            val transient = code == 429 || code in 500..599
            if ((gone || transient) && canSwitchModel) {
                val cands = GeminiAuto.fallbacks(curModel).filter { it !in tried }
                val next = cands.firstOrNull { GeminiKeyPool.usable(it) } ?: cands.firstOrNull()
                if (next != null) {
                    tried.add(next)
                    curModel = next
                    triedKeys.clear()
                    curKey = GeminiKeyPool.forModel(curKey, next)
                    continue
                }
            }
            if (transient && sameRetries < SAME_MODEL_RETRIES) {
                sameRetries++
                try {
                    Thread.sleep(1500L * sameRetries)
                } catch (e: InterruptedException) {
                    return o.step
                }
                if (cancelled) return o.step
                triedKeys.clear()
                continue
            }
            return o.step
        }
    }

    /** 이 키·지역에서 이 모델을 못 쓰는 경우 (권한 없음 · 모델 없음). 요청 모양이 틀려서 난 400 과 구별한다 */
    private fun modelUnavailable(code: Int, body: String): Boolean {
        if (code == 403) return true
        if (code != 400) return false
        val b = body.lowercase()
        return b.contains("model") && (b.contains("not found") || b.contains("not supported") || b.contains("not available") || b.contains("permission"))
    }

    private fun failure(code: Int, msg: String, badKey: Boolean = false, body: String = ""): Once =
        Once(Step(JSONArray(), emptyList(), "", "", msg), code, badKey, body)

    private fun once(
        apiKey: String,
        model: String,
        system: String,
        contents: JSONArray,
        decls: JSONArray,
        thoughts: Boolean,
        allowCalls: Boolean,
        onText: (String) -> Unit,
        onThought: (String) -> Unit
    ): Once {
        var c: HttpURLConnection? = null
        var got = false
        var finish = ""
        var blocked = ""
        val outParts = JSONArray()
        val calls = mutableListOf<Call>()
        val textBuf = StringBuilder()
        var textSig = ""

        // 이어 붙던 글을 한 덩어리(part)로 닫는다. 서명이 글에 붙어 오면 그 서명도 같이 남긴다
        fun flushText() {
            if (textBuf.isEmpty() && textSig.isEmpty()) return
            val p = JSONObject().put("text", textBuf.toString())
            if (textSig.isNotEmpty()) p.put("thoughtSignature", textSig)
            outParts.put(p)
            textBuf.setLength(0)
            textSig = ""
        }

        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            c = url.openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 300000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)

            val body = JSONObject().put("contents", contents)
            if (decls.length() > 0) {
                body.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
                body.put(
                    "toolConfig",
                    JSONObject().put("functionCallingConfig", JSONObject().put("mode", if (allowCalls) "AUTO" else "NONE"))
                )
            }
            val gen = JSONObject().put("maxOutputTokens", MAX_OUTPUT_TOKENS)
            val thinkApplied = GeminiThinking.apply(gen, model, GeminiThinking.LOW, thoughts)
            body.put("generationConfig", gen)
            GeminiSafety.apply(body)
            if (system.isNotBlank()) {
                body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            }
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = try {
                    c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
                // 이 모델이 생각 설정을 모르면 설정 없이 한 번 더 보낸다
                if (GeminiThinking.rejected(code, err, model, thinkApplied)) {
                    return once(apiKey, model, system, contents, decls, thoughts, allowCalls, onText, onThought)
                }
                val bad = code == 401 || code == 403 || (code == 400 && (err ?: "").contains("API key", ignoreCase = true))
                return failure(code, describeError(code, err), bad, err ?: "")
            }

            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.substring(5).trim()
                    if (data.isEmpty() || data == "[DONE]") continue
                    val o = JSONObject(data)
                    val br = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                    if (br.isNotEmpty()) blocked = br
                    val cand = o.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                    val fr = cand.optString("finishReason")
                    if (fr.isNotEmpty()) finish = fr
                    val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until parts.length()) {
                        val p = parts.optJSONObject(i) ?: continue
                        if (p.optBoolean("thought", false)) {
                            // 모델이 정리한 생각의 요약: 사고 과정 표시용으로만 넘기고, 다시 보내지는 않는다
                            val th = p.optString("text", "")
                            if (th.isNotEmpty()) {
                                got = true
                                onThought(th)
                            }
                            continue
                        }
                        val fc = p.optJSONObject("functionCall")
                        if (fc != null) {
                            flushText()
                            got = true
                            calls.add(Call(fc.optString("name"), fc.optJSONObject("args") ?: JSONObject(), fc.optString("id", "")))
                            // 생각 서명이 붙어 있을 수 있어서 받은 그대로 둔다
                            outParts.put(p)
                            continue
                        }
                        val t = p.optString("text", "")
                        if (t.isNotEmpty()) {
                            got = true
                            textBuf.append(t)
                            onText(t)
                        }
                        val sig = p.optString("thoughtSignature", "")
                        if (sig.isNotEmpty()) {
                            textSig = sig
                            flushText()
                        }
                    }
                }
            }
            flushText()
            // finishReason 없이 스트림이 끝났다면 중간에 끊긴 것으로 본다
            if (got && finish.isEmpty() && !cancelled) {
                return Once(Step(outParts, calls, "", blocked, "응답이 중간에 끊겼어요"), 0, false, "")
            }
            return Once(Step(outParts, calls, finish, blocked, null), 200, false, "")
        } catch (e: Exception) {
            return failure(0, "네트워크 오류: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
                // 무시
            }
            conn = null
        }
    }

    private fun describeError(code: Int, body: String?): String {
        val msg = try {
            JSONObject(body ?: "").optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        val head = when (code) {
            400 -> "요청이 올바르지 않거나 API 키가 잘못되었어요"
            401, 403 -> "API 키가 거부되었어요. 키와 사용 권한을 확인해 주세요"
            404 -> "모델을 찾을 수 없어요"
            429 -> if (GeminiKeyPool.isQuota(body)) "요청 한도를 넘었어요. 잠시 후 다시 시도해 주세요"
            else "Gemini 서버가 지금 붐벼서 요청을 처리하지 못했어요. 한도 문제는 아니에요. 잠시 후 다시 시도해 주세요 (429)"
            in 500..599 -> "Gemini 서버에 문제가 있어요. 잠시 후 다시 시도해 주세요"
            else -> "오류가 났어요 ($code)"
        }
        // 구글이 주는 설명은 영어라서 한글이 든 것만 덧붙이고, 나머지는 위의 한국어 안내만 보여 준다
        return if (msg.isNullOrBlank() || !msg.any { it in '가'..'힣' }) head else "$head\n$msg"
    }
}
