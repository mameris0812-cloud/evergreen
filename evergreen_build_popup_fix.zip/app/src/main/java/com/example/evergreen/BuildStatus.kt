package com.example.evergreen

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * GitHub Actions 빌드 진행 창("빌드 중… 43%").
 * 저절로 뜨지 않는다. 설정 > 앱 정보 > '빌드 진행 상황'을 눌렀을 때만 [show] 로 띄운다.
 *  - 지금 진행 중인 빌드가 있으면 진행 창을 띄우고, 없으면 안내만 보여 준다.
 *  - 빌드가 끝나면 창이 닫힌다. 성공하면 바로 업데이트를 확인하고, 실패·취소는 알림만 보여 준다.
 *
 * 로그인 없이 쓰는 GitHub API 는 시간당 60번 제한이 있어서 ETag(If-None-Match)를 쓴다.
 * 바뀐 게 없으면 304 로 답하고, 304 는 제한 횟수에 들어가지 않는다. 앱에는 토큰을 넣지 않는다 (공개 저장소 전용).
 */
object BuildStatus {
    private const val POLL_MS = 5_000L

    private class RateLimited : Exception()

    private class Snapshot(val status: String, val conclusion: String?, val done: Int, val total: Int)

    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followSslRedirects(false)
        .build()

    private val etags = HashMap<String, String>()
    private val bodies = HashMap<String, String>()

    @Volatile private var showing = false

    private fun get(url: String): String {
        val b = Request.Builder().url(url)
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "evergreen-updater")
        synchronized(etags) { etags[url] }?.let { b.header("If-None-Match", it) }
        client.newCall(b.build()).execute().use { resp ->
            if (resp.code == 304) {
                return synchronized(bodies) { bodies[url] } ?: throw IllegalStateException("캐시 없음")
            }
            if ((resp.code == 403 || resp.code == 429) && resp.header("x-ratelimit-remaining") == "0") throw RateLimited()
            if (!resp.isSuccessful) throw IllegalStateException("서버 응답 오류 (${resp.code})")
            val text = resp.body?.string() ?: throw IllegalStateException("빈 응답")
            resp.header("ETag")?.let { synchronized(etags) { etags[url] = it } }
            synchronized(bodies) { bodies[url] = text }
            return text
        }
    }

    /** headSha 가 있으면 그 커밋의 빌드를, 없으면 가장 최근 빌드를 가져온다. 없으면 null. */
    private fun fetch(headSha: String?): Snapshot? {
        val base = "https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/actions"
        val q = if (headSha != null) "?head_sha=$headSha&per_page=1" else "?per_page=1"
        val runs = JSONObject(get("$base/runs$q")).optJSONArray("workflow_runs")
        if (runs == null || runs.length() == 0) return null
        val run = runs.getJSONObject(0)
        val status = run.optString("status")
        var done = 0
        var total = 0
        if (status != "completed") {
            val jobs = JSONObject(get("$base/runs/${run.getLong("id")}/jobs")).optJSONArray("jobs")
            val steps = jobs?.takeIf { it.length() > 0 }?.getJSONObject(0)?.optJSONArray("steps")
            if (steps != null) {
                total = steps.length()
                for (i in 0 until total) if (steps.getJSONObject(i).optString("status") == "completed") done++
            }
        }
        return Snapshot(status, run.optString("conclusion").ifEmpty { null }, done, total)
    }

    /** 설정 > 앱 정보에서 눌렀을 때: 진행 중인 빌드가 있으면 진행 창을 띄운다 */
    fun show(act: Activity) {
        if (!Updater.enabled()) {
            AppToast.show(act, "GitHub Actions 로 빌드한 앱에서만 볼 수 있어요")
            return
        }
        track(act)
    }

    private fun track(act: Activity) {
        val headSha: String? = null
        if (showing) return
        showing = true
        val stopped = AtomicBoolean(false)
        val busy = AtomicBoolean(false)
        var dlg: AlertDialog? = null
        var label: TextView? = null
        var bar: ProgressBar? = null

        fun finish() {
            stopped.set(true)
            showing = false
            runCatching { dlg?.dismiss() }
        }

        fun ensureDialog() {
            if (dlg != null) return
            val dp = act.resources.displayMetrics.density
            fun px(v: Int) = (v * dp).toInt()
            // 오류 화면처럼 맨 위에 그림 카드, 그 아래 제목·진행 상태·진행 막대 (가운데 정렬)
            val art = BuildArtView(act)
            val title = TextView(act).apply {
                text = "빌드 중"
                textSize = 16f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_text))
            }
            val l = TextView(act).apply {
                text = "대기 중…"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_muted))
            }
            val b = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                isIndeterminate = true
            }
            val box = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(px(20), px(20), px(20), px(2))
                addView(art, LinearLayout.LayoutParams(px(112), LinearLayout.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER_HORIZONTAL })
                addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })
                addView(l, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(4) })
                addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })
            }
            label = l
            bar = b
            // 폭을 공통 창(360dp)보다 훨씬 좁게 (240dp). 그림도 작게 둔다
            dlg = MaterialAlertDialogBuilder(act, R.style.ThemeOverlay_Evergreen_Dialog_Narrow)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("숨기기") { _, _ -> finish() }
                .show()
        }

        fun render(s: Snapshot) {
            val b = bar ?: return
            if (s.status == "queued" || s.total == 0) {
                b.isIndeterminate = true
                label?.text = "대기 중…"
            } else {
                val pct = s.done * 100 / s.total
                b.isIndeterminate = false
                b.progress = pct
                label?.text = "빌드 중… $pct%"
            }
        }

        fun tick() {
            if (stopped.get() || !busy.compareAndSet(false, true)) return
            Thread {
                var snap: Snapshot? = null
                var rate = false
                var failed = false
                try {
                    snap = fetch(headSha)
                } catch (e: RateLimited) {
                    rate = true
                } catch (e: Exception) {
                    failed = true
                }
                val s = snap
                main.post {
                    busy.set(false)
                    if (stopped.get()) return@post
                    if (act.isFinishing || act.isDestroyed) { finish(); return@post }
                    when {
                        rate -> {
                            finish()
                            AppToast.show(act, "GitHub 요청 한도에 도달했어요. 잠시 뒤 다시 확인해 주세요")
                        }
                        failed -> {
                            // 일시적인 네트워크 오류: 창이 떠 있으면 계속 시도하고, 아니면 조용히 끝낸다
                            if (dlg != null) main.postDelayed({ tick() }, POLL_MS)
                            else { finish(); AppToast.show(act, "빌드 상태를 가져오지 못했어요") }
                        }
                        s == null -> {
                            finish()
                            AppToast.show(act, "진행 중인 빌드가 없어요")
                        }
                        s.status == "completed" -> {
                            val shown = dlg != null
                            finish()
                            // 창이 떠 있던 빌드가 끝났으면 결과를 알린다. 처음부터 끝나 있던 빌드면 없다고만 알린다.
                            if (shown) onDone(act, s) else AppToast.show(act, "진행 중인 빌드가 없어요")
                        }
                        else -> {
                            ensureDialog()
                            render(s)
                            main.postDelayed({ tick() }, POLL_MS)
                        }
                    }
                }
            }.start()
        }
        tick()
    }

    private fun onDone(act: Activity, s: Snapshot) {
        when (s.conclusion) {
            "success" -> Updater.manualCheck(act)   // 새 버전이 있으면 '새 버전이 있어요' 창이 뜬다
            "cancelled" -> AppToast.show(act, "빌드가 취소됐어요")
            else -> AppToast.show(act, "빌드에 실패했어요")
        }
    }
}
