package com.example.evergreen

/**
 * 웹 페이지가 상단바 뒤까지 그려질 때, 페이지 내용이 바에 가려지지 않도록 문서 맨 위에 바 높이만큼 여백(CSS)을 준다.
 * 여백은 화면 너비에 대한 비율로 넣는다(100vw × 비율). 그러면 사이트의 뷰포트 배율(데스크톱 사이트 등)이 달라도
 * 항상 바 높이와 같은 화면 길이가 된다.
 */
object TopInset {
    private const val APPLY = """
        function __apply(f){
          var s=document.getElementById('__ev_top_inset');
          if(!(f>0)){ if(s&&s.parentNode) s.parentNode.removeChild(s); return; }
          if(!s){ s=document.createElement('style'); s.id='__ev_top_inset'; (document.head||document.documentElement).appendChild(s); }
          var v='calc(100vw * '+f+')';
          s.textContent='html{padding-top:'+v+' !important;box-sizing:border-box !important;scroll-padding-top:'+v+' !important}';
        }
    """

    /** 문서 시작 스크립트: 자바 쪽(EvInset.frac)에서 지금 비율을 읽어 바로 적용하고, 나중에 바꿀 수 있게 함수를 남긴다 */
    val START_JS: String = "(function(){try{$APPLY window.__evTopInset=__apply; __apply(parseFloat(EvInset.frac()));}catch(e){}})();"

    /** 이미 열린 페이지에 비율 [frac] 을 적용한다 (0 이면 여백 제거) */
    fun js(frac: Float): String =
        "(function(){try{$APPLY __apply($frac);}catch(e){}})();"
}
