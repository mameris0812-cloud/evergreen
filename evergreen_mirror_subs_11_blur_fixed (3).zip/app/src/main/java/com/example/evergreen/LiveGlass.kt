package com.example.evergreen

import android.graphics.Canvas
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.view.View
import androidx.annotation.RequiresApi

/**
 * 상단바 뒤 유리(블러).
 * 웹 페이지가 상단바 뒤까지 실제로 그려지므로, 바가 그려질 때 그 자리의 페이지를 그대로 다시 그린 뒤
 * RenderEffect 블러를 걸어 바 배경으로 깐다. (화면 픽셀을 복사하지 않으므로 바 자신이 찍혀 번지는 일이 없다)
 * Android 12(API 31) 이상에서만 쓴다.
 */
@RequiresApi(Build.VERSION_CODES.S)
internal class LiveGlass(private val host: View, private val blurDp: Float) {

    private var node: RenderNode? = null
    private var effectRadius = -1f

    /**
     * [src] 뷰의 (sx, sy) 지점부터 w×h 영역을 흐리게 해서 canvas 의 (0,0)~(w,h) 자리에 그린다.
     * [flip] 이면 위아래를 뒤집어 (src 맨 위 줄이 영역의 아래 끝에 오도록) 그린다. 상태표시줄 자리처럼
     * 페이지 위쪽 가장자리를 거울처럼 이어 보일 때 쓴다.
     */
    fun draw(canvas: Canvas, w: Int, h: Int, src: View, sx: Int, sy: Int, flip: Boolean = false) {
        if (w <= 0 || h <= 0 || src.width <= 0 || src.height <= 0) return
        if (!canvas.isHardwareAccelerated) return
        val d = host.resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val radius = blurDp * d
        val rn = node ?: RenderNode("liveGlass").also { node = it }
        if (effectRadius != radius) {
            rn.setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP))
            effectRadius = radius
        }
        val tw = w + pad * 2
        val th = h + pad * 2
        rn.setPosition(0, 0, tw, th)
        val rc = rn.beginRecording(tw, th)
        try {
            if (flip) { rc.translate(0f, th.toFloat()); rc.scale(1f, -1f) }
            rc.translate((pad - sx).toFloat(), (pad - sy).toFloat())
            src.draw(rc)
        } finally {
            rn.endRecording()
        }
        canvas.save()
        canvas.clipRect(0, 0, w, h)
        canvas.translate(-pad.toFloat(), -pad.toFloat())
        canvas.drawRenderNode(rn)
        canvas.restore()
    }
}
