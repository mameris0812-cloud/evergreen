package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import android.widget.LinearLayout

/**
 * 상단바(탭 줄 · 주소창)와 하단 내비게이션 바용 유리 배경.
 * Android 12(API 31) 이상에서, 바와 맞닿은 웹 페이지 가장자리(위쪽 바는 페이지 맨 위, 아래쪽 바는 페이지 맨 아래)를
 * 흐리게 바 뒤에 깔고 바 배경은 반투명으로 만든다. 그 아래 버전에서는 원래 배경 그대로다.
 * 바는 페이지 위에 겹치지 않고 따로 놓여 있으므로(레이아웃은 그대로) 페이지의 맨 위/아래가 바에 가려지지 않는다.
 * 웹뷰를 직접 다시 그리지 않고 화면에 그려진 픽셀을 복사해 쓴다 (GlassBackdrop 참고).
 */
class BlurBarLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : LinearLayout(ctx, attrs) {

    /**
     * 페이지가 이 바 뒤까지 실제로 그려질 때의 페이지 뷰(상단바 전용). 있으면 그 자리를 흐리게 다시 그려 바 배경으로 깐다.
     * [liveOn] 이 false 면(페이지가 바 뒤로 오지 않는 상태) 평범한 불투명 바다.
     */
    var liveSource: View? = null
    var liveOn = false
        set(v) { if (field != v) { field = v; invalidate() } }

    /** 맞닿은 웹 페이지 영역 */
    var source: View? = null
        set(v) { field = v; invalidate() }

    /** true 면 아래쪽 바 (페이지 맨 아래를 비춘다), false 면 위쪽 바 (페이지 맨 위를 비춘다) */
    var bottomEdge = false

    /** 흐림 반경(dp) 과 바 배경 불투명도(0~255). 값이 클수록 은은하다. 뷰가 창에 붙기 전에 정한다 */
    var blurDp = 10f
    var tintAlpha = 0xC4

    /** 위쪽 바들이 한 장의 그림을 나눠 쓸 때: 공유 그림(GlassBackdrop), 이 바가 그림에서 시작하는 높이, 그림 전체 높이 */
    var shared: Any? = null
    var sliceOffset: () -> Int = { 0 }
    var sliceTotal: () -> Int = { height }

    private val blurOn = Blur.active()
    private var glass: Any? = null
    private var tinted = false
    private var liveTinted = false
    private var live: Any? = null
    private val a = IntArray(2)
    private val b = IntArray(2)
    private val pre = ViewTreeObserver.OnPreDrawListener {
        if (liveSource == null && source != null && shared == null) (glass as? GlassBackdrop)?.refresh()
        true
    }

    private fun region(): Rect? {
        val src = source ?: return null
        if (src.width <= 0 || src.height < height || height <= 0) return null
        getLocationInWindow(a)
        src.getLocationInWindow(b)
        val top = if (bottomEdge) b[1] + src.height - height else b[1]
        // 바가 스크롤로 움직이는 중이어도 페이지 쪽 위치 기준으로 가져온다
        return Rect(a[0], top, a[0] + width, top + height)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (blurOn) {
            if (liveSource == null && glass == null) glass = GlassBackdrop(this, blurDp) { region() }
            viewTreeObserver.addOnPreDrawListener(pre)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (blurOn) {
            if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(pre)
            (glass as? GlassBackdrop)?.release()
        }
    }

    override fun draw(canvas: Canvas) {
        val ls = liveSource
        if (blurOn && ls != null) {
            // 상단바: 페이지가 바 뒤까지 그려지는 동안만 반투명 + 뒤 페이지 블러
            if (liveOn != liveTinted) {
                background?.mutate()?.alpha = if (liveOn) tintAlpha else 255
                liveTinted = liveOn
            }
            if (liveOn && ls.isAttachedToWindow && width > 0 && height > 0) {
                try {
                    val lg = (live as? LiveGlass) ?: LiveGlass(this, blurDp).also { live = it }
                    getLocationInWindow(a)
                    ls.getLocationInWindow(b)
                    lg.draw(canvas, width, height, ls, a[0] - b[0], a[1] - b[1])
                } catch (e: Throwable) { /* 못 그리면 원래 배경 */ }
            }
            super.draw(canvas)
            return
        }
        val g = (shared ?: glass) as? GlassBackdrop
        if (blurOn && g != null && source != null && width > 0 && height > 0) {
            try {
                if (!tinted) {
                    // 뒤의 흐린 그림이 비치도록 바 배경을 반투명으로 (한 번만)
                    background?.mutate()?.alpha = tintAlpha
                    tinted = true
                }
                if (shared != null) g.drawSlice(canvas, width, height, sliceOffset(), sliceTotal())
                else g.drawSlice(canvas, width, height, 0, height)
            } catch (e: Throwable) { /* 못 그리면 원래 배경 */ }
        }
        super.draw(canvas)
    }
}
