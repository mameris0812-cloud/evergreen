package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.core.graphics.PathParser
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 아래로 당겨 새로고침.
 * - 페이지(자식 WebView)가 손가락을 따라 고무줄처럼 내려오고, 그 빈자리에 로딩 원이 나타난다.
 * - 당기는 동안 원의 호가 당긴 만큼 자라며 돌고, 기준선에 닿으면 햅틱과 함께 톡 튄다.
 * - 놓으면 튕기지 않고 자리를 잡고, 호가 같은 길이로 일정하게 계속 돈다.
 * - 로딩이 끝나면 호가 닫힌 원이 되며 멈춘 뒤 부드럽게 올라간다.
 */
class PullRefreshLayout @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    /** 자식(웹페이지)이 위로 더 스크롤될 수 있으면 true → 당기기 비활성 */
    var canChildScrollUp: () -> Boolean = { false }
    var onRefresh: (() -> Unit)? = null

    /** true 이면 이번 제스처로는 당겨서 새로고침을 하지 않는다 (예: 핀치로 확대된 상태) */
    var isPullBlocked: () -> Boolean = { false }

    /** 페이지 안쪽 요소가 이미 스크롤되어 있거나 스크롤 중이면 true (JS 가 알려 준다). 손가락이 닿을 때마다 false 로 초기화 */
    @Volatile var innerScrolled = false

    /** 자식(NestedWebView)의 세로 스크롤을 먼저 받아 쓰는 쪽. dy 를 받아 실제로 쓴 양을 돌려준다. */
    var onNestedStart: (() -> Unit)? = null
    var onNestedPreScrollDy: ((Int) -> Int)? = null
    var onNestedStop: (() -> Unit)? = null

    var isRefreshing = false
        private set

    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val maxPull = 200f * d
    private val trigger = 96f * d
    private val hold = 72f * d

    private var offset = 0f
    private var armed = false
    private var dragging = false
    private var pointerId = -1
    /** 손가락을 대는 순간 페이지가 이미 맨 위였는지. 아니면 이번 터치로는 새로고침하지 않는다 (맨 위로 올라가려고 끌어내린 동작과 구분) */
    private var downAtTop = false
    /** 이번 제스처(DOWN~UP) 중 손가락이 둘 이상이었던 적이 있는지. 한 번이라도 있었으면 UP/CANCEL 까지 새로고침 불가 */
    private var sawMultiTouch = false
    /** 마지막으로 멀티터치가 끝난 시각. 핀치 직후 곧바로 이어지는 끌어내림은 무시한다 */
    private var multiTouchEndedAt = 0L
    private val pinchCooldownMs = 450L
    /** 새로고침으로 인정하려면 처음 방향이 거의 수직이어야 하고, 이만큼은 연속으로 내려와야 한다 */
    private val minStartDy get() = slop * 2f
    private var downX = 0f
    private var downY = 0f
    private var startY = 0f
    private var refreshStartedAt = 0L
    /** 손을 뗄 때의 속도를 스프링에 이어 주려고 손가락 움직임을 재는 도구 */
    private var vt: VelocityTracker? = null

    private var spinT = 0f            // 도는 동안 0~1 (1.2초에 한 바퀴)
    private var spinner: ValueAnimator? = null
    private var spring: SpringAnimation? = null

    /** 완료 연출 0→1: 나뭇잎이 앞면으로 멈추고 작은 잎이 흩날린다. finishing 은 연출이 시작된 뒤 완전히 닫힐 때까지 true */
    private var done = 0f
    private var finishing = false
    /** 기준선을 넘거나 완료되는 순간 표시기가 톡 튀는 정도 0→1 (1 이면 끝난 상태) */
    private var pop = 1f
    private var doneAnim: ValueAnimator? = null
    /** 완료 연출 동안 잎이 멈추지 않고 앞면이 될 때까지 마저 도는 각도: 시작 각도, 더 돌 각도, 연출 길이 */
    private var finishAng0 = 0f
    private var finishRemain = 0f
    private var finishMs = 300L
    private val popRunnable = Runnable { if (finishing) playPop() }
    private var popAnim: ValueAnimator? = null
    private val closeRunnable = Runnable {
        if (!finishing) return@Runnable
        isRefreshing = false
        animateTo(0f, 260f, 0.92f)
    }

    private val gapPaint = Paint().apply { color = ContextCompat.getColor(ctx, R.color.ev_bg) }
    /** 당기기 시작할 때 떠 둔 페이지 맨 윗줄의 색(가로 edgeCols 칸). 빈자리를 이 색으로 칠해 웹페이지 배경이 위로 이어지게 한다 */
    private val edgeCols = 24
    private var edgeBmp: Bitmap? = null
    private var edgeOk = false
    private var edgeSampled = false
    private val edgePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val edgeSrc = Rect()
    private val edgeDst = RectF()
    private val accent = ContextCompat.getColor(ctx, R.color.ev_accent)
    /** 로딩 원: 반지름과 선 굵기 */
    private val ringR = 13f * d
    private val ringRect = RectF()
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        strokeCap = Paint.Cap.ROUND
        color = accent
    }
    /** 호가 아직 지나가지 않은 부분의 옅은 바탕 원 */
    private val ringTrack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        color = accent
    }

    private val offsetProp = object : FloatPropertyCompat<PullRefreshLayout>("pullOffset") {
        override fun getValue(o: PullRefreshLayout) = o.offset
        override fun setValue(o: PullRefreshLayout, v: Float) = o.applyOffset(v)
    }

    init {
        setWillNotDraw(false)
    }

    // ───────────────────────── 상태 ─────────────────────────

    /** 새로고침이 끝났을 때 부르면 표시기가 너무 빨리 사라지지 않게 잠깐 두었다가 올라간다. */
    fun endRefresh() {
        if (!isRefreshing || finishing) return
        val wait = 550L - (System.currentTimeMillis() - refreshStartedAt)
        if (wait > 0) { postDelayed({ endRefresh() }, wait); return }
        // 앞면으로 멈추고 작은 잎이 흩날리는 동안 잠깐 보여 준 뒤 올라간다
        finishing = true
        // 도는 잎을 갑자기 세우지 않고, 지금 각도에서 앞면이 될 때까지 감속하며 마저 돈다 (뒷면이었으면 그만큼 더 돈다)
        spinner?.cancel()
        spinner = null
        val remainFrac = if (spinT < 0.02f) 0f else 1f - spinT
        finishAng0 = 2f * PI.toFloat() * spinT
        finishRemain = 2f * PI.toFloat() * remainFrac
        finishMs = (300L + 280L * remainFrac).toLong()
        doneAnim?.cancel()
        doneAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = finishMs
            interpolator = LinearInterpolator()
            addUpdateListener { done = it.animatedValue as Float; invalidate() }
            start()
        }
        // 앞면으로 내려앉는 순간에 톡 튀고, 그 직후 작은 잎이 흩날린다
        postDelayed(popRunnable, (finishMs * 0.55f).toLong())
        postDelayed(closeRunnable, maxOf(240L, finishMs - 40L))
    }

    /** 탭을 바꾸는 등 즉시 원래 상태로 되돌릴 때 */
    fun reset() {
        edgeOk = false
        spring?.cancel()
        popAnim?.cancel()
        pop = 1f
        stopSpinner()
        isRefreshing = false
        dragging = false
        armed = false
        applyOffset(0f)
    }

    // ───────────────────────── 중첩 스크롤 (메뉴바 숨김용) ─────────────────────────

    override fun onStartNestedScroll(child: View, target: View, nestedScrollAxes: Int): Boolean {
        val accept = onNestedPreScrollDy != null && (nestedScrollAxes and View.SCROLL_AXIS_VERTICAL) != 0
        if (accept) onNestedStart?.invoke()
        return accept
    }

    override fun onNestedPreScroll(target: View, dx: Int, dy: Int, consumed: IntArray) {
        consumed[1] = onNestedPreScrollDy?.invoke(dy) ?: 0
    }

    override fun onStopNestedScroll(child: View) {
        super.onStopNestedScroll(child)
        onNestedStop?.invoke()
    }

    override fun onViewRemoved(child: View) {
        super.onViewRemoved(child)
        child.translationY = 0f
    }

    override fun onViewAdded(child: View) {
        super.onViewAdded(child)
        child.translationY = offset
    }

    override fun onDetachedFromWindow() {
        spring?.cancel()
        popAnim?.cancel()
        stopSpinner()
        vt?.recycle()
        vt = null
        super.onDetachedFromWindow()
    }

    // ───────────────────────── 터치 ─────────────────────────

    /** 진행 중이던 끌어내림을 즉시 취소하고 원위치로 되돌린다 (새로고침은 하지 않는다) */
    private fun cancelPull() {
        if (dragging || offset > 0f) {
            dragging = false
            armed = false
            if (!isRefreshing) animateTo(0f, 300f, 0.9f)
        }
        dragging = false
    }

    /** 자식(웹페이지) 맨 위 12dp 줄의 색을 가로로 edgeCols 칸 떠 둔다. 실패하면 기본 배경색을 쓴다. */
    private fun sampleEdge() {
        edgeOk = false
        var child: View? = null
        for (i in childCount - 1 downTo 0) {
            val c = getChildAt(i)
            if (c.visibility == View.VISIBLE && c.width > 0 && c.height > 0) { child = c; break }
        }
        val v = child ?: return
        try {
            val bmp = edgeBmp ?: Bitmap.createBitmap(edgeCols, 2, Bitmap.Config.ARGB_8888).also { edgeBmp = it }
            bmp.eraseColor(Color.TRANSPARENT)
            val cv = Canvas(bmp)
            cv.scale(edgeCols.toFloat() / v.width, 2f / (12f * d))
            v.draw(cv)
            edgeOk = true
        } catch (_: Throwable) {
            edgeOk = false
        }
    }

    private fun velocityTracker(): VelocityTracker = vt ?: VelocityTracker.obtain().also { vt = it }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) velocityTracker().clear()
        vt?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerId = ev.getPointerId(0)
                downX = ev.x
                downY = ev.y
                dragging = false
                sawMultiTouch = false
                innerScrolled = false
                edgeSampled = false
                downAtTop = !canChildScrollUp() && !isPullBlocked() &&
                    System.currentTimeMillis() - multiTouchEndedAt > pinchCooldownMs
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // 두 번째 손가락: 핀치 줌 등. 이번 제스처는 끝날 때까지 새로고침으로 쓰지 않는다.
                sawMultiTouch = true
                downAtTop = false
                if (dragging) cancelPull()
                return false
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // 손가락 하나가 떨어져도 남은 손가락의 좌표 기준은 이미 낡았으므로 이번 제스처는 계속 무효
                sawMultiTouch = true
                downAtTop = false
                multiTouchEndedAt = System.currentTimeMillis()
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                val i = ev.findPointerIndex(pointerId)
                if (i < 0 || !isEnabled || isRefreshing) return false
                // 손가락이 둘 이상이거나, 이번 제스처에서 한 번이라도 둘 이상이었으면 새로고침 끌어내리기가 아니다
                if (ev.pointerCount > 1 || sawMultiTouch) {
                    sawMultiTouch = true
                    downAtTop = false
                    if (dragging) cancelPull()
                    return false
                }
                // 맨 위가 아닌 상태에서 시작한 끌어내리기는 '위로 스크롤'이다: 도중에 맨 위에 닿아도 새로고침으로 바꾸지 않는다.
                // 새로고침은 맨 위에 멈춘 페이지를 새로 당겨야만 된다.
                if (!downAtTop) return false
                // 페이지 안쪽 스크롤 영역을 만지고 있다면 페이지 스크롤이다 (WebView scrollY 는 0 이라도)
                if (innerScrolled) {
                    downAtTop = false
                    if (dragging) cancelPull()
                    return false
                }
                // 도중에 확대되었으면(핀치 직후 등) 취소
                if (isPullBlocked()) {
                    downAtTop = false
                    if (dragging) cancelPull()
                    return false
                }
                val x = ev.getX(i)
                val y = ev.getY(i)
                if (canChildScrollUp()) {
                    // 아직 맨 위가 아니면 기준점을 계속 갱신 (맨 위에 닿은 순간부터 거리를 잰다)
                    downX = x
                    downY = y
                    return false
                }
                val dy = y - downY
                val dx = abs(x - downX)
                // 아래로 끌기 시작한 걸로 보이면 미리 페이지 윗줄 색을 떠 둔다 (당기기가 시작될 때 끊기지 않게)
                if (!edgeSampled && dy > slop * 0.5f && dy > dx * 2f) {
                    edgeSampled = true
                    sampleEdge()
                }
                // 페이지의 판정(안쪽 스크롤 여부)이 도착할 시간을 준 뒤에만 시작한다
                val held = ev.eventTime - ev.downTime
                if (!dragging && held >= 70L && dy > minStartDy && dy > dx * 2f) {
                    dragging = true
                    // 판정을 기다리는 사이 이미 멀리 내려왔어도 페이지가 한 번에 튀지 않게, 시작점을 손가락 가까이로 당겨 둔다
                    startY = max(downY + minStartDy, y - slop)
                    spring?.cancel()
                    clearFinish()   // 체크가 보이는 채로 올라가던 중이면 다시 당기는 모양으로
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (sawMultiTouch) multiTouchEndedAt = System.currentTimeMillis()
                sawMultiTouch = false
                dragging = false
                pointerId = -1
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!dragging) return false
        vt?.addMovement(ev)
        // 끌어내리는 도중 두 번째 손가락이 닿거나 떨어지면 새로고침 취소
        if (ev.actionMasked == MotionEvent.ACTION_POINTER_DOWN ||
            ev.actionMasked == MotionEvent.ACTION_POINTER_UP || ev.pointerCount > 1) {
            sawMultiTouch = true
            cancelPull()
            return true
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val i = ev.findPointerIndex(pointerId)
                if (i < 0) { cancelPull(); return true }
                val raw = max(0f, ev.getY(i) - startY)
                applyOffset(rubber(raw))
                if (!armed && offset >= trigger) {
                    armed = true
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    playPop()
                } else if (armed && offset < trigger - 8f * d) {
                    armed = false
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                // 손을 떼는 순간의 속도를 화면에서 움직이는 속도로 바꿔 스프링에 이어 준다 (멈췄다가 튕기는 어색함을 없앤다)
                var v = 0f
                if (ev.actionMasked == MotionEvent.ACTION_UP) {
                    vt?.let { t ->
                        t.computeCurrentVelocity(1000)
                        v = t.getYVelocity(pointerId) * (1f - offset / maxPull).coerceIn(0f, 1f) / 1.1f
                    }
                    v = v.coerceIn(-3000f * d, 3000f * d)
                }
                dragging = false
                pointerId = -1
                val fire = ev.actionMasked == MotionEvent.ACTION_UP && offset >= trigger &&
                    !sawMultiTouch && !isPullBlocked() && !innerScrolled
                if (sawMultiTouch) multiTouchEndedAt = System.currentTimeMillis()
                sawMultiTouch = false
                armed = false
                if (fire) {
                    isRefreshing = true
                    refreshStartedAt = System.currentTimeMillis()
                    startSpinner()
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    animateTo(hold, 380f, 0.9f, v)
                    onRefresh?.invoke()
                } else {
                    animateTo(0f, 300f, 0.9f, v)
                }
            }
        }
        return true
    }

    // ───────────────────────── 애니메이션 ─────────────────────────

    /** 당긴 거리 → 화면에서 내려오는 거리 (멀어질수록 저항이 커지는 고무줄) */
    private fun rubber(raw: Float): Float = maxPull * (1f - exp(-raw / (maxPull * 1.1f)))

    private fun applyOffset(v: Float) {
        offset = v
        for (i in 0 until childCount) getChildAt(i).translationY = v
        invalidate()
    }

    private fun animateTo(target: Float, stiffness: Float, damping: Float, velocity: Float = 0f) {
        spring?.cancel()
        if (abs(offset - target) < 0.5f) {
            applyOffset(target)
            if (target == 0f && !isRefreshing) stopSpinner()
            return
        }
        spring = SpringAnimation(this, offsetProp).apply {
            setSpring(
                SpringForce(target)
                    .setStiffness(stiffness)
                    .setDampingRatio(damping)
            )
            setStartVelocity(velocity)
            setMinimumVisibleChange(0.5f)
            addEndListener { _, canceled, _, _ ->
                if (!canceled && target == 0f) {
                    applyOffset(0f)
                    if (!isRefreshing) stopSpinner()
                }
            }
            start()
        }
    }

    private fun startSpinner() {
        spinner?.cancel()
        // 1.2초에 한 바퀴 돌고, 한 바퀴 동안 두 번 떠올랐다 내려온다
        spinner = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { spinT = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopSpinner() {
        spinner?.cancel()
        spinner = null
        spinT = 0f
        clearFinish()
    }

    /** 완료 연출을 지우고 당기는 모양으로 되돌린다 */
    private fun clearFinish() {
        removeCallbacks(closeRunnable)
        removeCallbacks(popRunnable)
        doneAnim?.cancel()
        finishing = false
        done = 0f
    }

    /** 표시기가 톡 튀었다 돌아오는 효과 */
    private fun playPop() {
        popAnim?.cancel()
        popAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 340
            addUpdateListener { pop = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    // ───────────────────────── 그리기 ─────────────────────────

    private fun easeOut(x: Float): Float { val k = 1f - x; return 1f - k * k * k }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (offset <= 0.5f) return

        // 페이지가 내려오면서 생긴 빈자리
        canvas.drawRect(0f, 0f, width.toFloat(), offset, gapPaint)
        // 떠 둔 페이지 윗줄 색을 위로 길게 펼쳐서, 끌려 내려온 페이지와 배경이 이어져 보이게 한다 (투명한 곳은 기본 배경색)
        val eb = edgeBmp
        if (edgeOk && eb != null) {
            edgeSrc.set(0, 0, eb.width, 1)
            edgeDst.set(0f, 0f, width.toFloat(), offset)
            canvas.drawBitmap(eb, edgeSrc, edgeDst, edgePaint)
        }

        // 표시기: 빈자리 한가운데에 돌아가는 로딩 원. 내려온 만큼 커지면서 나타난다
        val appear = (offset / hold).coerceIn(0f, 1f)
        val eased = appear * appear * (3f - 2f * appear)
        if (eased <= 0.01f) return
        val cx = width / 2f
        val cy = offset / 2f
        val progress = (offset / trigger).coerceIn(0f, 1f)
        val r = ringR * (0.6f + 0.4f * eased)

        // rot: 호가 시작하는 각도(도), sweep: 호의 길이(도)
        // 당길 땐 당긴 만큼 자라고 돌며(끝에서 rot=180, sweep=270), 놓은 뒤엔 같은 길이로 일정하게 돈다
        val rot: Float
        val sweep: Float
        if (finishing) {
            // 도는 걸 갑자기 세우지 않고 감속하며 마저 돌고, 호가 닫힌 원이 된다
            val ang = finishAng0 + finishRemain * easeOut(done)
            rot = 180f + ang * 180f / PI.toFloat()
            sweep = 270f + 90f * easeOut(done)
        } else if (isRefreshing) {
            rot = 180f + 360f * spinT
            sweep = 270f
        } else {
            rot = -90f + 270f * progress
            sweep = max(8f, 270f * progress)
        }

        ringTrack.alpha = (45 * eased).toInt()
        canvas.drawCircle(cx, cy, r, ringTrack)
        ringPaint.alpha = (255 * eased).toInt()
        ringRect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(ringRect, rot, sweep, false, ringPaint)
    }

}
