package com.example.evergreen

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

/**
 * 홈 화면 검색 위젯. 위쪽 검색창은 새 탭에서 주소창을 열고, 아래 버튼 셋은
 * 새 탭 · 새 시크릿 탭 · 북마크 보기를 연다. 동작은 런처 바로가기(res/xml/shortcuts.xml)와 같은
 * 인텐트를 보내서 MainActivity.handleAppShortcut 이 그대로 처리한다.
 * 위젯은 높이가 낮게(1줄) 줄여지면 검색창만 보이게 한다.
 */
class SearchWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, build(context, manager.getAppWidgetOptions(it))) }
    }

    /** 크기를 바꾸면 버튼 줄을 보이거나 감춘다 */
    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, id: Int, newOptions: android.os.Bundle
    ) {
        manager.updateAppWidget(id, build(context, newOptions))
    }

    private fun build(context: Context, options: android.os.Bundle?): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_search)
        views.setOnClickPendingIntent(R.id.widget_search, pending(context, 1, ACTION_WEB_SEARCH))
        views.setOnClickPendingIntent(R.id.widget_new_tab, pending(context, 2, ACTION_NEW_TAB))
        views.setOnClickPendingIntent(R.id.widget_incognito, pending(context, 3, ACTION_NEW_INCOGNITO))
        views.setOnClickPendingIntent(R.id.widget_bookmarks, pending(context, 4, ACTION_BOOKMARKS))
        val minH = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0) ?: 0
        // 낮게 줄이면(검색창 한 줄 높이) 버튼 줄은 감추고 검색창만 남긴다
        views.setViewVisibility(R.id.widget_actions, if (minH in 1..127) View.GONE else View.VISIBLE)
        return views
    }

    private fun pending(context: Context, code: Int, action: String): PendingIntent {
        val intent = Intent(action).apply {
            setClassName(context.packageName, "com.example.evergreen.MainActivity")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        // 런처가 위젯 모양을 창 크기까지 부풀리는 전환 대신 부드러운 페이드로 열리도록 기본 전환을 지정한다
        val opts = android.app.ActivityOptions
            .makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
        return PendingIntent.getActivity(
            context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE, opts
        )
    }

    companion object {
        // MainActivity 의 ACTION_SHORTCUT_* 와 같은 값 (shortcuts.xml 과도 같다)
        private const val ACTION_NEW_TAB = "com.example.evergreen.action.NEW_TAB"
        private const val ACTION_NEW_INCOGNITO = "com.example.evergreen.action.NEW_INCOGNITO"
        private const val ACTION_WEB_SEARCH = "com.example.evergreen.action.WEB_SEARCH"
        private const val ACTION_BOOKMARKS = "com.example.evergreen.action.BOOKMARKS"
    }
}
