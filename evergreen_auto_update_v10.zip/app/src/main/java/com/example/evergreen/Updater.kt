package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * 앱 안에서 하는 업데이트.
 * GitHub 의 '최신 릴리스'(워크플로가 빌드마다 올린다)를 확인해서 지금 설치된 것보다 새 버전이면 APK 를 받아 설치 화면을 띄운다.
 * 저장소 이름은 빌드할 때 GitHub Actions 가 넣어 준다(BuildConfig.UPDATE_REPO). 직접 빌드해서 비어 있으면 동작하지 않는다.
 * 설치는 같은 키로 서명한 APK 만 덮어쓰기가 되고, 설치 확인 버튼은 매번 눌러야 한다(안드로이드 정책).
 */
object Updater {
    class Release(val versionName: String, val versionCode: Long, val apkUrl: String)

    sealed class Result {
        object UpToDate : Result()
        class Available(val release: Release) : Result()
        class Failed(val msg: String) : Result()
    }

    private const val PREFS = "evergreen_updater"
    private const val KEY_LAST_CHECK = "last_check"
    private const val AUTO_INTERVAL_MS = 6L * 60 * 60 * 1000

    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    @Volatile private var autoChecked = false

    fun enabled(): Boolean = BuildConfig.UPDATE_REPO.contains('/')

    private fun currentCode(ctx: Context): Long =
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))

    private fun updateDir(ctx: Context) = File(ctx.cacheDir, "updates")

    // ───────── 확인 ─────────

    private fun check(ctx: Context, cb: (Result) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val res = try {
                fetch(app)
            } catch (e: Exception) {
                Result.Failed(e.message ?: "네트워크 오류")
            }
            main.post { cb(res) }
        }.start()
    }

    private fun fetch(ctx: Context): Result {
        if (!enabled()) return Result.Failed("업데이트 저장소가 설정되지 않았어요 (GitHub Actions 로 빌드한 앱에서만 동작해요)")
        val req = Request.Builder()
            .url("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/latest")
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "evergreen-updater")
            .build()
        return client.newCall(req).execute().use { resp ->
            if (resp.code == 404) return@use Result.Failed("공개된 릴리스를 찾지 못했어요 (저장소가 비공개이거나 릴리스가 아직 없어요)")
            if (!resp.isSuccessful) return@use Result.Failed("서버 응답 오류 (${resp.code})")
            val j = JSONObject(resp.body?.string() ?: return@use Result.Failed("빈 응답"))
            val body = j.optString("body")
            val code = Regex("versionCode:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toLongOrNull()
                ?: return@use Result.Failed("릴리스에 버전 정보가 없어요")
            if (code <= currentCode(ctx)) return@use Result.UpToDate
            val assets = j.optJSONArray("assets") ?: return@use Result.Failed("릴리스에 APK 가 없어요")
            var url: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); break }
            }
            if (url.isNullOrEmpty()) return@use Result.Failed("릴리스에 APK 가 없어요")
            val name = Regex("versionName:\\s*(\\S+)").find(body)?.groupValues?.get(1)
                ?: j.optString("tag_name").removePrefix("v").ifEmpty { code.toString() }
            Result.Available(Release(name, code, url))
        }
    }

    /** 설정의 '업데이트 확인' 을 눌렀을 때: 결과를 항상 알려 준다 */
    fun manualCheck(act: Activity) {
        AppToast.show(act, "업데이트 확인 중…")
        check(act) { res ->
            if (act.isFinishing || act.isDestroyed) return@check
            when (res) {
                is Result.UpToDate -> AppToast.show(act, "최신 버전이에요 (${BuildConfig.VERSION_NAME})")
                is Result.Failed -> AppToast.show(act, res.msg)
                is Result.Available -> showAvailable(act, res.release)
            }
        }
    }

    /** 앱을 켰을 때 알아서: 새 버전이 있을 때만 알리고, 실패는 조용히 넘긴다 (프로세스당 한 번, 6시간 간격) */
    fun autoCheck(act: Activity) {
        if (!enabled() || autoChecked) return
        autoChecked = true
        val sp = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - sp.getLong(KEY_LAST_CHECK, 0L) < AUTO_INTERVAL_MS) return
        sp.edit().putLong(KEY_LAST_CHECK, now).apply()
        check(act) { res ->
            if (res is Result.Available && !act.isFinishing && !act.isDestroyed) showAvailable(act, res.release)
        }
    }

    // ───────── 안내 · 받기 · 설치 ─────────

    private fun showAvailable(act: Activity, r: Release) {
        MaterialAlertDialogBuilder(act)
            .setTitle("새 버전이 있어요")
            .setMessage("${BuildConfig.VERSION_NAME} → ${r.versionName}\n지금 받아서 업데이트할까요?")
            .setPositiveButton("업데이트") { _, _ -> startDownload(act, r) }
            .setNegativeButton("나중에", null)
            .show()
    }

    private fun startDownload(act: Activity, r: Release) {
        val dp = act.resources.displayMetrics.density
        val label = TextView(act).apply { text = "받는 중…" }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = true
        }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((24 * dp).toInt(), (12 * dp).toInt(), (24 * dp).toInt(), 0)
            addView(label)
            addView(bar)
        }
        val canceled = java.util.concurrent.atomic.AtomicBoolean(false)
        val dlg = MaterialAlertDialogBuilder(act)
            .setTitle("업데이트 받는 중")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("취소") { _, _ -> canceled.set(true) }
            .show()

        val app = act.applicationContext
        Thread {
            var err: String? = null
            var file: File? = null
            try {
                val dir = updateDir(app).apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val tmp = File(dir, "evergreen-update.apk.part")
                val req = Request.Builder().url(r.apkUrl).header("User-Agent", "evergreen-updater").build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("서버 응답 오류 (${resp.code})")
                    val body = resp.body ?: throw IllegalStateException("빈 응답")
                    val total = body.contentLength()
                    var done = 0L
                    var lastPct = -1
                    body.byteStream().use { input ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                if (canceled.get()) throw InterruptedException()
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val pct = (done * 100 / total).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        main.post {
                                            bar.isIndeterminate = false
                                            bar.progress = pct
                                            label.text = "받는 중… $pct%"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (tmp.length() <= 0L) throw IllegalStateException("받은 파일이 비어 있어요")
                val apk = File(dir, "evergreen-update.apk")
                if (!tmp.renameTo(apk)) throw IllegalStateException("파일을 저장하지 못했어요")
                file = apk
            } catch (e: InterruptedException) {
                // 사용자가 취소함
            } catch (e: Exception) {
                err = e.message ?: "받지 못했어요"
            }
            val doneFile = file
            val doneErr = err
            main.post {
                runCatching { dlg.dismiss() }
                when {
                    canceled.get() -> {}
                    doneErr != null -> AppToast.show(act, "업데이트를 받지 못했어요: $doneErr")
                    doneFile != null && !act.isFinishing && !act.isDestroyed -> install(act, doneFile)
                }
            }
        }.start()
    }

    private fun install(act: Activity, apk: File) {
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            // 이 앱이 APK 를 설치하도록 한 번 허용해야 한다. 허용하고 돌아와서 다시 '업데이트' 를 누른다.
            AppToast.show(act, "'이 출처 허용'을 켠 뒤 다시 업데이트해 주세요")
            act.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}"))
            )
            return
        }
        val uri = FileProvider.getUriForFile(act, "${act.packageName}.updates", apk)
        act.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
