function __evxMake(ID, M, MSG, B, T) {
  var BASE = "https://ext.evergreen.invalid/" + ID + "/";
  function ev() {
    var L = [];
    return {
      addListener: function (f) { if (typeof f === "function") L.push(f); },
      removeListener: function (f) { var i = L.indexOf(f); if (i >= 0) L.splice(i, 1); },
      hasListener: function (f) { return L.indexOf(f) >= 0; },
      hasListeners: function () { return L.length > 0; },
      _a: function () { return L.slice(); },
      _d: function (a) { L.slice().forEach(function (f) { try { f.apply(null, a); } catch (e) { console.error(e); } }); }
    };
  }
  // 값을 돌려주는 함수를 콜백/프로미스 양쪽 방식으로 부를 수 있게 감싼다
  function cb(args, fn) {
    var last = args[args.length - 1];
    if (typeof last === "function") {
      var v, err = null;
      try { v = fn(); } catch (e) { err = e; }
      setTimeout(function () { if (err) console.error(err); else last(v); }, 0);
      return undefined;
    }
    try { return Promise.resolve(fn()); } catch (e) { return Promise.reject(e); }
  }
  // 지원하지 않는 API: 호출해도 오류 없이 조용히 넘어간다
  function stub() {
    var f = function () {
      var c = arguments[arguments.length - 1];
      if (typeof c === "function") { setTimeout(function () { try { c(); } catch (e) {} }, 0); return undefined; }
      return Promise.resolve();
    };
    return new Proxy(f, {
      get: function (t, k) {
        if (k === "then" || typeof k === "symbol") return undefined;
        if (k === "addListener" || k === "removeListener") return function () {};
        if (k === "hasListener" || k === "hasListeners") return function () { return false; };
        return stub();
      }
    });
  }
  function ns(o) {
    return new Proxy(o, {
      get: function (t, k) {
        if (k in t) return t[k];
        if (typeof k === "symbol" || k === "then") return undefined;
        return stub();
      }
    });
  }

  var onChanged = ev();
  function fire(ch, area) { onChanged._d([ch, area]); }
  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }

  // ── 네이티브와 주고받는 비동기 호출 (메시지 · fetch · 탭 메시지) ──
  var ROOT = "https://ext.evergreen.invalid/";
  var G = window.__evxPending;
  if (!G) { G = {}; try { Object.defineProperty(window, "__evxPending", { value: G }); } catch (e) { window.__evxPending = G; } }
  if (!window.__evxResp) {
    try { Object.defineProperty(window, "__evxResp", { value: function (id, j) { var f = G[id]; if (f) { delete G[id]; f(j); } } }); } catch (e) { }
  }
  function rid() { return Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function ask(start, ms) {
    return new Promise(function (res) {
      var cid = rid();
      var t = setTimeout(function () { delete G[cid]; res(""); }, ms || 30000);
      G[cid] = function (j) { clearTimeout(t); res(j); };
      try { start(cid); } catch (e) { delete G[cid]; clearTimeout(t); res(""); }
    });
  }
  function parseJ(j) { if (j === "" || j == null) return undefined; try { return JSON.parse(j); } catch (e) { return undefined; } }
  function str(m) { var j = JSON.stringify(m === undefined ? null : m); return j === undefined ? "null" : j; }
  function withCb(done, p) {
    if (typeof done === "function") { p.then(function (v) { try { done(v); } catch (e) { console.error(e); } }); return undefined; }
    return p;
  }
  function openTab(u) {
    try { u = new URL(String(u || ""), BASE).href; B.opentab(ID, u, T); } catch (e) { }
  }
  // 크롬처럼: 리스너가 true 를 돌려주면 나중에 sendResponse, 아니면 바로 닫는다 (Promise 반환은 무시)
  function dispatch(evObj, msg, sender, reply) {
    var ls = evObj ? evObj._a() : [], done = false, async = false;
    function respond(v) { if (done) return; done = true; reply(v); }
    for (var i = 0; i < ls.length && !done; i++) {
      var r;
      try { r = ls[i](clone(msg), sender, respond); } catch (e) { console.error(e); continue; }
      if (r === true) async = true;
    }
    if (!async && !done) respond(undefined);
  }
  // 알람 (백그라운드 페이지가 살아 있는 동안만 울린다)
  var onAlarm = ev(), AL = {}, ALT = {};
  function clearA(n) { if (ALT[n] != null) { clearTimeout(ALT[n]); delete ALT[n]; } var had = n in AL; delete AL[n]; return had; }
  var alarms = ns({
    create: function (name, info) {
      if (name && typeof name === "object") { info = name; name = ""; }
      info = info || {}; name = name || "";
      clearA(name);
      var d = info.when != null ? Math.max(0, info.when - Date.now()) : (info.delayInMinutes != null ? info.delayInMinutes * 60000 : (info.periodInMinutes || 0) * 60000);
      var per = info.periodInMinutes ? Math.max(info.periodInMinutes, 0.5) * 60000 : 0;
      var al = { name: name, scheduledTime: Date.now() + d };
      if (info.periodInMinutes) al.periodInMinutes = info.periodInMinutes;
      AL[name] = al;
      var fire = function () {
        if (!AL[name] || AL[name] !== al) return;
        var copy = JSON.parse(JSON.stringify(al));
        if (per) { al.scheduledTime = Date.now() + per; ALT[name] = setTimeout(fire, per); } else { delete AL[name]; delete ALT[name]; }
        onAlarm._d([copy]);
      };
      ALT[name] = setTimeout(fire, d);
      return cb(arguments, function () {});
    },
    get: function (name) { var a = arguments; return cb(a, function () { return clone(AL[typeof name === "string" ? name : ""]); }); },
    getAll: function () { return cb(arguments, function () { return Object.keys(AL).map(function (k) { return clone(AL[k]); }); }); },
    clear: function (name) { var a = arguments; return cb(a, function () { return clearA(typeof name === "string" ? name : ""); }); },
    clearAll: function () { return cb(arguments, function () { var any = Object.keys(AL).length > 0; Object.keys(AL).forEach(clearA); return any; }); },
    onAlarm: onAlarm
  });
  function area(name) {
    function load() { try { return JSON.parse(B.sget(ID, name, T) || "{}"); } catch (e) { return {}; } }
    function save(o) { B.sset(ID, name, JSON.stringify(o), T); }
    return {
      get: function (keys) {
        return cb(arguments, function () {
          var o = load();
          if (keys == null || typeof keys === "function") return o;
          var r = {};
          if (typeof keys === "string") keys = [keys];
          if (Array.isArray(keys)) keys.forEach(function (k) { if (k in o) r[k] = o[k]; });
          else if (typeof keys === "object") Object.keys(keys).forEach(function (k) { r[k] = (k in o) ? o[k] : keys[k]; });
          return r;
        });
      },
      set: function (items) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(items || {}).forEach(function (k) {
            var nv = clone(items[k]);
            ch[k] = { oldValue: o[k], newValue: nv };
            o[k] = nv;
          });
          save(o);
          fire(ch, name);
        });
      },
      remove: function (keys) {
        return cb(arguments, function () {
          var o = load(), ch = {};
          (Array.isArray(keys) ? keys : [keys]).forEach(function (k) {
            if (typeof k === "string" && k in o) { ch[k] = { oldValue: o[k] }; delete o[k]; }
          });
          save(o);
          fire(ch, name);
        });
      },
      clear: function () {
        return cb(arguments, function () {
          var o = load(), ch = {};
          Object.keys(o).forEach(function (k) { ch[k] = { oldValue: o[k] }; });
          save({});
          fire(ch, name);
        });
      },
      getBytesInUse: function () { return cb(arguments, function () { return JSON.stringify(load()).length; }); },
      onChanged: onChanged
    };
  }

  var runtime = ns({
    id: ID,
    getURL: function (p) { return BASE + String(p).replace(/^\//, ""); },
    getManifest: function () { return clone(M); },
    getPlatformInfo: function () { return cb(arguments, function () { return { os: "android", arch: "arm64", nacl_arch: "arm" }; }); },
    sendMessage: function () {
      var a = [].slice.call(arguments), done = null;
      if (typeof a[a.length - 1] === "function") done = a.pop();
      if (a.length >= 2 && typeof a[0] === "string" && /^[a-p]{32}$/.test(a[0])) a.shift();
      var m = a[0];
      var p = ask(function (cid) { B.send(ID, str(m), location.href, T, cid); }).then(parseJ);
      return withCb(done, p);
    },
    connect: function () {
      return { name: "", postMessage: function () {}, disconnect: function () {}, onMessage: ev(), onDisconnect: ev() };
    },
    openOptionsPage: function () {
      var o = (M.options_ui && M.options_ui.page) || M.options_page;
      if (o) openTab(o);
      return cb(arguments, function () {});
    },
    reload: function () {},
    onMessage: ev(), onConnect: ev(), onInstalled: ev(), onStartup: ev(), onSuspend: ev(), onUpdateAvailable: ev()
  });

  var C = {
    runtime: runtime,
    extension: ns({
      getURL: runtime.getURL, inIncognitoContext: false,
      getBackgroundPage: function () { return null; }, getViews: function () { return []; },
      isAllowedIncognitoAccess: function () { return cb(arguments, function () { return false; }); }
    }),
    storage: ns({
      local: area("local"), sync: area("sync"), session: area("session"), managed: area("managed"),
      onChanged: onChanged
    }),
    i18n: ns({
      getMessage: function (n, s) {
        var m = MSG[String(n).toLowerCase()];
        if (m == null) return "";
        if (s == null) s = []; else if (!Array.isArray(s)) s = [s];
        return m.replace(/\$(\d)/g, function (_, i) { var v = s[+i - 1]; return v == null ? "" : v; }).replace(/\$\$/g, "$");
      },
      getUILanguage: function () { return navigator.language; },
      getAcceptLanguages: function () { return cb(arguments, function () { return (navigator.languages || [navigator.language]).slice(); }); }
    }),
    tabs: ns({
      create: function (o) { openTab(o && o.url); return cb(arguments, function () { return { id: 2, url: o && o.url, active: true }; }); },
      query: function () {
        return cb(arguments, function () { try { return JSON.parse(B.tabinfo(ID, T)); } catch (e) { return []; } });
      },
      get: function () { return cb(arguments, function () { try { return JSON.parse(B.tabinfo(ID, T))[0]; } catch (e) { return undefined; } }); },
      getCurrent: function () { return cb(arguments, function () { return undefined; }); },
      sendMessage: function () {
        var a = [].slice.call(arguments), done = null;
        if (typeof a[a.length - 1] === "function") done = a.pop();
        var m = a[1];
        var p = ask(function (cid) { B.tabsend(ID, str(m), T, cid); }).then(parseJ);
        return withCb(done, p);
      }
    }),
    alarms: alarms,
    permissions: ns({
      contains: function () { return cb(arguments, function () { return true; }); },
      request: function () { return cb(arguments, function () { return true; }); },
      getAll: function () { return cb(arguments, function () { return { permissions: M.permissions || [], origins: [] }; }); }
    })
  };
  // 백그라운드 → 확장 프로그램 페이지(콘텐츠 스크립트 · 팝업) 메시지 받기 / 백그라운드가 받는 메시지 처리
  if (window.__evxIsBg) {
    window.__evxBgIn = function (cid, mj, sj) {
      dispatch(runtime.onMessage, parseJ(mj), parseJ(sj), function (v) { B.bgresp(ID, cid, v === undefined ? "" : JSON.stringify(v), T); });
    };
  } else {
    var LS = window.__evxLs;
    if (!LS) { LS = {}; try { Object.defineProperty(window, "__evxLs", { value: LS }); } catch (e) { } }
    LS[ID] = function (cid, mj, sj) {
      dispatch(runtime.onMessage, parseJ(mj), parseJ(sj), function (v) { B.pageresp(ID, cid, v === undefined ? "" : JSON.stringify(v), T); });
    };
    if (!window.__evxTabIn) {
      try {
        Object.defineProperty(window, "__evxTabIn", {
          value: function (ext, cid, mj, sj) {
            var f = window.__evxLs && window.__evxLs[ext];
            if (f) f(cid, mj, sj); else B.pageresp(ext, cid, "", T);
          }
        });
      } catch (e) { }
    }
  }

  // 백그라운드 페이지 전용: 서비스 워커 흉내 · CORS 없이 fetch · 시작 이벤트
  if (window.__evxIsBg && !window.__evxStarted) {
    window.__evxStarted = true;
    try { self.skipWaiting = function () { return Promise.resolve(); }; } catch (e) { }
    try { self.clients = { claim: function () { return Promise.resolve(); }, matchAll: function () { return Promise.resolve([]); } }; } catch (e) { }
    window.importScripts = function () {
      for (var i = 0; i < arguments.length; i++) {
        var u = new URL(arguments[i], BASE).href, x = new XMLHttpRequest();
        x.open("GET", u, false); x.send();
        if (x.status >= 200 && x.status < 300) (0, eval)(x.responseText + "\n//# sourceURL=" + u);
        else throw new Error("importScripts 실패: " + u);
      }
    };
    var _fetch = window.fetch.bind(window);
    var b64 = function (buf) {
      var u = new Uint8Array(buf), s = "";
      for (var i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
      return btoa(s);
    };
    var unb64 = function (s) { var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
    window.fetch = function (input, init) {
      var req;
      try { req = new Request(input, init); } catch (e) { return _fetch(input, init); }
      var url = req.url;
      if (!/^https?:\/\//i.test(url) || url.indexOf(ROOT) === 0) return _fetch(req);
      return req.arrayBuffer().then(function (buf) {
        var h = {};
        req.headers.forEach(function (v, k) { h[k] = v; });
        return ask(function (cid) { B.xfetch(ID, url, req.method, JSON.stringify(h), buf.byteLength ? b64(buf) : "", T, cid); }, 60000);
      }).then(function (j) {
        var r = parseJ(j);
        if (!r || r.error || r.status < 200 || r.status > 599) throw new TypeError("Failed to fetch");
        var nb = r.status === 204 || r.status === 205 || r.status === 304;
        return new Response(nb ? null : unb64(r.body || ""), { status: r.status, statusText: r.statusText || "", headers: r.headers || {} });
      });
    };
    window.addEventListener("load", function () {
      setTimeout(function () {
        ["install", "activate"].forEach(function (n) {
          try { var e = new Event(n); e.waitUntil = function () { }; window.dispatchEvent(e); } catch (x) { }
        });
        runtime.onStartup._d([]);
        if (window.__evxInstalled) runtime.onInstalled._d([{ reason: "install" }]);
      }, 0);
    });
  }

  return new Proxy(C, {
    get: function (t, k) {
      if (k in t) return t[k];
      if (typeof k === "symbol" || k === "then") return undefined;
      return ns({});
    }
  });
}
