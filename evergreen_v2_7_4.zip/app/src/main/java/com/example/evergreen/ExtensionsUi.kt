package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch

/** 설정 > 확장 프로그램 (상/하단바의 확장 프로그램 버튼도 같은 화면): 설치된 확장 프로그램을 켜고 끄고, 팝업·옵션을 열고, 지운다. */
object ExtensionsUi {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Float, ctx: Context) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp * ctx.resources.displayMetrics.density
    }

    /**
     * @param onAdd 웹스토어 / 파일(zip·crx) 중에 골라 추가하러 간다 (이 화면은 닫힌다)
     * @param onOpenPage 확장 프로그램 안의 페이지(옵션)를 새 탭으로 연다
     * @param onOpenPopup 확장 프로그램의 툴바 팝업을 앱 안 팝업으로 띄운다 (이 화면은 닫힌다)
     * @param onChanged 켜기/끄기/삭제로 바뀐 게 있을 때, 이 화면을 닫으면서 한 번 부른다
     */
    fun show(
        ctx: Context,
        mgr: ExtensionManager,
        onAdd: () -> Unit,
        onOpenPage: (String) -> Unit,
        onOpenPopup: (ExtensionManager.Ext) -> Unit,
        onChanged: () -> Unit
    ): Dialog {
        val items = mgr.list()
        val onSurface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val surface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        val cardBg = ColorUtils.blendARGB(surface, onSurface, 0.06f)
        val chipBg = ColorUtils.setAlphaComponent(primary, 0x24)
        val dangerFg = 0xFFD93025.toInt()
        var changed = false
        val enabledCount = items.count { it.enabled }

        return Popup.panel(
            ctx,
            title = "확장 프로그램",
            subtitle = if (items.isEmpty()) "설치된 확장 프로그램이 없어요" else "${items.size}개 설치됨 · ${enabledCount}개 켜짐",
            headerIcon = R.drawable.ic_extension,
            widthDp = 400,
            secondaryLabel = "＋ 추가",
            onSecondary = { d ->
                d.dismiss()
                onAdd()
            }
        ) { list, dialog ->
            dialog.setOnDismissListener { if (changed) onChanged() }
            if (!mgr.supported) {
                list.addView(TextView(ctx).apply {
                    text = "이 기기의 웹뷰(WebView)가 페이지 시작 시 스크립트 삽입을 지원하지 않아 확장 프로그램이 동작하지 않아요. 'Android System WebView'를 업데이트해 보세요."
                    textSize = 12f
                    setTextColor(dangerFg)
                    setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 4))
                })
            }
            if (items.isEmpty()) {
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(ctx, 20), dp(ctx, 18), dp(ctx, 20), dp(ctx, 14))
                    addView(ImageView(ctx).apply {
                        setImageResource(R.drawable.ic_extension)
                        imageTintList = android.content.res.ColorStateList.valueOf(primary)
                        background = round(chipBg, 28f, ctx)
                        val p = dp(ctx, 16)
                        setPadding(p, p, p, p)
                        layoutParams = LinearLayout.LayoutParams(dp(ctx, 64), dp(ctx, 64)).apply { bottomMargin = dp(ctx, 14) }
                    })
                    addView(TextView(ctx).apply {
                        text = "아직 설치한 확장 프로그램이 없어요"
                        textSize = 15f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(onSurface)
                        gravity = Gravity.CENTER
                    })
                    addView(TextView(ctx).apply {
                        text = "＋ 추가를 눌러 크롬 웹스토어의 주소(또는 ID)로 바로 설치하거나, .zip · .crx 파일을 추가해 보세요.\n\n" +
                            "다크 모드, 광고·요소 숨기기, 글자 정리처럼 웹페이지를 꾸미는 종류는 잘 동작해요. 백그라운드(메시지 · 알람 · 외부 요청)와 툴바 팝업도 지원하지만, 요청 차단(webRequest) · 우클릭 메뉴 · 포트 연결은 지원하지 않아요."
                        textSize = 12.5f
                        setTextColor(onVar)
                        setLineSpacing(0f, 1.15f)
                        gravity = Gravity.CENTER
                        setPadding(0, dp(ctx, 8), 0, 0)
                    })
                })
                return@panel
            }
            items.forEach { e ->
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    background = round(cardBg, 18f, ctx)
                    setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 8), dp(ctx, 10))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(ctx, 4)
                        bottomMargin = dp(ctx, 4)
                    }

                    // 윗줄: 아이콘 · 이름/버전/설명 · 스위치 (아이콘·이름을 누르면 팝업이 있는 확장 프로그램은 바로 팝업을 연다)
                    val top = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val info = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        if (e.popup != null && e.enabled) {
                            isClickable = true
                            setOnClickListener {
                                dialog.dismiss()
                                onOpenPopup(e)
                            }
                        }
                        addView(ImageView(ctx).apply {
                            val bmp = mgr.iconBitmap(e)
                            if (bmp != null) setImageBitmap(bmp)
                            else {
                                setImageResource(R.drawable.ic_extension)
                                imageTintList = android.content.res.ColorStateList.valueOf(onVar)
                                val p = dp(ctx, 8)
                                setPadding(p, p, p, p)
                            }
                            background = round(ColorUtils.blendARGB(surface, onSurface, 0.04f), 12f, ctx)
                            alpha = if (e.enabled) 1f else 0.45f
                            layoutParams = LinearLayout.LayoutParams(dp(ctx, 42), dp(ctx, 42)).apply { marginEnd = dp(ctx, 12) }
                        })
                        addView(LinearLayout(ctx).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            alpha = if (e.enabled) 1f else 0.55f
                            addView(LinearLayout(ctx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                addView(TextView(ctx).apply {
                                    text = e.name
                                    textSize = 15f
                                    setTypeface(typeface, Typeface.BOLD)
                                    setTextColor(onSurface)
                                    maxLines = 1
                                    ellipsize = android.text.TextUtils.TruncateAt.END
                                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(ctx, 6) }
                                })
                                addView(TextView(ctx).apply {
                                    text = "v${e.version}"
                                    textSize = 10.5f
                                    setTextColor(onVar)
                                    background = round(ColorUtils.setAlphaComponent(onSurface, 0x14), 8f, ctx)
                                    setPadding(dp(ctx, 6), dp(ctx, 1), dp(ctx, 6), dp(ctx, 1))
                                })
                            })
                            if (e.description.isNotBlank()) addView(TextView(ctx).apply {
                                text = e.description
                                textSize = 12f
                                setTextColor(onVar)
                                maxLines = 2
                                ellipsize = android.text.TextUtils.TruncateAt.END
                                setPadding(0, dp(ctx, 2), 0, 0)
                            })
                        })
                    }
                    top.addView(info)
                    top.addView(MaterialSwitch(ctx).apply {
                        isChecked = e.enabled
                        setOnCheckedChangeListener { _, on ->
                            mgr.setEnabled(e.id, on)
                            changed = true
                            // 켜짐/꺼짐에 맞춰 이 카드 모양만 바로 바꾼다
                            (top.parent as? View)?.animate()?.alpha(if (on) 1f else 0.85f)?.setDuration(150)?.start()
                            info.getChildAt(0).alpha = if (on) 1f else 0.45f
                            info.getChildAt(1).alpha = if (on) 1f else 0.55f
                        }
                    })
                    addView(top)

                    // 제한 사항 안내
                    val notes = ArrayList<String>()
                    if (e.entries.isEmpty() && !e.hasBackground && e.popup == null) notes.add("웹페이지에 넣는 스크립트가 없어서 이 앱에서는 할 수 있는 일이 없어요")
                    else if (e.hasBackground) notes.add("백그라운드는 메시지 · 알람 · 외부 요청만 지원해서 일부 기능은 동작하지 않을 수 있어요")
                    if (notes.isNotEmpty()) addView(TextView(ctx).apply {
                        text = notes.joinToString("\n")
                        textSize = 11.5f
                        setTextColor(0xFFC77700.toInt())
                        background = round(0x1AC77700, 10f, ctx)
                        setPadding(dp(ctx, 10), dp(ctx, 6), dp(ctx, 10), dp(ctx, 6))
                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                            topMargin = dp(ctx, 8)
                            marginEnd = dp(ctx, 4)
                        }
                    })

                    // 아랫줄: 팝업 · 옵션 ·········· 삭제 (알약 모양 버튼)
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, dp(ctx, 8), dp(ctx, 4), 0)
                        fun chip(label: String, fg: Int, bg: Int, click: () -> Unit) {
                            addView(TextView(ctx).apply {
                                text = label
                                textSize = 12.5f
                                setTypeface(typeface, Typeface.BOLD)
                                setTextColor(fg)
                                gravity = Gravity.CENTER
                                background = RippleDrawable(
                                    android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(fg, 0x33)),
                                    round(bg, 100f, ctx), null
                                )
                                setPadding(dp(ctx, 14), dp(ctx, 7), dp(ctx, 14), dp(ctx, 7))
                                isClickable = true
                                setOnClickListener { click() }
                                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 6) }
                            })
                        }
                        if (e.popup != null) {
                            chip("팝업 열기", primary, chipBg) {
                                if (!e.enabled) {
                                    AppToast.show(ctx, "꺼져 있는 확장 프로그램이에요. 먼저 켜 주세요")
                                } else {
                                    dialog.dismiss()
                                    onOpenPopup(e)
                                }
                            }
                        }
                        e.options?.let { o ->
                            chip("옵션", primary, chipBg) {
                                dialog.dismiss()
                                onOpenPage(mgr.pageUrl(e, o))
                            }
                        }
                        addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
                        chip("삭제", dangerFg, ColorUtils.setAlphaComponent(dangerFg, 0x1A)) {
                            Popup.confirm(
                                ctx, "'${e.name}'을(를) 삭제할까요?",
                                "확장 프로그램 파일과 저장된 설정이 모두 지워져요.",
                                "삭제", danger = true
                            ) {
                                mgr.remove(e.id)
                                changed = true
                                dialog.dismiss()
                                // 남은 목록으로 다시 연다 (바뀐 것은 닫을 때 한 번만 알린다)
                                if (mgr.list().isNotEmpty()) {
                                    show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged)
                                }
                            }
                        }
                    })
                })
            }
        }
    }
}
