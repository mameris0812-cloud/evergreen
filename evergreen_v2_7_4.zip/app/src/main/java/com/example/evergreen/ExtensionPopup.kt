package com.example.evergreen

import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.color.MaterialColors

/**
 * 확장 프로그램의 툴바 팝업(action.default_popup)을 새 탭이 아니라 앱 안 카드 팝업으로 띄운다 (크롬 방식).
 * 폭은 360dp 고정, 높이는 팝업 페이지 내용에 맞춰 늘고 줄며, 화면 높이의 80%를 넘으면 안에서 스크롤된다.
 */
object ExtensionPopup {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun viewport(ctx: Context): Pair<Int, Int> {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) {
                val root = c.window?.decorView
                if (root != null && root.width > 0 && root.height > 0) return root.width to root.height
                break
            }
            c = c.baseContext
        }
        val dm = ctx.resources.displayMetrics
        return dm.widthPixels to dm.heightPixels
    }

    /** @param onOpenTab 팝업 안 링크나 '탭에서 열기'로 주소를 새 탭에 열 때 */
    fun show(
        ctx: Context,
        mgr: ExtensionManager,
        e: ExtensionManager.Ext,
        onOpenTab: (String) -> Unit
    ): Dialog? {
        val page = e.popup ?: return null
        val url = mgr.pageUrl(e, page)
        val onSurface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val surface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurface, Color.WHITE)
        val primary = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())

        val dialog = Dialog(ctx, R.style.Evergreen_Popup)
        Popup.trackDialog(dialog)
        val (vw, vh) = viewport(ctx)
        val width = minOf(dp(ctx, 360), (vw * 0.94f).toInt())
        val maxBody = (vh * 0.78f).toInt() - dp(ctx, 64)
        val minBody = dp(ctx, 120)

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(surface)
                cornerRadius = dp(ctx, 26).toFloat()
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }

        // 머리말: 아이콘 · 이름 · 탭에서 열기 · 닫기
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 8), dp(ctx, 6))
        }
        header.addView(ImageView(ctx).apply {
            val bmp = mgr.iconBitmap(e)
            if (bmp != null) setImageBitmap(bmp)
            else {
                setImageResource(R.drawable.ic_extension)
                imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 26), dp(ctx, 26)).apply { marginEnd = dp(ctx, 10) }
        })
        header.addView(TextView(ctx).apply {
            text = e.name
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(onSurface)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        fun iconBtn(res: Int, desc: String, click: () -> Unit) = ImageButton(ctx).apply {
            setImageResource(res)
            imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            contentDescription = desc
            val tv = android.util.TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            val p = dp(ctx, 10)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 40), dp(ctx, 40))
            setOnClickListener { click() }
        }
        header.addView(iconBtn(R.drawable.ic_open_tab, "탭에서 열기") {
            dialog.dismiss()
            onOpenTab(url)
        })
        header.addView(iconBtn(R.drawable.ic_close, "닫기") { dialog.dismiss() })
        card.addView(header)

        // 위쪽 로딩 막대 (페이지가 다 불러와지면 사라진다)
        val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(primary)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 2))
        }
        card.addView(bar)

        val wv: WebView = mgr.newPopupView { link -> dialog.dismiss(); onOpenTab(link) }
        wv.setBackgroundColor(surface)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        val body = FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 200))
        }
        body.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(body)

        dialog.setContentView(card)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.apply {
            setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        // 내용 높이에 맞춰 팝업 높이를 늘이고 줄인다 (크롬의 팝업처럼)
        val ui = Handler(Looper.getMainLooper())
        var closed = false
        var curH = dp(ctx, 200)
        var anim: ValueAnimator? = null
        fun resizeTo(target: Int) {
            val t = target.coerceIn(minBody, maxOf(minBody, maxBody))
            if (kotlin.math.abs(t - curH) < dp(ctx, 6)) return
            anim?.cancel()
            anim = ValueAnimator.ofInt(curH, t).apply {
                duration = 180
                addUpdateListener {
                    curH = it.animatedValue as Int
                    body.layoutParams = body.layoutParams.apply { height = curH }
                    body.requestLayout()
                }
                start()
            }
        }
        lateinit var poll: Runnable
        poll = Runnable {
            if (closed) return@Runnable
            wv.evaluateJavascript(
                "(function(){var d=document.documentElement,b=document.body;return Math.max(d?d.scrollHeight:0,b?b.scrollHeight:0)})()"
            ) { r ->
                val cssPx = r?.trim('"')?.toDoubleOrNull() ?: 0.0
                if (cssPx > 0 && !closed) resizeTo((cssPx * ctx.resources.displayMetrics.density).toInt())
            }
            ui.postDelayed(poll, 700)
        }
        // 새로 불러오기가 끝나면 로딩 막대를 걷는다
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView?, p: Int) {
                if (p >= 100) bar.visibility = View.GONE
            }
        }
        dialog.setOnDismissListener {
            closed = true
            ui.removeCallbacksAndMessages(null)
            anim?.cancel()
            mgr.releasePopupView(wv)
        }
        card.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        wv.loadUrl(url)
        ui.postDelayed(poll, 250)
        return dialog
    }
}
