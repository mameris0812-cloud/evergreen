package com.example.evergreen

import android.app.Activity
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * 설정 > 앱 정보 > '업데이트 로그': 버전별로 바뀐 내용을 보여 준다.
 * 새 버전을 낼 때마다 [ENTRIES] 맨 위에 한 항목씩 더한다 (최신이 위).
 */
object Changelog {

    class Entry(val version: String, val date: String, val notes: List<String>)

    val ENTRIES: List<Entry> = listOf(
        Entry(
            "2.7.4", "2026-11-10", listOf(
                "확장 프로그램 수정: '문서 시작(document_start)'에 도는 콘텐츠 스크립트가 <html> 이 생기기 전에 실행돼 오류로 멈추던 문제를 고쳤어요 (페이지에 아무것도 적용되지 않던 원인)"
            )
        ),
        Entry(
            "2.7.3", "2026-11-10", listOf(
                "상/하단바에 '확장 프로그램' 버튼 추가: 설정 > 상/하단바 편집에서 고르면 바에서 바로 확장 프로그램 목록을 열 수 있어요",
                "확장 프로그램 툴바 팝업이 새 탭이 아니라 앱 안 팝업으로 떠요 (폭 360dp, 내용 높이에 맞춰 늘고 줄어요). 머리말의 버튼으로 탭에서도 열 수 있어요",
                "확장 프로그램 화면을 카드 모양으로 새로 꾸몄어요: 버전 표시, 켜짐/꺼짐 상태, 알약 모양 '팝업 열기 · 옵션 · 삭제' 버튼, 이름을 누르면 팝업 바로 열기, 비어 있을 때의 안내 화면"
            )
        ),
        Entry(
            "2.7.2", "2026-11-10", listOf(
                "확장 프로그램 백그라운드 지원: 눈에 안 보이는 웹뷰에서 background(service worker · scripts)를 돌려요",
                "콘텐츠 스크립트·팝업 ↔ 백그라운드 메시지(runtime.sendMessage / onMessage, 응답 포함), 백그라운드 → 보고 있는 탭 메시지(tabs.sendMessage), tabs.query · tabs.create, chrome.alarms, importScripts, onInstalled · onStartup 지원",
                "백그라운드의 fetch 는 host 권한이 있는 주소에 한해 앱이 대신 요청해서 CORS 에 막히지 않아요",
                "여전히 안 되는 것: 요청 차단(webRequest · declarativeNetRequest), contextMenus, runtime.connect(포트)"
            )
        ),
        Entry(
            "2.7.1", "2026-11-10", listOf(
                "크롬 웹스토어에서 확장 프로그램 바로 설치: 설정 > 확장 프로그램 > ＋ 추가 > '크롬 웹스토어에서 추가'에 웹스토어 주소(또는 영문 32자 ID)를 넣으면 내려받아 설치해요",
                "웹스토어 확장 프로그램 상세 페이지를 열면 아래에 '설치' 알림이 떠서 한 번에 설치할 수 있어요 (시크릿 탭 제외)",
                "'웹스토어 열기' 버튼으로 웹스토어를 새 탭에서 열어 둘러볼 수 있어요"
            )
        ),
        Entry(
            "2.7.0", "2026-11-10", listOf(
                "크롬 확장 프로그램 지원 (설정 > 브라우저 > 확장 프로그램): .zip · .crx 파일을 추가하면 조건(matches)에 맞는 페이지에 확장 프로그램의 스크립트·스타일이 적용돼요",
                "chrome.runtime · storage · i18n 등 자주 쓰는 API 지원, 켜기/끄기 · 옵션 열기 · 삭제 가능",
                "백그라운드(service worker) · webRequest · 팝업 메시지 같은 기능은 지원하지 않아요. 시크릿 탭에서는 쓰지 않아요"
            )
        ),
        Entry(
            "2.6.30", "2026-11-10", listOf(
                "웹사이트에서 펜 호버링 지원: 펜을 화면에 띄우고 움직이면 마우스를 올린 것처럼 호버 메뉴·툴팁·:hover 효과가 동작"
            )
        ),
        Entry(
            "2.6.29", "2026-11-10", listOf(
                "내장 플레이어: 추천 영상이 없을 때 '재생이 끝났어요'와 버튼이 가로 화면에서도 화면 가운데에 오도록 수정"
            )
        ),
        Entry(
            "2.6.28", "2026-11-10", listOf(
                "내장 플레이어 '다음 영상' 카드 UI 개선: 큰 카드·목록 썸네일을 키우고 길이 표시가 또렷하게 보이도록 개선",
                "가로 화면(태블릿)에서 오른쪽 '이어서 볼 영상' 목록이 왼쪽 카드와 같은 높이 중심에 오도록 정리",
                "목록 줄이 하나씩 차례로 나타나도록 애니메이션 개선"
            )
        ),
        Entry(
            "2.6.27", "2026-11-10", listOf(
                "메뉴창 미디어 플레이어: 일시정지 버튼과 10초 이동 버튼 사이 간격을 약 30dp로 맞춤"
            )
        ),
        Entry(
            "2.6.26", "2026-11-10", listOf(
                "메뉴창 미디어 플레이어: 재생/일시정지 버튼과 10초 이동 버튼 사이 여백을 살짝 줄임"
            )
        ),
        Entry(
            "2.6.25", "2026-11-10", listOf(
                "유튜브 광고가 시작될 때 로딩이 오래 걸리던 문제 개선",
                "광고를 끝으로 넘길 때 0.25초마다 계속 옮기던 것을 광고 하나당 한 번만 옮기도록 고침",
                "유튜브 광고 차단이 켜져 있으면 유튜브에서 구글 광고 서버 요청을 막지 않고 통과시킴 (막으면 광고가 안 불러와져 유튜브가 한참 기다림)"
            )
        ),
        Entry(
            "2.6.24", "2026-11-10", listOf(
                "설정 > 앱 정보에 '업데이트 로그' 추가"
            )
        ),
        Entry(
            "2.6.23", "2026-11-10", listOf(
                "유튜브 광고 차단 개선: 영상 정보에서 광고 목록을 미리 지워 광고가 시작되지 않게 함",
                "광고의 '건너뛰기' 버튼이 스크립트 클릭으로 안 눌리면 앱이 진짜 터치로 눌러 줌",
                "설정 > 광고 차단에 '유튜브 광고 미리 지우기' 켜고 끄기 추가"
            )
        )
    )

    fun show(act: Activity) {
        val dp = act.resources.displayMetrics.density
        val sb = SpannableStringBuilder()
        ENTRIES.forEachIndexed { i, e ->
            if (i > 0) sb.append("\n\n")
            val head = "v${e.version}"
            val s = sb.length
            sb.append(head)
            sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(RelativeSizeSpan(1.1f), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (e.version == BuildConfig.VERSION_NAME) sb.append("  · 현재 버전")
            sb.append("\n").append(e.date)
            e.notes.forEach { sb.append("\n• ").append(it) }
        }
        val tv = TextView(act).apply {
            text = sb
            textSize = 14f
            setLineSpacing(0f, 1.2f)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(act).apply {
            addView(
                LinearLayout(act).apply {
                    setPadding((24 * dp).toInt(), (8 * dp).toInt(), (24 * dp).toInt(), (8 * dp).toInt())
                    addView(tv)
                }
            )
        }
        MaterialAlertDialogBuilder(act)
            .setTitle("업데이트 로그")
            .setView(scroll)
            .setPositiveButton("닫기", null)
            .show()
    }
}
