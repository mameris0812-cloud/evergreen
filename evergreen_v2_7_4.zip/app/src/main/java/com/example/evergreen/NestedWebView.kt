package com.example.evergreen

import android.content.Context
import android.graphics.Rect
import android.view.ActionMode
import android.view.InputDevice
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.webkit.WebView

/**
 * 세로 스크롤을 부모(PullRefreshLayout)에게 먼저 나눠 주는 WebView.
 *
 * 손가락이 움직이면 부모가 그 만큼을 먼저 써서 메뉴바를 밀어내고, 남은 움직임만 웹페이지가 스크롤한다.
 * (크롬처럼 메뉴바가 손가락을 그대로 따라 움직이고, 그동안 페이지는 제자리에 있다.)
 */
class NestedWebView(context: Context) : WebView(context) {
    private var lastY = 0
    private var nestedOffsetY = 0
    private val scrollOffset = IntArray(2)
    private val scrollConsumed = IntArray(2)

    /**
     * 백그라운드 재생: true 를 돌려주는 동안에는 앱이 화면 밖으로 나가거나 화면이 꺼져도
     * 이 웹뷰를 '안 보임' 상태로 바꾸지 않는다. 안 보임으로 바뀌면 WebView 가 소리까지 멈춰 버리는 기기가 많다.
     */
    var keepPlaying: () -> Boolean = { false }

    init {
        isNestedScrollingEnabled = true
    }

    /**
     * 글자를 선택했을 때 뜨는 시스템(네이티브) 팝업에 「AI에게 물어보기」를 끼워 넣는다.
     * 눌리면 선택한 글을 이 콜백으로 넘긴다. null 이면 팝업을 건드리지 않는다.
     */
    var onAskAi: ((String) -> Unit)? = null

    override fun startActionMode(callback: ActionMode.Callback?, type: Int): ActionMode? {
        if (callback == null || onAskAi == null || type != ActionMode.TYPE_FLOATING) {
            return super.startActionMode(callback, type)
        }
        return super.startActionMode(AskAiCallback(callback), type)
    }

    private inner class AskAiCallback(private val base: ActionMode.Callback) : ActionMode.Callback2() {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean = base.onCreateActionMode(mode, menu)

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
            val changed = base.onPrepareActionMode(mode, menu)
            if (menu.findItem(ASK_AI_ID) == null) {
                menu.add(Menu.NONE, ASK_AI_ID, Menu.NONE, "AI에게 물어보기")
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
                return true
            }
            return changed
        }

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            if (item.itemId != ASK_AI_ID) return base.onActionItemClicked(mode, item)
            // 선택한 글을 읽은 뒤에 팝업을 닫는다 (먼저 닫으면 선택이 풀려 빈 글이 올 수 있다)
            evaluateJavascript("(function(){return window.getSelection().toString();})()") { raw ->
                val text = try {
                    (org.json.JSONTokener(raw ?: "null").nextValue() as? String).orEmpty().trim()
                } catch (e: Exception) {
                    ""
                }
                mode.finish()
                if (text.isNotEmpty()) onAskAi?.invoke(text)
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) = base.onDestroyActionMode(mode)

        override fun onGetContentRect(mode: ActionMode, view: View, outRect: Rect) {
            if (base is ActionMode.Callback2) base.onGetContentRect(mode, view, outRect)
            else super.onGetContentRect(mode, view, outRect)
        }
    }

    private companion object {
        const val ASK_AI_ID = 0x41490001
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.VISIBLE && keepPlaying()) {
            // 보이는 상태 그대로 유지 (안 보임/없어짐 알림을 웹뷰에 전달하지 않는다)
            super.onWindowVisibilityChanged(View.VISIBLE)
            return
        }
        super.onWindowVisibilityChanged(visibility)
    }

    /** 이 페이지에서 관측된 가장 작은 배율(= 기본 배율). 페이지가 새로 시작되면 0 으로 되돌린다 */
    var baseScale = 0f

    /** 사용자가 핀치로 기본 배율보다 확대해 둔 상태인지 (확대 중에는 당겨서 새로고침을 막는다) */
    var isZoomedIn = false
        private set

    fun onPageScaleChanged(newScale: Float) {
        if (newScale <= 0f) return
        if (baseScale <= 0f || newScale < baseScale) baseScale = newScale
        isZoomedIn = newScale > baseScale * 1.05f
    }

    fun resetZoomTracking() {
        baseScale = 0f
        isZoomedIn = false
    }

    /**
     * 펜 호버링: 펜을 화면에 대지 않고 띄운 채로 움직이면 웹페이지에 '마우스를 올린 것'으로 전달한다.
     * (메뉴가 펼쳐지는 호버 메뉴, 툴팁, :hover 효과 등이 마우스처럼 동작한다.)
     * 펜을 대고 쓰는 터치 동작은 그대로 두고, 띄운 상태(HOVER_*)의 이벤트만 마우스 종류로 바꿔 넘긴다.
     */
    override fun onHoverEvent(event: MotionEvent): Boolean {
        if (event.pointerCount == 1) {
            val tool = event.getToolType(0)
            if (tool == MotionEvent.TOOL_TYPE_STYLUS || tool == MotionEvent.TOOL_TYPE_ERASER) {
                val mouse = stylusHoverAsMouse(event)
                try {
                    super.onHoverEvent(mouse)
                } finally {
                    mouse.recycle()
                }
                return true
            }
        }
        return super.onHoverEvent(event)
    }

    private fun stylusHoverAsMouse(e: MotionEvent): MotionEvent {
        val props = MotionEvent.PointerProperties().also {
            e.getPointerProperties(0, it)
            it.toolType = MotionEvent.TOOL_TYPE_MOUSE
        }
        val coords = MotionEvent.PointerCoords().also { e.getPointerCoords(0, it) }
        return MotionEvent.obtain(
            e.downTime, e.eventTime, e.action, 1,
            arrayOf(props), arrayOf(coords),
            e.metaState, 0, e.xPrecision, e.yPrecision,
            e.deviceId, e.edgeFlags, InputDevice.SOURCE_MOUSE, e.flags
        )
    }

    /** 두 손가락 이상(핀치 확대/축소) 제스처가 진행 중인지 */
    private var multiTouch = false

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val action0 = ev.actionMasked
        // 핀치 줌: 손가락이 둘 이상이면 중첩 스크롤(메뉴바 밀기)과 좌표 보정을 모두 끄고
        // 원본 이벤트를 WebView 에 그대로 전달한다. 그래야 줌 제스처가 깨지지 않는다.
        if (action0 == MotionEvent.ACTION_POINTER_DOWN || ev.pointerCount > 1) {
            if (!multiTouch) {
                multiTouch = true
                stopNestedScroll()
            }
            // 보정했던 오프셋이 남아 있으면 되돌려서 좌표가 어긋나지 않게 한다
            val raw = MotionEvent.obtain(ev)
            raw.offsetLocation(0f, nestedOffsetY.toFloat())
            val h = super.onTouchEvent(raw)
            raw.recycle()
            return h
        }
        if (multiTouch) {
            // 손가락 하나만 남았거나 제스처가 끝남 — 기준점을 다시 잡고 이번 제스처는 중첩 스크롤 없이 끝까지 WebView 에 맡긴다
            if (action0 == MotionEvent.ACTION_UP || action0 == MotionEvent.ACTION_CANCEL) {
                multiTouch = false
                nestedOffsetY = 0
                stopNestedScroll()
            }
            val raw = MotionEvent.obtain(ev)
            raw.offsetLocation(0f, nestedOffsetY.toFloat())
            val h = super.onTouchEvent(raw)
            raw.recycle()
            return h
        }

        val event = MotionEvent.obtain(ev)
        val action = event.actionMasked
        if (action == MotionEvent.ACTION_DOWN) nestedOffsetY = 0
        val eventY = event.y.toInt()
        event.offsetLocation(0f, nestedOffsetY.toFloat())
        val handled: Boolean
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                handled = super.onTouchEvent(event)
                lastY = eventY
                startNestedScroll(View.SCROLL_AXIS_VERTICAL)
            }
            MotionEvent.ACTION_MOVE -> {
                val deltaY = lastY - eventY
                if (dispatchNestedPreScroll(0, deltaY, scrollConsumed, scrollOffset)) {
                    lastY = eventY - scrollOffset[1]
                    event.offsetLocation(0f, (-scrollOffset[1]).toFloat())
                    nestedOffsetY += scrollOffset[1]
                } else {
                    lastY = eventY
                }
                handled = super.onTouchEvent(event)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                stopNestedScroll()
                handled = super.onTouchEvent(event)
            }
            else -> handled = super.onTouchEvent(event)
        }
        event.recycle()
        return handled
    }
}
