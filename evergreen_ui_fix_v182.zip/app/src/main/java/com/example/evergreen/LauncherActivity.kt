package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 런처 아이콘(작업 표시줄·앱 목록·엣지 패널 포함)의 진입점. 보이지 않고 바로 닫힌다.
 *
 * - 떠 있는 창이 있으면: 앞으로 가져오기만 한다 (아이콘을 눌러도 새 창은 열지 않는다).
 * - 없으면: 여러 창으로 뜰 수 있는 문서형 작업(BrowserWindowActivity)으로 첫 창을 연다.
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val running = MainActivity.runningWindows().filter { !it.isFinishing && !it.isDestroyed }

        // 아이콘을 눌렀을 때는 새 창을 절대 만들지 않는다.
        // 이미 떠 있는 창이 있으면 그 작업을 앞으로 가져오기만 하고, 없을 때만 첫 창을 연다.
        // (창 모드에서 눌러도 isInMultiWindowMode 가 true 라서, 그걸로는 '끌어서 열기'와 구분할 수 없다)
        if (running.isNotEmpty()) {
            try {
                val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
                am.appTasks.firstOrNull {
                    it.taskInfo.baseIntent?.component?.className != LauncherActivity::class.java.name
                }?.moveToFront()
            } catch (e: Throwable) {
                // 앞으로 못 가져와도 새 창은 만들지 않는다
            }
        } else {
            startActivity(
                Intent(this, BrowserWindowActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
            )
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
