package com.example.evergreen

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.content.Intent
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * 앱 안에서 보는 다운로드 목록.
 * - 받은 파일을 최근 순으로 보여주고, 누르면 열기 / 공유 / 폴더로 이동 / 삭제
 * - 받는 중인 파일은 맨 위에 진행률과 함께 보이고 취소할 수 있다
 * - 폴더: 위쪽 칩으로 폴더를 만들고, 파일을 폴더로 옮겨 정리한다 (앱 안에서만 쓰는 분류 — 실제 파일 위치는 그대로)
 */
class DownloadsActivity : AppCompatActivity() {

    private class Item(
        /** "m:123" = 미디어 저장소, "d:55" = 시스템 다운로드 관리자, "a:1000" = 지금 받는 중 */
        val key: String,
        val name: String,
        val size: Long,
        val time: Long,
        val mime: String?,
        val uri: Uri?,
        val activeId: Int = -1,
        val downloaded: Long = 0L,
        val speed: Long = 0L
    ) {
        val active: Boolean get() = activeId >= 0
    }

    private lateinit var prefs: Prefs
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var chipRow: LinearLayout
    private val adapter = RowAdapter()

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var stored: List<Item> = emptyList()
    private var active: List<ActiveDownload> = emptyList()
    private val shown = ArrayList<Item>()
    private var folderNames: Map<Long, String> = emptyMap()
    private var folderMap: Map<String, Long> = emptyMap()
    private var selected = ListUi.ALL
    private var loaded = false
    private var hadActive = false

    private val dateFormat = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        ListUi.applyTabletPopup(this)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.listTitle).text = "다운로드"
        findViewById<View>(R.id.btnListBack).setOnClickListener { finish() }
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.listEmpty)
        chipRow = findViewById(R.id.chipRow)
        listView.adapter = adapter

        refreshView()
    }

    override fun onResume() {
        super.onResume()
        reload()
        ui.postDelayed(tick, 1000)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        io.shutdown()
        super.onDestroy()
    }

    /** 1초마다: 받는 중인 파일이 있으면 진행률을 갱신하고, 방금 끝난 파일도 목록에 나타나게 한다. */
    private val tick = object : Runnable {
        override fun run() {
            val now = DownloadService.snapshot()
            val busy = now.isNotEmpty() || hadActive
            hadActive = now.isNotEmpty()
            active = now
            if (busy) reload()
            ui.postDelayed(this, 1000)
        }
    }

    // ───────────────────────── 목록 읽기 ─────────────────────────

    private fun reload() {
        if (isDestroyed || io.isShutdown) return
        io.execute {
            val items = try {
                queryDownloads()
            } catch (e: Exception) {
                emptyList()
            }
            ui.post {
                if (isFinishing || isDestroyed) return@post
                stored = items
                loaded = true
                refreshView()
            }
        }
    }

    private fun queryDownloads(): List<Item> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) queryMediaStore() else queryDownloadManager()

    /** Android 10+: 이 앱이 받은 파일 (빠른 다운로드 + 시스템 다운로더) 이 미디어 저장소에 모두 올라온다. */
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun queryMediaStore(): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.MIME_TYPE
        )
        contentResolver.query(
            base, projection, null, null,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    Item(
                        key = "m:$id",
                        name = c.getString(iName) ?: "(이름 없음)",
                        size = c.getLong(iSize),
                        time = c.getLong(iDate) * 1000L,
                        mime = c.getString(iMime),
                        uri = ContentUris.withAppendedId(base, id)
                    )
                )
            }
        }
        return out
    }

    /** Android 9 이하: 시스템 다운로드 관리자에 맡긴 파일 목록 (저장소 권한이 필요 없다). */
    private fun queryDownloadManager(): List<Item> {
        val out = ArrayList<Item>()
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        dm.query(DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL))?.use { c ->
            val iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
            val iTitle = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
            val iSize = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val iMime = c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)
            val iTime = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    Item(
                        key = "d:$id",
                        name = c.getString(iTitle) ?: "(이름 없음)",
                        size = c.getLong(iSize),
                        time = c.getLong(iTime),
                        mime = c.getString(iMime),
                        uri = dm.getUriForDownloadedFile(id)
                    )
                )
            }
        }
        return out.sortedByDescending { it.time }
    }

    // ───────────────────────── 화면 그리기 ─────────────────────────

    private fun activeItems(): List<Item> = active.map {
        Item(
            key = "a:${it.id}",
            name = it.name.ifEmpty { "다운로드 준비 중…" },
            size = it.total,
            time = 0L,
            mime = null,
            uri = null,
            activeId = it.id,
            downloaded = it.downloaded,
            speed = it.speedBps
        )
    }

    private fun refreshView() {
        val folders = prefs.folders(Prefs.KIND_DL)
        folderNames = folders.associate { it.id to it.name }
        folderMap = prefs.downloadFolderMap()
        if (selected != ListUi.ALL && folders.none { it.id == selected }) selected = ListUi.ALL

        // 폴더 칩 (개수 포함)
        val counts = HashMap<Long, Int>()
        stored.forEach {
            val f = folderMap[it.key] ?: 0L
            counts[f] = (counts[f] ?: 0) + 1
        }
        val entries = ArrayList<ListUi.ChipEntry>()
        entries.add(ListUi.ChipEntry(ListUi.ALL, "전체 (${stored.size + active.size})"))
        folders.forEach { entries.add(ListUi.ChipEntry(it.id, "${it.name} (${counts[it.id] ?: 0})")) }
        ListUi.renderChips(
            chipRow, entries, selected,
            onSelect = {
                selected = it
                refreshView()
            },
            onLongPress = { id ->
                folders.firstOrNull { it.id == id }?.let { f ->
                    ListUi.showFolderMenu(this, prefs, Prefs.KIND_DL, f) { refreshView() }
                }
            },
            onAdd = {
                ListUi.createFolder(this, prefs, Prefs.KIND_DL) {
                    selected = it.id
                    refreshView()
                }
            }
        )

        // 목록
        shown.clear()
        if (selected == ListUi.ALL) {
            shown.addAll(activeItems())
            shown.addAll(stored)
        } else {
            shown.addAll(stored.filter { folderMap[it.key] == selected })
        }
        adapter.notifyDataSetChanged()

        if (shown.isEmpty() && loaded) {
            emptyView.text =
                if (selected == ListUi.ALL) "받은 파일이 없습니다"
                else "이 폴더는 비어 있습니다\n파일의 ⋮ 메뉴 → '폴더로 이동' 으로 정리해 보세요"
            emptyView.visibility = View.VISIBLE
        } else {
            emptyView.visibility = View.GONE
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_list_row, parent, false)
            val item = shown[position]

            val icon = v.findViewById<ImageView>(R.id.rowIcon)
            val title = v.findViewById<TextView>(R.id.rowTitle)
            val sub = v.findViewById<TextView>(R.id.rowSub)
            val bar = v.findViewById<ProgressBar>(R.id.rowProgress)
            val more = v.findViewById<ImageButton>(R.id.rowMore)

            title.text = item.name
            icon.setImageResource(
                when {
                    item.active -> R.drawable.ic_download
                    item.mime?.startsWith("video") == true -> R.drawable.ic_movie
                    else -> R.drawable.ic_file
                }
            )

            if (item.active) {
                val speed = if (item.speed > 0) " · ${ListUi.fmtSize(item.speed)}/s" else ""
                if (item.size > 0) {
                    val pct = (item.downloaded * 100 / item.size).toInt().coerceIn(0, 100)
                    bar.isIndeterminate = false
                    bar.progress = pct
                    sub.text = "$pct% · ${ListUi.fmtSize(item.downloaded)} / ${ListUi.fmtSize(item.size)}$speed"
                } else {
                    bar.isIndeterminate = true
                    sub.text = "${ListUi.fmtSize(item.downloaded)}$speed"
                }
                bar.visibility = View.VISIBLE
            } else {
                bar.visibility = View.GONE
                val folder = folderMap[item.key]?.let { folderNames[it] }
                val parts = ArrayList<String>()
                if (item.size > 0) parts.add(ListUi.fmtSize(item.size))
                if (item.time > 0) parts.add(dateFormat.format(Date(item.time)))
                if (folder != null && selected == ListUi.ALL) parts.add(folder)
                sub.text = parts.joinToString(" · ")
            }

            v.setOnClickListener { if (!item.active) open(item) }
            v.setOnLongClickListener {
                showItemMenu(item)
                true
            }
            more.setOnClickListener { showItemMenu(item) }
            return v
        }
    }

    // ───────────────────────── 항목 동작 ─────────────────────────

    private fun showItemMenu(item: Item) {
        if (item.active) {
            Popup.menu(
                this, title = item.name, subtitle = "다운로드 중", headerIcon = R.drawable.ic_download,
                items = listOf(
                    Popup.Item(R.drawable.ic_close, "다운로드 취소", danger = true) {
                        DownloadService.cancelJob(item.activeId)
                        ListUi.toast(this, "다운로드를 취소합니다")
                    }
                )
            )
            return
        }
        Popup.menu(
            this, title = item.name, headerIcon = R.drawable.ic_file,
            items = listOf(
                Popup.Item(R.drawable.ic_file, "열기") { open(item) },
                Popup.Item(R.drawable.ic_share, "공유") { share(item) },
                Popup.Item(R.drawable.ic_folder, "폴더로 이동") { moveToFolder(item) },
                Popup.Item(R.drawable.ic_delete, "삭제", danger = true) { confirmDelete(item) }
            )
        )
    }

    private fun open(item: Item) {
        val uri = item.uri ?: return
        try {
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, item.mime?.takeIf { it.isNotBlank() } ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            ListUi.toast(this, "이 파일을 열 수 있는 앱이 없습니다")
        } catch (e: Exception) {
            ListUi.toast(this, "파일을 열 수 없습니다")
        }
    }

    private fun share(item: Item) {
        val uri = item.uri ?: return
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = item.mime?.takeIf { it.isNotBlank() } ?: "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "공유"))
        } catch (e: Exception) {
            ListUi.toast(this, "공유할 수 없습니다")
        }
    }

    private fun moveToFolder(item: Item) {
        ListUi.pickFolder(this, prefs, Prefs.KIND_DL, folderMap[item.key] ?: 0L) { folderId ->
            prefs.setDownloadFolder(item.key, folderId)
            refreshView()
            val name = folderNames[folderId] ?: prefs.folders(Prefs.KIND_DL).firstOrNull { it.id == folderId }?.name
            ListUi.toast(this, if (folderId == 0L || name == null) "폴더에서 뺐습니다" else "'$name' 폴더로 옮겼습니다")
        }
    }

    private fun confirmDelete(item: Item) {
        MaterialAlertDialogBuilder(this)
            .setMessage("'${item.name}' 파일을 삭제할까요?\n기기에서도 완전히 지워집니다.")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                if (io.isShutdown) return@setPositiveButton
                io.execute {
                    val ok = removeFile(item)
                    ui.post {
                        if (isFinishing || isDestroyed) return@post
                        if (ok) {
                            prefs.setDownloadFolder(item.key, 0L)
                            ListUi.toast(this, "삭제했습니다")
                        } else {
                            ListUi.toast(this, "삭제하지 못했습니다")
                        }
                        reload()
                    }
                }
            }
            .show()
    }

    private fun removeFile(item: Item): Boolean = try {
        if (item.key.startsWith("m:")) {
            val uri = item.uri
            uri != null && contentResolver.delete(uri, null, null) > 0
        } else {
            val id = item.key.substring(2).toLong()
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).remove(id) > 0
        }
    } catch (e: Exception) {
        false
    }
}
