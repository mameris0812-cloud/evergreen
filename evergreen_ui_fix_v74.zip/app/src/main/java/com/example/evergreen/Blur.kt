package com.example.evergreen

import android.content.Context
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.PopupWindow
import androidx.annotation.RequiresApi
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 메뉴·팝업 뒤 배경 블러 (유리 느낌).
 * Android 12(API 31) 이상이고 기기가 창 블러를 지원/허용할 때만 켜진다.
 * 그 외 기기(또는 절전 모드 등으로 꺼진 경우)에서는 예전처럼 불투명 배경 + 어둡게 처리만 한다.
 */
object Blur {

    /** 기기가 창 뒤 블러를 쓸 수 있는지 (설정에서 꺼져 있거나 절전 모드면 false) */
    fun supported(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        return try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled
        } catch (e: Throwable) {
            false
        }
    }

    private fun px(ctx: Context, dp: Int) = (dp * ctx.resources.displayMetrics.density).toInt()

    /** 다이얼로그/바텀시트 창 뒤(웹 페이지)를 흐리게 한다. 적용됐으면 true */
    fun behind(window: Window?, ctx: Context, radiusDp: Int = 18, dim: Float = 0.12f): Boolean {
        if (window == null || !supported(ctx)) return false
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND or WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                window.setDimAmount(dim)
                window.attributes = window.attributes.apply { blurBehindRadius = px(ctx, radiusDp) }
                true
            } else false
        } catch (e: Throwable) {
            false
        }
    }

    /** 뷰 자체(앱 안의 화면)를 흐리게 한다. radiusPx 가 0 에 가까우면 효과를 끈다. */
    @RequiresApi(Build.VERSION_CODES.S)
    fun blurView(v: View, radiusPx: Float) {
        try {
            v.setRenderEffect(
                if (radiusPx < 0.5f) null
                else RenderEffect.createBlurEffect(radiusPx, radiusPx, Shader.TileMode.CLAMP)
            )
        } catch (e: Throwable) {
            // 블러를 못 쓰면 그냥 넘어간다
        }
    }

    fun dp(ctx: Context, dp: Int) = px(ctx, dp)

    /**
     * 이미 떠 있는 팝업 안의 아무 뷰로 그 팝업 창 뒤를 흐리게 한다 (자동완성 드롭다운처럼 창 객체를 못 얻는 경우).
     * 이미 적용돼 있으면 건너뛴다.
     */
    fun behindRootOf(v: View, ctx: Context, radiusDp: Int = 10) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !supported(ctx)) return
        try {
            val root = v.rootView
            val lp = root.layoutParams as? WindowManager.LayoutParams ?: return
            if (lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND != 0) return
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = px(ctx, radiusDp)
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(root, lp)
        } catch (e: Throwable) {
            // 블러를 못 쓰면 그냥 넘어간다
        }
    }

    /** 드롭다운 팝업(PopupWindow, 보이고 난 뒤에 부른다) 뒤를 흐리게 한다 */
    fun behindPopup(pw: PopupWindow, ctx: Context, radiusDp: Int = 10) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !supported(ctx)) return
        try {
            val root = pw.contentView.rootView
            val lp = root.layoutParams as? WindowManager.LayoutParams ?: return
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = px(ctx, radiusDp)
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(root, lp)
        } catch (e: Throwable) {
            // 블러를 못 쓰면 그냥 넘어간다
        }
    }

    /** 테마 표면색. 블러가 켜져 있으면 뒤가 비치도록 반투명 */
    fun surface(ctx: Context, attr: Int, glass: Boolean, alpha: Int = 0xD6): Int {
        val c = MaterialColors.getColor(ctx, attr, 0xFFFFFFFF.toInt())
        return if (glass) ColorUtils.setAlphaComponent(c, alpha) else c
    }

    /** 반투명 유리 카드 배경 (모서리 반경: 왼위, 오른위, 오른아래, 왼아래 순서로 같은 값) */
    fun glass(ctx: Context, attr: Int, radiusPx: Float, topOnly: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            setColor(surface(ctx, attr, true))
            if (topOnly) cornerRadii = floatArrayOf(radiusPx, radiusPx, radiusPx, radiusPx, 0f, 0f, 0f, 0f)
            else cornerRadius = radiusPx
            // 얇은 테두리로 유리 가장자리 느낌
            setStroke(1, ColorUtils.setAlphaComponent(MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOutlineVariant, 0x33888888), 0x80))
        }
}
