package com.example.evergreen

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * 'AI로 만들기': 한 줄 설명으로 확장 프로그램(MV3)을 만든다.
 *
 * 흐름: ① 생성(4 Hydrogen, 안 되면 앱의 다른 모델로 대신) → ② 검증(구조 · 파일 · 쓰면 안 되는 API · 숨은 웹뷰 문법 검사)
 * → 실패하면 오류를 모델에게 돌려줘 최대 [MAX_FIX]번 고친다 → ③ 미리보기 카드용 [Draft] 를 돌려준다.
 * 설치는 여기서 하지 않는다. 사용자가 카드에서 '적용'을 눌러야 [ExtensionManager.installDraft] 가 설치한다.
 *
 * 적용 범위(어느 사이트에 쓰는지)는 모델이 정하지 않는다. 사용자가 고른 [Scope] 를 매니페스트에 앱이 직접 써 넣는다.
 */
object ExtensionForge {

    const val MAX_FIX = 2
    private const val MAX_FILES = 8
    private const val MAX_FILE_CHARS = 60_000

    enum class ScopeKind { THIS_SITE, ALL, CUSTOM }

    /** 사용자가 고른 적용 범위. [patterns] 는 매니페스트의 match pattern 이다 */
    class Scope(val kind: ScopeKind, val patterns: List<String>) {
        val isAll: Boolean get() = kind == ScopeKind.ALL
    }

    class Draft(
        val name: String,
        val description: String,
        val manifest: JSONObject,
        val files: Map<String, String>,
        val scope: Scope,
        /** 쓰는 기능 칩: "콘텐츠 스크립트" · "백그라운드" · "저장소" … */
        val features: List<String>,
        /** 검사에서 끝내 못 고친 문제 / 주의할 점. 비어 있으면 검사 통과 */
        val problems: List<String>,
        val request: String
    ) {
        val passed: Boolean get() = problems.isEmpty()

        /** 모델이 적어 준 "이 코드가 하는 일" 한국어 줄들 (미리보기 카드의 코드 요약) */
        var summary: List<String> = emptyList()

        /** 지금까지 만든 판의 기록 [{rev, date, request, files, ok}] — 확장 폴더의 evergreen_ai_history.json 로 저장된다 */
        var revs: JSONArray = JSONArray()

        /** 고치기 직전 판의 소스 {rev, files} (되돌릴 때를 위해 한 판만 남긴다) */
        var prevSource: JSONObject? = null

        fun carryFrom(o: Draft): Draft { summary = o.summary; revs = o.revs; prevSource = o.prevSource; return this }
    }

    const val HISTORY_FILE = "evergreen_ai_history.json"

    class ForgeException(msg: String) : Exception(msg)

    /** 쓸 수 있는 chrome.* 이름공간 (앱의 ext_shim.js 가 실제로 구현한 것 가운데 AI 확장에 맞는 것만) */
    private val ALLOWED_NS = listOf(
        "runtime", "storage", "tabs", "scripting", "alarms", "i18n", "contextMenus", "menus",
        "action", "commands", "notifications", "webNavigation", "declarativeNetRequest"
    )

    /** 일부러 막는 이름공간: 사용자 데이터를 읽거나 앱이 구현하지 않은 것 */
    private val BLOCKED_NS = listOf(
        "cookies", "history", "bookmarks", "downloads", "management", "proxy", "privacy", "webRequest",
        "debugger", "tabCapture", "desktopCapture", "vpnProvider", "devtools", "printerProvider", "wallpaper",
        "identity", "pageCapture", "browsingData", "sessions", "topSites", "system", "tts", "userScripts"
    )

    private val ALLOWED_PERMS = setOf(
        "storage", "activeTab", "scripting", "alarms", "contextMenus", "notifications", "tabs",
        "webNavigation", "declarativeNetRequest", "declarativeNetRequestWithHostAccess", "unlimitedStorage"
    )

    // ───────────────────────── 만들기 ─────────────────────────

    /**
     * 확장 프로그램을 만든다. 인터넷을 쓰므로 화면 스레드가 아닌 곳에서만 부른다.
     * @param onStep 진행 단계 알림 ("write" · "check" · "fix:1" …). 부르는 스레드가 화면 스레드가 아닐 수 있다
     * @param previous 다시 만들기: 앞에서 만든 초안 (그것을 바탕으로 고친다)
     */
    fun generate(
        act: Activity,
        request: String,
        scope: Scope,
        pageUrl: String?,
        onStep: (String) -> Unit,
        previous: Draft? = null,
        feedback: String? = null
    ): Draft {
        if (Looper.myLooper() == Looper.getMainLooper()) throw ForgeException("화면 스레드에서는 쓸 수 없어요")
        val prefs = Prefs(act)
        val key = prefs.geminiKey
        if (key.isBlank()) throw ForgeException("설정에서 Gemini API 키를 먼저 저장해 주세요")
        val req = request.trim()
        if (req.isEmpty()) throw ForgeException("어떤 확장 프로그램을 만들지 적어 주세요")
        if (req.length > 2_000) throw ForgeException("설명이 너무 길어요 (2000자 이하)")

        val system = systemPrompt(scope)
        val history = ArrayList<ChatMsg>()
        history.add(ChatMsg("user", userPrompt(req, scope, pageUrl, previous, feedback)))

        var lastDraft: Draft? = null
        var lastProblems: List<String> = emptyList()
        var attempt = 0
        while (true) {
            onStep(if (attempt == 0) "write" else "fix:$attempt")
            val raw = callModel(key, system, history)
            history.add(ChatMsg("model", raw))
            onStep("check")
            val parsed = try { parse(raw, req, scope, previous?.name) } catch (e: ForgeException) { null to listOf(e.message ?: "형식이 맞지 않아요") }
            val draft = parsed.first
            val problems = ArrayList<String>(parsed.second)
            if (draft != null && previous != null) {
                stamp(draft.manifest, previous, feedback)
                draft.revs = previous.revs
                draft.prevSource = JSONObject().put("rev", previous.manifest.optString("version").substringBefore('.').toIntOrNull() ?: 1)
                    .put("files", JSONObject(previous.files))
            }
            if (draft != null) problems.addAll(validate(act, draft, onStep))
            if (draft != null) lastDraft = draft
            lastProblems = problems
            if (problems.isEmpty() && draft != null) return draft
            if (attempt >= MAX_FIX) break
            attempt++
            history.add(
                ChatMsg(
                    "user",
                    "방금 만든 확장 프로그램을 검사했더니 아래 문제가 있어요. 문제를 모두 고친 전체 결과를 같은 JSON 형식으로 다시 보내 주세요.\n" +
                        problems.joinToString("\n") { "- $it" }
                )
            )
        }
        val d = lastDraft ?: throw ForgeException("확장 프로그램을 만들지 못했어요: " + (lastProblems.firstOrNull() ?: "알 수 없는 오류"))
        return Draft(d.name, d.description, d.manifest, d.files, d.scope, d.features, lastProblems, d.request).carryFrom(d)
    }

    private fun callModel(key: String, system: String, history: List<ChatMsg>): String {
        val sb = StringBuilder()
        var err: String? = null
        try {
            GeminiClient().stream(
                key, GeminiModels.HYDROGEN.id, system, history,
                onDelta = { sb.append(it) }, onDone = { }, onError = { err = it },
                json = true, thinking = GeminiThinking.LOW
            )
        } catch (e: Exception) {
            err = e.message ?: "AI 요청에 실패했어요"
        }
        err?.let { throw ForgeException(it) }
        val out = sb.toString().trim()
        if (out.isEmpty()) throw ForgeException("AI가 빈 답을 보냈어요")
        return out
    }

    // ───────────────────────── 프롬프트 ─────────────────────────

    private fun systemPrompt(scope: Scope): String = buildString {
        append("당신은 안드로이드 브라우저 앱 'evergreen'의 확장 프로그램 제작자입니다. 사용자의 한 줄 설명을 Chrome 확장 프로그램(Manifest V3)으로 만듭니다.\n")
        append("반드시 아래 JSON 한 개만 출력하세요. 설명 글 · 마크다운 · 코드 울타리(```)는 쓰지 마세요.\n")
        append("{\"name\":\"짧은 한국어 이름\",\"description\":\"한 문장 설명(한국어)\",\"summary\":[\"이 코드가 하는 일을 한국어 한 줄씩, 2~4개\"],\"manifest\":{…manifest.json 내용…},\"files\":{\"경로\":\"파일 내용\", …}}\n\n")
        append("[규칙]\n")
        append("- manifest_version 은 3, version 은 \"1.0\". manifest 에 적은 모든 파일(js · css · html)은 files 에 있어야 합니다. 파일은 ")
        append(MAX_FILES).append("개 이하, 파일당 ").append(MAX_FILE_CHARS / 1000).append("천 자 이하입니다.\n")
        append("- 대부분은 콘텐츠 스크립트(content_scripts 의 js · css)만으로 충분합니다. 백그라운드(service_worker)·팝업·알람은 꼭 필요할 때만 쓰세요.\n")
        append("- 적용 범위는 앱이 정합니다. content_scripts 의 matches 에는 [\"")
        append(scope.patterns.joinToString("\",\"")).append("\"] 를 그대로 쓰고, host_permissions 는 쓰지 마세요(앱이 넣습니다).\n")
        append("- 쓸 수 있는 API: ").append(ALLOWED_NS.joinToString(" · ") { "chrome.$it" }).append(". 이 앱의 웹뷰는 크롬과 완전히 같지 않으므로 이 목록 밖의 API 는 쓰지 마세요.\n")
        append("- 쓰면 안 되는 API: ").append(BLOCKED_NS.joinToString(" · ")).append(" 과 chrome.webRequest(차단·수정). 요청을 막아야 하면 declarativeNetRequest 를 쓰세요.\n")
        append("- permissions 는 ").append(ALLOWED_PERMS.joinToString(" · ")).append(" 중에서 필요한 것만 쓰세요.\n")
        append("- 금지: eval · new Function · 문자열을 받는 setTimeout · 원격 코드 불러오기(외부 <script src> · importScripts(http…)) · 외부 서버로 데이터 보내기 · document.cookie 읽기 · 비밀번호/카드 입력칸 읽기.\n")
        append("- 페이지 글자를 바꿀 때는 사이트 디자인을 깨지 않게 !important 는 꼭 필요한 곳에만 쓰고, 동적으로 늘어나는 페이지는 MutationObserver 로 따라가되 성능을 해치지 마세요.\n")
        append("- 코드는 짧고 읽기 쉽게 쓰고, 주석은 한국어로 한 줄씩만 다세요. 사용자가 켜고 끌 수 있어야 하는 기능이면 chrome.storage.local 에 설정을 저장하세요.\n")
        if (scope.isAll) append("- 이 확장은 모든 사이트에 적용됩니다. 로그인 · 결제 화면의 입력칸은 건드리지 마세요.\n")
    }

    private fun userPrompt(req: String, scope: Scope, pageUrl: String?, prev: Draft?, feedback: String?): String = buildString {
        append("만들 것: ").append(req).append("\n")
        append("적용 범위: ").append(scope.patterns.joinToString(", ")).append("\n")
        if (!pageUrl.isNullOrBlank()) append("사용자가 지금 보는 페이지: ").append(pageUrl.take(200)).append("\n")
        if (prev != null) {
            append("\n앞에서 만든 결과를 바탕으로 다시 만들어 주세요.")
            if (!feedback.isNullOrBlank()) append(" 바꿀 점: ").append(feedback.take(500))
            append("\n앞의 결과:\n").append(JSONObject().put("name", prev.name).put("description", prev.description)
                .put("manifest", prev.manifest).put("files", JSONObject(prev.files)).toString().take(30_000))
        }
    }

    // ───────────────────────── 읽기 ─────────────────────────

    /** 모델의 답을 읽어 [Draft] 로 만든다. 읽을 수 없으면 (null, 문제 목록) */
    private fun parse(raw: String, req: String, scope: Scope, forceName: String? = null): Pair<Draft?, List<String>> {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = try { JSONObject(s) } catch (e: Exception) {
            val a = s.indexOf('{'); val b = s.lastIndexOf('}')
            if (a < 0 || b <= a) return null to listOf("JSON 형식이 아니에요")
            try { JSONObject(s.substring(a, b + 1)) } catch (e2: Exception) { return null to listOf("JSON 을 읽을 수 없어요: ${e2.message}") }
        }
        val problems = ArrayList<String>()
        val mj = o.optJSONObject("manifest") ?: return null to listOf("manifest 가 없어요")
        val filesObj = o.optJSONObject("files") ?: JSONObject()
        val files = LinkedHashMap<String, String>()
        val keys = filesObj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val path = k.replace('\\', '/').removePrefix("/")
            if (path.isEmpty() || path.contains("..") || path == "manifest.json") { problems.add("파일 경로가 올바르지 않아요: $k"); continue }
            val v = filesObj.optString(k)
            if (v.length > MAX_FILE_CHARS) problems.add("$path 가 너무 길어요 (${MAX_FILE_CHARS / 1000}천 자 이하)")
            files[path] = v
        }
        if (files.size > MAX_FILES) problems.add("파일이 너무 많아요 (${MAX_FILES}개 이하)")
        val name = forceName ?: o.optString("name").ifBlank { mj.optString("name") }.trim().take(40)
        if (name.isBlank()) problems.add("name 이 비었어요")
        val desc = o.optString("description").ifBlank { mj.optString("description") }.trim().take(200)

        normalizeManifest(mj, name.ifBlank { "AI 확장" }, desc, scope, req)
        val dr = Draft(name.ifBlank { "AI 확장" }, desc, mj, files, scope, features(mj), emptyList(), req)
        o.optJSONArray("summary")?.let { a -> dr.summary = (0 until a.length()).map { a.optString(it).trim().take(80) }.filter { it.isNotEmpty() }.take(4) }
        return dr to problems
    }

    /** 모델이 쓴 매니페스트를 앱의 규칙에 맞게 고친다: 범위는 사용자가 고른 것으로, 위험한 키는 지운다 */
    private fun normalizeManifest(mj: JSONObject, name: String, desc: String, scope: Scope, req: String) {
        mj.put("manifest_version", 3)
        mj.put("name", name)
        mj.put("version", "1.0")
        if (desc.isNotBlank()) mj.put("description", desc)
        listOf("key", "update_url", "externally_connectable", "content_security_policy", "oauth2", "chrome_url_overrides", "devtools_page", "omnibox").forEach { mj.remove(it) }

        // 권한: 허용 목록에 없는 것은 뺀다
        val perms = JSONArray()
        val pa = mj.optJSONArray("permissions")
        if (pa != null) for (i in 0 until pa.length()) {
            val p = pa.optString(i)
            if (p in ALLOWED_PERMS) perms.put(p)
        }
        mj.put("permissions", perms)
        mj.remove("optional_permissions")
        mj.remove("optional_host_permissions")

        // 적용 범위: 콘텐츠 스크립트의 matches 와 host_permissions 를 사용자가 고른 것으로 덮어쓴다
        val pats = JSONArray().also { a -> scope.patterns.forEach { a.put(it) } }
        val cs = mj.optJSONArray("content_scripts")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.optJSONObject(i) ?: continue
            c.put("matches", JSONArray(pats.toString()))
            c.remove("exclude_matches")
            c.remove("include_globs")
            c.remove("exclude_globs")
        }
        val needsHosts = mj.has("background") || (mj.optJSONArray("permissions")?.let { a -> (0 until a.length()).any { a.optString(it) == "scripting" || a.optString(it) == "declarativeNetRequestWithHostAccess" } } ?: false)
        mj.remove("host_permissions")
        if (needsHosts) mj.put("host_permissions", JSONArray(pats.toString()))
        mj.remove("web_accessible_resources")
        // 이 확장이 AI 로 만들어졌다는 표시 (카드에 'AI 제작' 으로 보인다)
        mj.put("evergreen_ai", JSONObject().put("request", req.take(300)).put("requests", JSONArray().put(req.take(300))).put("created", System.currentTimeMillis()))
    }

    internal fun features(mj: JSONObject): List<String> {
        val f = ArrayList<String>()
        if ((mj.optJSONArray("content_scripts")?.length() ?: 0) > 0) f.add("콘텐츠 스크립트")
        if (mj.has("background")) f.add("백그라운드")
        if (mj.has("action") && mj.optJSONObject("action")?.optString("default_popup").orEmpty().isNotEmpty()) f.add("팝업")
        val perms = mj.optJSONArray("permissions")
        val ps = (0 until (perms?.length() ?: 0)).map { perms!!.optString(it) }
        if ("storage" in ps || "unlimitedStorage" in ps) f.add("저장소")
        if ("alarms" in ps) f.add("알람")
        if ("notifications" in ps) f.add("알림")
        if ("contextMenus" in ps) f.add("길게 누르기 메뉴")
        if ("declarativeNetRequest" in ps || "declarativeNetRequestWithHostAccess" in ps) f.add("요청 차단")
        if ("tabs" in ps) f.add("탭 정보")
        return f
    }

    /** 고치기: 버전을 올리고(1.0 → 2.0) 지금까지의 요청 기록에 이번 요청을 더한다 */
    private fun stamp(mj: JSONObject, prev: Draft, change: String?) {
        val rev = (prev.manifest.optString("version").substringBefore('.').toIntOrNull() ?: 1) + 1
        mj.put("version", "$rev.0")
        val reqs = JSONArray()
        val old = prev.manifest.optJSONObject("evergreen_ai")?.optJSONArray("requests")
        if (old != null) for (i in 0 until old.length()) reqs.put(old.optString(i)) else reqs.put(prev.request)
        if (!change.isNullOrBlank()) reqs.put(change.substringBefore("\n\n[").trim().take(300))
        val ai = mj.optJSONObject("evergreen_ai") ?: JSONObject().also { mj.put("evergreen_ai", it) }
        ai.put("requests", reqs)
        prev.manifest.optJSONObject("evergreen_ai")?.optLong("created")?.takeIf { it > 0 }?.let { ai.put("created", it) }
    }

    // ───────────────────────── 검증 ─────────────────────────

    private val EVAL = Regex("""(?<![\w.$])eval\s*\(|new\s+Function\s*\(|setTimeout\s*\(\s*["'`]|setInterval\s*\(\s*["'`]""")
    private val REMOTE_CODE = Regex("""importScripts\s*\(\s*["'`]https?:|<script[^>]+src\s*=\s*["']?https?:""", RegexOption.IGNORE_CASE)
    private val EXTERNAL_NET = Regex("""(fetch|XMLHttpRequest|sendBeacon|WebSocket|EventSource)\b[^;\n]{0,120}https?://""")
    private val COOKIE = Regex("""document\.cookie""")
    private val NS_USE = Regex("""\b(?:chrome|browser)\s*\.\s*([A-Za-z]+)""")

    /** 설치 전 검사. 고쳐야 하는 문제 목록 (비어 있으면 통과) */
    private fun validate(act: Activity, d: Draft, onStep: (String) -> Unit): List<String> {
        val out = ArrayList<String>()
        val mj = d.manifest

        // 매니페스트가 가리키는 파일이 모두 있는지
        fun need(path: String?, where: String) {
            val p = path?.trim().orEmpty().removePrefix("/")
            if (p.isEmpty()) return
            if (!d.files.containsKey(p)) out.add("$where 에 적은 파일 '$p' 이(가) files 에 없어요")
        }
        val cs = mj.optJSONArray("content_scripts")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.optJSONObject(i) ?: continue
            for (k in listOf("js", "css")) c.optJSONArray(k)?.let { a -> for (j in 0 until a.length()) need(a.optString(j), "content_scripts.$k") }
            if ((c.optJSONArray("js")?.length() ?: 0) == 0 && (c.optJSONArray("css")?.length() ?: 0) == 0) out.add("content_scripts 에 js 나 css 가 없어요")
        }
        mj.optJSONObject("background")?.let { b ->
            need(b.optString("service_worker"), "background.service_worker")
            if (b.optString("service_worker").isBlank()) out.add("background 에는 service_worker 를 적어야 해요")
        }
        mj.optJSONObject("action")?.let { a -> need(a.optString("default_popup"), "action.default_popup") }
        need(mj.optString("options_page"), "options_page")
        mj.optJSONObject("options_ui")?.let { need(it.optString("page"), "options_ui.page") }
        if ((cs?.length() ?: 0) == 0 && !mj.has("background") && !(mj.optJSONObject("action")?.has("default_popup") ?: false))
            out.add("실행되는 코드가 없어요 (content_scripts · background · action 중 하나는 있어야 해요)")
        if (cs != null && cs.length() > 0 && d.scope.patterns.isEmpty()) out.add("적용할 사이트가 비어 있어요")

        // 코드 검사
        val syntaxJobs = ArrayList<Pair<String, String>>()
        for ((path, text) in d.files) {
            val lower = path.lowercase()
            if (lower.endsWith(".js") || lower.endsWith(".mjs") || lower.endsWith(".html")) {
                if (EVAL.containsMatchIn(text)) out.add("$path: eval · new Function · 문자열 setTimeout 은 쓸 수 없어요")
                if (REMOTE_CODE.containsMatchIn(text)) out.add("$path: 원격 코드를 불러올 수 없어요 (모든 코드는 파일에 넣어 주세요)")
                if (EXTERNAL_NET.containsMatchIn(text)) out.add("$path: 외부 주소로 요청을 보낼 수 없어요")
                if (COOKIE.containsMatchIn(text)) out.add("$path: document.cookie 는 읽을 수 없어요")
                NS_USE.findAll(text).map { it.groupValues[1] }.toSet().forEach { ns ->
                    if (ns in BLOCKED_NS) out.add("$path: chrome.$ns 는 이 앱에서 쓸 수 없어요" + if (ns == "webRequest") " (declarativeNetRequest 를 쓰세요)" else "")
                }
            }
            if ((lower.endsWith(".js") || lower.endsWith(".mjs")) && text.isNotBlank()) syntaxJobs.add(path to text)
        }
        // 문법 검사: 숨은 웹뷰에서 new Function() 으로 읽어 본다 (실행은 하지 않는다)
        val isModuleBg = mj.optJSONObject("background")?.optString("type") == "module"
        for ((path, text) in syntaxJobs) {
            val err = SyntaxCheck.run(act, text, module = isModuleBg && path == mj.optJSONObject("background")?.optString("service_worker"))
            if (err != null) out.add("$path: 문법 오류 — $err")
        }
        // 시험 실행: 정적 검사를 통과했을 때만 숨은 웹뷰에서 한 번 돌려 시작 오류를 잡는다
        if (out.isEmpty()) {
            onStep("run")
            val bg = mj.optJSONObject("background")?.optString("service_worker")?.removePrefix("/")?.takeIf { it.isNotBlank() && d.files.containsKey(it) }
            val cs2 = ArrayList<String>()
            if (cs != null) for (i in 0 until cs.length()) cs.optJSONObject(i)?.optJSONArray("js")?.let { a ->
                for (j in 0 until a.length()) a.optString(j).removePrefix("/").let { if (d.files.containsKey(it)) cs2.add(it) }
            }
            out.addAll(DryRun.run(act, d.files, bg, cs2.distinct(), isModuleBg))
        }
        return out
    }

    // ───────────────────────── 설치용 zip ─────────────────────────

    /** 초안을 .zip 바이트로 묶는다 ([ExtensionManager.installDraft] 가 이것을 풀어 설치한다) */
    fun toZip(d: Draft): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            z.putNextEntry(ZipEntry("manifest.json"))
            z.write(d.manifest.toString(2).toByteArray(Charsets.UTF_8))
            z.closeEntry()
            for ((p, t) in d.files) {
                z.putNextEntry(ZipEntry(p))
                z.write(t.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            z.putNextEntry(ZipEntry(HISTORY_FILE))
            z.write(historyOf(d).toString(1).toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
        return bos.toByteArray()
    }

    /** 확장 폴더에 남기는 기록: 요청 · 판별 파일 목록, 그리고 고치기 직전 판의 소스 */
    private fun historyOf(d: Draft): JSONObject {
        val revs = JSONArray()
        for (i in maxOf(0, d.revs.length() - 19) until d.revs.length()) revs.put(d.revs.optJSONObject(i))
        val reqs = d.manifest.optJSONObject("evergreen_ai")?.optJSONArray("requests")
        revs.put(
            JSONObject()
                .put("rev", d.manifest.optString("version").substringBefore('.').toIntOrNull() ?: 1)
                .put("date", System.currentTimeMillis())
                .put("request", reqs?.optString((reqs.length() - 1).coerceAtLeast(0)) ?: d.request)
                .put("files", JSONArray(d.files.keys.toList()))
                .put("ok", d.passed)
        )
        val o = JSONObject().put("revs", revs)
        d.prevSource?.let { o.put("prev", it) }
        return o
    }

    // ───────────────────────── 적용 범위 만들기 ─────────────────────────

    /** 주소(또는 호스트)에서 match pattern 들을 만든다. 예: playentry.org 는 정확한 주소와 하위 주소 두 패턴(스킴 · 호스트 · 경로 전체)이 된다 */
    fun siteScope(url: String?): Scope? {
        val host = try { android.net.Uri.parse(url ?: "").host } catch (e: Exception) { null }
        if (host.isNullOrBlank() || !host.contains('.') && host != "localhost") return null
        val base = host.removePrefix("www.")
        return Scope(ScopeKind.THIS_SITE, listOf("*://$base/*", "*://*.$base/*"))
    }

    fun allSitesScope() = Scope(ScopeKind.ALL, listOf("<all_urls>"))

    /** 직접 입력: 줄바꿈 · 쉼표로 나눈 주소들. 하나도 못 읽으면 null */
    fun customScope(text: String): Scope? {
        val out = ArrayList<String>()
        for (raw in text.split('\n', ',', ' ', ';')) {
            val s = raw.trim()
            if (s.isEmpty()) continue
            if (s == "<all_urls>" || s == "*" || s == "*://*/*") return allSitesScope()
            if (Regex("""^(\*|https?|file)://[^/]+/.*$""").matches(s)) { out.add(s); continue }
            val host = s.removePrefix("https://").removePrefix("http://").substringBefore('/').removePrefix("www.").trim()
            if (host.isEmpty() || !Regex("""^[A-Za-z0-9.*-]+$""").matches(host) || !host.contains('.')) continue
            out.add("*://$host/*")
            if (!host.startsWith("*.")) out.add("*://*.$host/*")
        }
        return if (out.isEmpty()) null else Scope(ScopeKind.CUSTOM, out.distinct())
    }

    // ───────────────────────── 숨은 웹뷰 문법 검사 ─────────────────────────

    /** 자바스크립트 문법만 확인한다 (코드는 실행하지 않는다). 화면 스레드가 아닌 곳에서 부르면 결과를 기다린다 */
    private object SyntaxCheck {
        private val ui = Handler(Looper.getMainLooper())

        /** 웹뷰의 검사 결과를 받는 다리 (익명 객체는 reflection 접근이 막힐 수 있어 이름 있는 클래스로 둔다) */
        class Bridge(private val onDone: (String) -> Unit) {
            @JavascriptInterface
            fun done(r: String) { onDone(r) }
        }

        fun run(act: Activity, code: String, module: Boolean): String? {
            if (act.isFinishing || act.isDestroyed) return null
            val latch = CountDownLatch(1)
            val box = arrayOfNulls<String>(1)
            var wv: WebView? = null
            ui.post {
                try {
                    val w = WebView(act.applicationContext)
                    wv = w
                    w.settings.javaScriptEnabled = true
                    w.settings.allowFileAccess = false
                    w.settings.allowContentAccess = false
                    w.addJavascriptInterface(Bridge { r -> box[0] = r; latch.countDown() }, "EvSyn")
                    w.loadDataWithBaseURL(
                        "https://ext.evergreen.invalid/",
                        "<html><body><script>" +
                            "var src=" + JSONObject.quote(code) + ";var mod=" + module + ";" +
                            "try{ if(mod){ new Function(src.replace(/^\\s*(import|export)\\b[^;\\n]*;?/gm,'')); } else { new Function(src); } EvSyn.done('ok'); }" +
                            "catch(e){ EvSyn.done('err:'+(e&&e.message?e.message:e)); }" +
                            "</script></body></html>",
                        "text/html", "utf-8", null
                    )
                } catch (e: Exception) {
                    box[0] = "ok"; latch.countDown()   // 검사 도구가 못 돌면 막지 않는다
                }
            }
            val done = latch.await(8, TimeUnit.SECONDS)
            ui.post { try { wv?.destroy() } catch (e: Exception) { } }
            val r = box[0]
            if (!done || r == null || r == "ok") return null
            return r.removePrefix("err:").take(160)
        }
    }

    // ───────────────────────── 시험 실행 (숨은 웹뷰) ─────────────────────────

    /**
     * 만든 코드를 숨은 웹뷰에서 한 번 돌려 시작 오류를 잡는다. chrome.* 은 무엇을 불러도 조용히 받아 주는 가짜(Proxy)라서
     * 이 검사는 "코드 자체의 오류"(정의 안 된 변수 · null 을 읽는 실수 등)만 잡는다. 실제 chrome.* 호환은 앱의 shim 이 맡는다.
     * 백그라운드는 모든 오류를, 콘텐츠 스크립트는 빈 페이지에서 돌리므로 ReferenceError · SyntaxError 만 문제로 본다.
     */
    private object DryRun {
        private val ui = Handler(Looper.getMainLooper())

        class Bridge(private val onDone: (String) -> Unit) {
            @JavascriptInterface
            fun report(json: String) { onDone(json) }
        }

        private const val PRELUDE = """
var __errs=[];
function __mk(p){var f=function(){var a=arguments,cb=a[a.length-1];if(typeof cb==='function'){setTimeout(function(){try{cb()}catch(e){}},0)}return Promise.resolve(undefined)};
 return new Proxy(f,{get:function(t,k){if(k==='then'||typeof k==='symbol')return undefined;
  if(k==='addListener'||k==='removeListener'||k==='hasListener')return function(){};return __mk(p.concat(k))}})}
var __C=__mk([]);
window.chrome=__C;window.browser=__C;window.importScripts=function(){};
function __run(path,code,bg){try{new Function('chrome','browser',code)(__C,__C)}catch(e){__push(path,e,bg)}}
function __push(path,e,bg){var n=(e&&e.name)||'Error';if(!bg&&n!=='ReferenceError'&&n!=='SyntaxError')return;__errs.push(path+': '+n+' — '+((e&&e.message)||e))}
window.addEventListener('error',function(ev){__push('실행 중',ev.error||{name:'Error',message:ev.message},__BG)});
window.addEventListener('unhandledrejection',function(ev){__push('비동기',ev.reason||{name:'Error',message:'거부된 약속'},__BG)});
"""

        fun run(act: Activity, files: Map<String, String>, bg: String?, content: List<String>, module: Boolean): List<String> {
            if (act.isFinishing || act.isDestroyed) return emptyList()
            if (bg == null && content.isEmpty()) return emptyList()
            val latch = CountDownLatch(1)
            val box = arrayOfNulls<String>(1)
            var wv: WebView? = null
            ui.post {
                try {
                    val w = WebView(act.applicationContext)
                    wv = w
                    w.settings.javaScriptEnabled = true
                    w.settings.allowFileAccess = false
                    w.settings.allowContentAccess = false
                    w.addJavascriptInterface(Bridge { r -> box[0] = r; latch.countDown() }, "EvDry")
                    val sb = StringBuilder()
                    sb.append("<html><body><div id=\"app\"></div><script>var __BG=false;").append(PRELUDE).append("</script><script>")
                    // 백그라운드 → 콘텐츠 스크립트 순서. 모듈 백그라운드는 import/export 줄을 뺀다
                    fun add(path: String, isBg: Boolean) {
                        var code = files[path] ?: return
                        if (isBg && module) code = code.replace(Regex("(?m)^\\s*(import|export)\\b[^;\\n]*;?"), "")
                        sb.append("__BG=").append(isBg).append(";__run(").append(JSONObject.quote(path)).append(",").append(JSONObject.quote(code)).append(",").append(isBg).append(");\n")
                    }
                    if (bg != null) add(bg, true)
                    content.forEach { add(it, false) }
                    sb.append("setTimeout(function(){EvDry.report(JSON.stringify(__errs))},1500);</script></body></html>")
                    w.loadDataWithBaseURL("https://ext.evergreen.invalid/", sb.toString(), "text/html", "utf-8", null)
                } catch (e: Exception) {
                    box[0] = "[]"; latch.countDown()   // 시험 도구가 못 돌면 막지 않는다
                }
            }
            val done = latch.await(8, TimeUnit.SECONDS)
            ui.post { try { wv?.destroy() } catch (e: Exception) { } }
            val r = box[0]
            if (!done || r == null) return emptyList()
            return try {
                val a = JSONArray(r)
                (0 until a.length()).map { a.optString(it) }.distinct().take(4).map { (if (it.startsWith("실행 중") || it.startsWith("비동기")) "시작 오류 — " else "시작 오류: ") + it }
            } catch (e: Exception) { emptyList() }
        }
    }
}
