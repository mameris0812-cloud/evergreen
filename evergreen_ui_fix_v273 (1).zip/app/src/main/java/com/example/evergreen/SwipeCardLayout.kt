package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import androidx.dynamicanimation.animation.DynamicAnimation
import kotlin.math.abs

/**
 * 좌우로 밀어 넘기는 카드 (메뉴 미디어 플레이어가 여러 개일 때).
 * - 손가락을 따라 카드가 움직이고, 충분히 밀거나 빠르게 튕기면 [onSwipe] 로 넘어간다.
 * - 더 갈 곳이 없는 쪽은 저항감 있게 조금만 끌려가다 돌아온다.
 * - [ignoreView](재생 위치 막대) 위에서 시작한 터치는 가로로 끌어도 넘기지 않는다.
 * - 꾹 누르면 [onLongPress] 가 불린다 (안쪽 버튼 위에서 눌러도 된다. 막대 위는 제외).
 */
class SwipeCardLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** dir: 다음(+1, 왼쪽으로 밀기) / 이전(-1). 넘길 수 있는지 */
    var canSwipe: (Int) -> Boolean = { false }
    var onSwipe: (Int) -> Unit = {}
    var ignoreView: View? = null

    /** 꾹 눌렀을 때 (null 이면 꾹 누르기를 보지 않는다) */
    var onLongPress: (() -> Unit)? = null

    /** 손가락을 따라 움직이는 안쪽 내용 (카드 바탕과 페이지 점은 제자리). 없으면 카드 전체 */
    var content: View? = null
    private val mover: View get() = content ?: this

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var ignored = false
    private var dragging = false
    private var tracker: VelocityTracker? = null

    private fun hitIgnored(ev: MotionEvent): Boolean {
        val v = ignoreView ?: return false
        if (v.visibility != VISIBLE) return false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return ev.rawX >= loc[0] && ev.rawX <= loc[0] + v.width &&
            ev.rawY >= loc[1] && ev.rawY <= loc[1] + v.height
    }

    // ── 꾹 누르기 ──
    private var lpFired = false
    private var lpDownTime = 0L
    private var lpX = 0f
    private var lpY = 0f
    private val lpRunnable = Runnable {
        if (dragging) return@Runnable
        lpFired = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        // 안쪽 버튼이 눌린 채로 남지 않게 취소 신호를 한 번 보낸다
        val c = MotionEvent.obtain(lpDownTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_CANCEL, lpX, lpY, 0)
        super@SwipeCardLayout.dispatchTouchEvent(c)
        c.recycle()
        onLongPress?.invoke()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lpFired = false
                removeCallbacks(lpRunnable)
                if (onLongPress != null && !hitIgnored(ev)) {
                    lpDownTime = ev.downTime; lpX = ev.x; lpY = ev.y
                    postDelayed(lpRunnable, ViewConfiguration.getLongPressTimeout().toLong())
                }
            }
            MotionEvent.ACTION_MOVE ->
                if (!lpFired && (abs(ev.x - lpX) > slop || abs(ev.y - lpY) > slop)) removeCallbacks(lpRunnable)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(lpRunnable)
        }
        if (lpFired) {
            // 꾹 누른 뒤 손가락을 뗄 때까지의 터치는 아무 데도 전달하지 않는다
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) lpFired = false
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(lpRunnable)
        super.onDetachedFromWindow()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y
                ignored = hitIgnored(ev)
                dragging = false
                tracker?.recycle(); tracker = VelocityTracker.obtain()
                tracker?.addMovement(ev)
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                if (!ignored && !dragging) {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (abs(dx) > slop && abs(dx) > abs(dy) * 1.2f) {
                        dragging = true
                        parent?.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { tracker?.recycle(); tracker = null }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        tracker?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dx = ev.x - downX
                val dir = if (dx < 0) 1 else -1
                val k = if (canSwipe(dir)) 0.75f else 0.2f
                val m = mover
                m.translationX = dx * k
                m.alpha = 1f - 0.7f * (abs(m.translationX) / (width.coerceAtLeast(1) * 0.6f)).coerceAtMost(1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    tracker?.computeCurrentVelocity(1000)
                    val vx = tracker?.xVelocity ?: 0f
                    val dx = ev.x - downX
                    val dir = if (dx < 0) 1 else -1
                    val far = abs(dx) > width * 0.22f
                    val fast = abs(vx) > 900f && (vx < 0) == (dx < 0)
                    if (ev.actionMasked == MotionEvent.ACTION_UP && (far || fast) && canSwipe(dir)) {
                        onSwipe(dir)
                    } else {
                        springBack()
                    }
                }
                dragging = false
                tracker?.recycle(); tracker = null
            }
        }
        return true
    }

    fun springBack() {
        Motion.spring(mover, DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.8f)
        Motion.spring(mover, DynamicAnimation.ALPHA, 1f, 420f, 1f)
    }
}
