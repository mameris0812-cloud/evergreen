package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewTreeObserver
import android.widget.LinearLayout
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 알약 모양 유리(블러) 막대: 자동 스크롤 조작 막대와 그 '숨김 탭' 이 쓴다.
 * 상/하단바 숨기기 때 뜨는 '더보기' 버튼([BlurFloatButton])과 같은 방식이다:
 * Android 12(API 31) 이상이고 블러가 켜져 있으면 막대 바로 뒤의 웹 페이지 색을 흐리게 깐 유리 모양이 되고,
 * 아니면 블러 없이 반투명 배경만 쓴다. 웹뷰를 다시 그리지 않고 화면에 그려진 픽셀을 복사해 쓴다 (GlassBackdrop 참고).
 *
 * 세로로 끄는 동작도 받는다: [onDrag] / [onDragEnd] 를 정하면, 자식 버튼 위에서 시작한 세로 끌기도 이 막대가 가져와
 * 막대를 따라 움직이게 한다 (버튼을 그냥 누르는 것은 그대로 버튼이 받는다).
 */
class BlurPillLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : LinearLayout(ctx, attrs) {

    /** 웹 페이지가 붙는 영역 (이 안에서만 가져온다) */
    var source: View? = null
        set(v) { field = v; invalidate() }

    /** 세로로 끄는 중: 처음 닿은 곳에서 지금까지 내려온 거리(px, 아래가 +) */
    var onDrag: ((Float) -> Unit)? = null

    /** 끌기가 끝났을 때: 내려온 거리(px)와 손가락을 뗄 때의 세로 속도(px/초, 아래가 +) */
    var onDragEnd: ((Float, Float) -> Unit)? = null

    val blurOn = Blur.active()
    private var glass: Any? = null
    private val clip = Path()
    private val clipRect = RectF()
    private val a = IntArray(2)
    private val pre = ViewTreeObserver.OnPreDrawListener {
        if (source != null && alpha > 0.01f) (glass as? GlassBackdrop)?.refresh()
        true
    }

    // 끌기 상태
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var vt: VelocityTracker? = null

    private companion object {
        /** 막대 둘레로 넓히는 폭 (dp). 막대 아래 여백(8dp 이상)보다 작아야 화면 밖으로 나가지 않는다 */
        const val EDGE_DP = 6f
    }

    /** 막대 사각형을 사방으로 EDGE_DP 만큼 넓힌 곳(막대 바로 뒤 + 둘레)을 가져온다. 가운데(막대 자리)는 GlassBackdrop 이 둘레 색으로 채운다 */
    private fun region(): Rect? {
        if (source == null || width <= 0) return null
        getLocationInWindow(a)
        val e = (EDGE_DP * resources.displayMetrics.density).toInt()
        return Rect(a[0] - e, a[1] - e, a[0] + width + e, a[1] + height + e)
    }

    init {
        // 블러가 켜져 있으면 뒤 페이지를 흐리게 깐 유리 모양(조금 더 투명), 꺼져 있으면 예전처럼 거의 불투명한 면
        val fillAlpha = if (blurOn) 0x8C else 0xF2
        val fill = ColorUtils.setAlphaComponent(
            MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFFEEEEEE.toInt()), fillAlpha
        )
        val edge = ColorUtils.setAlphaComponent(
            MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt()), if (blurOn) 0xA0 else 0x99
        )
        // 반지름을 아주 크게 주면 GradientDrawable 이 짧은 변의 절반으로 줄여 알약 모양이 된다
        val shape = GradientDrawable().apply {
            cornerRadius = 1000f
            setColor(fill)
            setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), edge)
        }
        background = shape
        // 그림자가 둘레 띠에 찍혀 유리가 어둡게 물드는 것을 막는다
        if (blurOn) outlineProvider = null
    }

    // 숨겨졌다가 다시 나타나면 옛 그림 대신 새로 복사해서 서서히 짙어지게 한다
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (changedView === this && visibility != View.VISIBLE) (glass as? GlassBackdrop)?.resetFade()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (blurOn) {
            if (glass == null) glass = GlassBackdrop(this, edgeDp = EDGE_DP) { region() }
            viewTreeObserver.addOnPreDrawListener(pre)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (blurOn) {
            if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(pre)
            (glass as? GlassBackdrop)?.release()
        }
        vt?.recycle(); vt = null
        dragging = false
    }

    // 배경(반투명 유리)보다 먼저 흐린 그림을 그려야 하므로 onDraw 가 아니라 draw 에서 한다
    override fun draw(canvas: Canvas) {
        val g = glass as? GlassBackdrop
        if (blurOn && g != null && source != null && width > 0 && height > 0) {
            val n = canvas.save()
            try {
                clip.reset()
                clipRect.set(0f, 0f, width.toFloat(), height.toFloat())
                val r = minOf(width, height) / 2f
                clip.addRoundRect(clipRect, r, r, Path.Direction.CW)
                canvas.clipPath(clip)
                g.draw(canvas, width, height)
            } catch (e: Throwable) { /* 못 그리면 유리 배경만 */ } finally {
                canvas.restoreToCount(n)
            }
        }
        super.draw(canvas)
    }

    // ───────────────────────── 세로 끌기 ─────────────────────────

    private fun beginTrack(ev: MotionEvent) {
        downX = ev.rawX
        downY = ev.rawY
        dragging = false
        vt?.recycle()
        vt = VelocityTracker.obtain()
        vt?.addMovement(ev)
    }

    private fun endTrack() {
        vt?.recycle()
        vt = null
        dragging = false
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (onDrag == null) return super.onInterceptTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> beginTrack(ev)
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                val dy = ev.rawY - downY
                val dx = ev.rawX - downX
                if (!dragging && Math.abs(dy) > slop && Math.abs(dy) > Math.abs(dx)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTrack()
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val drag = onDrag ?: return super.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (vt == null) beginTrack(ev)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                val dy = ev.rawY - downY
                val dx = ev.rawX - downX
                if (!dragging && Math.abs(dy) > slop && Math.abs(dy) > Math.abs(dx)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) drag(dy)
                return true
            }
            MotionEvent.ACTION_UP -> {
                val was = dragging
                val dy = ev.rawY - downY
                var vy = 0f
                vt?.let { it.addMovement(ev); it.computeCurrentVelocity(1000); vy = it.yVelocity }
                endTrack()
                if (was) onDragEnd?.invoke(dy, vy) else performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                val dy = ev.rawY - downY
                endTrack()
                if (was) onDragEnd?.invoke(dy, 0f)
                return true
            }
        }
        return super.onTouchEvent(ev)
    }
}
