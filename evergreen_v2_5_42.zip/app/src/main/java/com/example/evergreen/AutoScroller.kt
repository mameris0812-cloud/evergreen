package com.example.evergreen

import android.app.Activity
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.MaterialColors

/**
 * 웹 페이지를 저절로 아래로 스크롤해 주는 기능 (웹툰·긴 글을 손 안 대고 볼 때).
 *
 * - 화면 프레임(Choreographer)마다 지난 시간만큼 계산한 거리를 WebView 에 스크롤한다. 속도는 설정의 「자동 스크롤 속도」.
 * - 화면 아래에 작은 조작 막대(느리게 / 속도 / 빠르게 / 정지)를 띄운다 (설정에서 끌 수 있음).
 *   뒤 페이지를 흐리게 깐 유리 모양이고([BlurPillLayout]), 위쪽의 가는 손잡이를 아래로 끌면(막대 어디든 가능)
 *   막대가 아래로 내려가 완전히 숨는다 (숨긴 뒤에는 아무것도 남지 않는다).
 *   다시 보려면 화면 아래 가운데에서 위로 쓸어 올린다.
 * - 웹 화면을 손가락으로 만지면 설정에 따라 '만지는 동안 잠깐 멈춤' 또는 '완전히 멈춤'.
 * - 다른 탭·탭 화면·전체화면·새 페이지 이동·앱 나가기에서는 저절로 멈춘다.
 * - 페이지 끝에 닿은 채로 잠깐(이미지가 더 불러와질 시간) 지나면 멈춘다.
 */
class AutoScroller(
    private val act: Activity,
    private val prefs: Prefs,
    /** 이 WebView 에서 자동 스크롤을 계속해도 되는 상황인지 (현재 탭인지, 탭 화면·전체화면이 아닌지) */
    private val allowed: (WebView) -> Boolean,
    /** 창 아래에서 띄울 높이(px). 아래 막대가 보이면 그 위, 없으면 0 */
    private val liftProvider: () -> Int,
    private val notify: (String) -> Unit
) {
    companion object {
        const val MIN_LEVEL = 1
        const val MAX_LEVEL = 20
        const val DEFAULT_LEVEL = 6

        /** 단계 → 초당 dp. 1단계 = 25dp/초 (아주 천천히), 20단계 = 500dp/초 */
        fun dpPerSecond(level: Int): Float = 25f * level.coerceIn(MIN_LEVEL, MAX_LEVEL)

        /** 손가락을 떼고 이만큼(ms) 지나서 다시 흐른다 (뗀 뒤 이어지는 관성 스크롤이 가라앉을 시간) */
        private const val RESUME_DELAY_MS = 500L

        /** 끝에 닿은 채 이만큼(ms) 지나면 멈춘다 */
        private const val END_HOLD_MS = 1500L

        private const val PILL_TAG = "evergreen_auto_scroll_pill"
    }

    private val density = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private var target: WebView? = null
    private var running = false
    private var touching = false
    private var resumeAt = 0L
    private var lastNanos = 0L
    private var carry = 0f
    private var endSince = 0L
    private var everMoved = false
    private var frames = 0

    private var pill: BlurPillLayout? = null
    private var levelText: TextView? = null
    private var slowerBtn: View? = null
    private var fasterBtn: View? = null
    /** 막대를 내려서 숨긴 상태인지 (새로 시작할 때마다 다시 보이게 돌려 둔다) */
    private var collapsed = false
    /** 숨긴 막대를 다시 불러내는 쓸어올리기를 따라가는 중인지 / 처음 닿은 곳 */
    private var restoreTracking = false
    private var restoreX = 0f
    private var restoreY = 0f
    /** 숨기는 방법·다시 보는 방법 안내는 한 번만 띄운다 */
    private var hintShown = false

    val isRunning: Boolean get() = running

    fun isRunningOn(wv: WebView?): Boolean = running && wv != null && wv === target

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) = onFrame(frameTimeNanos)
    }

    fun start(wv: WebView) {
        if (running && target === wv) return
        stop(null)
        target = wv
        running = true
        touching = false
        resumeAt = 0L
        lastNanos = 0L
        carry = 0f
        endSince = 0L
        everMoved = false
        frames = 0
        collapsed = false
        if (prefs.autoScrollControls) showPill()
        notify("자동 스크롤을 시작했어요")
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    /** 설정에서 조작 막대를 켜거나 껐을 때: 흐르는 중이면 막대만 바로 보이거나 치운다 (스크롤은 그대로) */
    fun applyControlsSetting() {
        if (!running) return
        if (prefs.autoScrollControls) { if (pill == null) showPill() } else removePill()
    }

    /** 멈춘다. [message] 가 있으면 안내를 띄운다 */
    fun stop(message: String?) {
        val was = running
        running = false
        target = null
        touching = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        removePill()
        if (was && message != null) notify(message)
    }

    private fun onFrame(nanos: Long) {
        val wv = target
        if (!running || wv == null) return
        if (act.isFinishing || act.isDestroyed || !wv.isAttachedToWindow || !allowed(wv)) {
            stop(null)
            return
        }
        val dt = if (lastNanos == 0L) 0f else ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNanos = nanos

        val now = SystemClock.uptimeMillis()
        if (!touching && now >= resumeAt) {
            carry += dpPerSecond(prefs.autoScrollSpeed) * density * dt
            val dy = carry.toInt()
            if (dy > 0) {
                carry -= dy
                val before = wv.scrollY
                wv.scrollBy(0, dy)
                if (wv.scrollY != before) {
                    everMoved = true
                    endSince = 0L
                } else {
                    // 더 못 내려간다: 이미지가 더 불러와질 수 있으니 잠깐 기다려 본다
                    if (endSince == 0L) endSince = now
                    else if (now - endSince >= END_HOLD_MS) {
                        stop(if (everMoved) "페이지 끝에 닿아 자동 스크롤을 멈췄어요" else "이 페이지는 자동으로 스크롤할 수 없어요")
                        return
                    }
                }
            }
        }
        // 아래 막대가 나타나고 사라지는 만큼 조작 막대 높이를 맞춘다
        if (++frames % 15 == 0) placePill()
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    /** 액티비티의 dispatchTouchEvent 에서 모든 터치를 넘겨 받는다 (조작 막대 위의 터치는 건드리지 않는다) */
    fun onTouch(ev: MotionEvent) {
        if (!running) return
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                restoreTracking = false
                if (hitPill(ev) || !hitWeb(ev)) return
                if (collapsed && inRestoreZone(ev)) {
                    // 숨긴 막대를 불러내려는 쓸어올리기일 수 있다: 멈추지는 않고 만지는 동안만 잠깐 쉰다
                    restoreTracking = true
                    restoreX = ev.rawX
                    restoreY = ev.rawY
                    touching = true
                    return
                }
                if (prefs.autoScrollTouch == 1) stop("자동 스크롤을 멈췄어요") else touching = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (restoreTracking) {
                    val dy = ev.rawY - restoreY
                    val dx = ev.rawX - restoreX
                    if (dy < -dp(48) && Math.abs(dy) > Math.abs(dx) * 1.5f) {
                        restoreTracking = false
                        expand(true)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                restoreTracking = false
                if (touching) {
                    touching = false
                    resumeAt = SystemClock.uptimeMillis() + RESUME_DELAY_MS
                    lastNanos = 0L
                    carry = 0f
                }
            }
        }
    }

    /** 웹 화면 아래 가운데(시스템 제스처 영역 위): 숨긴 막대를 위로 쓸어 올려 다시 보는 자리 */
    private fun inRestoreZone(ev: MotionEvent): Boolean {
        val w = target ?: return false
        val r = Rect()
        if (!w.getGlobalVisibleRect(r)) return false
        val cx = (r.left + r.right) / 2
        val x = ev.rawX.toInt(); val y = ev.rawY.toInt()
        return x in (cx - dp(90))..(cx + dp(90)) && y in (r.bottom - dp(100))..(r.bottom - dp(20))
    }

    private fun hitPill(ev: MotionEvent): Boolean {
        val v = pill ?: return false
        val r = Rect()
        if (!v.isShown || !v.getGlobalVisibleRect(r)) return false
        return r.contains(ev.rawX.toInt(), ev.rawY.toInt())
    }

    private fun hitWeb(ev: MotionEvent): Boolean {
        val w = target ?: return false
        val r = Rect()
        if (!w.getGlobalVisibleRect(r)) return false
        return r.contains(ev.rawX.toInt(), ev.rawY.toInt())
    }

    // ───────────────────────── 조작 막대 ─────────────────────────

    private fun root(): ViewGroup? = act.window?.decorView as? ViewGroup

    private fun showPill() {
        val root = root() ?: return
        removePill()
        val fg = MaterialColors.getColor(root, com.google.android.material.R.attr.colorOnSurface, 0xFF202020.toInt())
        val outline = MaterialColors.getColor(root, com.google.android.material.R.attr.colorOutlineVariant, 0xFFCCCCCC.toInt())
        val accent = MaterialColors.getColor(root, com.google.android.material.R.attr.colorPrimary, 0xFF2E9E5B.toInt())
        val webArea = act.findViewById<View>(R.id.browserUi)

        fun ripple(v: View) {
            val r = android.util.TypedValue()
            act.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, r, true)
            if (r.resourceId != 0) v.setBackgroundResource(r.resourceId)
        }

        fun glyph(label: String, desc: String, onClick: () -> Unit) = TextView(act).apply {
            text = label
            textSize = 24f
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(fg)
            contentDescription = desc
            isClickable = true
            isFocusable = true
            ripple(this)
            setOnClickListener { onClick() }
        }

        val slower = glyph("−", "느리게") { changeLevel(-1) }
        val faster = glyph("+", "빠르게") { changeLevel(+1) }
        slowerBtn = slower
        fasterBtn = faster

        // 속도: 위에 작은 이름, 아래에 큰 숫자
        val caption = TextView(act).apply {
            text = "속도"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(ColorUtils.setAlphaComponent(fg, 0x99))
        }
        val lv = TextView(act).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(accent)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        levelText = lv
        val speed = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            minimumWidth = dp(46)
            contentDescription = "자동 스크롤 속도"
            addView(caption, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        val stopBtn = ImageView(act).apply {
            setImageResource(R.drawable.ic_pause)
            setColorFilter(fg)
            contentDescription = "자동 스크롤 멈추기"
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
            isFocusable = true
            ripple(this)
            setOnClickListener { stop("자동 스크롤을 멈췄어요") }
        }
        val divider = View(act).apply { setBackgroundColor(ColorUtils.setAlphaComponent(outline, 0xB0)) }

        // 위쪽 가는 손잡이: 아래로 끌면 막대가 내려가 숨는다는 표시
        val grip = View(act).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(ColorUtils.setAlphaComponent(fg, 0x4D))
            }
        }
        val row = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(slower, LinearLayout.LayoutParams(dp(42), dp(40)))
            addView(speed, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)))
            addView(faster, LinearLayout.LayoutParams(dp(42), dp(40)))
            addView(divider, LinearLayout.LayoutParams(dp(1), dp(24)).apply { marginStart = dp(6); marginEnd = dp(6) })
            addView(stopBtn, LinearLayout.LayoutParams(dp(42), dp(40)))
        }

        val bar = BlurPillLayout(act).apply {
            tag = PILL_TAG
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(10), dp(0), dp(10), dp(5))
            this.source = webArea
            addView(grip, LinearLayout.LayoutParams(dp(30), dp(4)).apply { topMargin = dp(6); bottomMargin = dp(1) })
            addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            // 아래로 끌면 막대가 손가락을 따라 내려가고, 충분히 내리거나 빠르게 쓸면 숨는다 (버튼 위에서 시작해도 된다)
            onDrag = { dy -> dragPill(dy) }
            onDragEnd = { dy, vy -> endDragPill(dy, vy) }
            // 앱 알림(토스트·진행 카드)보다는 아래, 일반 화면보다는 위
            AppToast.raiseToTop(this, dp(AppToast.CARD_Z_DP - 20))
        }

        pill = bar
        refreshLevelText()
        root.addView(bar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ))
        placePill()
        bar.bringToFront()
        if (collapsed) {
            bar.visibility = View.GONE
        } else if (Motion.enabled(act)) {
            // 블러가 켜져 있으면 투명도를 건드리지 않는다 (유리가 스스로 서서히 짙어지고, 투명도가 1 보다 작으면 뒤 페이지가 비쳐 겹쳐 보인다)
            if (!bar.blurOn) bar.alpha = 0f
            bar.translationY = dp(12).toFloat()
            bar.animate().alpha(1f).translationY(0f).setDuration(180).start()
        }
    }

    private fun placePill() {
        val root = root() ?: return
        val p = pill ?: return
        val lp = p.layoutParams as? FrameLayout.LayoutParams ?: return
        val bottomInset = ViewCompat.getRootWindowInsets(root)
            ?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val lift = liftProvider()
        val m = if (lift > 0) lift + dp(8) else bottomInset + dp(24)
        if (lp.bottomMargin != m) {
            lp.bottomMargin = m
            p.layoutParams = lp
        }
    }

    private fun removePill() {
        val p = pill ?: return
        pill = null
        levelText = null
        slowerBtn = null
        fasterBtn = null
        p.animate().cancel()
        (p.parent as? ViewGroup)?.removeView(p)
    }

    // ───────────────────────── 내려서 숨기기 ─────────────────────────

    /** 막대를 화면 아래로 완전히 내려 보내는 데 필요한 거리 */
    private fun hideDistance(p: View): Float {
        val m = (p.layoutParams as? FrameLayout.LayoutParams)?.bottomMargin ?: 0
        return (p.height + m + dp(12)).toFloat()
    }

    /** 끄는 동안 막대가 손가락을 따라 내려간다 (위로는 살짝만) */
    private fun dragPill(dy: Float) {
        val p = pill ?: return
        p.animate().cancel()
        p.translationY = if (dy >= 0f) dy else dy * 0.12f
    }

    private fun endDragPill(dy: Float, vy: Float) {
        val p = pill ?: return
        if (dy > dp(36) || (dy > dp(12) && vy > 1000f)) collapse(true)
        else p.animate().translationY(0f).setDuration(150).setInterpolator(DecelerateInterpolator()).start()
    }

    /** 막대를 아래로 내려 완전히 숨긴다 (아무것도 남기지 않는다) */
    private fun collapse(animated: Boolean) {
        val p = pill ?: return
        collapsed = true
        fun finish() {
            if (pill !== p || !collapsed) return
            p.animate().cancel()
            p.visibility = View.GONE
            p.translationY = 0f
            p.alpha = 1f
            if (!hintShown) {
                hintShown = true
                notify("화면 아래 가운데를 위로 쓸어 올리면 조작 막대가 다시 나와요")
            }
        }
        if (animated && Motion.enabled(act)) {
            p.animate().translationY(hideDistance(p)).setDuration(170)
                .setInterpolator(AccelerateInterpolator()).withEndAction { finish() }.start()
        } else finish()
    }

    /** 숨긴 막대를 다시 올린다 */
    private fun expand(animated: Boolean) {
        val p = pill ?: return
        collapsed = false
        p.animate().cancel()
        p.visibility = View.VISIBLE
        p.bringToFront()
        if (animated && Motion.enabled(act)) {
            p.translationY = dp(40).toFloat()
            p.animate().translationY(0f).setDuration(190).setInterpolator(DecelerateInterpolator()).start()
        } else p.translationY = 0f
    }

    private fun changeLevel(delta: Int) {
        val next = (prefs.autoScrollSpeed + delta).coerceIn(MIN_LEVEL, MAX_LEVEL)
        if (next == prefs.autoScrollSpeed) return
        prefs.autoScrollSpeed = next
        refreshLevelText()
        pill?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun refreshLevelText() {
        val v = prefs.autoScrollSpeed
        levelText?.text = v.toString()
        // 더 못 느리게/빠르게 할 때는 해당 버튼을 흐리게
        slowerBtn?.alpha = if (v <= MIN_LEVEL) 0.35f else 1f
        fasterBtn?.alpha = if (v >= MAX_LEVEL) 0.35f else 1f
    }
}
