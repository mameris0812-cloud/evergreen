package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 런처 아이콘(작업 표시줄·앱 목록·엣지 패널 포함)의 진입점. 보이지 않고 바로 닫힌다.
 *
 * 이미 떠 있는 에버그린을 앞으로 가져오기만 하면 삼성 One UI 가 "evergreen은(는) 이미 실행 중입니다."
 * 토스트로 막아 버린다. 그래서 '지금 화면에 보이는 창이 있는데 아이콘을 또 눌렀다'면
 * 창 모드(분할·자유 창)인지 전체 화면인지와 상관없이 새 창을 하나 더 띄운다.
 *
 * - 앱이 화면에 안 보이는 상태(홈 화면에서 눌렀을 때 등)면 예전처럼 떠 있는 앱을 앞으로 가져오거나 새로 시작한다.
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val running = MainActivity.runningWindows().filter { !it.isFinishing && !it.isDestroyed }

        // 새 창을 띄울 기준 창: 지금 보이는 창 > 창 모드로 떠 있는 창 > (이 진입점이 창 모드면) 아무 창
        // 전체 화면으로 떠 있어도 '보이는 중'이면 해당된다 (작업 표시줄에서 누르면 앱이 전체 화면이어도 isInMultiWindowMode 가 false 라서)
        val base = running.firstOrNull { it.visibleNow }
            ?: running.firstOrNull { it.isInMultiWindowMode }
            ?: if (isInMultiWindowMode) running.firstOrNull() else null

        var opened = false
        if (base != null) {
            opened = try {
                base.openNewWindow()
                true
            } catch (e: Throwable) {
                false
            }
        }
        if (!opened) {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .setAction(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
