package com.example.evergreen

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable

/**
 * 크롬 테마의 새 탭 배경(theme_ntp_background): 바탕색 위에 그림을 깐다.
 * ntp_background_alignment(left/right/top/bottom/center 조합)와 ntp_background_repeating(no-repeat/repeat/repeat-x/repeat-y)을 따른다.
 * no-repeat 는 화면을 덮도록 키워서(cover) 정렬 쪽을 기준으로 맞추고, 반복 모양은 그림을 화면 밀도에 맞춰 타일로 깐다.
 */
class ThemeHomeBgDrawable(
    private val bm: Bitmap?, private val color: Int,
    align: String, private val repeat: String, private val density: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fx: Float
    private val fy: Float
    init {
        val a = align.lowercase()
        fx = when { a.contains("left") -> 0f; a.contains("right") -> 1f; else -> 0.5f }
        fy = when { a.contains("top") -> 0f; a.contains("bottom") -> 1f; else -> 0.5f }
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        paint.shader = null
        paint.color = color
        canvas.drawRect(b, paint)
        val bmp = bm ?: return
        if (bmp.isRecycled || b.width() <= 0 || b.height() <= 0) return
        val w = b.width().toFloat(); val h = b.height().toFloat()
        val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat()
        val m = Matrix()
        if (repeat == "no-repeat") {
            val s = maxOf(w / bw, h / bh)
            val ox = (w - bw * s) * fx
            val oy = (h - bh * s) * fy
            m.postScale(s, s); m.postTranslate(b.left + ox, b.top + oy)
            val sh = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            sh.setLocalMatrix(m)
            paint.shader = sh
            canvas.drawRect(b, paint)
        } else {
            val s = density
            val iw = bw * s; val ih = bh * s
            val ox = (w - iw) * fx
            val oy = (h - ih) * fy
            val rx = repeat == "repeat" || repeat == "repeat-x"
            val ry = repeat == "repeat" || repeat == "repeat-y"
            m.postScale(s, s); m.postTranslate(b.left + ox, b.top + oy)
            val sh = BitmapShader(bmp, if (rx) Shader.TileMode.REPEAT else Shader.TileMode.CLAMP, if (ry) Shader.TileMode.REPEAT else Shader.TileMode.CLAMP)
            sh.setLocalMatrix(m)
            paint.shader = sh
            // 반복하지 않는 방향은 그림 크기만큼만 그린다 (CLAMP 가 가장자리를 늘려 번지지 않게)
            val r = RectF(
                if (rx) b.left.toFloat() else b.left + ox, if (ry) b.top.toFloat() else b.top + oy,
                if (rx) b.right.toFloat() else b.left + ox + iw, if (ry) b.bottom.toFloat() else b.top + oy + ih
            )
            r.intersect(RectF(b))
            canvas.drawRect(r, paint)
        }
        paint.shader = null
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/**
 * 크롬 테마가 바꾼 탭 모양: 선택 안 된 탭은 theme_tab_background 그림, 선택된 탭은 theme_toolbar 그림(없으면 기본 면 색)으로 채운다.
 * 윗면이 둥근 탭 모양으로 잘라 그리고, [setAlpha] 는 선택된 탭 쪽의 짙기(선택/해제 전환)에만 쓴다.
 */
class ThemeTabDrawable(
    private val shape: Drawable, private val selBm: Bitmap?, private val inactBm: Bitmap?,
    private val radius: Float, private val density: Float
) : Drawable() {
    private var selAlpha = 255
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val clip = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        shape.bounds = b
        clip.reset()
        clip.addRoundRect(RectF(b), floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f), android.graphics.Path.Direction.CW)
    }

    private fun tile(canvas: Canvas, bm: Bitmap) {
        val b = bounds
        val m = Matrix()
        m.postScale(density, density); m.postTranslate(b.left.toFloat(), b.top.toFloat())
        val sh = BitmapShader(bm, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP)
        sh.setLocalMatrix(m)
        paint.shader = sh
        canvas.drawRect(b, paint)
        paint.shader = null
    }

    override fun draw(canvas: Canvas) {
        if (bounds.isEmpty) return
        if (inactBm != null && !inactBm.isRecycled) {
            val n = canvas.save(); canvas.clipPath(clip); tile(canvas, inactBm); canvas.restoreToCount(n)
        }
        if (selAlpha > 0) {
            val n = canvas.saveLayerAlpha(RectF(bounds), selAlpha)
            shape.alpha = 255
            shape.draw(canvas)
            if (selBm != null && !selBm.isRecycled) {
                val k = canvas.save(); canvas.clipPath(clip); tile(canvas, selBm); canvas.restoreToCount(k)
            }
            canvas.restoreToCount(n)
        }
    }

    override fun setAlpha(alpha: Int) { selAlpha = alpha; invalidateSelf() }
    override fun getAlpha(): Int = selAlpha
    override fun setColorFilter(cf: ColorFilter?) {}
    override fun setTintList(tint: android.content.res.ColorStateList?) { shape.setTintList(tint); invalidateSelf() }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * 새 탭 화면의 버튼·카드 뒤를 흐리게(유리처럼) 보이게 하는 배경.
 * 새 탭 배경 그림을 미리 흐리게 만들어 둔 그림([bmp], 화면의 [scale] 배)에서 이 뷰가 놓인 자리만 잘라 둥근 모양으로 그리고,
 * 그 위에 살짝 색을 덮어 글자가 읽히게 한다. 뷰의 위치는 그릴 때마다 [root] 기준으로 다시 계산한다.
 */
class ThemeGlassDrawable(
    private val bmp: Bitmap, private val scale: Float,
    private val host: android.view.View, private val root: android.view.View,
    private val corner: Float, private val tint: Int, private val line: Int, private val lineW: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val a = IntArray(2)
    private val b = IntArray(2)
    private val path = android.graphics.Path()

    override fun draw(canvas: Canvas) {
        val bd = bounds
        if (bd.isEmpty) return
        host.getLocationInWindow(a); root.getLocationInWindow(b)
        val dx = a[0] - b[0]; val dy = a[1] - b[1]
        val l = ((dx * scale).toInt()).coerceIn(0, bmp.width - 1)
        val t = ((dy * scale).toInt()).coerceIn(0, bmp.height - 1)
        val r = (((dx + bd.width()) * scale).toInt()).coerceIn(l + 1, bmp.width)
        val bt = (((dy + bd.height()) * scale).toInt()).coerceIn(t + 1, bmp.height)
        val dst = RectF(bd)
        path.reset(); path.addRoundRect(dst, corner, corner, android.graphics.Path.Direction.CW)
        val n = canvas.save()
        canvas.clipPath(path)
        paint.style = Paint.Style.FILL
        canvas.drawBitmap(bmp, android.graphics.Rect(l, t, r, bt), dst, paint)
        paint.color = tint
        canvas.drawRect(dst, paint)
        canvas.restoreToCount(n)
        if (lineW > 0f) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = lineW; paint.color = line
            val h = lineW / 2f
            canvas.drawRoundRect(RectF(dst.left + h, dst.top + h, dst.right - h, dst.bottom - h), corner - h, corner - h, paint)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        /** 작은 그림을 상자 블러로 흐리게 한다 (가로·세로 두 번씩). 새 그림을 돌려준다 */
        fun blur(src: Bitmap, radius: Int): Bitmap {
            val w = src.width; val h = src.height
            var px = IntArray(w * h)
            src.getPixels(px, 0, w, 0, 0, w, h)
            var tmp = IntArray(w * h)
            repeat(2) {
                pass(px, tmp, w, h, radius, true)
                pass(tmp, px, w, h, radius, false)
            }
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            out.setPixels(px, 0, w, 0, 0, w, h)
            return out
        }

        private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
            val len = if (horiz) w else h
            val lines = if (horiz) h else w
            for (ln in 0 until lines) {
                for (i in 0 until len) {
                    var sa = 0; var sr = 0; var sg = 0; var sb = 0; var cnt = 0
                    for (k in -r..r) {
                        val j = (i + k).coerceIn(0, len - 1)
                        val c = if (horiz) src[ln * w + j] else src[j * w + ln]
                        sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255; cnt++
                    }
                    val v = ((sa / cnt) shl 24) or ((sr / cnt) shl 16) or ((sg / cnt) shl 8) or (sb / cnt)
                    if (horiz) dst[ln * w + i] = v else dst[i * w + ln] = v
                }
            }
        }
    }
}

/**
 * 탭바·툴바 배경에 까는 테마 그림: 크롬 1x 크기를 화면 밀도에 맞춰 가로로 반복해서 위쪽에 맞춰 그린다.
 * BitmapDrawable 과 달리 '자기 크기'가 없어서(-1), 그림이 크더라도 막대(뷰)의 높이를 키우지 않는다.
 */
class ThemeTileDrawable(private val bm: Bitmap, private val density: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    override fun draw(canvas: Canvas) {
        if (bm.isRecycled || bounds.isEmpty) return
        val b = bounds
        val m = Matrix()
        m.postScale(density, density); m.postTranslate(b.left.toFloat(), b.top.toFloat())
        val sh = BitmapShader(bm, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP)
        sh.setLocalMatrix(m)
        paint.shader = sh
        canvas.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), minOf(b.bottom.toFloat(), b.top + bm.height * density), paint)
        paint.shader = null
    }

    override fun getIntrinsicWidth(): Int = -1
    override fun getIntrinsicHeight(): Int = -1
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
