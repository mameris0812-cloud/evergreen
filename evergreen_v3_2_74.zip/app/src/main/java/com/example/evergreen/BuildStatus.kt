package com.example.evergreen

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * GitHub Actions 빌드 진행 창("빌드 중… 43%").
 * 저절로 뜨지 않는다. 설정 > 앱 정보 > '빌드 진행 상황'을 눌렀을 때만 [show] 로 띄운다.
 *  - 지금 진행 중인 빌드가 있으면 진행 창을 띄우고, 없으면 안내만 보여 준다.
 *  - 빌드가 끝나면 창이 닫힌다. 성공하면 바로 업데이트를 확인하고, 실패·취소는 알림만 보여 준다.
 *
 * 로그인 없이 쓰는 GitHub API 는 시간당 60번 제한이 있어서 ETag(If-None-Match)를 쓴다.
 * 바뀐 게 없으면 304 로 답하고, 304 는 제한 횟수에 들어가지 않는다. 
 * 파일 올리기에서 저장해 둔 GitHub 토큰이 있으면 그 토큰으로 묻는다 (한도가 시간당 60번 → 5000번). 없거나 안 맞으면 로그인 없이 묻는다.
 * 토큰은 api.github.com 요청 머리글로만 보내고 다른 곳에는 쓰지 않는다.
 */
object BuildStatus {
    private const val POLL_MS = 10_000L       // 진행 창이 떠 있는 동안 확인 간격 (바뀐 게 있을 때)
    private const val POLL_MAX_MS = 20_000L   // 몇 번 연속으로 그대로면 이 간격까지 천천히
    private const val HIDDEN_RECHECK_MS = 3_000L // 앱이 화면에 없을 때는 요청 없이 이 간격으로 돌아왔는지만 본다

    internal class RateLimited(val resetSec: Long) : Exception()

    internal class Snapshot(val status: String, val conclusion: String?, val done: Int, val total: Int, val startedMs: Long, val version: String? = null, val pct: Int = -1)

    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followSslRedirects(false)
        .build()

    private val etags = HashMap<String, String>()
    private val bodies = HashMap<String, String>()

    @Volatile private var showing = false

    /** 토큰이 거절(401)되면 true: 이후로는 토큰 없이 묻는다 */
    @Volatile private var tokenRejected = false

    private fun get(url: String, token: String?, accept: String = "application/vnd.github+json"): String {
        val useToken = token != null && !tokenRejected
        // 토큰으로 받은 응답과 아닌 응답이 같은 캐시(ETag)를 쓰지 않게 키를 나눈다
        val key = (if (useToken) "$url#auth" else url) + (if (accept.endsWith("raw")) "#raw" else "")
        val b = Request.Builder().url(url)
            .header("Accept", accept)
            .header("User-Agent", "evergreen-updater")
        if (useToken) b.header("Authorization", "Bearer $token")
        synchronized(etags) { etags[key] }?.let { b.header("If-None-Match", it) }
        client.newCall(b.build()).execute().use { resp ->
            if (resp.code == 401 && useToken) {
                tokenRejected = true
                return get(url, null, accept)
            }
            if (resp.code == 304) {
                return synchronized(bodies) { bodies[key] } ?: throw IllegalStateException("캐시 없음")
            }
            if ((resp.code == 403 || resp.code == 429) && resp.header("x-ratelimit-remaining") == "0") throw RateLimited(resp.header("x-ratelimit-reset")?.toLongOrNull() ?: 0L)
            if (!resp.isSuccessful) throw IllegalStateException("서버 응답 오류 (${resp.code})")
            val text = resp.body?.string() ?: throw IllegalStateException("빈 응답")
            resp.header("ETag")?.let { synchronized(etags) { etags[key] = it } }
            synchronized(bodies) { bodies[key] = text }
            return text
        }
    }

    /** headSha 가 있으면 그 커밋의 빌드를, 없으면 가장 최근 빌드를 가져온다. 없으면 null. */
    internal fun fetch(headSha: String?, token: String?): Snapshot? {
        val base = "https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/actions"
        val q = if (headSha != null) "?head_sha=$headSha&per_page=1" else "?per_page=1"
        val runs = JSONObject(get("$base/runs$q", token)).optJSONArray("workflow_runs")
        if (runs == null || runs.length() == 0) return null
        val run = runs.getJSONObject(0)
        val status = run.optString("status")
        var done = 0
        var total = 0
        var pct = -1
        val runId = run.getLong("id")
        if (status == "in_progress") {
            val steps = stepsOf(base, runId, token)
            if (steps != null) {
                total = steps.length()
                for (i in 0 until total) if (steps.getJSONObject(i).optString("status") == "completed") done++
                pct = estimatePct(steps)
            }
        } else if (status == "completed" && run.optString("conclusion") == "success") {
            // 성공한 빌드의 단계별 걸린 시간을 기억해 둔다 (다음 빌드의 진행률 계산에 쓴다)
            recordDurations(base, runId, token)
        }
        // 빌드가 시작된 시각 (UTC, 예: 2026-11-08T05:12:30Z). 못 읽으면 0
        val startedMs = parseIso(run.optString("run_started_at").ifEmpty { run.optString("created_at") })
        val version = if (status != "completed") versionOf(run.optString("head_sha"), run.optString("display_title"), token) else null
        return Snapshot(status, run.optString("conclusion").ifEmpty { null }, done, total, startedMs, version, pct)
    }


    /** 단계별 걸린 시간을 저장할 곳 (앱 문맥이 있을 때만) */
    @Volatile internal var appCtx: android.content.Context? = null
    private fun statsPrefs() = appCtx?.getSharedPreferences("build_stats", android.content.Context.MODE_PRIVATE)

    private fun stepsOf(base: String, runId: Long, token: String?): org.json.JSONArray? {
        val jobs = JSONObject(get("$base/runs/$runId/jobs", token)).optJSONArray("jobs")
        return jobs?.takeIf { it.length() > 0 }?.getJSONObject(0)?.optJSONArray("steps")
    }

    /** 단계 이름 → 지난번 걸린 시간(초) */
    private fun loadDurations(): Map<String, Double> {
        val raw = statsPrefs()?.getString("steps", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getDouble(it) }
        }.getOrDefault(emptyMap())
    }

    private fun stepSec(st: JSONObject): Double {
        val a = parseIso(st.optString("started_at"))
        val b = parseIso(st.optString("completed_at"))
        return if (a > 0 && b >= a) (b - a) / 1000.0 else 0.0
    }

    private fun recordDurations(base: String, runId: Long, token: String?) {
        val sp = statsPrefs() ?: return
        if (sp.getLong("recorded_run", 0L) == runId) return
        val steps = try { stepsOf(base, runId, token) } catch (e: RateLimited) { throw e } catch (e: Exception) { null } ?: return
        val o = JSONObject()
        for (i in 0 until steps.length()) {
            val st = steps.getJSONObject(i)
            if (st.optString("conclusion") != "success") continue
            o.put(st.optString("name"), stepSec(st))
        }
        if (o.length() > 0) sp.edit().putString("steps", o.toString()).putLong("recorded_run", runId).apply()
    }

    /**
     * 진행률(0..99). 단계 개수로만 나누면 단계가 서너 개라 33% → 66% → 80% 처럼 뚝뚝 끊겼다.
     * 지난 성공한 빌드의 단계별 걸린 시간을 무게로 삼고, 지금 하는 단계는 시작한 뒤 흐른 시간만큼 채운다.
     * 지난 기록이 없는 단계는 이미 끝난 단계들의 평균(없으면 20초)으로 잡는다.
     */
    private fun estimatePct(steps: org.json.JSONArray): Int {
        val known = loadDurations()
        val n = steps.length()
        if (n == 0) return -1
        val actual = ArrayList<Double>()
        for (i in 0 until n) { val st = steps.getJSONObject(i); if (st.optString("status") == "completed") actual.add(stepSec(st)) }
        val fallback = (known.values.filter { it > 0.5 }.average().takeIf { !it.isNaN() } ?: actual.filter { it > 0.5 }.average().takeIf { !it.isNaN() } ?: 20.0)
        var doneSec = 0.0
        var totalSec = 0.0
        val now = System.currentTimeMillis()
        for (i in 0 until n) {
            val st = steps.getJSONObject(i)
            val exp = (known[st.optString("name")] ?: fallback).coerceAtLeast(1.0)
            when (st.optString("status")) {
                "completed" -> { val a = maxOf(stepSec(st), 0.0); doneSec += a; totalSec += a }
                "in_progress" -> {
                    val started = parseIso(st.optString("started_at"))
                    val el = if (started > 0) ((now - started) / 1000.0).coerceAtLeast(0.0) else 0.0
                    // 예상보다 오래 걸려도 100% 에 닿지 않게, 예상 시간의 95% 까지만 채우고 그 뒤로는 아주 천천히 늘린다
                    val part = if (el <= exp * 0.95) el else exp * 0.95 + (el - exp * 0.95) * 0.02
                    doneSec += minOf(part, exp * 0.99); totalSec += exp
                }
                else -> totalSec += exp
            }
        }
        if (totalSec <= 0.0) return -1
        return (doneSec * 100.0 / totalSec).toInt().coerceIn(0, 99)
    }

    /** 커밋(sha)별로 빌드 중인 버전 이름 (한 번 알아낸 건 다시 묻지 않는다. 못 알아낸 것도 기억해서 요청 한도를 아낀다) */
    private val versions = HashMap<String, String?>()

    /** 빌드 중인 커밋의 app/build.gradle.kts 에서 versionName 을 읽는다. 못 읽으면 커밋 제목에서 버전 모양(3.2.72)을 찾고, 그래도 없으면 null */
    private fun versionOf(sha: String, title: String, token: String?): String? {
        if (sha.isEmpty()) return null
        synchronized(versions) { if (versions.containsKey(sha)) return versions[sha] }
        var v: String? = null
        try {
            val url = "https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/contents/app/build.gradle.kts?ref=$sha"
            v = Regex("versionName\\s*=\\s*\"([^\"]+)\"").find(get(url, token, "application/vnd.github.raw"))?.groupValues?.get(1)
        } catch (e: RateLimited) {
            throw e
        } catch (e: Exception) { /* 아래에서 제목으로 대신한다 */ }
        if (v == null) v = Regex("\\bv?(\\d+\\.\\d+\\.\\d+)\\b").find(title)?.groupValues?.get(1)
        synchronized(versions) { versions[sha] = v }
        return v
    }

    private fun parseIso(t0: String): Long = runCatching {
        val t = t0.replace(Regex("\\.\\d+Z$"), "Z")   // 단계 시각은 2026-11-08T05:12:30.000Z 처럼 소수 초가 붙어 온다
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        f.parse(t)?.time ?: 0L
    }.getOrDefault(0L)

    /** 경과 시간을 "2:05" / "1:02:05" 로 */
    internal fun fmtElapsed(ms: Long): String {
        val sec = (ms / 1000).coerceAtLeast(0)
        val h = sec / 3600
        val m = sec % 3600 / 60
        val ss = sec % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, ss) else String.format(java.util.Locale.US, "%d:%02d", m, ss)
    }

    /** 설정 > 앱 정보에서 눌렀을 때: 진행 중인 빌드가 있으면 진행 창을 띄운다 */
    fun show(act: Activity) {
        if (!Updater.enabled()) {
            AppToast.show(act, "GitHub Actions 로 빌드한 앱에서만 볼 수 있어요")
            return
        }
        track(act)
    }

    private fun track(act: Activity) {
        appCtx = act.applicationContext
        val headSha: String? = null
        if (showing) return
        showing = true
        val stopped = AtomicBoolean(false)
        val busy = AtomicBoolean(false)
        var dlg: AlertDialog? = null
        var label: TextView? = null
        var bar: ProgressBar? = null
        var timeLabel: TextView? = null
        var titleView: TextView? = null
        var startedMs = 0L
        var skewMs = 0L   // 기기 시계와 서버 시각 차이는 무시하고, 처음 본 값이 음수면 0부터 시작하게만 보정

        fun updateTime() {
            val t = timeLabel ?: return
            if (startedMs <= 0L) { t.text = ""; return }
            t.text = "경과 시간 ${fmtElapsed(System.currentTimeMillis() - startedMs + skewMs)}"
        }

        fun finish() {
            stopped.set(true)
            showing = false
            runCatching { dlg?.dismiss() }
        }

        fun ensureDialog() {
            if (dlg != null) return
            // 앱이 화면 밖에 있어도 알림으로 진행률·경과 시간을 보여 주는 서비스
            BuildWatchService.start(act.applicationContext)
            val dp = act.resources.displayMetrics.density
            fun px(v: Int) = (v * dp).toInt()
            // 오류 화면처럼 맨 위에 그림 카드, 그 아래 제목·진행 상태·진행 막대 (가운데 정렬)
            val art = BuildArtView(act)
            val title = TextView(act).apply {
                text = "빌드 중"
                textSize = 16f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_text))
            }
            val l = TextView(act).apply {
                text = "대기 중…"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_muted))
            }
            val tl = TextView(act).apply {
                text = ""
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(act.getColor(R.color.ev_muted))
            }
            val b = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                isIndeterminate = true
            }
            val box = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(px(16), px(18), px(16), px(2))
                addView(art, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })
                addView(l, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(4) })
                addView(tl, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(2) })
                addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })
            }
            label = l
            titleView = title
            timeLabel = tl
            bar = b
            // 폭을 좁게 (340dp, 아래에서 창 폭을 직접 지정). 그림은 창 폭에 꽉 차게 크게 둔다
            dlg = ThemedDialogBuilder(act, R.style.ThemeOverlay_Evergreen_Dialog_Narrow)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("숨기기") { _, _ -> finish() }
                .show()
            // 테마의 고정 폭이 큰 화면·창에서 안 먹는 경우가 있어서 창 폭을 직접 지정한다 (화면이 더 좁으면 화면 폭까지만)
            dlg?.window?.let { w ->
                val maxW = act.resources.displayMetrics.widthPixels - px(32)
                w.setLayout(minOf(px(340), maxW), android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        }

        fun render(s: Snapshot) {
            val b = bar ?: return
            if (s.startedMs > 0L) {
                startedMs = s.startedMs
                // 기기 시계가 서버보다 느려 경과가 음수로 나오면 0부터 시작하게 맞춘다
                val raw = System.currentTimeMillis() - startedMs
                skewMs = if (raw < 0) -raw else 0L
            }
            updateTime()
            titleView?.text = if (s.version != null) "빌드 중 · v${s.version}" else "빌드 중"
            if (s.status == "queued" || s.total == 0) {
                b.isIndeterminate = true
                label?.text = "대기 중…"
            } else {
                val pct = if (s.pct >= 0) s.pct else s.done * 100 / s.total
                b.isIndeterminate = false
                b.setProgress(pct, true)   // 부드럽게 차오르게
                label?.text = "빌드 중… $pct%"
            }
        }

        // 저장된 토큰은 확인 스레드에서 처음 쓸 때 읽는다 (기기 보안 저장소를 읽느라 화면이 멈추지 않게)
        val authToken by lazy { runCatching { GitUpload.loadToken(act.applicationContext) }.getOrNull() }
        var wait = POLL_MS
        var lastSig = ""

        // GitHub 확인(10초 간격)과 별개로 경과 시간은 1초마다 갱신한다 (요청 없음)
        fun clock() {
            if (stopped.get()) return
            updateTime()
            main.postDelayed({ clock() }, 1_000L)
        }

        fun tick() {
            if (stopped.get()) return
            // 앱이 화면에 없으면(다른 앱·화면 꺼짐) GitHub 에 묻지 않는다. 돌아오면 바로 이어서 확인한다.
            if (AppForeground.current() == null) {
                main.postDelayed({ tick() }, HIDDEN_RECHECK_MS)
                return
            }
            if (!busy.compareAndSet(false, true)) return
            Thread {
                var snap: Snapshot? = null
                var rate = false
                var resetSec = 0L
                var failed = false
                try {
                    snap = fetch(headSha, authToken)
                } catch (e: RateLimited) {
                    rate = true
                    resetSec = e.resetSec
                } catch (e: Exception) {
                    failed = true
                }
                val s = snap
                main.post {
                    busy.set(false)
                    if (stopped.get()) return@post
                    if (act.isFinishing || act.isDestroyed) { finish(); return@post }
                    when {
                        rate -> {
                            finish()
                            val mins = if (resetSec > 0) ((resetSec * 1000 - System.currentTimeMillis()) / 60_000L + 1).coerceIn(1, 60) else 0
                            AppToast.show(act, if (mins > 0) "GitHub 요청 한도에 도달했어요. 약 ${mins}분 뒤에 다시 확인해 주세요" else "GitHub 요청 한도에 도달했어요. 잠시 뒤 다시 확인해 주세요")
                        }
                        failed -> {
                            // 일시적인 네트워크 오류: 창이 떠 있으면 계속 시도하고, 아니면 조용히 끝낸다
                            if (dlg != null) main.postDelayed({ tick() }, wait)
                            else { finish(); AppToast.show(act, "빌드 상태를 가져오지 못했어요") }
                        }
                        s == null -> {
                            finish()
                            AppToast.show(act, "진행 중인 빌드가 없어요")
                        }
                        s.status == "completed" -> {
                            val shown = dlg != null
                            val took = if (startedMs > 0L) " (경과 ${fmtElapsed(System.currentTimeMillis() - startedMs + skewMs)})" else ""
                            finish()
                            BuildWatchService.stop(act.applicationContext)
                            // 창이 떠 있던 빌드가 끝났으면 결과를 알린다. 처음부터 끝나 있던 빌드면 없다고만 알린다.
                            if (shown) onDone(act, s, took) else AppToast.show(act, "진행 중인 빌드가 없어요")
                        }
                        else -> {
                            ensureDialog()
                            render(s)
                            // 진행이 그대로면 점점 천천히, 바뀌면 다시 기본 간격으로
                            val sig = "${s.status}/${s.done}/${s.total}/${s.pct}"
                            wait = if (sig == lastSig) minOf(wait + 5_000L, POLL_MAX_MS) else POLL_MS
                            lastSig = sig
                            main.postDelayed({ tick() }, wait)
                        }
                    }
                }
            }.start()
        }
        clock()
        tick()
    }

    private fun onDone(act: Activity, s: Snapshot, took: String) {
        when (s.conclusion) {
            "success" -> Updater.manualCheck(act)   // 새 버전이 있으면 '새 버전이 있어요' 창이 뜬다
            "cancelled" -> AppToast.show(act, "빌드가 취소됐어요$took")
            else -> AppToast.show(act, "빌드에 실패했어요$took")
        }
    }

    // ───────────────────────── 지난 빌드 기록(Actions 실행 기록) 정리 ─────────────────────────

    private const val KEEP_RUNS = 5   // 정리하고도 남겨 둘 최근 실행 개수

    @Volatile private var cleaning = false

    private fun delete(url: String, token: String): Int {
        val rq = Request.Builder().url(url).delete()
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "evergreen-updater")
            .header("Authorization", "Bearer $token").build()
        client.newCall(rq).execute().use { resp ->
            if ((resp.code == 403 || resp.code == 429) && resp.header("x-ratelimit-remaining") == "0") throw RateLimited(resp.header("x-ratelimit-reset")?.toLongOrNull() ?: 0L)
            return resp.code
        }
    }

    /**
     * 설정 > 앱 정보 > '빌드 기록 정리': 끝난 빌드 기록(성공·실패·취소)을 최근 [KEEP_RUNS]개만 남기고 지운다.
     * 진행 중인 빌드와 릴리스(APK)는 건드리지 않는다. 지우려면 파일 올리기에서 저장해 둔 GitHub 토큰에 Actions 쓰기 권한이 있어야 한다.
     */
    fun cleanup(act: Activity) {
        if (!Updater.enabled()) {
            AppToast.show(act, "GitHub Actions 로 빌드한 앱에서만 쓸 수 있어요")
            return
        }
        if (cleaning) { AppToast.show(act, "이미 정리하는 중이에요"); return }
        val token = runCatching { GitUpload.loadToken(act.applicationContext) }.getOrNull()
        if (token.isNullOrEmpty()) {
            AppToast.show(act, "먼저 'GitHub 에 파일 올리기'에서 GitHub 토큰을 저장해 주세요")
            return
        }
        Popup.confirm(
            act, "지난 빌드 기록을 정리할까요?",
            "끝난 빌드 기록을 최근 ${KEEP_RUNS}개만 남기고 모두 지워요. 진행 중인 빌드와 릴리스(APK)는 그대로예요. 지운 기록은 되돌릴 수 없어요.",
            "정리", danger = true
        ) {
            cleaning = true
            AppToast.show(act, "빌드 기록을 정리하는 중…")
            Thread {
                var deleted = 0
                var msg: String
                try {
                    val base = "https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/actions/runs"
                    // 끝난 기록을 최신순으로 모은다 (한 번에 100개씩, 앞쪽 KEEP_RUNS 개는 남긴다)
                    val ids = ArrayList<Long>()
                    var page = 1
                    while (page <= 30) {
                        val body = JSONObject(rawGet("$base?status=completed&per_page=100&page=$page", token))
                        val arr = body.optJSONArray("workflow_runs") ?: break
                        if (arr.length() == 0) break
                        for (i in 0 until arr.length()) ids.add(arr.getJSONObject(i).getLong("id"))
                        if (arr.length() < 100) break
                        page++
                    }
                    val old = if (ids.size > KEEP_RUNS) ids.subList(KEEP_RUNS, ids.size) else emptyList()
                    var denied = false
                    for (id in old) {
                        val code = delete("$base/$id", token)
                        if (code == 204) deleted++
                        else if (code == 403 || code == 404 || code == 401) { denied = true; break }
                    }
                    msg = when {
                        denied && deleted == 0 -> "지우지 못했어요. 토큰에 Actions 쓰기 권한이 있는지 확인해 주세요"
                        denied -> "${deleted}개를 지우고 멈췄어요. 토큰 권한을 확인해 주세요"
                        old.isEmpty() -> "정리할 빌드 기록이 없어요 (${ids.size}개)"
                        else -> "빌드 기록 ${deleted}개를 지웠어요 (최근 ${minOf(KEEP_RUNS, ids.size)}개 남김)"
                    }
                } catch (e: RateLimited) {
                    msg = "GitHub 요청 한도에 도달했어요. ${deleted}개를 지우고 멈췄어요. 잠시 뒤 다시 해 주세요"
                } catch (e: Exception) {
                    msg = if (deleted > 0) "${deleted}개를 지우고 멈췄어요 (${e.message})" else "정리하지 못했어요 (${e.message})"
                }
                cleaning = false
                main.post { if (!act.isFinishing && !act.isDestroyed) AppToast.show(act, msg) }
            }.start()
        }
    }

    /** 캐시(ETag)를 쓰지 않는 GET: 지우는 중에는 목록이 계속 바뀌므로 항상 새로 받는다 */
    private fun rawGet(url: String, token: String): String {
        val rq = Request.Builder().url(url)
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "evergreen-updater")
            .header("Authorization", "Bearer $token").build()
        client.newCall(rq).execute().use { resp ->
            if ((resp.code == 403 || resp.code == 429) && resp.header("x-ratelimit-remaining") == "0") throw RateLimited(resp.header("x-ratelimit-reset")?.toLongOrNull() ?: 0L)
            if (!resp.isSuccessful) throw IllegalStateException("서버 응답 오류 (${resp.code})")
            return resp.body?.string() ?: throw IllegalStateException("빈 응답")
        }
    }
}
