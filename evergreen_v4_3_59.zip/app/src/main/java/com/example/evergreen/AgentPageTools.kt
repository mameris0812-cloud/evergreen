package com.example.evergreen

import org.json.JSONObject

/**
 * 에이전트: 웹 페이지 안 조작 도구.
 * - 읽기(자동): read_page(페이지 글 + 누르거나 쓸 수 있는 요소 목록), scroll_page(스크롤)
 * - 변경(요청당 한 번 확인): click_element(요소 누르기), drag_element(요소 끌기 · 슬라이더), fill_field(입력칸 쓰기 · 선택 · 체크)
 * - 위험(매번 확인): 결제 · 삭제 · 전송 · 동의 같은 버튼이나 제출 버튼, 파일 내려받기 링크 누르기, 입력 뒤 Enter 로 제출
 *
 * 요소는 read_page 가 번호(element)를 붙여 주고, 그 번호는 마지막으로 읽은 결과에서만 유효하다.
 * 페이지 안 스크립트는 [AgentHost.pageScript] 로만 돌린다. 지금 보는 탭에서만 동작한다.
 * 비밀번호 · 카드번호 · 인증번호 칸은 값을 읽지도 쓰지도 않는다 (사용자가 직접 입력).
 * iframe(다른 출처 포함) 안: 모든 프레임에 [frameBridgeScript] 를 문서 시작 때 넣어 두고, 프레임이 앱에 자기를 알린다(WebMessageListener).
 *   read_page 는 본문과 iframe 안 요소를 함께 돌려주고, iframe 요소의 번호는 `프레임번호 * 1000 + 요소번호`(예: 2003 = 2번 iframe 의 3번 요소)다.
 *   누르기 · 쓰기 · 끌기 · 스크롤은 번호만 보고 알아서 그 프레임 안에서 돈다. 같은 안전 규칙(위험 버튼 확인 · 비밀번호/카드 칸 금지)이 그대로 적용된다.
 * 가짜(스크립트) 클릭이라 사용자 제스처가 필요한 동작(팝업 창 · 파일 선택 · 전체 화면)은 사이트가 막을 수 있다.
 */
object AgentPageTools {
    fun build(): List<AgentTool> = listOf(readPage(), scrollPage(), clickElement(), dragElement(), fillField())

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    /** 누르기 전에 사용자에게 매번 물어야 하는 버튼 글자 (되돌리기 어려운 동작) */
    private val RISKY = Regex(
        "결제|구매|주문|송금|이체|입금|삭제|제거|탈퇴|해지|로그아웃|전송|보내기|제출|가입|동의|확인|승인|게시|발행|신고|초기화|" +
            "\\b(buy|purchase|pay|payment|checkout|order|delete|remove|erase|send|submit|confirm|transfer|withdraw|unsubscribe|" +
            "sign ?out|log ?out|post|publish|accept|agree|subscribe|donate|install)\\b",
        RegexOption.IGNORE_CASE
    )

    // ───────────────────────── 페이지 안에서 돌리는 스크립트 ─────────────────────────

    /**
     * 조작 표시(시각화): AI 가 페이지를 읽고 · 누르고 · 입력하고 · 스크롤하는 걸 사용자가 볼 수 있게
     * 페이지 위에 화살표 커서와 따라다니는 그라데이션 별 · 요소 테두리 · 이름표 · 클릭 물결을 띄운다.
     * - 페이지 모양을 건드리지 않도록 닫힌 shadow root 안, `html` 바로 아래에 `position:fixed` + `pointer-events:none` 으로 둔다
     *   (read_page 의 요소 목록 · innerText · elementFromPoint 에 잡히지 않는다).
     * - 사이트의 CSP 에 막히지 않게 <style> · innerHTML 을 쓰지 않고 CSSOM(style.setProperty) · createElementNS · Web Animations 만 쓴다.
     * - 실패해도 조작 자체는 계속되게 전부 try/catch 로 감싼다. 한 페이지에 한 번만 깔고 `window.__evgFx` 에 둔다.
     * 주의: 이 안에서는 글자 템플릿(달러 기호 + 중괄호)과 큰따옴표 세 개를 쓰지 않는다 (코틀린 raw string 이라서).
     */
    private const val FXLIB = """
(function(){try{
if(window.__evgFx)return;
var ST=__GRAD__;
var WARM=['#F5A524','#E8741A','#E5484D'],BAD=['#E5484D','#C73A6B','#8E3AA8'];
var STAR='M12 0 C12.8 7.2 16.8 11.2 24 12 C16.8 12.8 12.8 16.8 12 24 C11.2 16.8 7.2 12.8 0 12 C7.2 11.2 11.2 7.2 12 0 Z';
var host=null,root=null,layer=null,cursor=null,cp=null,star=null,tint=null,ring=null,chip=null,chipTxt=null,mbox=null;
var sPop=null,sSpin=null,loops=[];
var sx=0,sy=0,svx=0,svy=0,stx=0,sty=0,sraf=0,slast=0,sInit=false,sFar=0;
var ACC=ST[Math.min(2,ST.length-1)];
var ARROW='M5.4 3.6 C5.1 2.8 5.8 2.5 6.4 2.9 L19 11.4 C19.7 11.9 19.5 12.7 18.7 12.9 L13.6 14.2 C13.2 14.3 12.9 14.5 12.7 14.9 L10.4 19.6 C10 20.4 9.2 20.3 9 19.5 Z';
var pos=null,track=null,rad=10,raf=0,mraf=0,timer=0,tick=0,token=0,curKey='',aimPtF=null,arriveAt=0;
function css(e,o){for(var k in o){e.style.setProperty(k,o[k]);}return e;}
function mk(t,o,par){var e=document.createElement(t);css(e,o);if(par)par.appendChild(e);return e;}
function sv(t,a,par){var e=document.createElementNS('http://www.w3.org/2000/svg',t);for(var k in a)e.setAttribute(k,a[k]);if(par)par.appendChild(e);return e;}
function cutS(s,n){s=String(s||'').replace(/\s+/g,' ').trim();return s.length>n?s.slice(0,n)+'…':s;}
function lg(c,deg){return 'linear-gradient('+(deg===undefined?90:deg)+'deg,'+c.join(',')+')';}
function rgb(h){var n=parseInt(h.slice(1),16);return [(n>>16)&255,(n>>8)&255,n&255];}
function rgba(h,a){var v=rgb(h);return 'rgba('+v[0]+','+v[1]+','+v[2]+','+a+')';}
function colorAt(t){
  t=Math.max(0,Math.min(1,t));
  var n=ST.length-1,x=t*n,i=Math.min(n-1,Math.floor(x)),f=x-i,a=rgb(ST[i]),b=rgb(ST[i+1]);
  return 'rgb('+Math.round(a[0]+(b[0]-a[0])*f)+','+Math.round(a[1]+(b[1]-a[1])*f)+','+Math.round(a[2]+(b[2]-a[2])*f)+')';
}
var RINGMASK={'-webkit-mask':'linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)','-webkit-mask-composite':'xor','mask':'linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)'};
/** 흐르는 그라데이션 배경 (색이 한 칸씩 옆으로 흐른다) */
function paint(e,c,dur){
  try{e.getAnimations().forEach(function(a){a.cancel();});}catch(x){}
  css(e,{'background':lg(c.concat(c,[c[0]])),'background-size':'200% 100%'});
  try{e.animate([{backgroundPosition:'0% 0'},{backgroundPosition:'100% 0'}],{duration:dur||2600,iterations:Infinity,easing:'linear'});}catch(x){}
}
function ensure(){
  if(host&&host.isConnected&&root)return;
  curKey='';
  host=document.createElement('div');
  css(host,{'all':'initial','position':'fixed','left':'0','top':'0','width':'0','height':'0','z-index':'2147483647','pointer-events':'none'});
  root=host.attachShadow({mode:'closed'});
  (document.documentElement||document.body).appendChild(host);
  layer=mk('div',{'position':'fixed','left':'0','top':'0','width':'100vw','height':'100vh','overflow':'hidden','pointer-events':'none','opacity':'0','transition':'opacity .22s'},root);
  tint=mk('div',{'position':'fixed','left':'0','top':'0','width':'0','height':'0','box-sizing':'border-box','border-radius':'14px','opacity':'0'},layer);
  ring=mk('div',{'position':'fixed','left':'0','top':'0','width':'0','height':'0','box-sizing':'border-box','padding':'2px','border-radius':'14px','opacity':'0'},layer);
  css(ring,RINGMASK);
  chip=mk('div',{'position':'fixed','left':'0','top':'0','display':'flex','align-items':'center','gap':'6px','max-width':'min(88vw,340px)','box-sizing':'border-box','padding':'6px 12px 6px 9px','border-radius':'999px','color':'#fff','font':'600 12px/1.25 system-ui,-apple-system,Roboto,sans-serif','white-space':'nowrap','box-shadow':'0 2px 10px rgba(0,0,0,.22)','opacity':'0','transition':'background .2s'},layer);
  var ic=sv('svg',{width:'13',height:'13',viewBox:'0 0 24 24'},chip);
  css(ic,{'flex':'none'});
  var df0=sv('defs',{},ic),g0=sv('linearGradient',{id:'evgC',x1:'0',y1:'0',x2:'1',y2:'1'},df0);
  for(var j=0;j<ST.length;j++)sv('stop',{offset:String(ST.length>1?j/(ST.length-1):0),'stop-color':ST[j]},g0);
  sv('path',{d:STAR,fill:'url(#evgC)'},ic);
  chipTxt=mk('span',{'overflow':'hidden','text-overflow':'ellipsis'},chip);
  // 커서: 화살표 포인터 + 그 옆을 살짝 늦게 따라다니는 그라데이션 별 (그라데이션은 별에만)
  cursor=mk('div',{'position':'fixed','left':'0','top':'0','width':'0','height':'0','opacity':'0'},layer);
  cp=mk('div',{'position':'absolute','left':'0','top':'0','width':'0','height':'0'},cursor);
  var ar=sv('svg',{width:'20',height:'20',viewBox:'0 0 24 24'},cp);
  css(ar,{'position':'absolute','left':'-4.4px','top':'-2.4px','overflow':'visible','filter':'drop-shadow(0 1px 2px rgba(0,0,0,.35))'});
  var dfa=sv('defs',{},ar),ga=sv('linearGradient',{id:'evgA',x1:'0',y1:'0',x2:'1',y2:'1'},dfa);
  for(var k=0;k<ST.length;k++)sv('stop',{offset:String(ST.length>1?k/(ST.length-1):0),'stop-color':ST[k]},ga);
  sv('path',{d:ARROW,fill:'url(#evgA)',stroke:'#fff','stroke-width':'1.6','stroke-linejoin':'round','paint-order':'stroke'},ar);
  // 별: 겉(star)은 스프링으로 따라오고, 안쪽은 [클릭 팝] 순서로 겹친다 (별은 돌지 않는다)
  star=mk('div',{'position':'fixed','left':'0','top':'0','width':'0','height':'0','opacity':'0'},layer);
  sInit=false;cancelAnimationFrame(sraf);sraf=0;loops=[];
  sPop=mk('div',{'position':'absolute','left':'0','top':'0','width':'19px','height':'19px'},star);
  sSpin=mk('div',{'position':'absolute','left':'0','top':'0','width':'19px','height':'19px'},sPop);
  var s=sv('svg',{width:'19',height:'19',viewBox:'0 0 24 24'},sSpin);
  css(s,{'overflow':'visible','filter':'drop-shadow(0 1px 2px rgba(0,0,0,.28))'});
  var df=sv('defs',{},s),g=sv('linearGradient',{id:'evgG',x1:'0',y1:'0',x2:'1',y2:'1'},df);
  for(var i=0;i<ST.length;i++)sv('stop',{offset:String(ST.length>1?i/(ST.length-1):0),'stop-color':ST[i]},g);
  sv('path',{d:STAR,fill:'url(#evgG)',stroke:'#fff','stroke-width':'2.4','stroke-linejoin':'round','paint-order':'stroke'},s);
}
/** 별 보조: 스프링 따라오기 · 클릭 팝 */
function loopsRun(on){for(var i=0;i<loops.length;i++){try{if(on)loops[i].play();else loops[i].pause();}catch(e){}}}
function popStar(k){
  try{sPop.animate([{transform:'scale(1)'},{transform:'scale('+k+')',offset:.4},{transform:'scale(1)'}],{duration:380,easing:'cubic-bezier(.3,1.3,.5,1)'});}catch(e){}
}
function applyStar(){star.style.setProperty('transform','translate('+sx+'px,'+sy+'px)');}
function starTo(x,y,snap){
  stx=x+6;sty=Math.max(2,y-9);
  if(snap||!sInit){sx=stx;sy=sty;svx=0;svy=0;sInit=true;applyStar();return;}
  if(!sraf){slast=0;sraf=requestAnimationFrame(stepStar);}
}
/** 별은 화살표가 가는 자리를 스프링으로 쫓아간다: 살짝 늦게 따라오고 도착할 때 한 번 출렁인다 */
function stepStar(ts){
  sraf=0;
  if(!star||!star.isConnected)return;
  var dt=slast?Math.min(.034,(ts-slast)/1000):.016;slast=ts;
  var ox=sx,oy=sy;
  svx+=((stx-sx)*170-svx*20)*dt;svy+=((sty-sy)*170-svy*20)*dt;
  sx+=svx*dt;sy+=svy*dt;
  applyStar();
  var sp=Math.sqrt(svx*svx+svy*svy);
  sFar+=Math.sqrt((sx-ox)*(sx-ox)+(sy-oy)*(sy-oy));
  if(sp<5&&Math.abs(stx-sx)<.5&&Math.abs(sty-sy)<.5){
    sx=stx;sy=sty;svx=0;svy=0;applyStar();slast=0;sFar=0;
    return;
  }
  sraf=requestAnimationFrame(stepStar);
}
function clearMarks(){cancelAnimationFrame(mraf);if(mbox){var o=mbox;mbox=null;try{var op=getComputedStyle(o).opacity,fa=o.animate([{opacity:op},{opacity:0}],{duration:280,easing:'ease-out',fill:'forwards'});fa.onfinish=function(){try{o.remove();}catch(e){}};}catch(e){try{o.remove();}catch(x){}}}}
function stop(){clearTimeout(timer);clearInterval(tick);cancelAnimationFrame(raf);token++;}
function show(){ensure();layer.style.setProperty('opacity','1');loopsRun(true);}
function hide(){
  stop();track=null;
  if(!layer)return;
  layer.style.setProperty('opacity','0');
  var my=token;
  setTimeout(function(){if(my===token){clearMarks();if(ring)ring.style.setProperty('opacity','0');if(tint)tint.style.setProperty('opacity','0');if(layer.style.getPropertyValue('opacity')==='0')loopsRun(false);}},300);
}
function later(ms){clearTimeout(timer);timer=setTimeout(hide,ms);}
function setChip(kind,text){
  var bad=(kind==='warn'||kind==='fail'),key=kind==='ask'?'w':(bad?'b':'n');
  if(key!==curKey){
    curKey=key;
    var cc=key==='w'?'#E8941A':(key==='b'?'#E5484D':ACC);
    var bg=key==='w'?'rgba(150,88,10,.94)':(key==='b'?'rgba(160,40,48,.94)':'rgba(28,28,34,.88)');
    css(chip,{'background':bg});
    css(ring,{'background':cc});
    css(tint,{'background':rgba(cc,.07),'box-shadow':'none'});
  }
  chip.style.setProperty('opacity','1');
  chipTxt.textContent=text;
}
function pop(e){try{e.animate([{transform:'translateY(6px) scale(.92)',opacity:0},{transform:'none',opacity:1}],{duration:180,easing:'ease-out'});}catch(x){}}
function box(l,t,w,h,r){var o={'left':l+'px','top':t+'px','width':w+'px','height':h+'px','border-radius':r+'px'};css(ring,o);css(tint,o);}
function statusPlace(){var cw=chip.offsetWidth,ch=chip.offsetHeight;css(chip,{'left':Math.max(8,(innerWidth-cw)/2)+'px','top':Math.max(8,innerHeight-ch-28)+'px'});}
function place(){
  if(!track)return;
  if(!track.isConnected){track=null;ring.style.setProperty('opacity','0');tint.style.setProperty('opacity','0');statusPlace();return;}
  var r=track.getBoundingClientRect(),p=4;
  box(r.left-p,r.top-p,r.width+2*p,r.height+2*p,rad);
  if(aimPtF&&pos&&Date.now()>=arriveAt){
    var c=aimPtF();
    if(Math.abs(c.x-pos.x)>1.5||Math.abs(c.y-pos.y)>1.5)setCur(c.x,c.y);
  }
  var cw=chip.offsetWidth,ch=chip.offsetHeight;
  var x=Math.max(8,Math.min(innerWidth-cw-8,r.left-p));
  var y=r.top-p-ch-8;
  if(y<8)y=Math.min(innerHeight-ch-8,r.bottom+p+8);
  css(chip,{'left':x+'px','top':y+'px'});
  raf=requestAnimationFrame(place);
}
function setCur(x,y){
  try{cursor.getAnimations().forEach(function(a){a.cancel();});}catch(e){}
  cursor.style.setProperty('transform','translate('+x+'px,'+y+'px)');
  starTo(x,y);
  pos={x:x,y:y};
}
/** 지금 화면에 보이는 화살표 자리 (움직이는 도중이면 그 중간 자리). 새 이동이 중간에 시작돼도 튀지 않게 여기서 출발한다 */
function curNow(){
  try{var m=new DOMMatrix(getComputedStyle(cursor).transform);if(isFinite(m.e)&&isFinite(m.f))return {x:m.e,y:m.f};}catch(e){}
  return pos;
}
function moveTo(x,y,dur0,ease){
  var f=(pos&&curNow())||pos||{x:innerWidth*0.5,y:innerHeight*0.88};
  var d=Math.sqrt((x-f.x)*(x-f.x)+(y-f.y)*(y-f.y));
  var dur=dur0||(pos?Math.max(240,Math.min(620,Math.round(d*1.1))):520);
  cursor.style.setProperty('opacity','1');star.style.setProperty('opacity','1');
  loopsRun(true);
  try{cursor.getAnimations().forEach(function(a){a.cancel();});}catch(e){}
  try{cursor.animate([{transform:'translate('+f.x+'px,'+f.y+'px)'},{transform:'translate('+x+'px,'+y+'px)'}],{duration:dur,easing:ease||'cubic-bezier(.22,.8,.25,1)'});}catch(e){}
  cursor.style.setProperty('transform','translate('+x+'px,'+y+'px)');
  // 별은 화살표 오른쪽 위에서 스프링으로 살짝 늦게 따라온다 (처음 나올 때는 출발 자리에서 시작)
  if(!sInit)starTo(f.x,f.y,true);
  starTo(x,y);
  pos={x:x,y:y};
  arriveAt=Date.now()+dur+220;
  return dur;
}
var VERB={drag:'끌 준비',click:'누르는 중',type:'입력 중',select:'고르는 중',check:'체크 바꾸는 중',scroll:'이 요소로 스크롤',ask:'확인을 기다리는 중',warn:'직접 입력해 주세요'};
/** 요소를 짚는다. 돌려주는 값 = 눈에 보이게 기다려야 할 시간(ms) */
function aim(el,kind,lb,text,hold,pt){
  show();stop();clearMarks();
  var my=token;
  track=el;
  var r=el.getBoundingClientRect(),cs=getComputedStyle(el);
  rad=Math.max(12,Math.min(30,(parseFloat(cs.borderTopLeftRadius)||0)+8));
  aimPtF=function(){
    if(pt&&pt.cx!==undefined){var q=pt.cx();return {x:Math.max(6,Math.min(innerWidth-6,q.x)),y:Math.max(6,Math.min(innerHeight-6,q.y))};}
    var rr=el.getBoundingClientRect();
    return {x:Math.max(6,Math.min(innerWidth-6,rr.left+rr.width/2)),y:Math.max(6,Math.min(innerHeight-6,rr.top+rr.height/2))};
  };
  var p0=aimPtF();
  var dur=moveTo(p0.x,p0.y);
  ring.style.setProperty('opacity','1');tint.style.setProperty('opacity','1');
  var name=lb?' · 「'+cutS(lb,22)+'」':'';
  var extra=0;
  if(kind==='type'&&text){
    var full=String(text).replace(/\s+/g,' '),n=full.length,steps=Math.min(n,18),i=0;
    setChip(kind,'입력 중 · ▍');
    setTimeout(function(){
      if(my!==token)return;
      tick=setInterval(function(){
        if(my!==token){clearInterval(tick);return;}
        i++;
        var sh=full.slice(0,Math.ceil(n*i/steps));
        if(sh.length>26)sh='…'+sh.slice(sh.length-26);
        chipTxt.textContent='입력 중 · '+sh+(i<steps?'▍':'');
        if(i>=steps)clearInterval(tick);
      },40);
    },dur);
    extra=steps*40+160;
  }else if(kind==='select'&&text){
    setChip(kind,'고르는 중 · '+cutS(text,26));
  }else{
    setChip(kind,(VERB[kind]||'다루는 중')+name);
  }
  pop(chip);
  place();
  later(hold>0?hold:4000);
  return dur+extra+260;
}
function ripple(){
  if(!layer||!pos)return;
  var x=pos.x,y=pos.y;
  var rp=mk('div',{'position':'fixed','left':(x-20)+'px','top':(y-20)+'px','width':'40px','height':'40px','box-sizing':'border-box','border':'2px solid '+rgba(ACC,.85),'border-radius':'50%'},layer);
  try{var a=rp.animate([{transform:'scale(.2)',opacity:1},{transform:'scale(1.9)',opacity:0}],{duration:520,easing:'ease-out'});a.onfinish=function(){rp.remove();};}catch(e){rp.remove();}
  try{cp.animate([{transform:'scale(1)'},{transform:'scale(.88)'},{transform:'scale(1)'}],{duration:260});}catch(e){}
  popStar(1.12);
  setChip('click','✓ 눌렀어요');
  later(1100);
}
function done(text,kind){show();setChip(kind||'click','✓ '+text);if(!track)statusPlace();later(1100);}
function failFx(msg){
  show();stop();clearMarks();
  var had=!!track;
  setChip('fail','✕ '+cutS(msg,60));
  if(!had){ring.style.setProperty('opacity','0');tint.style.setProperty('opacity','0');statusPlace();}else{place();}
  pop(chip);
  later(2600);
}
/** read_page: 알갱이 · 요소 빛 · 상자 없이, 화면 아래에서 번지는 배경 빛만 천천히 일렁이고 아래쪽 "페이지 읽는 중…" 이름표가 뜬다.
 *  배경 빛이 남아 있는 동안 또 읽으면 새로 만들지 않고 같은 빛을 이어서 연장해 끊기지 않는다. 자리 · 크기 · 색 · 길이는 매번 다르다 */
var washBox=null,wtimer=0;
function ca(t,a){return colorAt(t).replace('rgb(','rgba(').replace(')',','+a+')');}
function rnd(a,b){return a+Math.random()*(b-a);}
function marks(arr,total){
  show();stop();track=null;
  ring.style.setProperty('opacity','0');tint.style.setProperty('opacity','0');
  var D=Math.round(rnd(2400,3400)),bx;
  if(washBox&&mbox===washBox&&washBox.isConnected){
    bx=washBox;bx.style.setProperty('opacity','1');
  }else{
    clearMarks();
    bx=mk('div',{'position':'fixed','left':'0','top':'0','width':'100vw','height':'100vh','overflow':'hidden','pointer-events':'none','opacity':'0','transition':'opacity .8s ease'},layer);
    mbox=bx;washBox=bx;
    layer.insertBefore(bx,layer.firstChild); // 빛은 맨 아래 층: 이름표 · 커서가 위에 보인다
    var M=Math.max(innerWidth,innerHeight),hue0=Math.random(),dir=Math.random()<.5?1:-1,nb=3,i;
    for(i=0;i<nb;i++){
      var sz=Math.round(M*rnd(.75,1.15)),px=rnd(-5,105),py=(i<2)?rnd(70,108):rnd(25,60),h=((hue0+dir*i*.26)%1+1)%1;
      var bl=mk('div',{'position':'absolute','left':'calc('+px+'vw - '+(sz/2)+'px)','top':'calc('+py+'vh - '+(sz/2)+'px)','width':sz+'px','height':sz+'px','border-radius':'50%','opacity':String(rnd(.4,.55)),'will-change':'transform',
        'background':'radial-gradient(closest-side,'+ca(h,.8)+' 0%,'+ca(h,.3)+' 45%,'+ca(0,0)+' 100%)'},bx);
      var ax=rnd(14,26)*(Math.random()<.5?-1:1),ay=rnd(8,18)*(Math.random()<.5?-1:1);
      try{bl.animate([{transform:'translate('+(-ax)+'vw,'+(-ay)+'vh) scale(.85)'},{transform:'translate('+ax+'vw,'+ay+'vh) scale(1.15)'}],{duration:Math.round(rnd(4200,6000)),iterations:Infinity,direction:'alternate',easing:'ease-in-out'});}catch(e){}
    }
    requestAnimationFrame(function(){requestAnimationFrame(function(){bx.style.setProperty('opacity','1');});});
  }
  clearTimeout(wtimer);
  wtimer=setTimeout(function(){if(mbox===bx)bx.style.setProperty('opacity','0');},D);
  setChip('click','페이지 읽는 중…');
  statusPlace();pop(chip);
  later(D+1000);
}
/** scroll_page: 오른쪽 가장자리에 위치 막대 + 방향 이름표 */
function scrollFx(dir,pct,moved){
  show();stop();clearMarks();track=null;
  ring.style.setProperty('opacity','0');tint.style.setProperty('opacity','0');
  var bx=mk('div',{'position':'fixed','left':'0','top':'0','width':'100vw','height':'100vh'},layer);
  mbox=bx;
  var th=innerHeight*0.5,ty=innerHeight*0.25,tx=innerWidth-12;
  mk('div',{'position':'fixed','left':tx+'px','top':ty+'px','width':'5px','height':th+'px','border-radius':'3px','background':'rgba(0,0,0,.18)','box-shadow':'0 0 0 1px rgba(255,255,255,.45)'},bx);
  var hh=Math.max(22,th*0.18);
  var thumb=mk('div',{'position':'fixed','left':tx+'px','width':'5px','height':hh+'px','border-radius':'3px','background':rgba(ACC,.9),'top':(ty+(th-hh)*(Math.max(0,Math.min(100,pct))/100))+'px'},bx);
  try{thumb.animate([{opacity:.3},{opacity:1}],{duration:260});}catch(e){}
  var up=(dir==='up'||dir==='top');
  var nm=dir==='top'?'맨 위로':(dir==='bottom'?'맨 아래로':(up?'위로 스크롤':'아래로 스크롤'));
  setChip('click',moved?((up?'↑ ':'↓ ')+nm+' · '+pct+'%'):'더 갈 곳이 없어요 · '+pct+'%');
  statusPlace();pop(chip);
  later(1300);
}
/** 끌기: 커서와 별이 도착 자리까지 [dur] ms 동안 따라 움직이고 이름표를 바꾼다. 페이지의 실제 끌기도 같은 시간·곡선으로 진행된다 */
function dragTo(x,y,text,dur){
  show();
  var d=moveTo(x,y,dur,'cubic-bezier(.42,0,.58,1)');
  aimPtF=function(){return {x:x,y:y};};
  setChip('click','끄는 중 · '+cutS(text,22));
  later(d+1300);
  return d;
}
var API={dragTo:dragTo,aim:aim,ripple:ripple,done:done,fail:failFx,marks:marks,scroll:scrollFx,hide:hide,v:19};
try{Object.defineProperty(window,'__evgFx',{value:API,configurable:true,writable:true,enumerable:false});}catch(e){window.__evgFx=API;}
}catch(e){}})();
"""

    /** 모든 스크립트가 같이 쓰는 도우미 함수들. 요소 목록은 페이지 안 `window.__evgS` 에 둔다 (나열되지 않게 숨김) */
    private const val PRE = """
var S=window.__evgS;
if(!S){S={els:[null]};try{Object.defineProperty(window,'__evgS',{value:S,configurable:true,writable:true,enumerable:false});}catch(e){window.__evgS=S;}}
var IN_FRAME=false;try{IN_FRAME=(window.top!==window);}catch(e){IN_FRAME=true;}
var PAYF=IN_FRAME&&/stripe|paypal|braintree|adyen|checkout\.com|toss|iamport|portone|kakaopay|naverpay|nicepay|inicis|kcp\.co|payment|billing|secure\.pay|\bpay\./i.test(location.hostname);
function fail(m,x){try{if(FX&&FX.fail)FX.fail(m);}catch(e0){}var o={ok:false,error:m};if(x){for(var k in x)o[k]=x[k];}return JSON.stringify(o);}
function cut(s,n){s=(s||'').replace(/\s+/g,' ').trim();return s.length>n?s.slice(0,n)+'…':s;}
function isVis(el){var r=el.getBoundingClientRect();if(r.width<1||r.height<1)return false;var cs=getComputedStyle(el);return !(cs.visibility==='hidden'||cs.display==='none'||parseFloat(cs.opacity)===0);}
function inView(el){var r=el.getBoundingClientRect();return r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;}
function secret(el){
  if(el.tagName!=='INPUT'&&el.tagName!=='TEXTAREA')return false;
  if(PAYF)return true;
  var t=(el.type||'').toLowerCase();
  if(t==='password')return true;
  var ac=(el.getAttribute('autocomplete')||'').toLowerCase();
  if(/cc-|password|one-time-code/.test(ac))return true;
  var nm=((el.name||'')+' '+(el.id||'')).toLowerCase();
  return /passw|pwd|cvc|cvv|card.?num|cardnum|ssn|otp|\bpin\b|주민/.test(nm);
}
function kindOf(el){
  var tg=el.tagName;
  if(tg==='A')return 'link';
  if(tg==='SELECT')return 'select';
  if(tg==='TEXTAREA')return 'textarea';
  if(tg==='INPUT'){
    var t=(el.type||'text').toLowerCase();
    if(t==='checkbox')return 'checkbox';
    if(t==='radio')return 'radio';
    if(t==='file')return 'file';
    if(t==='submit'||t==='button'||t==='reset'||t==='image')return 'button';
    if(t==='range')return 'slider';
    return 'text';
  }
  if(tg==='BUTTON'||tg==='SUMMARY')return 'button';
  if(el.isContentEditable)return 'text';
  var r=(el.getAttribute('role')||'').toLowerCase();
  if(r==='link')return 'link';
  if(r==='checkbox'||r==='switch')return 'checkbox';
  return 'button';
}
function label(el){
  var t=el.getAttribute('aria-label')||'';
  if(!t&&el.labels&&el.labels.length)t=el.labels[0].innerText||el.labels[0].textContent||'';
  var tg=el.tagName;
  var isIn=(tg==='INPUT'||tg==='TEXTAREA'||tg==='SELECT');
  if(!t&&isIn)t=el.getAttribute('placeholder')||'';
  if(!t&&!isIn)t=el.innerText||el.textContent||'';
  if(!t)t=el.getAttribute('title')||el.getAttribute('alt')||'';
  if(!t&&el.querySelector){var im=el.querySelector('img[alt]');if(im)t=im.getAttribute('alt')||'';}
  if(!t&&tg==='INPUT'){var ty=(el.type||'').toLowerCase();if(ty==='submit'||ty==='button'||ty==='reset')t=el.value||'';}
  if(!t)t=el.getAttribute('name')||'';
  return cut(t,60);
}
function isSubmit(el){
  var tg=el.tagName;
  if(tg==='INPUT'){var t=(el.type||'').toLowerCase();return t==='submit'||t==='image';}
  if(tg==='BUTTON')return !!el.form&&((el.getAttribute('type')||'submit').toLowerCase()==='submit');
  return false;
}
function hrefOf(el){
  var h=el.href||'';
  try{var u=new URL(h,location.href);return u.origin===location.origin?cut(u.pathname+u.search,90):cut(u.origin+u.pathname+u.search,100);}catch(e){return cut(h,100);}
}
function canScroll(e){var oy=getComputedStyle(e).overflowY;return (oy==='auto'||oy==='scroll'||oy==='overlay')&&e.scrollHeight>e.clientHeight+1;}
function clipped(el){
  var r=el.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,p=el.parentElement;
  while(p&&p!==document.body&&p!==document.documentElement){
    var cs=getComputedStyle(p);
    if(/(auto|scroll|hidden|clip|overlay)/.test(cs.overflowY+' '+cs.overflowX)){
      var pr=p.getBoundingClientRect();
      if(cy<pr.top||cy>pr.bottom||cx<pr.left||cx>pr.right)return true;
    }
    p=p.parentElement;
  }
  return false;
}
function scrollBy0(p,dy){var t=p.scrollTop+dy;try{p.scrollTo({top:t,left:p.scrollLeft,behavior:'instant'});}catch(e){p.scrollTop=t;}}
function safeScroll(el){
  safeScroll0(el);
  if(IN_FRAME){try{el.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'});}catch(e){}}
}
function safeScroll0(el){
  var r=el.getBoundingClientRect();
  if(r.top>=0&&r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth&&!clipped(el))return;
  var p=el.parentElement;
  while(p&&p!==document.body&&p!==document.documentElement){
    if(canScroll(p)){var pr=p.getBoundingClientRect(),er=el.getBoundingClientRect();scrollBy0(p,(er.top+er.height/2)-(pr.top+pr.height/2));}
    p=p.parentElement;
  }
  var r2=el.getBoundingClientRect();
  if(r2.top<0||r2.bottom>innerHeight){
    var se=document.scrollingElement||document.documentElement;
    if(se.scrollHeight>innerHeight+1){var y=Math.max(0,Math.min(se.scrollHeight-innerHeight,window.pageYOffset+(r2.top+r2.height/2)-innerHeight/2));try{window.scrollTo({top:y,left:window.pageXOffset,behavior:'instant'});}catch(e){window.scrollTo(window.pageXOffset,y);}}
  }
}
function pick(id){var el=S.els[id];return (el&&el.isConnected)?el:null;}
var GONE='그 요소를 찾을 수 없어요. 페이지가 바뀌었을 수 있으니 read_page 로 다시 읽어 주세요';
"""

    /** 페이지 글 + 요소 목록. P.scope = viewport | all, P.text = true | false, P.max = 요소 최대 개수(기본 60) */
    private const val READ = """
var scope=P.scope,withText=P.text;
var sel='a[href],button,input:not([type=hidden]),textarea,select,summary,[role=button],[role=link],[role=checkbox],[role=switch],[role=tab],[role=menuitem],[role=option],[contenteditable=""],[contenteditable="true"],[onclick]';
var found=[];
function collect(root){var l=root.querySelectorAll(sel);for(var i=0;i<l.length;i++)found.push(l[i]);}
collect(document);
var every=document.querySelectorAll('*');
if(every.length<6000){for(var q=0;q<every.length;q++){if(every[q].shadowRoot)collect(every[q].shadowRoot);}}
var seen=new Set(),inc=new Set(),list=[];
for(var i=0;i<found.length;i++){
  var el=found[i];
  if(seen.has(el))continue;
  seen.add(el);
  var tg=el.tagName;
  if(tg==='BODY'||tg==='HTML')continue;
  if(!isVis(el))continue;
  var isIn=(tg==='INPUT'||tg==='TEXTAREA'||tg==='SELECT');
  if(!isIn){
    var up=el.parentElement&&el.parentElement.closest('a[href],button,[role=button],[role=link]');
    if(up&&up!==el&&inc.has(up))continue;
    var rr=el.getBoundingClientRect();
    if(tg!=='A'&&tg!=='BUTTON'&&rr.width*rr.height>0.7*innerWidth*innerHeight)continue;
  }
  inc.add(el);
  list.push(el);
}
S.els=[null];
var out=[],total=list.length,marked=[];
for(var j=0;j<list.length;j++){
  var e=list[j];
  if(scope==='viewport'&&!inView(e))continue;
  if(out.length>=(P.max||60))break;
  S.els.push(e);
  marked.push([e,S.els.length-1]);
  var k=kindOf(e);
  var o={element:S.els.length-1,kind:k,label:label(e)};
  if(k==='link'){o.href=hrefOf(e);if(e.target==='_blank')o.new_tab=true;}
  if(k==='text'||k==='textarea'||k==='slider'){
    if(secret(e))o.secret=true;
    else{var v=(e.value!==undefined)?e.value:e.textContent;if(v)o.value=cut(v,60);}
  }
  if(k==='checkbox'||k==='radio'){o.checked=(e.checked!==undefined)?!!e.checked:(e.getAttribute('aria-checked')==='true');}
  if(k==='select'){
    var op=[];
    for(var m=0;m<e.options.length&&m<10;m++)op.push(cut(e.options[m].text,30)+(e.options[m].selected?' *':''));
    o.options=op;
    if(e.options.length>10)o.option_count=e.options.length;
  }
  if(isSubmit(e))o.submit=true;
  if(e.disabled)o.disabled=true;
  if(scope==='all'&&!inView(e))o.offscreen=true;
  out.push(o);
}
var se=document.scrollingElement||document.documentElement;
var res={url:cut(location.href,300),title:cut(document.title,100),loading:document.readyState!=='complete',
  scroll:{y:Math.round(window.pageYOffset),max:Math.max(0,Math.round(se.scrollHeight-innerHeight)),view:innerHeight},
  shown:out.length,total:total,elements:out};
var dlg=document.querySelector('[role=dialog],[role=alertdialog],[aria-modal=true],dialog[open]');
if(dlg&&isVis(dlg))res.popup=cut(dlg.innerText,120);
if(withText)res.text=cut(document.body?document.body.innerText:'',2000);
var nf=document.querySelectorAll('iframe,frame').length;
if(nf)res.iframes=nf;
if(nf&&!IN_FRAME){var il=[],fl=document.querySelectorAll('iframe,frame');for(var u=0;u<fl.length&&il.length<10;u++){var fe=fl[u],fq=fe.getBoundingClientRect();if(fq.width<40||fq.height<40||!isVis(fe))continue;il.push({src:cut(fe.getAttribute('src')||'(srcdoc)',100),w:Math.round(fq.width),h:Math.round(fq.height),y:Math.round(fq.top),in_view:inView(fe)});}if(il.length)res.iframe_boxes=il;}
if(IN_FRAME)res.frame={url:cut(location.href,200),title:cut(document.title,80),w:innerWidth,h:innerHeight,visible:P.vis!==false};
if(!IN_FRAME)fx(function(F){F.marks(marked,out.length);});
return JSON.stringify(res);
"""

    /**
     * 누르기 · 입력 전에 가상 커서가 그 요소로 가서 짚어 준다 (실제 동작은 하지 않는다).
     * P.id = 요소 번호, P.kind = click | fill | scroll | ask, P.hold = 표시를 유지할 시간(ms), P.val = 쓸 글(fill · ask 일 때)
     * 돌려주는 ms = 눈에 보이게 기다려 줄 시간
     */
    private const val AIM = """
var el=pick(P.id);
if(!el)return fail(GONE);
safeScroll(el);
var kind=P.kind,txt=P.val,lb=label(el),k=kindOf(el);
if(kind==='fill'){
  if(secret(el)){kind='warn';txt='';}
  else if(k==='select')kind='select';
  else if(k==='checkbox'||k==='radio'){kind='check';txt='';}
  else kind='type';
}
if(kind==='ask'&&secret(el))txt='';
var pt=null;
if(kind==='drag'&&el.tagName==='INPUT'&&(el.type||'').toLowerCase()==='range'){
  pt={cx:function(){var q=el.getBoundingClientRect(),mn=parseFloat(el.min||'0'),mx=parseFloat(el.max||'100'),f=mx>mn?(parseFloat(el.value)-mn)/(mx-mn):0;return {x:q.left+9+Math.max(0,Math.min(1,f))*Math.max(1,q.width-18),y:q.top+q.height/2};}};
}
var ms=0;
fx(function(F){ms=F.aim(el,kind,lb,txt,P.hold,pt);});
return JSON.stringify({ok:true,ms:ms});
"""

    /** 요소 한 개의 이름 · 종류 · 위험 신호만 알아 온다 (확인 카드와 위험도 판단에 쓴다). P.id = 요소 번호 */
    private const val INFO = """
var el=pick(P.id);
if(!el)return fail(GONE);
var h=(el.tagName==='A')?(el.href||''):'';
var dl=el.hasAttribute('download')||/\.(apk|exe|msi|dmg|zip|rar|7z|jar)(?![a-z0-9])/i.test(h.split(/[?#]/)[0]);
return JSON.stringify({ok:true,label:label(el),kind:kindOf(el),submit:isSubmit(el),secret:secret(el),download:dl,href:cut(h,120),frame:IN_FRAME?cut(location.hostname,60):''});
"""

    /** 요소 누르기. P.id = 요소 번호 */
    private const val CLICK = """
var el=pick(P.id);
if(!el)return fail(GONE);
if(el.disabled||el.getAttribute('aria-disabled')==='true')return fail('비활성화된 요소라 누를 수 없어요');
if(el.tagName==='A'){
  var h=el.href||'';
  if(/^(javascript|intent|mailto|tel|sms|market|file|content|data|blob):/i.test(h))return fail('앱을 부르거나 스크립트를 실행하는 링크는 누르지 않아요');
  if(el.target==='_blank')return fail('새 탭으로 열리는 링크예요. open_tab 으로 이 주소를 열어 주세요',{href:cut(h,300)});
}
safeScroll(el);
var r=el.getBoundingClientRect();
var x=Math.min(innerWidth-1,Math.max(0,r.left+r.width/2)),y=Math.min(innerHeight-1,Math.max(0,r.top+r.height/2));
var top=document.elementFromPoint(x,y);
if(top&&top!==el&&!el.contains(top)&&!top.contains(el)){
  var rt=el.getRootNode&&el.getRootNode();
  if(!(rt&&rt.host&&(rt.host===top||rt.host.contains(top)))){
    return fail('다른 요소가 가리고 있어요: '+(label(top)||top.tagName.toLowerCase())+' (팝업이나 광고를 먼저 닫아야 할 수 있어요)');
  }
}
var base={bubbles:true,cancelable:true,composed:true,view:window,clientX:x,clientY:y,button:0};
function send(type,C,buttons){try{var o={};for(var k in base)o[k]=base[k];o.buttons=buttons;el.dispatchEvent(new C(type,o));}catch(e){}}
if(window.PointerEvent)send('pointerdown',PointerEvent,1);
send('mousedown',MouseEvent,1);
if(window.PointerEvent)send('pointerup',PointerEvent,0);
send('mouseup',MouseEvent,0);
fx(function(F){F.ripple();});
el.click();
return JSON.stringify({ok:true,label:label(el),kind:kindOf(el)});
"""

    /** 입력칸 쓰기 · 선택 상자 고르기 · 체크 켜고 끄기. P.id = 요소 번호, P.val = 값, P.submit = true | false */
    private const val FILL = """
var el=pick(P.id),V=String(P.val),submit=!!P.submit;
if(!el)return fail(GONE);
if(el.disabled||el.readOnly)return fail('쓸 수 없는 칸이에요 (비활성화 또는 읽기 전용)');
if(secret(el))return fail('비밀번호 · 카드번호 · 인증번호 같은 칸은 안전을 위해 직접 입력해 주세요');
var k=kindOf(el),tg=el.tagName;
if(k==='file')return fail('파일 선택은 직접 해 주세요. 에이전트는 파일을 고를 수 없어요');
if(k==='button'||k==='link')return fail('입력칸이 아니에요. 누르려면 click_element 를 쓰세요');
safeScroll(el);
function fire(t,type,I){try{t.dispatchEvent(new (I||Event)(type,{bubbles:true,cancelable:true,composed:true}));}catch(e){}}
var shown='';
if(k==='select'){
  var want=V.trim().toLowerCase(),idx=-1,i;
  for(i=0;i<el.options.length;i++){var op=el.options[i];if(op.value.toLowerCase()===want||op.text.trim().toLowerCase()===want){idx=i;break;}}
  if(idx<0){for(i=0;i<el.options.length;i++){if(el.options[i].text.toLowerCase().indexOf(want)>=0){idx=i;break;}}}
  if(idx<0)return fail('그런 선택지가 없어요: '+cut(V,40),{options:Array.prototype.slice.call(el.options,0,12).map(function(o){return cut(o.text,30);})});
  el.selectedIndex=idx;fire(el,'input');fire(el,'change');
  shown=cut(el.options[idx].text,40);
}else if(k==='checkbox'||k==='radio'){
  var on=/^(true|on|1|yes|checked|켜기|켬|체크)(?![\s\S])/i.test(V.trim());
  var cur=(el.checked!==undefined)?!!el.checked:(el.getAttribute('aria-checked')==='true');
  if(k==='radio'){if(!cur)el.click();}
  else if(cur!==on)el.click();
  shown=((el.checked!==undefined)?!!el.checked:(el.getAttribute('aria-checked')==='true'))?'체크됨':'체크 안 됨';
}else if(tg==='INPUT'||tg==='TEXTAREA'){
  var proto=(tg==='TEXTAREA')?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  var setter=Object.getOwnPropertyDescriptor(proto,'value');
  if(setter&&setter.set)setter.set.call(el,V);else el.value=V;
  try{el.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:V}));}catch(e){fire(el,'input');}
  fire(el,'change');
  shown=cut(el.value,40);
}else if(el.isContentEditable){
  try{el.focus({preventScroll:true});}catch(e){el.focus();}
  try{document.execCommand('selectAll',false,null);document.execCommand('insertText',false,V);}catch(e){el.textContent=V;}
  fire(el,'input');
  shown=cut(el.textContent,40);
}else{
  return fail('이 요소에는 쓸 수 없어요');
}
if(submit){
  var f=el.form;
  var kopt={key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true,composed:true};
  var go=el.dispatchEvent(new KeyboardEvent('keydown',kopt));
  el.dispatchEvent(new KeyboardEvent('keypress',kopt));
  el.dispatchEvent(new KeyboardEvent('keyup',kopt));
  if(go&&f){if(f.requestSubmit)f.requestSubmit();else f.submit();}
}
var doneTxt=(k==='select')?'골랐어요':((k==='checkbox'||k==='radio')?'바꿨어요':'입력했어요');
if(submit)doneTxt+=' · 제출';
fx(function(F){F.done(doneTxt);});
return JSON.stringify({ok:true,label:label(el),value:shown,submitted:submit});
"""

    /**
     * 요소 끌기. P.id = 시작 요소 번호, P.to = 도착 요소 번호(0 이면 없음), P.dx · P.dy = 도착 요소가 없을 때 옮길 픽셀
     * 범위 막대(input range)는 값을 직접 맞추고, 그 밖에는 포인터 · 마우스 · 터치 이벤트와 HTML5 끌어다 놓기 이벤트를 순서대로 보낸다.
     */
    private const val DRAG = """
var el=pick(P.id),toId=P.to|0,DX=P.dx|0,DY=P.dy|0;
if(!el)return fail(GONE);
if(el.disabled||el.getAttribute('aria-disabled')==='true')return fail('비활성화된 요소라 끌 수 없어요');
safeScroll(el);
function cl(v,a,b){return Math.max(a,Math.min(b,v));}
var r=el.getBoundingClientRect();
var isRange=(el.tagName==='INPUT'&&(el.type||'').toLowerCase()==='range');
var mn=0,mx=100,st=1,TH=9;
if(isRange){mn=parseFloat(el.min||'0');mx=parseFloat(el.max||'100');st=parseFloat(el.step||'1');}
var sx,sy;
if(isRange){var f0=mx>mn?cl((parseFloat(el.value)-mn)/(mx-mn),0,1):0;sx=r.left+TH+f0*Math.max(1,r.width-2*TH);sy=r.top+r.height/2;}
else{sx=r.left+r.width/2;sy=r.top+r.height/2;}
sx=cl(sx,1,innerWidth-1);sy=cl(sy,1,innerHeight-1);
var tel=null,tx,ty;
if(toId>0){
  tel=pick(toId);
  if(!tel)return fail(GONE);
  var tr=tel.getBoundingClientRect();
  if(tr.bottom<0||tr.top>innerHeight||tr.right<0||tr.left>innerWidth)return fail('도착할 요소가 화면 밖이에요. scroll_page 로 두 요소가 같이 보이게 한 뒤 read_page 로 다시 읽어 주세요');
  tx=tr.left+tr.width/2;ty=tr.top+tr.height/2;
}else{tx=sx+DX;ty=sy+DY;}
tx=cl(tx,1,innerWidth-1);ty=cl(ty,1,innerHeight-1);
if(Math.abs(tx-sx)<2&&Math.abs(ty-sy)<2)return fail('시작과 도착 위치가 같아서 끌 곳이 없어요');
if(!isRange){
  var top=document.elementFromPoint(sx,sy);
  if(top&&top!==el&&!el.contains(top)&&!top.contains(el)){
    var rt=el.getRootNode&&el.getRootNode();
    if(!(rt&&rt.host&&(rt.host===top||rt.host.contains(top))))return fail('다른 요소가 가리고 있어요: '+(label(top)||top.tagName.toLowerCase())+' (팝업이나 광고를 먼저 닫아야 할 수 있어요)');
  }
}
var lb=label(el),to=tel?label(tel):'';
var nat=(!isRange&&(el.draggable===true||el.getAttribute('draggable')==='true'));
function snap(f){var v=mn+(mx-mn)*cl(f,0,1);if(st>0)v=Math.round((v-mn)/st)*st+mn;return Math.min(mx,Math.max(mn,v));}
var finalVal=isRange?snap((tx-r.left-TH)/Math.max(1,r.width-2*TH)):null;
function setRange(v){
  var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
  if(setter&&setter.set)setter.set.call(el,String(v));else el.value=String(v);
  try{el.dispatchEvent(new Event('input',{bubbles:true,composed:true}));}catch(e){}
}
function mouse(t,type,x,y,b){
  try{
    var o={bubbles:true,cancelable:true,composed:true,view:window,clientX:x,clientY:y,button:0,buttons:b};
    var C=MouseEvent;
    if(/^pointer/.test(type)&&window.PointerEvent){C=PointerEvent;o.pointerId=1;o.pointerType='mouse';o.isPrimary=true;}
    t.dispatchEvent(new C(type,o));
  }catch(e){}
}
function touch(t,type,x,y){
  try{
    if(!window.TouchEvent||!window.Touch)return;
    var th=new Touch({identifier:1,target:t,clientX:x,clientY:y,pageX:x+window.pageXOffset,pageY:y+window.pageYOffset});
    var l=(type==='touchend')?[]:[th];
    t.dispatchEvent(new TouchEvent(type,{bubbles:true,cancelable:true,composed:true,touches:l,targetTouches:l,changedTouches:[th]}));
  }catch(e){}
}
var dt=null;try{dt=new DataTransfer();}catch(e){}
function dnd(t,type,x,y){
  try{
    var o={bubbles:true,cancelable:true,composed:true,clientX:x,clientY:y};
    if(dt)o.dataTransfer=dt;
    t.dispatchEvent(new DragEvent(type,o));
  }catch(e){}
}
function begin(){
  if(isRange)return;
  mouse(el,'pointerdown',sx,sy,1);mouse(el,'mousedown',sx,sy,1);touch(el,'touchstart',sx,sy);
  if(nat)dnd(el,'dragstart',sx,sy);
}
/** t = 0..1 : 그 만큼 끌린 상태로 */
function move(t){
  var e=t*t*(3-2*t),x=sx+(tx-sx)*e,y=sy+(ty-sy)*e;
  if(isRange){setRange(snap((x-r.left-TH)/Math.max(1,r.width-2*TH)));return;}
  var under=document.elementFromPoint(x,y)||el;
  if(nat){dnd(under,'dragover',x,y);}
  else{mouse(el,'pointermove',x,y,1);mouse(under,'mousemove',x,y,1);touch(el,'touchmove',x,y);}
}
function finish(){
  if(isRange){setRange(finalVal);try{el.dispatchEvent(new Event('change',{bubbles:true,composed:true}));}catch(e){}return;}
  var dest=tel||document.elementFromPoint(tx,ty)||el;
  if(nat){dnd(dest,'dragenter',tx,ty);dnd(dest,'dragover',tx,ty);dnd(dest,'drop',tx,ty);dnd(el,'dragend',tx,ty);}
  mouse(el,'pointerup',tx,ty,0);mouse(dest,'mouseup',tx,ty,0);touch(el,'touchend',tx,ty);
}
var N=14,dur=0;
if(FX){
  // 보이는 커서와 페이지의 실제 끌기가 같은 시간·곡선으로 같이 움직인다
  dur=Math.round(cl(Math.sqrt((tx-sx)*(tx-sx)+(ty-sy)*(ty-sy))*1.3,420,1200));
  fx(function(F){F.dragTo(tx,ty,to||lb,dur);});
  begin();
  for(var i=1;i<=N;i++){(function(i){setTimeout(function(){try{move(i/N);}catch(e){}},Math.round(dur*i/N));})(i);}
  setTimeout(function(){try{finish();}catch(e){}},dur+30);
}else{
  begin();
  for(var j=1;j<=N;j++)move(j/N);
  finish();
}
return JSON.stringify({ok:true,label:lb,to:to,moved:[Math.round(tx-sx),Math.round(ty-sy)],native:nat,value:isRange?String(finalVal):undefined,ms:dur?dur+330:0});
"""

    /** 스크롤. P.dir = up | down | top | bottom, P.amt = 픽셀(0 이면 화면 높이의 80%), P.id = 요소 번호(0 이면 없음) */
    private const val SCROLL = """
var dir=P.dir,amt=P.amt|0,id=P.id|0;
function best(){
  var se=document.scrollingElement||document.documentElement;
  if(se.scrollHeight-se.clientHeight>4)return se;
  var c=null,ca=0,all=document.querySelectorAll('*');
  for(var i=0;i<all.length&&i<5000;i++){
    var e=all[i];
    if(e.scrollHeight-e.clientHeight<=40)continue;
    var oy=getComputedStyle(e).overflowY;
    if(oy!=='auto'&&oy!=='scroll'&&oy!=='overlay')continue;
    if(!inView(e))continue;
    var a=e.clientWidth*e.clientHeight;
    if(a>ca){ca=a;c=e;}
  }
  return c||se;
}
var sc=best();
var isDoc=(sc===document.scrollingElement||sc===document.documentElement||sc===document.body);
function pos(){
  var y=isDoc?(window.pageYOffset||sc.scrollTop):sc.scrollTop;
  var vh=isDoc?innerHeight:sc.clientHeight;
  return {y:Math.round(y),max:Math.max(0,Math.round(sc.scrollHeight-vh)),view:Math.round(vh)};
}
function to(t){
  if(isDoc){try{window.scrollTo({top:t,left:0,behavior:'instant'});}catch(e){window.scrollTo(0,t);}}
  else sc.scrollTop=t;
}
var before=pos();
if(id>0){
  var el=pick(id);
  if(!el)return fail(GONE);
  safeScroll(el);
}else{
  var step=amt>0?amt:Math.round(before.view*0.8);
  var t=dir==='top'?0:(dir==='bottom'?before.max:(dir==='up'?before.y-step:before.y+step));
  to(Math.max(0,Math.min(before.max,t)));
}
var after=pos();
var res={ok:true,y:after.y,max:after.max,view:after.view,moved:after.y!==before.y,
  at_top:after.y<=2,at_bottom:after.y>=after.max-2,percent:after.max>0?Math.round(after.y*100/after.max):100,inner_scroll:!isDoc};
fx(function(F){
  if(id>0){var t=pick(id);if(t)F.aim(t,'scroll',label(t),'',1300);}
  else F.scroll(dir,res.percent,res.moved);
});
return JSON.stringify(res);
"""

    /**
     * [fx] 가 true 면 조작 표시([FXLIB])를 깔고 스크립트 안의 `fx(...)` 호출이 화면에 그린다. false 면 `fx(...)` 는 아무 일도 안 한다
     * (요소 정보만 알아 오는 스크립트나, 사용자가 설정에서 끈 경우).
     */
    /** 앱의 AI 그라데이션 색(초록 → 청록 → 파랑 → 보라, 테마 대표색에 맞춰 바뀜)을 JS 배열로 */
    private fun gradJs(): String =
        AiGradient.STOPS.joinToString(",", "[", "]") { String.format("'#%06X'", it and 0xFFFFFF) }

    /** 본문(주 프레임)에서 돌리는 스크립트. [p] 는 스크립트 안에서 `P` 로 읽는 값들(요소 번호 · 글 · 방향 등) */
    private fun wrap(body: String, fx: Boolean = false, p: JSONObject = JSONObject()): String =
        "(function(){" + (if (fx) FXLIB.replace("__GRAD__", gradJs()) else "") +
            "var FX=" + (if (fx) "(window.__evgFx||null)" else "null") + ";" +
            "function fx(f){try{if(FX)f(FX);}catch(e1){}}" +
            "var P=" + p.toString() + ";" +
            PRE + "try{" + body +
            "}catch(e){return JSON.stringify({ok:false,error:'페이지 스크립트 오류: '+(e&&e.message?e.message:e)});}})()"

    /** 페이지 안에서 돌리는 동작 하나. 본문은 [wrap] 으로, iframe 안은 [frameBridgeScript] 안의 같은 코드로 돈다 */
    private class Op(val name: String, val body: String)

    private val OP_READ = Op("read", READ)
    private val OP_AIM = Op("aim", AIM)
    private val OP_INFO = Op("info", INFO)
    private val OP_CLICK = Op("click", CLICK)
    private val OP_FILL = Op("fill", FILL)
    private val OP_DRAG = Op("drag", DRAG)
    private val OP_SCROLL = Op("scroll", SCROLL)
    private val ALL_OPS = listOf(OP_READ, OP_AIM, OP_INFO, OP_CLICK, OP_FILL, OP_DRAG, OP_SCROLL)

    /**
     * 모든 프레임(본문 · iframe, 다른 출처 포함)에 문서 시작 때 넣는 스크립트 (WebMessageListener 이름은 [FRAME_BRIDGE_NAME]).
     * 본문에서는 아무 일도 하지 않고, iframe 안에서는 ① 앱에 자기를 알리고(hi) ② 앱이 보내는 동작 요청(run)을 받아
     * 위 [ALL_OPS] 와 같은 코드로 돌린 뒤 ③ 결과(res)를 돌려준다. 코드가 미리 들어 있어서 사이트의 CSP(eval 금지)에 막히지 않는다.
     * 무거운 부분은 처음 요청이 올 때까지 함수 안에 잠들어 있다 (광고 iframe 이 많은 페이지에서 느려지지 않게).
     * 주의: 코틀린 raw string 이라 달러 기호 + 중괄호와 큰따옴표 세 개를 쓰지 않는다.
     */
    fun frameBridgeScript(): String {
        val ops = StringBuilder("var OPS={")
        ALL_OPS.forEachIndexed { i, o ->
            if (i > 0) ops.append(',')
            ops.append(o.name).append(":function(P){").append(o.body).append("\n}")
        }
        ops.append("};")
        val lib = "function lib(){" +
            "var FX=null;function fx(f){try{if(FX)f(FX);}catch(e1){}}" +
            "function ensureFx(GRAD){if(window.__evgFx)return;" + FXLIB.replace("__GRAD__", "GRAD") + "\n}" +
            PRE + ops +
            "return function(op,P){var f=OPS[op];if(!f)return JSON.stringify({ok:false,error:'알 수 없는 동작: '+op});" +
            "if(P.fx){try{ensureFx(P.grad);}catch(e){}FX=window.__evgFx||null;}else{FX=null;}" +
            "P.vis=vis;" +
            // 화면 밖에 있는 iframe 은 viewport 읽기에서 내용을 싣지 않고 자리만 알려 준다 (scroll_page 로 가까이 가져온 뒤 다시 읽게)
            "if(op==='read'&&P.scope==='viewport'&&vis===false){return JSON.stringify({ok:true,offscreen:true,shown:0,total:0,elements:[],frame:{url:cut(location.href,200),title:cut(document.title,80),w:innerWidth,h:innerHeight,visible:false}});}" +
            "try{return f(P);}catch(e){return JSON.stringify({ok:false,error:'페이지 스크립트 오류: '+(e&&e.message?e.message:e)});}};}"
        return "(function(){try{" +
            "var top0=false;try{top0=(window.top===window);}catch(e){}" +
            "if(top0)return;" +
            "var N=null,tok='',booted=false,vis=true,L=null;" +
            lib +
            "function send(o){try{N.postMessage(JSON.stringify(o));}catch(e){}}" +
            "function hi(){send({t:'hi',tok:tok,url:String(location.href).slice(0,300)});}" +
            "function boot(){" +
            "if(booted)return true;" +
            "var n=window." + FRAME_BRIDGE_NAME + ";" +
            "if(!n||typeof n.postMessage!=='function')return false;" +
            "N=n;booted=true;" +
            "tok=Math.random().toString(36).slice(2)+Date.now().toString(36);" +
            "hi();" +
            "N.onmessage=function(ev){" +
            "var m=null;try{m=JSON.parse(ev.data);}catch(e){return;}" +
            "if(!m||m.t!=='run'||typeof m.id!=='number')return;" +
            "var r;" +
            "try{if(!L)L=lib();r=L(String(m.op),m.p||{});}catch(e){r=JSON.stringify({ok:false,error:'iframe 스크립트 오류: '+(e&&e.message?e.message:e)});}" +
            "send({t:'res',id:m.id,tok:tok,r:String(r)});" +
            "};" +
            "var later=function(){hi();try{if(window.IntersectionObserver&&document.documentElement){" +
            "new IntersectionObserver(function(es){if(es.length)vis=!!es[es.length-1].isIntersecting;}).observe(document.documentElement);}}catch(e){}};" +
            "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',later,{once:true});else later();" +
            "window.addEventListener('pagehide',function(e){if(!e.persisted)send({t:'bye',tok:tok});});" +
            "return true;}" +
            "if(!boot())document.addEventListener('DOMContentLoaded',boot,{once:true});" +
            "}catch(e){}})();"
    }

    /** 앱이 WebView 에 붙이는 WebMessageListener 이름 (프레임이 앱과 말하는 통로) */
    const val FRAME_BRIDGE_NAME = "EvFrame"

    /** iframe 안 요소의 번호는 `프레임번호 * FRAME_STRIDE + 프레임 안 요소번호`. 본문 요소는 FRAME_STRIDE 보다 작다 */
    private const val FRAME_STRIDE = 1000

    private fun frameOf(id: Int): Int = if (id >= FRAME_STRIDE) id / FRAME_STRIDE else 0

    private fun localOf(id: Int): Int = if (id >= FRAME_STRIDE) id % FRAME_STRIDE else id

    // ───────────────────────── 도우미 ─────────────────────────

    /** 페이지 안에서 스크립트를 돌려 JSON 결과를 받는다. 실패하면 (null, 이유) */
    private fun runJson(ctx: AgentContext, js: String): Pair<JSONObject?, String> {
        val o = ctx.host.pageScript(js)
        if (!o.ok) return null to o.message
        return try {
            JSONObject(o.message) to ""
        } catch (e: Exception) {
            null to "페이지에서 받은 결과를 읽지 못했어요"
        }
    }

    /**
     * 동작 [op] 을 [frame] 번 iframe 안에서(0 이면 본문에서) 돌린다. [p] 의 `id` 는 그 프레임 안 번호다.
     * iframe 이 응답하지 않으면 (null, 이유).
     */
    private fun runOp(ctx: AgentContext, frame: Int, op: Op, p: JSONObject, fx: Boolean): Pair<JSONObject?, String> {
        if (frame <= 0) return runJson(ctx, wrap(op.body, fx, p))
        p.put("fx", fx)
        if (fx) p.put("grad", org.json.JSONArray(AiGradient.STOPS.map { String.format("#%06X", it and 0xFFFFFF) }))
        val o = ctx.host.frameScript(frame, op.name, p.toString())
        if (!o.ok) return null to o.message
        return try {
            JSONObject(o.message) to ""
        } catch (e: Exception) {
            null to "iframe 에서 받은 결과를 읽지 못했어요"
        }
    }

    /** 스크립트 결과를 도구 결과로 바꾼다. 스크립트가 ok=false 로 돌려주면 그 이유를 실패로 낸다 */
    private fun asResult(o: JSONObject?, err: String, summary: (JSONObject) -> String, untrusted: Boolean = false): AgentResult {
        if (o == null) return AgentResult.fail(err)
        if (!o.optBoolean("ok", true)) {
            val d = JSONObject().put("error", o.optString("error"))
            o.optString("href").takeIf { it.isNotEmpty() }?.let { d.put("href", it) }
            if (o.has("options")) d.put("options", o.opt("options"))
            return AgentResult(false, d, o.optString("error"), untrusted)
        }
        return AgentResult.ok(o, summary(o), untrusted)
    }

    /** 사용자가 설정에서 「웹 조작 표시」를 켜 두었는가 (기본 켜짐) */
    private fun fxOn(ctx: AgentContext): Boolean = try { ctx.host.showActions() } catch (e: Exception) { false }

    /**
     * 가상 커서가 요소로 가서 짚어 준다 (표시가 꺼져 있거나 요소를 못 찾으면 아무 일도 안 한다).
     * [wait] 가 true 면 커서가 도착해서 눈에 보일 만큼 기다린 뒤 돌아온다. false 면 표시만 하고 바로 돌아온다 (확인 카드가 떠 있는 동안 쓴다).
     * [kind] = click | fill | scroll | ask. 실제 동작은 하지 않는다.
     */
    private fun aim(ctx: AgentContext, id: Int, kind: String, value: String = "", hold: Int = 4000, wait: Boolean = true) {
        if (id <= 0 || !fxOn(ctx)) return
        val p = JSONObject().put("id", localOf(id)).put("kind", kind).put("hold", hold).put("val", value.take(200))
        val (o, _) = runOp(ctx, frameOf(id), OP_AIM, p, true)
        if (wait && !ctx.cancelled && o != null && o.optBoolean("ok", false)) {
            val ms = o.optInt("ms", 500).coerceIn(200, 600)
            try { Thread.sleep(ms.toLong()) } catch (e: InterruptedException) { }
        }
    }

    /** 마지막으로 읽은 read_page 의 요소 번호 → 이름. 진행 카드에 「3번 요소」 대신 「로그인」 처럼 보여 주려고 쓴다 */
    private val seenLabels = java.util.concurrent.ConcurrentHashMap<Int, String>()

    private fun seen(id: Int): String = seenLabels[id].orEmpty()

    /** 요소 정보를 한 번 물은 결과 (시각 · 정보). 위험도 판단 · 확인 카드 · 안내가 같은 요소를 연달아 물어서 생기는 페이지 왕복을 줄인다 */
    private val infoCache = java.util.concurrent.ConcurrentHashMap<Int, Pair<Long, JSONObject>>()
    private const val INFO_TTL_MS = 3000L

    private fun elInfo(ctx: AgentContext, id: Int): JSONObject? {
        if (id <= 0) return null
        val now = android.os.SystemClock.elapsedRealtime()
        infoCache[id]?.let { (t, v) -> if (now - t < INFO_TTL_MS) return v }
        val (o, _) = runOp(ctx, frameOf(id), OP_INFO, JSONObject().put("id", localOf(id)), false)
        val ok = if (o != null && o.optBoolean("ok", false)) o else null
        if (ok != null) infoCache[id] = now to ok else infoCache.remove(id)
        return ok
    }

    /**
     * 누르거나 입력한 뒤, 이동이 시작되거나 새 내용이 뜰 시간을 조금 준다.
     * 고정으로 오래 기다리지 않고 짧게 쉰 뒤 불러오는 중이면 조금씩 더 기다린다 (최대 약 1초). 지금 탭의 정보를 돌려준다
     */
    private fun settle(ctx: AgentContext): AgentTab? {
        infoCache.clear()
        var cur: AgentTab? = null
        var i = 0
        while (i < 5 && !ctx.cancelled) {
            try { Thread.sleep(if (i == 0) 350L else 150L) } catch (e: InterruptedException) { break }
            cur = try { ctx.host.tabs().firstOrNull { it.current } } catch (e: Exception) { null }
            if (cur != null && !cur.loading) break
            i++
        }
        return cur
    }

    private fun describe(ctx: AgentContext, id: Int): String {
        val info = elInfo(ctx, id) ?: return "${id}번 요소"
        val l = info.optString("label")
        val base = if (l.isEmpty()) "${id}번 ${info.optString("kind")}" else "「${short(l, 30)}」"
        // iframe 안 요소면 어느 사이트의 iframe 인지 확인 카드에 같이 보여 준다
        val fr = info.optString("frame")
        return if (fr.isEmpty()) base else "$base · iframe($fr)"
    }

    /** 요소 목록 전체(본문 + iframe)의 상한. 너무 길어지면 AI 가 읽기 벅차다 */
    private const val MAX_ELEMENTS = 120

    /**
     * 본문 읽기 결과 [res] 에 iframe 안 읽기 결과를 합친다.
     * 요소에는 `frame` 과 합쳐진 번호가 붙고, `frames` 목록에 iframe 별 주소 · 크기 · 글(짧게)이 들어간다.
     * 크기가 작거나 비어 있는 프레임(광고 · 추적용)은 건너뛴다. 응답하지 않는 iframe 은 조용히 건너뛴다.
     */
    private fun mergeFrames(ctx: AgentContext, res: JSONObject, scope: String, text: Boolean) {
        val frames = try { ctx.host.frames() } catch (e: Exception) { emptyList() }
        if (frames.isEmpty()) {
            if (res.optInt("iframes", 0) > 0) res.put("iframe_note", "iframe 안은 아직 읽지 못했어요 (불러오는 중이거나, 이 기기의 웹뷰가 지원하지 않거나, 막힌 iframe 일 수 있어요)")
            return
        }
        val list = frames.take(8)
        val slots = arrayOfNulls<Pair<JSONObject?, String>>(list.size)
        // 프레임마다 따로 묻는 데 시간이 걸리니 한꺼번에 묻는다
        val threads = list.mapIndexed { i, f ->
            val t = Thread {
                val p = JSONObject().put("scope", scope).put("text", text).put("max", 30)
                slots[i] = runOp(ctx, f.number, OP_READ, p, false)
            }
            t.isDaemon = true
            t.start()
            t
        }
        for (t in threads) try { t.join(3000) } catch (e: InterruptedException) { }
        val elements = res.optJSONArray("elements") ?: org.json.JSONArray().also { res.put("elements", it) }
        val out = org.json.JSONArray()
        var shown = res.optInt("shown", 0)
        var total = res.optInt("total", 0)
        for (i in list.indices) {
            val f = list[i]
            val fo = slots[i]?.first ?: continue
            if (!fo.optBoolean("ok", true)) continue
            val meta = fo.optJSONObject("frame")
            val w = meta?.optInt("w", 0) ?: 0
            val h = meta?.optInt("h", 0) ?: 0
            val offscreen = fo.optBoolean("offscreen", false)
            val arr = fo.optJSONArray("elements")
            val n = arr?.length() ?: 0
            val txt = fo.optString("text").trim()
            if (!offscreen && n == 0 && txt.length < 20) continue
            if (w in 1..39 || h in 1..39) continue
            val info = JSONObject().put("frame", f.number).put("url", (meta?.optString("url") ?: f.url).take(200))
            meta?.optString("title")?.takeIf { it.isNotEmpty() }?.let { info.put("title", it) }
            if (w > 0 && h > 0) info.put("size", "${w}x${h}")
            if (offscreen) {
                info.put("offscreen", true)
            } else {
                info.put("shown", n).put("total", fo.optInt("total", n))
                if (text && txt.isNotEmpty()) info.put("text", short(txt, 600))
                var room = MAX_ELEMENTS - elements.length()
                if (arr != null) for (k in 0 until arr.length()) {
                    if (room <= 0) break
                    val e = arr.optJSONObject(k) ?: continue
                    e.put("element", f.number * FRAME_STRIDE + e.optInt("element", 0)).put("frame", f.number)
                    elements.put(e)
                    room--
                    shown++
                }
                total += fo.optInt("total", n)
            }
            out.put(info)
        }
        if (out.length() > 0) res.put("frames", out)
        res.put("shown", shown).put("total", total)
        if (res.optInt("iframes", 0) > 0 && out.length() == 0) res.put("iframe_note", "iframe 이 있지만 안쪽에서 읽을 만한 요소를 찾지 못했어요 (아직 불러오는 중이거나 비어 있을 수 있어요)")
    }

    // ───────────────────────── 읽기 ─────────────────────────

    private fun readPage() = AgentTool(
        name = "read_page",
        description = "지금 보고 있는 탭의 웹 페이지 글과, 누르거나 입력할 수 있는 요소(링크 · 버튼 · 입력칸 · 선택 상자 · 체크 상자)의 목록을 읽어 옵니다. " +
            "요소마다 element 번호가 붙고, 이 번호를 click_element · drag_element · fill_field · scroll_page 에 씁니다. 번호는 마지막으로 읽은 결과에서만 맞으니, 페이지가 바뀌면(이동 · 클릭 · 스크롤로 새 내용이 뜰 때) 다시 읽으세요. " +
            "scope 는 viewport(지금 화면에 보이는 것만, 기본) 또는 all(페이지 전체, 최대 60개)입니다. 화면 밖 요소는 scroll_page 로 내린 뒤 다시 읽어도 됩니다. " +
            "iframe(영상 · 결제 · 로그인 · 댓글 같은 외부 임베드, 다른 사이트 것도 포함) 안의 요소도 함께 읽습니다: 요소에 frame 번호가 붙고(element 번호는 2003 처럼 프레임번호×1000+번호), frames 목록에 각 iframe 의 주소 · 크기 · 글이 나옵니다. " +
            "그 번호를 click_element · fill_field · drag_element 에 그대로 쓰면 알아서 그 iframe 안에서 동작합니다. 화면 밖에 있는 iframe 은 frames 에 offscreen 으로만 나오니 scroll_page 로 가까이 가져온 뒤 다시 읽으세요. " +
            "비밀번호 · 카드번호 칸은 값이 보이지 않고 secret 으로 표시됩니다. 새 탭(홈) 화면에서는 쓸 수 없습니다.",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "scope" to AgentSchema.oneOf("읽을 범위 (기본 viewport)", "viewport", "all"),
                "text" to AgentSchema.flag("페이지 글도 함께 읽을지 (기본 true)")
            )
        ),
        doing = { "페이지 읽는 중…" },
        run = { a, ctx ->
            val scope = if (a.optString("scope") == "all") "all" else "viewport"
            val text = a.optBoolean("text", true)
            val (o, err) = runOp(ctx, 0, OP_READ, JSONObject().put("scope", scope).put("text", text).put("max", 60), fxOn(ctx))
            // 본문에 iframe 이 있으면 그 안 요소도 같이 읽어 합친다 (다른 출처여도 앱이 프레임마다 심어 둔 스크립트로 읽는다)
            if (o != null && o.optBoolean("ok", true)) mergeFrames(ctx, o, scope, text)
            // 진행 카드에 요소 이름을 보여 주려고 번호 → 이름을 기억해 둔다 (번호는 마지막으로 읽은 결과에서만 맞다)
            if (o != null && o.optBoolean("ok", true)) {
                seenLabels.clear()
                infoCache.clear()
                val arr = o.optJSONArray("elements")
                if (arr != null) for (i in 0 until arr.length()) {
                    val e = arr.optJSONObject(i) ?: continue
                    val n = e.optInt("element", 0)
                    val l = e.optString("label")
                    if (n > 0 && l.isNotEmpty()) seenLabels[n] = l
                }
            }
            // 페이지 글 · 요소 이름은 웹페이지가 정한 글이라 자료로만 다룬다
            asResult(o, err, { "페이지를 읽었어요 · 요소 ${it.optInt("shown")}개" }, untrusted = true)
        }
    )

    private fun scrollPage() = AgentTool(
        name = "scroll_page",
        description = "지금 탭의 페이지를 스크롤합니다. direction: down(아래, 기본) · up(위) · top(맨 위) · bottom(맨 아래). amount 는 픽셀(비우면 화면 높이의 약 80%). " +
            "element 를 주면 그 요소가 화면 가운데 오도록 스크롤합니다(iframe 안 요소면 iframe 안과 바깥 페이지를 함께 맞춥니다). frame 을 주면 그 iframe 안(자체 스크롤이 있는 임베드)을 스크롤합니다. 결과에 지금 위치(percent)와 맨 위 · 맨 아래인지가 나옵니다. 스크롤한 뒤 새로 보이는 요소는 read_page 로 다시 읽어야 번호를 쓸 수 있습니다.",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "direction" to AgentSchema.oneOf("스크롤 방향 (기본 down)", "down", "up", "top", "bottom"),
                "amount" to AgentSchema.int("스크롤할 픽셀 (비우면 화면 높이의 80%)"),
                "element" to AgentSchema.int("화면 가운데로 가져올 요소 번호 (read_page 의 element)"),
                "frame" to AgentSchema.int("이 iframe 안을 스크롤 (read_page 의 frames 에 나온 frame 번호, 비우면 본문)")
            )
        ),
        doing = { a ->
            when (a.optString("direction")) {
                "top" -> "맨 위로 스크롤하는 중…"
                "bottom" -> "맨 아래로 스크롤하는 중…"
                "up" -> "위로 스크롤하는 중…"
                else -> if (a.optInt("element", 0) > 0) "요소 쪽으로 스크롤하는 중…" else "아래로 스크롤하는 중…"
            }
        },
        run = { a, ctx ->
            val dir = when (a.optString("direction")) {
                "up", "top", "bottom" -> a.optString("direction")
                else -> "down"
            }
            val amt = a.optInt("amount", 0).coerceIn(0, 20000)
            val id = a.optInt("element", 0).coerceAtLeast(0)
            val fr = if (id > 0) frameOf(id) else a.optInt("frame", 0).coerceAtLeast(0)
            val p = JSONObject().put("dir", dir).put("amt", amt).put("id", if (id > 0) localOf(id) else 0)
            val (o, err) = runOp(ctx, fr, OP_SCROLL, p, fxOn(ctx))
            asResult(o, err, { if (it.optBoolean("moved")) "스크롤했어요 (${it.optInt("percent")}%)" else "더 갈 곳이 없어요" })
        }
    )

    // ───────────────────────── 변경 ─────────────────────────

    /** 누를 요소의 위험도: 제출 · 내려받기 · 결제 같은 글자의 버튼이면 매번 확인(DANGER), 아니면 요청당 한 번(CHANGE) */
    private fun clickRisk(ctx: AgentContext, id: Int): AgentRisk {
        val info = elInfo(ctx, id) ?: return AgentRisk.CHANGE
        return if (info.optBoolean("submit") || info.optBoolean("download") || RISKY.containsMatchIn(info.optString("label"))) {
            AgentRisk.DANGER
        } else AgentRisk.CHANGE
    }

    private fun clickElement() = AgentTool(
        name = "click_element",
        description = "read_page 로 읽은 요소 하나를 누릅니다(링크 · 버튼 · 탭 · 메뉴 항목 등). element 는 read_page 의 번호입니다. " +
            "결제 · 삭제 · 전송 · 제출 · 동의 같은 버튼과 파일 내려받기 링크는 누를 때마다 사용자 확인을 받습니다. " +
            "iframe 안 요소(read_page 에서 frame 이 붙은 2003 같은 큰 번호)도 그 번호 그대로 누르면 됩니다. " +
            "새 탭으로 열리는 링크(new_tab)는 눌리지 않으니 open_tab 으로 주소를 여세요. 팝업 · 광고가 가리고 있으면 눌리지 않고 그 이유가 나옵니다. " +
            "누른 뒤 페이지가 바뀔 수 있으니 결과를 보려면 read_page 로 다시 읽으세요.",
        risk = AgentRisk.CHANGE,
        riskFor = { a, ctx -> clickRisk(ctx, a.optInt("element", 0)) },
        params = AgentSchema.obj(
            listOf("element" to AgentSchema.int("누를 요소 번호 (read_page 의 element)")),
            listOf("element")
        ),
        doing = { a ->
            val id = a.optInt("element", 0)
            val l = seen(id)
            if (l.isEmpty()) "페이지의 ${id}번 요소를 누르는 중…" else "「${short(l, 20)}」 누르는 중…"
        },
        run = { a, ctx ->
            val id = a.optInt("element", 0)
            if (id <= 0) {
                AgentResult.fail("element 번호가 필요해요 (read_page 로 먼저 읽으세요)")
            } else {
                // 가상 커서가 먼저 그 요소로 가서 짚어 준 다음 누른다 (조작 표시)
                aim(ctx, id, "click")
                val (o, err) = runOp(ctx, frameOf(id), OP_CLICK, JSONObject().put("id", localOf(id)), fxOn(ctx))
                val r = asResult(o, err, { "눌렀어요: " + short(it.optString("label").ifEmpty { "${id}번 요소" }, 24) }, untrusted = true)
                if (r.ok) {
                    // 누른 뒤 이동이 시작되거나 새 내용이 뜰 시간을 조금 준다
                    val cur = settle(ctx)
                    if (cur != null) {
                        r.data.put("now_url", cur.url.take(300)).put("loading", cur.loading)
                        r.data.put("hint", "페이지가 바뀌었을 수 있어요. 결과를 보려면 read_page 로 다시 읽으세요")
                    }
                }
                r
            }
        },
        ask = { a, ctx ->
            val id = a.optInt("element", 0)
            // 확인 카드가 떠 있는 동안 어떤 요소인지 페이지에서 주황색으로 짚어 둔다
            aim(ctx, id, "ask", hold = 15000, wait = false)
            "페이지에서 누르기: " + describe(ctx, id)
        }
    )

    private fun dragElement() = AgentTool(
        name = "drag_element",
        description = "read_page 로 읽은 요소 하나를 끌어서 옮깁니다(범위 막대 · 슬라이더 · 끌어다 놓기 · 정렬 · 지도 · 캐러셀 넘기기 등). element 는 끌 요소 번호입니다. " +
            "iframe 안 요소도 끌 수 있지만 도착 요소는 같은 iframe(또는 같은 본문) 안에 있어야 합니다. " +
            "도착 자리는 to_element(그 요소 위에 놓기) 또는 dx · dy(오른쪽 · 아래로 옮길 픽셀, 음수는 왼쪽 · 위)로 줍니다. 둘 중 하나는 꼭 있어야 합니다. " +
            "범위 막대(slider)는 막대의 왼쪽 끝~오른쪽 끝에서 도착 위치에 해당하는 값으로 바로 맞춥니다. 끌 요소와 도착 요소는 같은 화면에 보여야 하니, 멀면 scroll_page 로 가까이 가져온 뒤 read_page 로 다시 읽으세요. " +
            "사이트가 가짜(스크립트) 끌기를 막으면 안 될 수 있으니, 끈 뒤에는 read_page 로 결과를 확인하세요. 퍼즐 · 보안문자 같은 사람 확인은 하지 말고 사용자에게 직접 하라고 알리세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "element" to AgentSchema.int("끌 요소 번호 (read_page 의 element)"),
                "to_element" to AgentSchema.int("그 위에 놓을 도착 요소 번호 (비우면 dx · dy 사용)"),
                "dx" to AgentSchema.int("오른쪽으로 옮길 픽셀 (음수 = 왼쪽)"),
                "dy" to AgentSchema.int("아래로 옮길 픽셀 (음수 = 위)")
            ),
            listOf("element")
        ),
        doing = { a ->
            val id = a.optInt("element", 0)
            val l = seen(id)
            if (l.isEmpty()) "페이지의 ${id}번 요소를 끄는 중…" else "「${short(l, 20)}」 끄는 중…"
        },
        run = { a, ctx ->
            val id = a.optInt("element", 0)
            val to = a.optInt("to_element", 0).coerceAtLeast(0)
            val dx = a.optInt("dx", 0).coerceIn(-5000, 5000)
            val dy = a.optInt("dy", 0).coerceIn(-5000, 5000)
            if (id <= 0) {
                AgentResult.fail("element 번호가 필요해요 (read_page 로 먼저 읽으세요)")
            } else if (to <= 0 && dx == 0 && dy == 0) {
                AgentResult.fail("도착 자리가 필요해요: to_element 또는 dx · dy 를 주세요")
            } else if (to > 0 && frameOf(to) != frameOf(id)) {
                AgentResult.fail("끌 요소와 도착 요소가 서로 다른 곳(본문 · iframe)에 있어서 끌 수 없어요. 같은 곳 안에서만 끌 수 있으니 dx · dy 로 옮겨 보세요")
            } else {
                // 가상 커서가 먼저 끌 요소로 가서 짚어 준 다음, 끌어서 도착 자리까지 따라간다 (조작 표시)
                aim(ctx, id, "drag")
                val p = JSONObject().put("id", localOf(id)).put("to", if (to > 0) localOf(to) else 0).put("dx", dx).put("dy", dy)
                val (o, err) = runOp(ctx, frameOf(id), OP_DRAG, p, fxOn(ctx))
                val r = asResult(o, err, {
                    val t = it.optString("to")
                    "끌었어요: " + short(it.optString("label").ifEmpty { "${id}번 요소" }, 20) + (if (t.isNotEmpty()) " → " + short(t, 20) else "")
                }, untrusted = true)
                if (r.ok) {
                    infoCache.clear()
                    // 커서와 페이지가 같이 끌려가는 시간만큼 기다린 뒤 돌아온다
                    val waitMs = r.data.optInt("ms", 0).coerceIn(0, 1800)
                    if (waitMs > 0) try { Thread.sleep(waitMs.toLong()) } catch (e: InterruptedException) { }
                    r.data.put("hint", "끌어서 페이지가 바뀌었을 수 있어요. 결과를 보려면 read_page 로 다시 읽으세요")
                }
                r
            }
        },
        ask = { a, ctx ->
            val id = a.optInt("element", 0)
            val to = a.optInt("to_element", 0)
            aim(ctx, id, "ask", hold = 15000, wait = false)
            val from = describe(ctx, id)
            if (to > 0) "페이지에서 끌기: $from → " + describe(ctx, to)
            else "페이지에서 끌기: $from (오른쪽 ${a.optInt("dx", 0)}px · 아래 ${a.optInt("dy", 0)}px)"
        }
    )

    private fun fillField() = AgentTool(
        name = "fill_field",
        description = "read_page 로 읽은 입력칸에 글을 쓰거나, 선택 상자의 항목을 고르거나, 체크 상자 · 라디오를 켜고 끕니다. element 는 read_page 의 번호입니다. " +
            "value 는 쓸 글(입력칸 · 텍스트 영역), 고를 항목의 글이나 값(선택 상자), true/false(체크 상자)입니다. 기존 내용은 value 로 바뀝니다. " +
            "iframe 안 입력칸(frame 이 붙은 큰 번호)도 그대로 쓸 수 있습니다. 결제 · 인증 서비스 iframe 의 입력칸은 안전을 위해 쓰지 않습니다. " +
            "submit 이 true 면 쓴 뒤 Enter 를 눌러 제출합니다(검색창 · 폼). 제출은 매번 사용자 확인을 받습니다. " +
            "비밀번호 · 카드번호 · 인증번호 칸과 파일 선택은 쓸 수 없으니 사용자에게 직접 하라고 알리세요. 사용자가 시키지 않은 개인정보를 지어내서 쓰지 마세요.",
        risk = AgentRisk.CHANGE,
        riskFor = { a, _ -> if (a.optBoolean("submit", false)) AgentRisk.DANGER else AgentRisk.CHANGE },
        params = AgentSchema.obj(
            listOf(
                "element" to AgentSchema.int("쓸 요소 번호 (read_page 의 element)"),
                "value" to AgentSchema.str("쓸 글 · 고를 항목 · true/false"),
                "submit" to AgentSchema.flag("쓴 뒤 Enter 로 제출할지 (기본 false)")
            ),
            listOf("element", "value")
        ),
        doing = { a ->
            val id = a.optInt("element", 0)
            val l = seen(id)
            if (l.isEmpty()) "페이지의 ${id}번 칸에 입력하는 중…" else "「${short(l, 20)}」 입력하는 중…"
        },
        run = { a, ctx ->
            val id = a.optInt("element", 0)
            if (id <= 0 || !a.has("value")) {
                AgentResult.fail("element 번호와 value 가 필요해요 (read_page 로 먼저 읽으세요)")
            } else {
                val value = a.optString("value").take(2000)
                val submit = a.optBoolean("submit", false)
                // 가상 커서가 그 칸으로 가서, 쓸 글이 한 글자씩 써지는 걸 보여 준 다음 실제로 쓴다 (조작 표시)
                aim(ctx, id, "fill", value)
                val p = JSONObject().put("id", localOf(id)).put("val", value).put("submit", submit)
                val (o, err) = runOp(ctx, frameOf(id), OP_FILL, p, fxOn(ctx))
                infoCache.clear()
                val r = asResult(o, err, { "입력했어요: " + short(it.optString("label").ifEmpty { "${id}번 칸" }, 20) + (if (submit) " (제출)" else "") }, untrusted = true)
                if (r.ok && submit) {
                    val cur = settle(ctx)
                    if (cur != null) r.data.put("now_url", cur.url.take(300)).put("loading", cur.loading)
                }
                r
            }
        },
        ask = { a, ctx ->
            val id = a.optInt("element", 0)
            // 확인 카드가 떠 있는 동안 어떤 칸인지 페이지에서 주황색으로 짚어 둔다
            aim(ctx, id, "ask", hold = 15000, wait = false)
            val what = describe(ctx, id)
            "입력하기: $what ← “${short(a.optString("value"), 40)}”" + if (a.optBoolean("submit", false)) " 그리고 Enter 로 제출" else ""
        }
    )
}
