package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch

/** 설정 > 확장 프로그램: 설치된 확장 프로그램을 켜고 끄고, 옵션을 열고, 지운다. */
object ExtensionsUi {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /**
     * @param onAdd 웹스토어 / 파일(zip·crx) 중에 골라 추가하러 간다 (이 화면은 닫힌다)
     * @param onOpenPage 확장 프로그램 안의 페이지(옵션 · 팝업)를 새 탭으로 연다
     * @param onChanged 켜기/끄기/삭제로 바뀐 게 있을 때, 이 화면을 닫으면서 한 번 부른다
     */
    fun show(
        ctx: Context,
        mgr: ExtensionManager,
        onAdd: () -> Unit,
        onOpenPage: (String) -> Unit,
        onChanged: () -> Unit
    ): Dialog {
        val items = mgr.list()
        val onSurface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        var changed = false

        return Popup.panel(
            ctx,
            title = "확장 프로그램",
            subtitle = if (items.isEmpty()) "설치된 확장 프로그램이 없어요" else "${items.size}개 설치됨",
            headerIcon = R.drawable.ic_extension,
            widthDp = 400,
            secondaryLabel = "＋ 추가",
            onSecondary = { d ->
                d.dismiss()
                onAdd()
            }
        ) { list, dialog ->
            dialog.setOnDismissListener { if (changed) onChanged() }
            if (!mgr.supported) {
                list.addView(TextView(ctx).apply {
                    text = "이 기기의 웹뷰(WebView)가 페이지 시작 시 스크립트 삽입을 지원하지 않아 확장 프로그램이 동작하지 않아요. 'Android System WebView'를 업데이트해 보세요."
                    textSize = 12f
                    setTextColor(0xFFD93025.toInt())
                    setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 4))
                })
            }
            if (items.isEmpty()) {
                list.addView(TextView(ctx).apply {
                    text = "＋ 추가를 눌러 크롬 웹스토어의 주소(또는 ID)로 바로 설치하거나, .zip · .crx 파일을 추가하면 조건에 맞는 웹페이지에 확장 프로그램의 스크립트와 스타일이 적용돼요.\n\n" +
                        "웹페이지를 꾸미거나 바꾸는 종류(다크 모드, 광고·요소 숨기기, 글자 정리 등)는 잘 동작해요. 백그라운드(메시지 · 알람 · 외부 요청)도 지원하지만, 요청 차단(webRequest) · 우클릭 메뉴 · 포트 연결 같은 기능은 지원하지 않아요."
                    textSize = 13f
                    setTextColor(onVar)
                    setLineSpacing(0f, 1.15f)
                    setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12))
                })
                return@panel
            }
            items.forEach { e ->
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 8), dp(ctx, 10))

                    // 윗줄: 아이콘 · 이름/버전 · 스위치
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        addView(ImageView(ctx).apply {
                            val bmp = mgr.iconBitmap(e)
                            if (bmp != null) setImageBitmap(bmp)
                            else {
                                setImageResource(R.drawable.ic_extension)
                                imageTintList = android.content.res.ColorStateList.valueOf(onVar)
                                val p = dp(ctx, 6)
                                setPadding(p, p, p, p)
                            }
                            alpha = if (e.enabled) 1f else 0.45f
                            layoutParams = LinearLayout.LayoutParams(dp(ctx, 36), dp(ctx, 36)).apply { marginEnd = dp(ctx, 12) }
                        })
                        addView(LinearLayout(ctx).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            addView(TextView(ctx).apply {
                                text = e.name
                                textSize = 15f
                                setTypeface(typeface, Typeface.BOLD)
                                setTextColor(onSurface)
                                maxLines = 1
                                ellipsize = android.text.TextUtils.TruncateAt.END
                            })
                            addView(TextView(ctx).apply {
                                text = "v${e.version}" + if (e.description.isNotBlank()) "  ·  ${e.description}" else ""
                                textSize = 12f
                                setTextColor(onVar)
                                maxLines = 2
                                ellipsize = android.text.TextUtils.TruncateAt.END
                            })
                        })
                        addView(MaterialSwitch(ctx).apply {
                            isChecked = e.enabled
                            setOnCheckedChangeListener { _, on ->
                                mgr.setEnabled(e.id, on)
                                changed = true
                            }
                        })
                    })

                    // 제한 사항 안내
                    val notes = ArrayList<String>()
                    if (e.entries.isEmpty() && !e.hasBackground) notes.add("웹페이지에 넣는 스크립트가 없어서 이 앱에서는 할 수 있는 일이 없어요")
                    else if (e.hasBackground) notes.add("백그라운드는 메시지 · 알람 · 외부 요청만 지원해서 일부 기능은 동작하지 않을 수 있어요")
                    if (notes.isNotEmpty()) addView(TextView(ctx).apply {
                        text = notes.joinToString("\n")
                        textSize = 11.5f
                        setTextColor(0xFFC77700.toInt())
                        setPadding(dp(ctx, 48), dp(ctx, 4), 0, 0)
                    })

                    // 아랫줄: 옵션 · 팝업 · 삭제
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(dp(ctx, 40), dp(ctx, 4), 0, 0)
                        fun action(label: String, color: Int, click: () -> Unit) {
                            addView(TextView(ctx).apply {
                                text = label
                                textSize = 13f
                                setTypeface(typeface, Typeface.BOLD)
                                setTextColor(color)
                                setPadding(dp(ctx, 8), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
                                isClickable = true
                                setOnClickListener { click() }
                            })
                        }
                        e.options?.let { o ->
                            action("옵션", primary) {
                                dialog.dismiss()
                                onOpenPage(mgr.pageUrl(e, o))
                            }
                        }
                        e.popup?.let { p ->
                            action("팝업 열기", primary) {
                                dialog.dismiss()
                                onOpenPage(mgr.pageUrl(e, p))
                            }
                        }
                        action("삭제", 0xFFD93025.toInt()) {
                            Popup.confirm(
                                ctx, "'${e.name}'을(를) 삭제할까요?",
                                "확장 프로그램 파일과 저장된 설정이 모두 지워져요.",
                                "삭제", danger = true
                            ) {
                                mgr.remove(e.id)
                                changed = true
                                dialog.dismiss()
                                // 남은 목록으로 다시 연다 (바뀐 것은 닫을 때 한 번만 알린다)
                                if (mgr.list().isNotEmpty()) {
                                    show(ctx, mgr, onAdd, onOpenPage, onChanged)
                                }
                            }
                        }
                    })
                })
            }
        }
    }
}
