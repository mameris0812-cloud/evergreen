package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.os.SystemClock
import android.view.animation.PathInterpolator
import kotlin.math.max
import kotlin.math.min

/**
 * 영상 로딩 표시 (v2.6.13): 내장 플레이어와 미러링 오버레이가 함께 쓴다.
 * 화면 가운데(재생 버튼 자리)에 재생 버튼을 감싸는 고리가 돌아간다.
 *
 * - 잠깐 끊겼다 이어지는 정도(기본 250ms 안)에는 나타나지 않아 깜빡이지 않는다.
 * - 나타날 때는 살짝 작았다가 커지며 서서히 떠오르고, 사라질 때는 살짝 작아지며 흐려진다.
 * - 터치는 그대로 아래 화면으로 통과한다.
 * - 보이지 않는 동안에는 애니메이션을 멈춘다.
 */
class VideoLoadingView(ctx: Context) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val stroke = 3f * d
    private val box = RectF()
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        strokeWidth = stroke + 2f * d; color = 0x55000000
    }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; color = 0x33FFFFFF
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        strokeWidth = stroke; color = ctx.getColor(R.color.ev_accent)
    }

    private companion object {
        const val SHOW_FROM = 0.82f
        const val HIDE_TO = 0.92f
        const val CYCLE_MS = 1333.0   // 호가 한 번 늘었다 줄어드는 주기
        const val ROTATE_MS = 1600.0  // 고리 전체가 한 바퀴 도는 시간
        const val ADVANCE = 290.0     // 한 주기마다 호가 앞으로 나아가는 각도
        const val MIN_SWEEP = 24.0    // 가장 짧을 때 호의 길이
    }

    // 머리는 빠르게 앞서 나가고 꼬리는 늦게 따라붙는다 (머티리얼 로딩 고리와 같은 가감속 곡선)
    private val ease = PathInterpolator(0.4f, 0f, 0.2f, 1f)

    private var wanted = false
    private var startMs = 0L
    private var spin: ValueAnimator? = null
    private val showRun = Runnable { reveal() }

    init {
        visibility = GONE
        alpha = 0f
        scaleX = SHOW_FROM; scaleY = SHOW_FROM
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    /** 로딩 중이면 true. [delayMs] 가 지나도 계속 로딩 중일 때만 나타난다 (끄는 것은 바로) */
    fun setLoading(on: Boolean, delayMs: Long = 250L) {
        if (on == wanted) return
        wanted = on
        removeCallbacks(showRun)
        if (on) {
            if (visibility == VISIBLE) {
                // 사라지던 중이면 다시 또렷하게
                animate().cancel()
                animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180)
                    .setInterpolator(DecelerateInterpolator(1.5f)).start()
                startSpin()
            } else postDelayed(showRun, delayMs)
        } else {
            conceal()
        }
    }

    private fun reveal() {
        if (!wanted) return
        animate().cancel()
        // 작고 투명한 상태에서 시작해 천천히 가라앉듯 떠오른다 (호는 가장 짧은 길이에서 시작해 늘어남)
        alpha = 0f
        scaleX = SHOW_FROM; scaleY = SHOW_FROM
        visibility = VISIBLE
        startSpin()
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320)
            .setInterpolator(DecelerateInterpolator(1.8f)).start()
    }

    private fun conceal() {
        if (visibility != VISIBLE) return
        animate().cancel()
        animate().alpha(0f).scaleX(HIDE_TO).scaleY(HIDE_TO).setDuration(240)
            .setInterpolator(AccelerateInterpolator(1.2f)).withEndAction {
            if (!wanted) {
                visibility = GONE
                stopSpin()
            }
        }.start()
    }

    private fun startSpin() {
        if (spin?.isRunning == true) return
        // 시간은 애니메이터 값이 아니라 흘러간 시간으로 직접 계산한다 (반복 경계에서 튀지 않게)
        startMs = SystemClock.uptimeMillis()
        spin = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { invalidate() }
            start()
        }
    }

    private fun stopSpin() {
        spin?.cancel()
        spin = null
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(showRun)
        stopSpin()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (changedView === this && visibility != VISIBLE) stopSpin()
        else if (changedView === this && wanted && alpha > 0f) startSpin()
    }

    override fun onDraw(canvas: Canvas) {
        val pad = stroke + 2f * d
        box.set(pad, pad, width - pad, height - pad)
        canvas.drawOval(box, track)

        val elapsed = (SystemClock.uptimeMillis() - startMs).toDouble()
        val cycle = (elapsed / CYCLE_MS).toLong()
        val p = ((elapsed % CYCLE_MS) / CYCLE_MS).toFloat()
        // 머리: 주기 앞쪽에서 빠르게 나아감 / 꼬리: 뒤쪽에서 따라잡음 → 호가 부드럽게 늘었다 줄어든다
        val head = ADVANCE * ease.getInterpolation(min(1f, p / 0.7f))
        val tail = ADVANCE * ease.getInterpolation(max(0f, (p - 0.3f) / 0.7f))
        val rot = (elapsed % ROTATE_MS) / ROTATE_MS * 360.0
        val start = ((cycle * ADVANCE + rot) % 360.0 + tail - 90.0).toFloat()
        val sweep = max(head - tail, MIN_SWEEP).toFloat()
        canvas.drawArc(box, start, sweep, false, shadow)
        canvas.drawArc(box, start, sweep, false, arc)
    }
}
