package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.google.android.material.color.MaterialColors

/**
 * 눌린 카드([origin], 새 탭 화면의 개인정보 위젯)가 그대로 펼쳐져 팝업 창이 되고,
 * 닫을 때는 다시 그 카드 자리로 접혀 들어가는 팝업 (컨테이너 트랜스폼).
 *
 * - 창 배경(면·테두리·모서리)이 카드 모양에서 팝업 모양으로 연속해서 변한다. 크기·위치·모서리·색이 하나의 스프링으로 움직인다.
 * - 카드 안의 글자·아이콘은 카드가 커지는 동안 사라지고, 팝업 내용은 펼쳐지는 면 안에서만 보이며
 *   머리말 → 항목 → 버튼 순서로 떠오른다. (내용은 처음부터 최종 크기로 배치되어 있어 글자가 늘어나거나 찌그러지지 않는다)
 * - 뒤 화면의 어두워짐·블러도 진행도에 맞춰 서서히 진해진다.
 * - 스프링이라 열리는 도중에 닫아도 그 자리에서 자연스럽게 되돌아간다.
 *
 * 창 전체를 투명하게 덮고 그 안에서 면을 직접 그리기 때문에, 카드가 팝업 창 밖(화면 어디든)에 있어도 이어진다.
 */
internal class MorphDialog(
    ctx: Context,
    private val origin: View,
    private val originRadiusDp: Float = 24f
) : Dialog(ctx, R.style.Evergreen_Popup) {

    private lateinit var root: FrameLayout
    private lateinit var card: View
    private lateinit var surface: MorphSurface

    private val src = RectF()
    private val dst = RectF()
    private val rect = RectF()
    private val clip = RectF()
    private var clipRadius = 0f

    private var header: View? = null
    private var buttons: View? = null
    private var rows: List<View> = emptyList()

    private var ghost: Bitmap? = null
    private var useGhost = true
    private var originPrevVisibility = View.VISIBLE
    private var originHidden = false

    private var startColor = 0
    private var endColor = 0
    private var outlineColor = 0
    private var endStrokeAlpha = 0
    private var endDim = 0.12f
    private var endBlur = 0
    private var blurOn = false
    private var lastDim = -1f
    private var lastBlur = -1

    private var progress = 0f
    private var spring: SpringAnimation? = null
    private var ready = false
    private var settled = false
    private var closing = false
    private var finished = false

    private fun dp(v: Float) = v * context.resources.displayMetrics.density

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun seg(c: Float, a: Float, b: Float): Float = ((c - a) / (b - a)).coerceIn(0f, 1f)

    /** 팝업 카드를 투명한 전체 창 가운데에 올린다. 창이 뜨기 전에 한 번 부른다. */
    fun setCard(card: View, widthPx: Int) {
        this.card = card
        surface = MorphSurface(context)
        root = FrameLayout(context)
        root.addView(surface, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(card, FrameLayout.LayoutParams(
            widthPx, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        // 카드 바깥(투명한 부분)을 누르면 닫는다. 카드 안을 눌러도 닫히지 않도록 카드가 터치를 받는다.
        root.setOnClickListener { cancel() }
        root.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        card.setOnClickListener { }
        // 내용은 펼쳐지는 면 안에서만 보이게 자른다
        card.clipToOutline = true
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(
                    clip.left.toInt(), clip.top.toInt(), clip.right.toInt(), clip.bottom.toInt(), clipRadius
                )
            }
        }
        setContentView(root)
        window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            // 창 전체가 커지고 줄어드는 기본 애니메이션은 끈다. 움직임은 전부 여기서 그린다.
            setWindowAnimations(0)
        }
    }

    /**
     * 배경 블러·색을 정하고 시작 준비를 한다. 블러(Blur.behind) 처리까지 끝난 뒤, show() 전에 부른다.
     * @param glass 반투명 유리 배경(+뒤 블러)으로 만들어졌는지
     */
    fun arm(glass: Boolean) {
        startColor = MaterialColors.getColor(
            origin.context, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        endColor = Blur.surface(context, com.google.android.material.R.attr.colorSurface, glass)
        outlineColor = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOutlineVariant, 0x33888888)
        endStrokeAlpha = if (glass) 0x80 else 0
        val lp = window?.attributes
        if (lp != null) {
            endDim = lp.dimAmount
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                (lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND) != 0
            ) {
                blurOn = true
                endBlur = lp.blurBehindRadius
            }
        }
        // 배경은 이제 MorphSurface 가 그린다
        card.background = null
        card.alpha = 0f
        applyBackdrop(0f)
        root.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                if (card.width <= 0 || card.height <= 0) return true
                root.viewTreeObserver.removeOnPreDrawListener(this)
                begin()
                return true
            }
        })
    }

    /** 첫 프레임이 그려지기 직전: 카드 자리·팝업 자리를 재고, 카드 모양에서 출발한다 */
    private fun begin() {
        header = card.findViewById(R.id.popupHeader)
        buttons = card.findViewById(R.id.popupButtons)
        val list = card.findViewById<ViewGroup>(R.id.popupList)
        rows = if (list == null) emptyList() else (0 until list.childCount).map { list.getChildAt(it) }
        dst.set(card.left.toFloat(), card.top.toFloat(), card.right.toFloat(), card.bottom.toFloat())
        locateOrigin()
        originPrevVisibility = origin.visibility
        // 카드는 숨기고 그 자리를 지금부터 MorphSurface 가 (같은 모양으로) 이어받는다
        origin.visibility = View.INVISIBLE
        originHidden = true
        ready = true
        card.alpha = 1f
        applyProgress(0f)
        root.viewTreeObserver.addOnPreDrawListener(follow)
        runSpring(1f, 300f, 0.86f) {
            applyProgress(1f)
            settled = true
            card.clipToOutline = false
        }
    }

    /** 팝업이 다 열린 뒤 창 크기가 바뀌면(분할 화면 등) 면이 카드를 따라가게 한다 */
    private val follow = ViewTreeObserver.OnPreDrawListener {
        if (settled && !closing) {
            val l = card.left.toFloat()
            val t = card.top.toFloat()
            val r = card.right.toFloat()
            val b = card.bottom.toFloat()
            if (l != dst.left || t != dst.top || r != dst.right || b != dst.bottom) {
                dst.set(l, t, r, b)
                applyProgress(1f)
            }
        }
        true
    }

    /** 카드(origin)의 지금 화면 위치를 출발/도착점으로 잡는다. 카드가 없으면 팝업을 살짝 줄이며 사라지게 한다 */
    private fun locateOrigin() {
        if (origin.isAttachedToWindow && origin.width > 0 && origin.height > 0) {
            val rl = IntArray(2)
            val ol = IntArray(2)
            root.getLocationOnScreen(rl)
            origin.getLocationOnScreen(ol)
            val l = (ol[0] - rl[0]).toFloat()
            val t = (ol[1] - rl[1]).toFloat()
            src.set(l, t, l + origin.width, t + origin.height)
            useGhost = true
            if (ghost == null) ghost = snapshotOrigin()
        } else {
            val w = dst.width() * 0.9f
            val h = dst.height() * 0.9f
            src.set(dst.centerX() - w / 2f, dst.centerY() - h / 2f, dst.centerX() + w / 2f, dst.centerY() + h / 2f)
            useGhost = false
        }
    }

    /** 카드 안의 글자·아이콘(배경 제외)을 그림으로 떠 둔다: 펼쳐지는 면 위에서 서서히 사라진다 */
    private fun snapshotOrigin(): Bitmap? {
        val w = origin.width
        val h = origin.height
        if (w <= 0 || h <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            if (origin is ViewGroup) {
                for (i in 0 until origin.childCount) {
                    val ch = origin.getChildAt(i)
                    if (ch.visibility != View.VISIBLE) continue
                    canvas.save()
                    canvas.translate(ch.left.toFloat(), ch.top.toFloat())
                    ch.draw(canvas)
                    canvas.restore()
                }
            } else {
                origin.draw(canvas)
            }
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    private fun runSpring(target: Float, stiffness: Float, damping: Float, onEnd: (() -> Unit)?) {
        spring?.cancel()
        val s = SpringAnimation(FloatValueHolder(progress))
        s.setStartValue(progress)
        s.setSpring(SpringForce(target).setStiffness(stiffness).setDampingRatio(damping))
        s.setMinimumVisibleChange(1f / 500f)
        s.addUpdateListener { _, value, _ -> applyProgress(value) }
        s.addEndListener { _, canceled, _, _ -> if (!canceled) onEnd?.invoke() }
        spring = s
        s.start()
    }

    /**
     * 0 = 카드 모양, 1 = 팝업 모양. 스프링이 살짝 넘칠 수 있어 1 을 넘는 값도 들어온다.
     * 가로는 그대로, 세로는 조금 앞서 자라게 해서 중심이 직선이 아니라 살짝 호를 그리며 움직인다.
     */
    private fun applyProgress(v: Float) {
        progress = v
        val t = if (v < 0f) 0f else v
        val c = if (t > 1f) 1f else t
        val ty = t * 0.5f + (1f - (1f - c) * (1f - c)) * 0.5f
        rect.set(
            lerp(src.left, dst.left, t), lerp(src.top, dst.top, ty),
            lerp(src.right, dst.right, t), lerp(src.bottom, dst.bottom, ty)
        )
        val radius = lerp(dp(originRadiusDp), dp(26f), c)

        // 카드로 돌아갈 자리가 없을 때만 면 전체가 서서히 사라진다
        val fadeAll = if (useGhost) 1f else seg(c, 0f, 0.6f)
        var fill = ColorUtils.blendARGB(startColor, endColor, c)
        fill = ColorUtils.setAlphaComponent(fill, (Color.alpha(fill) * fadeAll).toInt().coerceIn(0, 255))
        val strokeA = (lerp(255f, endStrokeAlpha.toFloat(), c) * fadeAll).toInt().coerceIn(0, 255)
        val stroke = ColorUtils.setAlphaComponent(outlineColor, strokeA)
        val ghostA = if (useGhost) ((1f - seg(c, 0f, 0.28f)) * 255f).toInt() else 0
        surface.update(rect, radius, fill, lerp(dp(1f), 1f, c), stroke, if (useGhost) ghost else null, ghostA)

        // 내용은 면 안쪽만 보인다 (카드 좌표로 바꿔서)
        clip.set(rect.left - card.left, rect.top - card.top, rect.right - card.left, rect.bottom - card.top)
        clipRadius = radius
        card.invalidateOutline()

        applyParts(c)
        applyBackdrop(c)
    }

    /** 머리말 → 항목(위에서 아래로) → 버튼 순서로 떠오른다. 닫을 때는 같은 값이 거꾸로 흘러 아래부터 먼저 사라진다 */
    private fun applyParts(c: Float) {
        header?.alpha = seg(c, 0.12f, 0.45f)
        buttons?.alpha = seg(c, 0.55f, 0.92f)
        val rise = dp(8f)
        rows.forEachIndexed { i, r ->
            val a = 0.28f + minOf(i, 10) * 0.028f
            val s = seg(c, a, a + 0.4f)
            r.alpha = s
            r.translationY = (1f - s) * rise
        }
    }

    /** 뒤 화면을 어둡게·흐리게 하는 정도를 진행도에 맞춘다 */
    private fun applyBackdrop(c: Float) {
        val w = window ?: return
        val dim = endDim * c
        val blur = if (blurOn) (endBlur * c).toInt() else 0
        val edge = c <= 0f || c >= 1f
        if (!edge && blur == lastBlur && Math.abs(dim - lastDim) < 0.004f) return
        lastDim = dim
        lastBlur = blur
        val lp = w.attributes
        lp.dimAmount = dim
        if (blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) lp.blurBehindRadius = blur
        w.attributes = lp
    }

    /** 닫기(뒤로 가기·바깥 누르기·버튼): 카드 자리로 접혀 들어간 뒤 창을 없앤다 */
    override fun dismiss() {
        if (finished) {
            super.dismiss()
            return
        }
        if (closing) return
        if (!ready || !isShowing || !Motion.enabled(context)) {
            dismissNow()
            return
        }
        closing = true
        settled = false
        dst.set(card.left.toFloat(), card.top.toFloat(), card.right.toFloat(), card.bottom.toFloat())
        locateOrigin()
        card.clipToOutline = true
        runSpring(0f, 380f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
            applyProgress(0f)
            // 카드를 먼저 되살리고, 다음 프레임에 창을 없앤다 (그 사이 카드가 한 프레임 비어 보이지 않게)
            restoreOrigin()
            root.postOnAnimation { dismissNow() }
        }
    }

    /** 애니메이션 없이 바로 닫는다 (같은 팝업을 곧바로 다시 열 때 등) */
    fun dismissNow() {
        if (finished) return
        finished = true
        spring?.cancel()
        restoreOrigin()
        ghost = null
        super.dismiss()
    }

    override fun onStop() {
        super.onStop()
        restoreOrigin()
    }

    private fun restoreOrigin() {
        if (originHidden) {
            originHidden = false
            origin.visibility = originPrevVisibility
        }
    }
}

/** 카드 모양에서 팝업 모양으로 변하는 면(둥근 사각형 + 테두리)과, 사라져 가는 카드 속 내용 그림 */
private class MorphSurface(ctx: Context) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ghostPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val inset = RectF()
    private val path = Path()
    private var radius = 0f
    private var visible = false
    private var ghost: Bitmap? = null
    private var ghostAlpha = 0

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun update(
        r: RectF, radius: Float, color: Int, strokeWidth: Float, strokeColor: Int,
        ghost: Bitmap?, ghostAlpha: Int
    ) {
        rect.set(r)
        this.radius = radius
        fill.color = color
        stroke.strokeWidth = strokeWidth
        stroke.color = strokeColor
        this.ghost = ghost
        this.ghostAlpha = ghostAlpha
        visible = true
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!visible) return
        canvas.drawRoundRect(rect, radius, radius, fill)
        if (Color.alpha(stroke.color) > 0 && stroke.strokeWidth > 0f) {
            val h = stroke.strokeWidth / 2f
            inset.set(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h)
            val rr = maxOf(radius - h, 0f)
            canvas.drawRoundRect(inset, rr, rr, stroke)
        }
        val g = ghost
        if (g != null && ghostAlpha > 0) {
            path.reset()
            path.addRoundRect(rect, radius, radius, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(path)
            canvas.translate(rect.left, rect.top)
            ghostPaint.alpha = ghostAlpha.coerceIn(0, 255)
            canvas.drawBitmap(g, 0f, 0f, ghostPaint)
            canvas.restore()
        }
    }
}
