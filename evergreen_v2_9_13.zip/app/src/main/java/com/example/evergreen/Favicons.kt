package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * 방문 기록 · 북마크 목록에 보여 줄 웹사이트 아이콘.
 * - 웹페이지가 알려 준 아이콘은 사이트(호스트)별로 파일에 저장해 둔다 (MainActivity 의 onReceivedIcon).
 * - 저장된 게 없으면 사이트의 /favicon.ico 를 받아 보고, 그래도 없으면 EXTERNAL_FALLBACK 서비스에서 받는다.
 *   (외부 서비스를 쓰고 싶지 않으면 EXTERNAL_FALLBACK 을 null 로 바꾸면 된다)
 * - 끝내 못 구하면 원래 아이콘(지구본/북마크)을 그대로 둔다.
 */
object Favicons {

    private const val EXTERNAL_FALLBACK = "https://www.google.com/s2/favicons?sz=64&domain=%s"

    private val mem = LruCache<String, Bitmap>(120)
    private val failed = HashSet<String>()
    private val pending = HashMap<String, MutableList<(Bitmap?) -> Unit>>()
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun host(url: String): String? =
        try { Uri.parse(url).host?.lowercase()?.removePrefix("www.")?.ifEmpty { null } } catch (e: Exception) { null }

    private fun dir(ctx: Context) = File(ctx.applicationContext.filesDir, "favicons").also { it.mkdirs() }
    private fun file(ctx: Context, host: String) = File(dir(ctx), host.replace(Regex("[^a-z0-9.-]"), "_") + ".png")

    /** 웹페이지가 알려 준 아이콘을 저장한다 (너무 작은 건 무시) */
    fun save(ctx: Context, url: String?, icon: Bitmap?) {
        val host = host(url ?: return) ?: return
        if (icon == null || icon.width < 16 || icon.height < 16) return
        val copy = icon.copy(Bitmap.Config.ARGB_8888, false) ?: return
        io.execute {
            try {
                file(ctx, host).outputStream().use { copy.compress(Bitmap.CompressFormat.PNG, 100, it) }
                synchronized(this) { mem.put(host, copy); failed.remove(host) }
            } catch (_: Exception) {}
        }
    }

    private fun fetch(urlStr: String): Bitmap? = try {
        val c = URL(urlStr).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 4000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode == 200) {
            val bytes = c.inputStream.use { it.readBytes() }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.takeIf { it.width >= 16 && it.height >= 16 }
        } else null
    } catch (_: Exception) { null }

    private fun load(ctx: Context, host: String): Bitmap? {
        val f = file(ctx, host)
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return it }
        val bmp = fetch("https://$host/favicon.ico")
            ?: EXTERNAL_FALLBACK?.let { fetch(it.format(host)) }
        if (bmp != null) try { f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Exception) {}
        return bmp
    }

    /** 아이콘 뷰에 사이트 아이콘을 입힌다. 아직 없으면 받아 오는 동안 원래 아이콘을 그대로 둔다. */
    fun apply(iv: ImageView, url: String) {
        val host = host(url)
        iv.tag = host
        if (host == null) return
        val ctx = iv.context.applicationContext
        fun show(b: Bitmap) {
            if (iv.tag != host) return
            iv.imageTintList = null
            iv.setImageBitmap(b)
        }
        synchronized(this) {
            mem.get(host)?.let { show(it); return }
            if (host in failed) return
            val waiting = pending[host]
            val cb: (Bitmap?) -> Unit = { b -> if (b != null) show(b) }
            if (waiting != null) { waiting.add(cb); return }
            pending[host] = mutableListOf(cb)
        }
        io.execute {
            val bmp = load(ctx, host)
            val cbs: List<(Bitmap?) -> Unit>
            synchronized(this) {
                if (bmp != null) mem.put(host, bmp) else failed.add(host)
                cbs = pending.remove(host) ?: emptyList()
            }
            main.post { cbs.forEach { it(bmp) } }
        }
    }
}
