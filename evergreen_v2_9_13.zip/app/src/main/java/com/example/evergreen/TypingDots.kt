package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos

/**
 * AI 가 답을 준비하는 동안 보여 주는 점 세 개.
 * 멈춤 없이 이어지는 물결로 점이 차례로 떠올랐다 가라앉고,
 * 떠오를 때 커지며 은은한 빛이 번진다. 그라데이션 색이 점 사이를 흘러 지나간다.
 * 시스템의 "애니메이션 끄기" 설정이면 움직이지 않고 점만 보여 준다.
 */
class TypingDotsView(context: Context, private val dotColor: Int, private val gradient: Boolean = false) : View(context) {
    private val d = resources.displayMetrics.density
    private val radius = 3.5f * d
    private val gap = 6.5f * d
    private val lift = 6f * d
    private val pad = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val animate = Motion.enabled(context)

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 950
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedFraction
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animate) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (radius * 2 * 3 + gap * 2 + pad * 2).toInt() + 2
        val h = (radius * 2 + lift + pad * 2).toInt() + 2
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val cy = height - radius - pad - 1f
        val startX = (width - (radius * 2 * 3 + gap * 2)) / 2f + radius
        for (i in 0 until 3) {
            // 점마다 늦게 출발해서 왼쪽부터 물결처럼 이어진다. 코사인이라 위·아래에서 속도가 부드럽게 줄어든다.
            val phase = t - i * 0.15f
            val base = if (animate) 0.5f - 0.5f * cos(phase * 2f * PI.toFloat()) else 0f
            // 정점은 살짝 뾰족하게, 바닥은 오래 머물게
            val wave = base * base * (3f - 2f * base)

            // 색은 세 점 모두 앱 대표색 하나로 고정 (움직이지 않는다)
            val color = if (gradient) AiGradient.BRAND else dotColor

            val cx = startX + i * (radius * 2 + gap)
            val y = cy - lift * wave
            val r = radius * (0.88f + 0.30f * wave)

            paint.color = color
            paint.alpha = (120 + 135 * wave).toInt()
            canvas.drawCircle(cx, y, r, paint)
        }
    }
}
