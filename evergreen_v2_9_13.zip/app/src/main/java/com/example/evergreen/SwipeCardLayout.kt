package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import androidx.dynamicanimation.animation.DynamicAnimation
import kotlin.math.abs

/**
 * 좌우로 밀어 넘기는 카드 (메뉴 미디어 플레이어가 여러 개일 때).
 * - 손가락을 따라 카드가 움직이고, 충분히 밀거나 빠르게 튕기면 [onSwipe] 로 넘어간다.
 * - 더 갈 곳이 없는 쪽은 저항감 있게 조금만 끌려가다 돌아온다.
 * - [ignoreView](재생 위치 막대) 위에서 시작한 터치는 가로로 끌어도 넘기지 않는다.
 */
class SwipeCardLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** dir: 다음(+1, 왼쪽으로 밀기) / 이전(-1). 넘길 수 있는지 */
    var canSwipe: (Int) -> Boolean = { false }
    var onSwipe: (Int) -> Unit = {}
    var ignoreView: View? = null

    /** true 면 (삭제 화면이 떠 있는 동안) 밀어 넘기지 않는다 */
    var locked = false

    /** 손가락을 따라 움직이는 안쪽 내용 (카드 바탕과 페이지 점은 제자리). 없으면 카드 전체 */
    var content: View? = null
    private val mover: View get() = content ?: this

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var ignored = false
    private var dragging = false
    private var tracker: VelocityTracker? = null

    private fun hitIgnored(x: Float, y: Float): Boolean {
        val v = ignoreView ?: return false
        if (v.visibility != VISIBLE) return false
        return x >= v.left && x <= v.right && y >= v.top && y <= v.bottom
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y
                ignored = hitIgnored(ev.x, ev.y)
                dragging = false
                tracker?.recycle(); tracker = VelocityTracker.obtain()
                tracker?.addMovement(ev)
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                if (!ignored && !dragging && !locked) {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (abs(dx) > slop && abs(dx) > abs(dy) * 1.2f) {
                        dragging = true
                        parent?.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { tracker?.recycle(); tracker = null }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        tracker?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dx = ev.x - downX
                val dir = if (dx < 0) 1 else -1
                val k = if (canSwipe(dir)) 0.75f else 0.2f
                val m = mover
                m.translationX = dx * k
                m.alpha = 1f - 0.7f * (abs(m.translationX) / (width.coerceAtLeast(1) * 0.6f)).coerceAtMost(1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    tracker?.computeCurrentVelocity(1000)
                    val vx = tracker?.xVelocity ?: 0f
                    val dx = ev.x - downX
                    val dir = if (dx < 0) 1 else -1
                    val far = abs(dx) > width * 0.22f
                    val fast = abs(vx) > 900f && (vx < 0) == (dx < 0)
                    if (ev.actionMasked == MotionEvent.ACTION_UP && (far || fast) && canSwipe(dir)) {
                        onSwipe(dir)
                    } else {
                        springBack()
                    }
                }
                dragging = false
                tracker?.recycle(); tracker = null
            }
        }
        return true
    }

    fun springBack() {
        Motion.spring(mover, DynamicAnimation.TRANSLATION_X, 0f, 420f, 0.8f)
        Motion.spring(mover, DynamicAnimation.ALPHA, 1f, 420f, 1f)
    }
}
