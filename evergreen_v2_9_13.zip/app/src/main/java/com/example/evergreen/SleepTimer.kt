package com.example.evergreen

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * 취침 타이머: 정한 시간이 지나면 [onFire] 를 부른다 (내장 플레이어는 거기서 재생을 멈춘다).
 * 일반 내장 플레이어와 미러링 내장 플레이어가 함께 쓴다.
 */
class SleepTimer(private val onFire: () -> Unit) {
    private val h = Handler(Looper.getMainLooper())
    private var endAt = 0L
    private val run = Runnable { endAt = 0L; onFire() }

    val active: Boolean get() = endAt > 0L

    fun start(minutes: Int) {
        cancel()
        endAt = SystemClock.elapsedRealtime() + minutes * 60_000L
        h.postDelayed(run, minutes * 60_000L)
    }

    fun cancel() {
        h.removeCallbacks(run)
        endAt = 0L
    }

    /** 설정 줄에 보여 줄 값: 끄면 "끔", 켜 있으면 남은 시간 */
    fun valueLabel(): String {
        if (endAt <= 0L) return "끔"
        val m = ((endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L) + 59_999L) / 60_000L
        return "${label(m.toInt().coerceAtLeast(1))} 남음"
    }

    companion object {
        /** 고를 수 있는 시간 (분) */
        val OPTIONS = intArrayOf(10, 15, 30, 45, 60, 90, 120)

        fun label(min: Int): String = when {
            min < 60 -> "${min}분"
            min % 60 == 0 -> "${min / 60}시간"
            else -> "${min / 60}시간 ${min % 60}분"
        }
    }
}
