package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.util.AttributeSet
import android.widget.TextView

/**
 * 10초 앞/뒤 아이콘의 원 안에 얹는 숫자.
 * 글꼴 여백(ascent/descent)에 따라 숫자가 위아래로 치우치지 않게, 글자의 "실제 잉크 범위"를 재서
 * 원의 중심에 정확히 맞춰 그린다.
 *
 * 아이콘(24 단위 벡터)의 원 중심은 (12, 13) 이라 뷰 중심보다 1/24 만큼 아래에 있다.
 * 이 뷰는 아이콘과 같은 칸(가운데 정렬)에 match_parent 로 겹쳐 놓고, iconDp 는 아이콘 한 변의 길이(dp)이다.
 */
class IconNumberView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle,
) : TextView(context, attrs, defStyleAttr) {

    private val bounds = Rect()
    /** 아이콘 한 변 (dp). 레이아웃의 아이콘 크기와 같아야 한다. */
    private val iconDp = 28f
    /** 아이콘 원 중심이 뷰 중심보다 아래로 내려가 있는 정도 (벡터 좌표 1/24 = iconDp/24 dp) */
    private val circleDropDp = iconDp / 24f

    override fun onDraw(canvas: Canvas) {
        val s = text?.toString().orEmpty()
        if (s.isEmpty()) return
        val p = paint
        p.color = currentTextColor
        p.textAlign = android.graphics.Paint.Align.CENTER
        p.getTextBounds(s, 0, s.length, bounds)
        val cx = width / 2f
        val cy = height / 2f + circleDropDp * resources.displayMetrics.density
        // 잉크 범위의 세로 중앙(bounds.centerY, baseline 기준 음수)이 cy 에 오도록 baseline 을 정한다
        val baseline = cy - bounds.exactCenterY()
        canvas.drawText(s, cx, baseline, p)
    }
}
