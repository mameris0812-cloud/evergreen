package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * 동영상 전체화면 컨테이너: 화면 가운데에서 아래로 밀면 영상이 손가락을 따라 내려오며 작아지고,
 * 충분히 밀고 놓으면 전체화면을 빠져나간다. 모자라게 밀고 놓으면 탄성 있게 제자리로 돌아간다.
 *
 * 오작동을 줄이려고 아래 조건을 모두 만족할 때만 끼어든다 (그 전에는 페이지가 터치를 그대로 받는다):
 * - 손가락 하나, 시작 위치가 화면 대부분의 영역 (위쪽 제목 막대·아래쪽 컨트롤 막대, 시스템 제스처가 먹는 좌우 가장자리만 제외)
 * - 처음부터 분명하게 아래쪽으로 움직임 (가로로 먼저 움직이거나 위로 움직이면 이번 터치는 포기 → 탐색 막대 끌기 등과 겹치지 않음)
 * - 놓을 때 충분히 내려왔거나 빠르게 휙 내렸을 때만 나감. 끌고 있는 도중 다시 위로 올리면 취소됨
 */
class FullscreenSwipeLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    /** 지금 이 제스처를 쓸 수 있는지 (설정이 켜져 있고 전체화면 중일 때) */
    var enabledProvider: () -> Boolean = { false }

    /** 터치를 시작한 자리가 제스처를 써도 되는 곳인지 (진행 막대 위처럼 따로 끌어야 하는 자리를 빼는 데 쓴다) */
    var startFilter: (Float, Float) -> Boolean = { _, _ -> true }

    /** 이 레이아웃 좌표 (x, y) 가 [v] 안(사방으로 [pad] 만큼 넓혀서)에 있는지 */
    fun hits(v: View, x: Float, y: Float, pad: Float): Boolean {
        val a = IntArray(2)
        val b = IntArray(2)
        v.getLocationInWindow(a)
        getLocationInWindow(b)
        val l = a[0] - b[0] - pad
        val t = a[1] - b[1] - pad
        return x in l..(l + v.width + 2 * pad) && y in t..(t + v.height + 2 * pad)
    }

    /**
     * 콘텐츠(자식 뷰)와 함께 움직일 다른 뷰들. 미러링은 영상이 이 레이아웃 밖(뒤쪽 웹뷰)에 있고
     * 여기엔 컨트롤 UI 만 있어서, 웹뷰 쪽도 같이 내려가게 하려고 쓴다.
     */
    var companions: () -> List<View> = { emptyList() }

    /** 놓았을 때 나가기로 결정되고 나가는 애니메이션이 끝난 뒤 불린다 */
    var onDismiss: () -> Unit = {}

    private val density = resources.displayMetrics.density
    private val slop = maxOf(ViewConfiguration.get(ctx).scaledTouchSlop * 1.5f, 14f * density)
    private val flingV = 1000f * density
    private val minFlingDist = 48f * density

    private var eligible = false
    private var dragging = false
    private var animating = false
    private var downX = 0f
    private var downY = 0f
    private var armed = false          // 지금 놓으면 나가는 거리에 도달했는지 (햅틱 1회용)
    private var vt: VelocityTracker? = null

    private fun content(): View? = if (childCount > 0) getChildAt(childCount - 1) else null

    /** 영상 위치·크기·투명도를 원래대로 돌린다 (영상 뷰는 다음 전체화면에서 다시 쓰일 수 있다) */
    fun resetTransform() {
        animating = false          // 먼저 내려야 cancel() 이 끝 동작(onDismiss)을 다시 부르지 않는다
        content()?.let {
            it.animate().cancel()
            it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f; it.alpha = 1f
        }
        companions().forEach {
            it.animate().cancel()
            it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f; it.alpha = 1f
        }
        dragging = false
        eligible = false
        armed = false
        recycle()
    }

    private fun recycle() { vt?.recycle(); vt = null }

    /**
     * 터치를 아래 영상(웹뷰)보다 먼저 지켜본다. 예전엔 onInterceptTouchEvent 로 끼어들었는데,
     * 웹 영상 화면은 requestDisallowInterceptTouchEvent(true) 로 끼어들기를 막거나 아래에서 터치를 받지 않아서
     * 움직임이 여기까지 오지 않았다. dispatchTouchEvent 는 그런 것과 상관없이 모든 터치가 지나간다.
     */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (animating) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = false; armed = false
                val w = width.toFloat(); val h = height.toFloat()
                eligible = enabledProvider() && content() != null &&
                    ev.x in (w * 0.06f)..(w * 0.94f) && ev.y in (h * 0.08f)..(h * 0.82f) &&
                    startFilter(ev.x, ev.y)
                downX = ev.x; downY = ev.y
                recycle()
                if (eligible) { vt = VelocityTracker.obtain(); vt?.addMovement(ev) }
                // 아래에서 아무도 DOWN 을 받지 않아도 이후 움직임이 여기로 오게 true 로 돌려준다
                val r = super.dispatchTouchEvent(ev)
                return r || eligible
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!dragging) eligible = false          // 두 손가락(확대 등)이면 포기
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && eligible) {
                    vt?.addMovement(ev)
                    val dx = ev.x - downX; val dy = ev.y - downY
                    if (dy < -slop * 0.5f || (abs(dx) > slop && abs(dx) > dy)) {
                        eligible = false
                    } else if (dy > slop && dy > abs(dx) * 1.3f) {   // 비스듬히 내려도(약 40° 이상) 인식
                        dragging = true
                        parent?.requestDisallowInterceptTouchEvent(true)
                        // 아래 영상에는 터치가 취소됐다고 알려서, 끌던 동작이 이어지지 않게 한다
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(c)
                        c.recycle()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) { eligible = false; recycle() }
            }
        }
        if (dragging) {
            handleDrag(ev)
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun handleDrag(ev: MotionEvent) {
        vt?.addMovement(ev)
        val v = content() ?: return
        val h = height.toFloat().coerceAtLeast(1f)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val dy = (ev.y - downY - slop).coerceAtLeast(0f)       // 끼어든 순간부터 따라가서 툭 튀지 않게
                val p = (dy / (h * 0.45f)).coerceIn(0f, 1f)
                val s = 1f - 0.12f * p
                for (t in targets(v)) {
                    t.translationY = dy * 0.85f
                    t.scaleX = s; t.scaleY = s
                    t.alpha = 1f - 0.45f * p
                }
                val ready = dy > h * 0.22f
                if (ready != armed) {
                    armed = ready
                    // 놓으면 나가는 거리에 닿거나, 다시 돌아가면 살짝 진동
                    performHapticFeedback(
                        if (ready) {
                            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.KEYBOARD_TAP
                        } else HapticFeedbackConstants.CLOCK_TICK
                    )
                }
            }
            MotionEvent.ACTION_UP -> {
                vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                val dy = (ev.y - downY - slop).coerceAtLeast(0f)
                dragging = false; eligible = false; recycle()
                if (dy > h * 0.22f || (vy > flingV && dy > minFlingDist)) dismiss(v, h) else springBack(v)
            }
            MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> {
                dragging = false; eligible = false; recycle()
                springBack(v)
            }
        }
    }

    /** 같이 움직일 뷰들: 콘텐츠 + [companions] (중복 없이) */
    private fun targets(v: View): List<View> {
        val extra = companions().filter { it !== v }
        return if (extra.isEmpty()) listOf(v) else listOf(v) + extra
    }

    private fun dismiss(v: View, h: Float) {
        animating = true
        val ts = targets(v)
        ts.forEachIndexed { i, t ->
            t.animate().cancel()
            val a = t.animate()
                .translationY(h * 0.55f).scaleX(0.82f).scaleY(0.82f).alpha(0f)
                .setDuration(190).setInterpolator(AccelerateInterpolator(1.4f))
            // 끝 동작은 한 번만 (첫 뷰에서)
            if (i == 0) a.withEndAction {
                if (!animating) return@withEndAction      // 그 사이 다른 경로(뒤로 가기 등)로 이미 닫힌 경우
                animating = false
                onDismiss()
            }
            a.start()
        }
    }

    private fun springBack(v: View) {
        armed = false
        for (t in targets(v)) {
            t.animate().cancel()
            t.animate()
                .translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(260).setInterpolator(OvershootInterpolator(1.1f))
                .start()
        }
    }
}
