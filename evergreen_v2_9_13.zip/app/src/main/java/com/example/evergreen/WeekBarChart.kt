package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.SpringAnimation
import java.util.Locale
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * 최근 7일 막대그래프 (삼성 인터넷의 광고 차단 현황 같은 모양).
 * 둥근 막대 + 오른쪽에 눈금 숫자가 붙은 옅은 가로선 + 아래에 요일, 오늘은 동그라미로 강조한다.
 * 처음 보일 때 막대가 왼쪽부터 시간차를 두고(막대마다 [STEP_MS] 간격) 스프링으로 자라 오른다.
 * 앱의 다른 움직임(Motion.spring)과 같은 물리 기반이라 끝에서 살짝 넘쳤다 안착한다.
 * 애니메이션을 끈 기기에서는 바로 그려진다.
 *
 * 시작 시점: 뷰가 붙는 순간이 아니라 '눈에 보이기 시작할 때'다. 새 탭 카드에서 펼쳐지는 팝업(MorphDialog)은
 * 항목을 진행도에 맞춰 서서히 나타내므로, 차트(와 부모들)의 alpha 가 [SHOW_AT] 를 넘으면 자라기 시작한다.
 * 그래서 면이 아직 펼쳐지는 중에 막대가 먼저 자라 버려 앞부분이 안 보이는 일이 없다.
 */
class WeekBarChart(
    ctx: Context,
    private val values: List<Int>,
    private val labels: List<String>,
    private val barColor: Int,
    private val textColor: Int,
    private val todayTextColor: Int
) : View(ctx) {

    private fun dp(v: Int) = v * resources.displayMetrics.density
    private fun sp(v: Float) = v * resources.displayMetrics.scaledDensity

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ColorUtils.setAlphaComponent(textColor, 46)
        strokeWidth = dp(1)
    }
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textColor
        textSize = sp(12f)
    }
    private val dayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textColor
        textSize = sp(13f)
        textAlign = Paint.Align.CENTER
    }
    private val todayDayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = todayTextColor
        textSize = sp(13f)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = textColor }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    /** 막대별 자라는 정도 (0 → 1, 스프링이라 잠깐 1 을 넘을 수 있다) */
    private val grow = FloatArray(values.size) { 1f }
    private val springs = ArrayList<SpringAnimation>()
    private val pending = ArrayList<Runnable>()
    private var attachedAt = 0L
    private var started = false

    /** 보이기 시작했는지 지켜보다가(매 프레임) 그때 막대들을 차례로 출발시킨다 */
    private val gate = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow || started) return
            val waited = SystemClock.uptimeMillis() - attachedAt
            if (shownFraction() >= SHOW_AT || waited >= MAX_WAIT_MS) startGrow() else postOnAnimation(this)
        }
    }

    /** 가로선 간격 (눈금 한 칸) — 가장 큰 값이 두 번째 선 아래에 오도록 깔끔한 수로 고른다 */
    private val step: Int = niceStep(values.maxOrNull() ?: 0)
    private val axisMax: Float = step * 2 * 1.08f

    init {
        contentDescription = "최근 7일 광고 차단 건수. " +
            labels.indices.joinToString(", ") { "${labels[it]}요일 ${values[it]}건" }
    }

    companion object {
        /** 막대 사이 출발 간격 (Motion.stagger 의 기본 간격과 비슷하게) */
        private const val STEP_MS = 40L
        private const val MAX_STAGGER_MS = 280L

        /** 차트가 이만큼 이상 드러나면 자라기 시작한다 (펼쳐지는 팝업에서 항목이 나타나는 중간쯤) */
        private const val SHOW_AT = 0.6f

        /** 끝내 드러나지 않아도(스크롤 밖 등) 이 시간 뒤에는 시작한다 */
        private const val MAX_WAIT_MS = 700L
    }

    private fun niceStep(maxValue: Int): Int {
        val raw = max(maxValue, 4) / 1.8f
        val mag = 10.0.pow(floor(log10(raw.toDouble()))).toFloat()
        for (m in floatArrayOf(1f, 2f, 2.5f, 5f, 10f)) {
            if (m * mag >= raw) return max(1, (m * mag).toInt())
        }
        return max(1, (10 * mag).toInt())
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize(suggestedMinimumWidth, widthMeasureSpec),
            resolveSize(dp(190).toInt(), heightMeasureSpec)
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!Motion.enabled(context) || values.all { it == 0 }) return
        stop()
        // 첫 프레임부터 막대는 0 에서 시작한다
        grow.fill(0f)
        started = false
        attachedAt = SystemClock.uptimeMillis()
        postOnAnimation(gate)
    }

    override fun onDetachedFromWindow() {
        stop()
        grow.fill(1f)
        super.onDetachedFromWindow()
    }

    /** 나(와 부모들)의 alpha 를 곱한 값 = 지금 화면에 얼마나 드러나 있는지 */
    private fun shownFraction(): Float {
        var a = 1f
        var v: View? = this
        while (v != null) {
            a *= v.alpha
            v = v.parent as? View
        }
        return a
    }

    /** 막대마다 시간차를 두고 스프링을 출발시킨다 (왼쪽 → 오른쪽, 오른쪽 끝이 오늘) */
    private fun startGrow() {
        started = true
        values.forEachIndexed { i, v ->
            if (v <= 0) return@forEachIndexed
            val begin = Runnable {
                springs += Motion.springValue(
                    from = 0f, to = 1f, stiffness = 190f, damping = 0.72f,
                    onUpdate = { grow[i] = it.coerceAtLeast(0f); invalidate() },
                    onEnd = { grow[i] = 1f; invalidate() }
                )
            }
            pending += begin
            postDelayed(begin, minOf(i * STEP_MS, MAX_STAGGER_MS))
        }
    }

    private fun stop() {
        removeCallbacks(gate)
        pending.forEach { removeCallbacks(it) }
        pending.clear()
        springs.forEach { it.cancel() }
        springs.clear()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val labelArea = dp(38)
        val top = dp(10)
        val base = height - labelArea
        val plotH = base - top
        val axisW = dp(44)
        val plotW = w - axisW

        // 가로선 + 오른쪽 눈금 숫자
        for (i in 1..2) {
            val v = step * i
            val y = base - plotH * (v / axisMax)
            c.drawLine(0f, y, plotW, y, linePaint)
            c.drawText(
                String.format(Locale.getDefault(), "%,d", v),
                plotW + dp(10),
                y + axisPaint.textSize * 0.35f,
                axisPaint
            )
        }
        c.drawLine(0f, base, plotW, base, linePaint)

        val slot = plotW / values.size
        val barW = min(dp(28), slot * 0.56f)
        val radius = barW / 2f

        values.forEachIndexed { i, v ->
            val cx = slot * (i + 0.5f)
            // 아주 작은 값도 자라는 동안은 같이 자란다 (처음부터 3dp 토막이 보이지 않게)
            val h = if (v > 0) max(dp(3), plotH * (v / axisMax)) * grow[i] else 0f
            if (h > 0.5f) {
                val l = cx - barW / 2f
                val t = base - h
                barPaint.shader = LinearGradient(
                    0f, t, 0f, base,
                    barColor,
                    ColorUtils.setAlphaComponent(barColor, 150),
                    Shader.TileMode.CLAMP
                )
                // 위쪽 모서리만 둥글게 (아래는 기준선에 붙는다)
                val r = min(radius, h)
                path.reset()
                rect.set(l, t, l + barW, base)
                path.addRoundRect(rect, floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f), Path.Direction.CW)
                c.drawPath(path, barPaint)
            }

            // 요일 (오늘은 동그라미 강조)
            val textY = base + dp(24)
            val isToday = i == values.lastIndex
            if (isToday) {
                c.drawCircle(cx, textY - dayPaint.textSize * 0.35f, dp(13), dotPaint)
            }
            c.drawText(labels[i], cx, textY, if (isToday) todayDayPaint else dayPaint)
        }
    }
}
