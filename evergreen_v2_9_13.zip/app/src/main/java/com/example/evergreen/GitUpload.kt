package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.text.InputType
import android.util.Base64
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.security.KeyStore
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * 앱에서 고른 파일을 GitHub 저장소(BuildConfig.UPDATE_REPO) 맨 위 폴더에 그대로 올린다.
 *
 *  - zip 도 풀지 않고 zip 파일 그대로 올린다. 같은 이름이 있으면 덮어쓰고, 내용이 똑같으면 올리지 않는다.
 *  - 다른 파일은 건드리지 않는다.
 *  - 커밋은 마지막에 한 번만 반영하므로, 중간에 취소하거나 실패해도 저장소는 그대로다.
 *  - 토큰(PAT)은 빌드에 넣지 않고 사용자가 직접 붙여 넣는다. 안드로이드 Keystore 키로 암호화해서 저장한다.
 *    권장: 이 저장소 한 곳만 고른 fine-grained 토큰, 권한은 Contents: Read and write 만 (워크플로 파일도 올리려면 Workflows 도).
 */
object GitUpload {
    private const val PREFS = "evergreen_gitupload"
    private const val KEY_TOKEN = "tok"
    private const val ALIAS = "evergreen_gh_token"

    private const val MAX_FILE = 25L * 1024 * 1024
    private const val MAX_TOTAL = 200L * 1024 * 1024

    private class GitErr(msg: String) : Exception(msg)
    private class Budget { var used = 0L }
    private class Item(val path: String, val file: File, val mode: String, val isNew: Boolean)
    private class Plan(
        val branch: String, val parent: String, val baseTree: String,
        val changed: List<Item>, val unchanged: Int, val skipped: Int, val dir: File
    )

    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .followSslRedirects(false)
        .build()
    private val JSON = "application/json".toMediaType()

    // ───────── 토큰 저장 (Keystore AES-GCM) ─────────

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun saveToken(ctx: Context, token: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secretKey())
        val out = c.iv + c.doFinal(token.toByteArray())
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TOKEN, Base64.encodeToString(out, Base64.NO_WRAP)).apply()
    }

    /** 저장된 토큰(없으면 null). 빌드 진행 상황이 GitHub 요청 한도를 늘리려고 읽어 간다 */
    fun loadToken(ctx: Context): String? {
        return try {
            val saved = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TOKEN, null)
            if (saved == null) {
                null
            } else {
                val all = Base64.decode(saved, Base64.NO_WRAP)
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, all, 0, 12))
                String(c.doFinal(all, 12, all.size - 12))
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun clearToken(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_TOKEN).apply()
    }

    // ───────── 진입 ─────────

    /** 메뉴에서 눌렀을 때. 토큰이 없으면 먼저 받고, 있으면 안내 창을 띄운다. pickFile 은 파일 선택 화면을 여는 함수. */
    fun begin(act: Activity, pickFile: () -> Unit) {
        if (!Updater.enabled()) {
            AppToast.show(act, "업로드할 저장소가 설정되지 않았어요 (GitHub Actions 로 빌드한 앱에서만 동작해요)")
            return
        }
        if (loadToken(act) == null) { askToken(act, pickFile); return }
        MaterialAlertDialogBuilder(act)
            .setTitle("GitHub 에 올리기")
            .setMessage("저장소: ${BuildConfig.UPDATE_REPO}\n\n고른 파일을 압축을 풀지 않고 그대로 저장소 맨 위에 올려요. 같은 이름이 있으면 덮어써요.")
            .setPositiveButton("파일 선택") { _, _ -> pickFile() }
            .setNeutralButton("토큰 관리") { _, _ ->
                MaterialAlertDialogBuilder(act)
                    .setItems(arrayOf("토큰 변경", "토큰 삭제")) { _, which ->
                        if (which == 0) askToken(act) {} else { clearToken(act); AppToast.show(act, "토큰을 지웠어요") }
                    }.show()
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    private fun askToken(act: Activity, then: () -> Unit) {
        val dp = act.resources.displayMetrics.density
        val et = EditText(act).apply {
            hint = "github_pat_…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }
        val box = LinearLayout(act).apply {
            setPadding((24 * dp).toInt(), (8 * dp).toInt(), (24 * dp).toInt(), 0)
            addView(et, LinearLayout.LayoutParams(-1, -2))
        }
        MaterialAlertDialogBuilder(act)
            .setTitle("GitHub 토큰")
            .setMessage("이 저장소 한 곳만 고른 fine-grained 토큰을 만들고, 권한은 'Contents: Read and write' 만 주세요. 토큰은 이 기기에 암호화해서 저장돼요.")
            .setView(box)
            .setPositiveButton("저장") { _, _ ->
                val t = et.text.toString().trim()
                if (t.length < 20 || t.any { it.isWhitespace() }) {
                    AppToast.show(act, "토큰 형식이 올바르지 않아요")
                } else {
                    try { saveToken(act, t); AppToast.show(act, "토큰을 저장했어요"); then() }
                    catch (e: Exception) { AppToast.show(act, "토큰을 저장하지 못했어요") }
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // ───────── GitHub API ─────────

    private fun api(token: String, method: String, path: String, body: JSONObject? = null): JSONObject {
        val rb = if (method == "GET") null else (body?.toString() ?: "{}").toRequestBody(JSON)
        val req = Request.Builder()
            .url("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}$path")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "evergreen-updater")
            .method(method, rb)
            .build()
        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(text).optString("message") }.getOrDefault("")
                throw GitErr(
                    when (resp.code) {
                        401 -> "토큰이 올바르지 않거나 만료됐어요"
                        403 -> "권한이 없어요 (Contents: Read and write 가 필요해요; 워크플로 파일은 Workflows 권한도 필요해요) $msg"
                        404 -> "저장소를 찾지 못했거나 토큰에 이 저장소 권한이 없어요"
                        409 -> "저장소가 비어 있거나 충돌했어요. $msg"
                        422 -> "GitHub 가 거부했어요: $msg"
                        else -> "서버 오류 (${resp.code}) $msg"
                    }
                )
            }
            return JSONObject(text)
        }
    }

    // ───────── 1단계: 풀고 비교하기 ─────────

    fun upload(act: Activity, uri: Uri) {
        val token = loadToken(act) ?: run { askToken(act) {}; return }
        val app = act.applicationContext
        val canceled = AtomicBoolean(false)
        val (dlg, label, _) = progressDialog(act, "파일 확인 중", canceled)
        Thread {
            var plan: Plan? = null
            var err: String? = null
            try {
                plan = analyze(app, uri, token, canceled) { t -> main.post { label.text = t } }
            } catch (e: InterruptedException) {
            } catch (e: Exception) {
                err = e.message ?: "실패했어요"
            }
            main.post {
                runCatching { dlg.dismiss() }
                when {
                    canceled.get() -> plan?.dir?.deleteRecursively()
                    err != null -> { File(app.cacheDir, "git_upload").deleteRecursively(); AppToast.show(act, err) }
                    plan != null && !act.isFinishing && !act.isDestroyed -> confirm(act, token, plan)
                }
            }
        }.start()
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0)?.let { n -> if (n.isNotBlank()) return n.substringAfterLast('/') }
            }
        }
        return "upload.bin"
    }

    /** 파일 이름에서 경로 문자와 위험한 이름을 걸러 낸다 */
    private fun safeName(n: String): String {
        val x = n.replace('\\', '/').substringAfterLast('/').trim()
        return if (x.isEmpty() || x == "." || x == "..") "upload.bin" else x
    }

    private fun copyLimited(input: InputStream, dest: File, budget: Budget) {
        dest.outputStream().use { out ->
            val buf = ByteArray(64 * 1024)
            var size = 0L
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                size += n
                budget.used += n.toLong()
                if (size > MAX_FILE) throw GitErr("파일 하나가 너무 커요 (최대 25MB)")
                if (budget.used > MAX_TOTAL) throw GitErr("전체 크기가 너무 커요 (최대 200MB)")
                out.write(buf, 0, n)
            }
        }
    }

    private fun gitSha(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update("blob ${f.length()}\u0000".toByteArray())
        f.inputStream().use { i ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = i.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun analyze(app: Context, uri: Uri, token: String, canceled: AtomicBoolean, say: (String) -> Unit): Plan {
        val dir = File(app.cacheDir, "git_upload").apply { deleteRecursively(); mkdirs() }
        val files = ArrayList<Pair<String, File>>()
        val budget = Budget()

        // 고른 파일은 풀지 않고 그대로(zip 도 zip 인 채로) 저장소 맨 위 폴더에 올린다
        val raw = app.contentResolver.openInputStream(uri) ?: throw GitErr("파일을 열지 못했어요")
        raw.use {
            val f = File(dir, "0.bin")
            copyLimited(it, f, budget)
            files.add(safeName(displayName(app, uri)) to f)
        }
        if (files.isEmpty() || files[0].second.length() == 0L) throw GitErr("올릴 파일이 비어 있어요")

        say("저장소 확인 중…")
        val branch = api(token, "GET", "").getString("default_branch")
        val parent = try {
            api(token, "GET", "/git/ref/heads/$branch").getJSONObject("object").getString("sha")
        } catch (e: GitErr) {
            throw GitErr("저장소에 커밋이 하나도 없어요. 파일 하나를 먼저 만들어 주세요")
        }
        val baseTree = api(token, "GET", "/git/commits/$parent").getJSONObject("tree").getString("sha")
        val tree = api(token, "GET", "/git/trees/$baseTree?recursive=1")
        val existing = HashMap<String, Pair<String, String>>() // path → (sha, mode)
        if (!tree.optBoolean("truncated")) {
            val arr = tree.optJSONArray("tree") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                if (t.optString("type") == "blob") existing[t.getString("path")] = t.getString("sha") to t.getString("mode")
            }
        }

        say("바뀐 파일 찾는 중…")
        val changed = ArrayList<Item>()
        var unchanged = 0
        for ((path, f) in files) {
            if (canceled.get()) throw InterruptedException()
            val old = existing[path]
            when {
                old == null -> changed.add(Item(path, f, "100644", true))
                old.first != gitSha(f) -> changed.add(Item(path, f, old.second, false)) // 실행 권한 등 기존 모드는 유지
                else -> unchanged++
            }
        }
        return Plan(branch, parent, baseTree, changed, unchanged, 0, dir)
    }

    // ───────── 2단계: 확인 → 올리기 ─────────

    private fun confirm(act: Activity, token: String, plan: Plan) {
        if (plan.changed.isEmpty()) {
            plan.dir.deleteRecursively()
            AppToast.show(act, "바뀐 파일이 없어요 (${plan.unchanged}개 모두 저장소와 같아요)")
            return
        }
        val nNew = plan.changed.count { it.isNew }
        val nMod = plan.changed.size - nNew
        val list = plan.changed.take(12).joinToString("\n") { (if (it.isNew) "＋ " else "✎ ") + it.path } +
            if (plan.changed.size > 12) "\n… 외 ${plan.changed.size - 12}개" else ""
        val wf = plan.changed.any { it.path.startsWith(".github/workflows/") }
        MaterialAlertDialogBuilder(act)
            .setTitle("이대로 올릴까요?")
            .setMessage(
                "${BuildConfig.UPDATE_REPO} · ${plan.branch}\n" +
                    "새 파일 $nNew · 수정 $nMod · 그대로 ${plan.unchanged}\n\n$list" +
                    (if (wf) "\n\n※ 워크플로 파일이 들어 있어요. 토큰에 Workflows 권한이 없으면 거부돼요." else "")
            )
            .setPositiveButton("올리기") { _, _ -> commit(act, token, plan) }
            .setNegativeButton("취소") { _, _ -> plan.dir.deleteRecursively() }
            .setOnCancelListener { plan.dir.deleteRecursively() }
            .show()
    }

    private fun commit(act: Activity, token: String, plan: Plan) {
        val canceled = AtomicBoolean(false)
        val (dlg, label, bar) = progressDialog(act, "GitHub 에 올리는 중", canceled)
        Thread {
            var err: String? = null
            var sha: String? = null
            try {
                val n = plan.changed.size
                val entries = ArrayList<JSONObject>()
                plan.changed.forEachIndexed { i, it ->
                    if (canceled.get()) throw InterruptedException()
                    main.post { label.text = "올리는 중… ${i + 1}/$n"; bar.isIndeterminate = false; bar.progress = (i * 100 / n) }
                    val b64 = Base64.encodeToString(it.file.readBytes(), Base64.NO_WRAP)
                    val r = api(token, "POST", "/git/blobs", JSONObject().put("content", b64).put("encoding", "base64"))
                    entries.add(JSONObject().put("path", it.path).put("mode", it.mode).put("type", "blob").put("sha", r.getString("sha")))
                }
                if (canceled.get()) throw InterruptedException()
                main.post { label.text = "커밋 만드는 중…"; bar.isIndeterminate = true }
                // 확인 창을 띄운 뒤에도 저장소 끝(head)은 움직일 수 있다(빌드 봇 커밋, 앞서 올린 파일의 빌드 결과 등).
                // 그래서 올리는 순간의 최신 head 를 다시 읽어 그 위에 쌓고, 그 사이 또 바뀌어 "fast forward 아님" 으로 거부되면 처음부터 다시 쌓는다(최대 3번).
                // 올리는 파일은 경로 단위(blob)라서 최신 트리 위에 얹어도 다른 파일은 건드리지 않는다.
                var attempt = 0
                while (true) {
                    attempt++
                    if (canceled.get()) throw InterruptedException()
                    val head = api(token, "GET", "/git/ref/heads/${plan.branch}").getJSONObject("object").getString("sha")
                    var base = if (head == plan.parent) plan.baseTree
                        else api(token, "GET", "/git/commits/$head").getJSONObject("tree").getString("sha")
                    for (chunk in entries.chunked(300)) {
                        base = api(token, "POST", "/git/trees", JSONObject().put("base_tree", base).put("tree", JSONArray(chunk))).getString("sha")
                    }
                    val c = api(
                        token, "POST", "/git/commits",
                        JSONObject().put("message", if (n == 1) "Upload ${plan.changed[0].path} via Evergreen app" else "Upload via Evergreen app ($n files)")
                            .put("tree", base).put("parents", JSONArray().put(head))
                    )
                    if (canceled.get()) throw InterruptedException()
                    try {
                        api(token, "PATCH", "/git/refs/heads/${plan.branch}", JSONObject().put("sha", c.getString("sha")))
                        sha = c.getString("sha")
                        break
                    } catch (e: GitErr) {
                        if (attempt < 3 && (e.message ?: "").contains("fast forward", ignoreCase = true)) continue
                        throw GitErr("그 사이 저장소가 계속 바뀌었거나 거부됐어요. 잠시 뒤 다시 시도해 주세요. (${e.message})")
                    }
                }
            } catch (e: InterruptedException) {
            } catch (e: Exception) {
                err = e.message ?: "실패했어요"
            }
            plan.dir.deleteRecursively()
            main.post {
                runCatching { dlg.dismiss() }
                if (act.isFinishing || act.isDestroyed) return@post
                when {
                    canceled.get() -> AppToast.show(act, "취소했어요 (저장소는 바뀌지 않았어요)")
                    err != null -> MaterialAlertDialogBuilder(act).setTitle("올리지 못했어요").setMessage(err)
                        .setPositiveButton("확인", null).show()
                    else -> {
                        AppToast.show(act, "올렸어요 (커밋 ${sha?.take(7)} · 파일 ${plan.changed.size}개)")
                        // 빌드 진행 창은 저절로 뜨지 않는다. 설정 > 앱 정보 > '빌드 진행 상황'에서 본다.
                    }
                }
            }
        }.start()
    }

    private fun progressDialog(act: Activity, title: String, canceled: AtomicBoolean): Triple<androidx.appcompat.app.AlertDialog, TextView, ProgressBar> {
        val dp = act.resources.displayMetrics.density
        val label = TextView(act).apply { text = "준비 중…" }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((24 * dp).toInt(), (12 * dp).toInt(), (24 * dp).toInt(), 0)
            addView(label); addView(bar)
        }
        val dlg = MaterialAlertDialogBuilder(act)
            .setTitle(title).setView(box).setCancelable(false)
            .setNegativeButton("취소") { _, _ -> canceled.set(true) }
            .show()
        return Triple(dlg, label, bar)
    }
}
