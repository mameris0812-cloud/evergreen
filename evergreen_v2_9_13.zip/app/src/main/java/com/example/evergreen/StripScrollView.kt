package com.example.evergreen

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.HorizontalScrollView

/**
 * 상단 탭 줄용 스크롤 뷰.
 * 가장자리 페이드는 "오른쪽(+ 버튼 앞)"에만 보여 준다. 왼쪽은 화면 끝에서 탭이 그냥 잘리게 두는 게 자연스럽다.
 *
 * 탭이 넘쳐 + 버튼이 오른쪽 끝에 멈추면, + 밑으로 들어가는 탭은 색을 덮어 가리는 대신 투명하게 지워서 가린다
 * ([setCover]). 탭 줄 배경이 반투명 유리라서, 불투명한 색으로 덮으면 그 자리만 색 덩어리로 튀어 보이기 때문이다.
 */
class StripScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.horizontalScrollViewStyle
) : HorizontalScrollView(context, attrs, defStyleAttr) {

    override fun getLeftFadingEdgeStrength(): Float = 0f

    private var coverPx = 0
    private var fadePx = 0
    private var coverAmt = 0f
    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) }

    /** 오른쪽 끝 [coverPx] 만큼을 지우고, 그 왼쪽 [fadePx] 는 서서히 지운다. amount(0~1)로 세기를 조절한다 */
    fun setCover(coverPx: Int, fadePx: Int, amount: Float) {
        val a = amount.coerceIn(0f, 1f)
        if (this.coverPx == coverPx && this.fadePx == fadePx && coverAmt == a) return
        this.coverPx = coverPx; this.fadePx = fadePx; coverAmt = a
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (coverPx <= 0 || coverAmt <= 0.01f || width <= 0) {
            super.dispatchDraw(canvas)
            return
        }
        // 이 캔버스는 내용 좌표라서 보이는 영역은 scrollX ~ scrollX + width
        val l = scrollX.toFloat()
        val r = l + width
        val sc = canvas.saveLayer(l, 0f, r, height.toFloat(), null)
        try {
            super.dispatchDraw(canvas)
            val x1 = r - coverPx
            val x0 = x1 - fadePx
            maskPaint.shader = LinearGradient(x0, 0f, x1, 0f, 0x00000000, 0xFF000000.toInt(), Shader.TileMode.CLAMP)
            maskPaint.alpha = (255 * coverAmt).toInt()
            canvas.drawRect(x0, 0f, r, height.toFloat(), maskPaint)
        } finally {
            canvas.restoreToCount(sc)
        }
    }
}
