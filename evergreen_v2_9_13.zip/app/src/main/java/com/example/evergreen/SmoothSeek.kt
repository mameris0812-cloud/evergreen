package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.TimeBar
import java.util.concurrent.CopyOnWriteArraySet

/**
 * 재생바를 끌 때 쓰는 부드러운 값 (0 → 1).
 * 누르면 톡 튀어 오르듯(살짝 넘쳤다 돌아옴) 커지고, 놓으면 천천히 원래대로 돌아온다.
 * 막대 굵기와 손잡이 크기를 이 값 하나로 같이 움직인다.
 */
class PressAnim(private val onChange: () -> Unit) {
    /** 손잡이용: 누르는 순간 1 을 살짝 넘겼다가 돌아온다 */
    var t = 0f
        private set

    /** 막대 굵기용: 0~1 안에서만 움직인다 */
    val tc: Float get() = t.coerceIn(0f, 1f)

    private var anim: ValueAnimator? = null

    fun to(down: Boolean) {
        anim?.cancel()
        val target = if (down) 1f else 0f
        if (t == target) return
        anim = ValueAnimator.ofFloat(t, target).apply {
            duration = if (down) 280L else 240L
            interpolator = if (down) OvershootInterpolator(1.6f) else DecelerateInterpolator(1.6f)
            addUpdateListener {
                t = it.animatedValue as Float
                onChange()
            }
            start()
        }
    }

    fun cancel() {
        anim?.cancel()
    }
}

/**
 * 내장 플레이어의 재생바 (미디어 컨트롤이 쓰는 [TimeBar] 를 직접 구현).
 * 끌기 시작하면 막대가 굵어지고 손잡이가 톡 커진다.
 * 처음 누른 자리로 손잡이가 순간이동하지 않고 빠르게 미끄러져 간다.
 */
@UnstableApi
class SmoothTimeBar @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    View(ctx, attrs), TimeBar {

    var playedColor = 0xFF2FA35B.toInt()
        set(v) { field = v; invalidate() }
    var scrubberColor = 0xFF2FA35B.toInt()
        set(v) { field = v; invalidate() }
    var bufferedColor = 0x59FFFFFF
        set(v) { field = v; invalidate() }
    var unplayedColor = 0x40FFFFFF
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val padX = 14f * d

    private var duration = C.TIME_UNSET
    private var position = 0L
    private var buffered = 0L
    private var scrubPos = 0L
    private var scrubbing = false
    private val listeners = CopyOnWriteArraySet<TimeBar.OnScrubListener>()
    private val press = PressAnim { invalidate() }

    // 처음 눌렀을 때 손잡이가 그 자리로 미끄러져 가는 움직임
    private var jumpFrom = 0f
    private var jumpK = 1f
    private var jumpAnim: ValueAnimator? = null

    private fun frac(ms: Long): Float =
        if (duration <= 0L || duration == C.TIME_UNSET) 0f else (ms.toFloat() / duration).coerceIn(0f, 1f)

    private fun msAtX(x: Float): Long {
        val w = (width - 2 * padX).coerceAtLeast(1f)
        return (((x - padX) / w).coerceIn(0f, 1f) * duration).toLong()
    }

    override fun onDraw(c: Canvas) {
        val left = padX
        val right = width - padX
        val cy = height / 2f
        val h = (4f + 3f * press.tc) * d
        val r = h / 2f

        paint.color = unplayedColor
        rect.set(left, cy - r, right, cy + r)
        c.drawRoundRect(rect, r, r, paint)

        val cur = frac(if (scrubbing) scrubPos else position)
        val shown = if (jumpK < 1f) jumpFrom + (cur - jumpFrom) * jumpK else cur
        val xp = left + (right - left) * shown

        val xb = left + (right - left) * frac(buffered)
        if (xb > xp) {
            paint.color = bufferedColor
            rect.set(left, cy - r, xb, cy + r)
            c.drawRoundRect(rect, r, r, paint)
        }

        paint.color = playedColor
        rect.set(left, cy - r, xp, cy + r)
        c.drawRoundRect(rect, r, r, paint)

        if (isEnabled && duration > 0L && duration != C.TIME_UNSET) {
            val rad = (7f + 6f * press.t) * d
            paint.color = scrubberColor
            c.drawCircle(xp, cy, rad.coerceAtLeast(1f), paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled || duration <= 0L || duration == C.TIME_UNSET) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val before = frac(position)
                scrubbing = true
                scrubPos = msAtX(e.x)
                isPressed = true
                press.to(true)
                jumpAnim?.cancel()
                jumpFrom = before
                jumpK = 0f
                jumpAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 140L
                    interpolator = DecelerateInterpolator(1.4f)
                    addUpdateListener {
                        jumpK = it.animatedValue as Float
                        invalidate()
                    }
                    start()
                }
                for (l in listeners) l.onScrubStart(this, scrubPos)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> if (scrubbing) {
                scrubPos = msAtX(e.x)
                for (l in listeners) l.onScrubMove(this, scrubPos)
                invalidate()
            }
            MotionEvent.ACTION_UP -> if (scrubbing) stop(false)
            MotionEvent.ACTION_CANCEL -> if (scrubbing) stop(true)
        }
        return true
    }

    private fun stop(canceled: Boolean) {
        scrubbing = false
        isPressed = false
        parent?.requestDisallowInterceptTouchEvent(false)
        press.to(false)
        // 손을 떼면 플레이어가 이동을 마칠 때까지 잠깐 예전 자리로 튕기지 않게, 놓은 자리에 둔다
        if (!canceled) position = scrubPos
        jumpAnim?.cancel()
        jumpK = 1f
        invalidate()
        for (l in listeners) l.onScrubStop(this, scrubPos, canceled)
    }

    override fun onDetachedFromWindow() {
        press.cancel()
        jumpAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        if (!enabled && scrubbing) stop(true)
        invalidate()
    }

    // ── TimeBar ──
    override fun addListener(listener: TimeBar.OnScrubListener) {
        listeners.add(listener)
    }

    override fun removeListener(listener: TimeBar.OnScrubListener) {
        listeners.remove(listener)
    }

    override fun setKeyTimeIncrement(time: Long) {}

    override fun setKeyCountIncrement(count: Int) {}

    override fun setPosition(position: Long) {
        if (this.position == position) return
        this.position = position
        invalidate()
    }

    override fun setBufferedPosition(bufferedPosition: Long) {
        if (this.buffered == bufferedPosition) return
        this.buffered = bufferedPosition
        invalidate()
    }

    override fun setDuration(duration: Long) {
        if (this.duration == duration) return
        this.duration = duration
        if (scrubbing && duration == C.TIME_UNSET) stop(true)
        invalidate()
    }

    override fun getPreferredUpdateDelay(): Long {
        val wDp = (width / d).toInt()
        val per = if (wDp == 0 || duration == 0L || duration == C.TIME_UNSET) 0L else duration / wDp
        return if (per == 0L) Long.MAX_VALUE else per
    }

    override fun setAdGroupTimesMs(adGroupTimesMs: LongArray?, playedAdGroups: BooleanArray?, adGroupCount: Int) {}
}

/**
 * 메뉴창 미디어 카드 재생바의 막대: 평소엔 가늘고, 끌면 부드럽게 굵어진다.
 * (ProgressBar 의 진행 그림으로 넣는다. level 0~10000 = 채워진 정도)
 */
class SmoothSeekTrack(ctx: Context, private val bg: Int, private val fg: Int) : Drawable() {
    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val press = PressAnim { invalidateSelf() }
    private var pressed = false

    override fun isStateful() = true

    override fun onStateChange(state: IntArray): Boolean {
        val now = state.contains(android.R.attr.state_pressed)
        if (now != pressed) {
            pressed = now
            press.to(now)
        }
        return false
    }

    override fun onLevelChange(level: Int): Boolean {
        invalidateSelf()
        return true
    }

    override fun getIntrinsicHeight() = (6f * d).toInt()

    override fun draw(c: Canvas) {
        val b = bounds
        val cy = b.exactCenterY()
        val h = (6f + 3f * press.tc) * d
        val r = h / 2f
        paint.color = bg
        rect.set(b.left.toFloat(), cy - r, b.right.toFloat(), cy + r)
        c.drawRoundRect(rect, r, r, paint)
        val x = b.left + b.width() * (level / 10000f)
        if (x > b.left) {
            paint.color = fg
            rect.set(b.left.toFloat(), cy - r, x, cy + r)
            c.drawRoundRect(rect, r, r, paint)
        }
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/**
 * 메뉴창 미디어 카드 재생바의 손잡이: 누르면 톡 커졌다가(살짝 넘침) 놓으면 부드럽게 줄어든다.
 * 자리 크기(14dp)는 그대로 두고 그림만 더 크게 그려서, 누를 때 막대 높이가 출렁이지 않는다.
 */
class SmoothSeekThumb(ctx: Context, private val color: Int, private val disabledColor: Int) : Drawable() {
    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val press = PressAnim { invalidateSelf() }
    private var pressed = false
    private var enabledNow = true

    override fun isStateful() = true

    override fun onStateChange(state: IntArray): Boolean {
        val p = state.contains(android.R.attr.state_pressed)
        val e = state.contains(android.R.attr.state_enabled)
        var changed = false
        if (e != enabledNow) {
            enabledNow = e
            changed = true
        }
        if (p != pressed) {
            pressed = p
            press.to(p)
        }
        return changed
    }

    override fun getIntrinsicWidth() = (14f * d).toInt()

    override fun getIntrinsicHeight() = (14f * d).toInt()

    override fun draw(c: Canvas) {
        val b = bounds
        val r = (7f + 4f * press.t) * d
        paint.color = if (enabledNow) color else disabledColor
        c.drawCircle(b.exactCenterX(), b.exactCenterY(), r.coerceAtLeast(1f), paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
