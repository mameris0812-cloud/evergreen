package com.example.evergreen

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.PixelCopy
import android.view.View
import androidx.annotation.RequiresApi
import androidx.core.graphics.ColorUtils

/**
 * 유리(블러) 배경 공통 도우미 (Android 12 이상에서만 쓴다).
 *
 * 웹 페이지(WebView)를 우리가 직접 한 번 더 그리면 같은 프레임에 두 번 그려져 화면이 깜빡이므로,
 * 화면에 이미 그려진 픽셀을 PixelCopy 로 작게(1/8) 복사해 와서 그 그림을 흐리게 깐다.
 *
 * 실시간으로 자연스럽게 따라가기:
 * - 복사는 그림이 바뀌는 동안 계속 이어서 한다 (끝난 직후 바로 다음 복사). 복사본은 직전 프레임이라 한두 프레임 늦으므로,
 *   그림이 멈춘 뒤에도 몇 번 더 복사해서 마지막 모습까지 따라잡는다 (스크롤이 멈췄는데 블러만 옛 모습인 일이 없다).
 * - 복사본으로 곧바로 바꾸지 않고, 보이는 색이 목표 색을 향해 시간 기준으로 부드럽게 따라간다 (뚝뚝 끊기지 않는다).
 * - 처음 나타날 때는 서서히 짙어진다.
 *
 * [rectProvider]: 복사할 곳(창 좌표).
 *
 * [edgeDp] 가 0 이면: 이 뷰 자신이 겹치지 않는 곳을 가리켜야 한다 (자기 자신이 찍히면 번져 보인다).
 * [edgeDp] 가 0 보다 크면 '가운데 구멍' 방식: [rectProvider] 는 뷰 사각형을 사방으로 [edgeDp] 만큼 넓힌 곳이어야 하고,
 * 복사한 그림에서 뷰와 겹치는 가운데는 버리고 둘레 띠 색으로 매끄럽게 채운다.
 * 그래서 뷰 바로 뒤(둘레)의 페이지 색을 따라가면서도 뷰 자신이 찍혀 번지는 일이 없다.
 */
@RequiresApi(Build.VERSION_CODES.S)
internal class GlassBackdrop(
    private val view: View,
    /** 흐림 반경 (dp). 클수록 비침이 뭉개져 은은해진다 */
    private val blurDp: Float = 10f,
    /** 0 보다 크면 '가운데 구멍' 방식 (위 설명 참고). 뷰 둘레로 넓힌 폭 (dp) */
    private val edgeDp: Float = 0f,
    private val rectProvider: () -> Rect?
) {

    private val handler = Handler(Looper.getMainLooper())

    // 복사 쪽
    private var copyBmp: Bitmap? = null
    private var busy = false
    private var lastAt = 0L
    private var retryQueued = false
    private var failTries = 0
    /** 그림이 마지막으로 바뀐 뒤에도 이만큼 더 복사해서 마무리한다 */
    private var settle = 0
    private val retry = Runnable { retryQueued = false; refresh() }

    // 그리기 쪽: 목표 색(복사본)을 향해 보이는 색이 따라간다
    private var shown: Bitmap? = null
    private var target = IntArray(0)
    private var cur = FloatArray(0)
    private var out = IntArray(0)
    private var fade = 0f
    private var lastFrameAt = 0L
    private var dirty = false
    private var node: RenderNode? = null
    private var recW = -1
    private var recH = -1
    private var recPad = -1
    private var recFlip = false

    private companion object {
        /** 복사 최소 간격. 거의 매 프레임 따라가되 한 프레임에 두 번은 하지 않는다 */
        const val MIN_INTERVAL_MS = 12L
        /** 변화가 멈춘 뒤 마무리로 더 복사하는 횟수 */
        const val SETTLE_COPIES = 3
        /** 보이는 색이 목표 색을 따라가는 시간 상수 (ms). 작을수록 빠릿하고 클수록 부드럽다 */
        const val FOLLOW_TAU_MS = 38f
        /** 처음 나타날 때 짙어지는 시간 상수 (ms) */
        const val FADE_TAU_MS = 70f
    }

    /** 그림이 바뀌었을 때 (이 그림을 나눠 쓰는 다른 뷰도 다시 그리게 할 때 쓴다) */
    var onUpdated: (() -> Unit)? = null

    private fun activity(c: Context): Activity? {
        var x: Context? = c
        while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }
        return null
    }

    private fun queueRetry() {
        if (!retryQueued) { retryQueued = true; handler.postDelayed(retry, MIN_INTERVAL_MS) }
    }

    /** 화면이 그려지기 직전에, 또 복사가 끝난 뒤에 부른다. 필요하면 복사를 요청한다 */
    fun refresh() {
        if (busy || !view.isShown || view.width <= 0) return
        val now = SystemClock.uptimeMillis()
        if (now - lastAt < MIN_INTERVAL_MS) { queueRetry(); return }
        val win = activity(view.context)?.window ?: return
        val r = rectProvider() ?: return
        val dm = view.resources.displayMetrics
        val bounds = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        if (r.isEmpty || !bounds.contains(r)) return
        val bw = (r.width() / 8).coerceIn(8, 400)
        val bh = (r.height() / 8).coerceIn(4, 400)
        var dst = copyBmp
        if (dst == null || dst.width != bw || dst.height != bh) {
            dst = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            copyBmp = dst
        }
        busy = true
        lastAt = now
        try {
            PixelCopy.request(win, r, dst, { result -> onCopied(result, dst, r) }, handler)
        } catch (e: Throwable) {
            busy = false
        }
    }

    private fun onCopied(result: Int, dst: Bitmap, r: Rect) {
        busy = false
        if (result != PixelCopy.SUCCESS) {
            // 아직 그려진 프레임이 없는 등 — 몇 번만 다시 시도한다
            if (failTries++ < 6) queueRetry()
            return
        }
        failTries = 0
        if (edgeDp > 0f) fillHole(dst, r.width(), r.height())
        val bw = dst.width; val bh = dst.height; val n = bw * bh
        val px = IntArray(n)
        dst.getPixels(px, 0, bw, 0, 0, bw, bh)
        var changed = false
        val sh = shown
        if (sh == null || sh.width != bw || sh.height != bh || target.size != n) {
            // 처음이거나 크기가 바뀌었다: 부드럽게 이어 가지 않고 바로 이 그림으로 시작한다
            shown = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            target = px
            cur = FloatArray(n * 3)
            out = IntArray(n)
            for (i in 0 until n) {
                val c = px[i]
                cur[i * 3] = ((c shr 16) and 0xFF).toFloat()
                cur[i * 3 + 1] = ((c shr 8) and 0xFF).toFloat()
                cur[i * 3 + 2] = (c and 0xFF).toFloat()
                out[i] = c or (0xFF shl 24)
            }
            shown!!.setPixels(out, 0, bw, 0, 0, bw, bh)
            dirty = true
            changed = true
        } else if (!px.contentEquals(target)) {
            target = px
            changed = true
        }
        if (changed) {
            settle = SETTLE_COPIES
            view.invalidate()
            onUpdated?.invoke()
        } else if (settle > 0) {
            settle--
        }
        // 그림이 바뀌는 중이면 쉬지 않고 이어서 복사한다
        if (settle > 0) queueRetry()
    }

    /** [px] 의 start 부터 step 간격으로 count 개 픽셀의 평균 색 */
    private fun mean(px: IntArray, start: Int, step: Int, count: Int): Int {
        if (count <= 0) return px[start.coerceIn(0, px.size - 1)]
        var r = 0; var g = 0; var b = 0
        for (i in 0 until count) {
            val c = px[start + i * step]
            r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF
        }
        return (0xFF shl 24) or ((r / count) shl 16) or ((g / count) shl 8) or (b / count)
    }

    /**
     * '가운데 구멍' 방식: 복사한 그림([regionW]x[regionH] 영역)에서 뷰가 차지한 가운데를 지우고,
     * 왼/오른 띠는 가로로, 위/아래 띠는 세로로 이어 평균내어 채운다. 바로 위에 뷰가 그려져 있어도 그 색이 섞이지 않는다.
     */
    private fun fillHole(bmp: Bitmap, regionW: Int, regionH: Int) {
        if (regionW <= 0 || regionH <= 0) return
        val d = view.resources.displayMetrics.density
        val edge = (edgeDp * d).toInt()
        val inner = (edge - (2 * d).toInt()).coerceAtLeast(0)   // 가장자리 번짐·테두리 몫으로 구멍을 2dp 키운다
        val bw = bmp.width; val bh = bmp.height
        val sx = bw.toFloat() / regionW; val sy = bh.toFloat() / regionH
        val hx0 = Math.floor((inner * sx).toDouble()).toInt()
        val hx1 = Math.ceil(((regionW - inner) * sx).toDouble()).toInt()
        val hy0 = Math.floor((inner * sy).toDouble()).toInt()
        val hy1 = Math.ceil(((regionH - inner) * sy).toDouble()).toInt()
        if (hx0 < 1 || hy0 < 1 || hx1 > bw - 1 || hy1 > bh - 1 || hx1 - hx0 < 1 || hy1 - hy0 < 1) return
        val px = IntArray(bw * bh)
        bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
        val left = IntArray(bh); val right = IntArray(bh)
        for (y in hy0 until hy1) {
            left[y] = mean(px, y * bw, 1, hx0)
            right[y] = mean(px, y * bw + hx1, 1, bw - hx1)
        }
        val top = IntArray(bw); val bottom = IntArray(bw)
        for (x in hx0 until hx1) {
            top[x] = mean(px, x, bw, hy0)
            bottom[x] = mean(px, hy1 * bw + x, bw, bh - hy1)
        }
        for (y in hy0 until hy1) {
            val ty = (y - hy0 + 0.5f) / (hy1 - hy0)
            for (x in hx0 until hx1) {
                val tx = (x - hx0 + 0.5f) / (hx1 - hx0)
                val h = ColorUtils.blendARGB(left[y], right[y], tx)
                val v = ColorUtils.blendARGB(top[x], bottom[x], ty)
                px[y * bw + x] = ColorUtils.blendARGB(h, v, 0.5f)
            }
        }
        bmp.setPixels(px, 0, bw, 0, 0, bw, bh)
    }

    /** 뷰의 (0,0)~(w,h) 자리에 흐린 그림을 그린다. 뒤 배경보다 먼저 불러야 한다 */
    fun draw(canvas: Canvas, w: Int, h: Int) = drawSlice(canvas, w, h, 0, h, false)

    /** 보이는 색을 목표 색 쪽으로 한 걸음 옮긴다. 아직 가는 중이면 true */
    private fun advance(): Boolean {
        val bmp = shown ?: return false
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrameAt == 0L) 16L else (now - lastFrameAt).coerceIn(1L, 64L)
        lastFrameAt = now
        val k = 1f - Math.exp(-dt / FOLLOW_TAU_MS.toDouble()).toFloat()
        val kf = 1f - Math.exp(-dt / FADE_TAU_MS.toDouble()).toFloat()
        var moving = false
        var pixelsChanged = false
        val n = target.size
        for (i in 0 until n) {
            val t = target[i]
            val j = i * 3
            var cr = cur[j]; var cg = cur[j + 1]; var cb = cur[j + 2]
            val tr = ((t shr 16) and 0xFF).toFloat()
            val tg = ((t shr 8) and 0xFF).toFloat()
            val tb = (t and 0xFF).toFloat()
            cr += (tr - cr) * k; cg += (tg - cg) * k; cb += (tb - cb) * k
            // 거의 다 왔으면 목표 색에 딱 붙인다
            if (Math.abs(tr - cr) < 0.6f && Math.abs(tg - cg) < 0.6f && Math.abs(tb - cb) < 0.6f) {
                cr = tr; cg = tg; cb = tb
            } else moving = true
            cur[j] = cr; cur[j + 1] = cg; cur[j + 2] = cb
            val c = (0xFF shl 24) or (Math.round(cr) shl 16) or (Math.round(cg) shl 8) or Math.round(cb)
            if (c != out[i]) { out[i] = c; pixelsChanged = true }
        }
        if (pixelsChanged) {
            bmp.setPixels(out, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            dirty = true
        }
        if (fade < 1f) {
            fade += (1f - fade) * kf
            if (fade > 0.995f) fade = 1f
            moving = true
        }
        return moving
    }

    /**
     * 복사해 온 그림 전체(높이 [totalH])에서 위로부터 [offsetY] 만큼 아래 구간을 이 뷰의 (0,0)~(w,h) 에 그린다.
     * 상태표시줄·탭 줄·주소창이 한 장의 그림을 나눠 그리므로 경계에서 끊기지 않고 이어진다.
     * [flip] 이면 그림을 위아래로 뒤집어, 페이지와 맞닿는 바의 가장자리가 페이지의 그 가장자리 줄과 같게(거울처럼) 이어 보이게 한다.
     */
    fun drawSlice(canvas: Canvas, w: Int, h: Int, offsetY: Int, totalH: Int, flip: Boolean = true) {
        val bmp = shown ?: return
        if (!canvas.isHardwareAccelerated) return
        val moving = advance()
        val d = view.resources.displayMetrics.density
        // 구멍 방식은 복사한 그림이 (뷰 + 둘레) 크기 그대로이므로 둘레 폭만큼만 여백을 둔다 (위치가 1:1 로 맞는다)
        val pad = if (edgeDp > 0f) (edgeDp * d).toInt() else (16 * d).toInt()
        val rn = node ?: RenderNode("glassBlur").also {
            val r = blurDp * d
            it.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
            node = it
        }
        val th = maxOf(totalH, h + offsetY)
        val nw = w + pad * 2
        val nh = th + pad * 2
        // 그림이 바뀌었거나 크기가 달라졌을 때만 다시 기록한다
        if (dirty || recW != nw || recH != nh || recPad != pad || recFlip != flip) {
            rn.setPosition(0, 0, nw, nh)
            val rc = rn.beginRecording(nw, nh)
            try {
                if (flip) { rc.translate(0f, nh.toFloat()); rc.scale(1f, -1f) }
                rc.drawBitmap(bmp, null, RectF(0f, 0f, nw.toFloat(), nh.toFloat()), null)
            } finally {
                rn.endRecording()
            }
            recW = nw; recH = nh; recPad = pad; recFlip = flip
            dirty = false
        }
        rn.setAlpha(fade)
        canvas.save()
        canvas.clipRect(0, 0, w, h)
        canvas.translate(-pad.toFloat(), -pad.toFloat() - offsetY)
        canvas.drawRenderNode(rn)
        canvas.restore()
        // 아직 따라가는 중이면 다음 프레임에도 이어서 그린다
        if (moving) view.postInvalidateOnAnimation()
    }

    /** 숨겨질 때: 옛 그림을 버린다. 다시 나타나면 새로 복사해서 서서히 짙어진다 */
    fun resetFade() {
        handler.removeCallbacks(retry)
        retryQueued = false
        settle = 0
        failTries = 0
        shown = null
        target = IntArray(0)
        fade = 0f
        lastFrameAt = 0L
        dirty = false
        recW = -1
    }

    fun release() {
        handler.removeCallbacks(retry)
        retryQueued = false
    }
}
