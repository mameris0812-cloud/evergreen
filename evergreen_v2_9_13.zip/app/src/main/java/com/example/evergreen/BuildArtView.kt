package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.PathParser
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 빌드 진행창 위쪽에 들어가는 그림: 앱 아이콘(초록 그라데이션 타일 + 흰 나뭇잎 + 궤도 링)이 연두 카드 한가운데에서
 * 위아래로 떠다니며 살짝 기울고, 링을 따라 꼬리가 달린 알갱이가 돈다.
 * 타일 위로는 주기적으로 반짝이는 빛줄기가 지나가고, 둘레에서는 작은 네모·점이 떠다니며 잎이 피어올라 사라지고 별빛이 깜빡인다.
 *
 * 모든 움직임은 하나의 반복 시간([LOOP_MS])을 정수 번 도는 주기로 돌려서, 주기가 서로 달라도 반복 지점에서 끊기지 않는다.
 * 처음 나타날 때는 타일이 통통 튀며 커지고 둘레 장식이 서서히 떠오른다.
 * 356×212 좌표로 그려서 가로 폭에 맞춰 늘린다.
 */
class BuildArtView(context: Context) : View(context) {
    private companion object {
        const val LOOP_MS = 14_400L   // 3.6초(떠오름)·2.4초(궤도)·4.8초(빛줄기)·7.2초(잎)가 모두 정수 번 들어간다
        const val ENTER_MS = 650L
        const val TAIL = 24           // 알갱이 꼬리 점 개수
        const val TAIL_STEP = 2.2f    // 꼬리 점 사이 간격 (화면 위 거리, 링의 어디서나 같다)
        val TAU = (2.0 * PI).toFloat()
    }

    private val vw = 356f
    private val vh = 212f
    private val cx = 178f
    private val cy = 104f

    private val sky = context.getColor(R.color.ev_art_sky)
    private val line = context.getColor(R.color.ev_art_line)
    private val halo = context.getColor(R.color.ev_art_halo)
    private val accent = context.getColor(R.color.ev_accent)

    private fun p(d: String): Path = PathParser.createPathFromPathData(d) ?: Path()

    private val leafPath = p("M888,337C898,405 902,470 889,545C876,620 858,665 838,690C815,730 790,765 750,795C700,835 630,840 570,850C510,860 465,885 435,921C436,880 452,835 480,775C540,650 650,570 772,510C640,540 480,600 432,793C395,745 385,700 387,660C390,560 460,480 560,435C660,390 790,395 888,337Z")
    private val bitA = p("M0 0C-1-7 4-12 11-12C11-5 6 1 0 0Z")
    private val bitB = p("M0 0C-1-6 3-10 9-10C9-4 5 1 0 0Z")
    /** 네 갈래 별 (반지름 1) */
    private val star = p("M0-1Q0.13-0.13 1 0Q0.13 0.13 0 1Q-0.13 0.13 -1 0Q-0.13-0.13 0-1Z")
    /** 타일 위를 지나가는 빛줄기 (가운데 0, 폭 30). 기울기는 그릴 때 캔버스를 비틀어서 준다 */
    private val shineRect = RectF(-15f, -60f, 15f, 60f)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tilePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        shader = LinearGradient(
            -44f, -44f, 44f, 44f,
            intArrayOf(Color.parseColor("#7DF695"), Color.parseColor("#34D37F"), Color.parseColor("#09975D"), Color.parseColor("#06B56A")),
            floatArrayOf(0f, 0.32f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
    }
    private val leafPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        shader = LinearGradient(
            420f, 420f, 720f, 905f,
            intArrayOf(Color.WHITE, Color.parseColor("#DDF8E6"), Color.parseColor("#7FE3A9")),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
    }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        shader = LinearGradient(
            -15f, 0f, 15f, 0f,
            intArrayOf(
                Color.argb(0, 255, 255, 255), Color.argb(50, 255, 255, 255), Color.argb(135, 255, 255, 255),
                Color.argb(50, 255, 255, 255), Color.argb(0, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
    }

    private val clip = Path()
    private val rect = RectF()
    private val borderRect = RectF()
    private var radius = 0f
    private var borderWidth = 1f
    private val tileRect = RectF(-44f, -44f, 44f, 44f)
    private val tileClip = Path().apply { addRoundRect(tileRect, 26f, 26f, Path.Direction.CW) }
    private val sq = RectF()
    private val tailA = FloatArray(TAIL)
    private val ringRect = RectF(-76f, -22f, 76f, 22f)

    private var u = 0f        // 반복 시간 0~1 (한 바퀴 = LOOP_MS)
    private var enter = 0f    // 처음 나타나는 연출 0~1

    /** 아래에서 위로 피어올랐다 사라지는 잎: 중심 x, 좌우 흔들림, 시작·끝 y, 한 바퀴 동안 도는 횟수, 시작 위상, 크기, 처음 기울기, 큰 잎 여부, 최대 투명도 */
    private class Rise(
        val x: Float, val sway: Float, val y0: Float, val y1: Float, val cycles: Int,
        val off: Float, val scale: Float, val rot: Float, val big: Boolean, val alpha: Int
    )

    private val rises = arrayOf(
        Rise(54f, 6f, 150f, 56f, 2, 0.00f, 1.3f, 20f, true, 150),
        Rise(304f, 6f, 148f, 60f, 2, 0.50f, 1.2f, -35f, false, 150),
        Rise(88f, 5f, 160f, 76f, 3, 0.33f, 1.0f, -10f, false, 120),
        Rise(270f, 5f, 164f, 80f, 3, 0.75f, 1.1f, 30f, true, 120)
    )

    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = LOOP_MS
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { u = it.animatedValue as Float; invalidate() }
    }

    private val intro = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = ENTER_MS
        interpolator = LinearInterpolator()
        addUpdateListener { enter = it.animatedValue as Float }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (Build.VERSION.SDK_INT >= 26 && !ValueAnimator.areAnimatorsEnabled()) {
            // 절전 모드·'애니메이션 끄기' 설정: 움직이지 않고 보기 좋은 한 장면(빛줄기가 쉬는 때)만 그린다
            u = 0.15f
            enter = 1f
            invalidate()
            return
        }
        enter = 0f
        intro.start()
        if (!loop.isStarted) loop.start()
    }

    override fun onDetachedFromWindow() {
        intro.cancel()
        loop.cancel()
        super.onDetachedFromWindow()
    }

    /** 앱이 가려지거나 화면이 꺼져 있는 동안은 멈춰서 배터리를 아낀다 */
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            if (loop.isPaused) loop.resume()
            if (intro.isPaused) intro.resume()
        } else {
            if (loop.isRunning) loop.pause()
            if (intro.isRunning) intro.pause()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * vh / vw).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val dp = resources.displayMetrics.density
        radius = 20 * dp
        borderWidth = dp
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        clip.reset()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        borderRect.set(rect)
        borderRect.inset(dp / 2f, dp / 2f)
    }

    // ── 시간 도우미 ───────────────────────────────────────────────

    /** 한 바퀴 동안 [n] 번 도는 0~1 위상 (offset 만큼 앞서 시작) */
    private fun ph(n: Int, offset: Float = 0f): Float {
        val x = u * n + offset
        return x - floor(x)
    }

    /** 0→1→0 으로 부드럽게 오르내림 (위상 0 에서 0) */
    private fun wave(n: Int, offset: Float = 0f): Float = 0.5f - 0.5f * cos(TAU * ph(n, offset))

    /** -1~1 사인 */
    private fun swing(n: Int, offset: Float = 0f): Float = sin(TAU * ph(n, offset))

    private fun easeOutCubic(x: Float): Float { val k = 1f - x; return 1f - k * k * k }

    /** 살짝 넘쳤다가 돌아오는 튕김 (0→1) */
    private fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val k = x - 1f
        return 1f + (c1 + 1f) * k * k * k + c1 * k * k
    }

    // ── 그리기 ───────────────────────────────────────────────────

    override fun onDraw(c: Canvas) {
        val sc = width / vw

        // 카드: 연두 바탕, 모서리는 둥글게 잘라낸다
        fill.style = Paint.Style.FILL
        fill.color = sky; fill.alpha = 255
        c.drawPath(clip, fill)

        c.save()
        c.clipPath(clip)
        c.scale(sc, sc)

        val fade = easeOutCubic(enter)    // 둘레 장식이 서서히 떠오르는 정도
        val pop = easeOutBack(enter)      // 타일이 튕기며 커지는 정도
        val bob = wave(4)                 // 3.6초에 한 번 떠올랐다 내려옴
        val lift = -7f * bob              // 타일이 떠오른 정도

        // 바닥 그림자(타일이 뜨면 작고 옅어진다) + 숨 쉬는 후광
        fill.color = line; fill.alpha = (179 * (1f - 0.3f * bob) * fade).toInt()
        val sw = 50f * (1f - 0.14f * bob) * pop
        c.drawOval(cx - sw, 178f - 6f, cx + sw, 178f + 6f, fill)
        val breath = (0.6f + 0.4f * fade) * (1f + 0.03f * bob)
        fill.color = halo; fill.alpha = (128 * fade).toInt()
        c.drawCircle(cx, cy, 90f * breath, fill)
        fill.alpha = (179 * fade).toInt()
        c.drawCircle(cx, cy, 64f * breath, fill)

        // 아래에서 피어올랐다 사라지는 잎
        for (r in rises) {
            val q = ph(r.cycles, r.off)
            val a = sin(PI.toFloat() * q)   // 0→1→0: 생겼다가 사라진다
            val x = r.x + r.sway * sin(TAU * (q * 1.5f + r.off))
            val y = r.y0 + (r.y1 - r.y0) * q
            fill.color = accent; fill.alpha = (r.alpha * a * fade).toInt()
            c.save()
            c.translate(x, y)
            c.rotate(r.rot + 70f * q)
            c.scale(r.scale, r.scale)
            c.drawPath(if (r.big) bitA else bitB, fill)
            c.restore()
        }

        // 둘레에 떠다니는 작은 네모·점 (느리게 돌고, 좌우로 살랑이고, 크기·농도가 숨 쉰다)
        fill.color = accent
        floatSquare(c, 62f, 142f, 10f, 3, 0.10f, fade)
        floatSquare(c, 300f, 66f, 12f, -2, 0.40f, fade)
        floatSquare(c, 270f, 156f, 8f, 2, 0.70f, fade)
        floatSquare(c, 86f, 54f, 8f, -3, 0.55f, fade)
        floatDot(c, 40f, 96f, 3f, 0.25f, fade)
        floatDot(c, 318f, 112f, 2.5f, 0.85f, fade)

        // 별빛: 돌면서 커졌다 사라진다
        sparkle(c, 128f, 56f, 7f, 3, 0.00f, fade)
        sparkle(c, 236f, 48f, 9f, 4, 0.30f, fade)
        sparkle(c, 248f, 138f, 6f, 3, 0.55f, fade)
        sparkle(c, 112f, 150f, 5f, 4, 0.80f, fade)

        // 앱 아이콘 타일: 링 뒤쪽 → 타일+잎+빛줄기 → 링 앞쪽 순으로 겹친다
        c.save()
        c.translate(cx, cy + lift)
        c.scale(pop, pop)

        val theta = TAU * ph(6)   // 2.4초에 한 바퀴
        val ringTilt = -24f + 2.5f * swing(4, 0.25f)

        c.save()
        c.rotate(ringTilt)
        ring(c, 180f)                    // 위쪽(뒤쪽) 반원
        orb(c, theta, false)
        c.restore()

        c.save()
        c.rotate(2f * swing(4, 0f))      // 떠오르며 좌우로 살짝 기운다
        fill.style = Paint.Style.FILL
        c.drawRoundRect(tileRect, 26f, 26f, tilePaint)
        c.save()
        c.scale(0.082f, 0.082f)
        c.translate(-640f, -629f)
        c.drawPath(leafPath, leafPaint)
        c.restore()
        shine(c)
        c.restore()

        c.save()
        c.rotate(ringTilt)
        ring(c, 0f)                      // 아래쪽(앞쪽) 반원
        orb(c, theta, true)
        c.restore()

        c.restore()
        c.restore()

        // 테두리 (잘라낸 모서리 위에 얹는다)
        fill.style = Paint.Style.STROKE
        fill.strokeWidth = borderWidth
        fill.color = line; fill.alpha = 255
        c.drawRoundRect(borderRect, radius, radius, fill)
        fill.style = Paint.Style.FILL
    }

    /** 4.8초마다 타일 위를 왼쪽에서 오른쪽으로 한 번 지나가는 빛줄기 (나머지 시간은 쉰다) */
    private fun shine(c: Canvas) {
        val q = ph(3, 0.12f) / 0.5f
        if (q >= 1f) return
        val e = 0.5f - 0.5f * cos(PI.toFloat() * q)   // 가운데서 빠르고 양끝에서 느리게
        c.save()
        c.clipPath(tileClip)
        // 양끝에서는 줄기가 타일 밖에 완전히 나가 있어야 가장자리가 갑자기 생기거나 사라지지 않는다
        c.translate(-76f + 152f * e, 0f)
        // 모양만 비스듬히 그리면 밝기 그라데이션은 똑바로 남아서 한쪽 가장자리가 칼로 자른 듯 딱딱해 보였다.
        // 캔버스를 비틀어 그라데이션까지 같이 기울인다 (위쪽이 오른쪽으로)
        c.skew(-0.29f, 0f)
        shinePaint.alpha = (255 * sin(PI.toFloat() * q)).toInt()
        c.drawRect(shineRect, shinePaint)
        c.restore()
    }

    /**
     * 궤도 링의 반원 하나. 초록 밑줄을 한 겹 깔고 흰 선을 올려서 연한 바탕·진한 타일 위에서 다 보이게 한다.
     * 두 반원이 만나는 양 끝이 끊겨 보이지 않도록: 반원마다 농도를 다르게 하지 않고, 반투명 밑줄은 끝을 평평하게(BUTT) 맞대어
     * 겹쳐 칠해지지 않게 하며, 흰 선만 둥근 끝으로 이어 붙인다.
     */
    private fun ring(c: Canvas, startAngle: Float) {
        stroke.strokeCap = Paint.Cap.BUTT
        stroke.color = accent; stroke.alpha = 125; stroke.strokeWidth = 7.5f
        c.drawArc(ringRect, startAngle, 180f, false, stroke)
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.color = Color.WHITE; stroke.alpha = 255; stroke.strokeWidth = 4f
        c.drawArc(ringRect, startAngle, 180f, false, stroke)
    }

    /**
     * 링을 따라 도는 알갱이와 꼬리. 앞쪽(링 아래 반원)에 있는 점만 [front]=true 일 때, 뒤쪽 점만 false 일 때 그린다.
     * 그래서 꼬리가 타일 뒤로 넘어가는 순간 점이 하나씩 타일에 가려진다. 앞에 올수록 조금 커진다.
     *
     * 꼬리 점은 '각도'가 아니라 '화면 위 거리'가 일정하게 배치한다. 링이 납작한 타원이라 각도 간격으로 찍으면
     * 링 양 끝에서는 점이 한 덩어리로 뭉치고 가운데에서는 알갱이가 띄엄띄엄 떨어져 보였다.
     * 점마다 연한 초록 번짐을 한 겹 깔아서 흰 링 위에서도 꼬리가 보이게 한다.
     */
    private fun orb(c: Canvas, theta: Float, front: Boolean) {
        val rx = ringRect.right
        val ry = ringRect.bottom
        fill.style = Paint.Style.FILL
        var a = theta
        for (j in 0 until TAIL) {
            val vx = rx * sin(a)
            val vy = ry * cos(a)
            a -= TAIL_STEP / max(sqrt(vx * vx + vy * vy), 1f)
            tailA[j] = a
        }
        for (pass in 0..1) {
            for (j in TAIL - 1 downTo 0) {
                val ang = tailA[j]
                val d = sin(ang)
                if ((d > 0f) != front) continue
                val f = 1f - (j + 1) / (TAIL + 1f)
                val r = (0.8f + 3.6f * f) * (1f + 0.22f * d)
                if (pass == 0) {
                    fill.color = accent; fill.alpha = (34 * f).toInt()
                    c.drawCircle(rx * cos(ang), ry * d, r * 1.8f, fill)
                } else {
                    fill.color = Color.WHITE; fill.alpha = (200 * f * f).toInt()
                    c.drawCircle(rx * cos(ang), ry * d, r, fill)
                }
            }
        }
        val d = sin(theta)
        if ((d > 0f) != front) return
        val k = 1f + 0.22f * d
        val x = rx * cos(theta)
        val y = ry * d
        // 흰 알갱이가 연한 바탕(링 뒤쪽) 위에서는 속이 비어 보이는 '고리'처럼 보이고 진한 타일 위에서는 꽉 찬 공처럼 보여서
        // 앞뒤를 오갈 때 모양이 바뀌었다. 초록 테두리를 둘러 어디서나 같은 '테두리 있는 흰 공'으로 보이게 한다.
        fill.color = accent; fill.alpha = 70
        c.drawCircle(x, y, 9.5f * k, fill)
        fill.color = accent; fill.alpha = 255
        c.drawCircle(x, y, 6.6f * k, fill)
        fill.color = Color.WHITE; fill.alpha = 255
        c.drawCircle(x, y, 5.0f * k, fill)
    }

    /** 천천히 돌며 떠다니는 둥근 네모. [rotCycles] 가 음수면 반대로 돈다 */
    private fun floatSquare(c: Canvas, x: Float, y: Float, size: Float, rotCycles: Int, off: Float, fade: Float) {
        val breath = wave(3, off)
        fill.alpha = ((70 + 45 * breath) * fade).toInt()
        val deg = 360f * ph(abs(rotCycles)) * (if (rotCycles < 0) -1f else 1f)
        c.save()
        c.translate(x + 3f * swing(2, off), y - 6f * wave(4, off))
        c.rotate(deg)
        val s = size * (0.92f + 0.16f * wave(3, off + 0.3f))
        sq.set(-s / 2f, -s / 2f, s / 2f, s / 2f)
        c.drawRoundRect(sq, s * 0.28f, s * 0.28f, fill)
        c.restore()
    }

    private fun floatDot(c: Canvas, x: Float, y: Float, r: Float, off: Float, fade: Float) {
        fill.alpha = ((70 + 45 * wave(3, off)) * fade).toInt()
        c.drawCircle(x + 2f * swing(2, off), y - 6f * wave(4, off), r * (0.9f + 0.2f * wave(3, off + 0.3f)), fill)
    }

    /** 한 바퀴 [n] 번 중 절반 동안만 보이는 별빛: 돌면서 커졌다가 작아져 사라진다 */
    private fun sparkle(c: Canvas, x: Float, y: Float, size: Float, n: Int, off: Float, fade: Float) {
        val s = swing(n, off)
        if (s <= 0f) return
        val k = s * s
        fill.color = accent; fill.alpha = (235 * k * fade).toInt()
        c.save()
        c.translate(x, y)
        c.rotate(90f * ph(n, off))
        c.scale(size * max(k, 0.01f), size * max(k, 0.01f))
        c.drawPath(star, fill)
        c.restore()
    }
}
