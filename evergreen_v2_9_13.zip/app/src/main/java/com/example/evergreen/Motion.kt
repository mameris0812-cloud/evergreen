package com.example.evergreen

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import java.util.WeakHashMap

/**
 * 스프링(물리 기반) 애니메이션 모음.
 * 고정된 시간·곡선 대신 용수철 물리를 써서 속도가 이어지고, 끊기거나 중간에 바뀌어도 자연스럽게 이어진다.
 * 시스템의 "애니메이션 끄기" 설정을 따른다.
 */
object Motion {
    private val running = WeakHashMap<View, HashMap<DynamicAnimation.ViewProperty, SpringAnimation>>()

    fun enabled(ctx: Context): Boolean =
        Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f

    private fun dp(v: View, n: Float) = n * v.resources.displayMetrics.density

    private fun minChange(p: DynamicAnimation.ViewProperty): Float = when (p) {
        DynamicAnimation.ALPHA -> DynamicAnimation.MIN_VISIBLE_CHANGE_ALPHA
        DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y -> DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE
        DynamicAnimation.ROTATION, DynamicAnimation.ROTATION_X, DynamicAnimation.ROTATION_Y ->
            DynamicAnimation.MIN_VISIBLE_CHANGE_ROTATION_DEGREES
        else -> DynamicAnimation.MIN_VISIBLE_CHANGE_PIXELS
    }

    /** 같은 뷰·같은 속성의 이전 스프링은 현재 값에서 멈추고, 새 스프링이 그 위치에서 이어서 움직인다. */
    fun spring(
        v: View,
        prop: DynamicAnimation.ViewProperty,
        target: Float,
        stiffness: Float = SpringForce.STIFFNESS_LOW,
        damping: Float = SpringForce.DAMPING_RATIO_LOW_BOUNCY,
        velocity: Float = 0f,
        onEnd: (() -> Unit)? = null
    ): SpringAnimation {
        val map = running.getOrPut(v) { HashMap() }
        map[prop]?.cancel()
        val a = SpringAnimation(v, prop)
        a.setSpring(SpringForce(target).setStiffness(stiffness).setDampingRatio(damping))
        a.setMinimumVisibleChange(minChange(prop))
        if (velocity != 0f) a.setStartVelocity(velocity)
        a.addEndListener { _, canceled, _, _ ->
            if (map[prop] === a) map.remove(prop)
            if (!canceled) onEnd?.invoke()
        }
        map[prop] = a
        a.start()
        return a
    }

    /**
     * 뷰의 속성이 아니라 onDraw 에서 직접 쓰는 값(막대가 자라는 정도 등)을 스프링으로 움직인다.
     * 취소되면 onEnd 는 부르지 않는다. 취소·정리는 돌려받은 SpringAnimation 으로 한다.
     */
    fun springValue(
        from: Float,
        to: Float,
        stiffness: Float = SpringForce.STIFFNESS_LOW,
        damping: Float = SpringForce.DAMPING_RATIO_LOW_BOUNCY,
        velocity: Float = 0f,
        onUpdate: (Float) -> Unit,
        onEnd: (() -> Unit)? = null
    ): SpringAnimation {
        val a = SpringAnimation(FloatValueHolder(from))
        a.setStartValue(from)
        if (velocity != 0f) a.setStartVelocity(velocity)
        a.setSpring(SpringForce(to).setStiffness(stiffness).setDampingRatio(damping))
        a.setMinimumVisibleChange(1f / 500f)
        a.addUpdateListener { _, value, _ -> onUpdate(value) }
        a.addEndListener { _, canceled, _, _ -> if (!canceled) onEnd?.invoke() }
        a.start()
        return a
    }

    fun cancel(v: View) {
        val anims = running.remove(v)?.values?.toList() ?: return
        anims.forEach { it.cancel() }
    }

    /** 아래에서 떠오르며 살짝 커지면서 나타난다. 여러 개면 delay 를 늘려 물결처럼 이어지게 한다. */
    fun enter(
        v: View, delayMs: Long = 0, rise: Float = 20f, scale: Float = 0.94f,
        riseDamping: Float = 0.72f, scaleDamping: Float = 0.62f
    ) {
        if (!enabled(v.context)) return
        cancel(v)
        v.alpha = 0f
        v.translationY = dp(v, rise)
        v.scaleX = scale
        v.scaleY = scale
        val start = Runnable {
            spring(v, DynamicAnimation.ALPHA, 1f, 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            spring(v, DynamicAnimation.TRANSLATION_Y, 0f, 220f, riseDamping)
            spring(v, DynamicAnimation.SCALE_X, 1f, 260f, scaleDamping)
            spring(v, DynamicAnimation.SCALE_Y, 1f, 260f, scaleDamping)
        }
        if (delayMs <= 0) v.post(start) else v.postDelayed(start, delayMs)
    }

    /**
     * 말풍선이 나타난다: 보낸 말은 오른쪽 아래 모서리에서, 받은 말은 왼쪽 아래 모서리에서 자라나며 떠오른다.
     * 크기가 정해진 뒤(레이아웃 후)에 모서리를 기준점으로 잡아서, 처음부터 그 모서리에서 자라는 것처럼 보인다.
     * 튕김은 아주 약하게 — 글이 읽히는 말풍선이 출렁이지 않게 한다.
     */
    fun bubbleIn(v: View, fromRight: Boolean, rise: Float = 14f, scale: Float = 0.88f) {
        if (!enabled(v.context)) return
        cancel(v)
        v.alpha = 0f
        v.translationY = dp(v, rise)
        v.scaleX = scale
        v.scaleY = scale
        fun go() {
            v.pivotX = if (fromRight) v.width.toFloat() else 0f
            v.pivotY = v.height.toFloat()
            spring(v, DynamicAnimation.ALPHA, 1f, 320f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
            spring(v, DynamicAnimation.TRANSLATION_Y, 0f, 300f, 0.86f)
            spring(v, DynamicAnimation.SCALE_X, 1f, 320f, 0.8f)
            spring(v, DynamicAnimation.SCALE_Y, 1f, 320f, 0.8f)
        }
        if (v.isLaidOut && v.width > 0 && v.height > 0) {
            v.post { go() }
        } else {
            v.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
                override fun onLayoutChange(
                    view: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or2: Int, ob: Int
                ) {
                    if (view.width <= 0 || view.height <= 0) return
                    view.removeOnLayoutChangeListener(this)
                    go()
                }
            })
        }
    }

    /** 자식 뷰들을 차례로 떠오르게 한다. */
    fun stagger(parent: ViewGroup, startDelay: Long = 0, step: Long = 38, maxDelay: Long = 320) {
        for (i in 0 until parent.childCount) {
            enter(parent.getChildAt(i), minOf(startDelay + i * step, maxDelay))
        }
    }

    /** 작게 시작해 통통 튀며 커진다 (숫자 배지 등). */
    fun pop(v: View, from: Float = 0.55f) {
        if (!enabled(v.context)) return
        v.scaleX = from
        v.scaleY = from
        spring(v, DynamicAnimation.SCALE_X, 1f, 420f, 0.42f)
        spring(v, DynamicAnimation.SCALE_Y, 1f, 420f, 0.42f)
    }

    /** 옆으로 살짝 기울어지며 날아가듯 사라진다. */
    fun flyAway(v: View, toRight: Boolean = true, onEnd: () -> Unit) {
        if (!enabled(v.context)) {
            onEnd()
            return
        }
        val dir = if (toRight) 1f else -1f
        spring(v, DynamicAnimation.ALPHA, 0f, 520f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.ROTATION, 5f * dir, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.SCALE_X, 0.88f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.SCALE_Y, 0.88f, 300f, SpringForce.DAMPING_RATIO_NO_BOUNCY)
        spring(v, DynamicAnimation.TRANSLATION_X, dir * dp(v, 140f), 260f, SpringForce.DAMPING_RATIO_NO_BOUNCY, 0f, onEnd)
    }

    /**
     * 목록이 다시 그려질 때 남은 항목들이 예전 위치에서 새 위치로 미끄러지듯 이동하게 한다.
     * before: 다시 그리기 직전의 화면상 위치.
     */
    fun glideFrom(parent: View, items: Map<View, Pair<Int, Int>>) {
        if (!enabled(parent.context) || items.isEmpty()) return
        parent.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                parent.viewTreeObserver.removeOnPreDrawListener(this)
                val loc = IntArray(2)
                items.forEach { (view, old) ->
                    view.getLocationOnScreen(loc)
                    val dx = (old.first - loc[0]).toFloat()
                    val dy = (old.second - loc[1]).toFloat()
                    if (dx != 0f || dy != 0f) {
                        view.translationX = dx
                        view.translationY = dy
                        spring(view, DynamicAnimation.TRANSLATION_X, 0f, 380f, 0.78f)
                        spring(view, DynamicAnimation.TRANSLATION_Y, 0f, 380f, 0.78f)
                    }
                }
                return true
            }
        })
    }

    /** 누르면 쏙 들어갔다가, 떼면 탄성 있게 튀어 돌아온다. */
    @SuppressLint("ClickableViewAccessibility")
    fun pressable(
        v: View, pressedScale: Float = 0.9f, extra: ((View, MotionEvent) -> Boolean)? = null,
        releaseDamping: Float = 0.36f
    ) {
        v.setOnTouchListener { view, e ->
            if (enabled(view.context)) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        spring(view, DynamicAnimation.SCALE_X, pressedScale, 1100f, 0.9f)
                        spring(view, DynamicAnimation.SCALE_Y, pressedScale, 1100f, 0.9f)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        spring(view, DynamicAnimation.SCALE_X, 1f, 480f, releaseDamping)
                        spring(view, DynamicAnimation.SCALE_Y, 1f, 480f, releaseDamping)
                    }
                }
            }
            extra?.invoke(view, e) ?: false
        }
    }

    // ───────────────────────── 상/하단바 버튼: 버튼마다 다른 동작 ─────────────────────────

    /**
     * 버튼 한 종류의 눌림·떼는 동작.
     *  - pressScale: 누르는 동안 줄어드는 정도
     *  - windX/windY(dp): 누를 때 반대쪽으로 살짝 물러나는 준비 동작
     *  - kickX/kickY(dp): 떼면 그 방향으로 튀어 나갔다가 스프링으로 돌아온다
     *  - kickRot(도): 떼면 그 방향으로 기울었다가 흔들리며 돌아온다
     *  - spin(도): 떼면 한 바퀴(또는 spin 만큼) 돌고 제자리, flip: 세로축으로 한 바퀴 뒤집힌다
     *  - pop: 떼는 순간 크기가 튀는 세기 (음수면 오히려 움찔 작아졌다 돌아온다)
     */
    private class BarFx(
        val pressScale: Float = 0.88f,
        val windX: Float = 0f, val windY: Float = 0f,
        val kickX: Float = 0f, val kickY: Float = 0f,
        val kickRot: Float = 0f,
        val spin: Float = 0f,
        val flip: Boolean = false,
        val pop: Float = 0f
    )

    /**
     * 버튼 종류별 눌림. 이동·회전·크기 튐 대신 아이콘 모양이 변하는 것(MorphIconDrawable)이 주 동작이고,
     * 여기서는 누르는 동안 줄어드는 정도만 다르게 한다. 새로고침만 아이콘 교체/spinOnce 가 따로 맡는다.
     */
    private fun barFx(kind: String): BarFx = when (kind) {
        "refresh" -> BarFx(pop = 5f)
        "home", "tabs" -> BarFx(pressScale = 0.86f)
        "menu", "hidebars" -> BarFx(pressScale = 0.88f)
        // 플레이어 · 탭 화면 버튼
        "pip", "skip", "rotate", "skipback", "skipfwd", "player", "openplayer" -> BarFx(pressScale = 0.88f)
        "chip" -> BarFx(pressScale = 0.92f)
        // 폭이 넓은 버튼(새 탭 · 선택 …)은 10% 줄면 너무 커 보여서 덜 줄인다
        "wide" -> BarFx(pressScale = 0.96f)
        else -> BarFx(pressScale = 0.9f)
    }

    private val pendingKick = WeakHashMap<View, Runnable>()
    private val detachWatch = WeakHashMap<View, View.OnAttachStateChangeListener>()

    /** 뷰의 눌림·이동·회전 스프링을 멈추고 제자리(크기 1, 이동 0, 회전 0)로 돌린다. */
    private fun snapHome(v: View) {
        pendingKick.remove(v)?.let { v.removeCallbacks(it) }
        cancel(v)
        v.scaleX = 1f; v.scaleY = 1f
        v.translationX = 0f; v.translationY = 0f
        v.rotation = 0f; v.rotationY = 0f
    }

    /**
     * 상/하단바 버튼용 눌림 동작. 누르면 쏙 들어가고, 떼면(탭으로 눌렀을 때만) 버튼 종류에 맞는 동작을 한다.
     * 길게 눌렀거나 손가락이 밖으로 나가서 뗐다면 동작 없이 제자리로만 돌아온다.
     * kind: back, forward, home, refresh, tabs, menu, desktop, ai, newtab, bookmark, bookmarks, history,
     *       downloads, find, player(재생/일시정지), openplayer(내장 플레이어로 열기), hidebars, settings, tablist, pip, rotate, skipback, skipfwd,
     *       chip(글자 칩), wide(넓은 버튼). 모양이 그려져 있지 않은 종류는 아이콘을 바꾸지 않고 눌림만 준다.
     * playOnTap: false 면 탭해도 아이콘이 따로 튀지 않는다 (재생/일시정지처럼 상태가 모양을 정하는 버튼).
     * 돌려주는 값: 버튼에 끼운 모양 변하는 아이콘 (없으면 null).
     */
    @SuppressLint("ClickableViewAccessibility")
    fun barButton(
        v: View, kind: String, extra: ((View, MotionEvent) -> Boolean)? = null, playOnTap: Boolean = true
    ): MorphIconDrawable? {
        val fx = barFx(kind)
        val icon = MorphIconDrawable.install(v, kind)
        // 바 버튼은 설정 변경·바 숨김 등으로 떼어졌다 다시 붙는다. 손가락을 뗀 신호(UP/CANCEL)를 못 받은 채 떼어지면
        // 버튼이 눌린 크기로 남고 아이콘 모양이 중간에 멈춰 다음 눌림이 시작되지 않으므로, 떼어질 때 제자리로 되돌린다.
        // (새로고침 ↔ 중지 아이콘 교체 중의 회전·투명도는 건드리지 않는다)
        detachWatch.remove(v)?.let { v.removeOnAttachStateChangeListener(it) }
        if (kind != "refresh") {
            val watch = object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(view: View) {}
                override fun onViewDetachedFromWindow(view: View) {
                    cancelPendingRelease(view)
                    snapHome(view)
                    icon?.reset()
                }
            }
            detachWatch[v] = watch
            v.addOnAttachStateChangeListener(watch)
        }
        v.setOnTouchListener { view, e ->
            if (enabled(view.context)) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        cancelPendingRelease(view)
                        barPress(view, fx)
                        icon?.press(true)   // 탭 버튼·플레이어 버튼은 누르는 동안 아이콘이 미리 움츠린다
                    }
                    MotionEvent.ACTION_UP -> {
                        val inside = e.x >= 0f && e.x <= view.width && e.y >= 0f && e.y <= view.height
                        val tap = inside &&
                            e.eventTime - e.downTime < android.view.ViewConfiguration.getLongPressTimeout()
                        val release = Runnable {
                            barRelease(view, fx, tap)
                            if (tap && playOnTap) icon?.play() else icon?.press(false)
                        }
                        // 홈 · 더보기: 떼면 곧바로 홈 화면을 불러오거나 메뉴를 만드느라 메인 스레드가 잠깐 막힌다.
                        // 그때 아이콘이 막 움직이기 시작하면 첫 장면들이 통째로 사라져 끊겨 보이므로,
                        // 눌린 자세 그대로 기다렸다가 클릭 처리와 그 무거운 첫 프레임이 지난 뒤에 움직임을 시작한다.
                        if (inside && kind in AFTER_CLICK) afterClick(view, release) else release.run()
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        cancelPendingRelease(view)
                        barRelease(view, fx, false)
                        icon?.press(false)
                    }
                }
            }
            extra?.invoke(view, e) ?: false
        }
        return icon
    }

    /** 떼는 동작을 클릭 처리 뒤로 미루는 버튼 종류 (클릭이 무거운 화면·메뉴를 만드는 것들) */
    private val AFTER_CLICK = setOf("home", "menu")

    /** 클릭 뒤로 미뤄 둔 떼기 동작 (뷰마다 하나) */
    private val pendingRelease = WeakHashMap<View, PendingRelease>()

    private class PendingRelease(val view: View, val action: Runnable) : android.view.Choreographer.FrameCallback {
        private var fired = false
        private var frames = 0
        private val timeout = Runnable { fire() }

        fun start() {
            // 클릭(performClick)은 이 터치 처리가 끝난 뒤 메시지로 실행된다.
            // 한 번 더 post 하면 그 클릭 다음에 와서, 메뉴·홈이 만들어진 뒤가 된다.
            view.post { view.post { android.view.Choreographer.getInstance().postFrameCallback(this) } }
            // 화면이 그려지지 않는 등 프레임이 안 오더라도 버튼이 눌린 채 남지 않게 한다
            view.postDelayed(timeout, 450L)
        }

        // 새 창(메뉴)의 첫 배치·그리기는 클릭 뒤 첫 프레임에서 일어난다. 그 프레임이 지난 다음 프레임에서 움직임을 시작한다.
        override fun doFrame(frameTimeNanos: Long) {
            if (fired) return
            if (++frames < 2) android.view.Choreographer.getInstance().postFrameCallback(this) else fire()
        }

        fun fire() {
            if (fired) return
            fired = true
            cancel()
            if (pendingRelease[view] === this) pendingRelease.remove(view)
            if (view.isAttachedToWindow) action.run()
        }

        fun cancel() {
            fired = true
            android.view.Choreographer.getInstance().removeFrameCallback(this)
            view.removeCallbacks(timeout)
        }
    }

    private fun afterClick(v: View, action: Runnable) {
        cancelPendingRelease(v)
        val p = PendingRelease(v, action)
        pendingRelease[v] = p
        p.start()
    }

    private fun cancelPendingRelease(v: View) {
        pendingRelease.remove(v)?.cancel()
    }

    private fun barPress(v: View, fx: BarFx) {
        pendingKick.remove(v)?.let { v.removeCallbacks(it) }
        val d = dp(v, 1f)
        spring(v, DynamicAnimation.SCALE_X, fx.pressScale, 1100f, 0.9f)
        spring(v, DynamicAnimation.SCALE_Y, fx.pressScale, 1100f, 0.9f)
        if (fx.windX != 0f) spring(v, DynamicAnimation.TRANSLATION_X, fx.windX * d, 900f, 0.9f)
        if (fx.windY != 0f) spring(v, DynamicAnimation.TRANSLATION_Y, fx.windY * d, 900f, 0.9f)
    }

    private fun barRelease(v: View, fx: BarFx, tap: Boolean) {
        val d = dp(v, 1f)
        // 크기는 바로 돌아오기 시작한다 (tap 이면 pop 세기만큼 더 튄다)
        val popV = if (tap) fx.pop else 0f
        spring(v, DynamicAnimation.SCALE_X, 1f, 480f, 0.36f, popV)
        spring(v, DynamicAnimation.SCALE_Y, 1f, 480f, 0.36f, popV)
        // 이동·회전은 클릭 처리가 끝난 뒤(팝업이 버튼 위치를 잡은 다음) 시작해, 팝업 위치가 흔들리지 않게 한다
        val moves = fx.windX != 0f || fx.windY != 0f ||
            (tap && (fx.kickX != 0f || fx.kickY != 0f || fx.kickRot != 0f || fx.spin != 0f || fx.flip))
        if (!moves) return
        val run = Runnable {
            pendingKick.remove(v)
            if (!v.isAttachedToWindow) return@Runnable
            val omega = 22f // sqrt(stiffness 500)
            fun kickVelocity(amount: Float, wind: Float) =
                if (tap && amount != 0f) Math.signum(amount) * (Math.abs(amount) + Math.abs(wind)) * omega * 1.3f else 0f
            if (fx.windX != 0f || (tap && fx.kickX != 0f)) {
                spring(v, DynamicAnimation.TRANSLATION_X, 0f, 500f, 0.4f, kickVelocity(fx.kickX * d, fx.windX * d))
            }
            if (fx.windY != 0f || (tap && fx.kickY != 0f)) {
                spring(v, DynamicAnimation.TRANSLATION_Y, 0f, 500f, 0.4f, kickVelocity(fx.kickY * d, fx.windY * d))
            }
            if (!tap) return@Runnable
            if (fx.kickRot != 0f) {
                spring(v, DynamicAnimation.ROTATION, 0f, 420f, 0.3f, fx.kickRot * 20f * 1.3f)
            }
            if (fx.spin != 0f) spin(v, DynamicAnimation.ROTATION, fx.spin)
            if (fx.flip) {
                v.cameraDistance = 9000f * v.resources.displayMetrics.density
                spin(v, DynamicAnimation.ROTATION_Y, 360f)
            }
        }
        pendingKick[v] = run
        v.postDelayed(run, 40)
    }

    /** 같은 뷰·같은 속성에서 돌고 있는 스프링을 현재 값에서 멈춘다 (다른 애니메이션이 그 속성을 넘겨받을 때). */
    fun stop(v: View, prop: DynamicAnimation.ViewProperty) {
        running[v]?.remove(prop)?.cancel()
    }

    /** 버튼 아이콘을 한 바퀴 돌린다 (새로고침을 눌렀는데 로딩 표시로 바뀌지 않을 때의 눌림 반응). */
    fun spinOnce(v: View, degrees: Float = 360f) {
        if (!enabled(v.context)) return
        spin(v, DynamicAnimation.ROTATION, degrees)
    }

    /** period 만큼(부호는 방향) 돌고 제자리. 도는 중에 또 눌러도 지금 각도에서 이어서 돈다. */
    private fun spin(v: View, prop: DynamicAnimation.ViewProperty, period: Float) {
        val p = Math.abs(period)
        val cur = if (prop == DynamicAnimation.ROTATION) v.rotation else v.rotationY
        val mod = ((cur % p) + p) % p
        val start = if (period > 0f) mod else mod - p
        if (prop == DynamicAnimation.ROTATION) v.rotation = start else v.rotationY = start
        val end = if (period > 0f) p else -p
        spring(v, prop, end, 170f, 0.74f) {
            if (prop == DynamicAnimation.ROTATION) v.rotation = 0f else v.rotationY = 0f
        }
    }
}
