package com.example.evergreen

import android.content.Context
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.color.MaterialColors
import com.google.android.material.textfield.TextInputEditText

/** 다운로드 목록 / 북마크 화면이 같이 쓰는 도우미 (폴더 칩, 폴더 선택, 이름 입력, 북마크 편집). */
object ListUi {

    /** "전체" 칩의 id (실제 폴더 id 는 항상 양수) */
    const val ALL = -1L

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    /** targetSdk 35 는 화면 가장자리까지 그리기가 강제된다 → 목록 화면은 시스템 바·키보드 만큼 여백을 둔다 */
    fun fitSystemBars(activity: AppCompatActivity) {
        val root = activity.findViewById<View>(android.R.id.content) ?: return
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars() or
                    androidx.core.view.WindowInsetsCompat.Type.displayCutout() or
                    androidx.core.view.WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            androidx.core.view.WindowInsetsCompat.CONSUMED
        }
    }

    /** 메뉴 팝업이 떠 있던 자리(버튼 오른쪽 끝 / 아래쪽, 화면 좌표) — 목록 팝업이 같은 자리에 뜨도록 넘긴다 */
    const val EXTRA_ANCHOR_RIGHT = "anchorRight"
    const val EXTRA_ANCHOR_BOTTOM = "anchorBottom"
    /** 같은 자리를 '앱 창 안' 좌표로 (분할 화면·프리폼처럼 창이 화면 모서리에 붙어 있지 않을 때 팝업 위치 계산용) */
    const val EXTRA_ANCHOR_WIN_RIGHT = "anchorWinRight"
    const val EXTRA_ANCHOR_WIN_BOTTOM = "anchorWinBottom"

    /** 목록 팝업의 ← 로 닫았을 때 true: 돌아온 메인 화면이 메뉴를 다시 띄운다 (한 번 쓰면 꺼진다) */
    @Volatile
    var reopenMenu = false

    /**
     * 폰 시트에서 ← / 뒤로가기로 닫을 때만 메뉴로 돌아가게 표시한다.
     * (아래로 내려서 닫거나 바깥을 눌러 닫으면 표시하지 않으니 메뉴 없이 그냥 닫힌다)
     */
    fun markBackToMenu(act: android.app.Activity) {
        if (act.resources.configuration.smallestScreenWidthDp < 600) reopenMenu = true
    }

    /**
     * 메뉴 시트(Material BottomSheetDialog → BottomSheetBehavior → ViewDragHelper)와 같은 움직임 곡선·시간.
     * 곡선은 ViewDragHelper 의 5차 ease-out, 시간은 (이동 거리/시트 높이 + 1) × 256ms (최대 600ms).
     */
    private val sheetInterp = android.animation.TimeInterpolator { t ->
        val x = t - 1f
        x * x * x * x * x + 1f
    }

    private fun settleMs(dist: Float, h: Float): Long =
        ((dist / h.coerceAtLeast(1f)).coerceIn(0f, 1f) + 1f).times(256f).toLong().coerceAtMost(600L)

    /** 폰 시트마다 "내려가며 닫는" 동작을 하나씩 들고 있는다 (applyPhoneSheet 가 등록) */
    private val sheetClosers = java.util.WeakHashMap<android.app.Activity, () -> Unit>()

    /**
     * 시트를 닫는 유일한 길: 시트가 내려가고 뒤 배경(어두움·블러)이 함께 풀린 다음 finish 한다 (메뉴 시트가 닫히는 방식).
     * backToMenu 가 true 면 닫은 뒤 메뉴로 돌아간다 (← 버튼·시스템 뒤로가기).
     * 폰 시트가 아니면(태블릿 팝업) 그냥 finish 한다.
     */
    fun closeSheet(act: android.app.Activity, backToMenu: Boolean = false) {
        if (backToMenu) markBackToMenu(act)
        val closer = sheetClosers[act]
        if (closer != null) closer() else act.finish()
    }

    /** 이 목록 화면을 연 메인 화면 — 시트 뒤에서 흐려질 화면 */
    @Volatile
    var behindActivity: java.lang.ref.WeakReference<android.app.Activity>? = null

    /**
     * 태블릿(최소 너비 600dp 이상)이면 이 화면을 전체 화면 대신 메뉴와 같은 모양의 팝업으로 만든다.
     * - 메뉴 버튼 아래(오른쪽 끝 맞춤)에 같은 둥근 카드(연한 면 + 블러 유리) 로 뜨고, 같은 스프링으로 열린다.
     * - 메뉴 자리를 모르면 가운데에 뜬다.
     * (창 테마는 values-sw600dp 의 Theme.Evergreen.ListWindow 가 floating 으로 바꿔 준다.)
     * setContentView 뒤에 불러야 한다. 
     */
    fun applyTabletPopup(act: AppCompatActivity) {
        if (act.resources.configuration.smallestScreenWidthDp < 600) {
            applyPhoneSheet(act)
            return
        }
        val root0 = act.findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as? ViewGroup ?: return
        // 폰 시트를 연 채 태블릿으로 바뀌어 다시 만들어진 경우: 메인 화면이 아직 태블릿 상단바를 배치하는 중이라
        // 메뉴 버튼 자리를 모른다 → 그대로 열면 가운데에 뜬다. 자리가 안정될 때까지 숨겨 두고 기다렸다가 연다. (최대 1.2초)
        val fromMenu0 = act.intent.getIntExtra(EXTRA_ANCHOR_RIGHT, -1) > 0 &&
            act.intent.getIntExtra(EXTRA_ANCHOR_BOTTOM, -1) > 0
        val main = behindActivity?.get() as? MainActivity
        if (!fromMenu0 && main != null && main.listAnchorInfo() == null) {
            root0.visibility = View.INVISIBLE
            val start = android.os.SystemClock.uptimeMillis()
            var last: List<Int>? = null
            var stable = 0
            val tick = object : Runnable {
                override fun run() {
                    if (act.isFinishing || act.isDestroyed) return
                    val now = android.os.SystemClock.uptimeMillis()
                    val info = if (main.isFinishing || main.isDestroyed) null else main.listAnchorInfo()
                    val sig = info?.toList()
                    if (sig != null && sig == last) stable++ else stable = 0
                    last = sig
                    if ((info != null && stable >= 3) || now - start >= 1200L) {
                        root0.visibility = View.VISIBLE
                        buildTabletPopup(act, root0, info)
                    } else {
                        root0.postDelayed(this, 16)
                    }
                }
            }
            root0.postDelayed(tick, 16)
            return
        }
        buildTabletPopup(act, root0, null)
    }

    /** [knownInfo]: 메뉴 자리를 기다렸다가 알아낸 값 (없으면 지금 메인 화면에 물어본다) */
    private fun buildTabletPopup(act: AppCompatActivity, root: ViewGroup, knownInfo: IntArray?) {
        // 제목 왼쪽의 뒤로가기(←) 버튼 (태블릿 팝업 레이아웃에만 있다)
        // 메뉴에서 열린 팝업이면(메뉴 자리를 받았으면) 닫은 뒤 메뉴를 다시 띄우고, 아니면 그냥 닫는다.
        act.findViewById<View>(R.id.btnListArrow)?.setOnClickListener {
            reopenMenu = act.intent.getIntExtra(EXTRA_ANCHOR_RIGHT, -1) > 0
            act.finish()
        }
        // 시스템 뒤로가기도 ← 버튼과 같게: 메뉴에서 열린 팝업이면 닫은 뒤 메뉴로 돌아간다 (바깥을 눌러 닫으면 메뉴 없이 닫힘)
        act.onBackPressedDispatcher.addCallback(act, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                reopenMenu = act.intent.getIntExtra(EXTRA_ANCHOR_RIGHT, -1) > 0
                isEnabled = false
                act.onBackPressedDispatcher.onBackPressed()
            }
        })
        val dm = act.resources.displayMetrics
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels
        val margin = dp(act, 8)

        // 화면 좌표 (창이 어디 있는지 확인하는 데만 쓴다)
        var sRight = act.intent.getIntExtra(EXTRA_ANCHOR_RIGHT, -1)
        var sBottom = act.intent.getIntExtra(EXTRA_ANCHOR_BOTTOM, -1)
        // 메뉴에서 연 팝업인지 (← / 뒤로가기 / 바깥 누름으로 닫을 때 메뉴로 돌아갈지 정한다)
        val fromMenu = sRight > 0 && sBottom > 0
        // 팝업 창의 위치(lp.x / lp.y)는 앱 창 안 좌표 기준이라, 창 안 좌표가 있으면 그것으로 계산한다
        var aRight = act.intent.getIntExtra(EXTRA_ANCHOR_WIN_RIGHT, sRight)
        var aBottom = act.intent.getIntExtra(EXTRA_ANCHOR_WIN_BOTTOM, sBottom)
        // 폰 시트로 열었다가 태블릿으로 바뀌어 다시 만들어진 경우처럼 자리를 모르면, 상단바 메뉴 버튼 아래에 붙인다
        if (!fromMenu) {
            val info = knownInfo ?: (behindActivity?.get() as? MainActivity)?.listAnchorInfo()
            if (info != null) {
                aRight = info[0]; aBottom = info[1]; sRight = info[2]; sBottom = info[3]
            }
        }
        val anchored = sRight > 0 && sBottom > 0

        val width = minOf(dp(act, 360), screenW - margin * 2)
        val top = if (anchored) aBottom + dp(act, 4) else 0
        val maxH = if (anchored) screenH - top - dp(act, 12) else (screenH * 0.82f).toInt()
        val height = if (anchored) maxOf(maxH, dp(act, 240)).coerceAtMost(screenH - margin * 2)
            else minOf(maxOf(maxH, dp(act, 320)), dp(act, 760), screenH - margin * 2)

        val lp = act.window.attributes
        lp.width = width
        lp.height = height
        if (anchored) {
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (aRight - width).coerceIn(margin, maxOf(margin, screenW - width - margin))
            lp.y = top
        } else {
            lp.gravity = Gravity.CENTER
        }
        act.window.attributes = lp
        act.setFinishOnTouchOutside(true)
        // 바깥을 눌러 닫을 때도 ← 와 같이 메뉴로 돌아간다 (터치 처리 자체는 그대로 두고 표시만 켠다)
        val orig = act.window.callback
        act.window.callback = object : android.view.Window.Callback by orig {
            override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
                if (ev.action == android.view.MotionEvent.ACTION_DOWN) {
                    // 창 바깥(투명한 가장자리)을 누른 것인지 직접 판정한다 (Activity 의 바깥 누름 닫기와 같은 기준)
                    val d = act.window.decorView
                    val slop = android.view.ViewConfiguration.get(act).scaledWindowTouchSlop
                    if (ev.x < -slop || ev.y < -slop || ev.x > d.width + slop || ev.y > d.height + slop) {
                        reopenMenu = fromMenu
                    }
                }
                return orig.dispatchTouchEvent(ev)
            }
        }

        // 메뉴 팝업과 같은 카드 모양 (연한 면 + 둥근 모서리, 블러가 켜져 있으면 뒤가 비치는 유리).
        // 카드는 창이 아니라 내용 뷰에 입혀서, 열릴 때 배경도 함께 움직이게 한다.
        root.background = Popup.anchoredBackground(act, root)
        Blur.behind(act.window, act, radiusDp = 10, dim = 0.12f)

        Popup.prepareAnchoredEnter(
            root,
            if (anchored) (aRight - dp(act, 22) - lp.x).toFloat() else width / 2f,
            width
        )
        val decor = act.window.decorView
        decor.post {
            if (anchored) {
                // 상태 표시줄 등으로 창 위치가 어긋나면 메뉴가 있던 높이에 맞춘다
                val loc = IntArray(2)
                decor.getLocationOnScreen(loc)
                // 화면 좌표끼리 비교한다 (창 안 좌표 top 과 섞으면 창이 내려앉은 분할 화면에서 어긋난다)
                val diff = loc[1] - (sBottom + dp(act, 4))
                if (kotlin.math.abs(diff) > 2) {
                    lp.y -= diff
                    act.window.attributes = lp
                }
            }
            Popup.playAnchoredEnter(root, act.findViewById<ViewGroup>(R.id.listView))
        }
    }

    /**
     * 폰: 이 화면을 아래에서 올라오는 바텀시트로 만든다.
     * - 화면 아래에 붙고 높이는 상태표시줄 아래까지(메뉴 시트와 같게), 위쪽 모서리가 둥글다. 위에 손잡이가 있다.
     * - 손잡이를 아래로 끌거나 빠르게 쓸어내리면 닫히고, 바깥(어두운 곳)을 눌러도 닫힌다.
     * (창 테마는 themes_list.xml 의 Theme.Evergreen.ListWindow 가 floating 으로 만든다.)
     */
    private fun applyPhoneSheet(act: AppCompatActivity) {
        val root = act.findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as? LinearLayout ?: return
        val dm = act.resources.displayMetrics
        val lp = act.window.attributes
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        // 메뉴 시트처럼 상태표시줄 바로 아래까지 올라온다
        val sbId = act.resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusH = if (sbId > 0) act.resources.getDimensionPixelSize(sbId) else dp(act, 24)
        lp.height = dm.heightPixels - statusH - dp(act, 4)
        lp.gravity = Gravity.BOTTOM
        act.window.attributes = lp
        // 메뉴 시트처럼 처음부터 시트 전체가 한 번에 올라오게 한다.
        // 시스템 창 전환(내용이 그려지는 중에 시작해 중간에 끊겨 보일 수 있다)은 끄고, 시트 뷰를 화면 아래에서 직접 올린다.
        if (Motion.enabled(act)) {
            @Suppress("DEPRECATION")
            act.overridePendingTransition(0, 0)
            root.translationY = lp.height.toFloat()
            root.post {
                root.animate().translationY(0f).setDuration(settleMs(lp.height.toFloat(), lp.height.toFloat()))
                    .setInterpolator(sheetInterp).start()
            }
        }
        act.setFinishOnTouchOutside(true)

        // 시트는 화면 아래에만 붙으니 위쪽 시스템 바 여백은 필요 없고, 아래(내비게이션 바·키보드)만 비운다
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(act.findViewById<View>(android.R.id.content)) { v, insets ->
            val b = insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.navigationBars() or
                    androidx.core.view.WindowInsetsCompat.Type.ime()
            )
            v.setPadding(0, 0, 0, b.bottom)
            androidx.core.view.WindowInsetsCompat.CONSUMED
        }

        // 위쪽 모서리만 둥근 시트 배경
        val r = dp(act, 28).toFloat()  // 메뉴 시트와 같은 모서리
        // 뒤 페이지를 흐리게 + 시트를 반투명 유리로 (블러가 적용될 때만)
        // 이 화면을 연 메인 화면을 직접 흐리게 한다 (안 되면 예전처럼 창 블러를 시도)
        val glass = Blur.behindLauncher(act, behindActivity?.get(), radiusDp = 18, dim = 0.12f) ||
            Blur.behind(act.window, act, radiusDp = 18, dim = 0.12f)
        // 뒤 화면을 어둡게 하는 정도도 메뉴 시트처럼 시트가 올라오고 내려가는 동안 서서히 바뀐다
        // (시스템 창 전환을 껐으니 직접 한다. 안 그러면 시트가 뜨기 전에 어둠이 먼저 확 켜진다)
        val dimTarget = act.window.attributes.dimAmount
        var dimNow = dimTarget
        var dimAnim: android.animation.ValueAnimator? = null
        fun fadeDim(to: Float, ms: Long, ip: android.animation.TimeInterpolator) {
            dimAnim?.cancel()
            dimAnim = android.animation.ValueAnimator.ofFloat(dimNow, to).apply {
                duration = ms
                interpolator = ip
                addUpdateListener {
                    dimNow = it.animatedValue as Float
                    try { act.window.setDimAmount(dimNow) } catch (_: Throwable) {}
                }
                start()
            }
        }
        if (Motion.enabled(act)) {
            dimNow = 0f
            try { act.window.setDimAmount(0f) } catch (_: Throwable) {}
            root.post { fadeDim(dimTarget, settleMs(root.height.toFloat(), root.height.toFloat()), sheetInterp) }
        }
        root.background = if (glass) {
            Blur.glass(act, com.google.android.material.R.attr.colorSurfaceContainer, r, topOnly = true)
        } else GradientDrawable().apply {
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setColor(MaterialColors.getColor(root, com.google.android.material.R.attr.colorSurfaceContainer))
        }
        root.clipToOutline = true
        root.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) {
                outline.setRoundRect(0, 0, v.width, v.height + r.toInt(), r)
            }
        }

        // 손잡이 (끌어서 닫는 자리)
        val grab = FrameLayout(act)
        val pill = View(act).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(act, 3).toFloat()
                setColor(MaterialColors.getColor(root, com.google.android.material.R.attr.colorOutlineVariant))
            }
        }
        grab.addView(pill, FrameLayout.LayoutParams(dp(act, 40), dp(act, 5), Gravity.CENTER))
        root.addView(grab, 0, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(act, 24)))

        // 메뉴 시트처럼 안의 내용(제목줄·칩·목록)이 시트가 올라오는 동안 차례로 떠오른다 (손잡이는 시트와 함께 움직이니 제외)
        for (i in 1 until root.childCount) {
            val ch = root.getChildAt(i)
            // 큰 목록 카드는 통째로 커지지 않고 떠오르기만 한다 (메뉴는 항목 하나하나가 작게 떠오른다)
            Motion.enter(ch, minOf(90L + (i - 1) * 32L, 360L), scale = if (((ch.layoutParams as? LinearLayout.LayoutParams)?.weight ?: 0f) > 0f) 1f else 0.94f)
        }

        var closing = false
        fun dismiss() {
            if (closing) return
            closing = true
            Blur.releaseBehindLauncher(act)
            // 남은 거리에 비례한 시간으로, 메뉴 시트가 내려가는 곡선 그대로
            val ms = settleMs(root.height - root.translationY, root.height.toFloat())
            fadeDim(0f, ms, sheetInterp)
            root.animate().translationY(root.height.toFloat()).setDuration(ms).setInterpolator(sheetInterp).withEndAction {
                act.finish()
                // 이미 내려간 상태에서 닫으니 시스템 닫힘 모션은 끈다
                act.overridePendingTransition(0, 0)
            }.start()
        }
        sheetClosers[act] = { dismiss() }

        // 메뉴 시트처럼 중간 멈춤 자리가 있다: 펼친 상태(0) ↔ 반쯤 내린 상태(collapsedTy) ↔ 닫힘.
        // 반쯤 내린 자리는 Material 기본값(시트 윗선이 화면 너비의 9/16 높이)과 같다.
        val collapsedTy = (dm.widthPixels * 9f / 16f - (dm.heightPixels - lp.height)).coerceAtLeast(0f)
        fun moveTo(ty: Float) {
            root.animate().cancel()
            root.animate().translationY(ty)
                .setDuration(settleMs(kotlin.math.abs(root.translationY - ty), root.height.toFloat()))
                .setInterpolator(sheetInterp).start()
        }
        // 손을 뗄 때: 빠르게 쓸면 다음 자리로, 천천히 놓으면 가장 가까운 자리로
        fun settle(vy: Float, cancelled: Boolean) {
            val ty = root.translationY
            val h = root.height.toFloat()
            val stops = if (collapsedTy > dp(act, 40)) floatArrayOf(0f, collapsedTy, h) else floatArrayOf(0f, h)
            if (cancelled) { moveTo(stops.minByOrNull { kotlin.math.abs(it - ty) } ?: 0f); return }
            val target = when {
                vy > 1400f -> stops.firstOrNull { it > ty + dp(act, 8) } ?: h
                vy < -1400f -> stops.lastOrNull { it < ty - dp(act, 8) } ?: 0f
                else -> {
                    // 닫힘 쪽 경계는 마지막 멈춤 자리에서 시트 높이의 1/4 만큼 더 내려간 곳
                    val last = stops[stops.size - 2]
                    if (ty > last + (h - last) * 0.25f) h
                    else stops.dropLast(1).minByOrNull { kotlin.math.abs(it - ty) } ?: 0f
                }
            }
            if (target >= h) dismiss() else moveTo(target)
        }

        // 시스템 뒤로가기: 메뉴에서 열었던 시트면 메뉴로 돌아간다 (내려서 닫기·바깥 누름은 메뉴 없이 닫힘)
        act.onBackPressedDispatcher.addCallback(act, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                closeSheet(act, backToMenu = true)
            }
        })
        // 바깥(어두운 곳)을 눌러도 같은 모션으로 내려가며 닫힌다 (Activity 기본 바깥 누름 닫기는 모션 없이 끊겨 보인다)
        val origCb = act.window.callback
        act.window.callback = object : android.view.Window.Callback by origCb {
            override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
                if (ev.actionMasked == android.view.MotionEvent.ACTION_DOWN) {
                    val d = act.window.decorView
                    val slop = android.view.ViewConfiguration.get(act).scaledWindowTouchSlop
                    if (ev.x < -slop || ev.y < -slop || ev.x > d.width + slop || ev.y > d.height + slop) {
                        closeSheet(act)
                        return true
                    }
                }
                return origCb.dispatchTouchEvent(ev)
            }
        }
        var startY = 0f
        var startTy = 0f
        var vt: android.view.VelocityTracker? = null
        grab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    startTy = root.translationY
                    vt?.recycle()
                    vt = android.view.VelocityTracker.obtain().also { it.addMovement(e) }
                    root.animate().cancel()
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(e)
                    root.translationY = (startTy + e.rawY - startY).coerceAtLeast(0f)
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    vt?.addMovement(e)
                    vt?.computeCurrentVelocity(1000)
                    val vy = vt?.yVelocity ?: 0f
                    vt?.recycle(); vt = null
                    settle(vy, e.actionMasked == android.view.MotionEvent.ACTION_CANCEL)
                }
            }
            true
        }

        // 메뉴 시트와 같은 제스처: 목록이 맨 위에 있을 때 목록을 아래로 끌면 시트가 따라 내려오고(놓으면 닫히거나 제자리로),
        // 목록이 아래로 스크롤돼 있으면 시트는 가만히 있고 목록만 스크롤된다.
        val list = act.findViewById<android.widget.AbsListView>(R.id.listView)
        if (list != null) {
            val slop = android.view.ViewConfiguration.get(act).scaledTouchSlop
            var downY = 0f
            var downTy = 0f
            var dragging = false
            var tracker: android.view.VelocityTracker? = null
            list.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        downY = e.rawY
                        downTy = root.translationY
                        dragging = false
                        tracker?.recycle()
                        tracker = android.view.VelocityTracker.obtain().also { it.addMovement(e) }
                        false
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        tracker?.addMovement(e)
                        val dy = e.rawY - downY
                        // 맨 위에서 아래로 끌거나, 시트가 내려가 있을 땐 위로 끌어도 시트가 움직임을 가져간다
                        if (!dragging && ((dy > slop && !list.canScrollVertically(-1)) || (downTy > 0f && dy < -slop))) {
                            // 여기부터는 시트가 움직임을 가져간다: 목록이 하던 터치는 취소
                            dragging = true
                            downY = e.rawY
                            root.animate().cancel()
                            downTy = root.translationY
                            val c = android.view.MotionEvent.obtain(e)
                            c.action = android.view.MotionEvent.ACTION_CANCEL
                            list.onTouchEvent(c)
                            c.recycle()
                        }
                        if (dragging) {
                            root.translationY = (downTy + e.rawY - downY).coerceAtLeast(0f)
                            true
                        } else false
                    }
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                        val was = dragging
                        dragging = false
                        if (was) {
                            tracker?.addMovement(e)
                            tracker?.computeCurrentVelocity(1000)
                            val vy = tracker?.yVelocity ?: 0f
                            settle(vy, e.actionMasked == android.view.MotionEvent.ACTION_CANCEL)
                        }
                        tracker?.recycle(); tracker = null
                        was
                    }
                    else -> dragging
                }
            }
        }
    }

    fun toast(ctx: Context, msg: String) = AppToast.show(ctx, msg)

    /** 지운 직후에 '실행 취소' 버튼이 달린 알림을 띄운다 (누르면 onUndo) */
    fun undoToast(act: AppCompatActivity, msg: String, onUndo: () -> Unit) {
        if (Prefs(act).notifyDeleteUndo) AppToast.showAction(act, msg, null, "실행 취소", onUndo)
    }

    fun fmtSize(n: Long): String = when {
        n >= 1L shl 30 -> String.format("%.2f GB", n / (1024.0 * 1024 * 1024))
        n >= 1L shl 20 -> String.format("%.1f MB", n / (1024.0 * 1024))
        n >= 1L shl 10 -> String.format("%.0f KB", n / 1024.0)
        else -> "$n B"
    }

    // ───────────────────────── 글자 입력 대화상자 ─────────────────────────

    fun promptText(
        ctx: Context,
        title: String,
        initial: String,
        hint: String,
        onOk: (String) -> Unit
    ) {
        val et = EditText(ctx)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setSingleLine(true)
        et.hint = hint
        et.setText(initial)
        et.setSelection(et.text.length)
        Popup.styleInput(et)

        val box = FrameLayout(ctx)
        box.setPadding(dp(ctx, 24), dp(ctx, 12), dp(ctx, 24), 0)
        box.addView(
            et,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val dialog = MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(box)
            .setNegativeButton("취소", null)
            .setPositiveButton("확인") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) onOk(s)
            }
            .create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        et.requestFocus()
    }

    // ───────────────────────── 폴더 칩 ─────────────────────────

    class ChipEntry(val id: Long, val label: String)

    /**
     * 화면 위쪽의 폴더 칩 줄을 다시 그린다.
     * 칩을 누르면 onSelect, 폴더 칩을 길게 누르면 onLongPress, 맨 끝 "＋ 폴더" 를 누르면 onAdd.
     */
    fun renderChips(
        row: LinearLayout,
        entries: List<ChipEntry>,
        selected: Long,
        onSelect: (Long) -> Unit,
        onLongPress: (Long) -> Unit,
        onAdd: (() -> Unit)? = null
    ) {
        val ctx = row.context
        row.removeAllViews()

        val onContainer = MaterialColors.getColor(row, com.google.android.material.R.attr.colorOnPrimaryContainer)
        val container = MaterialColors.getColor(row, com.google.android.material.R.attr.colorPrimaryContainer)
        val surfaceHigh = MaterialColors.getColor(row, com.google.android.material.R.attr.colorSurfaceContainerHigh)
        val onSurface = MaterialColors.getColor(row, com.google.android.material.R.attr.colorOnSurface)
        val outline = MaterialColors.getColor(row, com.google.android.material.R.attr.colorOutlineVariant)

        fun makeChip(text: String, on: Boolean, outlined: Boolean): TextView {
            val tv = TextView(ctx)
            tv.text = text
            tv.textSize = 13.5f
            tv.maxLines = 1
            tv.setPadding(dp(ctx, 14), dp(ctx, 7), dp(ctx, 14), dp(ctx, 7))
            tv.setTextColor(if (on) onContainer else onSurface)
            tv.background = GradientDrawable().apply {
                cornerRadius = dp(ctx, 18).toFloat()
                if (outlined) {
                    setColor(0)
                    setStroke(dp(ctx, 1), outline)
                } else {
                    setColor(if (on) container else surfaceHigh)
                }
            }
            tv.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(ctx, 4), 0, dp(ctx, 4), 0) }
            return tv
        }

        entries.forEach { e ->
            val chip = makeChip(e.label, e.id == selected, false)
            if (e.id != ALL) {
                // 폴더 칩 앞에 폴더 아이콘
                androidx.appcompat.content.res.AppCompatResources.getDrawable(ctx, R.drawable.ic_folder)?.mutate()?.let { d ->
                    d.setBounds(0, 0, dp(ctx, 18), dp(ctx, 18))
                    d.setTint(if (e.id == selected) onContainer else onSurface)
                    chip.setCompoundDrawablesRelative(d, null, null, null)
                    chip.compoundDrawablePadding = dp(ctx, 6)
                }
            }
            chip.setOnClickListener { onSelect(e.id) }
            if (e.id != ALL) {
                chip.setOnLongClickListener {
                    onLongPress(e.id)
                    true
                }
            }
            row.addView(chip)
        }
        if (onAdd != null) {
            val add = makeChip("＋ 폴더", false, true)
            add.setOnClickListener { onAdd() }
            row.addView(add)
        }
    }

    /** 폴더 칩을 길게 눌렀을 때: 이름 변경 / 삭제 */
    fun showFolderMenu(
        ctx: Context,
        prefs: Prefs,
        kind: String,
        folder: Folder,
        onChanged: () -> Unit
    ) {
        Popup.menu(
            ctx,
            title = folder.name,
            subtitle = "폴더",
            headerIcon = R.drawable.ic_folder,
            items = listOf(
                Popup.Item(R.drawable.ic_edit, "이름 변경") {
                    promptText(ctx, "폴더 이름 변경", folder.name, "폴더 이름") { name ->
                        prefs.renameFolder(kind, folder.id, name)
                        onChanged()
                    }
                },
                Popup.Item(R.drawable.ic_delete, "폴더 삭제", "안의 항목은 그대로 남습니다", danger = true) {
                    val what = if (kind == Prefs.KIND_BM) "북마크" else "파일"
                    Popup.confirm(
                        ctx, "폴더를 삭제할까요?",
                        "'${folder.name}' 폴더만 삭제되고, 안에 있던 ${what}은(는) 그대로 남습니다.",
                        "삭제", danger = true
                    ) {
                        prefs.removeFolder(kind, folder.id)
                        onChanged()
                    }
                }
            )
        )
    }

    /** 새 폴더 이름을 물어보고 만든다. */
    fun createFolder(ctx: Context, prefs: Prefs, kind: String, onCreated: (Folder) -> Unit) {
        promptText(ctx, "새 폴더", "", "폴더 이름") { name ->
            onCreated(prefs.addFolder(kind, name))
        }
    }

    /** 폴더 고르기: 폴더 없음 / 기존 폴더들 / 새 폴더 만들기. 고른 폴더 id (없음 = 0) 를 돌려준다. */
    fun pickFolder(
        ctx: Context,
        prefs: Prefs,
        kind: String,
        current: Long,
        onPick: (Long) -> Unit
    ) {
        val folders = prefs.folders(kind)
        val labels = ArrayList<String>()
        labels.add("폴더 없음")
        folders.forEach { labels.add(it.name) }
        labels.add("＋ 새 폴더 만들기")
        val checked = if (current == 0L) 0 else folders.indexOfFirst { it.id == current } + 1

        MaterialAlertDialogBuilder(ctx)
            .setTitle("폴더 선택")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                d.dismiss()
                when {
                    which == 0 -> onPick(0L)
                    which == labels.size - 1 -> createFolder(ctx, prefs, kind) { onPick(it.id) }
                    else -> onPick(folders[which - 1].id)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // ───────────────────────── 북마크 추가 / 수정 ─────────────────────────

    /** 주소가 http(s) 로 시작하지 않으면 https:// 를 붙인다. */
    fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        return if (s.startsWith("http://") || s.startsWith("https://")) s else "https://$s"
    }

    fun displayTitle(title: String, url: String): String =
        title.trim().ifEmpty { try { Uri.parse(url).host } catch (e: Exception) { null } ?: url }

    /**
     * 북마크 추가/수정 대화상자 (이름, 주소, 폴더). existing 이 있으면 수정 + 삭제 버튼이 나온다.
     * onDone 은 저장/삭제가 끝난 뒤 불린다.
     */
    fun showBookmarkEditor(
        activity: AppCompatActivity,
        prefs: Prefs,
        existing: Bookmark?,
        url: String,
        title: String,
        onDone: (message: String) -> Unit
    ) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_bookmark, null)
        val etTitle = view.findViewById<TextInputEditText>(R.id.etBmTitle)
        val etUrl = view.findViewById<TextInputEditText>(R.id.etBmUrl)
        val btnFolder = view.findViewById<Button>(R.id.btnBmFolder)

        etTitle.setText(existing?.title ?: title)
        etUrl.setText(existing?.url ?: url)

        var folderId = existing?.folderId ?: prefs.lastBookmarkFolder
        if (folderId != 0L && prefs.folders(Prefs.KIND_BM).none { it.id == folderId }) folderId = 0L

        fun showFolder() {
            btnFolder.text =
                prefs.folders(Prefs.KIND_BM).firstOrNull { it.id == folderId }?.name ?: "폴더 없음"
        }
        showFolder()
        btnFolder.setOnClickListener {
            pickFolder(activity, prefs, Prefs.KIND_BM, folderId) {
                folderId = it
                showFolder()
            }
        }

        val builder = MaterialAlertDialogBuilder(activity)
            .setTitle(if (existing == null) "북마크 추가" else "북마크 수정")
            .setView(view)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                val rawUrl = etUrl.text.toString().trim()
                if (rawUrl.isEmpty()) {
                    toast(activity, "주소를 입력하세요")
                } else {
                    val finalUrl = normalizeUrl(rawUrl)
                    val finalTitle = displayTitle(etTitle.text.toString(), finalUrl)
                    prefs.saveBookmark(finalUrl, finalTitle, folderId, existing?.id)
                    prefs.lastBookmarkFolder = folderId
                    onDone(if (existing == null) "북마크에 추가했습니다" else "북마크를 수정했습니다")
                }
            }
        if (existing != null) {
            builder.setNeutralButton("삭제") { _, _ ->
                prefs.removeBookmark(existing.id)
                onDone("북마크를 삭제했습니다")
            }
        }
        builder.show()
    }
}
