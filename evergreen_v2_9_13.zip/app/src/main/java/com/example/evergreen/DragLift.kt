package com.example.evergreen

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.view.View

/**
 * 끌 때 손가락 밑에 따라오는 그림. 원래 크기보다 살짝 키우고(들어 올린 느낌) 둥근 판과 그림자를 깔아 준다.
 * 손가락이 그림 가운데를 잡고 있는 것처럼 보이게 터치 기준점을 가운데로 둔다.
 */
internal class LiftShadow(
    v: View,
    private val plateColor: Int,
    private val scale: Float = 1.18f
) : View.DragShadowBuilder(v) {

    private val d = v.resources.displayMetrics.density
    private val pad = (10 * d)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onProvideShadowMetrics(outShadowSize: Point, outShadowTouchPoint: Point) {
        val v = view
        val w = (v.width * scale + pad * 2).toInt()
        val h = (v.height * scale + pad * 2).toInt()
        outShadowSize.set(w, h)
        outShadowTouchPoint.set(w / 2, h / 2)
    }

    override fun onDrawShadow(canvas: Canvas) {
        val v = view
        val w = v.width * scale + pad * 2
        val h = v.height * scale + pad * 2
        // 둥근 판 (+ 가능한 기기에서는 부드러운 그림자)
        paint.color = plateColor
        try { paint.setShadowLayer(6 * d, 0f, 2 * d, 0x55000000) } catch (e: Throwable) { }
        val inset = pad * 0.55f
        canvas.drawRoundRect(RectF(inset, inset, w - inset, h - inset), 14 * d, 14 * d, paint)
        paint.clearShadowLayer()
        canvas.save()
        canvas.translate(w / 2f, h / 2f)
        canvas.scale(scale, scale)
        canvas.translate(-v.width / 2f, -v.height / 2f)
        v.draw(canvas)
        canvas.restore()
    }
}
