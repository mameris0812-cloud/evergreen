package com.example.evergreen

import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.io.OutputStream
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * HLS(m3u8) 영상을 받아 파일 하나로 이어 붙이는 도구. (안드로이드 클래스를 쓰지 않는 순수 코드)
 *
 * - 마스터 목록이면 가장 화질 좋은 것을 고른다. 소리가 따로 있는 영상(EXT-X-MEDIA)은 소리도 같이 받는다.
 * - 조각(TS / fMP4)은 여러 개를 동시에 받되, 파일에는 순서대로 이어 쓴다.
 * - AES-128 로 암호화된 조각은 키를 받아 풀어 쓴다. (SAMPLE-AES, DRM 은 지원하지 않음)
 * - EXT-X-MAP(초기화 조각), EXT-X-BYTERANGE 를 지원한다.
 */
object HlsDownload {

    /** 암호화 키 정보. iv 가 null 이면 조각 번호(EXT-X-MEDIA-SEQUENCE)를 IV 로 쓴다. */
    class Key(val uri: String, val iv: ByteArray?)

    class Seg(val url: String, val rangeStart: Long, val rangeLen: Long, val key: Key?, val seq: Long)

    class Init(val url: String, val rangeStart: Long, val rangeLen: Long)

    class Stream(val segs: List<Seg>, val init: Init?) {
        /** 조각이 fMP4(.m4s / .mp4 …) 이면 true, 아니면 TS 또는 소리만 있는 파일 */
        val fmp4: Boolean
            get() = init != null || (segs.firstOrNull()?.url?.let { extOf(it) } in FMP4_EXTS)

        /** 이어 붙인 파일의 확장자: ts / mp4 / aac / mp3 … */
        val rawExt: String
            get() {
                if (fmp4) return "mp4"
                return when (segs.firstOrNull()?.url?.let { extOf(it) }) {
                    "aac" -> "aac"
                    "mp3" -> "mp3"
                    "ac3" -> "ac3"
                    else -> "ts"
                }
            }

        val rawMime: String
            get() = when (rawExt) {
                "mp4" -> "video/mp4"
                "aac" -> "audio/aac"
                "mp3" -> "audio/mpeg"
                "ac3" -> "audio/ac3"
                else -> "video/mp2t"
            }
    }

    class Plan(val video: Stream, val audio: Stream?)

    /** 네트워크 설정 / 취소 / 진행 알림 */
    class Ctx(
        val client: OkHttpClient,
        val userAgent: String?,
        val referer: String?,
        val cookieFor: (String) -> String?,
        val cancelled: () -> Boolean,
        val calls: ConcurrentLinkedQueue<Call>,
        val onBytes: (Long) -> Unit,
        val onSegment: () -> Unit
    ) {
        val keyCache = ConcurrentHashMap<String, ByteArray>()
    }

    private class HttpErr(val code: Int) : IOException("HTTP $code")

    private val FMP4_EXTS = setOf("m4s", "mp4", "m4v", "m4a", "cmfv", "cmfa", "cmfm", "fmp4")
    private const val PARALLEL = 6

    private fun extOf(url: String): String? {
        val p = url.substringBefore('#').substringBefore('?')
        val d = p.lastIndexOf('.')
        if (d < 0 || p.length - d > 8) return null
        return p.substring(d + 1).lowercase()
    }

    /** 주소나 서버가 알려 준 종류만 보고 HLS 인지 짐작한다 */
    fun looksLikeHls(url: String?, mime: String?): Boolean {
        if (mime != null && isHlsMime(mime)) return true
        val u = url?.lowercase() ?: return false
        val path = u.substringBefore('#').substringBefore('?')
        return path.endsWith(".m3u8") || path.endsWith(".m3u")
    }

    fun isHlsMime(mime: String): Boolean = mime.lowercase().contains("mpegurl")

    // ───────────────────────── 목록(playlist) 읽기 ─────────────────────────

    fun plan(ctx: Ctx, url: String): Plan {
        val text = fetchText(ctx, url)
        if (!text.trimStart().startsWith("#EXTM3U")) throw IOException("HLS 목록이 아닙니다")
        if (!text.contains("#EXT-X-STREAM-INF")) {
            return Plan(parseMedia(text, url), null)
        }
        val variant = pickVariant(text, url) ?: throw IOException("재생 목록에서 영상을 찾지 못했어요")
        val video = parseMedia(fetchText(ctx, variant.url), variant.url)
        var audio: Stream? = null
        val ag = variant.audioGroup
        if (ag != null) {
            val aurl = findAudio(text, url, ag)
            if (aurl != null && aurl != variant.url) {
                audio = parseMedia(fetchText(ctx, aurl), aurl)
            }
        }
        return Plan(video, audio)
    }

    private class Variant(val url: String, val audioGroup: String?)

    private fun attrs(s: String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        val re = Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)")
        for (r in re.findAll(s)) {
            m[r.groupValues[1]] = r.groupValues[2].trim().removeSurrounding("\"")
        }
        return m
    }

    private fun resolve(base: String, ref: String): String {
        val r = ref.trim()
        val out = base.toHttpUrlOrNull()?.resolve(r)?.toString()
            ?: throw IOException("잘못된 주소: $r")
        // 보안 연결(https) 목록이 비보안(http) 조각을 가리키면 따라가지 않는다 (일반 다운로드와 같은 기준)
        if (base.startsWith("https://") && out.startsWith("http://")) {
            throw IOException("보안 연결(https)에서 비보안(http)으로 이동해 차단했습니다")
        }
        return out
    }

    private fun pickVariant(text: String, base: String): Variant? {
        val lines = text.lines()
        class V(val url: String, val bw: Long, val hasRes: Boolean, val audio: String?)
        val all = ArrayList<V>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i].trim()
            if (l.startsWith("#EXT-X-STREAM-INF:")) {
                val a = attrs(l.substringAfter(':'))
                var j = i + 1
                while (j < lines.size && (lines[j].isBlank() || lines[j].startsWith("#"))) j++
                if (j < lines.size) {
                    val bw = a["BANDWIDTH"]?.toLongOrNull() ?: a["AVERAGE-BANDWIDTH"]?.toLongOrNull() ?: 0L
                    all.add(V(resolve(base, lines[j]), bw, a.containsKey("RESOLUTION"), a["AUDIO"]))
                    i = j
                }
            }
            i++
        }
        if (all.isEmpty()) return null
        // 화면 크기 정보가 있는(=영상이 있는) 것을 우선, 그중 가장 높은 대역폭
        val pool = all.filter { it.hasRes }.ifEmpty { all }
        val best = pool.maxByOrNull { it.bw } ?: return null
        return Variant(best.url, best.audio)
    }

    private fun findAudio(text: String, base: String, group: String): String? {
        var first: String? = null
        for (raw in text.lines()) {
            val l = raw.trim()
            if (!l.startsWith("#EXT-X-MEDIA:")) continue
            val a = attrs(l.substringAfter(':'))
            if (a["TYPE"] != "AUDIO" || a["GROUP-ID"] != group) continue
            val uri = a["URI"] ?: continue
            val u = resolve(base, uri)
            if (a["DEFAULT"] == "YES") return u
            if (first == null) first = u
        }
        return first
    }

    private fun parseHex(s: String): ByteArray? {
        val h = s.removePrefix("0x").removePrefix("0X")
        if (h.isEmpty() || h.length > 32) return null
        val p = h.padStart(32, '0')
        return ByteArray(16) { p.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    /** "길이@시작" → (시작, 길이). 시작이 없으면 직전 조각의 끝에서 이어진다. */
    private fun parseRange(s: String, prevEnd: Long): LongArray? {
        val len = s.substringBefore('@').trim().toLongOrNull() ?: return null
        val off: Long = if (s.contains('@')) {
            s.substringAfter('@').trim().toLongOrNull() ?: return null
        } else {
            prevEnd
        }
        return longArrayOf(off, len)
    }

    fun parseMedia(text: String, base: String): Stream {
        val segs = ArrayList<Seg>()
        var init: Init? = null
        var key: Key? = null
        var seq = 0L
        var pendingRange: LongArray? = null
        var prevEnd = 0L
        var prevUrl = ""
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#")) {
                when {
                    l.startsWith("#EXT-X-MEDIA-SEQUENCE:") ->
                        seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                    l.startsWith("#EXT-X-KEY:") -> {
                        val a = attrs(l.substringAfter(':'))
                        when (val method = a["METHOD"]?.uppercase() ?: "NONE") {
                            "NONE" -> key = null
                            "AES-128" -> {
                                val u = a["URI"] ?: throw IOException("암호화 키 주소가 없어요")
                                key = Key(resolve(base, u), a["IV"]?.let { parseHex(it) })
                            }
                            else -> throw IOException("암호화($method)된 영상은 저장할 수 없어요")
                        }
                    }
                    l.startsWith("#EXT-X-MAP:") -> {
                        val a = attrs(l.substringAfter(':'))
                        val u = a["URI"]
                        if (u != null) {
                            val r = a["BYTERANGE"]?.let { parseRange(it, 0L) }
                            init = Init(resolve(base, u), r?.get(0) ?: 0L, r?.get(1) ?: -1L)
                        }
                    }
                    l.startsWith("#EXT-X-BYTERANGE:") ->
                        pendingRange = l.substringAfter(':').trim().let { parseRange(it, -1L) }
                }
                continue
            }
            // 조각 주소
            val url = resolve(base, l)
            var rs = -1L
            var rl = -1L
            val pr = pendingRange
            if (pr != null) {
                rs = if (pr[0] >= 0) pr[0] else if (url == prevUrl) prevEnd else 0L
                rl = pr[1]
                prevEnd = rs + rl
            }
            pendingRange = null
            prevUrl = url
            segs.add(Seg(url, rs, rl, key, seq))
            seq++
        }
        if (segs.isEmpty()) throw IOException("영상 조각을 찾지 못했어요")
        return Stream(segs, init)
    }

    // ───────────────────────── 받기 ─────────────────────────

    private fun buildRequest(ctx: Ctx, url: String, rangeStart: Long, rangeLen: Long): Request {
        val b = Request.Builder().url(url)
        ctx.userAgent?.takeIf { it.isNotBlank() }?.let { b.header("User-Agent", it) }
        ctx.referer?.takeIf { it.isNotBlank() }?.let { b.header("Referer", it) }
        ctx.cookieFor(url)?.takeIf { it.isNotBlank() }?.let { b.header("Cookie", it) }
        if (rangeStart >= 0 && rangeLen > 0) b.header("Range", "bytes=$rangeStart-${rangeStart + rangeLen - 1}")
        return b.build()
    }

    private fun fetchBytes(ctx: Ctx, url: String, rangeStart: Long = -1L, rangeLen: Long = -1L): ByteArray {
        var last: IOException? = null
        for (attempt in 0 until 4) {
            if (ctx.cancelled()) throw IOException("cancelled")
            val call = ctx.client.newCall(buildRequest(ctx, url, rangeStart, rangeLen))
            ctx.calls.add(call)
            try {
                call.execute().use { r ->
                    if (!r.isSuccessful) throw HttpErr(r.code)
                    return r.body?.bytes() ?: throw IOException("빈 응답")
                }
            } catch (e: IOException) {
                if (ctx.cancelled()) throw IOException("cancelled")
                last = e
                // 주소가 틀렸거나 권한이 없으면 다시 해도 소용없다
                if (e is HttpErr && e.code in 400..499 && e.code != 408 && e.code != 429) throw e
                try {
                    Thread.sleep(400L * (attempt + 1))
                } catch (ie: InterruptedException) {
                    throw IOException("cancelled")
                }
            } finally {
                ctx.calls.remove(call)
            }
        }
        throw last ?: IOException("받기 실패")
    }

    private fun fetchText(ctx: Ctx, url: String): String =
        String(fetchBytes(ctx, url), Charsets.UTF_8).removePrefix("﻿")

    private fun keyBytes(ctx: Ctx, k: Key): ByteArray {
        ctx.keyCache[k.uri]?.let { return it }
        val b = fetchBytes(ctx, k.uri)
        if (b.size != 16) throw IOException("암호화 키 형식이 맞지 않아요")
        ctx.keyCache[k.uri] = b
        return b
    }

    private fun seqIv(seq: Long): ByteArray {
        val iv = ByteArray(16)
        for (i in 0 until 8) iv[15 - i] = ((seq ushr (8 * i)) and 0xff).toByte()
        return iv
    }

    private fun decrypt(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val spec = SecretKeySpec(key, "AES")
        val ivs = IvParameterSpec(iv)
        return try {
            Cipher.getInstance("AES/CBC/PKCS5Padding").run {
                init(Cipher.DECRYPT_MODE, spec, ivs)
                doFinal(data)
            }
        } catch (e: javax.crypto.BadPaddingException) {
            // 끝 패딩이 없는 스트림
            Cipher.getInstance("AES/CBC/NoPadding").run {
                init(Cipher.DECRYPT_MODE, spec, ivs)
                doFinal(data, 0, data.size - data.size % 16)
            }
        }
    }

    private fun fetchSegment(ctx: Ctx, s: Seg): ByteArray {
        val raw = fetchBytes(ctx, s.url, s.rangeStart, s.rangeLen)
        ctx.onBytes(raw.size.toLong())
        val k = s.key ?: return raw
        return decrypt(raw, keyBytes(ctx, k), k.iv ?: seqIv(s.seq))
    }

    /** 한 줄기(영상 또는 소리)를 순서대로 이어서 out 에 쓴다. 조각은 여러 개를 동시에 받는다. */
    fun download(ctx: Ctx, stream: Stream, out: OutputStream) {
        val pool = Executors.newFixedThreadPool(minOf(PARALLEL, stream.segs.size).coerceAtLeast(1))
        try {
            stream.init?.let {
                val b = fetchBytes(ctx, it.url, it.rangeStart, it.rangeLen)
                ctx.onBytes(b.size.toLong())
                out.write(b)
            }
            val pending = java.util.ArrayDeque<Future<ByteArray>>()
            var next = 0
            while (next < stream.segs.size && pending.size < PARALLEL * 2) {
                val seg = stream.segs[next++]
                pending.add(pool.submit(Callable { fetchSegment(ctx, seg) }))
            }
            while (pending.isNotEmpty()) {
                val f = pending.removeFirst()
                val bytes = try {
                    f.get()
                } catch (e: ExecutionException) {
                    throw (e.cause as? IOException) ?: IOException(e.cause?.message ?: "받기 실패")
                }
                out.write(bytes)
                ctx.onSegment()
                if (next < stream.segs.size) {
                    val seg = stream.segs[next++]
                    pending.add(pool.submit(Callable { fetchSegment(ctx, seg) }))
                }
            }
        } finally {
            pool.shutdownNow()
        }
    }
}
