package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.widget.LinearLayout

/** 상/하단바. 블러(유리) 효과는 없애고 평범한 LinearLayout 으로 동작한다. */
class BlurBarLayout @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : LinearLayout(ctx, attrs)
