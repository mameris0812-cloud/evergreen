package com.example.evergreen

import android.view.Choreographer

/**
 * 프레임이 길게 밀려도(메뉴·새 탭 화면을 만드느라 메인 스레드가 잠깐 막혀도) 건너뛰지 않고 이어서 움직이는 애니메이션.
 *
 * 보통의 애니메이터는 '실제 흐른 시간'만큼 한 번에 나아가서, 프레임이 0.2초 밀리면 그만큼을 훌쩍 뛰어넘어
 * 아이콘이 뚝 끊기며 튄다. 여기서는 한 프레임에 나아갈 수 있는 시간을 [MAX_STEP_MS] 로 제한해서,
 * 밀린 프레임 뒤에도 멈췄던 자리에서 그대로 이어 움직인다 (잠깐 멈출 수는 있어도 튀지는 않는다).
 */
internal object SmoothAnim {
    /** 한 프레임에 나아갈 수 있는 최대 시간(ms). 60Hz 한 프레임(16.7ms) 보다 조금 넉넉하게 */
    const val MAX_STEP_MS = 25f

    /** 프레임 사이 간격(ns)을 [MAX_STEP_MS] 로 제한해 ms 로 돌려준다 */
    fun step(lastNanos: Long, nowNanos: Long): Float =
        if (lastNanos == 0L) 0f else minOf((nowNanos - lastNanos) / 1_000_000f, MAX_STEP_MS)
}

/**
 * 0 → 1 로 일정하게 흐르는 시계 (ValueAnimator + LinearInterpolator 대신).
 * 취소하면 onEnd 를 부르지 않는다. 쓰는 쪽에서 취소 뒤 상태를 직접 정리한다.
 */
internal class SmoothClock(
    private val durationMs: Long,
    private val onFrame: (Float) -> Unit,
    private val onEnd: () -> Unit
) {
    var isRunning = false
        private set
    private var elapsedMs = 0f
    private var lastNanos = 0L

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isRunning) return
            elapsedMs += SmoothAnim.step(lastNanos, frameTimeNanos)
            lastNanos = frameTimeNanos
            val t = (elapsedMs / durationMs).coerceIn(0f, 1f)
            onFrame(t)
            if (t >= 1f) {
                isRunning = false
                onEnd()
            } else {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    fun start(): SmoothClock {
        isRunning = true
        elapsedMs = 0f
        lastNanos = 0L
        Choreographer.getInstance().postFrameCallback(callback)
        return this
    }

    fun cancel() {
        if (!isRunning) return
        isRunning = false
        Choreographer.getInstance().removeFrameCallback(callback)
    }
}

/**
 * 스프링(Motion.springValue 와 같은 물리: 질량 1, 강성 stiffness, 감쇠비 damping)이되
 * 프레임이 밀려도 건너뛰지 않는다. 한 프레임에 [SmoothAnim.MAX_STEP_MS] 까지만 나아가고,
 * 그 시간은 4ms 이하로 쪼개서 적분하므로 정확도는 그대로다.
 * 취소하면 onEnd 를 부르지 않는다 (SpringAnimation 과 같다).
 */
internal class SmoothSpring(
    private var value: Float,
    private val target: Float,
    private val stiffness: Float,
    private val damping: Float,
    private var velocity: Float,
    private val onUpdate: (Float) -> Unit,
    private val onEnd: (() -> Unit)?
) {
    var isRunning = false
        private set
    private var lastNanos = 0L
    private val omega = Math.sqrt(stiffness.toDouble()).toFloat()

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isRunning) return
            val dtMs = SmoothAnim.step(lastNanos, frameTimeNanos)
            lastNanos = frameTimeNanos
            if (dtMs > 0f) integrate(dtMs / 1000f)
            // SpringAnimation 과 같은 멈춤 기준 (거리 1/500, 속도 그 62.5배)
            val done = Math.abs(velocity) < 0.125f && Math.abs(value - target) < 0.002f
            if (done) {
                isRunning = false
                value = target
                velocity = 0f
                onUpdate(target)
                onEnd?.invoke()
            } else {
                onUpdate(value)
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    private fun integrate(seconds: Float) {
        var left = seconds
        val c = 2f * damping * omega
        while (left > 0f) {
            val h = minOf(left, 0.004f)
            val a = -stiffness * (value - target) - c * velocity
            velocity += a * h
            value += velocity * h
            left -= h
        }
    }

    fun start(): SmoothSpring {
        isRunning = true
        lastNanos = 0L
        Choreographer.getInstance().postFrameCallback(callback)
        return this
    }

    fun cancel() {
        if (!isRunning) return
        isRunning = false
        Choreographer.getInstance().removeFrameCallback(callback)
    }

    companion object {
        /** Motion.springValue 와 같은 모양으로 부른다 */
        fun run(
            from: Float,
            to: Float,
            stiffness: Float,
            damping: Float,
            velocity: Float = 0f,
            onUpdate: (Float) -> Unit,
            onEnd: (() -> Unit)? = null
        ): SmoothSpring = SmoothSpring(from, to, stiffness, damping, velocity, onUpdate, onEnd).start()
    }
}
