package com.example.evergreen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * AI 답을 받아 오는 동안만 떠 있는 포그라운드 서비스.
 * 앱이 화면 밖으로 나가거나 화면이 꺼져도 시스템이 앱·네트워크를 멈추지 못하게 붙들어 둔다.
 * 답이 끝나면 AssistantUi 가 바로 내린다. (화면이 꺼진 채 무한정 붙들지 않도록 10분 뒤에는 스스로 내려간다)
 */
class AiKeepAliveService : Service() {

    companion object {
        private const val CH = "ai_keepalive"
        private const val CH_HIDDEN = "ai_keepalive_hidden"
        private const val ID = 4301
        private const val MAX_MS = 10 * 60 * 1000L

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, AiKeepAliveService::class.java))
            } catch (e: Exception) {
                // 시작이 막혀도 답 받기 자체는 그대로 진행한다 (앞에 떠 있을 땐 문제 없다)
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, AiKeepAliveService::class.java))
            } catch (e: Exception) {
                // 이미 내려간 상태
            }
        }
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            // 소리·팝업 없는 최소 중요도 채널
            nm.createNotificationChannel(NotificationChannel(CH, "AI 답변 받는 중", NotificationManager.IMPORTANCE_MIN))
            nm.createNotificationChannel(NotificationChannel(CH_HIDDEN, "AI 답변 받는 중 (표시 안 함)", NotificationManager.IMPORTANCE_NONE))
        }
        // (주의: apply 안의 flags 는 onStartCommand 의 매개변수 flags 와 이름이 겹치니 addFlags 를 쓴다)
        val launch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val open = launch?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val n: Notification = NotificationCompat.Builder(this, if (Prefs(this).notifyAiKeepAlive) CH else CH_HIDDEN)
            .setSmallIcon(R.drawable.ic_notif_evergreen)
            .setContentTitle("AI 답변을 받는 중이에요")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .build()
        try {
            ServiceCompat.startForeground(
                this, ID, n,
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "evergreen:ai").apply {
                setReferenceCounted(false)
                try { acquire(MAX_MS) } catch (e: Exception) { /* 무시 */ }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // 무시
        }
        wake = null
        super.onDestroy()
    }
}
