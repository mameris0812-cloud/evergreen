package com.example.evergreen

import android.content.Context
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageButton

/**
 * 아이콘을 앱이 직접 그린 모양 변하는 그림(MorphIconDrawable)으로 쓰는 버튼.
 *
 * 내장 플레이어의 재생/일시정지 버튼은 media3 가 상태가 바뀔 때마다 자기 아이콘(setImageDrawable)으로 갈아 끼워서,
 * 앱이 끼워 둔 모양이 풀리고 두 아이콘이 번갈아 깜박였다. 모양을 끼운 뒤 lock 을 켜 두면 media3 가 넣는 그림은 무시하고
 * MorphIconDrawable 만 받는다 (재생 ↔ 일시정지는 앱이 모양을 변하게 해서 보여 준다).
 */
class LockableImageButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.appcompat.R.attr.imageButtonStyle
) : AppCompatImageButton(context, attrs, defStyleAttr) {

    /** true 면 MorphIconDrawable 이 아닌 그림·이미지 지정은 무시한다 */
    var locked = false

    override fun setImageDrawable(drawable: Drawable?) {
        if (locked && drawable !is MorphIconDrawable) return
        super.setImageDrawable(drawable)
    }

    override fun setImageResource(resId: Int) {
        if (locked) return
        super.setImageResource(resId)
    }

    override fun setImageURI(uri: Uri?) {
        if (locked) return
        super.setImageURI(uri)
    }
}
