package com.example.evergreen

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class GeminiModel(val id: String, val label: String)

object GeminiModels {
    val all = listOf(
        GeminiModel("gemini-3.5-flash", "Gemini 3.5 Flash"),
        GeminiModel("gemini-3.8-flash", "Gemini 3.8 Flash")
    )

    fun byId(id: String): GeminiModel = all.firstOrNull { it.id == id } ?: all[0]
}

/** AI 에게 같이 보낼 사진 한 장. [base64] 는 JPEG 를 Base64 로 인코딩한 것, [label] 은 사진 설명(alt 등) */
class PageImage(val mime: String, val base64: String, val label: String)

data class ChatMsg(val role: String, var text: String, val images: List<PageImage> = emptyList())

/**
 * 지금 보고 있는 웹페이지의 내용 (AI 에게 참고 자료로 보낸다).
 * [images] 는 AI 에게 실제로 첨부한 사진, [imageTotal] 은 페이지에서 찾은 (의미 있는 크기의) 사진 수.
 */
data class PageSnapshot(
    val url: String,
    val title: String,
    val text: String,
    val selection: String,
    val images: List<PageImage> = emptyList(),
    val imageTotal: Int = 0
)

/** API 키를 기기 보안 저장소(Android Keystore)의 키로 암호화해서 저장한다. */
object KeyVault {
    private const val ALIAS = "evergreen_ai_key"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, secretKey())
            val iv = c.iv
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            "e:" + Base64.encodeToString(iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) {
            // 보안 저장소를 쓸 수 없는 기기: 앱 전용 저장소에 그대로 저장
            "p:$plain"
        }
    }

    fun decrypt(stored: String): String? {
        if (stored.startsWith("p:")) return stored.substring(2)
        if (!stored.startsWith("e:")) return null
        return try {
            val all = Base64.decode(stored.substring(2), Base64.NO_WRAP)
            val iv = all.copyOfRange(0, 12)
            val ct = all.copyOfRange(12, all.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}

/** Gemini API (generativelanguage.googleapis.com) 스트리밍 호출. 반드시 백그라운드 스레드에서 부른다. */
class GeminiClient {
    private companion object {
        const val MAX_OUTPUT_TOKENS = 65536
        const val MAX_CONTINUE = 4
    }

    @Volatile
    private var conn: HttpURLConnection? = null

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
        try {
            conn?.disconnect()
        } catch (e: Exception) {
            // 이미 끝난 연결
        }
    }

    fun stream(
        apiKey: String,
        model: String,
        system: String,
        history: List<ChatMsg>,
        onDelta: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
        json: Boolean = false
    ) {
        cancelled = false
        // 답이 토큰 한도로 잘리거나 연결이 중간에 끊기면, 받은 부분을 붙여서 "이어서 써 줘" 로 자동 재요청한다.
        val msgs = history.toMutableList()
        var total = 0
        var round = 0
        while (true) {
            val roundText = StringBuilder()
            val r = once(apiKey, model, system, msgs, json) { d ->
                roundText.append(d)
                total += d.length
                onDelta(d)
            }
            if (cancelled) { onDone(); return }
            when {
                r.error != null && r.fatal -> { onError(r.error); return }
                // 정상 종료
                r.error == null && r.finish != "MAX_TOKENS" -> {
                    if (total == 0) {
                        onError(
                            when {
                                r.blocked.isNotEmpty() -> "요청이 안전 정책에 의해 차단되었어요 (${r.blocked})"
                                r.finish.isNotEmpty() -> "응답이 비어 있어요 (${r.finish})"
                                else -> "응답이 비어 있어요"
                            }
                        )
                    } else onDone()
                    return
                }
            }
            // 여기까지 오면: 토큰 한도로 잘렸거나(MAX_TOKENS) 중간에 연결이 끊긴 경우
            round++
            if (roundText.isEmpty() || round > MAX_CONTINUE) {
                if (total > 0 && r.error == null) onDone()
                else onError(r.error ?: "응답이 중간에 끊겼어요")
                return
            }
            msgs.add(ChatMsg("model", roundText.toString()))
            msgs.add(ChatMsg("user", "끊긴 바로 그 지점부터 이어서 계속 써 줘. 앞에 쓴 내용은 반복하지 말고, 인사말이나 설명 없이 본문만 이어 써."))
        }
    }

    private class Round(
        val finish: String,
        val blocked: String,
        val error: String?,
        val fatal: Boolean
    )

    /** 요청 한 번. 받은 글자는 [onText] 로 흘려 보낸다. */
    private fun once(
        apiKey: String,
        model: String,
        system: String,
        history: List<ChatMsg>,
        json: Boolean,
        onText: (String) -> Unit
    ): Round {
        var c: HttpURLConnection? = null
        var got = false
        var blocked = ""
        var finish = ""
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            c = url.openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 300000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)

            val contents = JSONArray()
            for (m in history) {
                val parts = JSONArray()
                // 사진은 글보다 앞에 둔다 (Gemini 권장 순서)
                for (img in m.images) {
                    parts.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject().put("mimeType", img.mime).put("data", img.base64)
                        )
                    )
                }
                parts.put(JSONObject().put("text", m.text))
                contents.put(JSONObject().put("role", m.role).put("parts", parts))
            }
            val body = JSONObject().put("contents", contents)
            val gen = JSONObject().put("maxOutputTokens", MAX_OUTPUT_TOKENS)
            if (json) gen.put("responseMimeType", "application/json")
            body.put("generationConfig", gen)
            if (system.isNotBlank()) {
                body.put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
            }
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = try {
                    c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
                return Round("", "", describeError(code, err), true)
            }

            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.substring(5).trim()
                    if (data.isEmpty() || data == "[DONE]") continue
                    val o = JSONObject(data)
                    val br = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                    if (br.isNotEmpty()) blocked = br
                    val cand = o.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                    val fr = cand.optString("finishReason")
                    if (fr.isNotEmpty()) finish = fr
                    val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until parts.length()) {
                        val p = parts.optJSONObject(i) ?: continue
                        if (p.optBoolean("thought", false)) continue
                        val t = p.optString("text", "")
                        if (t.isNotEmpty()) {
                            got = true
                            onText(t)
                        }
                    }
                }
            }
            // finishReason 없이 스트림이 끝났다면 중간에 끊긴 것으로 본다
            if (got && finish.isEmpty() && !cancelled) {
                return Round("", blocked, "응답이 중간에 끊겼어요", false)
            }
            return Round(finish, blocked, null, false)
        } catch (e: Exception) {
            val msg = "네트워크 오류: ${e.message ?: e.javaClass.simpleName}"
            // 글자를 하나라도 받은 뒤의 오류는 이어받기를 시도하고, 처음부터 실패한 건 바로 오류로 알린다
            return Round(finish, blocked, msg, !got)
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
                // 무시
            }
            conn = null
        }
    }

    private fun describeError(code: Int, body: String?): String {
        val msg = try {
            JSONObject(body ?: "").optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        val head = when (code) {
            400 -> "요청이 올바르지 않거나 API 키가 잘못되었어요"
            401, 403 -> "API 키가 거부되었어요. 키와 사용 권한을 확인해 주세요"
            404 -> "모델을 찾을 수 없어요"
            429 -> "요청 한도를 넘었어요. 잠시 후 다시 시도해 주세요"
            in 500..599 -> "Gemini 서버에 문제가 있어요. 잠시 후 다시 시도해 주세요"
            else -> "오류가 났어요 ($code)"
        }
        return if (msg.isNullOrBlank()) head else "$head\n$msg"
    }
}
