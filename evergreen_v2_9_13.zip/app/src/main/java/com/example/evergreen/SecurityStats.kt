package com.example.evergreen

import android.content.Context
import android.content.SharedPreferences
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * 보안 현황용 차단 기록: 종류별로 하루 단위 건수를 최근 7일치 모아 둔다.
 * 어느 스레드에서 불러도 안전하고, 일정 건수마다 / 앱을 나갈 때 저장한다.
 */
object SecurityStats {
    const val AD = 0          // 광고·추적 요청
    const val POPUP = 1       // 광고 팝업·광고 페이지 이동
    const val TRACKER = 2     // 트래커 (엄격 모드)
    const val HIJACK = 3      // 클릭 가로채기 이동
    const val AUTO_DL = 4     // 자동 다운로드
    const val BACK = 5        // 뒤로가기 중 자동 이동
    const val MALWARE = 6     // 악성 사이트
    const val HTTPS = 7       // http → https 로 올려 연결
    const val KINDS = 8
    /** 보안 현황에 들어가는 첫 종류 (AD·POPUP 은 광고 차단 현황 몫이라 보안 합계에서 뺀다) */
    const val FIRST_SECURITY = TRACKER

    private const val DAYS = 7

    private var sp: SharedPreferences? = null
    private val counts = ConcurrentHashMap<String, AtomicInteger>()
    private val pending = AtomicInteger(0)

    /** 기록이 바뀔 때마다 알림을 받는 곳 (새 탭 위젯 등). 어느 스레드에서든 불릴 수 있다 */
    private val listeners = java.util.concurrent.CopyOnWriteArraySet<Runnable>()
    fun addListener(l: Runnable) { listeners.add(l) }
    fun removeListener(l: Runnable) { listeners.remove(l) }
    private fun notifyChanged() { for (l in listeners) l.run() }

    fun dayKey(): Long {
        val now = System.currentTimeMillis()
        return (now + java.util.TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    private fun key(day: Long, kind: Int) = "d${day}_$kind"

    @Synchronized
    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("security_stats", Context.MODE_PRIVATE)
        sp = p
        val oldest = dayKey() - (DAYS - 1)
        val ed = p.edit()
        for ((k, v) in p.all) {
            val day = k.removePrefix("d").substringBefore('_').toLongOrNull()
            if (day == null || day < oldest) { ed.remove(k); continue }
            (v as? Int)?.let { counts[k] = AtomicInteger(it) }
        }
        ed.apply()
    }

    fun add(kind: Int) {
        if (sp == null) return
        counts.getOrPut(key(dayKey(), kind)) { AtomicInteger(0) }.incrementAndGet()
        if (pending.incrementAndGet() >= 30) flush()
        notifyChanged()
    }

    fun flush() {
        val p = sp ?: return
        pending.set(0)
        val oldest = dayKey() - (DAYS - 1)
        val ed = p.edit()
        for ((k, v) in counts) {
            val day = k.removePrefix("d").substringBefore('_').toLongOrNull() ?: continue
            if (day < oldest) { counts.remove(k); ed.remove(k) } else ed.putInt(k, v.get())
        }
        ed.apply()
    }

    fun count(day: Long, kind: Int): Int = counts[key(day, kind)]?.get() ?: 0

    fun dayTotal(day: Long): Int = (FIRST_SECURITY until KINDS).sumOf { count(day, it) }

    /** 오늘을 마지막으로 하는 최근 7일의 하루 합계 (오래된 날 → 오늘) */
    fun week(): IntArray {
        val today = dayKey()
        return IntArray(DAYS) { dayTotal(today - (DAYS - 1 - it)) }
    }

    /** 지정한 종류만 합친, 오늘을 마지막으로 하는 최근 7일 (오래된 날 → 오늘) */
    fun week(vararg kinds: Int): IntArray {
        val today = dayKey()
        return IntArray(DAYS) { i -> kinds.sumOf { count(today - (DAYS - 1 - i), it) } }
    }

    /** 지정한 종류의 기록만 지운다 */
    fun reset(vararg kinds: Int) {
        val p = sp
        val ed = p?.edit()
        for (k in counts.keys.toList()) {
            val kind = k.substringAfter('_').toIntOrNull() ?: continue
            if (kind in kinds) { counts.remove(k); ed?.remove(k) }
        }
        ed?.apply()
        notifyChanged()
    }

    fun today(kind: Int): Int = count(dayKey(), kind)

    fun todayTotal(): Int = dayTotal(dayKey())

    fun weekTotal(kind: Int): Int {
        val today = dayKey()
        return (0 until DAYS).sumOf { count(today - it, kind) }
    }

    /** 보안 기록만 지운다 (광고 차단 기록은 그대로) */
    fun reset() = reset(*IntArray(KINDS - FIRST_SECURITY) { FIRST_SECURITY + it })
}
