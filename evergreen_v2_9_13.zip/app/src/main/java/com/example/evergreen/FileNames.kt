package com.example.evergreen

import android.webkit.MimeTypeMap
import android.webkit.URLUtil

/**
 * 다운로드 파일 이름 / MIME 정하기.
 *
 * URLUtil.guessFileName 은 서버가 종류를 알 수 없는 "application/octet-stream" 으로 보내면
 * 주소나 헤더에 적힌 올바른 확장자(.apk, .zip …)를 버리고 ".bin" 으로 바꿔 버린다.
 * 그래서 '그냥 바이너리'라는 뜻의 일반적인 MIME 은 없는 것으로 보고 이름을 정한다.
 */
object FileNames {

    private val GENERIC = setOf(
        "application/octet-stream", "binary/octet-stream", "application/x-binary",
        "application/force-download", "application/x-force-download",
        "application/download", "application/x-download", "application/unknown"
    )

    fun isGeneric(mime: String?): Boolean =
        mime.isNullOrBlank() || mime.substringBefore(';').trim().lowercase() in GENERIC

    fun guess(url: String?, contentDisposition: String?, mime: String?): String {
        // 1) 서버가 알려 준 파일 이름을 그대로 쓴다 (filename*=UTF-8''… 와 한글 이름 포함)
        fromDisposition(contentDisposition)?.let { return it }
        // 2) S3 같은 곳의 주소에 들어 있는 response-content-disposition / filename 값
        fromQuery(url)?.let { return it }
        // 3) 주소 끝 글자 → 그래도 없으면 MIME 으로 확장자만 붙인다
        return URLUtil.guessFileName(url, null, if (isGeneric(mime)) null else mime)
    }

    private val RE_STAR = Regex("""filename\*\s*=\s*([^'";]*)'[^'";]*'([^;]+)""", RegexOption.IGNORE_CASE)
    private val RE_QUOTED = Regex("""filename\s*=\s*"((?:[^"\\]|\\.)*)"""", RegexOption.IGNORE_CASE)
    private val RE_PLAIN = Regex("""filename\s*=\s*([^;"]+)""", RegexOption.IGNORE_CASE)

    /** Content-Disposition 에서 파일 이름을 꺼낸다. URLUtil 은 filename*= (RFC 5987) 을 못 읽어서 'download' 로 저장되곤 했다 */
    fun fromDisposition(cd: String?): String? {
        if (cd.isNullOrBlank()) return null
        val star = RE_STAR.find(cd)
        var raw: String? = null
        if (star != null) {
            raw = percentDecode(star.groupValues[2].trim().trim('"'), star.groupValues[1].trim())
        }
        if (raw.isNullOrBlank()) {
            raw = RE_QUOTED.find(cd)?.groupValues?.get(1)?.replace(Regex("""\\(.)"""), "$1")
                ?: RE_PLAIN.find(cd)?.groupValues?.get(1)?.trim()
            if (raw != null) {
                if (Regex("%[0-9a-fA-F]{2}").containsMatchIn(raw)) raw = percentDecode(raw, "UTF-8")
                raw = fixMojibake(raw)
            }
        }
        return clean(raw)
    }

    private fun fromQuery(url: String?): String? {
        if (url.isNullOrBlank()) return null
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull() ?: return null
        if (uri.isOpaque) return null
        // 주소 끝 글자에 이미 확장자가 있으면 그것을 쓴다
        val last = uri.lastPathSegment.orEmpty()
        if (Regex(""".+\.[A-Za-z0-9]{1,6}""").matches(last)) return null
        uri.getQueryParameter("response-content-disposition")?.let { fromDisposition(it)?.let { n -> return n } }
        for (k in arrayOf("filename", "file_name", "fileName", "fname", "fn", "name", "file", "attachment")) {
            val v = uri.getQueryParameter(k) ?: continue
            val c = clean(v) ?: continue
            if (Regex(""".+\.[A-Za-z0-9]{1,6}""").matches(c)) return c
        }
        return null
    }

    private fun percentDecode(s: String, charset: String): String {
        val cs = runCatching { java.nio.charset.Charset.forName(charset.ifBlank { "UTF-8" }) }.getOrDefault(Charsets.UTF_8)
        val out = java.io.ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '%' && i + 2 < s.length) {
                val h = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (h != null) { out.write(h); i += 3; continue }
            }
            out.write(c.toString().toByteArray(Charsets.UTF_8))
            i++
        }
        return String(out.toByteArray(), cs)
    }

    /** 헤더의 UTF-8 글자가 ISO-8859-1 로 잘못 읽혀 깨진 경우(한글이 이상한 글자로 보이는 경우)를 되돌린다 */
    private fun fixMojibake(s: String): String {
        if (s.all { it.code < 0x80 } || s.any { it.code > 0xFF }) return s
        val fixed = String(s.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
        return if (fixed.contains('\uFFFD')) s else fixed
    }

    private fun clean(raw: String?): String? {
        var n = raw?.trim()?.trim('"') ?: return null
        n = n.substringAfterLast('/').substringAfterLast('\\')
        n = n.replace(Regex("[\\u0000-\\u001f:*?\"<>|]"), "_").trim().trimEnd('.')
        return n.ifBlank { null }
    }

    /** 서버가 준 MIME 이 일반적이면, 파일 이름의 확장자로 알맞은 MIME 을 찾는다 (예: .apk → android 패키지) */
    fun mimeFor(fileName: String, mime: String?): String? {
        if (!isGeneric(mime)) return mime
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: mime
    }
}
