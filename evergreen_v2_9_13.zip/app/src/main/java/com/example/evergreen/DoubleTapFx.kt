package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.hypot

/**
 * 플레이어 위에 얹는 더블탭 효과 (터치는 받지 않고 그리기만 한다).
 * - 왼쪽/오른쪽 더블탭: 그 쪽 화면이 곡선 모양으로 밝아지고, 탭한 자리에서 물결이 번지며, 화살표가 차례로 흐르고 누적 초가 톡 튄다
 * - 가운데 더블탭: 재생/일시정지 아이콘이 동그라미 안에서 톡 커졌다가 사라진다
 */
class DoubleTapFx(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val chev = Paint(Paint.ANTI_ALIAS_FLAG).apply { pathEffect = CornerPathEffect(2.5f * d) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = 15f * resources.displayMetrics.scaledDensity
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        setShadowLayer(3f * d, 0f, 0f, 0x99000000.toInt())
    }
    private val region = Path()
    private val tri = Path()
    private val rect = RectF()

    // ── 좌우 건너뛰기 ──
    private var side = 0 // -1 왼쪽, 1 오른쪽, 0 없음
    private var secs = 0
    private var tapX = 0f
    private var tapY = 0f
    private var bg = 0f
    private var ripple = 1f
    private var chevT = 0f
    private var pulse = 1f
    private var bgAnim: ValueAnimator? = null
    private var rippleAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null
    private var chevAnim: ValueAnimator? = null
    private val hideRun = Runnable { fadeSide() }

    // ── 가운데 재생/일시정지 ──
    private var cPlay = false
    private var cT = 1f
    private var cAnim: ValueAnimator? = null

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    /** 왼쪽(-1)/오른쪽(1) 더블탭. total: 연달아 누적된 초, x·y: 탭한 자리 */
    fun skip(left: Boolean, total: Int, x: Float, y: Float) {
        val s = if (left) -1 else 1
        val fresh = side != s || bg <= 0.02f
        side = s
        secs = total
        tapX = x
        tapY = y
        removeCallbacks(hideRun)
        if (fresh) {
            bgAnim?.cancel()
            bgAnim = ValueAnimator.ofFloat(bg, 1f).apply {
                duration = 130
                interpolator = DecelerateInterpolator()
                addUpdateListener { bg = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        rippleAnim?.cancel()
        rippleAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 480
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { ripple = it.animatedValue as Float; invalidate() }
            start()
        }
        pulseAnim?.cancel()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 260
            addUpdateListener {
                val t = it.animatedValue as Float
                // 살짝 커졌다가 제자리로
                pulse = 1f + 0.22f * kotlin.math.sin(Math.PI * t).toFloat()
                invalidate()
            }
            start()
        }
        if (chevAnim == null) {
            chevAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 720
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { chevT = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        postDelayed(hideRun, 700L)
    }

    private fun fadeSide() {
        bgAnim?.cancel()
        bgAnim = ValueAnimator.ofFloat(bg, 0f).apply {
            duration = 260
            addUpdateListener { bg = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (bg <= 0.02f) {
                        side = 0
                        chevAnim?.cancel()
                        chevAnim = null
                        invalidate()
                    }
                }
            })
            start()
        }
    }

    /** 가운데 더블탭: 바뀐 뒤의 상태(재생 중이 되면 true)에 맞는 아이콘을 보여 준다 */
    fun center(playing: Boolean) {
        cPlay = playing
        cAnim?.cancel()
        cAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            interpolator = LinearInterpolator()
            addUpdateListener { cT = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    cT = 1f
                    invalidate()
                }
            })
            start()
        }
    }

    fun clear() {
        removeCallbacks(hideRun)
        bgAnim?.cancel(); rippleAnim?.cancel(); pulseAnim?.cancel(); chevAnim?.cancel(); cAnim?.cancel()
        chevAnim = null
        side = 0; bg = 0f; cT = 1f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        clear()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (side != 0 && bg > 0.01f) drawSide(c, w, h)
        if (cT < 1f) drawCenter(c, w, h)
    }

    private fun drawSide(c: Canvas, w: Float, h: Float) {
        region.reset()
        if (side < 0) {
            region.moveTo(0f, 0f)
            region.lineTo(w * 0.40f, 0f)
            region.quadTo(w * 0.53f, h / 2f, w * 0.40f, h)
            region.lineTo(0f, h)
        } else {
            region.moveTo(w, 0f)
            region.lineTo(w * 0.60f, 0f)
            region.quadTo(w * 0.47f, h / 2f, w * 0.60f, h)
            region.lineTo(w, h)
        }
        region.close()
        c.save()
        c.clipPath(region)
        fill.style = Paint.Style.FILL
        fill.color = 0xFFFFFFFF.toInt()
        fill.alpha = (0x26 * bg).toInt()
        c.drawRect(0f, 0f, w, h, fill)
        // 탭한 자리에서 번지는 물결
        val maxR = hypot(w, h) * 0.55f
        fill.alpha = ((1f - ripple) * 0x3A * bg).toInt()
        c.drawCircle(tapX, tapY, maxR * ripple, fill)
        c.restore()

        val cx = if (side < 0) w * 0.20f else w * 0.80f
        val cy = h / 2f
        // 화살표 세 개가 가는 쪽으로 차례로 밝아진다
        val cw = 9f * d
        val ch = 15f * d
        val gap = 13f * d
        for (i in 0 until 3) {
            val order = if (side > 0) i else 2 - i
            val x0 = cx + (i - 1) * gap * 1.0f - (if (side > 0) cw / 2f else -cw / 2f)
            var v = (chevT - order * 0.18f) % 1f
            if (v < 0f) v += 1f
            val a = 0.28f + 0.72f * (1f - abs(v * 2f - 1f))
            chev.style = Paint.Style.FILL
            chev.color = 0xFFFFFFFF.toInt()
            chev.alpha = (255 * a * bg).toInt()
            tri.reset()
            val dx = if (side > 0) cw else -cw
            tri.moveTo(x0, cy - 18f * d - ch / 2f)
            tri.lineTo(x0 + dx, cy - 18f * d)
            tri.lineTo(x0, cy - 18f * d + ch / 2f)
            tri.close()
            c.drawPath(tri, chev)
        }
        c.save()
        c.scale(pulse, pulse, cx, cy + 14f * d)
        text.alpha = (255 * bg).toInt()
        c.drawText("${secs}초", cx, cy + 20f * d, text)
        c.restore()
    }

    private fun drawCenter(c: Canvas, w: Float, h: Float) {
        val t = cT
        val alpha: Float
        val scale: Float
        when {
            t < 0.28f -> {
                val k = t / 0.28f
                alpha = minOf(1f, k * 2f)
                scale = 0.55f + 0.57f * (1f - (1f - k) * (1f - k)) // 0.55 → 1.12
            }
            t < 0.42f -> {
                alpha = 1f
                scale = 1.12f - 0.12f * ((t - 0.28f) / 0.14f)
            }
            t < 0.66f -> {
                alpha = 1f
                scale = 1f
            }
            else -> {
                val k = (t - 0.66f) / 0.34f
                alpha = 1f - k
                scale = 1f + 0.28f * k
            }
        }
        val cx = w / 2f
        val cy = h / 2f
        val r = 34f * d * scale
        fill.style = Paint.Style.FILL
        fill.color = 0xFF000000.toInt()
        fill.alpha = (0xB8 * alpha).toInt()
        c.drawCircle(cx, cy, r, fill)
        fill.color = 0xFFFFFFFF.toInt()
        fill.alpha = (255 * alpha).toInt()
        val u = 13f * d * scale
        if (cPlay) {
            tri.reset()
            tri.moveTo(cx - u * 0.55f, cy - u)
            tri.lineTo(cx + u * 0.95f, cy)
            tri.lineTo(cx - u * 0.55f, cy + u)
            tri.close()
            chev.style = Paint.Style.FILL
            chev.color = 0xFFFFFFFF.toInt()
            chev.alpha = (255 * alpha).toInt()
            c.drawPath(tri, chev)
        } else {
            val bw = u * 0.62f
            rect.set(cx - u * 0.85f, cy - u, cx - u * 0.85f + bw, cy + u)
            c.drawRoundRect(rect, 2f * d, 2f * d, fill)
            rect.set(cx + u * 0.85f - bw, cy - u, cx + u * 0.85f, cy + u)
            c.drawRoundRect(rect, 2f * d, 2f * d, fill)
        }
    }
}
