package com.example.evergreen

import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.color.MaterialColors

/**
 * 확장 프로그램의 툴바 팝업(action.default_popup)을 새 탭이 아니라 앱 안 카드 팝업으로 띄운다 (크롬 방식).
 * 폭은 360dp 고정, 높이는 팝업 페이지 내용에 맞춰 늘고 줄며, 화면 높이의 80%를 넘으면 안에서 스크롤된다.
 */
object ExtensionPopup {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun viewport(ctx: Context): Pair<Int, Int> {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) {
                val root = c.window?.decorView
                if (root != null && root.width > 0 && root.height > 0) return root.width to root.height
                break
            }
            c = c.baseContext
        }
        val dm = ctx.resources.displayMetrics
        return dm.widthPixels to dm.heightPixels
    }

    /** @param onOpenTab 팝업 안 링크나 '탭에서 열기'로 주소를 새 탭에 열 때 */
    fun show(
        ctx: Context,
        mgr: ExtensionManager,
        e: ExtensionManager.Ext,
        onOpenTab: (String) -> Unit
    ): Dialog? {
        val page = mgr.popupOf(e) ?: return null
        val url = mgr.pageUrl(e, page)
        val onSurface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val surface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurface, Color.WHITE)
        val primary = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())

        val dialog = Dialog(ctx, R.style.Evergreen_Popup)
        Popup.trackDialog(dialog)
        val (vw, vh) = viewport(ctx)
        val width = minOf(dp(ctx, 360), (vw * 0.94f).toInt())
        val maxBody = (vh * 0.78f).toInt() - dp(ctx, 64)
        val minBody = dp(ctx, 120)

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(surface)
                cornerRadius = dp(ctx, 26).toFloat()
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }

        // 머리말: 아이콘 · 이름 · 탭에서 열기 · 닫기
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 8), dp(ctx, 6))
        }
        header.addView(ImageView(ctx).apply {
            val bmp = mgr.iconBitmap(e)
            if (bmp != null) setImageBitmap(bmp)
            else {
                setImageResource(R.drawable.ic_extension)
                imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 26), dp(ctx, 26)).apply { marginEnd = dp(ctx, 10) }
        })
        header.addView(TextView(ctx).apply {
            text = e.name
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(onSurface)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        fun iconBtn(res: Int, desc: String, click: () -> Unit) = ImageButton(ctx).apply {
            setImageResource(res)
            imageTintList = android.content.res.ColorStateList.valueOf(onVar)
            contentDescription = desc
            val tv = android.util.TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            val p = dp(ctx, 10)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 40), dp(ctx, 40))
            setOnClickListener { click() }
        }
        header.addView(iconBtn(R.drawable.ic_open_tab, "탭에서 열기") {
            dialog.dismiss()
            onOpenTab(url)
        })
        header.addView(iconBtn(R.drawable.ic_close, "닫기") { dialog.dismiss() })
        card.addView(header)

        // 위쪽 로딩 막대 (페이지가 다 불러와지면 사라진다)
        val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(primary)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 2))
        }
        card.addView(bar)

        val wv: WebView = mgr.newPopupView { link -> dialog.dismiss(); onOpenTab(link) }
        wv.setBackgroundColor(surface)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        val body = FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 200))
        }
        body.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(body)

        dialog.setContentView(card)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.apply {
            setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            // 글자를 입력할 때 키보드가 입력칸을 가리지 않게
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        // 내용 높이에 맞춰 팝업 높이를 늘이고 줄인다 (크롬의 팝업처럼)
        val ui = Handler(Looper.getMainLooper())
        var closed = false
        var curH = dp(ctx, 200)
        var anim: ValueAnimator? = null
        fun resizeTo(target: Int) {
            val t = target.coerceIn(minBody, maxOf(minBody, maxBody))
            if (kotlin.math.abs(t - curH) < dp(ctx, 6)) return
            anim?.cancel()
            anim = ValueAnimator.ofInt(curH, t).apply {
                duration = 180
                addUpdateListener {
                    curH = it.animatedValue as Int
                    body.layoutParams = body.layoutParams.apply { height = curH }
                    body.requestLayout()
                }
                start()
            }
        }
        // 팝업 내용이 360dp 보다 넓으면 (최대 화면 폭의 94% 까지) 카드를 넓힌다
        var curW = width
        val maxW = (vw * 0.94f).toInt()
        fun widenTo(target: Int) {
            val t = target.coerceAtMost(maxW)
            if (t <= curW + dp(ctx, 6)) return
            curW = t
            dialog.window?.setLayout(curW, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        lateinit var poll: Runnable
        poll = Runnable {
            if (closed) return@Runnable
            // 내용 높이: 문서가 보이는 영역보다 길면 그 길이, 아니면 안쪽 요소들의 맨 아래 (그래야 내용이 줄 때 같이 줄어든다)
            wv.evaluateJavascript(
                "(function(){var d=document.documentElement,b=document.body;if(!d||!b)return '0,0';" +
                    "var vh=window.innerHeight,h=d.scrollHeight;" +
                    "if(h<=vh+1){var m=0,k=b.children;for(var i=0;i<k.length;i++){var r=k[i].getBoundingClientRect();if(r.height>0&&r.bottom>m)m=r.bottom}" +
                    "var cs=getComputedStyle(b);h=m>0?Math.ceil(m+(parseFloat(cs.marginBottom)||0)+(parseFloat(cs.paddingBottom)||0)):b.scrollHeight}" +
                    "return Math.max(d.scrollWidth,b.scrollWidth)+','+h})()"
            ) { r ->
                val parts = r?.trim('"')?.split(',')
                val cssW = parts?.getOrNull(0)?.toDoubleOrNull() ?: 0.0
                val cssPx = parts?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
                val den = ctx.resources.displayMetrics.density
                if (!closed) {
                    if (cssW > 0) widenTo((cssW * den).toInt())
                    if (cssPx > 0) resizeTo((cssPx * den).toInt())
                }
            }
            ui.postDelayed(poll, 700)
        }
        // 새로 불러오기가 끝나면 로딩 막대를 걷는다
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView?, p: Int) {
                if (p >= 100) bar.visibility = View.GONE
            }

            // 팝업 안의 스크립트 오류를 진단 기록에 남긴다
            override fun onConsoleMessage(m: android.webkit.ConsoleMessage): Boolean {
                if (m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) {
                    mgr.diagLog(e.id, "팝업 콘솔: " + m.message().take(240) + " (" + m.sourceId().substringAfterLast('/').take(40) + ":" + m.lineNumber() + ")")
                }
                return true
            }

            override fun onCloseWindow(window: WebView?) { dialog.dismiss() }

            // 팝업 안에서 띄운 새 창(window.open)은 새 탭으로 연다
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                val t = view?.hitTestResult?.extra
                if (t != null && (t.startsWith("http://") || t.startsWith("https://"))) { dialog.dismiss(); onOpenTab(t); return false }
                return false
            }
        }
        mgr.popupClosers[e.id] = { dialog.dismiss() }
        dialog.setOnDismissListener {
            closed = true
            if (mgr.popupClosers[e.id] != null) mgr.popupClosers.remove(e.id)
            ui.removeCallbacksAndMessages(null)
            anim?.cancel()
            mgr.releasePopupView(wv)
        }
        card.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
        dialog.show()
        mgr.diagLog(e.id, "팝업 열기: $page")
        wv.loadUrl(url)
        ui.postDelayed(poll, 250)
        return dialog
    }
}
