package com.example.evergreen

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * 내장 플레이어가 영상 조각을 받아 올 때 쓰는 HTTP 클라이언트.
 * 앱 전체에서 하나를 공유해서, 같은 서버로 이어지는 요청이 연결(TCP/TLS)을 다시 맺지 않고 재사용한다.
 * HTTP/2 라서 HLS·DASH 조각을 한 연결로 동시에 받는다.
 */
object PlayerHttp {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true) // http ↔ https 로 넘어가는 주소도 따라간다
            .retryOnConnectionFailure(true)
            .build()
    }
}
