package com.example.evergreen

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.File
import java.io.FileDescriptor
import java.nio.ByteBuffer

/**
 * 이어 붙인 HLS 파일(TS / fMP4)과 따로 받은 소리 파일을 mp4 하나로 다시 묶는다. (코덱은 그대로, 다시 인코딩하지 않음)
 * 갤러리·다른 플레이어에서 바로 열리고 위치 이동이 되는 mp4 를 얻기 위한 단계로, 실패하면 호출한 쪽이 이어 붙인 원본을 그대로 저장한다.
 */
object Mp4Remux {

    private class Src(val ex: MediaExtractor, val map: HashMap<Int, Int>)

    /**
     * @param video 영상(과 소리가 들어 있을 수 있는) 파일
     * @param audio 따로 받은 소리 파일. 있으면 소리는 이 파일에서 가져온다.
     * @param out   결과를 쓸 파일 (MediaMuxer 는 읽기/쓰기 모드로 연 것이어야 한다)
     * @return 성공하면 true. 지원하지 않는 코덱이면 예외가 나므로 호출한 쪽에서 잡는다.
     */
    @RequiresApi(Build.VERSION_CODES.O)
    fun run(video: File, audio: File?, out: FileDescriptor, isCancelled: () -> Boolean): Boolean {
        val extractors = ArrayList<MediaExtractor>()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            val srcs = ArrayList<Src>()
            muxer = MediaMuxer(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // 영상 파일에서 영상 1개(+ 소리 파일이 따로 없으면 소리 1개)
            val vx = MediaExtractor().also { extractors.add(it) }
            vx.setDataSource(video.absolutePath)
            val vmap = HashMap<Int, Int>()
            var haveV = false
            var haveA = false
            for (i in 0 until vx.trackCount) {
                val f = vx.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && !haveV) {
                    vmap[i] = muxer.addTrack(f); haveV = true
                } else if (mime.startsWith("audio/") && !haveA && audio == null) {
                    vmap[i] = muxer.addTrack(f); haveA = true
                }
            }
            if (vmap.isNotEmpty()) srcs.add(Src(vx, vmap))

            if (audio != null) {
                val ax = MediaExtractor().also { extractors.add(it) }
                ax.setDataSource(audio.absolutePath)
                val amap = HashMap<Int, Int>()
                for (i in 0 until ax.trackCount) {
                    val f = ax.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/")) {
                        amap[i] = muxer.addTrack(f)
                        break
                    }
                }
                if (amap.isNotEmpty()) srcs.add(Src(ax, amap))
            }
            if (srcs.isEmpty()) return false

            for (s in srcs) for (t in s.map.keys) s.ex.selectTrack(t)

            // TS 는 첫 시각이 10초처럼 0 이 아닌 경우가 많아서, 가장 이른 시각을 0 으로 맞춘다
            var base = Long.MAX_VALUE
            for (s in srcs) {
                val t = s.ex.sampleTime
                if (t >= 0 && t < base) base = t
            }
            if (base == Long.MAX_VALUE) return false

            muxer.start()
            started = true

            val buf = ByteBuffer.allocate(4 shl 20)
            val info = MediaCodec.BufferInfo()
            var wrote = 0L
            while (true) {
                if (isCancelled()) throw java.io.IOException("cancelled")
                // 시각이 가장 이른 쪽부터 써서 영상과 소리가 번갈아 들어가게 한다
                var pick: Src? = null
                var pickT = Long.MAX_VALUE
                for (s in srcs) {
                    val t = s.ex.sampleTime
                    if (t >= 0 && t < pickT && s.map.containsKey(s.ex.sampleTrackIndex)) {
                        pick = s; pickT = t
                    }
                }
                val p = pick ?: break
                buf.clear()
                val size = p.ex.readSampleData(buf, 0)
                if (size < 0) {
                    p.ex.advance()
                    continue
                }
                val track = p.map[p.ex.sampleTrackIndex]!!
                info.set(
                    0, size, (pickT - base).coerceAtLeast(0L),
                    if (p.ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_SYNC_FRAME else 0
                )
                muxer.writeSampleData(track, buf, info)
                wrote++
                p.ex.advance()
            }
            return wrote > 0
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (e: Exception) {
                // 무시
            }
            try {
                muxer?.release()
            } catch (e: Exception) {
                // 무시
            }
            extractors.forEach {
                try {
                    it.release()
                } catch (e: Exception) {
                    // 무시
                }
            }
        }
    }
}
