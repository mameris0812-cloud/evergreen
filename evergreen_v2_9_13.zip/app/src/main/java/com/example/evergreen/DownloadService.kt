package com.example.evergreen

import android.app.DownloadManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/** 다운로드 화면에 보여줄, 지금 받는 중인 파일 정보 */
class ActiveDownload(
    val id: Int,
    val name: String,
    val downloaded: Long,
    val total: Long,
    val speedBps: Long
)

/**
 * 시스템 다운로드 관리자(DownloadManager)로 내려받기.
 * Android 9 이하일 때, 또는 빠른 다운로드가 실패했을 때 쓴다.
 * 성공하면 파일 이름을, 실패하면 null 을 돌려준다.
 */
object SystemDownload {
    fun enqueue(
        context: Context,
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?,
        referer: String?
    ): String? {
        return try {
            val fileName = FileNames.guess(url, contentDisposition, mimeType)
            val mime = FileNames.mimeFor(fileName, mimeType)?.takeIf { it.isNotBlank() }
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                if (mime != null) setMimeType(mime)
                if (userAgent != null) addRequestHeader("User-Agent", userAgent)
                if (referer != null) addRequestHeader("Referer", referer)
                CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            }
            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            fileName
        } catch (e: Exception) {
            null
        }
    }
}

/**
 * 빠른 다운로드 (Android 10+).
 * - 서버가 구간 요청(Range)을 지원하면 파일을 여러 조각으로 나눠 동시에 여러 연결로 내려받는다.
 * - 지원하지 않거나 작은 파일이면 연결 1개로 받는다.
 * - 조각이 끊기면 받은 곳부터 이어받고, 서버가 동시 연결을 거부하면 연결 수를 줄여 계속한다.
 * - 끝까지 실패하면 시스템 다운로드 관리자로 자동 전환한다.
 * - 포그라운드 서비스라서 앱을 나가도 계속 받는다.
 */
class DownloadService : Service() {

    private class Job(
        val id: Int,
        val url: String,
        val userAgent: String?,
        val contentDisposition: String?,
        val mimeType: String?,
        val referer: String?,
        /** 저장 파일 이름으로 쓸 제목 (스트리밍 영상처럼 주소에 이름이 없을 때) */
        val title: String? = null,
        /** 영상을 보던 화면이 쓰던 쿠키. 없으면 앱의 쿠키 저장소에서 읽는다 */
        val cookie: String? = null
    ) {
        val cancelled = AtomicBoolean(false)

        /** HLS(m3u8) 스트리밍 저장 작업이면 true */
        @Volatile
        var isHls: Boolean = false

        val calls = ConcurrentLinkedQueue<okhttp3.Call>()
        val downloaded = AtomicLong(0)

        @Volatile
        var total: Long = -1

        @Volatile
        var fileName: String = ""

        @Volatile
        var savedMime: String = "application/octet-stream"

        @Volatile
        var savedUri: Uri? = null

        @Volatile
        var speedBps: Long = 0

        /** 끝났거나 실패해서 진행 알림을 더 갱신하면 안 될 때 */
        @Volatile
        var finished: Boolean = false

        val conns = ConcurrentLinkedQueue<HttpURLConnection>()

        fun cancel() {
            cancelled.set(true)
            calls.forEach {
                try {
                    it.cancel()
                } catch (e: Exception) {
                    // 무시
                }
            }
            conns.forEach {
                try {
                    it.disconnect()
                } catch (e: Exception) {
                    // 무시
                }
            }
        }
    }

    private val pool = Executors.newCachedThreadPool()

    /** 진행 중인 작업 (다운로드 화면에서도 읽을 수 있도록 companion 에 둔다) */
    private val jobs: ConcurrentHashMap<Int, Job> get() = registry
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CH_DOWNLOAD, "다운로드", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_SERVICE, "다운로드 서비스", NotificationManager.IMPORTANCE_MIN)
            )
            // 완료 알림은 화면 위에 팝업으로 떠서 바로 '열기'를 누를 수 있게 중요도를 높인다
            DownloadNotifier.ensureChannel(this)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService 로 시작되면 바로 startForeground 를 호출해야 한다.
        ServiceCompat.startForeground(
            this, SERVICE_NOTIF_ID, serviceNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        when (intent?.action) {
            ACTION_CANCEL -> jobs[intent.getIntExtra(EXTRA_JOB, -1)]?.cancel()
            ACTION_START -> {
                val url = intent.getStringExtra(EXTRA_URL)
                if (url != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val job = Job(
                        id = nextId.getAndIncrement(),
                        url = url,
                        userAgent = intent.getStringExtra(EXTRA_UA),
                        contentDisposition = intent.getStringExtra(EXTRA_CD),
                        mimeType = intent.getStringExtra(EXTRA_MIME),
                        referer = intent.getStringExtra(EXTRA_REFERER),
                        title = intent.getStringExtra(EXTRA_TITLE),
                        cookie = intent.getStringExtra(EXTRA_COOKIE)
                    )
                    jobs[job.id] = job
                    pool.execute { runJob(job) }
                }
            }
        }
        if (jobs.isEmpty()) finishService()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        jobs.values.forEach { it.cancel() }
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun finishService() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ───────────────────────── 다운로드 작업 ─────────────────────────

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun runJob(job: Job) {
        var uri: Uri? = null
        var pfd: ParcelFileDescriptor? = null
        var channel: FileChannel? = null
        val ticker = pool.submit { runTicker(job) }

        try {
            notifyProgress(job)

            // 스트리밍(HLS, m3u8) 영상은 조각을 받아 파일 하나로 이어 붙인다
            if (HlsDownload.looksLikeHls(job.url, job.mimeType)) {
                runHlsJob(job)
                return
            }

            // 1) 첫 요청으로 파일 정보 확인 (리다이렉트 따라감)
            val (probe, finalUrl) = connect(job, job.url, 0, -1)
            val code = probe.responseCode
            if (code != 200 && code != 206) {
                probe.disconnect()
                throw IOException("HTTP $code")
            }

            var total = -1L
            var ranged = false
            if (code == 206) {
                total = probe.getHeaderField("Content-Range")
                    ?.substringAfter('/', "")?.toLongOrNull() ?: -1L
                ranged = total > 0
            } else {
                total = probe.contentLengthLong
            }

            val headerMime = probe.contentType?.substringBefore(';')?.trim()
            // 주소엔 .m3u8 이 안 보여도 서버가 HLS 목록이라고 알려 주면 스트리밍으로 처리
            if (headerMime != null && HlsDownload.isHlsMime(headerMime)) {
                probe.disconnect()
                job.conns.remove(probe)
                runHlsJob(job)
                return
            }
            val mime = job.mimeType?.takeIf { it.isNotBlank() && it != "application/octet-stream" }
                ?: headerMime?.takeIf { it.isNotBlank() }
            val disposition = job.contentDisposition?.takeIf { it.isNotBlank() }
                ?: probe.getHeaderField("Content-Disposition")
            job.fileName = FileNames.guess(finalUrl, disposition, mime)
            job.total = if (total > 0) total else -1
            job.savedMime = FileNames.mimeFor(job.fileName, mime) ?: "application/octet-stream"

            // 2) 다운로드 폴더에 파일 만들기
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, job.fileName)
                put(MediaStore.Downloads.MIME_TYPE, FileNames.mimeFor(job.fileName, mime) ?: "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val created = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("파일을 만들 수 없습니다")
            uri = created
            job.savedUri = created
            pfd = contentResolver.openFileDescriptor(created, "rw")
                ?: throw IOException("파일을 열 수 없습니다")
            val ch = FileOutputStream(pfd!!.fileDescriptor).channel
            channel = ch
            notifyProgress(job)

            // 3) 받기
            if (ranged && total >= MIN_SPLIT_BYTES) {
                probe.disconnect()
                job.conns.remove(probe)
                downloadSegmented(job, finalUrl, total, ch)
            } else {
                streamSingle(job, probe, ch)
            }
            if (job.cancelled.get()) throw IOException("cancelled")

            // 4) 완료 처리
            ch.close()
            pfd?.close()
            channel = null
            pfd = null
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            contentResolver.update(created, done, null, null)
            job.finished = true
            notifyDone(job)
        } catch (e: Exception) {
            job.finished = true
            try {
                channel?.close()
                pfd?.close()
            } catch (ignored: Exception) {
                // 무시
            }
            channel = null
            pfd = null
            uri?.let {
                try {
                    contentResolver.delete(it, null, null)
                } catch (ignored: Exception) {
                    // 무시
                }
            }
            if (job.cancelled.get()) {
                nm.cancel(job.id)
            } else {
                // 빠른 다운로드가 안 되면 시스템 다운로더로 다시 시도
                val name = SystemDownload.enqueue(
                    this, job.url, job.userAgent, job.contentDisposition, job.mimeType, job.referer
                )
                notifyFailed(job, name != null)
            }
        } finally {
            ticker.cancel(true)
            try {
                channel?.close()
                pfd?.close()
            } catch (ignored: Exception) {
                // 무시
            }
            jobs.remove(job.id)
            if (jobs.isEmpty()) finishService()
        }
    }

    // ───────────────────────── HLS(m3u8) 스트리밍 저장 ─────────────────────────

    /** 저장 파일 이름(확장자 제외). 제목이 있으면 제목, 없으면 주소의 파일 이름, 그것도 흔한 이름이면 날짜로 정한다 */
    private fun hlsBaseName(job: Job): String {
        fun clean(s: String) = s.replace(Regex("[\\\\/:*?\"<>|\\r\\n\\t]"), "_").trim().trim('.').take(80)
        job.title?.let { clean(it) }?.takeIf { it.isNotBlank() }?.let { return it }
        val last = job.url.substringBefore('#').substringBefore('?').substringAfterLast('/')
            .substringBeforeLast('.').let { clean(it) }
        val generic = setOf("index", "master", "playlist", "video", "chunklist", "manifest", "stream", "main", "hls", "")
        if (last.isNotBlank() && last.lowercase() !in generic && !last.all { it.isDigit() }) return last
        return "video_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun runHlsJob(job: Job) {
        job.isHls = true
        val tmpV = File.createTempFile("hls_v_", ".bin", cacheDir)
        val tmpA = File.createTempFile("hls_a_", ".bin", cacheDir)
        var outUri: Uri? = null
        try {
            val ctx = HlsDownload.Ctx(
                client = PlayerHttp.client,
                userAgent = job.userAgent,
                referer = job.referer,
                cookieFor = { u -> cookieFor(job, u) },
                cancelled = { job.cancelled.get() },
                calls = job.calls,
                onBytes = { job.downloaded.addAndGet(it) },
                onSegment = {}
            )
            val plan = HlsDownload.plan(ctx, job.url)
            val base = hlsBaseName(job)
            job.fileName = "$base.mp4"
            notifyProgress(job)

            // 진행률: 조각 개수로 전체 크기를 어림해서 막대를 채운다
            val allSegs = plan.video.segs.size + (plan.audio?.segs?.size ?: 0)
            val doneSegs = AtomicInteger(0)
            val ctx2 = HlsDownload.Ctx(
                ctx.client, ctx.userAgent, ctx.referer, ctx.cookieFor, ctx.cancelled, ctx.calls, ctx.onBytes
            ) {
                val d = doneSegs.incrementAndGet()
                if (d >= 2) job.total = (job.downloaded.get() * allSegs / d).coerceAtLeast(job.downloaded.get())
            }
            ctx2.keyCache.putAll(ctx.keyCache)

            FileOutputStream(tmpV).buffered(BUFFER_SIZE).use { HlsDownload.download(ctx2, plan.video, it) }
            plan.audio?.let { a ->
                FileOutputStream(tmpA).buffered(BUFFER_SIZE).use { HlsDownload.download(ctx2, a, it) }
            }
            if (job.cancelled.get()) throw IOException("cancelled")
            job.total = job.downloaded.get()

            // 1) mp4 로 다시 묶기 (재인코딩 없음). 코덱이 맞지 않으면 2) 이어 붙인 원본 그대로 저장
            val canRemux = plan.video.rawExt == "ts" || plan.video.rawExt == "mp4"
            var savedName = ""
            var savedMime = ""
            var savedSize = 0L
            if (canRemux && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val mp4 = "$base.mp4"
                val uri = insertDownload(mp4, "video/mp4")
                outUri = uri
                var ok = false
                try {
                    contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                        ok = Mp4Remux.run(
                            tmpV, if (plan.audio != null && tmpA.length() > 0) tmpA else null,
                            pfd.fileDescriptor
                        ) { job.cancelled.get() }
                        savedSize = pfd.statSize
                    }
                } catch (e: Exception) {
                    if (job.cancelled.get()) throw e
                    ok = false
                }
                if (ok) {
                    savedName = mp4
                    savedMime = "video/mp4"
                } else {
                    try {
                        contentResolver.delete(uri, null, null)
                    } catch (e: Exception) {
                        // 무시
                    }
                    outUri = null
                }
            }
            if (outUri == null) {
                val ext = plan.video.rawExt
                val name = "$base.$ext"
                val uri = insertDownload(name, plan.video.rawMime)
                outUri = uri
                contentResolver.openOutputStream(uri, "w")?.use { os ->
                    tmpV.inputStream().use { it.copyTo(os, BUFFER_SIZE) }
                } ?: throw IOException("파일을 열 수 없습니다")
                savedName = name
                savedMime = plan.video.rawMime
                savedSize = tmpV.length()
            }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            contentResolver.update(outUri!!, done, null, null)
            job.fileName = savedName
            job.savedMime = savedMime
            job.savedUri = outUri
            job.downloaded.set(savedSize)
            job.finished = true
            notifyDone(job)
        } catch (e: Exception) {
            job.finished = true
            outUri?.let {
                try {
                    contentResolver.delete(it, null, null)
                } catch (ignored: Exception) {
                    // 무시
                }
            }
            if (job.cancelled.get()) {
                nm.cancel(job.id)
            } else {
                notifyFailed(job, false, e.message?.takeIf { it.length < 60 })
            }
        } finally {
            tmpV.delete()
            tmpA.delete()
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun insertDownload(name: String, mime: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("파일을 만들 수 없습니다")
    }

    /**
     * 요청에 실어 보낼 쿠키. 받기를 시작한 주소와 같은 사이트면 넘겨받은 쿠키(시크릿 탭 포함)를,
     * 다른 사이트(리다이렉트·CDN)면 그 사이트의 쿠키만 앱 쿠키 저장소에서 읽는다. (로그인 쿠키가 다른 사이트로 새지 않게)
     */
    private fun cookieFor(job: Job, url: String): String? {
        val own = job.cookie
        if (!own.isNullOrBlank()) {
            val same = try {
                URL(url).host.equals(URL(job.url).host, ignoreCase = true)
            } catch (e: Exception) {
                false
            }
            if (same) return own
        }
        return CookieManager.getInstance().getCookie(url)
    }

    /** 리다이렉트를 직접 따라가며 연결한다. 반환: (연결, 최종 주소) */
    private fun connect(job: Job, startUrl: String, start: Long, end: Long): Pair<HttpURLConnection, String> {
        var currentUrl = startUrl
        for (i in 0 until MAX_REDIRECTS) {
            if (job.cancelled.get()) throw IOException("cancelled")
            val conn = URL(currentUrl).openConnection() as HttpURLConnection
            job.conns.add(conn)
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            // gzip 으로 풀리면 길이/구간이 어긋나므로 원본 그대로 받는다.
            conn.setRequestProperty("Accept-Encoding", "identity")
            job.userAgent?.let { conn.setRequestProperty("User-Agent", it) }
            job.referer?.let { conn.setRequestProperty("Referer", it) }
            cookieFor(job, currentUrl)?.let { conn.setRequestProperty("Cookie", it) }
            conn.setRequestProperty("Range", if (end >= 0) "bytes=$start-$end" else "bytes=$start-")

            val code = conn.responseCode
            if (code in 300..399 && code != 304) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                job.conns.remove(conn)
                if (location.isNullOrBlank()) throw IOException("잘못된 리다이렉트")
                val next = URL(URL(currentUrl), location)
                // http/https 외의 주소(file:, ftp: 등)나 https → http 로의 이동은 따라가지 않는다.
                if (next.protocol != "https" && next.protocol != "http") throw IOException("지원하지 않는 이동 주소")
                if (currentUrl.startsWith("https://") && next.protocol == "http") {
                    throw IOException("보안 연결(https)에서 비보안(http)으로 이동해 차단했습니다")
                }
                currentUrl = next.toString()
            } else {
                return conn to currentUrl
            }
        }
        throw IOException("리다이렉트가 너무 많습니다")
    }

    private fun writeFully(channel: FileChannel, data: ByteBuffer, position: Long) {
        var p = position
        while (data.hasRemaining()) p += channel.write(data, p)
    }

    /** 연결 1개로 처음부터 끝까지 받기 (구간 요청 미지원 / 작은 파일) */
    private fun streamSingle(job: Job, conn: HttpURLConnection, channel: FileChannel) {
        try {
            val buf = ByteArray(BUFFER_SIZE)
            var pos = 0L
            conn.inputStream.use { input ->
                while (true) {
                    if (job.cancelled.get()) throw IOException("cancelled")
                    val n = input.read(buf)
                    if (n < 0) break
                    writeFully(channel, ByteBuffer.wrap(buf, 0, n), pos)
                    pos += n
                    job.downloaded.addAndGet(n.toLong())
                }
            }
            if (job.total > 0 && pos < job.total) throw IOException("연결이 일찍 끊김")
        } finally {
            conn.disconnect()
            job.conns.remove(conn)
        }
    }

    /** 여러 연결로 조각을 나눠 받기 */
    private fun downloadSegmented(job: Job, url: String, total: Long, channel: FileChannel) {
        val chunk = (total / (CONNECTIONS * 3)).coerceIn(1L shl 20, 8L shl 20)
        val queue = ConcurrentLinkedQueue<LongArray>()
        var s = 0L
        while (s < total) {
            val e = minOf(s + chunk, total) - 1
            queue.add(longArrayOf(s, e))
            s = e + 1
        }

        val workers = minOf(CONNECTIONS, queue.size)
        val executor = Executors.newFixedThreadPool(workers)
        val failure = AtomicReference<Exception?>(null)
        val latch = CountDownLatch(workers)

        for (index in 0 until workers) {
            executor.execute {
                var range: LongArray? = null
                try {
                    while (!job.cancelled.get() && failure.get() == null) {
                        range = queue.poll() ?: break
                        fetchRange(job, url, range[0], range[1], channel)
                        range = null
                    }
                } catch (e: Exception) {
                    val pending = range
                    if (index > 0 && pending != null && !job.cancelled.get()) {
                        // 서버가 동시 연결을 거부했을 수 있다 → 이 연결은 빠지고 조각은 다른 연결이 받는다.
                        queue.add(pending)
                    } else {
                        failure.compareAndSet(null, e)
                    }
                } finally {
                    latch.countDown()
                }
            }
        }
        latch.await()
        executor.shutdown()

        if (job.cancelled.get()) throw IOException("cancelled")
        failure.get()?.let { throw it }

        // 연결이 빠지면서 남은 조각이 있으면 마저 받는다.
        while (!job.cancelled.get()) {
            val r = queue.poll() ?: break
            fetchRange(job, url, r[0], r[1], channel)
        }
    }

    /** [start, end] 구간을 받는다. 끊기면 받은 곳부터 다시 요청한다. */
    private fun fetchRange(job: Job, url: String, start: Long, end: Long, channel: FileChannel) {
        var pos = start
        var attempts = 0
        val buf = ByteArray(BUFFER_SIZE)
        while (pos <= end) {
            if (job.cancelled.get()) throw IOException("cancelled")
            var conn: HttpURLConnection? = null
            try {
                val (c, _) = connect(job, url, pos, end)
                conn = c
                if (c.responseCode != 206) throw IOException("구간 요청 거부 (HTTP ${c.responseCode})")
                c.inputStream.use { input ->
                    while (pos <= end) {
                        val want = minOf(buf.size.toLong(), end - pos + 1).toInt()
                        val n = input.read(buf, 0, want)
                        if (n < 0) break
                        writeFully(channel, ByteBuffer.wrap(buf, 0, n), pos)
                        pos += n
                        job.downloaded.addAndGet(n.toLong())
                    }
                }
                if (pos <= end) throw IOException("연결이 일찍 끊김")
            } catch (e: IOException) {
                if (job.cancelled.get()) throw e
                attempts++
                if (attempts > MAX_RETRY) throw e
                Thread.sleep(500L * attempts)
            } finally {
                conn?.let {
                    job.conns.remove(it)
                    it.disconnect()
                }
            }
        }
    }

    // ───────────────────────── 알림 ─────────────────────────

    /** 0.5초마다 속도를 계산하고 진행률 알림을 갱신 */
    private fun runTicker(job: Job) {
        var last = job.downloaded.get()
        try {
            while (!Thread.currentThread().isInterrupted) {
                Thread.sleep(500)
                val now = job.downloaded.get()
                job.speedBps = (now - last) * 2
                last = now
                if (!job.cancelled.get()) notifyProgress(job)
            }
        } catch (e: InterruptedException) {
            // 종료
        }
    }

    private fun serviceNotification(): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("evergreen 다운로드")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

    /** 알림을 누르면 앱 안의 다운로드 목록 화면이 열린다. */
    private fun openDownloadsIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0,
            Intent(this, DownloadsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun notifyProgress(job: Job) {
        if (job.finished) return
        if (!Prefs(this).notifyDownloadProgress) { try { nm.cancel(job.id) } catch (e: Exception) { /* 무시 */ }; return }
        val done = job.downloaded.get()
        val total = job.total
        val speed = if (job.speedBps > 0) " · ${formatBytes(job.speedBps)}/s" else ""
        val cancel = PendingIntent.getService(
            this, job.id,
            Intent(this, DownloadService::class.java)
                .setAction(ACTION_CANCEL)
                .putExtra(EXTRA_JOB, job.id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CH_DOWNLOAD)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(job.fileName.ifEmpty { "다운로드 준비 중…" })
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openDownloadsIntent())
            .addAction(0, "취소", cancel)
        if (total > 0) {
            val pct = (done * 100 / total).toInt().coerceIn(0, 100)
            b.setProgress(100, pct, false)
                .setContentText("$pct% · ${formatBytes(done)} / ${formatBytes(total)}$speed")
        } else {
            b.setProgress(0, 0, true).setContentText("${formatBytes(done)}$speed")
        }
        nm.notify(job.id, b.build())
    }

    private fun notifyDone(job: Job) {
        DownloadNotifier.done(this, job.id, job.fileName, job.downloaded.get(), job.savedMime, job.savedUri)
    }

    private fun notifyFailed(job: Job, retriedWithSystem: Boolean, reason: String? = null) {
        if (!Prefs(this).notifyDownloadFailed) { try { nm.cancel(job.id) } catch (e: Exception) { /* 무시 */ }; return }
        nm.notify(
            job.id,
            NotificationCompat.Builder(this, CH_DOWNLOAD)
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle(job.fileName.ifEmpty { "다운로드 실패" })
                .setContentText(
                    if (retriedWithSystem) "빠른 다운로드 실패 → 시스템 다운로더로 다시 시도합니다"
                    else if (!reason.isNullOrBlank()) "다운로드에 실패했습니다 · $reason"
                    else "다운로드에 실패했습니다"
                )
                .setAutoCancel(true)
                .build()
        )
    }

    private fun formatBytes(n: Long): String = when {
        n >= 1L shl 30 -> String.format("%.2f GB", n / (1024.0 * 1024 * 1024))
        n >= 1L shl 20 -> String.format("%.1f MB", n / (1024.0 * 1024))
        n >= 1L shl 10 -> String.format("%.0f KB", n / 1024.0)
        else -> "$n B"
    }

    companion object {
        private const val ACTION_START = "com.example.evergreen.DOWNLOAD_START"
        private const val ACTION_CANCEL = "com.example.evergreen.DOWNLOAD_CANCEL"
        private const val EXTRA_URL = "url"
        private const val EXTRA_UA = "ua"
        private const val EXTRA_CD = "cd"
        private const val EXTRA_MIME = "mime"
        private const val EXTRA_REFERER = "referer"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_COOKIE = "cookie"
        private const val EXTRA_JOB = "job"

        private const val CH_DOWNLOAD = "downloads"
        private const val CH_SERVICE = "download_service"
        private const val SERVICE_NOTIF_ID = 1

        /** 동시에 여는 연결 수 */
        private const val CONNECTIONS = 8

        /** 이보다 작은 파일은 나누지 않고 연결 1개로 받는다 */
        private const val MIN_SPLIT_BYTES = 2L * 1024 * 1024

        private const val BUFFER_SIZE = 64 * 1024
        private const val MAX_RETRY = 5
        private const val MAX_REDIRECTS = 6

        private val nextId = AtomicInteger(1000)

        private val registry = ConcurrentHashMap<Int, Job>()

        fun snapshot(): List<ActiveDownload> =
            registry.values
                .map { ActiveDownload(it.id, it.fileName, it.downloaded.get(), it.total, it.speedBps) }
                .sortedBy { it.id }

        fun cancelJob(id: Int) {
            registry[id]?.cancel()
        }

        fun start(
            context: Context,
            url: String,
            userAgent: String?,
            contentDisposition: String?,
            mimeType: String?,
            referer: String?,
            title: String? = null,
            cookie: String? = null
        ) {
            val intent = Intent(context, DownloadService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_COOKIE, cookie)
                .putExtra(EXTRA_URL, url)
                .putExtra(EXTRA_UA, userAgent)
                .putExtra(EXTRA_CD, contentDisposition)
                .putExtra(EXTRA_MIME, mimeType)
                .putExtra(EXTRA_REFERER, referer)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
