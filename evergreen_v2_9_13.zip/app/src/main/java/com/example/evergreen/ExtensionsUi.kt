package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch

/** 설정 > 확장 프로그램 (상/하단바의 확장 프로그램 버튼도 같은 화면): 설치된 확장 프로그램을 켜고 끄고, 팝업·옵션을 열고, 지운다. */
object ExtensionsUi {

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Float, ctx: Context) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp * ctx.resources.displayMetrics.density
    }

    /** 이 확장 프로그램이 페이지에 적용됐는지, 막혔는지, 오류가 났는지 보여 주는 기록 */
    private fun showDiag(ctx: Context, mgr: ExtensionManager, e: ExtensionManager.Ext) {
        val sb = StringBuilder()
        sb.append("${e.name} v${e.version}\n")
        sb.append(if (e.enabled) "켜짐" else "꺼짐").append(" · 스크립트 삽입 ")
            .append(if (mgr.supported) "지원" else "미지원(웹뷰 업데이트 필요)").append("\n")
        sb.append("웹페이지 스크립트 ${e.entries.size}개")
        e.entries.forEach { en -> sb.append("\n  · ").append(en.matches.joinToString(", ")).append("  [").append(en.runAt).append("]") }
        sb.append(if (e.hasBackground) "\n백그라운드 있음" else "")
        val pop = mgr.popupOf(e)
        sb.append(
            if (pop != null) "\n팝업: $pop"
            else if (mgr.hasActionClick(e.id)) "\n팝업 없음 · 툴바 버튼을 누르면 백그라운드가 실행돼요 (action.onClicked)"
            else "\n팝업 없음 · 툴바 버튼 동작 없음"
        )
        val dnr = mgr.dnrRuleCount(e.id)
        if (dnr > 0) sb.append("\n요청 차단 규칙 ${dnr}개 적용 중")
        sb.append("\n\n기록 (이 확장이 적용된 페이지를 연 뒤에 보세요)\n")
        val lines = mgr.diagLines(e.id)
        if (lines.isEmpty()) sb.append("아직 없음 — 주소 조건에 맞는 페이지에서 한 번도 실행되지 않았어요")
        else lines.forEach { sb.append(it).append("\n") }
        val tv = TextView(ctx).apply {
            text = sb.toString()
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(ctx, 20), dp(ctx, 8), dp(ctx, 20), dp(ctx, 8))
        }
        val scroll = android.widget.ScrollView(ctx).apply { addView(tv) }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle("확장 프로그램 진단")
            .setView(scroll)
            .setPositiveButton("닫기", null)
            .setNeutralButton("복사") { _, _ ->
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("진단", sb.toString()))
                AppToast.show(ctx, "복사했어요")
            }
            .setNegativeButton("기록 지우기") { _, _ -> mgr.diagClear(e.id) }
            .show()
    }

    /**
     * @param onAdd 웹스토어 / 파일(zip·crx) 중에 골라 추가하러 간다 (이 화면은 닫힌다)
     * @param onOpenPage 확장 프로그램 안의 페이지(옵션)를 새 탭으로 연다
     * @param onOpenPopup 확장 프로그램의 툴바 팝업을 앱 안 팝업으로 띄운다 (이 화면은 닫힌다)
     * @param onChanged 켜기/끄기/삭제로 바뀐 게 있을 때, 이 화면을 닫으면서 한 번 부른다
     */
    fun show(
        ctx: Context,
        mgr: ExtensionManager,
        onAdd: () -> Unit,
        onOpenPage: (String) -> Unit,
        onOpenPopup: (ExtensionManager.Ext) -> Unit,
        onChanged: () -> Unit,
        /** 상/하단바에서 누른 버튼. 태블릿이면 이 버튼 바로 아래에 붙어 뜬다 (없으면 가운데 팝업) */
        anchor: View? = null
    ) {
        val items = mgr.list().sortedWith(compareByDescending<ExtensionManager.Ext> { it.enabled }.thenBy { it.name.lowercase() })
        val onSurface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface, 0xFF000000.toInt())
        val onVar = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt())
        val primary = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF1B7F4B.toInt())
        val surface = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        // 메뉴창과 같은 색 조합: 회색 바탕 카드 · 연초록 아이콘 받침 · 짙은 초록 글자 · 연한 빨강 삭제 버튼
        val container = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurfaceContainer, 0xFFF7F8FA.toInt())
        val primaryContainer = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimaryContainer, 0xFFE8F5EC.toInt())
        val onPrimaryContainer = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnPrimaryContainer, 0xFF14532D.toInt())
        val cardBg = surface
        val cardBgOff = ColorUtils.blendARGB(surface, container, 0.55f)
        val iconBg = primaryContainer
        val chipBg = primaryContainer
        val dangerFg = androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_danger)
        val dangerBg = androidx.core.content.ContextCompat.getColor(ctx, R.color.ev_danger_soft)
        var changed = false
        val enabledCount = items.count { it.enabled }

        val title = "확장 프로그램"
        val subtitle = if (items.isEmpty()) "설치된 확장 프로그램이 없어요" else "${items.size}개 설치됨 · ${enabledCount}개 켜짐"
        // 팝업이 있으면 팝업을 열고, 없으면 툴바 버튼을 누른 것처럼 확장 프로그램의 onClicked 를 부른다
        fun launch(e: ExtensionManager.Ext) {
            if (mgr.popupOf(e) != null) onOpenPopup(e) else mgr.actionClick(e.id)
        }
        val fill: (LinearLayout, () -> Unit, (() -> Unit) -> Unit) -> Unit = fill@{ list, close, onDismiss ->
            onDismiss { if (changed) onChanged() }
            if (!mgr.supported) {
                list.addView(TextView(ctx).apply {
                    text = "이 기기의 웹뷰(WebView)가 페이지 시작 시 스크립트 삽입을 지원하지 않아 확장 프로그램이 동작하지 않아요. 'Android System WebView'를 업데이트해 보세요."
                    textSize = 12f
                    setTextColor(dangerFg)
                    setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 4))
                })
            }
            if (items.isEmpty()) {
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(ctx, 20), dp(ctx, 18), dp(ctx, 20), dp(ctx, 14))
                    addView(ImageView(ctx).apply {
                        setImageResource(R.drawable.ic_extension)
                        imageTintList = android.content.res.ColorStateList.valueOf(onPrimaryContainer)
                        background = round(chipBg, 28f, ctx)
                        val p = dp(ctx, 16)
                        setPadding(p, p, p, p)
                        layoutParams = LinearLayout.LayoutParams(dp(ctx, 64), dp(ctx, 64)).apply { bottomMargin = dp(ctx, 14) }
                    })
                    addView(TextView(ctx).apply {
                        text = "아직 설치한 확장 프로그램이 없어요"
                        textSize = 15f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(onSurface)
                        gravity = Gravity.CENTER
                    })
                    addView(TextView(ctx).apply {
                        text = "＋ 추가를 눌러 크롬 웹스토어 주소(또는 ID)로 바로 설치하거나,\n.zip · .crx 파일을 추가해 보세요.\n\n" +
                            "다크 모드 · 광고 차단 · 글자 정리처럼 웹페이지를 꾸미는 확장 프로그램과, 팝업 · 백그라운드 · 요청 차단 · 우클릭 메뉴를 쓰는 확장 프로그램도 지원해요."
                        textSize = 12.5f
                        setTextColor(onVar)
                        setLineSpacing(0f, 1.15f)
                        gravity = Gravity.CENTER
                        setPadding(0, dp(ctx, 8), 0, 0)
                    })
                })
                return@fill
            }
            var lastOn: Boolean? = null
            val hasBoth = items.any { it.enabled } && items.any { !it.enabled }
            items.forEach { e ->
                if (hasBoth && lastOn != e.enabled) {
                    list.addView(TextView(ctx).apply {
                        text = if (e.enabled) "켜짐 · ${enabledCount}" else "꺼짐 · ${items.size - enabledCount}"
                        textSize = 11.5f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(primary)
                        setPadding(dp(ctx, 6), dp(ctx, 10), 0, dp(ctx, 2))
                    })
                }
                lastOn = e.enabled
                list.addView(LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    alpha = if (e.enabled) 1f else 0.85f
                    background = round(if (e.enabled) cardBg else cardBgOff, 20f, ctx)
                    setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 8), dp(ctx, 10))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(ctx, 4)
                        bottomMargin = dp(ctx, 4)
                    }

                    // 윗줄: 아이콘 · 이름/버전/설명 · 스위치 (아이콘·이름을 누르면 팝업이 있는 확장 프로그램은 바로 팝업을 연다)
                    val top = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val info = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        if ((mgr.popupOf(e) != null || mgr.hasActionClick(e.id)) && e.enabled) {
                            isClickable = true
                            background = RippleDrawable(
                                android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(onPrimaryContainer, 0x22)),
                                null, round(0xFFFFFFFF.toInt(), 14f, ctx)
                            )
                            setOnClickListener {
                                close()
                                launch(e)
                            }
                        }
                        addView(ImageView(ctx).apply {
                            val bmp = mgr.iconBitmap(e)
                            if (bmp != null) setImageBitmap(bmp)
                            else {
                                setImageResource(R.drawable.ic_extension)
                                imageTintList = android.content.res.ColorStateList.valueOf(onPrimaryContainer)
                                val p = dp(ctx, 8)
                                setPadding(p, p, p, p)
                            }
                            background = round(iconBg, 12f, ctx)
                            alpha = if (e.enabled) 1f else 0.45f
                            layoutParams = LinearLayout.LayoutParams(dp(ctx, 42), dp(ctx, 42)).apply { marginEnd = dp(ctx, 12) }
                        })
                        addView(LinearLayout(ctx).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            alpha = if (e.enabled) 1f else 0.55f
                            addView(LinearLayout(ctx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                addView(TextView(ctx).apply {
                                    text = e.name
                                    textSize = 15f
                                    setTypeface(typeface, Typeface.BOLD)
                                    setTextColor(onSurface)
                                    maxLines = 1
                                    ellipsize = android.text.TextUtils.TruncateAt.END
                                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(ctx, 6) }
                                })
                                addView(TextView(ctx).apply {
                                    text = "v${e.version}"
                                    textSize = 10.5f
                                    setTextColor(onPrimaryContainer)
                                    background = round(primaryContainer, 8f, ctx)
                                    setPadding(dp(ctx, 6), dp(ctx, 1), dp(ctx, 6), dp(ctx, 1))
                                })
                            })
                            if (e.description.isNotBlank()) addView(TextView(ctx).apply {
                                text = e.description
                                textSize = 12f
                                setTextColor(onVar)
                                maxLines = 2
                                ellipsize = android.text.TextUtils.TruncateAt.END
                                setPadding(0, dp(ctx, 2), 0, 0)
                            })
                            // 이 확장 프로그램이 하는 일을 작은 꼬리표로 (최대 3개)
                            val tags = ArrayList<String>()
                            if (mgr.popupOf(e) != null) tags.add("팝업") else if (mgr.hasActionClick(e.id)) tags.add("툴바 실행")
                            if (e.hasBackground) tags.add("백그라운드")
                            val rules = mgr.dnrRuleCount(e.id)
                            if (rules > 0) tags.add("차단 규칙 $rules")
                            else if (e.entries.isNotEmpty()) tags.add("페이지 ${e.entries.size}곳")
                            if (tags.isNotEmpty()) addView(LinearLayout(ctx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                setPadding(0, dp(ctx, 5), 0, 0)
                                tags.take(3).forEach { t ->
                                    addView(TextView(ctx).apply {
                                        text = t
                                        textSize = 10.5f
                                        maxLines = 1
                                        setTextColor(onPrimaryContainer)
                                        background = round(if (e.enabled) primaryContainer else ColorUtils.blendARGB(surface, primaryContainer, 0.6f), 8f, ctx)
                                        setPadding(dp(ctx, 7), dp(ctx, 2), dp(ctx, 7), dp(ctx, 2))
                                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 5) }
                                    })
                                }
                            })
                        })
                    }
                    top.addView(info)
                    top.addView(MaterialSwitch(ctx).apply {
                        isChecked = e.enabled
                        setOnCheckedChangeListener { _, on ->
                            mgr.setEnabled(e.id, on)
                            changed = true
                            // 켜짐/꺼짐에 맞춰 이 카드 모양만 바로 바꾼다
                            (top.parent as? View)?.animate()?.alpha(if (on) 1f else 0.85f)?.setDuration(150)?.start()
                            info.getChildAt(0).alpha = if (on) 1f else 0.45f
                            info.getChildAt(1).alpha = if (on) 1f else 0.55f
                        }
                    })
                    addView(top)

                    // 제한 사항 안내
                    val notes = ArrayList<String>()
                    if (e.entries.isEmpty() && !e.hasBackground && mgr.popupOf(e) == null && !mgr.hasActionClick(e.id)) notes.add("웹페이지에 넣는 스크립트가 없어서 이 앱에서는 할 수 있는 일이 없어요")
                    if (notes.isNotEmpty()) addView(TextView(ctx).apply {
                        text = notes.joinToString("\n")
                        textSize = 11.5f
                        setTextColor(0xFFC77700.toInt())
                        background = round(0x1AC77700, 10f, ctx)
                        setPadding(dp(ctx, 10), dp(ctx, 6), dp(ctx, 10), dp(ctx, 6))
                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                            topMargin = dp(ctx, 8)
                            marginEnd = dp(ctx, 4)
                        }
                    })

                    // 아랫줄: 팝업 · 옵션 ·········· 삭제 (알약 모양 버튼)
                    addView(LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, dp(ctx, 8), dp(ctx, 4), 0)
                        fun chip(label: String, fg: Int, bg: Int, click: () -> Unit) {
                            addView(TextView(ctx).apply {
                                text = label
                                textSize = 12.5f
                                setTypeface(typeface, Typeface.BOLD)
                                setTextColor(fg)
                                gravity = Gravity.CENTER
                                background = RippleDrawable(
                                    android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(fg, 0x33)),
                                    round(bg, 100f, ctx), null
                                )
                                setPadding(dp(ctx, 14), dp(ctx, 7), dp(ctx, 14), dp(ctx, 7))
                                isClickable = true
                                setOnClickListener { click() }
                                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 6) }
                            })
                        }
                        fun delBtn(click: () -> Unit) {
                            addView(ImageButton(ctx).apply {
                                setImageResource(R.drawable.ic_delete)
                                imageTintList = android.content.res.ColorStateList.valueOf(dangerFg)
                                contentDescription = "삭제"
                                background = RippleDrawable(
                                    android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(dangerFg, 0x33)),
                                    round(dangerBg, 100f, ctx), null
                                )
                                val pd = dp(ctx, 8)
                                setPadding(pd, pd, pd, pd)
                                layoutParams = LinearLayout.LayoutParams(dp(ctx, 36), dp(ctx, 36))
                                setOnClickListener { click() }
                            })
                        }
                        val hasPop = mgr.popupOf(e) != null
                        if (hasPop || mgr.hasActionClick(e.id)) {
                            chip(if (hasPop) "팝업 열기" else "실행", onPrimaryContainer, chipBg) {
                                if (!e.enabled) {
                                    AppToast.show(ctx, "꺼져 있는 확장 프로그램이에요. 먼저 켜 주세요")
                                } else {
                                    close()
                                    launch(e)
                                }
                            }
                        }
                        e.options?.let { o ->
                            chip("옵션", onPrimaryContainer, chipBg) {
                                close()
                                onOpenPage(mgr.pageUrl(e, o))
                            }
                        }
                        chip("진단", onPrimaryContainer, ColorUtils.blendARGB(surface, primaryContainer, 0.6f)) { showDiag(ctx, mgr, e) }
                        addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
                        delBtn {
                            Popup.confirm(
                                ctx, "'${e.name}'을(를) 삭제할까요?",
                                "확장 프로그램 파일과 저장된 설정이 모두 지워져요.",
                                "삭제", danger = true
                            ) {
                                mgr.remove(e.id)
                                changed = true
                                close()
                                // 남은 목록으로 다시 연다 (바뀐 것은 닫을 때 한 번만 알린다)
                                if (mgr.list().isNotEmpty()) {
                                    show(ctx, mgr, onAdd, onOpenPage, onOpenPopup, onChanged, anchor)
                                }
                            }
                        }
                    })
                })
            }
        }
        if (anchor != null && Popup.canAnchor(ctx, anchor)) {
            Popup.panelAnchored(
                ctx, anchor, title, subtitle, R.drawable.ic_extension, widthDp = 400,
                secondaryLabel = "＋ 추가",
                onSecondary = { close -> close(); onAdd() },
                build = fill
            )
        } else {
            Popup.panel(
                ctx,
                title = title,
                subtitle = subtitle,
                headerIcon = R.drawable.ic_extension,
                widthDp = 400,
                grayBackground = true,
                secondaryLabel = "＋ 추가",
                onSecondary = { d ->
                    d.dismiss()
                    onAdd()
                }
            ) { list, dialog -> fill(list, { dialog.dismiss() }, { cb -> dialog.setOnDismissListener { cb() } }) }
        }
    }
}
