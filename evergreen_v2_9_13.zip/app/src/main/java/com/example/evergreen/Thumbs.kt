package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView

/** 다운로드 목록의 파일 미리보기 (사진 · 영상). 목록을 열 때 한 번 만들어 메모리에 잠시 둔다. */
object Thumbs {

    private const val PX = 160
    private val cache = LruCache<String, Bitmap>(100)
    private val failed = HashSet<String>()
    private val io = java.util.concurrent.Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    private val IMG = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif")
    private val VID = setOf("mp4", "mkv", "webm", "mov", "avi", "3gp", "m4v", "ts", "flv", "wmv")

    private fun isVideo(name: String, mime: String?) =
        mime?.startsWith("video") == true || name.substringAfterLast('.', "").lowercase() in VID

    private fun isImage(name: String, mime: String?) =
        mime?.startsWith("image") == true || name.substringAfterLast('.', "").lowercase() in IMG

    fun supports(name: String, mime: String?) = isVideo(name, mime) || isImage(name, mime)

    private fun dp(v: View, n: Int) = (n * v.resources.displayMetrics.density).toInt()

    /** 재활용되는 행을 기본 모양(동그라미 받침 + 안쪽 아이콘)으로 되돌린다 */
    fun reset(iv: ImageView) {
        iv.tag = null
        iv.setPadding(dp(iv, 10), dp(iv, 10), dp(iv, 10), dp(iv, 10))
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.clipToOutline = false
        iv.outlineProvider = ViewOutlineProvider.BACKGROUND
    }

    private fun show(iv: ImageView, b: Bitmap) {
        iv.setPadding(0, 0, 0, 0)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.imageTintList = null
        iv.background = null
        iv.setImageBitmap(b)
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(view, 10).toFloat())
            }
        }
        iv.clipToOutline = true
    }

    /** 색이 있는 문서 배지 아이콘: 받침 없이 아이콘 하나가 칸을 채운다 */
    fun badge(iv: ImageView, res: Int) {
        reset(iv)
        val p = dp(iv, 5)
        iv.setPadding(p, p, p, p)
        iv.imageTintList = null
        iv.background = null
        iv.setImageResource(res)
    }

    fun apply(iv: ImageView, uri: Uri?, name: String, mime: String?) {
        reset(iv)
        if (uri == null || !supports(name, mime)) return
        val key = uri.toString()
        iv.tag = key
        cache.get(key)?.let { show(iv, it); return }
        if (key in failed) return
        val ctx = iv.context.applicationContext
        val video = isVideo(name, mime)
        io.execute {
            val bmp = load(ctx, uri, video)
            main.post {
                if (bmp == null) { failed.add(key); return@post }
                cache.put(key, bmp)
                if (iv.tag == key) show(iv, bmp)
            }
        }
    }

    private fun load(ctx: Context, uri: Uri, video: Boolean): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) {
            try { return ctx.contentResolver.loadThumbnail(uri, Size(PX, PX), null) } catch (_: Exception) {}
        }
        return try {
            if (video) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val f = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: r.getFrameAtTime(0L)
                    f?.let { Bitmap.createScaledBitmap(it, PX, PX * it.height / maxOf(1, it.width), true) }
                } finally { r.release() }
            } else {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (o.outWidth / (s * 2) >= PX && o.outHeight / (s * 2) >= PX) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            }
        } catch (_: Throwable) { null }
    }
}
