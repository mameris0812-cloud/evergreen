package com.example.evergreen

import android.util.Base64
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** 실시간 자막 한 줄: 보여 줄 글과 화면에 머무는 시간 */
class LiveSeg(val text: String, val holdMs: Long)

/**
 * 플레이어가 재생하는 소리를 그대로 엿듣는 오디오 처리기 (소리는 바꾸지 않고 그대로 내보낸다).
 * 실시간 자막이 꺼져 있으면(sink == null) 아무 일도 하지 않는다.
 */
interface PcmSink {
    fun feed(buf: ByteBuffer, rate: Int, channels: Int)
    fun reset()
    fun stop()
}

class PcmTap : BaseAudioProcessor() {
    @Volatile
    var sink: PcmSink? = null

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // 16비트 PCM 만 다룬다. 그 밖의 형식(패스스루 등)은 건드리지 않고 비활성
        return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT) inputAudioFormat else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val n = inputBuffer.remaining()
        if (n == 0) return
        sink?.feed(inputBuffer.duplicate(), inputAudioFormat.sampleRate, inputAudioFormat.channelCount)
        val out = replaceOutputBuffer(n)
        out.put(inputBuffer)
        out.flip()
    }

    override fun onFlush() {
        // 되감기·건너뛰기: 모아 둔 소리는 버린다
        sink?.reset()
    }
}

/**
 * 재생 소리를 6초씩 모아 Gemini(무료 키로도 가능)에 보내 한국어 자막을 받아 온다.
 * 자막은 말이 끝난 뒤 받아 오므로 실제 말보다 몇 초 늦게 나온다.
 */
class LiveCaptioner(
    private val apiKey: String,
    private val model: String,
    private val onSegs: (List<LiveSeg>) -> Unit,
    private val onError: (String) -> Unit,
    private val onReset: () -> Unit
) : PcmSink {
    private companion object {
        const val RATE = 16000
        const val CHUNK_BYTES = RATE * 2 * 6 // 6초
        const val PROMPT =
            "이 오디오에서 들리는 말을 한국어 자막으로 만들어 주세요. 다른 언어는 자연스러운 한국어로 번역하고, " +
                "한국어는 그대로 받아적습니다. 음악·효과음·잡음뿐이면 빈 배열을 돌려주세요. " +
                "JSON 배열만 출력합니다: [{\"s\":시작초,\"e\":끝초,\"t\":\"자막\"}]. " +
                "자막 하나는 한두 줄 길이로 끊고 시간 순서대로 적습니다."
    }

    private val lock = Any()
    private val pcm = ByteArrayOutputStream()
    private var phase = 0.0
    private var acc = 0f
    private var cnt = 0
    private val exec = Executors.newSingleThreadExecutor()
    private val inflight = AtomicInteger(0)

    @Volatile private var stopped = false
    @Volatile private var pausedUntil = 0L
    @Volatile private var generation = 0

    override fun reset() {
        synchronized(lock) {
            pcm.reset(); phase = 0.0; acc = 0f; cnt = 0
            generation++
        }
        onReset()
    }

    override fun stop() {
        stopped = true
        exec.shutdownNow()
    }

    /** 재생 스레드에서 불린다: 소리를 모노 16kHz 로 줄여 쌓고, 6초가 차면 보낸다 */
    override fun feed(buf: ByteBuffer, rate: Int, channels: Int) {
        if (stopped || channels <= 0 || rate <= 0) return
        buf.order(java.nio.ByteOrder.LITTLE_ENDIAN)
        var chunk: ByteArray? = null
        var gen = 0
        synchronized(lock) {
            val ratio = rate.toDouble() / RATE
            while (buf.remaining() >= 2 * channels) {
                var sum = 0f
                for (i in 0 until channels) sum += buf.getShort().toFloat()
                acc += sum / channels
                cnt++
                phase += 1.0
                if (phase >= ratio) {
                    val v = (acc / cnt).toInt().coerceIn(-32768, 32767)
                    pcm.write(v and 0xff)
                    pcm.write((v shr 8) and 0xff)
                    phase -= ratio; acc = 0f; cnt = 0
                }
            }
            if (pcm.size() >= CHUNK_BYTES) {
                chunk = pcm.toByteArray()
                pcm.reset()
                gen = generation
            }
        }
        chunk?.let { submit(it, gen) }
    }

    private fun submit(data: ByteArray, gen: Int) {
        if (android.os.SystemClock.elapsedRealtime() < pausedUntil) return
        if (rms(data) < 150.0) return // 거의 무음이면 보내지 않는다 (무료 한도 절약)
        if (inflight.get() >= 2) return // 밀리면 오래된 소리는 건너뛴다
        inflight.incrementAndGet()
        try {
            exec.execute {
                try {
                    val segs = request(data)
                    if (!stopped && gen == generation && segs != null) onSegs(segs)
                } finally {
                    inflight.decrementAndGet()
                }
            }
        } catch (e: Exception) {
            inflight.decrementAndGet()
        }
    }

    private fun rms(d: ByteArray): Double {
        var s = 0.0
        var n = 0
        var i = 0
        while (i + 1 < d.size) {
            val v = ((d[i + 1].toInt() shl 8) or (d[i].toInt() and 0xff)).toShort().toInt()
            s += v.toDouble() * v
            n++
            i += 2
        }
        return if (n == 0) 0.0 else Math.sqrt(s / n)
    }

    private fun wav(d: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(d.size + 44)
        fun le32(v: Int) { for (k in 0 until 4) out.write((v shr (8 * k)) and 0xff) }
        fun le16(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff) }
        out.write("RIFF".toByteArray()); le32(36 + d.size)
        out.write("WAVE".toByteArray()); out.write("fmt ".toByteArray())
        le32(16); le16(1); le16(1); le32(RATE); le32(RATE * 2); le16(2); le16(16)
        out.write("data".toByteArray()); le32(d.size)
        out.write(d)
        return out.toByteArray()
    }

    /** @return 자막 목록 (말이 없으면 빈 목록), 실패하면 null (오류는 onError 로 알린다) */
    private fun request(data: ByteArray): List<LiveSeg>? {
        var c: HttpURLConnection? = null
        try {
            c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 40000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)
            val parts = JSONArray()
                .put(JSONObject().put("text", PROMPT))
                .put(
                    JSONObject().put(
                        "inlineData",
                        JSONObject().put("mimeType", "audio/wav")
                            .put("data", Base64.encodeToString(wav(data), Base64.NO_WRAP))
                    )
                )
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                when (code) {
                    429 -> {
                        pausedUntil = android.os.SystemClock.elapsedRealtime() + 20_000L
                        onError("무료 사용 한도에 걸려 잠시 쉬어요")
                    }
                    400, 401, 403 -> onError("API 키를 확인해 주세요 ($code)")
                    else -> onError("자막 요청 실패 ($code)")
                }
                return null
            }
            val text = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val cand = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0) ?: return emptyList()
            val ps = cand.optJSONObject("content")?.optJSONArray("parts") ?: return emptyList()
            val sb = StringBuilder()
            for (i in 0 until ps.length()) {
                val p = ps.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text", ""))
            }
            val raw = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            if (raw.isEmpty()) return emptyList()
            val arr = JSONArray(raw)
            val out = ArrayList<LiveSeg>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optString("t").trim()
                if (t.isEmpty()) continue
                val span = ((o.optDouble("e", 0.0) - o.optDouble("s", 0.0)) * 1000).toLong()
                out.add(LiveSeg(t, if (span > 0) span.coerceIn(1500L, 5000L) else 2500L))
            }
            return out
        } catch (e: Exception) {
            if (!stopped) onError("자막 오류: ${e.message ?: e.javaClass.simpleName}")
            return null
        } finally {
            try { c?.disconnect() } catch (e: Exception) { }
        }
    }
}

/**
 * 기기 안에서 소리를 글로 바꾼다 (Android 13+ 의 기기 내 음성 인식, 인터넷·키 필요 없음).
 * 재생 소리를 16kHz 모노로 줄여 파이프로 인식기에 흘려 넣는다. 인식된 원문은 onPartial/onFinal 로 알린다.
 * 모든 콜백은 메인 스레드에서 불린다.
 */
class OnDeviceCaptioner(
    private val ctx: android.content.Context,
    private val lang: String,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onError: (String) -> Unit,
    private val onReset: () -> Unit
) : PcmSink {
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val queue = java.util.concurrent.LinkedBlockingQueue<ByteArray>(120)
    private var recognizer: android.speech.SpeechRecognizer? = null
    private var readFd: android.os.ParcelFileDescriptor? = null
    @Volatile private var out: java.io.OutputStream? = null
    @Volatile private var stopped = false
    private var writer: Thread? = null

    // 소리 줄이기 (재생 스레드에서만 쓴다)
    private var phase = 0.0
    private var acc = 0f
    private var cnt = 0
    private val tmp = ByteArrayOutputStream()

    fun start() {
        stopped = false
        writer = Thread {
            while (!stopped) {
                try {
                    val b = queue.poll(300, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                    out?.write(b)
                } catch (e: InterruptedException) {
                    return@Thread
                } catch (e: Exception) {
                    // 인식기가 세션을 끝낸 직후의 끊긴 파이프: 다음 세션에서 이어진다
                }
            }
        }.also { it.isDaemon = true; it.start() }
        main.post { createRecognizer(); beginSession() }
    }

    private fun createRecognizer() {
        if (android.os.Build.VERSION.SDK_INT < 33) return
        val sr = android.speech.SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        sr.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(p: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: android.os.Bundle?) {}

            override fun onPartialResults(p: android.os.Bundle?) {
                first(p)?.let { if (!stopped) onPartial(it) }
            }

            override fun onSegmentResults(p: android.os.Bundle) {
                first(p)?.let { if (!stopped) onFinal(it) }
            }

            override fun onEndOfSegmentedSession() {
                again(150)
            }

            override fun onResults(p: android.os.Bundle?) {
                // 분할 세션이 아닌 경우의 최종 결과
                first(p)?.let { if (!stopped) onFinal(it) }
                again(150)
            }

            override fun onError(error: Int) {
                when (error) {
                    android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        { onError("마이크 권한이 필요해요 (소리 인식용)"); return }
                    android.speech.SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                    android.speech.SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
                        { diagnoseLanguage(error); return }
                    android.speech.SpeechRecognizer.ERROR_NO_MATCH,
                    android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again(100)
                    android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> again(800)
                    else -> { onError("음성 인식 오류 ($error)"); again(1500) }
                }
            }
        })
        recognizer = sr
    }

    /**
     * 언어 오류가 났을 때, 인식기에게 실제로 어떤 언어가 설치·지원되는지 물어서 알려 준다.
     * 설치돼 있지 않지만 받을 수 있으면 내려받기도 바로 시작한다.
     */
    private fun diagnoseLanguage(code: Int) {
        val sr = recognizer
        if (android.os.Build.VERSION.SDK_INT < 33 || sr == null) {
            onError("이 언어의 오프라인 음성 데이터를 쓸 수 없어요 (오류 $code)"); return
        }
        val probe = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, lang)
        try {
            sr.checkRecognitionSupport(probe, ctx.mainExecutor, object : android.speech.RecognitionSupportCallback {
                override fun onSupportResult(support: android.speech.RecognitionSupport) {
                    val installed = support.installedOnDeviceLanguages
                    val supported = support.supportedOnDeviceLanguages
                    val pending = support.pendingOnDeviceLanguages
                    fun has(l: List<String>) = l.any { it.equals(lang, true) }
                    when {
                        has(pending) -> onError("$lang 음성 데이터를 내려받는 중이에요. 끝나면 다시 켜 주세요")
                        has(supported) && !has(installed) -> {
                            runCatching { sr.triggerModelDownload(probe) }
                            onError("$lang 음성 데이터가 설치돼 있지 않아 내려받기를 시작했어요. 끝나면 다시 켜 주세요")
                        }
                        has(installed) ->
                            onError("$lang 는 설치돼 있다고 나오는데 인식기가 거부해요 (오류 $code). 설치된 언어: ${installed.joinToString()}")
                        else ->
                            onError("이 기기 인식기는 $lang 를 지원하지 않아요 (오류 $code). 기기 안 인식 언어: ${supported.joinToString().ifEmpty { "없음" }}")
                    }
                }

                override fun onError(error: Int) {
                    onError("이 언어의 오프라인 음성 데이터를 쓸 수 없어요 (오류 $code, 확인 실패 $error)")
                }
            })
        } catch (e: Exception) {
            onError("이 언어의 오프라인 음성 데이터를 쓸 수 없어요 (오류 $code)")
        }
    }

    private fun first(b: android.os.Bundle?): String? =
        b?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
            ?.takeIf { it.isNotEmpty() }

    private fun again(delayMs: Long) {
        if (stopped) return
        main.postDelayed({ beginSession() }, delayMs)
    }

    private fun beginSession() {
        if (stopped || android.os.Build.VERSION.SDK_INT < 33) return
        val sr = recognizer ?: return
        try {
            sr.cancel()
            closePipe()
            val pipe = android.os.ParcelFileDescriptor.createPipe()
            readFd = pipe[0]
            out = android.os.ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
            val it = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(android.speech.RecognizerIntent.EXTRA_SEGMENTED_SESSION, true)
                .putExtra(android.speech.RecognizerIntent.EXTRA_AUDIO_SOURCE, readFd)
                .putExtra(android.speech.RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                .putExtra(android.speech.RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, android.media.AudioFormat.ENCODING_PCM_16BIT)
                .putExtra(android.speech.RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16000)
            sr.startListening(it)
        } catch (e: Exception) {
            onError("음성 인식을 시작하지 못했어요: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun closePipe() {
        try { out?.close() } catch (e: Exception) { }
        out = null
        try { readFd?.close() } catch (e: Exception) { }
        readFd = null
        queue.clear()
    }

    override fun feed(buf: ByteBuffer, rate: Int, channels: Int) {
        if (stopped || channels <= 0 || rate <= 0) return
        buf.order(java.nio.ByteOrder.LITTLE_ENDIAN)
        val ratio = rate.toDouble() / 16000
        while (buf.remaining() >= 2 * channels) {
            var sum = 0f
            for (i in 0 until channels) sum += buf.getShort().toFloat()
            acc += sum / channels
            cnt++
            phase += 1.0
            if (phase >= ratio) {
                val v = (acc / cnt).toInt().coerceIn(-32768, 32767)
                tmp.write(v and 0xff)
                tmp.write((v shr 8) and 0xff)
                phase -= ratio; acc = 0f; cnt = 0
            }
        }
        if (tmp.size() >= 3200) { // 0.1초씩 보낸다. 인식기가 못 따라오면 오래된 소리는 버린다
            queue.offer(tmp.toByteArray())
            tmp.reset()
        }
    }

    override fun reset() {
        // 되감기·건너뛰기: 새 세션으로 시작한다
        tmp.reset(); phase = 0.0; acc = 0f; cnt = 0
        main.post { onReset(); again(50) }
    }

    override fun stop() {
        stopped = true
        writer?.interrupt()
        main.removeCallbacksAndMessages(null)
        main.post {
            try { recognizer?.cancel(); recognizer?.destroy() } catch (e: Exception) { }
            recognizer = null
            closePipe()
        }
    }
}
