package com.example.evergreen

/**
 * 자막 파일(VTT · SRT · ASS/SSA · TTML)을 읽어 시간별 글 목록으로 만든다.
 * 미러링처럼 앱이 자막을 직접 그릴 때 쓴다 (영상 위치 → [textAt] 으로 지금 보여 줄 글).
 */
object SubtitleFile {

    class Cue(val start: Double, val end: Double, val text: String)

    private val TAGS = Regex("<[^>]+>")
    private val TIME = Regex("""(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})""")

    fun parse(rawIn: String): List<Cue> {
        val raw = rawIn.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        val list = when {
            raw.contains("[Events]", ignoreCase = true) -> parseAss(raw)
            Regex("<tt[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(raw.take(2000)) -> parseTtml(raw)
            else -> parseVttSrt(raw)
        }
        return list.filter { it.text.isNotBlank() && it.end > it.start }.sortedBy { it.start }
    }

    private fun clean(s: String): String =
        s.replace(TAGS, "")
            .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
            .lines().joinToString("\n") { it.trim() }.trim()

    private fun sec(m: MatchResult): Double {
        val h = m.groupValues[1].ifEmpty { "0" }.toInt()
        val mi = m.groupValues[2].toInt()
        val s = m.groupValues[3].toInt()
        val frac = m.groupValues[4]
        val ms = (frac + "00").take(3).toInt()
        return h * 3600.0 + mi * 60.0 + s + ms / 1000.0
    }

    private fun parseVttSrt(raw: String): List<Cue> {
        val out = ArrayList<Cue>()
        for (block in raw.split(Regex("\n{2,}"))) {
            val lines = block.split('\n')
            val ai = lines.indexOfFirst { it.contains("-->") }
            if (ai < 0) continue
            val parts = lines[ai].split("-->")
            if (parts.size < 2) continue
            val a = TIME.find(parts[0]) ?: continue
            val b = TIME.find(parts[1]) ?: continue
            val text = clean(lines.drop(ai + 1).joinToString("\n"))
            if (text.isNotEmpty()) out.add(Cue(sec(a), sec(b), text))
        }
        return out
    }

    private fun assTime(s: String): Double? {
        val m = Regex("""(\d+):(\d{1,2}):(\d{1,2})[.:](\d{1,3})""").find(s.trim()) ?: return null
        val frac = m.groupValues[4]
        return m.groupValues[1].toInt() * 3600.0 + m.groupValues[2].toInt() * 60.0 +
            m.groupValues[3].toInt() + ("0." + frac).toDouble()
    }

    private fun parseAss(raw: String): List<Cue> {
        val out = ArrayList<Cue>()
        var iStart = 1
        var iEnd = 2
        var iText = 9
        var cols = 10
        var inEvents = false
        for (line in raw.lines()) {
            val t = line.trim()
            if (t.startsWith("[")) { inEvents = t.equals("[Events]", ignoreCase = true); continue }
            if (!inEvents) continue
            if (t.startsWith("Format:", ignoreCase = true)) {
                val names = t.substringAfter(':').split(',').map { it.trim().lowercase() }
                cols = names.size
                names.indexOf("start").takeIf { it >= 0 }?.let { iStart = it }
                names.indexOf("end").takeIf { it >= 0 }?.let { iEnd = it }
                names.indexOf("text").takeIf { it >= 0 }?.let { iText = it }
            } else if (t.startsWith("Dialogue:", ignoreCase = true)) {
                val f = t.substringAfter(':').split(',', limit = cols)
                if (f.size <= iText) continue
                val s = assTime(f[iStart]) ?: continue
                val e = assTime(f[iEnd]) ?: continue
                val text = f[iText]
                    .replace(Regex("\\{[^}]*\\}"), "")
                    .replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ")
                    .trim()
                if (text.isNotEmpty()) out.add(Cue(s, e, text))
            }
        }
        return out
    }

    private fun ttmlTime(s: String): Double? {
        val v = s.trim()
        Regex("""^(\d+(?:\.\d+)?)s$""").find(v)?.let { return it.groupValues[1].toDouble() }
        Regex("""^(\d+(?:\.\d+)?)ms$""").find(v)?.let { return it.groupValues[1].toDouble() / 1000.0 }
        val m = Regex("""^(\d+):(\d{2}):(\d{2})(?:[.,](\d+))?$""").find(v) ?: return null
        val frac = m.groupValues[4]
        return m.groupValues[1].toInt() * 3600.0 + m.groupValues[2].toInt() * 60.0 +
            m.groupValues[3].toInt() + (if (frac.isEmpty()) 0.0 else ("0.$frac").toDouble())
    }

    private fun parseTtml(raw: String): List<Cue> {
        val out = ArrayList<Cue>()
        val re = Regex("<p\\b([^>]*)>(.*?)</p>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        for (m in re.findAll(raw)) {
            val attrs = m.groupValues[1]
            val b = Regex("""\bbegin="([^"]+)"""").find(attrs)?.groupValues?.get(1)?.let { ttmlTime(it) } ?: continue
            val endAttr = Regex("""\bend="([^"]+)"""").find(attrs)?.groupValues?.get(1)?.let { ttmlTime(it) }
            val dur = Regex("""\bdur="([^"]+)"""").find(attrs)?.groupValues?.get(1)?.let { ttmlTime(it) }
            val e = endAttr ?: (if (dur != null) b + dur else continue)
            val text = clean(m.groupValues[2].replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n"))
            if (text.isNotEmpty()) out.add(Cue(b, e, text))
        }
        return out
    }

    /** [t] 초에 보여 줄 글 (겹치는 자막은 줄바꿈으로 이어 붙인다). 없으면 빈 글 */
    fun textAt(cues: List<Cue>, t: Double): String {
        if (cues.isEmpty()) return ""
        var lo = 0
        var hi = cues.size - 1
        var idx = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (cues[mid].start <= t) { idx = mid; lo = mid + 1 } else hi = mid - 1
        }
        if (idx < 0) return ""
        val hit = ArrayList<String>()
        var i = idx
        var steps = 0
        while (i >= 0 && steps < 8) {
            val c = cues[i]
            if (c.end > t) hit.add(0, c.text)
            i--
            steps++
        }
        return hit.joinToString("\n")
    }
}
