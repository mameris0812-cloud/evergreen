package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.SpringAnimation
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin

/**
 * AI 어시스턴트 전용 그라데이션: 앱 대표색(초록) → 청록 → 파랑 → 보라.
 * 아래 부품들이 한 가지 색 흐름을 함께 쓴다.
 *  - [FlowGradientDrawable]: 천천히 흐르는 그라데이션 (채움·테두리, 동그라미·둥근 사각형)
 *  - [AuroraDrawable]: 창 위쪽에 번졌다 천천히 떠다니는 오로라 빛
 *  - [GradientImageView]: 그라데이션으로 색을 입힌 아이콘
 *  - [CollapseLayout]: 높이가 스프링으로 접히고 펴지는 카드 틀
 * 시스템의 "애니메이션 끄기"를 켜 두면 흐르지 않고 멈춘 그라데이션만 보인다.
 */
object AiGradient {
    /**
     * 그라데이션의 색 네 개. 첫 번째는 언제나 앱 대표색(초록)이고,
     * 거기서 색상환을 따라 청록 → 파랑 → 보라로 이어진다. [setBase] 로 대표색에 맞춰 다시 만든다.
     */
    @Volatile var STOPS: IntArray = intArrayOf(0xFF2FA35B.toInt(), 0xFF2BA5A8.toInt(), 0xFF4285F4.toInt(), 0xFF8E6FD6.toInt())
        private set

    /** 보낸 말풍선용: 대표색 → 파랑이 옅게 비치는 색 (글자는 원래 색) */
    @Volatile var BUBBLE_START: Int = 0xFF1F7A43.toInt()
        private set
    @Volatile var BUBBLE_END: Int = 0xFF2E5FC4.toInt()
        private set

    /** 앱 대표색 [primary] 를 시작으로 색상환을 돌려 나머지 색을 만든다 */
    fun setBase(primary: Int) {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(primary, hsl)
        val h = hsl[0]
        // 너무 진하지 않게: 채도는 대표색 수준 이하로, 밝기는 조금 밝게
        val sat = hsl[1].coerceIn(0.35f, 0.55f)
        fun rot(d: Float, l: Float): Int = ColorUtils.HSLToColor(floatArrayOf((h + d) % 360f, sat, l))
        STOPS = intArrayOf(primary, rot(45f, 0.52f), rot(90f, 0.60f), rot(140f, 0.66f))
        // 보낸 말풍선: 두 색이 옅게 비치는 틴트
        BUBBLE_START = ColorUtils.setAlphaComponent(primary, 0x40)
        BUBBLE_END = ColorUtils.setAlphaComponent(rot(90f, 0.60f), 0x40)
    }

    /** 앱 대표색 (그라데이션의 시작) */
    val BRAND: Int get() = STOPS[0]
    /** 그라데이션 가운데쯤의 색 (포인트: 작은 알약·커서 등) */
    val ACCENT: Int get() = STOPS[2]

    /** 0..1 위치의 색 */
    fun at(t: Float): Int {
        val st = STOPS
        val x = t.coerceIn(0f, 1f) * (st.size - 1)
        val i = minOf(x.toInt(), st.size - 2)
        return ColorUtils.blendARGB(st[i], st[i + 1], x - i)
    }

    /** [n] 개 항목에 차례로 입힐 색 */
    fun pick(i: Int, n: Int): Int = at(if (n <= 1) 0f else i.toFloat() / (n - 1))

    /** 글자에 입히는 그라데이션 (글자 폭 [w] 에 맞춘다) */
    fun textShader(w: Float): Shader = LinearGradient(0f, 0f, max(w, 1f), 0f, STOPS, null, Shader.TileMode.CLAMP)
}

/**
 * 흐르는 그라데이션 그림.
 * [oval] 이면 동그라미, 아니면 [radiusPx] 로 둥근 사각형(또는 [radii] 로 모서리마다).
 * [strokePx] 가 0보다 크면 테두리만 그린다.
 * [setFlowing] 을 켜면 색이 한 방향으로 계속 흘러가고, 끄면 지금 자리에서 멈춘다.
 */
class FlowGradientDrawable(
    private val ctx: Context,
    private val oval: Boolean = false,
    private val radiusPx: Float = 0f,
    private val strokePx: Float = 0f,
    private val colors: IntArray = AiGradient.STOPS
) : Drawable() {
    var radii: FloatArray? = null
        set(v) { field = v; invalidateSelf() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = android.graphics.Path()
    private val matrix = Matrix()
    private var shader: LinearGradient? = null
    private var len = 1f
    private var phase = 0f
    private var alphaValue = 255
    private var anim: ValueAnimator? = null
    private var periodMs = 7000L

    init {
        if (strokePx > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = strokePx
        }
    }

    override fun onBoundsChange(b: android.graphics.Rect) {
        super.onBoundsChange(b)
        len = max(b.width(), b.height()).toFloat().coerceAtLeast(1f) * 1.3f
        // 거울처럼 이어붙여서 흐름이 끊기는 자리 없이 계속 이어진다
        shader = LinearGradient(0f, 0f, len, len * 0.35f, colors, null, Shader.TileMode.MIRROR)
        paint.shader = shader
    }

    override fun draw(canvas: Canvas) {
        val s = shader ?: return
        matrix.setTranslate(phase * 2f * len, 0f)
        s.setLocalMatrix(matrix)
        paint.alpha = alphaValue
        if (alphaValue == 0) return
        val inset = if (strokePx > 0f) strokePx / 2f else 0f
        rect.set(bounds)
        rect.inset(inset, inset)
        if (oval) {
            canvas.drawOval(rect, paint)
            return
        }
        val rr = radii
        if (rr != null) {
            path.reset()
            path.addRoundRect(rect, rr, android.graphics.Path.Direction.CW)
            canvas.drawPath(path, paint)
        } else {
            canvas.drawRoundRect(rect, radiusPx, radiusPx, paint)
        }
    }

    /** 흐름을 켜고 끈다. [period] 가 짧을수록 빨리 흐른다 (이미 흐르는 중이면 지금 위치에서 속도만 바뀐다) */
    fun setFlowing(on: Boolean, period: Long = periodMs) {
        if (!on || !Motion.enabled(ctx)) {
            stopFlow()
            return
        }
        if (anim != null && period == periodMs) return
        periodMs = period
        anim?.cancel()
        val from = phase
        anim = ValueAnimator.ofFloat(from, from + 1f).apply {
            duration = period
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = (it.animatedValue as Float) % 1f
                invalidateSelf()
            }
            start()
        }
    }

    private fun stopFlow() {
        anim?.cancel()
        anim = null
    }

    /** 창이 닫힐 때 정리 */
    fun release() = stopFlow()

    override fun setAlpha(a: Int) {
        if (a != alphaValue) {
            alphaValue = a
            invalidateSelf()
        }
    }

    override fun getAlpha(): Int = alphaValue
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * 창 위쪽에 번져 있는 오로라 빛: 파랑·보라·분홍 빛 덩어리 세 개가 천천히 떠다닌다.
 * [setEnergy] 로 밝기를 부드럽게 바꾼다 (AI 가 답을 만드는 동안 더 환해진다).
 * 바탕은 칠하지 않으니 창 배경 위에 겹쳐서 쓴다.
 */
class AuroraDrawable(private val ctx: Context) : Drawable() {
    private class Blob(val cx: Float, val cy: Float, val r: Float, val color: Int, val phase: Float, val ax: Float, val ay: Float)

    private val blobs = listOf(
        Blob(0.12f, -0.02f, 0.80f, AiGradient.STOPS[0], 0.00f, 0.10f, 0.025f),
        Blob(0.55f, -0.06f, 0.72f, AiGradient.STOPS[2], 0.33f, 0.12f, 0.030f),
        Blob(0.96f, 0.00f, 0.66f, AiGradient.STOPS[3], 0.66f, 0.09f, 0.025f)
    )
    private val paints = blobs.map { Paint(Paint.ANTI_ALIAS_FLAG) }
    private var t = 0f
    private var energy = 0f      // 0 = 잔잔함, 1 = 환함
    private var fade = 1f        // 열릴 때 서서히 나타나는 정도
    private var anim: ValueAnimator? = null
    private var fadeAnim: ValueAnimator? = null
    private var energySpring: SpringAnimation? = null
    private val enabled = Motion.enabled(ctx)

    override fun onBoundsChange(b: android.graphics.Rect) {
        super.onBoundsChange(b)
        val w = b.width().toFloat()
        for (i in blobs.indices) {
            val bl = blobs[i]
            val r = bl.r * w
            // 가운데가 가장 진하고 가장자리로 갈수록 투명해진다 (원점 기준: 그릴 때 위치만 옮긴다)
            paints[i].shader = RadialGradient(
                0f, 0f, r,
                intArrayOf(ColorUtils.setAlphaComponent(bl.color, 0x58), ColorUtils.setAlphaComponent(bl.color, 0x1E), bl.color and 0x00FFFFFF),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (w <= 0f) return
        val a = ((0.38f + 0.42f * energy) * fade * 255f).toInt().coerceIn(0, 255)
        for (i in blobs.indices) {
            val bl = blobs[i]
            val ang = 2.0 * PI * (t + bl.phase)
            val x = bounds.left + (bl.cx + bl.ax * sin(ang).toFloat()) * w
            val y = bounds.top + (bl.cy + bl.ay * cos(ang * 1.3).toFloat()) * h
            paints[i].alpha = a
            canvas.save()
            canvas.translate(x, y)
            canvas.drawCircle(0f, 0f, bl.r * w, paints[i])
            canvas.restore()
        }
    }

    fun start() {
        if (!enabled || anim != null) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 18000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidateSelf() }
            start()
        }
    }

    fun stop() {
        anim?.cancel(); anim = null
        fadeAnim?.cancel(); fadeAnim = null
        energySpring?.cancel(); energySpring = null
    }

    /** 처음 열릴 때 빛이 서서히 번져 나온다 */
    fun fadeIn(delayMs: Long = 0L) {
        fadeAnim?.cancel()
        if (!enabled) { fade = 1f; invalidateSelf(); return }
        fade = 0f
        fadeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            startDelay = delayMs
            duration = 900L
            interpolator = android.view.animation.DecelerateInterpolator(1.6f)
            addUpdateListener { fade = it.animatedValue as Float; invalidateSelf() }
            start()
        }
    }

    /** 밝기를 스프링으로 부드럽게 바꾼다 (0 = 잔잔함, 1 = 환함) */
    fun setEnergy(target: Float) {
        energySpring?.cancel()
        if (!enabled) { energy = target; invalidateSelf(); return }
        energySpring = Motion.springValue(
            energy, target, stiffness = 60f, damping = 1f,
            onUpdate = { energy = it.coerceIn(0f, 1f); invalidateSelf() }
        )
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** 아이콘 모양(알파)대로 그라데이션을 입힌다. [setFlowing] 이면 색이 천천히 흐른다. */
class GradientImageView(context: Context) : ImageView(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN) }
    private val matrix = Matrix()
    private var shader: LinearGradient? = null
    private var phase = 0f
    private var anim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val len = max(w, h).toFloat().coerceAtLeast(1f) * 1.4f
        shader = LinearGradient(0f, 0f, len, len, AiGradient.STOPS, null, Shader.TileMode.MIRROR)
        paint.shader = shader
    }

    override fun onDraw(canvas: Canvas) {
        val s = shader ?: return super.onDraw(canvas)
        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        super.onDraw(canvas)
        // 거울 반복의 한 주기(그라데이션 길이의 2배)만큼 정확히 한 바퀴를 돌아야 끝과 처음이 이어진다 (반 바퀴면 되돌 때마다 색이 툭 튄다)
        matrix.setTranslate(phase * 4f * max(width, height) * 1.4f, 0f)
        s.setLocalMatrix(matrix)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        canvas.restoreToCount(layer)
    }

    fun setFlowing(on: Boolean) {
        if (!on || !Motion.enabled(context)) {
            anim?.cancel(); anim = null
            return
        }
        if (anim != null) return
        anim = ValueAnimator.ofFloat(phase, phase + 1f).apply {
            duration = 5200L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = (it.animatedValue as Float) % 1f; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }
}

/**
 * 첫 번째 자식의 높이가 스프링으로 접히고 펴지는 틀.
 * 접힐 때 내용은 위로 살짝 말려 올라가며 투명해지고, 펴질 때는 반대로 내려오며 나타난다.
 */
class CollapseLayout(context: Context) : FrameLayout(context) {
    private var progress = 1f
    private var spring: SpringAnimation? = null
    var expanded = true
        private set

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        setMeasuredDimension(measuredWidth, (measuredHeight * progress).toInt())
    }

    private fun apply() {
        val c = getChildAt(0) ?: return
        // 높이가 80% 이하로 줄면 투명해지기 시작해서, 완전히 닫히기 전에 내용이 먼저 사라진다
        c.alpha = ((progress - 0.2f) / 0.8f).coerceIn(0f, 1f)
        c.translationY = -(1f - progress) * dp(10)
        requestLayout()
    }

    private fun dp(n: Int): Float = n * resources.displayMetrics.density

    fun setExpanded(open: Boolean, animate: Boolean = true) {
        if (open == expanded && spring == null) return
        expanded = open
        spring?.cancel()
        spring = null
        val target = if (open) 1f else 0f
        if (!animate || !Motion.enabled(context) || !isAttachedToWindow) {
            progress = target
            apply()
            return
        }
        spring = Motion.springValue(
            progress, target, stiffness = 280f, damping = 0.9f,
            onUpdate = { progress = it.coerceIn(0f, 1f); apply() },
            onEnd = { spring = null; progress = target; apply() }
        )
    }

    override fun onDetachedFromWindow() {
        spring?.cancel()
        spring = null
        super.onDetachedFromWindow()
    }
}

/**
 * 구슬(오브) 모양 그라데이션: 일직선으로 흐르는 띠 대신, 색 덩어리 세 개가 서로 다른 속도로 구슬 안을 천천히 돌며
 * 부드럽게 섞인다. 위쪽 왼쪽에는 은은한 하이라이트, 아래쪽 가장자리에는 옅은 그늘이 있어 입체감이 난다.
 * 시스템의 "애니메이션 끄기"를 켜 두면 멈춘 채 보인다.
 */
class OrbDrawable(private val ctx: Context) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = android.graphics.Path()
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var alphaValue = 255
    private var r = 1f
    private var blobShaders: Array<RadialGradient?> = arrayOfNulls(3)
    private var hiShader: RadialGradient? = null
    private var shadeShader: RadialGradient? = null
    private var baseColor = 0

    override fun onBoundsChange(b: android.graphics.Rect) {
        super.onBoundsChange(b)
        r = (minOf(b.width(), b.height()) / 2f).coerceAtLeast(1f)
        clip.reset()
        clip.addCircle(b.exactCenterX(), b.exactCenterY(), r, android.graphics.Path.Direction.CW)
        val st = AiGradient.STOPS
        baseColor = st[2]
        val blobs = intArrayOf(st[0], st[1], st[3])
        for (i in 0 until 3) {
            val c = blobs[i]
            blobShaders[i] = RadialGradient(
                0f, 0f, r * 0.95f,
                intArrayOf(c, ColorUtils.setAlphaComponent(c, 0xB0), ColorUtils.setAlphaComponent(c, 0)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
        }
        hiShader = RadialGradient(
            0f, 0f, r * 0.8f,
            intArrayOf(0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
        )
        shadeShader = RadialGradient(
            0f, 0f, r * 1.05f,
            intArrayOf(0x00000000, 0x00000000, 0x2A000000), floatArrayOf(0f, 0.62f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        if (alphaValue == 0) return
        val cx = bounds.exactCenterX()
        val cy = bounds.exactCenterY()
        val save = canvas.save()
        canvas.clipPath(clip)
        paint.shader = null
        paint.color = baseColor
        paint.alpha = alphaValue
        canvas.drawCircle(cx, cy, r, paint)
        // 색 덩어리: 서로 다른 속도·방향·반경으로 돌아서 매번 다른 모양으로 섞인다
        val tau = (2.0 * PI).toFloat()
        val orbit = r * 0.5f
        for (i in 0 until 3) {
            val speed = when (i) { 0 -> 1f; 1 -> -1f; else -> 2f }
            val off = i * tau / 3f
            val a = phase * tau * speed + off
            val rad = orbit * (0.7f + 0.3f * sin(phase * tau * (i + 1) + off))
            val sh = blobShaders[i] ?: continue
            paint.shader = sh
            paint.alpha = alphaValue
            canvas.save()
            canvas.translate(cx + cos(a) * rad, cy + sin(a) * rad)
            canvas.drawCircle(0f, 0f, r * 0.95f, paint)
            canvas.restore()
        }
        // 입체감: 아래 가장자리 그늘, 위 왼쪽 하이라이트
        shadeShader?.let {
            paint.shader = it
            paint.alpha = alphaValue
            canvas.save(); canvas.translate(cx - r * 0.12f, cy - r * 0.12f)
            canvas.drawCircle(0f, 0f, r * 1.3f, paint); canvas.restore()
        }
        hiShader?.let {
            paint.shader = it
            paint.alpha = alphaValue
            canvas.save(); canvas.translate(cx - r * 0.35f, cy - r * 0.4f)
            canvas.drawCircle(0f, 0f, r * 0.8f, paint); canvas.restore()
        }
        paint.shader = null
        canvas.restoreToCount(save)
    }

    // 흐름 속도는 켜고 끌 때 갑자기 바뀌지 않고, 천천히 빨라졌다 천천히 느려져 멈춘다 (구슬이 휙 돌다 뚝 멈추지 않는다)
    private var flowTarget = 0f
    private var flowSpeed = 0f
    private var periodMs = 9000L
    private var lastTick = 0L

    fun setFlowing(on: Boolean, period: Long = 9000L) {
        if (!Motion.enabled(ctx)) {
            flowTarget = 0f
            flowSpeed = 0f
            stopFlow()
            return
        }
        periodMs = period.coerceAtLeast(1000L)
        flowTarget = if (on) 1f else 0f
        if (anim == null && (on || flowSpeed > 0.01f)) startTicker()
    }

    private fun startTicker() {
        lastTick = SystemClock.uptimeMillis()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val now = SystemClock.uptimeMillis()
                val dt = (now - lastTick).coerceIn(0L, 64L)
                lastTick = now
                // 목표 속도를 향해 부드럽게 (약 0.3초에 걸쳐)
                flowSpeed += (flowTarget - flowSpeed) * (1f - exp(-dt / 300f))
                if (flowTarget == 0f && flowSpeed < 0.01f) {
                    flowSpeed = 0f
                    stopFlow()
                    invalidateSelf()
                    return@addUpdateListener
                }
                phase = (phase + dt * flowSpeed / periodMs) % 1f
                invalidateSelf()
            }
            start()
        }
    }

    private fun stopFlow() { anim?.cancel(); anim = null }
    fun release() = stopFlow()

    override fun setAlpha(alpha: Int) { alphaValue = alpha; invalidateSelf() }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
