package com.example.evergreen

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * 탭 화면 선택 모드에서 쓰는 '진행도(0..1)' 기반 그림들.
 * 카드를 다시 만들지 않고 진행도만 스프링으로 움직여서, 켜고 끄는 동안 중간 모습이 부드럽게 이어진다.
 * 빠르게 연타해도 현재 진행도에서 곧바로 반대 방향으로 이어서 움직인다.
 */
abstract class SpringProgressDrawable : Drawable() {
    var progress = 0f
        private set
    private var anim: SpringAnimation? = null

    fun snapTo(v: Float) {
        anim?.cancel()
        anim = null
        progress = v
        invalidateSelf()
    }

    fun animateTo(target: Float, stiffness: Float = 480f, damping: Float = 0.6f) {
        anim?.cancel()
        if (progress == target) return
        // 값을 1000배 해서 최소 변화량(0.001)을 맞춘다
        val holder = FloatValueHolder(progress * 1000f)
        val a = SpringAnimation(holder)
        a.setSpring(SpringForce(target * 1000f).setStiffness(stiffness).setDampingRatio(damping))
        a.setMinimumVisibleChange(1f)
        a.addUpdateListener { _, value, _ ->
            progress = value / 1000f
            invalidateSelf()
        }
        a.addEndListener { _, canceled, _, _ ->
            if (anim === a) anim = null
            if (!canceled) {
                progress = target
                invalidateSelf()
            }
        }
        anim = a
        a.start()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** 탭 카드 바탕: 꺼짐(평범한 카드) ↔ 켜짐(강조색 면 + 굵은 테두리) 사이를 색 · 테두리 굵기까지 함께 섞는다. */
class SelectCardDrawable(
    private val offFill: Int, private val onFill: Int,
    private val offStroke: Int, private val onStroke: Int,
    private val radius: Float, private val offW: Float, private val onW: Float
) : SpringProgressDrawable() {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()

    override fun draw(canvas: Canvas) {
        val t = progress.coerceIn(0f, 1f)
        val w = offW + (onW - offW) * t
        fillP.color = ColorUtils.blendARGB(offFill, onFill, t)
        strokeP.color = ColorUtils.blendARGB(offStroke, onStroke, t)
        strokeP.strokeWidth = w
        rect.set(bounds)
        canvas.drawRoundRect(rect, radius, radius, fillP)
        rect.inset(w / 2f, w / 2f)
        canvas.drawRoundRect(rect, radius - w / 2f, radius - w / 2f, strokeP)
    }
}

/**
 * 체크 동그라미: 꺼짐은 테두리만, 켜지면 색이 안쪽에서 퍼지며 차오르고(살짝 튐) 체크 표시가 쓱 그려진다.
 * partial 은 '일부만 선택' (그룹 줄) — 테두리만 강조색이 된다.
 */
class CheckCircleDrawable(
    private val primary: Int,
    private val offColor: Int,
    private val onPrimary: Int,
    private val strokePx: Float
) : SpringProgressDrawable() {
    var partial = false
        set(v) {
            if (field != v) {
                field = v
                invalidateSelf()
            }
        }

    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = strokePx }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = primary }
    private val checkP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = onPrimary
    }
    private val full = Path()
    private val seg = Path()
    private val measure = PathMeasure()
    private var len = 0f

    override fun onBoundsChange(b: Rect) {
        val r = minOf(b.width(), b.height()) / 2f
        val l = b.exactCenterX() - r
        val t = b.exactCenterY() - r
        full.reset()
        full.moveTo(l + r * 2 * 0.29f, t + r * 2 * 0.53f)
        full.lineTo(l + r * 2 * 0.43f, t + r * 2 * 0.67f)
        full.lineTo(l + r * 2 * 0.72f, t + r * 2 * 0.36f)
        measure.setPath(full, false)
        len = measure.length
        checkP.strokeWidth = maxOf(r * 0.2f, 1f)
    }

    override fun draw(canvas: Canvas) {
        val p = progress.coerceIn(0f, 1.15f)
        val t = p.coerceAtMost(1f)
        val cx = bounds.exactCenterX()
        val cy = bounds.exactCenterY()
        val maxR = minOf(bounds.width(), bounds.height()) / 2f
        // 테두리
        ringP.color = ColorUtils.blendARGB(offColor, primary, if (partial) 1f else t)
        canvas.drawCircle(cx, cy, maxR - strokePx / 2f, ringP)
        // 안쪽에서 퍼지는 채움
        if (p > 0.01f) {
            fillP.alpha = (255 * (p * 2.2f).coerceIn(0f, 1f)).toInt()
            canvas.drawCircle(cx, cy, maxR * (0.3f + 0.7f * p), fillP)
        }
        // 체크 표시가 그려진다
        val ct = ((progress - 0.25f) / 0.6f).coerceIn(0f, 1f)
        if (ct > 0f && len > 0f) {
            seg.reset()
            measure.getSegment(0f, len * ct, seg, true)
            canvas.drawPath(seg, checkP)
        }
    }
}
