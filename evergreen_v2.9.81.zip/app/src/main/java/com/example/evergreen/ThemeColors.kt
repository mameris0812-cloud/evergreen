package com.example.evergreen

import android.content.Context
import android.view.View
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors

/**
 * 크롬 테마를 앱 전체(메뉴 · 팝업 · 탭 화면 · 목록 화면 · 대화상자)에 입히는 색 표.
 * 테마가 켜져 있으면 머티리얼 색 속성(colorSurface · colorOnSurface · colorPrimary …)을 테마에서 뽑은 색으로 바꿔 돌려주고,
 * 꺼져 있으면 원래 머티리얼 색을 그대로 돌려준다. 앱 곳곳의 MaterialColors.getColor 대신 [get] 을 쓴다.
 */
object ThemeColors {
    @Volatile private var map: Map<Int, Int>? = null

    val active: Boolean get() = map != null
    val isDark: Boolean get() = dark
    @Volatile private var dark = false

    fun get(ctx: Context, attr: Int, def: Int): Int = map?.get(attr) ?: MaterialColors.getColor(ctx, attr, def)
    fun get(v: View, attr: Int): Int = map?.get(attr) ?: MaterialColors.getColor(v, attr)
    fun get(v: View, attr: Int, def: Int): Int = map?.get(attr) ?: MaterialColors.getColor(v, attr, def)

    /** [bg] 위에서 잘 읽히는 색: [want] 의 대비가 모자라면 흰색/검정 계열 */
    fun readableOn(bg: Int, want: Int?): Int {
        if (want != null) {
            val w = ColorUtils.setAlphaComponent(want, 255)
            if (ColorUtils.calculateContrast(w, bg) >= 3.0) return w
        }
        return if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF1F1F1F.toInt() else 0xFFF1F3F4.toInt()
    }

    /** 켜진 테마에서 색 표를 만든다. null 이면 테마 끔(원래 색) */
    fun set(th: ExtensionManager.ThemeSpec?) {
        if (th == null) { map = null; dark = false; return }
        val a = com.google.android.material.R.attr::class.java
        fun id(name: String): Int = try { a.getField(name).getInt(null) } catch (e: Throwable) { 0 }
        val surface = ColorUtils.setAlphaComponent(th.toolbar, 255)
        val isDk = ColorUtils.calculateLuminance(surface) < 0.5
        val on = readableOn(surface, th.icon ?: th.tabText ?: th.ntpText)
        fun mix(w: Float) = ColorUtils.blendARGB(surface, on, w)
        // 강조색: 테마의 링크색 → 탭바(frame) 색 → 글자색 순으로, 바탕과 대비가 3 이상인 첫 색
        val accent = listOfNotNull(th.ntpLink, th.frame, th.omnibox)
            .map { ColorUtils.setAlphaComponent(it, 255) }
            .firstOrNull { ColorUtils.calculateContrast(it, surface) >= 3.0 }
            ?: ColorUtils.blendARGB(on, surface, 0.15f)
        val primaryContainer = ColorUtils.blendARGB(surface, accent, if (isDk) 0.30f else 0.18f)
        val onPrimaryContainer = readableOn(primaryContainer, accent)
        val m = HashMap<Int, Int>()
        fun put(name: String, c: Int) { val i = id(name); if (i != 0) m[i] = c }
        put("colorSurface", surface)
        put("colorSurfaceBright", surface)
        put("colorSurfaceContainerLowest", ColorUtils.blendARGB(surface, if (isDk) 0xFF000000.toInt() else 0xFFFFFFFF.toInt(), 0.35f))
        put("colorSurfaceContainerLow", mix(0.03f))
        put("colorSurfaceContainer", mix(0.06f))
        put("colorSurfaceContainerHigh", mix(0.10f))
        put("colorSurfaceContainerHighest", mix(0.14f))
        put("colorSurfaceVariant", mix(0.10f))
        put("colorOnSurface", on)
        put("colorOnSurfaceVariant", ColorUtils.blendARGB(on, surface, 0.32f))
        put("colorPrimary", accent)
        put("colorOnPrimary", readableOn(accent, null))
        put("colorPrimaryContainer", primaryContainer)
        put("colorOnPrimaryContainer", onPrimaryContainer)
        put("colorSecondaryContainer", primaryContainer)
        put("colorOnSecondaryContainer", onPrimaryContainer)
        put("colorOutline", ColorUtils.blendARGB(surface, on, 0.45f))
        put("colorOutlineVariant", mix(0.18f))
        m[android.R.attr.colorBackground] = surface
        dark = isDk
        map = m
    }
}
