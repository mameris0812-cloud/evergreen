package com.example.evergreen

import android.annotation.SuppressLint
import android.content.Context
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * 접속 차단(SNI 검열) 우회. 유니콘 HTTPS 와 같은 방식을 앱 안에 직접 넣은 것.
 *
 * 웹뷰의 https 연결을 앱 안의 로컬 프록시(127.0.0.1)로 보내고, 프록시가 사이트에 연결하면서
 *  1) DNS 는 DoH(암호화 DNS)로 직접 조회하고 (통신사 DNS 차단 회피)
 *  2) TLS 첫 패킷(ClientHello)을 사이트 이름(SNI) 한가운데에서 둘로 쪼개 보낸다 (이름을 한 번에 읽는 차단 장비 회피).
 * 쪼갠 연결을 사이트가 받아 주지 않으면 더 약한 방식 → 원본 순서로 자동으로 되돌린다 (사이트별로 기억).
 *
 * 내용은 건드리지 않고 그대로 중계만 하므로 속도 저하는 거의 없다. 웹뷰에만 적용된다 (다운로드·플레이어 연결은 해당 없음).
 */
object SniBypass {
    private const val MODE_RECORD = 0 // TLS 기록을 둘로 나누고, 패킷도 따로 보낸다
    private const val MODE_TCP = 1    // 기록은 그대로, 패킷만 둘로 나눠 보낸다
    private const val MODE_RAW = 2    // 손대지 않고 그대로

    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "sni-bypass").apply { isDaemon = true } }
    @Volatile private var server: ServerSocket? = null

    /** 사이트별로 통했던 방식 (처음에는 RECORD 부터 시도) */
    private val hostMode = ConcurrentHashMap<String, Int>()

    private data class Dns(val addrs: List<InetAddress>, val expires: Long)
    private val dnsCache = ConcurrentHashMap<String, Dns>()

    private val http = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    // ───────────────────────── 켜고 끄기 ─────────────────────────

    /** 확장 프로그램(chrome.proxy)이 정한 프록시. 켜져 있으면 접속 차단 우회보다 우선한다 */
    class ExtProxy(
        val rules: List<Pair<String, String>>, // (프록시 주소, 적용할 주소 종류: ProxyConfig.MATCH_*)
        val bypass: List<String>,
        val direct: Boolean,                   // 프록시 없이 직접 연결 (mode: direct)
        val bypassLocal: Boolean               // <local> (점 없는 주소는 프록시를 거치지 않음)
    )

    @Volatile private var extProxy: ExtProxy? = null
    @Volatile private var wantSni = false

    /** 확장 프로그램 프록시를 웹뷰 설정으로 바꾼다. 잘못된 값이면 IllegalArgumentException */
    fun buildExt(ext: ExtProxy): ProxyConfig {
        val b = ProxyConfig.Builder()
        if (ext.direct) {
            b.addDirect()
        } else {
            for ((url, scheme) in ext.rules) b.addProxyRule(url, scheme)
            for (r in ext.bypass) b.addBypassRule(r)
            if (ext.bypassLocal) b.bypassSimpleHostnames()
        }
        return b.build()
    }

    /** 확장 프로그램 프록시를 켜거나(null 이면 끄고 원래 설정으로) 한다. 웹뷰가 지원하지 않으면 false */
    fun setExtProxy(ext: ExtProxy?): Boolean {
        extProxy = ext
        return reapply()
    }

    /** 설정에 맞춰 프록시를 켜거나 끈다. 웹뷰가 프록시 설정을 지원하지 않으면 false */
    fun apply(context: Context, enabled: Boolean): Boolean {
        wantSni = enabled
        return reapply()
    }

    @Synchronized
    @SuppressLint("RequiresFeature")
    private fun reapply(): Boolean {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return false
        val exec = Runnable::run
        return try {
            val ext = extProxy
            if (ext != null) {
                ProxyController.getInstance().setProxyOverride(buildExt(ext), exec) {}
            } else if (wantSni) {
                val port = ensureServer()
                val cfg = ProxyConfig.Builder()
                    .addProxyRule("127.0.0.1:$port", ProxyConfig.MATCH_HTTPS) // https 만 프록시로, http 는 그대로
                    .addBypassRule("127.0.0.1")
                    .addBypassRule("localhost")
                    .bypassSimpleHostnames()
                    .build()
                ProxyController.getInstance().setProxyOverride(cfg, exec) {}
            } else {
                ProxyController.getInstance().clearProxyOverride(exec) {}
            }
            true
        } catch (e: Throwable) {
            false
        }
    }

    @Synchronized
    private fun ensureServer(): Int {
        server?.let { if (!it.isClosed) return it.localPort }
        val ss = ServerSocket(0, 64, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)))
        server = ss
        pool.execute {
            while (!ss.isClosed) {
                val c = try { ss.accept() } catch (e: IOException) { break }
                pool.execute { runCatching { handle(c) }.also { runCatching { c.close() } } }
            }
        }
        return ss.localPort
    }

    // ───────────────────────── 연결 처리 ─────────────────────────

    private fun handle(client: Socket) {
        client.tcpNoDelay = true
        client.soTimeout = 15_000
        val cin = client.getInputStream()
        val cout = client.getOutputStream()

        // CONNECT host:port HTTP/1.1 + 헤더
        val head = readHead(cin) ?: return
        val first = head.substringBefore("\r\n")
        val parts = first.split(' ')
        if (parts.size < 2 || !parts[0].equals("CONNECT", true)) {
            cout.write("HTTP/1.1 405 Method Not Allowed\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
            return
        }
        val target = parts[1]
        val host = target.substringBeforeLast(':').trim('[', ']')
        val port = target.substringAfterLast(':', "443").toIntOrNull() ?: 443

        val addrs = resolve(host)
        if (addrs.isEmpty()) {
            cout.write("HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
            return
        }
        cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
        cout.flush()

        // 브라우저가 보내는 첫 TLS 기록(ClientHello)을 통째로 읽는다
        val hello = readTlsRecord(cin) ?: return
        val sni = findSni(hello)

        var mode = if (sni == null) MODE_RAW else hostMode[host] ?: MODE_RECORD
        while (true) {
            val remote = connectAndSend(addrs, port, hello, sni, mode)
            if (remote != null) {
                hostMode[host] = mode
                pipe(client, remote.first, remote.second)
                return
            }
            if (mode >= MODE_RAW) return
            mode++
        }
    }

    /** 사이트에 연결해 첫 패킷을 보내고, 사이트가 답하면 (소켓, 첫 응답)을 돌려준다. 답이 없거나 끊기면 null */
    private fun connectAndSend(
        addrs: List<InetAddress>, port: Int, hello: ByteArray, sni: IntRange?, mode: Int
    ): Pair<Socket, ByteArray>? {
        val s = Socket()
        try {
            var connected = false
            for (a in addrs) {
                try { s.connect(InetSocketAddress(a, port), 6_000); connected = true; break } catch (_: IOException) {}
            }
            if (!connected) { s.close(); return null }
            s.tcpNoDelay = true
            s.soTimeout = 6_000
            val out = s.getOutputStream()
            val cut = if (sni != null) sni.first + (sni.last - sni.first + 1) / 2 else -1
            if (mode == MODE_RAW || cut <= 5 || cut >= hello.size) {
                out.write(hello); out.flush()
            } else if (mode == MODE_TCP) {
                out.write(hello, 0, cut); out.flush()
                pause()
                out.write(hello, cut, hello.size - cut); out.flush()
            } else {
                // 기록 둘로 나누기: [헤더 + 앞부분] [헤더 + 뒷부분]
                val v1 = hello[1]; val v2 = hello[2]
                val a = cut - 5
                val b = hello.size - cut
                val r1 = ByteArray(5 + a)
                r1[0] = 0x16; r1[1] = v1; r1[2] = v2; r1[3] = (a shr 8).toByte(); r1[4] = a.toByte()
                System.arraycopy(hello, 5, r1, 5, a)
                val r2 = ByteArray(5 + b)
                r2[0] = 0x16; r2[1] = v1; r2[2] = v2; r2[3] = (b shr 8).toByte(); r2[4] = b.toByte()
                System.arraycopy(hello, cut, r2, 5, b)
                out.write(r1); out.flush()
                pause()
                out.write(r2); out.flush()
            }
            val buf = ByteArray(16 * 1024)
            val n = s.getInputStream().read(buf)
            if (n <= 0) { s.close(); return null }
            s.soTimeout = 0
            return s to buf.copyOf(n)
        } catch (e: IOException) {
            runCatching { s.close() }
            return null
        }
    }

    private fun pause() { try { Thread.sleep(1) } catch (_: InterruptedException) {} }

    /** 양쪽으로 그대로 중계한다 */
    private fun pipe(client: Socket, remote: Socket, firstFromRemote: ByteArray) {
        client.soTimeout = 0
        val cout = client.getOutputStream()
        cout.write(firstFromRemote); cout.flush()
        val up = pool.submit {
            copy(client.getInputStream(), remote.getOutputStream())
            runCatching { remote.shutdownOutput() }
        }
        copy(remote.getInputStream(), cout)
        runCatching { client.shutdownOutput() }
        runCatching { up.get(30, TimeUnit.SECONDS) }
        runCatching { remote.close() }
    }

    private fun copy(i: InputStream, o: OutputStream) {
        val buf = ByteArray(16 * 1024)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n); o.flush()
            }
        } catch (_: IOException) {}
    }

    // ───────────────────────── 읽기 · 해석 ─────────────────────────

    private fun readHead(i: InputStream): String? {
        val sb = StringBuilder()
        var last4 = 0
        while (sb.length < 8192) {
            val b = i.read()
            if (b < 0) return null
            sb.append(b.toChar())
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) return sb.toString()
        }
        return null
    }

    @Throws(IOException::class)
    private fun readFully(i: InputStream, buf: ByteArray, off: Int, len: Int) {
        var p = 0
        while (p < len) {
            val n = i.read(buf, off + p, len - p)
            if (n < 0) throw EOFException()
            p += n
        }
    }

    /** TLS 기록 하나(헤더 5바이트 + 본문)를 통째로 읽는다. TLS 가 아니면 null */
    private fun readTlsRecord(i: InputStream): ByteArray? {
        return try {
            val h = ByteArray(5)
            readFully(i, h, 0, 5)
            if (h[0].toInt() != 0x16) return null
            val len = ((h[3].toInt() and 0xFF) shl 8) or (h[4].toInt() and 0xFF)
            if (len <= 0 || len > 16 * 1024 + 256) return null
            val r = ByteArray(5 + len)
            System.arraycopy(h, 0, r, 0, 5)
            readFully(i, r, 5, len)
            r
        } catch (e: IOException) { null }
    }

    /** ClientHello 안에서 사이트 이름(SNI) 글자가 있는 범위(전체 배열 기준 인덱스)를 찾는다 */
    private fun findSni(r: ByteArray): IntRange? {
        try {
            fun u8(p: Int) = r[p].toInt() and 0xFF
            fun u16(p: Int) = (u8(p) shl 8) or u8(p + 1)
            if (r.size < 45 || u8(0) != 0x16 || u8(5) != 0x01) return null
            var p = 5 + 4 + 2 + 32 // 기록 헤더 + 핸드셰이크 헤더 + 버전 + 랜덤
            p += 1 + u8(p)         // 세션 ID
            p += 2 + u16(p)        // 암호 목록
            p += 1 + u8(p)         // 압축 방식
            val extEnd = p + 2 + u16(p)
            p += 2
            while (p + 4 <= extEnd && p + 4 <= r.size) {
                val type = u16(p); val len = u16(p + 2)
                if (type == 0) { // server_name
                    // 목록 길이(2) + 종류(1) + 이름 길이(2) + 이름
                    val nameLen = u16(p + 4 + 3)
                    val start = p + 4 + 5
                    if (nameLen > 0 && start + nameLen <= r.size) return start until start + nameLen
                    return null
                }
                p += 4 + len
            }
        } catch (_: IndexOutOfBoundsException) {}
        return null
    }

    // ───────────────────────── DNS (DoH) ─────────────────────────

    private fun resolve(host: String): List<InetAddress> {
        if (host.isEmpty()) return emptyList()
        // IP 주소나 내부 이름은 그대로
        val ipLiteral = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host) || host.contains(':')
        if (ipLiteral || !host.contains('.')) return runCatching { InetAddress.getAllByName(host).toList() }.getOrDefault(emptyList())
        val now = System.currentTimeMillis()
        dnsCache[host]?.let { if (it.expires > now) return it.addrs }
        val doh = doh(host, "https://1.1.1.1/dns-query") ?: doh(host, "https://8.8.8.8/resolve") ?: doh(host, "https://9.9.9.9:5053/dns-query")
        val addrs = doh?.first ?: runCatching { InetAddress.getAllByName(host).toList() }.getOrDefault(emptyList())
        if (addrs.isNotEmpty()) {
            val ttl = (doh?.second ?: 60).coerceIn(30, 600)
            dnsCache[host] = Dns(addrs, now + ttl * 1000L)
        }
        return addrs
    }

    private fun doh(host: String, base: String): Pair<List<InetAddress>, Int>? {
        return try {
            val req = Request.Builder()
                .url("$base?name=$host&type=A")
                .header("accept", "application/dns-json")
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val ans = JSONObject(resp.body?.string() ?: return null).optJSONArray("Answer") ?: return null
                val list = ArrayList<InetAddress>()
                var ttl = 300
                for (k in 0 until ans.length()) {
                    val a = ans.getJSONObject(k)
                    if (a.optInt("type") == 1) {
                        list.add(InetAddress.getByName(a.getString("data")))
                        ttl = minOf(ttl, a.optInt("TTL", 300))
                    }
                }
                if (list.isEmpty()) null else list to ttl
            }
        } catch (e: Exception) { null }
    }
}
