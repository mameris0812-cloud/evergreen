package com.example.evergreen

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class GeminiModel(val id: String, val label: String)

object GeminiModels {
    val LITE = GeminiModel("gemini-3.5-flash-lite", "3.5 Flash-Lite")
    val FLASH = GeminiModel("gemini-3.5-flash", "3.5 Flash")
    val PRO = GeminiModel("gemini-3.8-flash", "3.8 Flash")
    val HYDROGEN = GeminiModel("gemini-4-hydrogen", "4 Hydrogen")

    val all = listOf(LITE, FLASH, PRO, HYDROGEN)

    fun byId(id: String): GeminiModel = all.firstOrNull { it.id == id } ?: FLASH
}

/** 키가 바뀐 일. [from]·[to] 는 키 번호(1부터), [total] 은 등록한 키 개수, [bad] 는 한도가 아니라 키가 거부돼서 바꾼 경우 */
class KeySwitchEvent(val from: Int, val to: Int, val total: Int, val bad: Boolean) {
    val text: String
        get() = if (bad) "키 $from 거부됨 → 키 $to 사용" else "키 $from 한도 도달 → 키 $to 사용"
}

/**
 * API 키를 여러 개 넣어 두면 돌아가며 쓰고, 한도(429)가 찼거나 거부된 키는 잠시 쉬게 한 뒤 다른 키로 다시 보낸다.
 */
object GeminiKeyPool {
    private val cool = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** 키 전체가 쉬는 이유가 한도가 아니라 거부(401·403)인 키 */
    private val rejected = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    /** 키가 바뀔 때마다 불린다 (백그라운드 스레드에서 올 수 있다). 화면 쪽에서 메인 스레드로 넘겨 쓴다 */
    @Volatile
    var onEvent: ((KeySwitchEvent) -> Unit)? = null

    @Volatile
    private var lastUsed: String = ""
    private val lastEventAt = java.util.concurrent.atomic.AtomicLong(0L)

    /** 요청을 실제로 보내는 키를 기록한다 (AI 창 위쪽의 「키 n/m」 표시용) */
    fun used(key: String) { lastUsed = key }

    /** 등록한 키 개수 */
    fun count(): Int = known.size

    /** 지금 쓰는 키 번호(1부터). 모르면 0 */
    fun currentNo(): Int = known.indexOf(lastUsed) + 1

    /**
     * 한도·거부로 [from] 대신 [to] 로 바꿨을 때 알린다.
     * 번역처럼 여러 요청이 동시에 바꿀 때 알림이 쏟아지지 않게 3초에 한 번만 낸다.
     */
    fun notifySwitch(from: String, to: String, bad: Boolean) {
        lastUsed = to
        if (known.size < 2) return
        val t = now()
        val prev = lastEventAt.get()
        if (t - prev < 3_000L || !lastEventAt.compareAndSet(prev, t)) return
        onEvent?.invoke(KeySwitchEvent(known.indexOf(from) + 1, known.indexOf(to) + 1, known.size, bad))
    }

    /** 설정 화면 표시용: 이 키가 지금 못 쓰는 이유와 풀리기까지 남은 시간. 바로 쓸 수 있으면 null */
    fun statusOf(key: String): String? {
        val t = now()
        val until = cool[key] ?: 0L
        if (until > t) {
            val left = remainText(until - t)
            return if (rejected[key] == true) "키가 거부됐어요 · $left 뒤 다시 확인" else "한도 도달 · $left 뒤 다시 사용"
        }
        val models = coolModel.entries.filter { it.key.startsWith("$key|") && it.value > t }
        if (models.isNotEmpty()) {
            val names = models.map { GeminiAuto.label(it.key.substringAfter('|')) }.distinct().joinToString(", ")
            return "$names 한도 도달 · 다른 모델은 사용 가능"
        }
        return null
    }

    private fun remainText(ms: Long): String {
        val sec = (ms + 999) / 1000
        return if (sec < 60) "${sec}초" else "${(sec + 59) / 60}분"
    }
    private val counter = java.util.concurrent.atomic.AtomicInteger()

    @Volatile
    private var known: List<String> = emptyList()

    private fun now() = System.currentTimeMillis()

    /**
     * 429 응답이 정말 내 사용량 한도(분당·일일·무료 한도)인지.
     * 한도 응답에는 어느 한도인지(quota 상세 · 대기 시간)가 함께 실려 온다. 그런 게 없는 429
     * ("Resource has been exhausted" 등)는 Gemini 서버가 붐빌 때도 오는 응답이라 한도가 아니다.
     */
    fun isQuota(body: String?): Boolean {
        val low = (body ?: "").lowercase()
        return low.contains("quotafailure") || low.contains("quota_metric") || low.contains("quotametric") ||
            low.contains("quotaid") || low.contains("quota_id") || low.contains("retrydelay") ||
            low.contains("exceeded your current quota") || low.contains("per minute") || low.contains("per day") ||
            low.contains("perminute") || low.contains("perday")
    }

    /** 이번에 쓸 키. 쉬는 중이 아닌 키를 번갈아 고른다 (모두 쉬는 중이면 가장 빨리 풀리는 키) */
    fun pick(keys: List<String>): String {
        known = keys
        if (keys.isEmpty()) return ""
        val t = now()
        val ok = keys.filter { (cool[it] ?: 0L) <= t }
        if (ok.isNotEmpty()) return ok[Math.floorMod(counter.getAndIncrement(), ok.size)]
        return keys.minByOrNull { cool[it] ?: 0L } ?: keys[0]
    }

    fun cooldown(key: String, ms: Long, bad: Boolean = false) {
        cool[key] = now() + ms
        rejected[key] = bad
    }

    /** (키, 모델) 짝 단위로만 쉬게 한다 — 이 모델만 한도가 0 이거나 막힌 경우 */
    private val coolModel = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun blocked(key: String, model: String): Boolean {
        val t = now()
        return (cool[key] ?: 0L) > t || (coolModel["$key|$model"] ?: 0L) > t
    }

    /**
     * 429 · 키 거부 응답을 받았을 때 호출한다.
     * - 키 자체가 거부된 경우: 키를 오래 쉬게 한다
     * - 이 모델만의 한도(한도 0 · 일일 한도 등 모델 단위): 그 키는 다른 모델에 계속 쓰고, (키, 모델) 짝만 쉬게 한다
     * - 그 밖의 한도: 응답이 알려 준 대기 시간(없으면 60초)만큼 키를 쉬게 한다
     */
    fun onLimit(key: String, model: String, body: String?, badKey: Boolean) {
        if (badKey) {
            // 특정 모델만 못 쓰게 막힌 403 (예: 권한 없는 Hydrogen)은 키 탓이 아니다
            val b = (body ?: "").lowercase()
            if (b.contains("model") && (b.contains("permission") || b.contains("not found") || b.contains("not supported") || b.contains("not available"))) {
                coolModel["$key|$model"] = now() + 600_000L
            } else cooldown(key, 600_000L, bad = true)
            return
        }
        val b = (body ?: "")
        val low = b.lowercase()
        val zero = (Regex("limit\\W{0,4}0\\b").containsMatchIn(low) || Regex("limit_value\\W+0\\b").containsMatchIn(low)) && !Regex("limit\\W{0,4}0\\d").containsMatchIn(low)
        val perModel = zero || low.contains("perday") || low.contains("per_day") || low.contains("perdaypermodel")
        val wait = retryDelayMs(b)
        if (perModel) coolModel["$key|$model"] = now() + maxOf(wait, 300_000L)
        else cooldown(key, wait.coerceIn(10_000L, 300_000L).let { if (wait <= 0L) 60_000L else it })
    }

    /** 오류 본문의 "retryDelay": "34s" 를 ms 로. 없으면 0 */
    private fun retryDelayMs(body: String): Long {
        val m = Regex("retryDelay\\W+(\\d+(?:\\.\\d+)?)s").find(body) ?: return 0L
        return ((m.groupValues[1].toDoubleOrNull() ?: 0.0) * 1000).toLong()
    }

    /** 이 모델로 보낼 때 쓸 수 있는 키가 하나라도 있는지 */
    fun anyUsable(model: String): Boolean = known.any { !blocked(it, model) }

    /** 이 모델에 쓸 키로 바꿔 준다 ([key] 가 이 모델에서 막혀 있으면 막히지 않은 다른 키). 없으면 [key] 그대로 */
    fun forModel(key: String, model: String): String {
        if (!blocked(key, model)) return key
        return known.firstOrNull { !blocked(it, model) } ?: key
    }

    /** 한도가 차서 잠시 쉬는 중인 키인지 (설정 화면 표시용) */
    fun resting(key: String): Boolean = (cool[key] ?: 0L) > now()

    /** [exclude] 에 없고 지금 쉬는 중도 아닌 다른 키. 없으면 null. [model] 을 주면 그 모델에서 막힌 키도 뺀다 */
    fun alternative(exclude: Set<String>, model: String = ""): String? {
        val t = now()
        return known.firstOrNull { it !in exclude && (cool[it] ?: 0L) <= t && (model.isEmpty() || (coolModel["$it|$model"] ?: 0L) <= t) }
    }
}

/**
 * 모델은 사용자가 고르지 않고 일에 맞춰 자동으로 정한다.
 * 가벼운 일은 빠른 Flash-Lite, 페이지를 읽거나 사진을 볼 땐 더 똑똑한 모델.
 * 모델이 없거나(404) 한도(429)·서버 오류(5xx)가 나면 [fallbacks] 순서대로 다른 모델로 다시 보낸다.
 */
object GeminiAuto {
    /** 페이지 글 번역: 짧은 글 묶음이라 가장 빠른 모델로 충분 */
    val TRANSLATE = GeminiModels.LITE.id
    /** 사진 속 글자 읽기·번역, 실시간 자막(소리): 사진/소리를 잘 알아듣는 모델 */
    val VISION = GeminiModels.FLASH.id
    /** 확장 프로그램의 요약 */
    val SUMMARY = GeminiModels.LITE.id

    private val dead: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    fun markDead(model: String) { dead.add(model) }

    // ───────── 채팅 질문 하나에 쓸 모델: 요청을 더 보내지 않고 질문만 보고 점수로 고른다 ─────────

    private val URL_RE = Regex("(?i)(https?://|www\\.)\\S+")

    /** 코드임이 거의 확실한 낱말 (하나만 있어도 코딩) */
    private val CODE_STRONG = listOf(
        "코딩", "디버그", "디버깅", "리팩터", "컴파일", "스택트레이스", "스택 트레이스", "stack trace", "정규식", "정규표현식",
        "프로그래밍", "파이썬", "자바스크립트", "코틀린", "타입스크립트", "regex", "kotlin", "python", "javascript",
        "typescript", "java", "sql", "html", "css", "json", "c++", "git"
    )
    /** 코딩 말고도 흔히 쓰는 낱말 (두 개 이상이거나, 짜 줘·고쳐 줘 같은 작업 말이 함께 있어야 코딩) */
    private val CODE_WEAK = listOf(
        "코드", "함수", "버그", "프로그램", "스크립트", "알고리즘", "쿼리", "변수", "라이브러리",
        "api", "github", "깃허브", "에이전트", "agent", "자동화", "워크플로"
    )
    private val CODE_ACTION = listOf("짜 ", "짜줘", "짜 줘", "작성", "구현", "만들어", "고쳐", "고치", "수정", "리팩", "최적화", "추가해", "돌아가", "실행")
    /** 코드 모양 자체 (코드 블록 · 선언문 · 오류 로그 · 태그) */
    private val CODE_SHAPE = Regex(
        "(```|=>|\\bfun\\s+\\w+\\(|\\bdef\\s+\\w+\\(|\\bfunction\\s*\\w*\\(|\\bimport\\s+[\\w.]+|\\bclass\\s+\\w+|#include|</?[a-z][a-z0-9]*>|\\w+\\([^)\\n]*\\)\\s*\\{|Exception|Traceback|NullPointer)",
        RegexOption.IGNORE_CASE
    )

    /** 깊은 추론이 필요한 낱말 (하나만 있어도) */
    private val HEAVY_STRONG = listOf("증명", "추론", "단계별", "논리적", "방정식", "미분", "적분", "확률", "step by step")
    /** 평범한 질문에도 나오는 낱말 (두 개 이상일 때만) */
    private val HEAVY_WEAK = listOf("분석", "비교", "자세히", "왜", "원인", "계산", "표로", "장단점", "차이", "이유", "전략", "설계", "보고서", "에세이", "논문")
    private val MATH_RE = Regex("\\d+(\\.\\d+)?\\s*[+\\-*/^×÷=]\\s*\\d+")

    private val EXPLAIN_VERBS = listOf("요약", "번역", "설명", "정리", "교정", "첨삭", "해석", "풀이")
    /** 감사 · 맞장구 같은 한두 마디 */
    private val ACK_RE = Regex("^(고마워|고맙|감사|ㅇㅋ|ㅇㅇ|ok|okay|네|넵|응|아니|아냐|좋아|알겠|굿|ㅋ+|ㅎ+|thanks|thx|thank you)[\\s!.~?ㅋㅎ]*$", RegexOption.IGNORE_CASE)

    private fun hasWord(lower: String, w: String): Boolean =
        if (w.all { it.code < 128 }) Regex("(?<![a-z0-9])" + Regex.escape(w) + "s?(?![a-z0-9+#])").containsMatchIn(lower)
        else lower.contains(w)

    /** 바로 앞 채팅 질문에 쓴 모델 — "계속해" · "그럼 그건?" 같은 짧은 이어 묻기에 같은 모델을 쓰려고 기억한다 */
    @Volatile
    private var lastChat: String? = null

    /** 새 대화 · 불러오기 · 지우기 때 기억을 비운다 */
    fun resetChat() { lastChat = null }

    /**
     * 채팅 질문 하나에 쓸 모델. 위에서부터 먼저 맞는 것:
     * 1. 감사 · 맞장구 → Flash-Lite
     * 2. 코딩(코드 모양 · 확실한 낱말 · 낱말 둘 이상 · 낱말 + 작업 말) → Hydrogen
     * 3. 사진 · 깊은 추론(확실한 낱말 · 평범한 낱말 둘 이상 · 400자 넘는 글 · 계산식 둘 이상 · 물음표 셋 이상 · 여섯 줄 이상) → 3.8 Flash
     * 4. 링크가 든 질문 · 페이지 글을 읽는 중 · 긴 대화 · 120자 넘는 질문 · 50자 넘는 요약·번역·설명 · 이어 묻기 → 3.5 Flash
     * 5. 나머지 → Flash-Lite
     * 링크 주소 안의 글자는 질문 내용이 아니라서 빼고 센다.
     */
    fun forChat(question: String, turns: Int, hasPageText: Boolean, imageCount: Int): String {
        val raw = question.trim()
        val hasUrl = URL_RE.containsMatchIn(raw)
        val q = raw.replace(URL_RE, " ").trim()
        val lower = q.lowercase()

        if (imageCount == 0 && q.length <= 15 && !hasUrl && ACK_RE.matches(q)) return remember(GeminiModels.LITE.id)

        val strong = CODE_STRONG.count { hasWord(lower, it) }
        val weak = CODE_WEAK.count { hasWord(lower, it) }
        val action = CODE_ACTION.any { lower.contains(it) }
        val coding = CODE_SHAPE.containsMatchIn(q) || strong >= 1 || weak >= 2 || (weak >= 1 && action)
        if (coding) return remember(GeminiModels.HYDROGEN.id)

        val heavyStrong = HEAVY_STRONG.any { lower.contains(it) }
        val heavyWeak = HEAVY_WEAK.count { lower.contains(it) }
        val heavy = heavyStrong || heavyWeak >= 2 || q.length > 400 ||
            MATH_RE.findAll(q).count() >= 2 || q.count { it == '?' || it == '？' } >= 3 || q.lines().size >= 6
        if (imageCount > 0 || heavy) return remember(GeminiModels.PRO.id)

        val explain = EXPLAIN_VERBS.any { lower.contains(it) } && q.length > 50
        val prev = lastChat
        val shortFollowUp = q.length <= 30 && turns > 2 && prev != null
        val mid = hasUrl || hasPageText || turns > 6 || q.length > 120 || explain
        if (mid) return remember(if (shortFollowUp && prev == GeminiModels.HYDROGEN.id) prev!! else GeminiModels.FLASH.id)
        // 짧은 이어 묻기는 앞 질문과 같은 모델로 (대화 흐름이 끊기지 않게)
        if (shortFollowUp) return remember(prev!!)
        return remember(GeminiModels.LITE.id)
    }

    private fun remember(id: String): String {
        val m = live(id)
        lastChat = m
        return m
    }

    /** [model] 이 실패했을 때 차례로 써 볼 다른 모델들 (없어진 모델은 뺀다) */
    fun fallbacks(model: String): List<String> {
        val order = when (model) {
            GeminiModels.HYDROGEN.id -> listOf(GeminiModels.PRO.id, GeminiModels.FLASH.id, GeminiModels.LITE.id)
            GeminiModels.LITE.id -> listOf(GeminiModels.FLASH.id, GeminiModels.HYDROGEN.id, GeminiModels.PRO.id)
            GeminiModels.PRO.id -> listOf(GeminiModels.HYDROGEN.id, GeminiModels.FLASH.id, GeminiModels.LITE.id)
            else -> listOf(GeminiModels.HYDROGEN.id, GeminiModels.PRO.id, GeminiModels.LITE.id)
        }
        return order.filter { it !in dead }
    }

    /** 없어진 걸로 알려진 모델이면 다른 모델로 바꾼다 */
    fun live(model: String): String =
        if (model !in dead) model else fallbacks(model).firstOrNull() ?: model

    /** 지금 쓰는 모델 이름 (AI 창 위쪽 표시용) */
    fun label(model: String): String = GeminiModels.byId(model).label
}

/**
 * Gemini 3.x 는 따로 정하지 않으면 매번 길게 "생각"한 뒤에야 첫 글자를 보내서 느리다.
 * 요청에 thinkingLevel 을 넣어 생각 시간을 줄인다. 모델이 이 설정을 거부하면(400) 그 모델은 설정 없이 다시 보낸다.
 */
object GeminiThinking {
    const val MINIMAL = "minimal"
    const val LOW = "low"

    private val unsupported: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /**
     * [gen] (generationConfig) 에 생각 설정을 넣는다. 넣었으면 true.
     * [includeThoughts] 이면 모델이 "생각한 내용의 요약"도 함께 보내 달라고 한다 (AI 사고 과정 표시용).
     */
    fun apply(gen: JSONObject, model: String, level: String, includeThoughts: Boolean = false): Boolean {
        if (level.isEmpty() || model in unsupported) return false
        val cfg = JSONObject().put("thinkingLevel", level)
        if (includeThoughts) cfg.put("includeThoughts", true)
        gen.put("thinkingConfig", cfg)
        return true
    }

    /** 400 오류가 생각 설정 때문이면 그 모델을 기억해 두고 true (같은 요청을 설정 없이 다시 보내면 된다) */
    fun rejected(code: Int, body: String?, model: String, applied: Boolean): Boolean {
        if (!applied || code != 400 || body == null || !body.contains("thinking", ignoreCase = true)) return false
        unsupported.add(model)
        return true
    }
}

/**
 * Google 검색 연결(grounding). 켜 두면 모델이 필요하다고 판단할 때만 웹을 검색해서 답하고,
 * 어떤 말로 검색했고 어느 사이트를 참고했는지 응답에 함께 실려 온다 (앱은 이걸 출처 칩으로 보여 준다).
 * 모델이 이 도구를 거부하면(400) 그 모델은 검색 없이 다시 보낸다.
 */
object GeminiSearch {
    private val unsupported: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** [body] (요청 본문) 에 검색 도구를 넣는다. 넣었으면 true */
    fun apply(body: JSONObject, model: String, on: Boolean): Boolean {
        if (!on || model in unsupported) return false
        body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return true
    }

    /** 400 오류가 검색 도구 때문이면 그 모델을 기억해 두고 true (같은 요청을 검색 없이 다시 보내면 된다) */
    fun rejected(code: Int, body: String?, model: String, applied: Boolean): Boolean {
        if (!applied || code != 400 || body == null) return false
        val b = body.lowercase()
        if (!b.contains("google_search") && !b.contains("googlesearch") && !b.contains("tool")) return false
        unsupported.add(model)
        return true
    }
}

/** AI 에게 같이 보낼 사진 한 장. [base64] 는 JPEG 를 Base64 로 인코딩한 것, [label] 은 사진 설명(alt 등) */
class PageImage(val mime: String, val base64: String, val label: String)

/** AI 가 웹 검색으로 참고한 출처 한 곳. [title] 은 보통 사이트 이름(도메인), [url] 은 누르면 열 주소 */
data class SearchSource(val title: String, val url: String) {
    /** 아이콘을 구하는 데 쓸 사이트 주소 (검색 결과 주소는 중간 전달 주소라서 제목의 도메인을 쓴다) */
    val iconUrl: String?
        get() {
            val t = title.trim().lowercase()
            return if (t.contains('.') && !t.contains(' ') && !t.contains('/')) "https://$t" else null
        }
}

data class ChatMsg(val role: String, var text: String, val images: List<PageImage> = emptyList()) {
    /** AI 가 답하기 전에 정리한 생각의 요약 (모델이 보내 준 경우만) */
    var thought: String = ""

    /** 질문을 받고 첫 답이 나오기까지 걸린 시간(ms). 0 이면 모름 */
    var thinkMs: Long = 0L

    /** AI 가 웹에서 검색한 말들 */
    var searchQueries: List<String> = emptyList()

    /** AI 가 웹 검색으로 참고한 출처들 (검색을 했을 때만) */
    var sources: List<SearchSource> = emptyList()
}

/**
 * 지금 보고 있는 웹페이지의 내용 (AI 에게 참고 자료로 보낸다).
 * [images] 는 AI 에게 실제로 첨부한 사진, [imageTotal] 은 페이지에서 찾은 (의미 있는 크기의) 사진 수.
 */
data class PageSnapshot(
    val url: String,
    val title: String,
    val text: String,
    val selection: String,
    val images: List<PageImage> = emptyList(),
    val imageTotal: Int = 0
)

/** API 키를 기기 보안 저장소(Android Keystore)의 키로 암호화해서 저장한다. */
object KeyVault {
    private const val ALIAS = "evergreen_ai_key"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, secretKey())
            val iv = c.iv
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            "e:" + Base64.encodeToString(iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) {
            // 보안 저장소를 쓸 수 없는 기기: 앱 전용 저장소에 그대로 저장
            "p:$plain"
        }
    }

    fun decrypt(stored: String): String? {
        if (stored.startsWith("p:")) return stored.substring(2)
        if (!stored.startsWith("e:")) return null
        return try {
            val all = Base64.decode(stored.substring(2), Base64.NO_WRAP)
            val iv = all.copyOfRange(0, 12)
            val ct = all.copyOfRange(12, all.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}

/** Gemini API (generativelanguage.googleapis.com) 스트리밍 호출. 반드시 백그라운드 스레드에서 부른다. */
class GeminiClient {
    private companion object {
        const val MAX_OUTPUT_TOKENS = 65536
        const val MAX_CONTINUE = 4
    }

    @Volatile
    private var conn: HttpURLConnection? = null

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
        try {
            conn?.disconnect()
        } catch (e: Exception) {
            // 이미 끝난 연결
        }
    }

    fun stream(
        apiKey: String,
        model: String,
        system: String,
        history: List<ChatMsg>,
        onDelta: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
        json: Boolean = false,
        thinking: String = GeminiThinking.MINIMAL,
        search: Boolean = false,
        includeThoughts: Boolean = false,
        onThought: (String) -> Unit = {},
        onGrounding: (List<String>, List<SearchSource>) -> Unit = { _, _ -> }
    ) {
        cancelled = false
        var curModel = GeminiAuto.live(model)
        var curKey = apiKey
        val tried = mutableSetOf(curModel)
        val triedKeys = mutableSetOf<String>()
        // 답이 토큰 한도로 잘리거나 연결이 중간에 끊기면, 받은 부분을 붙여서 "이어서 써 줘" 로 자동 재요청한다.
        val msgs = history.toMutableList()
        var total = 0
        var round = 0
        var busyRetries = 0
        while (true) {
            val roundText = StringBuilder()
            GeminiKeyPool.used(curKey)
            val r = once(curKey, curModel, system, msgs, json, thinking, search, includeThoughts, onThought, onGrounding) { d ->
                roundText.append(d)
                total += d.length
                onDelta(d)
            }
            if (cancelled) { onDone(); return }
            when {
                r.error != null && r.fatal -> {
                    // 글자를 하나도 못 받았고 모델 쪽 문제(없음·한도·서버 오류)면 다른 모델로 바로 다시 보낸다
                    // 키 한도(429)가 찼거나 키가 거부됐으면 다른 키로 같은 요청을 다시 보낸다
                    // (한도가 아닌 429 는 서버가 붐비는 것이라 키를 쉬게 하거나 바꾸지 않는다)
                    val quota429 = r.code == 429 && GeminiKeyPool.isQuota(r.body)
                    if (total == 0 && (quota429 || r.badKey)) {
                        GeminiKeyPool.onLimit(curKey, curModel, r.body, r.badKey)
                        triedKeys.add(curKey)
                        val altKey = GeminiKeyPool.alternative(triedKeys, curModel)
                        if (altKey != null) {
                            GeminiKeyPool.notifySwitch(curKey, altKey, r.badKey)
                            curKey = altKey
                            continue
                        }
                    }
                    if (r.code == 404) GeminiAuto.markDead(curModel)
                    // Gemini 4 Hydrogen 이 이 키·지역에서 열려 있지 않으면(권한 없음 403 · 모델 없음 400) 쓸 수 없는 모델로 기억하고 다른 모델로 보낸다
                    val hydrogenDenied = curModel == GeminiModels.HYDROGEN.id && (r.code == 403 || r.code == 400)
                    if (hydrogenDenied) GeminiAuto.markDead(curModel)
                    val retryable = total == 0 && (r.code == 404 || r.code == 429 || r.code in 500..599 || hydrogenDenied)
                    val next = if (retryable) GeminiAuto.fallbacks(curModel).firstOrNull { it !in tried } else null
                    if (next != null) {
                        tried.add(next)
                        curModel = next
                        triedKeys.clear()
                        // 다음 모델에서는 막히지 않은 키로 (새로 넣은 키 포함)
                        curKey = GeminiKeyPool.forModel(curKey, next)
                        continue
                    }
                    // 서버가 붐빌 때(한도 아닌 429 · 5xx)는 다른 모델이 없으면 같은 모델로 잠깐 뒤 다시 보낸다
                    if (total == 0 && (r.code in 500..599 || (r.code == 429 && !quota429)) && busyRetries < 2) {
                        busyRetries++
                        try {
                            Thread.sleep(1500L * busyRetries)
                        } catch (e: InterruptedException) {
                            onDone(); return
                        }
                        if (cancelled) { onDone(); return }
                        continue
                    }
                    // 키를 여러 개 넣어 뒀는데도 한도로 끝나면 어느 키도 못 쓴 것이라고 알린다
                    val n = GeminiKeyPool.count()
                    onError(if (quota429 && n > 1) r.error + "\n등록한 키 ${n}개가 모두 지금은 한도예요" else r.error)
                    return
                }
                // 정상 종료
                r.error == null && r.finish != "MAX_TOKENS" -> {
                    if (total == 0) {
                        onError(
                            when {
                                r.blocked.isNotEmpty() -> "요청이 안전 정책에 의해 차단되었어요 (${r.blocked})"
                                r.finish.isNotEmpty() -> "응답이 비어 있어요 (${r.finish})"
                                else -> "응답이 비어 있어요"
                            }
                        )
                    } else onDone()
                    return
                }
            }
            // 여기까지 오면: 토큰 한도로 잘렸거나(MAX_TOKENS) 중간에 연결이 끊긴 경우
            round++
            if (roundText.isEmpty() || round > MAX_CONTINUE) {
                if (total > 0 && r.error == null) onDone()
                else onError(r.error ?: "응답이 중간에 끊겼어요")
                return
            }
            msgs.add(ChatMsg("model", roundText.toString()))
            msgs.add(ChatMsg("user", "끊긴 바로 그 지점부터 이어서 계속 써 줘. 앞에 쓴 내용은 반복하지 말고, 인사말이나 설명 없이 본문만 이어 써."))
        }
    }

    private class Round(
        val finish: String,
        val blocked: String,
        val error: String?,
        val fatal: Boolean,
        val code: Int = 0,
        val badKey: Boolean = false,
        val body: String = ""
    )

    /** 요청 한 번. 받은 글자는 [onText] 로 흘려 보낸다. */
    private fun once(
        apiKey: String,
        model: String,
        system: String,
        history: List<ChatMsg>,
        json: Boolean,
        thinking: String,
        search: Boolean,
        includeThoughts: Boolean,
        onThought: (String) -> Unit,
        onGrounding: (List<String>, List<SearchSource>) -> Unit,
        onText: (String) -> Unit
    ): Round {
        var c: HttpURLConnection? = null
        var got = false
        var blocked = ""
        var finish = ""
        // 검색한 말과 참고한 출처 (응답 조각마다 실려 올 수 있어서 모아 둔다)
        val queries = LinkedHashSet<String>()
        val sources = LinkedHashMap<String, SearchSource>()
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            c = url.openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 300000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)

            val contents = JSONArray()
            for (m in history) {
                val parts = JSONArray()
                // 사진은 글보다 앞에 둔다 (Gemini 권장 순서)
                for (img in m.images) {
                    parts.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject().put("mimeType", img.mime).put("data", img.base64)
                        )
                    )
                }
                parts.put(JSONObject().put("text", m.text))
                contents.put(JSONObject().put("role", m.role).put("parts", parts))
            }
            val body = JSONObject().put("contents", contents)
            val gen = JSONObject().put("maxOutputTokens", MAX_OUTPUT_TOKENS)
            if (json) gen.put("responseMimeType", "application/json")
            val thinkApplied = GeminiThinking.apply(gen, model, thinking, includeThoughts)
            // JSON 으로만 답하게 하는 요청에는 검색 도구를 같이 쓸 수 없다
            val searchApplied = GeminiSearch.apply(body, model, search && !json)
            body.put("generationConfig", gen)
            if (system.isNotBlank()) {
                body.put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
            }
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = try {
                    c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
                // 이 모델이 생각 설정을 모르면 설정 없이 한 번 더 보낸다
                if (GeminiThinking.rejected(code, err, model, thinkApplied)) {
                    return once(apiKey, model, system, history, json, thinking, search, includeThoughts, onThought, onGrounding, onText)
                }
                // 이 모델이 검색 도구를 모르면 검색 없이 한 번 더 보낸다
                if (GeminiSearch.rejected(code, err, model, searchApplied)) {
                    return once(apiKey, model, system, history, json, thinking, search, includeThoughts, onThought, onGrounding, onText)
                }
                val bad = code == 401 || code == 403 || (code == 400 && (err ?: "").contains("API key", ignoreCase = true))
                return Round("", "", describeError(code, err), true, code, bad, err ?: "")
            }

            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.substring(5).trim()
                    if (data.isEmpty() || data == "[DONE]") continue
                    val o = JSONObject(data)
                    val br = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                    if (br.isNotEmpty()) blocked = br
                    val cand = o.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                    val fr = cand.optString("finishReason")
                    if (fr.isNotEmpty()) finish = fr
                    // 웹 검색을 했다면: 검색한 말과 참고한 사이트 목록이 실려 온다
                    val gm = cand.optJSONObject("groundingMetadata")
                    if (gm != null) {
                        val before = queries.size + sources.size
                        gm.optJSONArray("webSearchQueries")?.let { qa ->
                            for (i in 0 until qa.length()) {
                                val q = qa.optString(i, "").trim()
                                if (q.isNotEmpty()) queries.add(q)
                            }
                        }
                        gm.optJSONArray("groundingChunks")?.let { ca ->
                            for (i in 0 until ca.length()) {
                                val web = ca.optJSONObject(i)?.optJSONObject("web") ?: continue
                                val u = web.optString("uri", "")
                                if (u.isEmpty() || sources.containsKey(u)) continue
                                val title = web.optString("title", "").ifBlank { u }
                                sources[u] = SearchSource(title, u)
                            }
                        }
                        if (queries.size + sources.size != before) {
                            onGrounding(queries.toList(), sources.values.toList())
                        }
                    }
                    val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until parts.length()) {
                        val p = parts.optJSONObject(i) ?: continue
                        if (p.optBoolean("thought", false)) {
                            // 모델이 정리한 생각의 요약: 답이 아니라 사고 과정 표시용으로만 넘긴다
                            val th = p.optString("text", "")
                            if (th.isNotEmpty()) onThought(th)
                            continue
                        }
                        val t = p.optString("text", "")
                        if (t.isNotEmpty()) {
                            got = true
                            onText(t)
                        }
                    }
                }
            }
            // finishReason 없이 스트림이 끝났다면 중간에 끊긴 것으로 본다
            if (got && finish.isEmpty() && !cancelled) {
                return Round("", blocked, "응답이 중간에 끊겼어요", false)
            }
            return Round(finish, blocked, null, false)
        } catch (e: Exception) {
            val msg = "네트워크 오류: ${e.message ?: e.javaClass.simpleName}"
            // 글자를 하나라도 받은 뒤의 오류는 이어받기를 시도하고, 처음부터 실패한 건 바로 오류로 알린다
            return Round(finish, blocked, msg, !got)
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
                // 무시
            }
            conn = null
        }
    }

    private fun describeError(code: Int, body: String?): String {
        val msg = try {
            JSONObject(body ?: "").optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        val head = when (code) {
            400 -> "요청이 올바르지 않거나 API 키가 잘못되었어요"
            401, 403 -> "API 키가 거부되었어요. 키와 사용 권한을 확인해 주세요"
            404 -> "모델을 찾을 수 없어요"
            429 -> if (GeminiKeyPool.isQuota(body)) "요청 한도를 넘었어요. 잠시 후 다시 시도해 주세요"
            else "Gemini 서버가 지금 붐벼서 요청을 처리하지 못했어요. 한도 문제는 아니에요. 잠시 후 다시 시도해 주세요 (429)"
            in 500..599 -> "Gemini 서버에 문제가 있어요. 잠시 후 다시 시도해 주세요"
            else -> "오류가 났어요 ($code)"
        }
        // 구글이 주는 설명은 영어라서 한글이 든 것만 덧붙이고, 나머지는 위의 한국어 안내만 보여 준다
        return if (msg.isNullOrBlank() || !msg.any { it in '가'..'힣' }) head else "$head\n$msg"
    }
}
