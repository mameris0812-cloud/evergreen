package com.example.evergreen

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 에이전트 2단계: 앱 조작 도구.
 * - 읽기(자동): 방문 기록 · 북마크 검색, 현재 설정 보기, 확장 프로그램 목록
 * - 변경(요청당 한 번 확인): 탭 열기 · 닫기 · 전환, 주소 이동, 뒤로/앞으로/새로고침, 북마크 추가, 설정 변경, 확장 켜기/끄기
 * - 위험(매번 확인): 파일 다운로드
 * 모두 [AgentHost] 만 통해 앱을 만진다.
 */
object AgentAppTools {
    fun build(): List<AgentTool> = listOf(
        searchHistory(), searchBookmarks(), getSettings(), listExtensions(),
        openTab(), closeTab(), switchTab(), goTo(), pageNav(), addBookmark(), changeSetting(), setExtension(),
        downloadFile()
    )

    private fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n) + "…"

    private fun stamp(t: Long): String =
        if (t <= 0L) "" else SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date(t))

    /** 조작 결과를 도구 결과로 바꾼다. 실패하면 이유를 그대로 돌려줘서 모델이 다른 방법을 고르게 한다 */
    private fun outcome(o: AgentOutcome): AgentResult {
        if (!o.ok) return AgentResult.fail(o.message)
        val d = JSONObject().put("message", o.message)
        if (o.number > 0) d.put("tab_number", o.number)
        if (o.tabCount > 0) d.put("tab_count", o.tabCount)
        return AgentResult.ok(d, o.message)
    }

    // ───────────────────────── 되돌리기 도우미 ─────────────────────────

    /** 번호와 주소가 모두 맞는 탭을 찾는다. 번호가 밀렸으면 주소가 같은 탭을 찾는다 (주소가 비어 있으면 번호가 같은 빈 탭만) */
    private fun findTab(tabs: List<AgentTab>, index: Int, url: String): AgentTab? =
        tabs.firstOrNull { it.index == index && it.url == url }
            ?: if (url.isNotEmpty()) tabs.firstOrNull { it.url == url } else null

    private val TAB_GONE = "그 탭은 이미 닫혔거나 바뀌어서 그대로 뒀어요"

    // ───────────────────────── 읽기 ─────────────────────────

    private fun searchHistory() = AgentTool(
        name = "search_history",
        description = "방문 기록에서 제목이나 주소에 검색어가 들어간 페이지를 최근 방문 순으로 찾습니다. query 를 비우면 가장 최근 기록을 돌려줍니다.",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "query" to AgentSchema.str("찾을 말 (비워도 됨)"),
                "limit" to AgentSchema.int("가져올 개수 (기본 10, 최대 30)")
            )
        ),
        doing = { a ->
            val q = a.optString("query").trim()
            if (q.isEmpty()) "최근 방문 기록 보는 중…" else "방문 기록 검색 중: ${short(q, 20)}…"
        },
        run = { a, ctx ->
            val limit = a.optInt("limit", 10).coerceIn(1, 30)
            val list = ctx.host.history(a.optString("query").trim(), limit)
            val arr = JSONArray()
            for (p in list) {
                arr.put(
                    JSONObject().put("title", p.title.take(120)).put("url", p.url.take(300)).put("visited", stamp(p.time))
                )
            }
            // 기록의 제목은 웹페이지가 정한 글이라 자료로만 다룬다
            AgentResult.ok(JSONObject().put("count", list.size).put("pages", arr), "방문 기록 ${list.size}건을 찾았어요", untrusted = true)
        }
    )

    private fun searchBookmarks() = AgentTool(
        name = "search_bookmarks",
        description = "북마크에서 제목이나 주소에 검색어가 들어간 것을 찾습니다. query 를 비우면 최근에 추가한 북마크를 돌려줍니다.",
        risk = AgentRisk.READ,
        params = AgentSchema.obj(
            listOf(
                "query" to AgentSchema.str("찾을 말 (비워도 됨)"),
                "limit" to AgentSchema.int("가져올 개수 (기본 10, 최대 30)")
            )
        ),
        doing = { a ->
            val q = a.optString("query").trim()
            if (q.isEmpty()) "북마크 보는 중…" else "북마크 검색 중: ${short(q, 20)}…"
        },
        run = { a, ctx ->
            val limit = a.optInt("limit", 10).coerceIn(1, 30)
            val list = ctx.host.bookmarks(a.optString("query").trim(), limit)
            val arr = JSONArray()
            for (b in list) {
                val o = JSONObject().put("title", b.title.take(120)).put("url", b.url.take(300))
                if (b.folder.isNotEmpty()) o.put("folder", b.folder.take(60))
                arr.put(o)
            }
            AgentResult.ok(JSONObject().put("count", list.size).put("bookmarks", arr), "북마크 ${list.size}개를 찾았어요", untrusted = true)
        }
    )

    private fun getSettings() = AgentTool(
        name = "get_settings",
        description = "앱의 현재 설정 값을 돌려줍니다. change_setting 으로 바꿀 수 있는 것은 web_dark_mode · ad_block · bookmark_bar · text_zoom 입니다. " +
            "나머지(desktop_site · homepage · search_engine)는 읽기만 됩니다.",
        risk = AgentRisk.READ,
        doing = { "현재 설정 확인하는 중…" },
        run = { _, ctx -> AgentResult.ok(ctx.host.settings(), "현재 설정을 확인했어요") }
    )

    private fun listExtensions() = AgentTool(
        name = "list_extensions",
        description = "설치된 확장 프로그램(테마 제외)의 id · 이름 · 버전 · 켜짐 여부를 돌려줍니다.",
        risk = AgentRisk.READ,
        doing = { "확장 프로그램 확인하는 중…" },
        run = { _, ctx ->
            val list = ctx.host.extensions()
            val arr = JSONArray()
            for (e in list) {
                arr.put(JSONObject().put("id", e.id).put("name", e.name.take(80)).put("version", e.version).put("enabled", e.enabled))
            }
            AgentResult.ok(JSONObject().put("count", list.size).put("extensions", arr), "확장 프로그램 ${list.size}개를 확인했어요", untrusted = true)
        }
    )

    // ───────────────────────── 변경 ─────────────────────────

    private fun tabTitleOf(ctx: AgentContext, number: Int): String {
        val t = ctx.host.tabs().firstOrNull { it.index == number } ?: return "${number}번 탭"
        return "${number}번 탭 (${short(t.title.ifBlank { t.url }, 30)})"
    }

    private fun openTab() = AgentTool(
        name = "open_tab",
        description = "새 탭을 엽니다. target 에 주소나 검색어를 주면 그 페이지를, 비우면 빈 새 탭을 엽니다. " +
            "background 가 true 면 지금 보던 탭을 그대로 두고 뒤에서 엽니다. 시크릿 탭은 설정에서 허용했을 때만 됩니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "target" to AgentSchema.str("열 주소(https://…)나 검색어. 비우면 빈 새 탭"),
                "background" to AgentSchema.flag("true 면 뒤에서 열기 (기본 false)"),
                "incognito" to AgentSchema.flag("true 면 시크릿 탭 (기본 false)")
            )
        ),
        doing = { a ->
            val t = a.optString("target").trim()
            if (t.isEmpty()) "새 탭 여는 중…" else "새 탭 여는 중: ${short(t, 28)}…"
        },
        run = { a, ctx ->
            outcome(ctx.host.openTab(a.optString("target"), a.optBoolean("incognito", false), a.optBoolean("background", false)))
        },
        undoPlan = { _, ctx ->
            { r ->
                val n = r.data.optInt("tab_number", 0)
                if (n <= 0) null else {
                    val url = ctx.host.tabs().firstOrNull { it.index == n }?.url.orEmpty()
                    AgentUndo("연 탭 닫기 (${n}번)") { h ->
                        val at = findTab(h.tabs(), n, url)
                        if (at == null) AgentOutcome.fail(TAB_GONE) else h.closeTab(at.index)
                    }
                }
            }
        },
        ask = { a, _ ->
            val t = a.optString("target").trim()
            val inc = if (a.optBoolean("incognito", false)) "시크릿 " else ""
            if (t.isEmpty()) "${inc}새 탭 열기" else "${inc}새 탭에서 열기: ${short(t, 60)}"
        }
    )

    private fun closeTab() = AgentTool(
        name = "close_tab",
        description = "탭 번호(list_tabs 의 number)로 탭을 닫습니다. 탭을 닫으면 뒤의 탭 번호가 하나씩 당겨지니, 여러 개를 닫을 때는 큰 번호부터 닫거나 닫은 뒤 list_tabs 로 다시 확인하세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(listOf("number" to AgentSchema.int("닫을 탭 번호 (1부터)")), listOf("number")),
        doing = { a -> "${a.optInt("number")}번 탭 닫는 중…" },
        run = { a, ctx -> outcome(ctx.host.closeTab(a.optInt("number"))) },
        undoPlan = { a, ctx ->
            val t = ctx.host.tabs().firstOrNull { it.index == a.optInt("number") }
            if (t == null || t.incognito) null else {
                { _ ->
                    AgentUndo("닫은 탭 다시 열기 (${short(t.title.ifBlank { t.url.ifBlank { "빈 탭" } }, 24)})") { h ->
                        h.openTab(t.url, false, true)
                    }
                }
            }
        },
        ask = { a, ctx -> "탭 닫기: " + tabTitleOf(ctx, a.optInt("number")) }
    )

    private fun switchTab() = AgentTool(
        name = "switch_tab",
        description = "탭 번호(list_tabs 의 number)의 탭으로 옮겨 가서 그 탭을 보이게 합니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(listOf("number" to AgentSchema.int("옮겨 갈 탭 번호 (1부터)")), listOf("number")),
        doing = { a -> "${a.optInt("number")}번 탭으로 옮기는 중…" },
        run = { a, ctx -> outcome(ctx.host.switchTab(a.optInt("number"))) },
        undoPlan = { _, ctx ->
            val from = ctx.host.tabs().firstOrNull { it.current }
            if (from == null) null else {
                { _ ->
                    AgentUndo("보던 탭으로 돌아가기 (${from.index}번)") { h ->
                        val at = findTab(h.tabs(), from.index, from.url)
                        if (at == null) AgentOutcome.fail(TAB_GONE) else h.switchTab(at.index)
                    }
                }
            }
        },
        ask = { a, ctx -> "탭 옮기기: " + tabTitleOf(ctx, a.optInt("number")) }
    )

    private fun goTo() = AgentTool(
        name = "go_to",
        description = "지금 보고 있는 탭(또는 tab_number 로 고른 탭)에서 주소나 검색어로 이동합니다. 새 탭에서 열려면 open_tab 을 쓰세요.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "target" to AgentSchema.str("이동할 주소(https://…)나 검색어"),
                "tab_number" to AgentSchema.int("이동할 탭 번호 (비우면 지금 탭)")
            ),
            listOf("target")
        ),
        doing = { a -> "이동하는 중: ${short(a.optString("target").trim(), 28)}…" },
        run = { a, ctx -> outcome(ctx.host.navigate(a.optString("target"), a.optInt("tab_number", 0))) },
        undoPlan = { _, _ ->
            { r ->
                val n = r.data.optInt("tab_number", 0)
                if (n <= 0) null else AgentUndo("이동 되돌리기 (${n}번 탭, 뒤로 가기)") { h ->
                    if (h.tabs().none { it.index == n }) AgentOutcome.fail(TAB_GONE)
                    else {
                        val sw = h.switchTab(n)
                        if (sw.ok) h.pageNav("back") else sw
                    }
                }
            }
        },
        ask = { a, _ -> "이동하기: ${short(a.optString("target").trim(), 60)}" }
    )

    private fun pageNav() = AgentTool(
        name = "page_nav",
        description = "지금 탭에서 뒤로 가기(back) · 앞으로 가기(forward) · 새로고침(reload) · 불러오기 중지(stop) 를 합니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf("action" to AgentSchema.oneOf("할 동작", "back", "forward", "reload", "stop")),
            listOf("action")
        ),
        doing = { a ->
            when (a.optString("action")) {
                "back" -> "뒤로 가는 중…"
                "forward" -> "앞으로 가는 중…"
                "reload" -> "새로고침하는 중…"
                "stop" -> "불러오기를 멈추는 중…"
                else -> "페이지 이동 중…"
            }
        },
        run = { a, ctx -> outcome(ctx.host.pageNav(a.optString("action"))) },
        undoPlan = { a, ctx ->
            val opposite = when (a.optString("action")) {
                "back" -> "forward"
                "forward" -> "back"
                else -> null
            }
            val cur = ctx.host.tabs().firstOrNull { it.current }
            if (opposite == null || cur == null) null else {
                { _ ->
                    AgentUndo(if (opposite == "forward") "뒤로 간 것 되돌리기" else "앞으로 간 것 되돌리기") { h ->
                        // 다른 탭을 보고 있으면 엉뚱한 탭이 움직이지 않게 그대로 둔다
                        if (h.tabs().firstOrNull { it.current }?.index != cur.index) AgentOutcome.fail("다른 탭을 보고 있어서 그대로 뒀어요")
                        else h.pageNav(opposite)
                    }
                }
            }
        },
        ask = { a, _ ->
            when (a.optString("action")) {
                "back" -> "뒤로 가기"
                "forward" -> "앞으로 가기"
                "reload" -> "새로고침"
                "stop" -> "불러오기 멈추기"
                else -> "페이지 이동"
            }
        }
    )

    private fun addBookmark() = AgentTool(
        name = "add_bookmark",
        description = "지금 보는 탭(또는 tab_number 로 고른 탭)의 페이지를 북마크에 추가합니다. 새 탭 · 시크릿 탭은 추가할 수 없습니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(listOf("tab_number" to AgentSchema.int("북마크할 탭 번호 (비우면 지금 탭)"))),
        doing = { "북마크에 추가하는 중…" },
        run = { a, ctx -> outcome(ctx.host.addBookmark(a.optInt("tab_number", 0))) },
        undoPlan = { a, ctx ->
            val n = a.optInt("tab_number", 0)
            val tabs = ctx.host.tabs()
            val t = if (n > 0) tabs.firstOrNull { it.index == n } else tabs.firstOrNull { it.current }
            if (t == null || t.url.isEmpty()) null else {
                { r ->
                    // 이미 북마크에 있던 것은 우리가 더한 게 아니니 지우지 않는다
                    if (r.data.optString("message").startsWith("이미")) null
                    else AgentUndo("추가한 북마크 지우기 (${short(t.title.ifBlank { t.url }, 24)})") { h -> h.removeBookmark(t.url) }
                }
            }
        },
        ask = { a, ctx ->
            val n = a.optInt("tab_number", 0)
            if (n > 0) "북마크에 추가: " + tabTitleOf(ctx, n) else "지금 페이지를 북마크에 추가"
        }
    )

    private fun changeSetting() = AgentTool(
        name = "change_setting",
        description = "앱 설정을 바꿉니다. 바꿀 수 있는 설정: " +
            "web_dark_mode(off · device · always), ad_block(on · off), bookmark_bar(on · off), text_zoom(50~200 사이 숫자, 10 단위). " +
            "그 밖의 설정은 바꿀 수 없다고 사용자에게 알리세요. 먼저 get_settings 로 현재 값을 보면 좋습니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "name" to AgentSchema.oneOf("바꿀 설정 이름", "web_dark_mode", "ad_block", "bookmark_bar", "text_zoom"),
                "value" to AgentSchema.str("새 값 (예: always · on · off · 120)")
            ),
            listOf("name", "value")
        ),
        doing = { a -> "설정 바꾸는 중: ${settingLabel(a.optString("name"))}…" },
        run = { a, ctx -> outcome(ctx.host.setSetting(a.optString("name"), a.optString("value"))) },
        undoPlan = { a, ctx ->
            val name = a.optString("name")
            val st = ctx.host.settings()
            val old: String? = when (name) {
                "web_dark_mode" -> st.optString("web_dark_mode").substringBefore(' ').ifEmpty { null }
                "ad_block" -> if (st.has("ad_block")) (if (st.optBoolean("ad_block")) "on" else "off") else null
                "bookmark_bar" -> if (st.has("bookmark_bar")) (if (st.optBoolean("bookmark_bar")) "on" else "off") else null
                "text_zoom" -> if (st.has("text_zoom_percent")) st.optInt("text_zoom_percent").toString() else null
                else -> null
            }
            if (old == null) null else {
                { _ ->
                    AgentUndo("설정 되돌리기: ${settingLabel(name)} → $old") { h -> h.setSetting(name, old) }
                }
            }
        },
        ask = { a, _ -> "설정 바꾸기: ${settingLabel(a.optString("name"))} → ${short(a.optString("value"), 20)}" }
    )

    private fun settingLabel(name: String): String = when (name) {
        "web_dark_mode" -> "웹 페이지 다크 모드"
        "ad_block" -> "광고 차단"
        "bookmark_bar" -> "북마크바"
        "text_zoom" -> "글자 크기"
        else -> name
    }

    /** id → 이름(대소문자 무시) → 이름 일부 순으로 확장 프로그램을 찾는다 */
    private fun findExtensions(all: List<AgentExt>, key: String): List<AgentExt> {
        val exact = all.filter { it.id == key }
        if (exact.isNotEmpty()) return exact
        val byName = all.filter { it.name.equals(key, ignoreCase = true) }
        return if (byName.isNotEmpty()) byName else all.filter { key.isNotEmpty() && it.name.contains(key, ignoreCase = true) }
    }

    private fun setExtension() = AgentTool(
        name = "set_extension",
        description = "확장 프로그램을 켜거나 끕니다. extension 에는 list_extensions 의 id 나 이름을 줍니다. 테마는 다룰 수 없습니다.",
        risk = AgentRisk.CHANGE,
        params = AgentSchema.obj(
            listOf(
                "extension" to AgentSchema.str("확장 프로그램 id 또는 이름"),
                "enabled" to AgentSchema.flag("true 면 켜기, false 면 끄기")
            ),
            listOf("extension", "enabled")
        ),
        doing = { a -> (if (a.optBoolean("enabled")) "확장 켜는 중: " else "확장 끄는 중: ") + short(a.optString("extension"), 24) + "…" },
        run = { a, ctx ->
            val key = a.optString("extension").trim()
            val found = findExtensions(ctx.host.extensions(), key)
            when {
                found.isEmpty() -> AgentResult.fail("그런 확장 프로그램이 없어요: $key (list_extensions 로 확인하세요)")
                found.size > 1 -> AgentResult.fail("이름이 겹쳐서 하나로 못 골랐어요: " + found.joinToString(", ") { "${it.name}(${it.id})" } + " — id 로 다시 불러 주세요")
                else -> outcome(ctx.host.setExtension(found[0].id, a.optBoolean("enabled")))
            }
        },
        undoPlan = { a, ctx ->
            val before = findExtensions(ctx.host.extensions(), a.optString("extension").trim()).singleOrNull()
            // 원래 이미 그 상태였다면 되돌릴 게 없다
            if (before == null || before.enabled == a.optBoolean("enabled")) null else {
                { _ ->
                    AgentUndo((if (before.enabled) "다시 켜기: " else "다시 끄기: ") + short(before.name, 24)) { h -> h.setExtension(before.id, before.enabled) }
                }
            }
        },
        ask = { a, ctx ->
            val key = a.optString("extension").trim()
            val name = ctx.host.extensions().firstOrNull { it.id == key || it.name.equals(key, ignoreCase = true) }?.name ?: key
            (if (a.optBoolean("enabled")) "확장 프로그램 켜기: " else "확장 프로그램 끄기: ") + short(name, 40)
        }
    )

    // ───────────────────────── 위험 ─────────────────────────

    private fun downloadFile() = AgentTool(
        name = "download_file",
        description = "주소(url)의 파일을 기기에 내려받기 시작합니다. 사용자가 파일을 내려받으라고 분명히 시켰을 때만 쓰세요. 실행할 때마다 사용자의 확인을 받습니다.",
        risk = AgentRisk.DANGER,
        params = AgentSchema.obj(listOf("url" to AgentSchema.str("내려받을 파일의 http(s) 주소")), listOf("url")),
        doing = { a -> "다운로드 시작하는 중: ${short(a.optString("url").trim(), 28)}…" },
        run = { a, ctx -> outcome(ctx.host.download(a.optString("url"))) },
        ask = { a, _ -> "파일 다운로드: ${short(a.optString("url").trim(), 80)}" }
    )
}
