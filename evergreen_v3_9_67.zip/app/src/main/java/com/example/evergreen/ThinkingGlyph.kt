package com.example.evergreen

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.SpringAnimation
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * AI 가 지금 무슨 생각을 하고 있는지(사고 과정의 종류).
 * 종류마다 입력 중 애니메이션의 모양·움직임·색이 달라지고, 바뀔 때는 모양이 이어서 변한다.
 */
enum class ThinkKind(val label: String) {
    /** 일반 생각: 점 세 개가 물결처럼 */
    THINK("생각하는 중…"),

    /** 페이지 읽기: 글줄이 위에서 아래로 차례로 읽힌다 */
    READ("페이지 읽는 중…"),

    /** 사진 보기: 세 점이 렌즈 조리개처럼 모였다 퍼진다 */
    LOOK("사진 살펴보는 중…"),

    /** 웹 검색: 꼬리가 달린 점이 원을 그리며 훑는다 */
    SEARCH("웹에서 찾는 중…"),

    /** 분석·비교·계산: 막대가 오르내린다 */
    ANALYZE("따져 보는 중…"),

    /** 답 정리·초안: 줄이 왼쪽에서 오른쪽으로 써진다 */
    WRITE("답 정리하는 중…");

    companion object {
        private val headingRe = Regex("\\*\\*([^*\\n]{2,90})\\*\\*")

        /**
         * 모델이 보내 준 생각 요약에서 지금 하고 있는 일을 읽어 낸다.
         * 요약은 「**제목**」으로 시작하는 토막이 이어지므로, 가장 마지막 제목의 낱말로 고른다.
         * 제목이 아직 없으면 null (지금 모양을 그대로 둔다).
         */
        fun classify(thought: String): ThinkKind? {
            val h = headingRe.findAll(thought).lastOrNull()?.groupValues?.get(1)?.lowercase() ?: return null
            fun has(vararg ks: String) = ks.any { h.contains(it) }
            return when {
                has("search", "look up", "looking up", "browsing", "fact-check", "fact check", "검색", "찾아", "찾는", "찾기", "조회", "알아보") -> SEARCH
                has("draft", "writ", "compos", "formulat", "structur", "outline", "organiz", "organis", "finaliz", "polish", "refin", "summar", "작성", "정리", "구성", "초안", "다듬", "요약") -> WRITE
                has("image", "photo", "picture", "visual", "screenshot", "사진", "이미지", "그림", "스크린샷") -> LOOK
                has("read", "page", "document", "article", "읽", "페이지", "본문", "문서") -> READ
                has("analy", "compar", "evaluat", "calculat", "weigh", "assess", "reason", "verif", "check", "분석", "비교", "계산", "따져", "검토", "평가", "확인") -> ANALYZE
                else -> THINK
            }
        }
    }
}

/**
 * AI 가 답을 준비하는 동안 보여 주는 작은 움직임 (예전 점 세 개를 대신한다).
 *
 * 세 개의 둥근 막대가 [ThinkKind] 마다 다른 모양으로 움직인다:
 * 점(생각) · 가로줄(읽기) · 조리개(사진) · 꼬리 달린 궤도(검색) · 막대(분석) · 써지는 줄(정리).
 * 종류가 바뀌면 지금 모양에서 새 모양으로 스프링을 타고 이어서 변하고, 색도 함께 흐른다.
 * 움직임은 멈추지 않고 계속 돌기 때문에 바뀌는 순간에도 끊기지 않는다.
 * 시스템의 "애니메이션 끄기" 설정이면 움직이지 않고 모양만 보여 준다.
 */
class ThinkingGlyphView(
    context: Context,
    kind: ThinkKind = ThinkKind.THINK,
    scale: Float = 1f
) : View(context) {

    private val d = resources.displayMetrics.density * scale
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val animate = Motion.enabled(context)

    /** 흐른 시간(초). 모든 종류의 움직임이 이 시계 하나를 쓴다 */
    private var ts = 0f

    var kind: ThinkKind = kind
        private set
    private var from: ThinkKind = kind
    private var morph = 1f
    private var morphAnim: SpringAnimation? = null

    private class S {
        var x = 0f
        var y = 0f
        var w = 0f
        var h = 0f
        var a = 1f
    }

    private val now = Array(3) { S() }
    private val old = Array(3) { S() }

    private val clock = ValueAnimator.ofFloat(0f, 3600f).apply {
        duration = 3_600_000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            ts = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        contentDescription = kind.label
    }

    /** [k] 모양으로 바꾼다. 이미 그 모양이면 아무것도 하지 않는다 */
    fun setKind(k: ThinkKind, withMorph: Boolean = true) {
        if (k == kind) return
        morphAnim?.cancel()
        from = kind
        kind = k
        contentDescription = k.label
        if (!animate || !withMorph || !isAttachedToWindow) {
            morph = 1f
            invalidate()
            return
        }
        morph = 0f
        morphAnim = Motion.springValue(
            0f, 1f, stiffness = 170f, damping = 0.78f,
            onUpdate = {
                morph = it
                invalidate()
            },
            onEnd = {
                morph = 1f
                invalidate()
            }
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animate) clock.start()
    }

    /** 보이지 않는 동안(접힌 카드 등)에는 시계를 세워 배터리를 아낀다 */
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (!animate || !isAttachedToWindow) return
        if (isShown) {
            if (!clock.isStarted) clock.start()
        } else {
            clock.cancel()
        }
    }

    override fun onDetachedFromWindow() {
        clock.cancel()
        morphAnim?.cancel()
        morph = 1f
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize((W * d).toInt() + 2, widthMeasureSpec),
            resolveSize((H * d).toInt() + 2, heightMeasureSpec)
        )
    }

    // ───────── 종류별 모양 (dp 단위, 가운데가 0,0) ─────────

    private fun smooth(x: Float): Float {
        val c = x.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    /** 0→1→0 으로 부드럽게 한 번 솟았다 가라앉는 값 ([phase] 가 1 늘 때마다 한 바퀴) */
    private fun pulse(phase: Float): Float {
        val p = phase - floor(phase)
        return 0.5f - 0.5f * cos(p * 2f * PI.toFloat())
    }

    private fun shape(k: ThinkKind, i: Int, t: Float, o: S) {
        val tau = 2f * PI.toFloat()
        when (k) {
            ThinkKind.THINK -> {
                // 점이 왼쪽부터 차례로 떠올랐다 가라앉는다
                val wave = smooth(pulse(t / 0.95f - i * 0.15f))
                val dia = 6.4f * (0.88f + 0.30f * wave)
                o.x = (i - 1) * 9.6f
                o.y = 3f - 6f * wave
                o.w = dia
                o.h = dia
                o.a = 0.47f + 0.53f * wave
            }
            ThinkKind.READ -> {
                // 글줄 세 개가 위에서 아래로 차례로 밝아지며 읽힌다
                val full = when (i) { 0 -> 17f; 1 -> 12.5f; else -> 15f }
                val sweep = smooth(pulse(t / 1.5f - i * 0.2f))
                val w = full * (0.78f + 0.22f * sweep)
                o.x = -9f + w / 2f
                o.y = (i - 1) * 6.6f
                o.w = w
                o.h = 3.4f
                o.a = 0.35f + 0.65f * sweep
            }
            ThinkKind.LOOK -> {
                // 세 점이 렌즈 조리개처럼 천천히 돌며 모였다 퍼진다
                val ang = tau * (t / 3.2f) + i * tau / 3f
                val rad = 6f + 2.4f * sin(tau * t / 1.7f)
                o.x = rad * cos(ang)
                o.y = rad * sin(ang)
                o.w = 5.6f
                o.h = 5.6f
                o.a = 0.95f
            }
            ThinkKind.SEARCH -> {
                // 꼬리가 달린 점이 원을 그리며 훑고 지나간다
                val theta = tau * (t / 1.15f) - i * 0.62f
                val dia = 6.4f * (1f - 0.2f * i)
                o.x = 6.6f * cos(theta)
                o.y = 6.6f * sin(theta)
                o.w = dia
                o.h = dia
                o.a = 1f - 0.3f * i
            }
            ThinkKind.ANALYZE -> {
                // 막대 세 개가 서로 엇갈려 오르내린다
                val s = 0.5f + 0.5f * sin(tau * t / 0.85f + i * 2.1f)
                o.x = (i - 1) * 8.2f
                o.y = 0f
                o.w = 4.2f
                o.h = 6f + 11f * smooth(s)
                o.a = 0.6f + 0.4f * s
            }
            ThinkKind.WRITE -> {
                // 짧은 줄이 왼쪽에서 오른쪽으로 하나씩 써지고, 다 쓰이면 옅어졌다 다시 시작한다
                val f = (t / 1.6f).let { it - floor(it) }
                val g = (f * 3.4f - i * 0.8f).coerceIn(0f, 1f)
                val eased = 1f - (1f - g) * (1f - g)
                val w = max(0.01f, 6.8f * eased)
                val fade = 1f - smooth((f - 0.88f) / 0.12f)
                o.x = -12.3f + i * 8.6f + w / 2f
                o.y = 0f
                o.w = w
                o.h = 3.4f
                o.a = (0.3f + 0.7f * g) * fade
            }
        }
    }

    private fun colorOf(k: ThinkKind): Int {
        val st = AiGradient.STOPS
        return when (k) {
            ThinkKind.THINK -> st[0]
            ThinkKind.READ -> st[1]
            ThinkKind.SEARCH -> st[2]
            ThinkKind.ANALYZE -> st[3]
            ThinkKind.LOOK -> AiGradient.at(0.78f)
            ThinkKind.WRITE -> AiGradient.at(0.2f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        // 움직이지 않는 설정이면 시간을 0 에 세워 두고 모양만 그린다
        val t = if (animate) ts else 0f
        val m = morph
        val morphing = m < 1f
        val mc = m.coerceIn(0f, 1f)
        val col = if (morphing) ColorUtils.blendARGB(colorOf(from), colorOf(kind), mc) else colorOf(kind)
        paint.color = col
        for (i in 0 until 3) {
            val b = now[i]
            shape(kind, i, t, b)
            var x = b.x
            var y = b.y
            var w = b.w
            var h = b.h
            var a = b.a
            if (morphing) {
                // 이전 모양도 같은 시계로 계속 움직이게 두고, 둘 사이를 스프링으로 오간다
                val o = old[i]
                shape(from, i, t, o)
                x = o.x + (b.x - o.x) * m
                y = o.y + (b.y - o.y) * m
                w = o.w + (b.w - o.w) * m
                h = o.h + (b.h - o.h) * m
                a = o.a + (b.a - o.a) * mc
            }
            w = max(0f, w) * d
            h = max(0f, h) * d
            if (w < 0.5f || h < 0.5f) continue
            paint.alpha = (a.coerceIn(0f, 1f) * 255f).toInt()
            rect.set(cx + x * d - w / 2f, cy + y * d - h / 2f, cx + x * d + w / 2f, cy + y * d + h / 2f)
            val r = min(w, h) / 2f
            canvas.drawRoundRect(rect, r, r, paint)
        }
    }

    private companion object {
        const val W = 30f
        const val H = 22f
    }
}

/** 글자를 바꿀 때 위로 살짝 떠오르며 옅어졌다가 새 글자가 아래에서 올라온다 */
object ThinkText {
    /**
     * [tv] 의 글을 [text] 로 바꾼다. [widthAnim] 이면 글 너비가 달라지는 만큼 칸이 부드럽게 늘고 줄어든다
     * (너비가 정해져 있지 않은 말풍선 안의 글에 쓴다).
     */
    fun swap(tv: TextView, text: String, widthAnim: Boolean = false) {
        if (tv.text.toString() == text) return
        if (!Motion.enabled(tv.context) || !tv.isAttachedToWindow || tv.width <= 0) {
            tv.animate().cancel()
            tv.text = text
            tv.alpha = 1f
            tv.translationY = 0f
            return
        }
        val d = tv.resources.displayMetrics.density
        val fromW = tv.width
        val toW = (tv.paint.measureText(text) + tv.paddingLeft + tv.paddingRight).toInt() + 1
        tv.animate().cancel()
        tv.animate().alpha(0f).translationY(-3f * d).setDuration(110).withEndAction {
            tv.text = text
            tv.translationY = 4f * d
            tv.animate().alpha(1f).translationY(0f).setDuration(190).start()
        }.start()
        if (widthAnim && fromW != toW) {
            val lp = tv.layoutParams
            ValueAnimator.ofInt(fromW, toW).apply {
                duration = 240
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener {
                    lp.width = it.animatedValue as Int
                    tv.layoutParams = lp
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        lp.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                        tv.layoutParams = lp
                    }
                })
                start()
            }
        }
    }
}
