package com.example.evergreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.WebResourceRequest
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.Collections
import java.util.Locale
import java.util.UUID
import java.util.WeakHashMap
import java.util.zip.ZipInputStream

/**
 * 크롬 확장 프로그램 지원.
 *
 * 안드로이드 WebView 는 크롬 확장을 그대로 돌릴 수 없어서, 확장 프로그램의 '콘텐츠 스크립트'(웹페이지에 끼워 넣는
 * JS/CSS)를 매니페스트의 주소 조건(matches)에 맞는 페이지에 직접 넣어 주고, 자주 쓰는 chrome.* API
 * (runtime · storage · i18n · tabs 일부 · alarms)를 흉내 내어 제공한다.
 * 백그라운드(service worker / background scripts)는 눈에 안 보이는 웹뷰에서 일반 페이지로 돌린다:
 * runtime.sendMessage ↔ onMessage, tabs.sendMessage(보고 있는 탭), alarms, importScripts, onInstalled/onStartup,
 * 그리고 host 권한이 있는 주소로의 fetch(CORS 없이 앱이 대신 요청)를 지원한다.
 * runtime.connect / tabs.connect(포트), storage.onChanged(창 사이 공유), scripting · tabs.executeScript · insertCSS(보고 있는 탭),
 * cookies, declarativeNetRequest(차단 · 허용 규칙: 정적 · 동적 · 세션)도 지원한다.
 * webRequest · contextMenus · declarativeNetRequest 의 헤더 고치기 · 리다이렉트도 지원한다.
 * tabs.onUpdated · onActivated · webNavigation 이벤트는 보고 있는 탭에 대해 백그라운드로 알려 주고(탭 id 는 항상 1),
 * history · bookmarks(읽기) · topSites 는 앱의 기록 · 북마크를, downloads.download · notifications.create 는 앱의 다운로드 · 알림을 쓴다.
 * 그 밖에 idle · management · commands · system · privacy · proxy 등은 크롬과 같은 모양의 기본값을 돌려줘서 확장 프로그램이 죽지 않게 한다.
 */
class ExtensionManager(private val ctx: Context) {

    class Entry(
        val matches: List<String>,
        val excludes: List<String>,
        val js: List<String>,
        val css: List<String>,
        val runAt: String,
        val allFrames: Boolean,
        val includeGlobs: List<String> = emptyList(),
        val excludeGlobs: List<String> = emptyList()
    )

    class Ext(
        val id: String,
        val name: String,
        val version: String,
        val description: String,
        val manifestVersion: Int,
        val dir: File,
        val manifest: JSONObject,
        val entries: List<Entry>,
        val hasBackground: Boolean,
        val options: String?,
        val popup: String?,
        val icon: String?,
        val messages: Map<String, String>,
        val hosts: List<Regex>,
        var enabled: Boolean
    )

    companion object {
        const val HOST = "ext.evergreen.invalid"
        private const val MAX_ZIP = 160L * 1024 * 1024
        private const val MAX_UNPACKED = 1024L * 1024 * 1024
        private const val MAX_AREA_JSON = 5_000_000
        private const val WR_TIMEOUT_MS = 1500L
        private val WR_EVENTS = setOf(
            "onBeforeRequest", "onBeforeSendHeaders", "onSendHeaders", "onHeadersReceived",
            "onBeforeRedirect", "onResponseStarted", "onCompleted", "onErrorOccurred", "onAuthRequired"
        )
        private const val STORE_CHROME_VERSION = "130.0.0.0"
        private const val MAX_MSG = 4_000_000
        private const val MAX_FETCH = 15L * 1024 * 1024
        private const val BG_PAGE = "__evx_bg.html"
        private val ID_RE = Regex("^[a-p]{32}$")
        private val STORE_RE = Regex("^https?://(chromewebstore\\.google\\.com|chrome\\.google\\.com/webstore)/detail/.*?([a-p]{32})(?:[/?#].*)?$", RegexOption.IGNORE_CASE)

        /** 웹스토어 상세 페이지 주소 또는 ID 만 적은 글에서 확장 프로그램 ID 를 뽑는다 (아니면 null) */
        fun parseStoreId(input: String): String? {
            val t = input.trim()
            if (ID_RE.matches(t)) return t
            return STORE_RE.matchEntire(t)?.groupValues?.get(2)?.lowercase(Locale.ROOT)
        }
    }

    private val root = File(ctx.filesDir, "extensions")
    private val dataDir = File(root, ".data")
    private val indexFile = File(root, "index.json")
    private val lock = Any()
    private var exts: List<Ext> = emptyList()
    private val scriptCache = HashMap<String, String>()
    private val shim: String by lazy {
        ctx.assets.open("ext_shim.js").use { String(it.readBytes(), Charsets.UTF_8) }
    }

    // 페이지가 마음대로 확장 저장소를 읽지 못하게, 매 실행마다 새로 만드는 이름과 열쇠
    private val bridgeName = "EvExt" + UUID.randomUUID().toString().replace("-", "").take(12)
    private val token = UUID.randomUUID().toString().replace("-", "")
    private val session = HashMap<String, String>()
    private val handlers = Collections.synchronizedMap(WeakHashMap<WebView, MutableList<ScriptHandler>>())

    private val ui = Handler(Looper.getMainLooper())
    private val pool = java.util.concurrent.Executors.newCachedThreadPool()
    private val bgViews = HashMap<String, WebView>() // 화면 스레드에서만 만진다
    /** chrome.offscreen 문서: 화면에 붙이지 않는 숨은 웹뷰 (확장 프로그램 id 별 하나, 화면 스레드에서만 만진다) */
    private val offViews = HashMap<String, WebView>()

    /** 백그라운드가 chrome.action.onClicked 리스너를 등록한 확장 프로그램 (툴바 버튼을 누르면 이게 불린다) */
    private val actListeners: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    /** chrome.action.setPopup 으로 바뀐 팝업 페이지 (빈 문자열 = 팝업 없음) */
    private val popupOverride = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** 지금 쓸 팝업 페이지 (manifest 의 default_popup, setPopup 으로 바뀌었으면 그것). 없으면 null */
    fun popupOf(e: Ext): String? = (popupOverride[e.id] ?: e.popup)?.takeIf { it.isNotEmpty() }

    /** 팝업은 없지만 툴바 버튼을 누르면 백그라운드의 onClicked 가 불리는 확장 프로그램인가 */
    fun hasActionClick(id: String): Boolean = actListeners.contains(id)

    /** 툴바 버튼을 누른 것처럼 백그라운드의 chrome.action.onClicked 를 부른다 (화면 스레드에서) */
    fun actionClick(id: String) {
        val wv = try { activeWebView?.invoke() } catch (e: Exception) { null }
        val tab = JSONObject().put("id", 1).put("index", 0).put("windowId", 1).put("active", true).put("highlighted", true)
            .put("url", wv?.url ?: "").put("title", wv?.title ?: "")
        val js = "window.__evxActClick&&window.__evxActClick(${q(tab.toString())})"
        val bg = bgViews[id]
        if (bg == null) { diagAdd(id, "툴바 실행: 백그라운드가 꺼져 있어요 (백그라운드가 없거나 시작에 실패했어요)"); return }
        try { bg.evaluateJavascript(js, null) } catch (e: Exception) { }
    }
    /** 열려 있는 확장 프로그램 팝업을 닫는 함수 (확장 프로그램 id 별, 화면 스레드에서만 만진다) */
    val popupClosers = HashMap<String, () -> Unit>()
    private val pages: MutableSet<WebView> = Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap<WebView, Boolean>()))
    private val pendingInstalled: MutableSet<String> = Collections.synchronizedSet(HashSet())

    /** 지금 보고 있는 (시크릿 아닌) 탭의 웹뷰 — tabs.query / tabs.sendMessage 용. MainActivity 가 채워 준다 */
    var activeWebView: (() -> WebView?)? = null

    /** 확장 프로그램이 새 탭을 열 때 (tabs.create · openOptionsPage) */
    var openTab: ((String) -> Unit)? = null

    /** 앱 데이터를 JSON 배열 문자열로 돌려준다: kind = history | bookmarks, arg = 검색어 (화면 스레드에서 불린다). MainActivity 가 채워 준다 */
    var dataProvider: ((String, String) -> String)? = null

    /** 앱 기능을 쓰는 명령: kind = notify(JSON: title · message) | download(주소) (화면 스레드에서 불린다) */
    var commandHandler: ((String, String) -> Unit)? = null

    /**
     * 보고 있는 탭의 이동 · 로드 · 전환을 켜진 확장 프로그램의 백그라운드에 알린다 (tabs.onUpdated · onActivated · webNavigation).
     * [name] 은 nav(이동 · 로드) / activated(탭 전환), [argsJson] 은 {phase, url, title}. 화면 스레드에서 부른다.
     */
    fun dispatchEvent(name: String, argsJson: String) {
        if (bgViews.isEmpty()) return
        val js = "window.__evxEvt&&window.__evxEvt(${q(name)},${q(argsJson)})"
        bgViews.values.toList().forEach { try { it.evaluateJavascript(js, null) } catch (e: Exception) { } }
    }

    val supported: Boolean by lazy { WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) }

    // declarativeNetRequest 규칙: init 에서 reload() 가 쓰므로 init 보다 먼저 선언해야 한다
    private class DnrRule(
        val id: Int, val priority: Int, val allow: Boolean, val re: Regex?, val types: Int, val party: Int,
        val initIn: List<String>, val initEx: List<String>, val reqIn: List<String>, val reqEx: List<String>,
        /** redirect 규칙이면 action.redirect, upgradeScheme 규칙이면 빈 객체 */
        val redirect: JSONObject? = null, val upgrade: Boolean = false,
        /** modifyHeaders 규칙이면 true, 그 요청 · 응답 헤더 작업 */
        val modify: Boolean = false, val reqOps: JSONArray? = null, val respOps: JSONArray? = null
    )

    private class DnrSet(val generic: List<DnrRule>, val byHost: Map<String, List<DnrRule>>, val count: Int, val hasModify: Boolean = false)

    // webRequest · 우클릭 메뉴 (init 에서 reload() 가 쓰므로 init 보다 먼저 선언)
    private class WrReg(
        val extId: String, val name: String, val lid: String, val urls: List<Regex>, val types: Int, val blocking: Boolean
    )
    private class WrWait { val latch = java.util.concurrent.CountDownLatch(1); @Volatile var result: String? = null }
    private val wrRegs = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.CopyOnWriteArrayList<WrReg>>()
    private val wrWaits = java.util.concurrent.ConcurrentHashMap<String, WrWait>()
    private val wrSkip = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val wrSeq = java.util.concurrent.atomic.AtomicLong(0)
    private val cmMem = java.util.concurrent.ConcurrentHashMap<String, JSONArray>()

    @Volatile private var dnrSets: Map<String, DnrSet> = emptyMap()
    private val dnrSession = HashMap<String, JSONArray>()
    private val dnrExec = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val dnrDiagCount = HashMap<String, Int>()
    private val dnrEvery = NetFilter.T_DOC or NetFilter.T_SCRIPT or NetFilter.T_IMAGE or NetFilter.T_CSS or NetFilter.T_XHR or
        NetFilter.T_SUBDOC or NetFilter.T_MEDIA or NetFilter.T_FONT or NetFilter.T_PING or NetFilter.T_WS or NetFilter.T_OTHER or NetFilter.T_OBJECT

    init {
        root.mkdirs()
        reload()
    }

    // ───────────────────────── 목록 ─────────────────────────

    fun list(): List<Ext> = synchronized(lock) { exts }

    private fun disabledIds(): MutableSet<String> {
        val set = HashSet<String>()
        try {
            if (indexFile.exists()) {
                val a = JSONObject(indexFile.readText()).optJSONArray("disabled")
                if (a != null) for (i in 0 until a.length()) set.add(a.getString(i))
            }
        } catch (e: Exception) { /* 읽지 못하면 모두 켜짐 */ }
        return set
    }

    private fun saveIndex() {
        val dis = JSONArray()
        exts.filter { !it.enabled }.forEach { dis.put(it.id) }
        try { indexFile.writeText(JSONObject().put("disabled", dis).toString()) } catch (e: Exception) { }
    }

    fun reload() = synchronized(lock) {
        scriptCache.clear()
        val dis = disabledIds()
        val out = ArrayList<Ext>()
        root.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name }?.forEach { d ->
            try { parse(d, d.name)?.let { it.enabled = it.id !in dis; out.add(it) } } catch (e: Exception) { }
        }
        exts = out.sortedBy { it.name.lowercase(Locale.ROOT) }
        rebuildDnr()
    }

    fun setEnabled(id: String, on: Boolean) = synchronized(lock) {
        exts.find { it.id == id }?.enabled = on
        scriptCache.keys.removeAll { it.startsWith("$id:") }
        saveIndex()
        rebuildDnr()
    }

    fun remove(id: String) = synchronized(lock) {
        File(root, id).deleteRecursively()
        File(dataDir, id).deleteRecursively()
        synchronized(dnrSession) { dnrSession.remove(id) }
        exts = exts.filter { it.id != id }
        scriptCache.keys.removeAll { it.startsWith("$id:") }
        saveIndex()
        rebuildDnr()
    }

    // ───────────────────────── 설치 ─────────────────────────

    /** .zip 또는 .crx 를 풀어 설치한다. 성공하면 이름을, 실패하면 예외(메시지는 사용자에게 보여 줄 말)를 던진다. */
    fun install(uri: Uri): Ext {
        val raw = ByteArrayOutputStream()
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                raw.write(buf, 0, n)
                if (raw.size() > MAX_ZIP) throw IllegalStateException("파일이 너무 커요 (160MB 이하만 가능)")
            }
        } ?: throw IllegalStateException("파일을 열 수 없어요")
        return installBytes(raw.toByteArray())
    }

    /**
     * 크롬 웹스토어 주소(또는 32자리 확장 프로그램 ID)로 .crx 를 받아 설치한다.
     * 구글 업데이트 서버(clients2.google.com)에서 크롬과 같은 방식으로 내려받는다.
     */
    fun installFromStore(input: String): Ext {
        val id = parseStoreId(input) ?: throw IllegalStateException("웹스토어 주소나 확장 프로그램 ID(영문 32자)를 확인해 주세요")
        val url = "https://clients2.google.com/service/update2/crx?response=redirect&os=android&arch=arm64&os_arch=arm64" +
            "&nacl_arch=arm&prod=chromecrx&prodchannel=stable&prodversion=$STORE_CHROME_VERSION" +
            "&acceptformat=crx2,crx3&x=" + java.net.URLEncoder.encode("id=$id&uc", "UTF-8")
        var conn: java.net.HttpURLConnection? = null
        try {
            conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 30000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$STORE_CHROME_VERSION Mobile Safari/537.36")
            }
            val code = conn.responseCode
            if (code == 204 || code == 404) throw IllegalStateException("웹스토어에서 이 확장 프로그램을 찾지 못했어요 (없어졌거나 내려받을 수 없는 항목)")
            if (code !in 200..299) throw IllegalStateException("웹스토어 서버 응답 오류 ($code)")
            val raw = ByteArrayOutputStream()
            conn.inputStream.use { ins ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    raw.write(buf, 0, n)
                    if (raw.size() > MAX_ZIP) throw IllegalStateException("파일이 너무 커요 (160MB 이하만 가능)")
                }
            }
            return installBytes(raw.toByteArray())
        } catch (e: IllegalStateException) {
            throw e
        } catch (e: java.io.IOException) {
            throw IllegalStateException("웹스토어에 연결하지 못했어요. 인터넷 연결을 확인해 주세요")
        } finally {
            try { conn?.disconnect() } catch (e: Exception) { }
        }
    }

    // ── 웹스토어 호환 확인: 설치하지 않고 manifest 만 읽어서, evergreen 이 지원하지 않는 확장 프로그램인지 미리 알려 준다 ──
    private val compatCache = java.util.concurrent.ConcurrentHashMap<String, String>() // ID → 빈 값(호환) 또는 호환되지 않는 이유

    /** 이미 확인한 결과: 호환되지 않는 이유, 호환되거나 아직 모르면 null */
    fun cachedIncompat(id: String): String? = compatCache[id]?.takeIf { it.isNotEmpty() }

    /** 앱이 지원하지 않는 기능을 꼭 필요로 하는 권한 (선택 권한은 보지 않는다). identity 는 로그인만 빠지고 나머지는 쓸 수 있는 경우가 많아 설치는 허용한다 */
    private val UNSUPPORTED_PERMS = setOf(
        "nativeMessaging", "sidePanel", "debugger", "proxy", "tabCapture", "desktopCapture",
        "pageCapture", "vpnProvider"
    )

    /**
     * 웹스토어 확장 프로그램이 evergreen 과 호환되지 않으면 그 이유를, 호환되거나 확인할 수 없으면 null.
     * 같은 ID 는 한 번만 확인한다. 네트워크 오류 등으로 못 읽었을 때는 결과를 남기지 않는다. (백그라운드 스레드에서 부른다)
     */
    fun storeIncompat(input: String): String? {
        val id = parseStoreId(input) ?: return null
        compatCache[id]?.let { return it.ifEmpty { null } }
        val reason = try { peekStoreIncompat(id) } catch (e: Exception) { return null }
        compatCache[id] = reason ?: ""
        return reason
    }

    private fun peekStoreIncompat(id: String): String? {
        val url = "https://clients2.google.com/service/update2/crx?response=redirect&os=android&arch=arm64&os_arch=arm64" +
            "&nacl_arch=arm&prod=chromecrx&prodchannel=stable&prodversion=$STORE_CHROME_VERSION" +
            "&acceptformat=crx2,crx3&x=" + java.net.URLEncoder.encode("id=$id&uc", "UTF-8")
        var conn: java.net.HttpURLConnection? = null
        try {
            conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 30000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$STORE_CHROME_VERSION Mobile Safari/537.36")
            }
            val code = conn.responseCode
            if (code == 204 || code == 404) return "Chrome 확장 프로그램이 아니에요"
            if (code !in 200..299) return null
            // 너무 큰 파일은 미리 읽지 않는다 (모르면 호환으로 보고 설치할 때 다시 확인한다)
            if (conn.contentLengthLong > 40L * 1024 * 1024) return null
            val raw = ByteArrayOutputStream()
            conn.inputStream.use { ins ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    raw.write(buf, 0, n)
                    if (raw.size() > 40 * 1024 * 1024) return null
                }
            }
            val bytes = raw.toByteArray()
            if (bytes.size < 16) return null
            var start = 0
            if (bytes[0] == 'C'.code.toByte() && bytes[1] == 'r'.code.toByte() && bytes[2] == '2'.code.toByte() && bytes[3] == '4'.code.toByte()) {
                fun le(o: Int) = (bytes[o].toInt() and 0xFF) or ((bytes[o + 1].toInt() and 0xFF) shl 8) or
                    ((bytes[o + 2].toInt() and 0xFF) shl 16) or ((bytes[o + 3].toInt() and 0xFF) shl 24)
                start = when (le(4)) {
                    3 -> 12 + le(8)
                    2 -> 16 + le(8) + le(12)
                    else -> return null
                }
                if (start <= 0 || start >= bytes.size) return null
            }
            var text: String? = null
            ZipInputStream(ByteArrayInputStream(bytes, start, bytes.size - start)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.name.replace('\\', '/') == "manifest.json") { text = String(zin.readBytes(), Charsets.UTF_8); break }
                }
            }
            val mj = JSONObject((text ?: return null).removePrefix("\uFEFF"))
            return manifestIncompat(mj)
        } finally {
            try { conn?.disconnect() } catch (e: Exception) { }
        }
    }

    /** manifest 만 보고 evergreen 이 지원하지 않는 확장 프로그램인지 (이유, 아니면 null) */
    private fun manifestIncompat(mj: JSONObject): String? {
        if (mj.has("theme")) return "테마는 지원하지 않아요"
        if (mj.has("app")) return "크롬 앱은 지원하지 않아요"
        if (mj.has("side_panel")) return "사이드 패널을 지원하지 않아요"
        if (mj.has("devtools_page")) return "개발자 도구 확장은 지원하지 않아요"
        if (mj.has("chrome_url_overrides")) return "새 탭·기록 화면 바꾸기를 지원하지 않아요"
        val perms = mj.optJSONArray("permissions")
        if (perms != null) {
            for (i in 0 until perms.length()) {
                val p = perms.optString(i)
                if (p in UNSUPPORTED_PERMS) return "'$p' 권한을 지원하지 않아요"
            }
        }
        return null
    }

    /** .zip / .crx 바이트를 풀어 설치한다 */
    private fun installBytes(bytes: ByteArray): Ext {
        if (bytes.size < 4) throw IllegalStateException("올바른 확장 프로그램 파일이 아니에요")

        // crx 머리글 건너뛰기
        var start = 0
        if (bytes[0] == 'C'.code.toByte() && bytes[1] == 'r'.code.toByte() && bytes[2] == '2'.code.toByte() && bytes[3] == '4'.code.toByte()) {
            fun le(o: Int) = (bytes[o].toInt() and 0xFF) or ((bytes[o + 1].toInt() and 0xFF) shl 8) or
                ((bytes[o + 2].toInt() and 0xFF) shl 16) or ((bytes[o + 3].toInt() and 0xFF) shl 24)
            start = when (le(4)) {
                3 -> 12 + le(8)
                2 -> 16 + le(8) + le(12)
                else -> throw IllegalStateException("지원하지 않는 crx 형식이에요")
            }
            if (start <= 0 || start >= bytes.size) throw IllegalStateException("crx 파일이 손상됐어요")
        }

        val tmp = File(root, ".tmp_" + UUID.randomUUID().toString().take(8))
        tmp.mkdirs()
        try {
            var total = 0L
            val tmpCanon = tmp.canonicalPath
            ZipInputStream(ByteArrayInputStream(bytes, start, bytes.size - start)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val name = e.name.replace('\\', '/')
                    if (name.startsWith("__MACOSX/") || name.isEmpty()) continue
                    val f = File(tmp, name)
                    if (!f.canonicalPath.startsWith(tmpCanon + File.separator)) continue // 폴더 밖으로 나가는 경로 차단
                    if (e.isDirectory) { f.mkdirs(); continue }
                    f.parentFile?.mkdirs()
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_UNPACKED) throw IllegalStateException("압축을 풀면 너무 커요 (1GB 이하만 가능)")
                            out.write(buf, 0, n)
                        }
                    }
                }
            }
            // manifest.json 이 있는 가장 얕은 폴더를 확장 프로그램 폴더로 본다
            val manifest = tmp.walkTopDown().filter { it.isFile && it.name == "manifest.json" }
                .minByOrNull { it.relativeTo(tmp).path.count { c -> c == File.separatorChar } }
                ?: throw IllegalStateException("manifest.json 이 없어요 (확장 프로그램 zip/crx 가 아니에요)")
            val base = manifest.parentFile!!
            val mj = readJson(manifest)
            val name0 = mj.optString("name")
            if (name0.isBlank() || mj.optString("version").isBlank()) throw IllegalStateException("manifest.json 에 name/version 이 없어요")
            val id = makeId(mj, name0)
            val dest = File(root, id)
            synchronized(lock) {
                dest.deleteRecursively()
                if (!base.renameTo(dest)) {
                    base.copyRecursively(dest, true)
                }
            }
            val ext = parse(dest, id) ?: throw IllegalStateException("manifest.json 을 읽지 못했어요")
            pendingInstalled.add(id)
            synchronized(lock) {
                ext.enabled = true
                exts = (exts.filter { it.id != id } + ext).sortedBy { it.name.lowercase(Locale.ROOT) }
                scriptCache.keys.removeAll { it.startsWith("$id:") }
                saveIndex()
            }
            rebuildDnr()
            return ext
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun readJson(f: File): JSONObject {
        var s = f.readText(Charsets.UTF_8)
        if (s.startsWith("\uFEFF")) s = s.substring(1)
        return JSONObject(s)
    }

    private fun makeId(mj: JSONObject, name: String): String {
        val seed = mj.optString("key").ifEmpty { "evergreen:$name" }
        val d = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        val sb = StringBuilder()
        for (i in 0 until 16) {
            val b = d[i].toInt() and 0xFF
            sb.append(('a' + (b shr 4))).append(('a' + (b and 0x0F)))
        }
        return sb.toString()
    }

    // ───────────────────────── 매니페스트 읽기 ─────────────────────────

    private fun loadMessages(dir: File, mj: JSONObject): Map<String, String> {
        val loc = File(dir, "_locales")
        if (!loc.isDirectory) return emptyMap()
        val names = loc.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: return emptyMap()
        val lang = Locale.getDefault().language
        val def = mj.optString("default_locale")
        val pick = listOf(Locale.getDefault().toString(), lang, def, "en", "en_US", "en_GB")
            .firstOrNull { it.isNotEmpty() && it in names } ?: names.firstOrNull() ?: return emptyMap()
        val f = File(loc, "$pick/messages.json")
        if (!f.exists()) return emptyMap()
        val out = HashMap<String, String>()
        try {
            val o = readJson(f)
            for (k in o.keys()) {
                val item = o.optJSONObject(k) ?: continue
                var msg = item.optString("message")
                item.optJSONObject("placeholders")?.let { ph ->
                    for (pk in ph.keys()) {
                        val c = ph.optJSONObject(pk)?.optString("content") ?: continue
                        msg = msg.replace("\$$pk\$", c, ignoreCase = true)
                    }
                }
                out[k.lowercase(Locale.ROOT)] = msg
            }
        } catch (e: Exception) { }
        return out
    }

    private fun parse(dir: File, id: String): Ext? {
        val mf = File(dir, "manifest.json")
        if (!mf.exists()) return null
        val mj = readJson(mf)
        val msgs = loadMessages(dir, mj)
        fun loc(s: String): String = Regex("__MSG_([A-Za-z0-9_@]+)__").replace(s) { m ->
            msgs[m.groupValues[1].lowercase(Locale.ROOT)] ?: m.value
        }
        val entries = ArrayList<Entry>()
        val cs = mj.optJSONArray("content_scripts")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.optJSONObject(i) ?: continue
            fun strs(k: String): List<String> {
                val a = c.optJSONArray(k) ?: return emptyList()
                return (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
            }
            val m = strs("matches")
            if (m.isEmpty()) continue
            entries.add(
                Entry(
                    m, strs("exclude_matches"), strs("js"), strs("css"),
                    c.optString("run_at", "document_idle"), c.optBoolean("all_frames", false),
                    strs("include_globs"), strs("exclude_globs")
                )
            )
        }
        val bg = mj.optJSONObject("background")
        val action = mj.optJSONObject("action") ?: mj.optJSONObject("browser_action") ?: mj.optJSONObject("page_action")
        val optUi = mj.optJSONObject("options_ui")?.optString("page")?.takeIf { it.isNotEmpty() }
        val options = optUi ?: mj.optString("options_page").takeIf { it.isNotEmpty() }
        val popup = action?.optString("default_popup")?.takeIf { it.isNotEmpty() }
        var icon: String? = null
        fun bestIcon(o: JSONObject?): String? {
            o ?: return null
            val best = o.keys().asSequence().mapNotNull { it.toIntOrNull() }.maxOrNull() ?: return null
            return o.optString(best.toString()).takeIf { it.isNotEmpty() }
        }
        icon = bestIcon(mj.optJSONObject("icons"))
        if (icon == null) {
            val di = action?.opt("default_icon")
            icon = when (di) {
                is String -> di
                is JSONObject -> bestIcon(di)
                else -> null
            }
        }
        val hostPats = ArrayList<String>()
        for (k in listOf("host_permissions", "optional_host_permissions", "permissions", "optional_permissions")) {
            val a = mj.optJSONArray(k) ?: continue
            for (i in 0 until a.length()) {
                val h = a.optString(i)
                if (h == "<all_urls>" || h.contains("://")) hostPats.add(h)
            }
        }
        val hosts = hostPats.mapNotNull { patternToRegex(it) }.mapNotNull { try { Regex(it) } catch (e: Exception) { null } }
        return Ext(
            id = id,
            name = loc(mj.optString("name")),
            version = mj.optString("version"),
            description = loc(mj.optString("description")),
            manifestVersion = mj.optInt("manifest_version", 2),
            dir = dir,
            manifest = mj,
            entries = entries,
            hasBackground = bg != null && (bg.has("service_worker") || bg.has("scripts") || bg.has("page")),
            options = options,
            popup = popup,
            icon = icon,
            messages = msgs,
            hosts = hosts,
            enabled = true
        )
    }

    fun iconBitmap(e: Ext): Bitmap? {
        val p = e.icon ?: return null
        return try {
            val f = File(e.dir, p.removePrefix("/"))
            if (f.canonicalPath.startsWith(e.dir.canonicalPath) && f.exists()) BitmapFactory.decodeFile(f.path) else null
        } catch (ex: Exception) { null }
    }

    /** 새 탭에서 열 수 있는 확장 프로그램 내부 페이지 주소 (옵션 · 팝업) */
    fun pageUrl(e: Ext, path: String): String = "https://$HOST/${e.id}/" + path.removePrefix("/")

    // ───────────────────────── 웹페이지에 넣기 ─────────────────────────

    private fun esc(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in ".+?^$()|[]{}\\") sb.append('\\')
            sb.append(c)
        }
        return sb.toString()
    }

    /** 크롬의 match pattern 을 JS 정규식 문자열로 바꾼다 (잘못된 패턴이면 null) */
    private fun patternToRegex(p: String): String? {
        if (p == "<all_urls>") return "^https?://.*$"
        val m = Regex("^(\\*|https?|file|ftp)://([^/]*)(/.*)$").matchEntire(p) ?: return null
        val scheme = m.groupValues[1]
        val host = m.groupValues[2]
        val path = m.groupValues[3]
        val s = if (scheme == "*") "https?" else scheme
        val h = when {
            scheme == "file" -> esc(host)
            host == "*" -> "[^/:]+"
            host.startsWith("*.") -> "([^/:]+\\.)?" + esc(host.substring(2))
            else -> esc(host)
        }
        val port = if (scheme == "file") "" else "(:\\d+)?"
        val pa = path.split("*").joinToString(".*") { esc(it) }
        return "^$s://$h$port$pa$"
    }

    private fun readText(e: Ext, rel: String): String? {
        return try {
            val f = File(e.dir, rel.removePrefix("/"))
            if (!f.canonicalPath.startsWith(e.dir.canonicalPath + File.separator) || !f.isFile) null
            else f.readText(Charsets.UTF_8)
        } catch (ex: Exception) { null }
    }

    private fun msgsJson(e: Ext): String {
        val o = JSONObject()
        e.messages.forEach { (k, v) -> o.put(k, v) }
        return o.toString()
    }

    private fun makeCall(e: Ext): String =
        "__evxMake(${JSONObject.quote(e.id)},${e.manifest},${msgsJson(e)},window[${JSONObject.quote(bridgeName)}],${JSONObject.quote(token)})"

    private fun buildScript(e: Ext, idx: Int): String? {
        val en = e.entries[idx]
        val key = "${e.id}:$idx"
        synchronized(lock) { scriptCache[key]?.let { return it } }
        val inc = en.matches.mapNotNull { patternToRegex(it) }
        if (inc.isEmpty()) return null
        val exc = en.excludes.mapNotNull { patternToRegex(it) }
        val js = StringBuilder()
        for (f in en.js) readText(e, f)?.let { js.append(it).append("\n;\n") }
        val css = StringBuilder()
        for (f in en.css) readText(e, f)?.let { css.append(it).append("\n") }
        if (js.isEmpty() && css.isEmpty()) return null
        val sb = StringBuilder()
        sb.append("(function(){\n")
        sb.append("if(location.hostname===${JSONObject.quote(HOST)})return;\n")
        sb.append("var __h=location.href.split('#')[0];\n")
        sb.append("var __i=").append(JSONArray(inc)).append(",__x=").append(JSONArray(exc)).append(";\n")
        sb.append("function __t(a){for(var i=0;i<a.length;i++){try{if(new RegExp(a[i]).test(__h))return true}catch(e){}}return false}\n")
        sb.append("if(!__t(__i)||__t(__x))return;\n")
        if (en.includeGlobs.isNotEmpty() || en.excludeGlobs.isNotEmpty()) {
            // include_globs / exclude_globs: * 는 아무 글자, ? 는 한 글자
            fun glob(g: String): String = "^" + g.map { ch -> when (ch) { '*' -> ".*"; '?' -> "."; else -> esc(ch.toString()) } }.joinToString("") + "\$"
            sb.append("var __ig=").append(JSONArray(en.includeGlobs.map { glob(it) })).append(",__eg=").append(JSONArray(en.excludeGlobs.map { glob(it) })).append(";\n")
            sb.append("if(__ig.length&&!__t(__ig))return;if(__eg.length&&__t(__eg))return;\n")
        }
        if (!en.allFrames) sb.append("if(window.top!==window)return;\n")
        sb.append("var __k=${JSONObject.quote("__evx_$key")};\n")
        sb.append("if(window[__k])return;try{Object.defineProperty(window,__k,{value:1})}catch(e){window[__k]=1}\n")
        // 진단: 적용됐는지 · 확장 주소의 파일이 보안 정책(CSP)에 막혔는지 · 오류가 났는지를 앱에 알린다 (확장 프로그램 화면의 '진단')
        sb.append("var __B=window[").append(q(bridgeName)).append("],__T=").append(q(token)).append(";\n")
        sb.append("function __lg(k,m){try{__B.log(").append(q(e.id)).append(",k,String(m).slice(0,300),__T)}catch(x){}}\n")
        sb.append("__lg('적용', location.href);\n")
        sb.append("try{document.addEventListener('securitypolicyviolation',function(v){__lg('CSP 차단',v.violatedDirective+' '+v.blockedURI)},true)}catch(x){}\n")
        sb.append("try{window.addEventListener('error',function(v){var t=v.target;var u=t&&t!==window?String(t.src||t.href||''):String(v.filename||'');")
            .append("if(u.indexOf(").append(q(HOST)).append(")>=0)__lg(t&&t!==window?'파일 불러오기 실패':'스크립트 오류',(t&&t!==window?u:(v.message+' @'+u+':'+v.lineno)))},true)}catch(x){}\n")
        // 페이지 쪽에서 난 오류(실행기 스크립트·워커 등)도 앞부분만 남긴다
        sb.append("try{window.addEventListener('unhandledrejection',function(v){var r=v.reason;__lg('처리 안 된 오류',(r&&(r.stack||r.message))||r)},true)}catch(x){}\n")
        sb.append("try{var __ce=console.error;console.error=function(){try{__lg('console.error',[].slice.call(arguments).map(function(a){return a&&a.stack?a.stack:String(a)}).join(' ').slice(0,260))}catch(x){}return __ce.apply(console,arguments)}}catch(x){}\n")
        sb.append(shim).append("\n")
        sb.append("var chrome=").append(makeCall(e)).append(",browser=chrome;\n")
        if (css.isNotEmpty()) {
            sb.append("function __css(){var s=document.createElement('style');s.textContent=")
                .append(JSONObject.quote(css.toString()))
                .append(";(document.head||document.documentElement).appendChild(s)}\n")
            sb.append("if(document.documentElement)__css();else{var __mo=new MutationObserver(function(){if(document.documentElement){__mo.disconnect();__css()}});__mo.observe(document,{childList:true})}\n")
        }
        if (js.isNotEmpty()) {
            // 확장 스크립트가 globalThis.chrome / globalThis.browser 로 API 를 찾는 경우를 위해, 그 스크립트가 보는 globalThis 에만 chrome 을 얹는다 (페이지의 window 는 건드리지 않는다)
            sb.append("var __G;try{__G=new Proxy(window,{get:function(t,k){if(k==='chrome')return chrome;if(k==='browser')return browser;var v=t[k];return typeof v==='function'&&!/^[A-Z]/.test(String(k))?v.bind(t):v},set:function(t,k,v){t[k]=v;return true},has:function(t,k){return k==='chrome'||k==='browser'||k in t}})}catch(x){__G=window}\n")
            sb.append("function __run(){try{(function(chrome,browser,globalThis){\n").append(js).append("\n})(chrome,browser,__G)}catch(e){console.error(${JSONObject.quote("[Evergreen 확장] " + e.name)},e);__lg('실행 오류',(e&&e.stack)||e)}}\n")
            when (en.runAt) {
                // 웹뷰의 문서 시작 스크립트는 <html> 이 생기기 전에 돌 수 있다 (크롬은 항상 있다) → 생길 때까지 기다렸다가 돌린다
                "document_start" -> sb.append("if(document.documentElement)__run();else{var __mr=new MutationObserver(function(){if(document.documentElement){__mr.disconnect();__run()}});__mr.observe(document,{childList:true})}\n")
                "document_end" -> sb.append("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',__run,{once:true});else __run();\n")
                else -> sb.append("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(__run,0)},{once:true});else setTimeout(__run,0);\n")
            }
        }
        sb.append("})();")
        val out = sb.toString()
        synchronized(lock) { scriptCache[key] = out }
        return out
    }

    private val diag = HashMap<String, java.util.ArrayDeque<String>>()

    private fun diagAdd(id: String, line: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
        synchronized(diag) {
            val q = diag.getOrPut(id) { java.util.ArrayDeque() }
            // 같은 줄이 연달아 오면 한 번만 남긴다
            if (q.peekLast()?.substring(10) == line) return
            q.addLast("$t  $line")
            while (q.size > 80) q.pollFirst()
        }
    }

    /** 팝업 등 다른 곳에서 진단 기록을 남길 때 */
    fun diagLog(id: String, line: String) = diagAdd(id, line)

    /** 웹뷰의 콘솔 오류(스크립트 문법 오류 · 못 불러온 모듈 · CSP 차단 등)를 진단 기록으로 돌린다 */
    fun consoleToDiag(id: String, who: String): android.webkit.WebChromeClient = object : android.webkit.WebChromeClient() {
        override fun onConsoleMessage(m: android.webkit.ConsoleMessage): Boolean {
            if (m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) {
                diagAdd(id, "$who 콘솔: " + m.message().take(240) + " (" + m.sourceId().substringAfterLast('/').take(40) + ":" + m.lineNumber() + ")")
            }
            return true
        }
    }

    /** 확장 프로그램 화면의 '진단'에 보여 줄 기록 (오래된 것부터) */
    fun diagLines(id: String): List<String> = synchronized(diag) { diag[id]?.toList() ?: emptyList() }

    fun diagClear(id: String) { synchronized(diag) { diag.remove(id) } }

    inner class Bridge {
        @JavascriptInterface
        fun log(id: String, kind: String, msg: String, t: String) {
            if (t != token || id.length > 40 || kind.length > 24 || msg.length > 400) return
            diagAdd(id, "$kind: $msg")
        }

        @JavascriptInterface
        fun sget(id: String, area: String, t: String): String {
            if (t != token) return "{}"
            return readArea(id, area)
        }

        @JavascriptInterface
        fun sset(id: String, area: String, json: String, t: String) {
            if (t != token || json.length > MAX_AREA_JSON) return
            writeArea(id, area, json)
        }

        /** 콘텐츠 스크립트 · 팝업 → 백그라운드: runtime.sendMessage */
        @JavascriptInterface
        fun send(id: String, msg: String, url: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || msg.length > MAX_MSG) return
            ui.post {
                val bg = bgViews[id]
                if (bg == null) { diagAdd(id, "메시지: 백그라운드가 꺼져 있어 응답을 못 줬어요"); respondPages(id, cid, ""); return@post }
                val sender = JSONObject().put("id", id).put("url", url)
                if (!url.startsWith("https://$HOST/")) {
                    val origin = try { Uri.parse(url).let { u -> if (u.scheme != null && u.host != null) u.scheme + "://" + u.authority else "" } } catch (e: Exception) { "" }
                    sender.put("frameId", 0).put("documentId", "0").put("origin", origin)
                    sender.put("tab", JSONObject().put("id", 1).put("index", 0).put("url", url).put("active", true).put("highlighted", true)
                        .put("windowId", 1).put("incognito", false).put("status", "complete").put("title", ""))
                }
                // 백그라운드 페이지가 아직 뜨는 중이면 (팝업을 바로 연 경우) 준비될 때까지 기다렸다가 전달한다
                bg.evaluateJavascript(
                    "(function w(n){if(window.__evxBgIn)window.__evxBgIn(${JSONObject.quote(cid)},${JSONObject.quote(msg)},${JSONObject.quote(sender.toString())});" +
                        "else if(n>0)setTimeout(function(){w(n-1)},100)})(100)", null
                )
            }
        }

        /** 백그라운드의 답장 → 요청한 페이지 */
        @JavascriptInterface
        fun bgresp(id: String, cid: String, json: String, t: String) {
            if (t != token || cid.length > 80 || json.length > MAX_MSG) return
            respondPages(id, cid, json)
        }

        /** 백그라운드 → 보고 있는 탭의 콘텐츠 스크립트: tabs.sendMessage */
        @JavascriptInterface
        fun tabsend(id: String, msg: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || msg.length > MAX_MSG) return
            ui.post {
                val wv = try { activeWebView?.invoke() } catch (e: Exception) { null }
                val ext = list().find { it.id == id }
                // 이 확장 프로그램의 콘텐츠 스크립트가 들어간 페이지에만 보낸다 (다른 사이트가 메시지를 엿보지 못하게)
                if (wv == null || ext == null || !canReach(ext, wv)) { respondBg(id, cid, ""); return@post }
                val sender = JSONObject().put("id", id).toString()
                wv.evaluateJavascript(
                    "(window.__evxTabIn?(window.__evxTabIn(${JSONObject.quote(id)},${JSONObject.quote(cid)},${JSONObject.quote(msg)},${JSONObject.quote(sender)}),1):0)"
                ) { r -> if (r == "0" || r == "null") respondBg(id, cid, "") }
            }
        }

        /** 콘텐츠 스크립트의 답장 → 백그라운드 */
        @JavascriptInterface
        fun pageresp(id: String, cid: String, json: String, t: String) {
            if (t != token || cid.length > 80 || json.length > MAX_MSG) return
            bcastReply(id, cid, json)
        }

        /** 백그라운드 → 열려 있는 확장 페이지(팝업 · 옵션 · 이 확장이 적용된 탭)에 메시지/포트 신호: runtime.sendMessage(백그라운드에서), 포트 */
        @JavascriptInterface
        fun bgbcast(id: String, msg: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || msg.length > MAX_MSG) return
            ui.post {
                val ext = list().find { it.id == id }
                val all: List<WebView> = if (ext == null) emptyList<WebView>() else synchronized(pages) { pages.toList() }.filter { canReach(ext, it) }
                if (all.isEmpty()) { respondBg(id, cid, ""); return@post }
                synchronized(bcast) { bcast[cid] = intArrayOf(all.size, 0) }
                val sender = JSONObject().put("id", id).toString()
                val js = "(window.__evxTabIn?(window.__evxTabIn(${q(id)},${q(cid)},${q(msg)},${q(sender)}),1):0)"
                all.forEach { wv ->
                    try { wv.evaluateJavascript(js) { r -> if (r == "0" || r == "null") bcastReply(id, cid, "") } }
                    catch (e: Exception) { bcastReply(id, cid, "") }
                }
            }
        }

        /** 저장소가 바뀌었음을 다른 창(백그라운드 · 팝업 · 탭)에 알린다: storage.onChanged */
        @JavascriptInterface
        fun sbcast(id: String, area: String, json: String, src: String, t: String) {
            if (t != token || area.length > 12 || src.length > 80 || json.length > 1_000_000) return
            ui.post {
                val ext = list().find { it.id == id } ?: return@post
                val js = "window.__evxSc&&window.__evxSc(${q(id)},${q(area)},${q(json)},${q(src)})"
                bgViews[id]?.let { try { it.evaluateJavascript(js, null) } catch (e: Exception) { } }
                val all = synchronized(pages) { pages.toList() }
                all.forEach { try { if (canReach(ext, it)) it.evaluateJavascript(js, null) } catch (e: Exception) { } }
            }
        }

        /** 보고 있는 탭에 스크립트/스타일 넣기: scripting.executeScript · insertCSS · tabs.executeScript */
        @JavascriptInterface
        fun tabexec(id: String, spec: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || spec.length > MAX_MSG) return
            ui.post {
                val e = list().find { it.id == id && it.enabled }
                val wv = try { activeWebView?.invoke() } catch (ex: Exception) { null }
                if (e == null || wv == null) { execReply(id, cid, execError("No active tab")); return@post }
                val url = wv.url ?: ""
                val allowed = e.hosts.any { it.matches(url) } || hasPermission(e, "activeTab")
                if (!allowed || !(url.startsWith("http://") || url.startsWith("https://"))) {
                    execReply(id, cid, execError("Cannot access contents of the page. Extension manifest must request permission to access the respective host."))
                    return@post
                }
                val code = try { buildExec(e, JSONObject(spec), id, cid) } catch (ex: Exception) { null }
                if (code == null) { execReply(id, cid, execError("Invalid injection details")); return@post }
                try { wv.evaluateJavascript(code, null) } catch (ex: Exception) { execReply(id, cid, execError("Injection failed")) }
            }
        }

        /** 탭에 넣은 스크립트의 결과 (주입된 코드가 부른다) */
        @JavascriptInterface
        fun execres(id: String, cid: String, json: String, t: String) {
            if (t != token || cid.length > 80 || json.length > MAX_MSG) return
            execReply(id, cid, json)
        }

        /** tabs.update(url) · reload · goBack · goForward: 보고 있는 탭 */
        @JavascriptInterface
        fun tabcmd(id: String, cmd: String, arg: String, t: String) {
            if (t != token || arg.length > 4000) return
            ui.post {
                if (list().none { it.id == id && it.enabled }) return@post
                val wv = try { activeWebView?.invoke() } catch (ex: Exception) { null }
                if (wv == null) return@post
                try {
                    when (cmd) {
                        "reload" -> wv.reload()
                        "back" -> if (wv.canGoBack()) wv.goBack()
                        "forward" -> if (wv.canGoForward()) wv.goForward()
                        "nav" -> { val u = arg.trim(); if (u.startsWith("https://") || u.startsWith("http://")) wv.loadUrl(u) }
                    }
                } catch (ex: Exception) { }
            }
        }

        /** cookies.get / getAll: host 권한이 있는 주소의 쿠키 (이름 · 값만 알 수 있다) */
        @JavascriptInterface
        fun cookieget(id: String, url: String, t: String): String {
            if (t != token || url.length > 4000) return "[]"
            val e = list().find { it.id == id && it.enabled } ?: return "[]"
            if (!(url.startsWith("https://") || url.startsWith("http://")) || e.hosts.none { it.matches(url) }) return "[]"
            val raw = try { android.webkit.CookieManager.getInstance().getCookie(url) } catch (ex: Exception) { null }
            if (raw.isNullOrEmpty()) return "[]"
            val host = try { Uri.parse(url).host.orEmpty() } catch (ex: Exception) { "" }
            val arr = JSONArray()
            raw.split(";").forEach { part ->
                val sp = part.trim()
                val i = sp.indexOf('=')
                if (i <= 0) return@forEach
                arr.put(
                    JSONObject().put("name", sp.substring(0, i)).put("value", sp.substring(i + 1)).put("domain", host)
                        .put("hostOnly", true).put("path", "/").put("secure", url.startsWith("https://")).put("httpOnly", false)
                        .put("session", true).put("storeId", "0").put("sameSite", "unspecified")
                )
            }
            return arr.toString()
        }

        /** cookies.set / remove */
        @JavascriptInterface
        fun cookieset(id: String, json: String, t: String): String {
            if (t != token || json.length > 8000) return "{\"error\":\"Invalid cookie details\"}"
            val e = list().find { it.id == id && it.enabled } ?: return "{\"error\":\"Extension is disabled\"}"
            return try {
                val d = JSONObject(json)
                val url = d.optString("url")
                val name = d.optString("name")
                if (name.isEmpty() || !(url.startsWith("https://") || url.startsWith("http://"))) return "{\"error\":\"Invalid cookie details\"}"
                if (e.hosts.none { it.matches(url) }) return "{\"error\":\"No host permission for the cookie's URL.\"}"
                val rm = d.optBoolean("remove")
                val sb = StringBuilder(name).append('=')
                if (!rm) sb.append(d.optString("value"))
                sb.append("; Path=").append(d.optString("path").ifEmpty { "/" })
                d.optString("domain").takeIf { it.isNotEmpty() }?.let { sb.append("; Domain=").append(it) }
                if (d.optBoolean("secure")) sb.append("; Secure")
                if (d.optBoolean("httpOnly")) sb.append("; HttpOnly")
                when (d.optString("sameSite")) {
                    "lax" -> sb.append("; SameSite=Lax")
                    "strict" -> sb.append("; SameSite=Strict")
                    "no_restriction" -> sb.append("; SameSite=None")
                }
                if (rm) sb.append("; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
                else if (d.has("expirationDate")) {
                    val left = (d.optDouble("expirationDate") - System.currentTimeMillis() / 1000.0).toLong()
                    sb.append("; Max-Age=").append(maxOf(0L, left))
                }
                val cm = android.webkit.CookieManager.getInstance()
                cm.setCookie(url, sb.toString())
                cm.flush()
                JSONObject().put("name", name).put("value", if (rm) "" else d.optString("value")).put("storeId", "0").toString()
            } catch (ex: Exception) {
                "{\"error\":\"Invalid cookie details\"}"
            }
        }

        /** declarativeNetRequest: getDynamicRules / getSessionRules / getEnabledRulesets */
        @JavascriptInterface
        fun dnrget(id: String, kind: String, t: String): String {
            if (t != token) return "[]"
            val e = list().find { it.id == id } ?: return "[]"
            return when (kind) {
                "dynamic" -> dnrLoadDynamic(id).toString()
                "session" -> dnrSessionRules(id).toString()
                "rulesets" -> dnrEnabledRulesets(e).toString()
                else -> "[]"
            }
        }

        /** declarativeNetRequest: updateDynamicRules / updateSessionRules / updateEnabledRulesets (성공하면 {} · 실패하면 {"error":...}) */
        @JavascriptInterface
        fun dnrupd(id: String, kind: String, json: String, t: String): String {
            if (t != token || json.length > MAX_AREA_JSON) return dnrError("Invalid request")
            val e = list().find { it.id == id && it.enabled } ?: return dnrError("Extension is disabled")
            return dnrUpdate(e, kind, json)
        }

        /** history · bookmarks 읽기: 매니페스트에 그 권한이 있는 확장 프로그램에만 앱의 기록 · 북마크를 보여 준다 */
        @JavascriptInterface
        fun appdata(id: String, kind: String, arg: String, t: String): String {
            if (t != token || arg.length > 2000) return "[]"
            val e = list().find { it.id == id && it.enabled } ?: return "[]"
            val need = when (kind) { "history" -> "history"; "bookmarks" -> "bookmarks"; else -> return "[]" }
            if (!hasPermission(e, need) && !(kind == "history" && hasPermission(e, "topSites"))) return "[]"
            val latch = java.util.concurrent.CountDownLatch(1)
            var out = "[]"
            ui.post {
                try { out = dataProvider?.invoke(kind, arg) ?: "[]" } catch (ex: Exception) { }
                latch.countDown()
            }
            latch.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS)
            return out
        }

        /** 알림 · 다운로드: notifications / downloads 권한이 있는 확장 프로그램만 */
        @JavascriptInterface
        fun appcmd(id: String, kind: String, arg: String, t: String) {
            if (t != token || arg.length > 8000) return
            val e = list().find { it.id == id && it.enabled } ?: return
            val need = when (kind) { "notify" -> "notifications"; "download" -> "downloads"; else -> return }
            if (!hasPermission(e, need)) {
                diagAdd(id, "권한 없음: $need 권한이 매니페스트에 없어서 무시했어요")
                return
            }
            ui.post { try { commandHandler?.invoke(kind, arg) } catch (ex: Exception) { } }
        }

        /** tabs.query / tabs.get: 보고 있는 탭 하나 */
        @JavascriptInterface
        fun tabinfo(id: String, t: String): String {
            if (t != token) return "[]"
            val latch = java.util.concurrent.CountDownLatch(1)
            var out = "[]"
            ui.post {
                try {
                    val wv = activeWebView?.invoke()
                    if (wv != null) {
                        out = JSONArray().put(
                            JSONObject().put("id", 1).put("index", 0).put("windowId", 1).put("active", true)
                                .put("highlighted", true).put("url", wv.url ?: "").put("title", wv.title ?: "")
                        ).toString()
                    }
                } catch (e: Exception) { }
                latch.countDown()
            }
            latch.await(800, java.util.concurrent.TimeUnit.MILLISECONDS)
            return out
        }

        @JavascriptInterface
        fun opentab(id: String, url: String, t: String) {
            if (t != token || url.length > 4000) return
            val u = url.trim()
            if (!u.startsWith("https://") && !u.startsWith("http://")) return
            ui.post { openTab?.invoke(u) }
        }


        /** webRequest 리스너 등록 (백그라운드가 addListener 할 때) */
        @JavascriptInterface
        fun wrreg(id: String, name: String, filter: String, lid: String, blocking: Boolean, t: String) {
            if (t != token || name !in WR_EVENTS || lid.isEmpty() || lid.length > 80 || filter.length > 20000) return
            val f = try { JSONObject(filter) } catch (e: Exception) { JSONObject() }
            val urls = ArrayList<Regex>()
            f.optJSONArray("urls")?.let { a ->
                for (i in 0 until a.length()) patternToRegex(a.optString(i))?.let { rx -> try { urls.add(Regex(rx)) } catch (e: Exception) { } }
            }
            var types = 0
            f.optJSONArray("types")?.let { a -> for (i in 0 until a.length()) types = types or dnrTypeBit(a.optString(i)) }
            wrRegs.getOrPut(id) { java.util.concurrent.CopyOnWriteArrayList() }.add(WrReg(id, name, lid, urls, types, blocking))
        }

        @JavascriptInterface
        fun wrunreg(id: String, lid: String, t: String) {
            if (t != token) return
            wrRegs[id]?.removeAll { it.lid == lid }
        }

        /** 막는(blocking) 리스너의 결과: 요청 스레드가 기다리고 있다 */
        @JavascriptInterface
        fun wrres(id: String, rid: String, json: String, t: String) {
            if (t != token || rid.length > 80 || json.length > MAX_MSG) return
            wrWaits[rid]?.let { it.result = json; it.latch.countDown() }
        }

        /** contextMenus 항목 읽기 · 저장 (앱을 다시 켜도 남도록 파일에 둔다) */
        @JavascriptInterface
        fun cmget(id: String, t: String): String {
            if (t != token) return "[]"
            return cmItems(id).toString()
        }

        @JavascriptInterface
        fun cmset(id: String, json: String, t: String) {
            if (t != token || json.length > MAX_AREA_JSON) return
            try {
                val a = JSONArray(json)
                cmMem[id] = a
                dnrFile(id, "cm_items.json")?.let { f -> f.parentFile?.mkdirs(); f.writeText(a.toString()) }
            } catch (e: Exception) { }
        }

        /** 백그라운드가 chrome.action.onClicked 리스너를 등록했다 */
        @JavascriptInterface
        fun actlisten(id: String, t: String) {
            if (t != token || id.length > 40) return
            actListeners.add(id)
        }

        /** chrome.action.setPopup */
        @JavascriptInterface
        fun actpopup(id: String, popup: String, t: String) {
            if (t != token || id.length > 40 || popup.length > 300) return
            popupOverride[id] = popup.trimStart('/')
        }

        /** chrome.offscreen.createDocument: 확장 프로그램 페이지를 화면 밖(숨은 웹뷰)에 띄운다 */
        @JavascriptInterface
        fun offcreate(id: String, url: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || url.length > 600) return
            ui.post {
                val e = list().find { it.id == id && it.enabled }
                if (e == null || !url.startsWith("https://$HOST/$id/")) { respondBg(id, cid, ""); return@post }
                closeOffscreen(id)
                try {
                    val wv = newPopupView { }
                    wv.webChromeClient = consoleToDiag(id, "offscreen")
                    offViews[id] = wv
                    diagAdd(id, "offscreen 문서 열기: " + url.substringAfter("/$id/").substringBefore('?'))
                    wv.loadUrl(url)
                    ui.postDelayed({ respondBg(id, cid, "true") }, 1200)
                } catch (ex: Exception) {
                    diagAdd(id, "offscreen 문서 열기 실패: " + (ex.message ?: ""))
                    respondBg(id, cid, "")
                }
            }
        }

        @JavascriptInterface
        fun offclose(id: String, t: String) {
            if (t != token) return
            ui.post { closeOffscreen(id) }
        }

        /** 팝업 페이지의 window.close() */
        @JavascriptInterface
        fun popclose(id: String, t: String) {
            if (t != token) return
            ui.post { popupClosers[id]?.invoke() }
        }

        /** 팝업 · 옵션 페이지의 fetch: 백그라운드와 같지만 답을 확장 프로그램 페이지들에게 돌려준다 */
        @JavascriptInterface
        fun pfetch(id: String, url: String, method: String, headers: String, body: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || body.length > MAX_MSG * 3) return
            pool.execute {
                val out = try { doFetch(id, url, method, headers, body) }
                catch (e: Exception) { JSONObject().put("error", e.message ?: "error").toString() }
                respondPages(id, cid, out)
            }
        }

        /** 백그라운드의 fetch: host 권한이 있는 주소만 앱이 대신 요청해 CORS 없이 돌려준다 */
        @JavascriptInterface
        fun xfetch(id: String, url: String, method: String, headers: String, body: String, t: String, cid: String) {
            if (t != token || cid.isEmpty() || cid.length > 80 || body.length > MAX_MSG * 3) return
            pool.execute {
                val out = try { doFetch(id, url, method, headers, body) }
                catch (e: Exception) { JSONObject().put("error", e.message ?: "error").toString() }
                respondBg(id, cid, out)
            }
        }
    }

    private fun q(s: String) = JSONObject.quote(s)

    /** 이 확장 프로그램의 스크립트가 들어간 페이지(콘텐츠 스크립트 · 팝업 · 옵션)에만 답을 돌려준다 */
    private fun respondPages(id: String, cid: String, json: String) {
        val js = "window.__evxResp&&window.__evxResp(${q(cid)},${q(json)})"
        ui.post {
            val e = list().find { it.id == id } ?: return@post
            val all = synchronized(pages) { pages.toList() }
            all.forEach { try { if (canReach(e, it)) it.evaluateJavascript(js, null) } catch (ex: Exception) { } }
        }
    }

    /** 웹뷰가 이 확장 프로그램의 페이지이거나, 이 확장 프로그램의 콘텐츠 스크립트가 들어가는 주소인가 (화면 스레드에서 부른다) */
    private fun canReach(e: Ext, wv: WebView): Boolean {
        val u = wv.url ?: return false
        if (u.startsWith("https://$HOST/${e.id}/")) return true
        if (!e.enabled) return false
        val h = u.substringBefore('#')
        fun hit(a: List<String>) = a.any { m ->
            val r = patternToRegex(m) ?: return@any false
            try { Regex(r).matches(h) } catch (ex: Exception) { false }
        }
        return e.entries.any { en -> hit(en.matches) && !hit(en.excludes) }
    }

    private fun hasPermission(e: Ext, name: String): Boolean {
        val a = e.manifest.optJSONArray("permissions") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == name) return true
        return false
    }

    // 여러 페이지에 한꺼번에 보낸 메시지의 답: 비어 있지 않은 첫 답을 쓰고, 모두 빈 답이면 빈 답으로 끝낸다
    private val bcast = HashMap<String, IntArray>() // cid → [남은 답 수, 이미 답했는지]

    private fun bcastReply(id: String, cid: String, json: String) {
        var send: String? = null
        synchronized(bcast) {
            val st = bcast[cid]
            if (st == null) {
                send = json
            } else {
                st[0]--
                if (json.isNotEmpty() && st[1] == 0) { st[1] = 1; send = json }
                if (st[0] <= 0) {
                    bcast.remove(cid)
                    if (st[1] == 0 && send == null) send = ""
                }
            }
        }
        send?.let { respondBg(id, cid, it) }
    }

    // 탭에 넣은 스크립트의 결과는 부른 쪽(백그라운드 또는 팝업)에 돌려준다
    private fun execReply(id: String, cid: String, json: String) {
        respondBg(id, cid, json)
        respondPages(id, cid, json)
    }

    private fun execError(msg: String) = JSONObject().put("error", msg).toString()

    /** 탭에 넣을 스크립트/스타일 코드를 만든다. 결과(또는 오류)는 execres 로 돌려보낸다 */
    private fun buildExec(e: Ext, spec: JSONObject, id: String, cid: String): String? {
        val kind = spec.optString("kind")
        val files = spec.optJSONArray("files")
        val text = StringBuilder()
        if (files != null) for (i in 0 until files.length()) readText(e, files.optString(i))?.let { text.append(it).append("\n;\n") }
        val body: String = when (kind) {
            "js" -> {
                val func = spec.optString("func")
                val code = spec.optString("code")
                when {
                    func.isNotEmpty() -> "(" + func + ").apply(null," + (spec.optJSONArray("args") ?: JSONArray()).toString() + ")"
                    code.isNotEmpty() -> "(0,eval)(" + q(code) + ")"
                    text.isNotEmpty() -> "(0,eval)(" + q(text.toString()) + ")"
                    else -> return null
                }
            }
            "css", "rmcss" -> {
                val css = spec.optString("css").ifEmpty { text.toString() }
                if (css.isEmpty()) return null
                if (kind == "css") {
                    "(function(){var s=document.createElement('style');s.setAttribute('data-evxcss','1');s.textContent=" + q(css) +
                        ";(document.head||document.documentElement).appendChild(s)})()"
                } else {
                    "(function(){var c=" + q(css) + ";[].slice.call(document.querySelectorAll('style[data-evxcss]')).forEach(function(s){if(s.textContent===c)s.remove()})})()"
                }
            }
            else -> return null
        }
        return "(function(){var B=window[${q(bridgeName)}];" +
            "function done(v,x){try{B.execres(${q(id)},${q(cid)},JSON.stringify(x?{error:String(x)}:{results:[v===undefined?null:v]}),${q(token)})}catch(y){}}" +
            "try{Promise.resolve($body).then(function(v){done(v)},function(x){done(undefined,(x&&x.message)||x)})}catch(x){done(undefined,(x&&x.message)||x)}})()"
    }

    private fun respondBg(id: String, cid: String, json: String) {
        val js = "window.__evxResp&&window.__evxResp(${q(cid)},${q(json)})"
        ui.post { try { bgViews[id]?.evaluateJavascript(js, null) } catch (e: Exception) { } }
    }

    private fun doFetch(id: String, url: String, method: String, headers: String, body: String): String {
        val e = list().find { it.id == id && it.enabled } ?: throw IllegalStateException("disabled")
        if (!url.startsWith("https://") && !url.startsWith("http://")) throw IllegalStateException("scheme")
        if (e.hosts.none { it.matches(url) }) throw IllegalStateException("no host permission")
        val m = method.uppercase(Locale.ROOT)
        if (m !in setOf("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS")) throw IllegalStateException("method")
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.instanceFollowRedirects = true
            conn.requestMethod = m
            var hasUa = false
            val hj = try { JSONObject(headers) } catch (ex: Exception) { JSONObject() }
            val cred = hj.optString("__evx_cred") == "include"
            hj.remove("__evx_cred")
            for (k in hj.keys()) {
                val lk = k.lowercase(Locale.ROOT)
                if (lk in setOf("host", "content-length", "connection", "cookie", "origin", "referer") || lk.startsWith("sec-") || lk.startsWith("proxy-")) continue
                if (lk == "user-agent") hasUa = true
                conn.setRequestProperty(k, hj.optString(k))
            }
            if (!hasUa) conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$STORE_CHROME_VERSION Mobile Safari/537.36")
            val cm = android.webkit.CookieManager.getInstance()
            // credentials: 'include' 인 요청에는 앱(웹뷰)에 저장된 그 주소의 쿠키를 붙이고, 응답의 Set-Cookie 는 저장한다
            if (cred) try { cm.getCookie(url)?.takeIf { it.isNotEmpty() }?.let { conn.setRequestProperty("Cookie", it) } } catch (ex: Exception) { }
            if (body.isNotEmpty() && m != "GET" && m != "HEAD") {
                conn.doOutput = true
                conn.outputStream.use { it.write(Base64.decode(body, Base64.DEFAULT)) }
            }
            val code = conn.responseCode
            val ins = try { conn.inputStream } catch (ex: java.io.IOException) { conn.errorStream }
            val bos = ByteArrayOutputStream()
            if (ins != null && m != "HEAD") ins.use {
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = it.read(buf)
                    if (n < 0) break
                    bos.write(buf, 0, n)
                    if (bos.size() > MAX_FETCH) throw IllegalStateException("too large")
                }
            }
            val hs = JSONObject()
            conn.headerFields?.forEach { (k, v) ->
                if (k != null && v != null) {
                    hs.put(k, v.joinToString(", "))
                    if (cred && k.equals("set-cookie", true)) v.forEach { c -> try { cm.setCookie(url, c) } catch (ex: Exception) { } }
                }
            }
            if (cred) try { cm.flush() } catch (ex: Exception) { }
            return JSONObject().put("status", code).put("statusText", conn.responseMessage ?: "")
                .put("headers", hs).put("body", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)).toString()
        } finally {
            conn.disconnect()
        }
    }

    // ───────────────────────── 백그라운드 페이지 ─────────────────────────

    /** 켜진 확장 프로그램의 백그라운드를 (다시) 시작하고, 꺼지거나 지워진 것은 끈다. 화면 스레드에서 부른다 */
    fun syncBackground() {
        bgViews.keys.toList().forEach { stopBg(it) }
        if (!supported) return
        list().filter { it.enabled && it.hasBackground }.forEach { startBg(it) }
    }

    private fun closeOffscreen(id: String) {
        offViews.remove(id)?.let { releasePopupView(it) }
    }

    private fun stopBg(id: String) {
        closeOffscreen(id)
        val wv = bgViews.remove(id) ?: return
        wrRegs.remove(id)
        actListeners.remove(id)
        popupOverride.remove(id)
        try {
            wv.stopLoading()
            wv.loadUrl("about:blank")
            wv.removeJavascriptInterface(bridgeName)
            wv.destroy()
        } catch (e: Exception) { }
    }

    fun destroyBackground() { bgViews.keys.toList().forEach { stopBg(it) } }

    private fun startBg(e: Ext) {
        try {
            val wv = WebView(ctx)
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = true
            }
            wv.addJavascriptInterface(bridge, bridgeName)
            wv.webChromeClient = consoleToDiag(e.id, "백그라운드")
            wv.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    if (request.url.host == HOST) serve(request.url) else null

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true

                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                    if (request.isForMainFrame || request.url.host == HOST) diagAdd(e.id, "백그라운드 불러오기 실패: " + request.url.path + " " + error.description)
                }

                override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                    diagAdd(e.id, "백그라운드 프로세스가 종료됐어요 (메모리 부족 등)")
                    bgViews.remove(e.id)
                    return true
                }
            }
            bgViews[e.id] = wv
            val bg = e.manifest.optJSONObject("background")
            val page = if (bg != null && bg.optString("service_worker").isEmpty()) bg.optString("page").takeIf { it.isNotEmpty() } else null
            val target = if (page != null) page.removePrefix("/") else BG_PAGE
            diagAdd(e.id, "백그라운드 시작: $target")
            wv.loadUrl("https://$HOST/${e.id}/$target?__evxbg=1")
        } catch (ex: Exception) {
            bgViews.remove(e.id)
        }
    }

    private fun bgHtml(e: Ext): String {
        val bg = e.manifest.optJSONObject("background")
        val sb = StringBuilder("<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body>")
        val sw = bg?.optString("service_worker").orEmpty()
        val module = bg?.optString("type") == "module"
        fun tag(src: String) = "<script" + (if (module) " type=\"module\"" else "") + " src=\"" +
            src.removePrefix("/").replace("\"", "&quot;") + "\"></script>"
        if (sw.isNotEmpty()) sb.append(tag(sw))
        else bg?.optJSONArray("scripts")?.let { a ->
            for (i in 0 until a.length()) a.optString(i).takeIf { it.isNotEmpty() }?.let { sb.append(tag(it)) }
        }
        sb.append("</body></html>")
        return injectHtml(e, sb.toString(), true)
    }

    private fun injectHtml(e: Ext, html: String, bg: Boolean): String {
        val flags = StringBuilder()
        if (bg) {
            flags.append("window.__evxIsBg=true;")
            if (pendingInstalled.remove(e.id)) flags.append("window.__evxInstalled=true;")
        }
        val inject = "<script>$flags$shim\nwindow.chrome=window.browser=${makeCall(e)};</script>"
        val at = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
        return if (at != null) html.substring(0, at.range.last + 1) + inject + html.substring(at.range.last + 1) else inject + html
    }

    private val bridge = Bridge()

    private fun areaFile(id: String, area: String): File? {
        if (id.isEmpty() || !id.all { it in 'a'..'z' }) return null
        if (area !in listOf("local", "sync", "managed")) return null
        return File(dataDir, "$id/$area.json")
    }

    private fun readArea(id: String, area: String): String {
        if (area == "session") return synchronized(session) { session["$id:$area"] ?: "{}" }
        val f = areaFile(id, area) ?: return "{}"
        return try { if (f.exists()) f.readText() else "{}" } catch (e: Exception) { "{}" }
    }

    private fun writeArea(id: String, area: String, json: String) {
        if (area == "session") { synchronized(session) { session["$id:$area"] = json }; return }
        val f = areaFile(id, area) ?: return
        try {
            f.parentFile?.mkdirs()
            f.writeText(json)
        } catch (e: Exception) { }
    }

    /** 웹뷰 하나에 확장 프로그램을 연결한다. 이미 연결돼 있으면 먼저 떼고 다시 붙인다. */
    fun attach(wv: WebView, incognito: Boolean) {
        detach(wv)
        try { wv.addJavascriptInterface(bridge, bridgeName) } catch (e: Exception) { }
        pages.add(wv)
        if (incognito || !supported) return // 크롬처럼 시크릿 탭에서는 확장 프로그램을 쓰지 않는다
        val hs = ArrayList<ScriptHandler>()
        for (e in list()) {
            if (!e.enabled) continue
            for (i in e.entries.indices) {
                val s = buildScript(e, i) ?: continue
                try { hs.add(WebViewCompat.addDocumentStartJavaScript(wv, s, setOf("*"))) } catch (ex: Exception) { }
            }
        }
        if (hs.isNotEmpty()) handlers[wv] = hs
    }

    fun detach(wv: WebView) {
        pages.remove(wv)
        handlers.remove(wv)?.forEach { try { it.remove() } catch (e: Exception) { } }
    }

    // ───────────────────────── 앱 안 팝업 웹뷰 ─────────────────────────

    /**
     * 확장 프로그램 팝업(action.default_popup)을 앱 안 카드로 띄울 때 쓰는 웹뷰.
     * 확장 프로그램 파일을 직접 받아 오고 chrome.* 연결을 붙인다. 링크는 [onLink] 로 넘겨 새 탭에서 열게 한다.
     */
    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    fun newPopupView(onLink: (String) -> Unit): WebView {
        val wv = WebView(ctx)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = true
        }
        wv.addJavascriptInterface(bridge, bridgeName)
        pages.add(wv)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.host == HOST) serve(request.url) else null

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                if (u.host == HOST) return false
                val s = u.toString()
                if (s.startsWith("http://") || s.startsWith("https://")) onLink(s)
                return true
            }
        }
        return wv
    }

    fun releasePopupView(wv: WebView) {
        pages.remove(wv)
        try { (wv.parent as? android.view.ViewGroup)?.removeView(wv); wv.stopLoading(); wv.destroy() } catch (e: Exception) { }
    }

    // ───────────────────────── 확장 프로그램 파일 제공 ─────────────────────────

    /** https://ext.evergreen.invalid/<id>/<경로> 요청에 확장 프로그램 안의 파일을 돌려준다 */
    fun serve(uri: Uri): WebResourceResponse? {
        val segs = uri.pathSegments
        if (segs.isEmpty()) return notFound()
        val e = list().find { it.id == segs[0] } ?: return notFound()
        val rel = segs.drop(1).joinToString("/")
        if (rel == BG_PAGE) {
            return WebResourceResponse(
                "text/html", "utf-8", 200, "OK",
                hashMapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache"),
                ByteArrayInputStream(bgHtml(e).toByteArray(Charsets.UTF_8))
            )
        }
        val f = File(e.dir, rel)
        try {
            if (!f.canonicalPath.startsWith(e.dir.canonicalPath + File.separator) || !f.isFile) {
                diagAdd(e.id, "파일 없음(404): $rel")
                return notFound()
            }
        } catch (ex: Exception) { return notFound() }
        if (uri.getQueryParameter("__evxbg") != "1") diagAdd(e.id, "파일 제공: $rel")
        val ext = f.extension.lowercase(Locale.ROOT)
        val mime = when (ext) {
            "js", "mjs" -> "text/javascript"
            "json" -> "application/json"
            "css" -> "text/css"
            "html", "htm" -> "text/html"
            "svg" -> "image/svg+xml"
            "woff2" -> "font/woff2"
            "woff" -> "font/woff"
            "wasm" -> "application/wasm"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
        val headers = hashMapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache")
        val stream: InputStream = if (mime == "text/html") {
            // 옵션/팝업 페이지: 맨 앞에 chrome.* 를 넣어 준다
            val html = f.readText(Charsets.UTF_8)
            val merged = injectHtml(e, html, uri.getQueryParameter("__evxbg") == "1")
            ByteArrayInputStream(merged.toByteArray(Charsets.UTF_8))
        } else f.inputStream()
        return WebResourceResponse(mime, if (mime.startsWith("text/") || mime == "application/json") "utf-8" else null, 200, "OK", headers, stream)
    }


    // ───────────────────────── 요청 차단 규칙 (declarativeNetRequest) ─────────────────────────
    // 지원: block · allow · allowAllRequests · redirect(url · extensionPath · regexSubstitution · transform) · upgradeScheme 규칙 (정적 rule_resources · 동적 · 세션).
    // 조건: urlFilter(||  |  *  ^) · regexFilter · resourceTypes · domainType · initiator/request 도메인.
    // modifyHeaders 는 요청을 앱이 대신 받아서(netIntercept) 요청 · 응답 헤더를 고친다 (GET 만)

    private fun dnrError(msg: String) = JSONObject().put("error", msg).toString()

    private fun dnrFile(id: String, name: String): File? =
        if (id.isNotEmpty() && id.all { it in 'a'..'z' }) File(dataDir, "$id/$name") else null

    private fun dnrLoadDynamic(id: String): JSONArray {
        val f = dnrFile(id, "dnr_dynamic.json") ?: return JSONArray()
        return try { if (f.exists()) JSONArray(f.readText()) else JSONArray() } catch (e: Exception) { JSONArray() }
    }

    private fun dnrSessionRules(id: String): JSONArray = synchronized(dnrSession) { dnrSession[id] ?: JSONArray() }

    private fun dnrRulesetOverride(id: String): Set<String>? {
        val f = dnrFile(id, "dnr_rulesets.json") ?: return null
        return try {
            if (!f.exists()) null else {
                val a = JSONArray(f.readText())
                (0 until a.length()).map { a.optString(it) }.toSet()
            }
        } catch (e: Exception) { null }
    }

    private fun dnrEnabledRulesets(e: Ext): JSONArray {
        val out = JSONArray()
        val ov = dnrRulesetOverride(e.id)
        e.manifest.optJSONObject("declarative_net_request")?.optJSONArray("rule_resources")?.let { res ->
            for (i in 0 until res.length()) {
                val r = res.optJSONObject(i) ?: continue
                val rid = r.optString("id")
                val on = if (ov != null) rid in ov else r.optBoolean("enabled", false)
                if (on) out.put(rid)
            }
        }
        return out
    }

    private fun dnrTypeBit(n: String): Int = when (n) {
        "main_frame" -> NetFilter.T_DOC
        "sub_frame" -> NetFilter.T_SUBDOC
        "stylesheet" -> NetFilter.T_CSS
        "script" -> NetFilter.T_SCRIPT
        "image" -> NetFilter.T_IMAGE
        "font" -> NetFilter.T_FONT
        "object" -> NetFilter.T_OBJECT
        "xmlhttprequest" -> NetFilter.T_XHR
        "ping", "csp_report" -> NetFilter.T_PING
        "media" -> NetFilter.T_MEDIA
        "websocket" -> NetFilter.T_WS
        "other" -> NetFilter.T_OTHER
        else -> 0
    }

    /** urlFilter(||도메인 · |시작 · 끝| · * · ^)를 정규식으로 */
    private fun dnrUrlFilter(f0: String, cs: Boolean): Regex? {
        var f = f0
        val sb = StringBuilder()
        if (f.startsWith("||")) {
            sb.append("^[a-zA-Z][a-zA-Z0-9+.-]*://([^/?#]*\\.)?")
            f = f.substring(2)
        } else if (f.startsWith("|")) {
            sb.append("^")
            f = f.substring(1)
        }
        var end = false
        if (f.endsWith("|")) { end = true; f = f.dropLast(1) }
        for (ch in f) {
            when (ch) {
                '*' -> sb.append(".*")
                '^' -> sb.append("(?:[^a-zA-Z0-9_.%-]|\$)")
                else -> {
                    if (ch in ".+?\$()|[]{}\\") sb.append('\\')
                    sb.append(ch)
                }
            }
        }
        if (end) sb.append('\$')
        return try { Regex(sb.toString(), if (cs) emptySet() else setOf(RegexOption.IGNORE_CASE)) } catch (e: Exception) { null }
    }

    /** '||example.com^' 처럼 도메인으로 시작하는 규칙은 도메인으로 미리 찾아 속도를 올린다 (아니면 null) */
    private fun dnrHostKey(o: JSONObject): String? {
        val uf = o.optJSONObject("condition")?.optString("urlFilter").orEmpty()
        if (!uf.startsWith("||")) return null
        val m = Regex("^([a-zA-Z0-9.-]+)[\\^/:?]").find(uf.substring(2)) ?: return null
        return m.groupValues[1].lowercase(Locale.ROOT).trim('.').takeIf { it.isNotEmpty() }
    }

    private fun dnrCompile(o: JSONObject): DnrRule? {
        val action = o.optJSONObject("action")?.optString("type") ?: return null
        val allow = when (action) {
            "block" -> false
            "allow", "allowAllRequests" -> true
            "redirect", "upgradeScheme", "modifyHeaders" -> false
            else -> return null
        }
        val isModify = action == "modifyHeaders"
        val reqOps = if (isModify) o.optJSONObject("action")?.optJSONArray("requestHeaders") else null
        val respOps = if (isModify) o.optJSONObject("action")?.optJSONArray("responseHeaders") else null
        val isRedirect = action == "redirect"
        val isUpgrade = action == "upgradeScheme"
        val redirectObj: JSONObject? = if (isRedirect) (o.optJSONObject("action")?.optJSONObject("redirect") ?: return null) else null
        val c = o.optJSONObject("condition") ?: JSONObject()
        fun list(k: String): List<String> {
            val a = c.optJSONArray(k) ?: return emptyList()
            return (0 until a.length()).map { a.optString(it).lowercase(Locale.ROOT) }.filter { it.isNotEmpty() }
        }
        val cs = c.optBoolean("isUrlFilterCaseSensitive", false)
        val uf = c.optString("urlFilter")
        val rf = c.optString("regexFilter")
        val re: Regex? = when {
            rf.isNotEmpty() -> try {
                Regex(rf, if (cs) emptySet() else setOf(RegexOption.IGNORE_CASE))
            } catch (e: Exception) { return null }
            uf.isNotEmpty() -> dnrUrlFilter(uf, cs) ?: return null
            else -> null
        }
        var types = 0
        val rt = c.optJSONArray("resourceTypes")
        if (rt != null) {
            for (i in 0 until rt.length()) types = types or dnrTypeBit(rt.optString(i))
        } else {
            types = dnrEvery and NetFilter.T_DOC.inv() // 크롬과 같게: 정하지 않으면 최상위 문서는 빼고 모두
        }
        val ex = c.optJSONArray("excludedResourceTypes")
        if (ex != null) for (i in 0 until ex.length()) types = types and dnrTypeBit(ex.optString(i)).inv()
        if (types == 0) return null
        val party = when (c.optString("domainType")) { "firstParty" -> 1; "thirdParty" -> 2; else -> 0 }
        return DnrRule(
            o.optInt("id"), o.optInt("priority", 1), allow, re, types, party,
            list("initiatorDomains").ifEmpty { list("domains") },
            list("excludedInitiatorDomains").ifEmpty { list("excludedDomains") },
            list("requestDomains"), list("excludedRequestDomains"),
            redirectObj, isUpgrade, isModify, reqOps, respOps
        )
    }

    private fun dnrBuildSet(e: Ext): DnrSet? {
        val raws = ArrayList<JSONObject>()
        e.manifest.optJSONObject("declarative_net_request")?.optJSONArray("rule_resources")?.let { res ->
            val ov = dnrRulesetOverride(e.id)
            for (i in 0 until res.length()) {
                val r = res.optJSONObject(i) ?: continue
                val on = if (ov != null) r.optString("id") in ov else r.optBoolean("enabled", false)
                if (!on) continue
                val txt = readText(e, r.optString("path"))?.removePrefix("\uFEFF") ?: continue
                try {
                    val a = JSONArray(txt)
                    for (k in 0 until a.length()) a.optJSONObject(k)?.let { raws.add(it) }
                } catch (ex: Exception) { }
            }
        }
        for (a in listOf(dnrLoadDynamic(e.id), dnrSessionRules(e.id))) {
            for (k in 0 until a.length()) a.optJSONObject(k)?.let { raws.add(it) }
        }
        if (raws.isEmpty()) return null
        val generic = ArrayList<DnrRule>()
        val byHost = HashMap<String, MutableList<DnrRule>>()
        var n = 0
        var hasMod = false
        for (o in raws) {
            if (n >= 50000) break
            val r = dnrCompile(o) ?: continue
            if (r.modify) hasMod = true
            n++
            val key = dnrHostKey(o)
            if (key != null) byHost.getOrPut(key) { ArrayList() }.add(r) else generic.add(r)
        }
        if (n == 0) return null
        return DnrSet(generic, byHost, n, hasMod)
    }

    /** 규칙을 (다시) 컴파일한다. 규칙이 많을 수 있어서 따로 한 줄 스레드에서 돌리고, 끝나면 한 번에 바꿔 끼운다 */
    private fun rebuildDnr() {
        dnrExec.execute {
            try {
                val m = HashMap<String, DnrSet>()
                list().filter { it.enabled }.forEach { e ->
                    try { dnrBuildSet(e)?.let { m[e.id] = it } } catch (ex: Exception) { }
                }
                dnrSets = m
            } catch (ex: Exception) { }
        }
    }

    private fun dnrUpdate(e: Ext, kind: String, json: String): String {
        val o = try { JSONObject(json) } catch (ex: Exception) { return dnrError("Invalid request") }
        when (kind) {
            "dynamic", "session" -> {
                val cur = if (kind == "dynamic") dnrLoadDynamic(e.id) else dnrSessionRules(e.id)
                val remove = HashSet<Int>()
                o.optJSONArray("removeRuleIds")?.let { a -> for (i in 0 until a.length()) remove.add(a.optInt(i)) }
                val out = ArrayList<JSONObject>()
                for (i in 0 until cur.length()) {
                    val r = cur.optJSONObject(i) ?: continue
                    if (r.optInt("id") !in remove) out.add(r)
                }
                val ids = HashSet<Int>()
                out.forEach { ids.add(it.optInt("id")) }
                val add = o.optJSONArray("addRules")
                if (add != null) {
                    for (i in 0 until add.length()) {
                        val r = add.optJSONObject(i) ?: return dnrError("Invalid rule")
                        val rid = r.optInt("id", -1)
                        if (rid < 1) return dnrError("Rule must have a unique positive integer ID.")
                        if (!ids.add(rid)) return dnrError("Rule with id $rid does not have a unique ID.")
                        if (r.optJSONObject("action")?.optString("type").isNullOrEmpty()) return dnrError("Rule with id $rid is missing action.type.")
                        out.add(r)
                    }
                }
                if (out.size > 30000) return dnrError("Rule count exceeded.")
                val arr = JSONArray()
                out.forEach { arr.put(it) }
                if (kind == "dynamic") {
                    val f = dnrFile(e.id, "dnr_dynamic.json") ?: return dnrError("Invalid extension")
                    try { f.parentFile?.mkdirs(); f.writeText(arr.toString()) } catch (ex: Exception) { return dnrError("Could not save rules") }
                } else {
                    synchronized(dnrSession) { dnrSession[e.id] = arr }
                }
            }
            "rulesets" -> {
                val cur = dnrEnabledRulesets(e)
                val set = LinkedHashSet<String>()
                for (i in 0 until cur.length()) set.add(cur.optString(i))
                o.optJSONArray("disableRulesetIds")?.let { a -> for (i in 0 until a.length()) set.remove(a.optString(i)) }
                o.optJSONArray("enableRulesetIds")?.let { a -> for (i in 0 until a.length()) set.add(a.optString(i)) }
                val f = dnrFile(e.id, "dnr_rulesets.json") ?: return dnrError("Invalid extension")
                try { f.parentFile?.mkdirs(); f.writeText(JSONArray(set.toList()).toString()) } catch (ex: Exception) { return dnrError("Could not save rulesets") }
            }
            else -> return dnrError("Invalid request")
        }
        rebuildDnr()
        return "{}"
    }

    private fun dnrSameSite(a: String, b: String): Boolean {
        fun base(h: String) = h.split('.').takeLast(2).joinToString(".")
        return base(a) == base(b)
    }

    private fun dnrDomainIn(h: String, d: String) = h == d || h.endsWith(".$d")

    private fun dnrMatch(r: DnrRule, url: String, host: String, init: String?, type: Int): Boolean {
        if ((r.types and type) == 0) return false
        val re = r.re
        if (re != null && !re.containsMatchIn(url)) return false
        if (r.party != 0 && init != null) {
            val same = dnrSameSite(host, init)
            if (r.party == 1 && !same) return false
            if (r.party == 2 && same) return false
        }
        if (r.initIn.isNotEmpty() && (init == null || r.initIn.none { dnrDomainIn(init, it) })) return false
        if (init != null && r.initEx.any { dnrDomainIn(init, it) }) return false
        if (r.reqIn.isNotEmpty() && r.reqIn.none { dnrDomainIn(host, it) }) return false
        if (r.reqEx.any { dnrDomainIn(host, it) }) return false
        return true
    }

    /**
     * 켜진 확장 프로그램의 declarativeNetRequest 규칙에 걸려 막아야 하는 요청이면 true.
     * 우선순위가 가장 높은 규칙이 이기고, 같으면 허용이 이긴다. 웹뷰의 요청 스레드에서 불린다.
     * @param initiator 요청을 낸 페이지의 호스트 (최상위 문서면 null)
     * @param type [NetFilter] 의 T_ 값 (확장자·Accept 로 추정한 값)
     */
    fun dnrBlocks(url: String, host: String?, initiator: String?, type: Int): Boolean {
        val sets = dnrSets
        if (sets.isEmpty() || host == null) return false
        val h = host.lowercase(Locale.ROOT)
        val init = initiator?.lowercase(Locale.ROOT)
        for ((id, set) in sets) {
            var bp = -1
            var ap = -1
            fun visit(rules: List<DnrRule>) {
                for (r in rules) {
                    if (!dnrMatch(r, url, h, init, type)) continue
                    if (r.allow) { if (r.priority > ap) ap = r.priority }
                    else if (r.redirect == null && !r.upgrade && !r.modify) { if (r.priority > bp) bp = r.priority }
                }
            }
            visit(set.generic)
            var d = h
            while (true) {
                set.byHost[d]?.let { visit(it) }
                val i = d.indexOf('.')
                if (i < 0) break
                d = d.substring(i + 1)
            }
            if (bp >= 0 && bp > ap) {
                val n = synchronized(dnrDiagCount) { val c = (dnrDiagCount[id] ?: 0) + 1; dnrDiagCount[id] = c; c }
                if (n <= 30) diagAdd(id, "요청 차단(규칙): " + url.take(140))
                return true
            }
        }
        return false
    }


    /**
     * declarativeNetRequest 의 redirect · upgradeScheme 규칙에 걸리면 바꿀 주소를, 아니면 null.
     * 같은 우선순위에서는 허용 > 차단 > 리다이렉트 순으로 이긴다 (차단·허용이 같거나 높으면 null).
     */
    fun dnrRedirect(url: String, host: String?, initiator: String?, type: Int): String? {
        val sets = dnrSets
        if (sets.isEmpty() || host == null) return null
        val h = host.lowercase(Locale.ROOT)
        val init = initiator?.lowercase(Locale.ROOT)
        for ((id, set) in sets) {
            var bp = -1
            var ap = -1
            var rp = -1
            var best: DnrRule? = null
            fun visit(rules: List<DnrRule>) {
                for (r in rules) {
                    if (!dnrMatch(r, url, h, init, type)) continue
                    if (r.allow) { if (r.priority > ap) ap = r.priority }
                    else if (r.redirect != null || r.upgrade) { if (r.priority > rp) { rp = r.priority; best = r } }
                    else if (r.modify) { }
                    else if (r.priority > bp) bp = r.priority
                }
            }
            visit(set.generic)
            var d = h
            while (true) {
                set.byHost[d]?.let { visit(it) }
                val i = d.indexOf('.')
                if (i < 0) break
                d = d.substring(i + 1)
            }
            val r = best ?: continue
            if (rp <= bp || rp <= ap) continue
            val target = try { dnrRedirectTarget(id, r, url) } catch (ex: Exception) { null } ?: continue
            if (target == url) continue
            val n = synchronized(dnrDiagCount) { val c = (dnrDiagCount[id] ?: 0) + 1; dnrDiagCount[id] = c; c }
            if (n <= 30) diagAdd(id, "요청 바꿈(규칙): " + url.take(100) + " → " + target.take(100))
            return target
        }
        return null
    }

    private fun dnrRedirectTarget(id: String, r: DnrRule, url: String): String? {
        if (r.upgrade) return if (url.startsWith("http://", true)) "https://" + url.substring(7) else null
        val rd = r.redirect ?: return null
        val direct = rd.optString("url")
        if (direct.isNotEmpty()) return direct
        val path = rd.optString("extensionPath")
        if (path.isNotEmpty()) return "https://$HOST/$id/" + path.trimStart('/')
        val sub = rd.optString("regexSubstitution")
        if (sub.isNotEmpty()) {
            val m = r.re?.find(url) ?: return null
            val sb = StringBuilder()
            var i = 0
            while (i < sub.length) {
                val c = sub[i]
                if (c == '\\' && i + 1 < sub.length) {
                    val n = sub[i + 1]
                    if (n.isDigit()) { sb.append(m.groups[n - '0']?.value ?: ""); i += 2; continue }
                    if (n == '\\') { sb.append('\\'); i += 2; continue }
                }
                sb.append(c); i++
            }
            return sb.toString()
        }
        val tr = rd.optJSONObject("transform") ?: return null
        val u = java.net.URI(url)
        val scheme = tr.optString("scheme").ifEmpty { u.scheme }
        var hostPart = tr.optString("host").ifEmpty { u.host ?: return null }
        val port = if (tr.has("port")) tr.optString("port") else (if (u.port >= 0) u.port.toString() else "")
        val userInfo = if (tr.has("username") || tr.has("password")) {
            val us = tr.optString("username"); val pw = tr.optString("password")
            if (us.isEmpty() && pw.isEmpty()) "" else us + (if (pw.isNotEmpty()) ":$pw" else "") + "@"
        } else (u.rawUserInfo?.let { "$it@" } ?: "")
        val pathPart = if (tr.has("path")) tr.optString("path").let { if (it.isEmpty() || it.startsWith("/")) it else "/$it" } else (u.rawPath ?: "")
        var query: String = if (tr.has("query")) tr.optString("query") else (u.rawQuery?.let { "?$it" } ?: "")
        val qt = tr.optJSONObject("queryTransform")
        if (qt != null) {
            val parts = ArrayList<Pair<String, String?>>()
            query.removePrefix("?").split('&').filter { it.isNotEmpty() }.forEach {
                val k = it.substringBefore('=')
                parts.add(k to (if (it.contains('=')) it.substringAfter('=') else null))
            }
            val rm = qt.optJSONArray("removeParams")
            if (rm != null) for (i in 0 until rm.length()) { val k = rm.optString(i); parts.removeAll { p -> p.first == k } }
            val add = qt.optJSONArray("addOrReplaceParams")
            if (add != null) for (i in 0 until add.length()) {
                val o = add.optJSONObject(i) ?: continue
                val k = java.net.URLEncoder.encode(o.optString("key"), "UTF-8")
                val v = java.net.URLEncoder.encode(o.optString("value"), "UTF-8")
                val idx = parts.indexOfFirst { p -> p.first == k }
                if (idx >= 0) parts[idx] = k to v
                else if (!o.optBoolean("replaceOnly", false)) parts.add(k to v)
            }
            query = if (parts.isEmpty()) "" else "?" + parts.joinToString("&") { p -> if (p.second == null) p.first else p.first + "=" + p.second }
        }
        val frag = if (tr.has("fragment")) tr.optString("fragment") else (u.rawFragment?.let { "#$it" } ?: "")
        if (hostPart.contains(':') && !hostPart.startsWith("[")) hostPart = "[$hostPart]"
        return scheme + "://" + userInfo + hostPart + (if (port.isNotEmpty()) ":$port" else "") + pathPart + query + frag
    }

    /**
     * [dnrRedirect] 로 정해진 주소의 내용을 대신 받아 돌려준다 (하위 리소스용). 확장 프로그램 안의 파일이면 바로 제공한다.
     * 못 받으면 null → 원래 요청을 그대로 보낸다.
     */
    fun dnrRedirectResponse(target: String, req: WebResourceRequest): WebResourceResponse? {
        return try {
            val uri = Uri.parse(target)
            if (uri.host == HOST) return serve(uri)
            if (uri.scheme != "http" && uri.scheme != "https") return null
            val c = java.net.URL(target).openConnection() as java.net.HttpURLConnection
            try {
                c.connectTimeout = 10000
                c.readTimeout = 20000
                c.instanceFollowRedirects = true
                req.requestHeaders?.forEach { (k, v) ->
                    if (!k.equals("Host", true) && !k.equals("Range", true) && !k.equals("If-None-Match", true) && !k.equals("If-Modified-Since", true)) c.setRequestProperty(k, v)
                }
                val code = c.responseCode
                val ct = c.contentType ?: "application/octet-stream"
                val mime = ct.substringBefore(';').trim().ifEmpty { "application/octet-stream" }
                val enc = Regex("charset=([^;\\s]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
                val ins = (if (code >= 400) c.errorStream else c.inputStream) ?: return null
                val status = if (code in 300..399) 200 else code.coerceIn(200, 599)
                WebResourceResponse(mime, enc, status, c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK",
                    hashMapOf("Access-Control-Allow-Origin" to "*"), ins)
            } catch (e: Exception) {
                try { c.disconnect() } catch (x: Exception) { }
                null
            }
        } catch (e: Exception) { null }
    }

    /** 켜진 규칙이 하나라도 있는가 (없으면 요청마다 따질 필요가 없다) */
    val dnrActive: Boolean get() = dnrSets.isNotEmpty()

    /** 지금 적용 중인 요청 차단 규칙 수 (확장 프로그램 '진단'에 보여 준다) */
    fun dnrRuleCount(id: String): Int = dnrSets[id]?.count ?: 0


    // ───────────────────────── webRequest · 헤더 고치기 · 우클릭 메뉴 ─────────────────────────
    // webRequest: 백그라운드가 등록한 리스너를 요청이 올 때마다 불러 준다.
    //   막는(blocking) 리스너는 결과를 기다린다(최대 1.5초, 늦으면 그 확장 프로그램은 20초 동안 건너뜀): cancel · redirectUrl · requestHeaders · responseHeaders
    //   헤더를 보거나 고쳐야 하면(요청 · 응답 헤더 리스너, modifyHeaders 규칙) 앱이 그 요청을 대신 받아서 돌려준다 (GET 만)
    // contextMenus: 링크 · 이미지를 길게 누를 때 나오는 메뉴에 항목을 더한다.

    class NetResult(val cancel: Boolean = false, val redirect: String? = null, val response: WebResourceResponse? = null)
    class MenuEntry(val extId: String, val extName: String, val id: String, val title: String)

    val netActive: Boolean get() = wrRegs.values.any { it.isNotEmpty() } || dnrSets.values.any { it.hasModify }

    private fun typeName(t: Int): String = when (t) {
        NetFilter.T_DOC -> "main_frame"
        NetFilter.T_SUBDOC -> "sub_frame"
        NetFilter.T_CSS -> "stylesheet"
        NetFilter.T_SCRIPT -> "script"
        NetFilter.T_IMAGE -> "image"
        NetFilter.T_FONT -> "font"
        NetFilter.T_OBJECT -> "object"
        NetFilter.T_XHR -> "xmlhttprequest"
        NetFilter.T_PING -> "ping"
        NetFilter.T_MEDIA -> "media"
        NetFilter.T_WS -> "websocket"
        else -> "other"
    }

    private fun wrFor(name: String, url: String, type: Int): Map<String, List<WrReg>> {
        if (wrRegs.isEmpty()) return emptyMap()
        val now = System.currentTimeMillis()
        val out = HashMap<String, MutableList<WrReg>>()
        for ((id, regs) in wrRegs) {
            for (r in regs) {
                if (r.name != name) continue
                if (r.types != 0 && (r.types and type) == 0) continue
                if (r.urls.isNotEmpty() && r.urls.none { it.matches(url) }) continue
                if (r.blocking && (wrSkip[id] ?: 0L) > now) continue
                out.getOrPut(id) { ArrayList() }.add(r)
            }
        }
        return out
    }

    /** 백그라운드의 리스너를 부른다. wait 면 막는 리스너의 결과를 기다려 돌려주고, 아니면 바로 null */
    private fun wrCall(extId: String, name: String, details: JSONObject, regs: List<WrReg>, wait: Boolean): JSONObject? {
        val rid = UUID.randomUUID().toString()
        val lids = JSONArray()
        regs.forEach { lids.put(it.lid) }
        val w = if (wait) WrWait().also { wrWaits[rid] = it } else null
        val js = "window.__evxWr&&window.__evxWr(${q(name)},${q(details.toString())},${q(rid)},$lids,$wait)"
        ui.post {
            val wv = bgViews[extId]
            if (wv == null) w?.latch?.countDown()
            else try { wv.evaluateJavascript(js, null) } catch (e: Exception) { w?.latch?.countDown() }
        }
        if (w == null) return null
        try { w.latch.await(WR_TIMEOUT_MS, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { }
        wrWaits.remove(rid)
        val r = w.result
        if (r == null) { wrSkip[extId] = System.currentTimeMillis() + 20000L; return null }
        return try { JSONObject(r) } catch (e: Exception) { null }
    }

    private fun headersToJson(h: List<Pair<String, String>>): JSONArray {
        val a = JSONArray()
        h.forEach { a.put(JSONObject().put("name", it.first).put("value", it.second)) }
        return a
    }

    private fun replaceHeaders(h: MutableList<Pair<String, String>>, a: JSONArray) {
        h.clear()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val n = o.optString("name")
            if (n.isNotEmpty()) h.add(n to o.optString("value"))
        }
    }

    private fun applyHeaderOp(h: MutableList<Pair<String, String>>, op: JSONObject) {
        val name = op.optString("header")
        if (name.isEmpty()) return
        val value = op.optString("value")
        when (op.optString("operation")) {
            "remove" -> h.removeAll { it.first.equals(name, true) }
            "set" -> { h.removeAll { it.first.equals(name, true) }; h.add(name to value) }
            "append" -> h.add(name to value)
        }
    }

    private fun dnrWalk(set: DnrSet, host: String, f: (List<DnrRule>) -> Unit) {
        f(set.generic)
        var d = host
        while (true) {
            set.byHost[d]?.let { f(it) }
            val i = d.indexOf('.')
            if (i < 0) break
            d = d.substring(i + 1)
        }
    }

    /** modifyHeaders 규칙에 걸린 (요청 헤더 작업, 응답 헤더 작업). 같은 우선순위 이상의 허용 규칙이 있으면 건너뛴다 */
    private fun dnrHeaderOps(url: String, host: String?, initiator: String?, type: Int): Pair<List<JSONObject>, List<JSONObject>>? {
        if (host == null) return null
        val h = host.lowercase(Locale.ROOT)
        val init = initiator?.lowercase(Locale.ROOT)
        val req = ArrayList<JSONObject>()
        val resp = ArrayList<JSONObject>()
        for ((_, set) in dnrSets) {
            if (!set.hasModify) continue
            var ap = -1
            val mods = ArrayList<DnrRule>()
            dnrWalk(set, h) { rules ->
                for (r in rules) {
                    if (!dnrMatch(r, url, h, init, type)) continue
                    if (r.allow) { if (r.priority > ap) ap = r.priority } else if (r.modify) mods.add(r)
                }
            }
            for (r in mods.sortedBy { it.priority }) {
                if (r.priority <= ap) continue
                r.reqOps?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { req.add(it) } }
                r.respOps?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { resp.add(it) } }
            }
        }
        return if (req.isEmpty() && resp.isEmpty()) null else req to resp
    }

    /** 영상·음악 조각을 받는 요청인가 (googlevideo · videoplayback · 미디어 종류 · Range 헤더가 붙은 요청) */
    private fun isStreamRequest(request: WebResourceRequest, type: Int): Boolean {
        val host = request.url.host?.lowercase(Locale.ROOT).orEmpty()
        if (host == "googlevideo.com" || host.endsWith(".googlevideo.com")) return true
        if (request.url.path?.contains("/videoplayback", ignoreCase = true) == true) return true
        if ((type and NetFilter.T_MEDIA) != 0) return true
        return request.requestHeaders?.keys?.any { it.equals("Range", true) } == true
    }

    /**
     * 웹뷰의 요청 스레드에서 부른다. webRequest 리스너와 modifyHeaders 규칙을 적용한다.
     * 돌려주는 값: 막기(cancel) · 다른 주소로(redirect) · 앱이 대신 받은 응답(response), 아무것도 안 하면 null
     */
    fun netIntercept(request: WebResourceRequest, initiatorHost: String?, type: Int): NetResult? {
        // 영상 조각(유튜브 googlevideo 등)은 확장 프로그램을 거치지 않고 웹뷰가 직접 받게 한다.
        // 요청마다 백그라운드 응답을 기다리거나 앱이 대신 받으면 영상이 느려져서, 유튜브가 화질을 480p 로 낮추고
        // 화질을 올리면 끊기며 오류가 나고 영상을 바꿀 때 '오프라인' 으로 보인다
        if (isStreamRequest(request, type)) return null
        val url = request.url.toString()
        val method = request.method ?: "GET"
        val main = request.isForMainFrame
        val reqId = wrSeq.incrementAndGet().toString()
        fun details(): JSONObject {
            val d = JSONObject().put("requestId", reqId).put("url", url).put("method", method)
                .put("frameId", if (main) 0 else 1).put("parentFrameId", if (main) -1 else 0).put("tabId", 1)
                .put("type", typeName(type)).put("timeStamp", System.currentTimeMillis().toDouble())
            if (initiatorHost != null) d.put("initiator", "https://$initiatorHost")
            return d
        }

        // 1) 요청 직전
        var redirect: String? = null
        for ((id, regs) in wrFor("onBeforeRequest", url, type)) {
            val res = wrCall(id, "onBeforeRequest", details(), regs, regs.any { it.blocking })
            if (res != null) {
                if (res.optBoolean("cancel")) return NetResult(cancel = true)
                val rd = res.optString("redirectUrl")
                if (rd.isNotEmpty()) redirect = rd
            }
        }
        if (redirect != null) return NetResult(redirect = redirect, response = if (main) null else dnrRedirectResponse(redirect, request))

        // 2) 헤더를 보거나 고쳐야 하나
        val sendMap = wrFor("onBeforeSendHeaders", url, type)
        val sentMap = wrFor("onSendHeaders", url, type)
        val recvMap = wrFor("onHeadersReceived", url, type)
        val startMap = wrFor("onResponseStarted", url, type)
        val doneMap = wrFor("onCompleted", url, type)
        val ops = if (dnrSets.values.any { it.hasModify }) dnrHeaderOps(url, request.url.host, initiatorHost, type) else null
        val blockingHeaders = sendMap.values.any { l -> l.any { it.blocking } } || recvMap.values.any { l -> l.any { it.blocking } }
        val needProxy = method == "GET" && (blockingHeaders || ops != null || recvMap.isNotEmpty() || startMap.isNotEmpty() || doneMap.isNotEmpty())

        val reqH = ArrayList<Pair<String, String>>()
        request.requestHeaders?.forEach { (k, v) -> if (!k.equals("Accept-Encoding", true)) reqH.add(k to v) }
        if (reqH.none { it.first.equals("Cookie", true) }) {
            try { android.webkit.CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotEmpty() }?.let { reqH.add("Cookie" to it) } } catch (e: Exception) { }
        }
        ops?.first?.forEach { applyHeaderOp(reqH, it) }
        for ((id, regs) in sendMap) {
            val d = details().put("requestHeaders", headersToJson(reqH))
            val res = wrCall(id, "onBeforeSendHeaders", d, regs, regs.any { it.blocking })
            if (res != null) {
                if (res.optBoolean("cancel")) return NetResult(cancel = true)
                res.optJSONArray("requestHeaders")?.let { replaceHeaders(reqH, it) }
            }
        }
        for ((id, regs) in sentMap) wrCall(id, "onSendHeaders", details().put("requestHeaders", headersToJson(reqH)), regs, false)
        if (!needProxy) return null

        // 3) 앱이 대신 받는다
        var c: java.net.HttpURLConnection? = null
        try {
            c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = !main
            for ((k, v) in reqH) {
                if (k.equals("Host", true) || k.equals("If-None-Match", true) || k.equals("If-Modified-Since", true)) continue
                c.addRequestProperty(k, v)
            }
            val code = c.responseCode
            val respH = ArrayList<Pair<String, String>>()
            for ((k, vs) in c.headerFields) {
                if (k == null) continue
                if (k.equals("Content-Encoding", true) || k.equals("Content-Length", true) || k.equals("Transfer-Encoding", true)) continue
                vs.forEach { respH.add(k to it) }
            }
            ops?.second?.forEach { applyHeaderOp(respH, it) }
            val reason = c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK"
            for ((id, regs) in recvMap) {
                val d = details().put("statusCode", code).put("statusLine", "HTTP/1.1 $code $reason").put("responseHeaders", headersToJson(respH))
                val res = wrCall(id, "onHeadersReceived", d, regs, regs.any { it.blocking })
                if (res != null) {
                    if (res.optBoolean("cancel")) { try { c.disconnect() } catch (e: Exception) { }; return NetResult(cancel = true) }
                    val rd = res.optString("redirectUrl")
                    if (rd.isNotEmpty()) { try { c.disconnect() } catch (e: Exception) { }; return NetResult(redirect = rd, response = if (main) null else dnrRedirectResponse(rd, request)) }
                    res.optJSONArray("responseHeaders")?.let { replaceHeaders(respH, it) }
                }
            }
            // 쿠키는 웹뷰 쿠키 저장소에 넣고, 응답에는 싣지 않는다
            val cm = android.webkit.CookieManager.getInstance()
            respH.filter { it.first.equals("Set-Cookie", true) }.forEach { try { cm.setCookie(url, it.second) } catch (e: Exception) { } }
            respH.removeAll { it.first.equals("Set-Cookie", true) }
            val done = details().put("statusCode", code).put("statusLine", "HTTP/1.1 $code $reason").put("responseHeaders", headersToJson(respH)).put("fromCache", false)
            for ((id, regs) in startMap) wrCall(id, "onResponseStarted", done, regs, false)
            for ((id, regs) in doneMap) wrCall(id, "onCompleted", done, regs, false)

            if (code in 300..399 && main) {
                val loc = respH.firstOrNull { it.first.equals("Location", true) }?.second
                if (loc != null) {
                    try { c.disconnect() } catch (e: Exception) { }
                    return NetResult(redirect = java.net.URL(java.net.URL(url), loc).toString())
                }
            }
            val ct = respH.firstOrNull { it.first.equals("Content-Type", true) }?.second ?: "application/octet-stream"
            val mime = ct.substringBefore(';').trim().ifEmpty { "application/octet-stream" }
            val enc = Regex("charset=([^;\\s]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
            val out = HashMap<String, String>()
            for ((k, v) in respH) out[k] = if (out.containsKey(k)) out[k] + ", " + v else v
            val origin = reqH.firstOrNull { it.first.equals("Origin", true) }?.second
            if (origin != null && out.keys.none { it.equals("Access-Control-Allow-Origin", true) }) {
                out["Access-Control-Allow-Origin"] = origin
                out["Access-Control-Allow-Credentials"] = "true"
            }
            val status = if (code in 300..399) 200 else code
            val ins = (if (code >= 400) c.errorStream else c.inputStream) ?: ByteArrayInputStream(ByteArray(0))
            return NetResult(response = WebResourceResponse(mime, enc, status, reason, out, ins))
        } catch (e: Exception) {
            try { c?.disconnect() } catch (x: Exception) { }
            for ((id, regs) in wrFor("onErrorOccurred", url, type)) {
                wrCall(id, "onErrorOccurred", details().put("error", e.message ?: "net::ERR_FAILED"), regs, false)
            }
            return null
        }
    }


    /** 인증 창(onAuthRequired)을 처리하는 확장 프로그램이 있는가 */
    val authActive: Boolean get() = wrRegs.values.any { l -> l.any { it.name == "onAuthRequired" } }

    /**
     * 사이트가 아이디·비밀번호를 물을 때 확장 프로그램의 onAuthRequired 리스너에게 먼저 묻는다.
     * 결과는 [done] 으로 (아이디, 비밀번호, 취소 여부) — 아이디가 null 이고 취소도 아니면 앱이 직접 묻는다. 어느 스레드에서 불릴지 모른다.
     */
    fun netAuth(host: String?, realm: String?, pageUrl: String?, done: (String?, String?, Boolean) -> Unit) {
        pool.execute {
            var user: String? = null
            var pass: String? = null
            var cancel = false
            try {
                val url = pageUrl ?: ("https://" + (host ?: ""))
                val d = JSONObject().put("requestId", wrSeq.incrementAndGet().toString()).put("url", url).put("method", "GET")
                    .put("frameId", 0).put("parentFrameId", -1).put("tabId", 1).put("type", "main_frame")
                    .put("timeStamp", System.currentTimeMillis().toDouble()).put("scheme", "basic").put("isProxy", false)
                    .put("statusCode", 401).put("statusLine", "HTTP/1.1 401 Unauthorized").put("responseHeaders", JSONArray())
                    .put("challenger", JSONObject().put("host", host ?: "").put("port", 443))
                if (realm != null) d.put("realm", realm)
                for ((id, regs) in wrFor("onAuthRequired", url, NetFilter.T_DOC)) {
                    val res = wrCall(id, "onAuthRequired", d, regs, true) ?: continue
                    if (res.optBoolean("cancel")) { cancel = true; break }
                    val c = res.optJSONObject("authCredentials")
                    if (c != null) { user = c.optString("username"); pass = c.optString("password"); break }
                }
            } catch (e: Exception) { }
            done(user, pass, cancel)
        }
    }

    // ── 우클릭 메뉴 (contextMenus) ──

    private fun cmItems(id: String): JSONArray {
        cmMem[id]?.let { return it }
        val f = dnrFile(id, "cm_items.json") ?: return JSONArray()
        val a = try { if (f.exists()) JSONArray(f.readText()) else JSONArray() } catch (e: Exception) { JSONArray() }
        cmMem[id] = a
        return a
    }

    /** 링크 · 이미지를 길게 눌렀을 때 보여 줄 확장 프로그램 메뉴 항목 (화면 스레드에서 부른다) */
    fun contextMenuEntries(contexts: Set<String>, pageUrl: String?, linkUrl: String?, srcUrl: String?): List<MenuEntry> {
        val out = ArrayList<MenuEntry>()
        for (e in list()) {
            if (!e.enabled || !hasPermission(e, "contextMenus")) continue
            val items = cmItems(e.id)
            val byId = HashMap<String, JSONObject>()
            val parents = HashSet<String>()
            for (i in 0 until items.length()) {
                val o = items.optJSONObject(i) ?: continue
                val id = o.opt("id")?.toString() ?: continue
                byId[id] = o
                o.opt("parentId")?.toString()?.let { parents.add(it) }
            }
            for (i in 0 until items.length()) {
                val o = items.optJSONObject(i) ?: continue
                val id = o.opt("id")?.toString() ?: continue
                if (o.optString("type", "normal") == "separator" || id in parents) continue
                if (o.has("visible") && !o.optBoolean("visible", true)) continue
                if (o.has("enabled") && !o.optBoolean("enabled", true)) continue
                val ca = o.optJSONArray("contexts")
                val ctxs = if (ca == null) listOf("page") else (0 until ca.length()).map { ca.optString(it) }
                if (ctxs.none { it == "all" || it in contexts }) continue
                fun patternsOk(key: String, url: String?): Boolean {
                    val pa = o.optJSONArray(key) ?: return true
                    if (pa.length() == 0) return true
                    if (url == null) return false
                    for (k in 0 until pa.length()) {
                        val rx = patternToRegex(pa.optString(k)) ?: continue
                        if (try { Regex(rx).matches(url) } catch (x: Exception) { false }) return true
                    }
                    return false
                }
                if (!patternsOk("documentUrlPatterns", pageUrl)) continue
                if (!patternsOk("targetUrlPatterns", linkUrl ?: srcUrl)) continue
                var title = o.optString("title").replace("%s", "선택한 글")
                var pid = o.opt("parentId")?.toString()
                var guard = 0
                while (pid != null && guard++ < 5) {
                    val po = byId[pid] ?: break
                    title = po.optString("title").replace("%s", "선택한 글") + " › " + title
                    pid = po.opt("parentId")?.toString()
                }
                if (title.isBlank()) title = e.name
                out.add(MenuEntry(e.id, e.name, id, title))
            }
        }
        return out
    }

    fun contextMenuClick(en: MenuEntry, pageUrl: String?, linkUrl: String?, srcUrl: String?, selection: String? = null) {
        val info = JSONObject().put("menuItemId", en.id).put("editable", false)
        pageUrl?.let { info.put("pageUrl", it) }
        linkUrl?.let { info.put("linkUrl", it) }
        srcUrl?.let { info.put("srcUrl", it); info.put("mediaType", "image") }
        selection?.let { info.put("selectionText", it.take(4000)) }
        val tab = JSONObject().put("id", 1).put("index", 0).put("windowId", 1).put("active", true).put("url", pageUrl ?: "")
        val js = "window.__evxCmClick&&window.__evxCmClick(${q(info.toString())},${q(tab.toString())})"
        ui.post { try { bgViews[en.extId]?.evaluateJavascript(js, null) } catch (e: Exception) { } }
    }

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", hashMapOf("Access-Control-Allow-Origin" to "*"),
        ByteArrayInputStream(ByteArray(0))
    )
}
