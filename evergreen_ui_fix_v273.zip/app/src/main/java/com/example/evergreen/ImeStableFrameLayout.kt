package com.example.evergreen

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * 웹 영역을 담는 FrameLayout.
 * 키보드가 올라와도 높이를 줄이지 않고 키보드가 없을 때의 높이를 그대로 유지한다.
 * (adjustResize 로 웹뷰가 줄어들면 페이지의 viewport 가 바뀌어 유튜브 같은 사이트의 레이아웃·영상 비율이 바뀐다.
 *  PC/크롬처럼 키보드는 화면 위에 덮이기만 하고 페이지 크기는 그대로다. 넘치는 아래쪽은 상위 레이아웃이 잘라낸다.)
 */
class ImeStableFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private var stableW = -1
    private var stableH = -1

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val ime = ViewCompat.getRootWindowInsets(this)?.isVisible(WindowInsetsCompat.Type.ime()) == true
        if (ime && stableH > h && stableW == w && MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY) {
            super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(stableH, MeasureSpec.EXACTLY))
        } else {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
            if (!ime) {
                stableW = measuredWidth
                stableH = measuredHeight
            }
        }
    }
}
