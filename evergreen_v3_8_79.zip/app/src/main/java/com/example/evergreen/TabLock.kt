package com.example.evergreen

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * 숨긴 탭을 다시 열 때 하는 본인 확인: 지문·얼굴 인식 (기기에 생체인식이 없으면 화면 잠금 PIN·패턴).
 */
object TabLock {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    @Volatile private var showing = false

    /** 이 기기에서 본인 확인을 쓸 수 있는가 (생체인식이나 화면 잠금이 하나도 설정돼 있지 않으면 false) */
    fun available(act: FragmentActivity): Boolean =
        BiometricManager.from(act).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS

    /** 확인에 성공하면 [onOk] 를 부른다. 취소·실패하면 아무 일도 하지 않는다 */
    fun authenticate(act: FragmentActivity, title: String, subtitle: String?, onOk: () -> Unit) {
        if (showing) return
        if (!available(act)) {
            AppToast.show(act, "기기에 지문·얼굴 인식이나 화면 잠금이 설정돼 있지 않아요")
            return
        }
        showing = true
        val prompt = BiometricPrompt(
            act, ContextCompat.getMainExecutor(act),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    showing = false
                    onOk()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { showing = false }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .apply { if (subtitle != null) setSubtitle(subtitle) }
            .setAllowedAuthenticators(AUTH)
            .build()
        try { prompt.authenticate(info) } catch (e: Exception) { showing = false }
    }
}
