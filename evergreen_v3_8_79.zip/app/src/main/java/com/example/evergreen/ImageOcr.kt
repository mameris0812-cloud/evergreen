package com.example.evergreen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * 이미지 속 글자 번역용 글자 인식 (기기 안의 ML Kit, 인터넷 필요 없음).
 *
 * - 영문(라틴) · 일본어 · 중국어를 인식한다. 한글은 이미 한국어라 번역하지 않으므로 인식하지 않는다.
 * - 어떤 언어인지는 페이지의 lang 값과 인식 결과로 정한다 (라틴 → 일본어 → 중국어 순으로 시도, 페이지 언어가 먼저).
 * - 웹툰처럼 세로로 아주 긴 이미지는 일정 높이로 잘라 나눠 읽는다 (경계에 걸린 글자는 한쪽 조각에서만 쓴다).
 * - 글자 덩어리마다 주변 배경색을 읽어 두어, 번역한 글을 같은 색 바탕 위에 얹을 수 있게 한다.
 * - 반드시 백그라운드 스레드에서 부른다.
 */
object ImageOcr {
    /** 글자 덩어리 하나. 좌표는 원본 이미지 기준(px) */
    class Block(
        val text: String,
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
        /** 글자 주변 배경색 / 그 위에 읽기 좋은 글자색 */
        val bg: Int,
        val fg: Int,
        /** 원래 글자 크기(px) 어림: 번역문 글자가 이보다 너무 커지지 않게 */
        val fs: Int = 0,
        /** 말풍선 같은 단색 바탕이 아니라 그림 위 글자: 덮지 않고 원문에 블러를 깐다 */
        val blur: Boolean = false
    )

    /** [width] x [height] 는 원본 이미지 크기 */
    /** [lang] 은 읽은 글자 종류: "latin"(영문 등) · "ja" · "zh-CN" · 모르면 "auto" */
    class Result(val width: Int, val height: Int, val blocks: List<Block>, val lang: String = "auto")

    private enum class Lang { LATIN, JAPANESE, CHINESE }

    private val latin: TextRecognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val japanese: TextRecognizer by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val chinese: TextRecognizer by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }

    private fun rec(l: Lang): TextRecognizer = when (l) {
        Lang.LATIN -> latin
        Lang.JAPANESE -> japanese
        Lang.CHINESE -> chinese
    }

    /** 이보다 작은 이미지는 읽지 않는다 */
    private const val MIN_W = 80
    private const val MIN_H = 40

    /** 읽을 때 가로가 이만큼(px)을 넘지 않게 줄인다 */
    private const val MAX_DECODE_W = 2000

    /** 긴 이미지를 나눌 때: 조각 높이 / 조각이 맡는 높이 (조각 끼리 겹치는 부분은 경계 글자를 온전히 읽으려는 여유) */
    private const val TILE_H = 2200
    private const val TILE_STEP = 2000

    /** 한 이미지에서 읽는 조각 수의 한계 (아주 긴 이미지의 끝은 건너뜀) */
    private const val MAX_TILES = 14

    /** 글자 한 줄이 이 정도 확신(0~1)에 못 미치면 버린다 (확신 값을 안 주는 경우는 거르지 않음) */
    private const val MIN_CONF = 0.4f

    /** 한 덩어리 안에서 이보다 확신이 낮은 줄은 버린다 */
    private const val LINE_MIN_CONF = 0.25f

    /** 가나가 두 글자 이상 있는 덩어리에 쓰는 낮춘 기준 */
    private const val MIN_CONF_KANA = 0.25f
    private const val LINE_MIN_CONF_KANA = 0.12f

    private class Raw(
        val text: String, val rect: Rect, val cjk: Boolean, val fs: Int = 0, val grown: Boolean = false,
        /** 이 덩어리를 이룬 줄들(줄마다 글과 범위). 말풍선이 아닌 곳의 글은 줄 모양 그대로 번역하려고 남겨 둔다 */
        val lines: List<Raw> = emptyList()
    )

    /** 말풍선 덮개 범위. [open] 이 true 면 윤곽선으로 둘러싸인 곳이 아니라 열린 바탕(제목·크레딧·자막)이라 넓히지 않았다 */
    private class Bub(val rect: Rect, val open: Boolean)

    /** [core] 는 덮개를 넓히기 전, 실제로 읽은 글자 범위(조각 좌표). 겹침을 풀 때 이 안쪽은 건드리지 않는다 */
    private class Grp(val raw: Raw, val bg: Int, val flat: Boolean, val core: Rect)

    private class Stats {
        var latin = 0
        var kana = 0
        var han = 0
        fun add(s: String) {
            for (ch in s) {
                val c = ch.code
                when {
                    c in 0x3040..0x30FF -> kana++
                    c in 0x3400..0x9FFF -> han++
                    c < 0x250 && Character.isLetter(ch) -> latin++
                }
            }
        }
    }

    /** 이미지 하나를 읽는다. 읽을 수 없는 이미지(너무 작음·해독 실패)면 null, 글자가 없으면 blocks 가 빈 결과 */
    fun recognize(bytes: ByteArray, langHint: String): Result? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            val w = bounds.outWidth
            val h = bounds.outHeight
            if (w < MIN_W || h < MIN_H) return null

            var sample = 1
            while (w / (sample * 2) >= MAX_DECODE_W) sample *= 2

            var dec: BitmapRegionDecoder? = null
            var full: Bitmap? = null
            val tall = h / sample > TILE_H + 400
            if (tall) {
                dec = try {
                    BitmapRegionDecoder.newInstance(bytes, 0, bytes.size, false)
                } catch (e: Exception) {
                    null
                }
            }
            if (dec == null) {
                // 통째로 읽는다: 메모리를 아끼려고 1200만 화소 안쪽이 되게 줄여서
                while ((w.toLong() / sample) * (h.toLong() / sample) > 12_000_000L) sample *= 2
                full = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                    ?: return null
            }
            val dh = if (full != null) full.height else h / sample
            val single = dh <= TILE_H + 400

            val blocks = ArrayList<Block>()
            val cores = ArrayList<Rect>()
            var lang: Lang? = null
            var top = 0
            var n = 0
            try {
                while (top < dh && n < MAX_TILES) {
                    val bottom = if (single) dh else minOf(dh, top + TILE_H)
                    val last = bottom >= dh
                    val keepEnd = if (last) dh else top + TILE_STEP
                    var tile: Bitmap? = if (full != null) {
                        if (single) full else Bitmap.createBitmap(full, 0, top, full.width, bottom - top)
                    } else {
                        val o = BitmapFactory.Options().apply { inSampleSize = sample }
                        dec?.decodeRegion(Rect(0, top * sample, w, minOf(h, bottom * sample)), o)
                    }
                    val src = tile
                    if (src != null && src.hasAlpha()) {
                        // 투명한 부분은 흰 바탕에 얹어서 읽는다
                        val flat = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
                        val cv = Canvas(flat)
                        cv.drawColor(Color.WHITE)
                        cv.drawBitmap(src, 0f, 0f, null)
                        if (src !== full) src.recycle()
                        tile = flat
                    }
                    if (tile != null) {
                        val raws: List<Raw>
                        if (lang == null) {
                            val d = detect(tile, langHint)
                            if (d != null) {
                                lang = d.first
                                raws = d.second
                            } else {
                                raws = emptyList()
                            }
                        } else {
                            raws = readWith(lang, tile) ?: emptyList()
                        }
                        val kept = ArrayList<Raw>()
                        for (r in raws) {
                            val absCy = (r.rect.top + r.rect.bottom) / 2 + top
                            if (absCy >= keepEnd) continue   // 다음 조각에서 읽는 글자
                            if (r.rect.height() < 8) continue
                            if (FreeTranslator.isKoreanOrEmpty(r.text)) continue
                            if (!r.cjk && letters(r.text) < 2) continue
                            kept.add(r)
                        }
                        // 같은 말풍선 안의 글자 덩어리는 하나로 합치고, 풍선 안쪽 전체를 덮을 범위로 넓힌다
                        for (g in mergeBubbles(tile, kept)) {
                            blocks.add(toBlock(g.raw, top, sample, w, h, g.bg, g.flat))
                            cores.add(
                                Rect(
                                    g.core.left * sample,
                                    (g.core.top + top) * sample,
                                    minOf(w, g.core.right * sample),
                                    minOf(h, (g.core.bottom + top) * sample)
                                )
                            )
                        }
                        if (tile !== full) tile.recycle()
                    }
                    if (last) break
                    top += TILE_STEP
                    n++
                }
            } finally {
                try {
                    dec?.recycle()
                } catch (e: Exception) {
                    // 무시
                }
                full?.recycle()
            }
            val langCode = when (lang) {
                Lang.LATIN -> "latin"
                Lang.JAPANESE -> "ja"
                Lang.CHINESE -> "zh-CN"
                null -> "auto"
            }
            return Result(w, h, separate(blocks, cores, sample), langCode)
        } catch (e: Throwable) {
            // 메모리 부족·인식기 오류 등 — 이 이미지만 건너뜀
            return null
        }
    }

    /** 인식 결과(조각 좌표)를 원본 좌표의 덩어리로 바꾼다. 세로쓰기처럼 좁고 긴 글은 번역문이 들어갈 만큼 가로로 넓힌다 */
    private fun toBlock(r: Raw, tileTop: Int, sample: Int, w: Int, h: Int, bg: Int, flat: Boolean): Block {
        var l = r.rect.left * sample
        var rr = r.rect.right * sample
        var t = (r.rect.top + tileTop) * sample
        var b = (r.rect.bottom + tileTop) * sample
        val bw = rr - l
        val bh = b - t
        if (!r.grown && r.cjk && bh > bw * 2) {
            val nw = minOf((bh * 0.5f).toInt(), (bw * 2.2f).toInt())
            if (nw > bw) {
                val cx = (l + rr) / 2
                l = cx - nw / 2
                rr = l + nw
            }
        }
        // 글자 가장자리가 비치지 않게 조금 키운다
        val pad = if (r.grown) 0 else 3 * sample
        l = maxOf(0, l - pad)
        t = maxOf(0, t - pad)
        rr = minOf(w, rr + pad)
        b = minOf(h, b + pad)
        val lum = (0.299f * Color.red(bg) + 0.587f * Color.green(bg) + 0.114f * Color.blue(bg)) / 255f
        val fg = if (lum >= 0.55f) Color.parseColor("#111111") else Color.WHITE
        val fsz = (if (r.fs > 0) r.fs else minOf(r.rect.width(), r.rect.height())) * sample
        return Block(r.text, l, t, rr, b, bg, fg, fsz, !flat)
    }

    // ───────────────────────── 덮개끼리 겹침 풀기 ─────────────────────────

    /**
     * 서로 다른 말풍선의 번역 덮개가 겹치면(넓힌 범위·세로쓰기 가로 넓히기·가장자리 여유 때문에 생김)
     * 겹친 부분을 둘이 반씩 나눠 갖도록 맞닿는 가장자리를 잘라 낸다.
     * 실제로 읽은 글자 범위([cores])는 항상 덮여 있도록 그 안쪽으로는 자르지 않는다.
     * 글자 범위끼리 위아래·좌우로 갈라 낼 수 없는 쌍은 그대로 둔다.
     */
    private fun separate(blocks: List<Block>, cores: List<Rect>, sample: Int): List<Block> {
        val n = blocks.size
        if (n < 2 || cores.size != n) return blocks
        val rs = Array(n) { Rect(blocks[it].left, blocks[it].top, blocks[it].right, blocks[it].bottom) }
        val gap = maxOf(1, sample)
        for (pass in 0 until 3) {
            var changed = false
            for (i in 0 until n) {
                for (j in i + 1 until n) {
                    val a = rs[i]
                    val b = rs[j]
                    val ix = minOf(a.right, b.right) - maxOf(a.left, b.left)
                    val iy = minOf(a.bottom, b.bottom) - maxOf(a.top, b.top)
                    if (ix <= 0 || iy <= 0) continue
                    val ca = cores[i]
                    val cb = cores[j]
                    // 어느 방향으로 갈라 낼 수 있나: 글자 범위끼리 그 방향으로 이미 떨어져 있어야 한다
                    val xOk = ca.right <= cb.left || cb.right <= ca.left
                    val yOk = ca.bottom <= cb.top || cb.bottom <= ca.top
                    val useX = when {
                        xOk && yOk -> ix <= iy
                        xOk -> true
                        yOk -> false
                        else -> continue
                    }
                    if (useX) {
                        // 왼쪽에 있는 쪽(글자 범위 기준)을 first 로
                        val firstIsA = ca.right <= cb.left
                        val f = if (firstIsA) a else b
                        val s = if (firstIsA) b else a
                        val fc = if (firstIsA) ca else cb
                        val sc = if (firstIsA) cb else ca
                        val mid = (f.right + s.left) / 2
                        val cut = mid.coerceIn(fc.right, sc.left)
                        f.right = minOf(f.right, maxOf(fc.right, cut - gap))
                        s.left = maxOf(s.left, minOf(sc.left, cut + gap))
                    } else {
                        val firstIsA = ca.bottom <= cb.top
                        val f = if (firstIsA) a else b
                        val s = if (firstIsA) b else a
                        val fc = if (firstIsA) ca else cb
                        val sc = if (firstIsA) cb else ca
                        val mid = (f.bottom + s.top) / 2
                        val cut = mid.coerceIn(fc.bottom, sc.top)
                        f.bottom = minOf(f.bottom, maxOf(fc.bottom, cut - gap))
                        s.top = maxOf(s.top, minOf(sc.top, cut + gap))
                    }
                    changed = true
                }
            }
            if (!changed) break
        }
        return List(n) {
            val o = blocks[it]
            val r = rs[it]
            Block(o.text, r.left, r.top, r.right, r.bottom, o.bg, o.fg, o.fs, o.blur)
        }
    }

    // ───────────────────────── 언어 고르기 ─────────────────────────

    private fun order(hint: String): List<Lang> {
        val h = hint.lowercase()
        return when {
            h.startsWith("ja") -> listOf(Lang.JAPANESE, Lang.LATIN, Lang.CHINESE)
            h.startsWith("zh") -> listOf(Lang.CHINESE, Lang.JAPANESE, Lang.LATIN)
            else -> listOf(Lang.LATIN, Lang.JAPANESE, Lang.CHINESE)
        }
    }

    private fun accept(l: Lang, raws: List<Raw>): Boolean {
        val st = Stats()
        for (r in raws) st.add(r.text)
        return when (l) {
            // 영문: 글자가 몇 개는 있고, 한자·가나(잘못 읽은 흔적)보다 확실히 많을 때
            Lang.LATIN -> st.latin >= 3 && st.latin >= (st.kana + st.han) * 2
            Lang.JAPANESE -> st.kana >= 1 || st.han >= 2 || st.latin >= 3
            Lang.CHINESE -> st.han >= 2
        }
    }

    private fun hanCount(raws: List<Raw>): Int {
        val st = Stats()
        for (r in raws) st.add(r.text)
        return st.han
    }

    private fun kanaCount(raws: List<Raw>): Int {
        val st = Stats()
        for (r in raws) st.add(r.text)
        return st.kana
    }

    /** 첫 조각에서 어느 인식기가 맞는지 찾는다. 맞는 게 없으면 null */
    private fun detect(bmp: Bitmap, hint: String): Pair<Lang, List<Raw>>? {
        var tries = 0
        var jaResult: List<Raw>? = null
        for (l in order(hint)) {
            if (tries >= 3) break
            tries++
            val raws = readWith(l, bmp) ?: continue
            if (!accept(l, raws)) continue
            if (l == Lang.JAPANESE) {
                // 가나가 없고 한자만 있으면 중국어일 수 있다: 중국어로도 읽어 한자를 더 많이 읽는 쪽을 쓴다
                if (kanaCount(raws) == 0 && hanCount(raws) > 0) {
                    jaResult = raws
                    continue
                }
            }
            if (l == Lang.CHINESE && jaResult != null) {
                return if (hanCount(raws) > hanCount(jaResult)) Pair(Lang.CHINESE, raws) else Pair(Lang.JAPANESE, jaResult)
            }
            return Pair(l, raws)
        }
        return jaResult?.let { Pair(Lang.JAPANESE, it) }
    }

    private fun readWith(l: Lang, bmp: Bitmap): List<Raw>? {
        return try {
            val t = Tasks.await(rec(l).process(InputImage.fromBitmap(bmp, 0)))
            rawBlocks(t)
        } catch (e: Throwable) {
            null
        }
    }

    /** ML Kit 의 글자 덩어리를 우리 모양으로: 확신이 낮은 줄은 빼고, 줄을 이어 한 문장으로 만든다 */
    private fun rawBlocks(t: Text): List<Raw> {
        val out = ArrayList<Raw>()
        for (b in t.textBlocks) {
            val lines = b.lines
            val anyConf = lines.any { it.confidence > 0f }
            // 가나가 두 글자 이상 읽힌 덩어리는 진짜 일본어일 가능성이 높아 기준을 낮춘다
            // (세로쓰기·색 말풍선의 짧은 대사가 확신이 낮게 나와 통째로 버려지던 것을 막음)
            val kanaN = Stats().also { st -> for (ln in lines) st.add(ln.text) }.kana
            val minConf = if (kanaN >= 2) MIN_CONF_KANA else MIN_CONF
            val lineMin = if (kanaN >= 2) LINE_MIN_CONF_KANA else LINE_MIN_CONF
            if (anyConf && lines.maxOf { it.confidence } < minConf) continue
            var rect: Rect? = null
            val sb = StringBuilder()
            var cjk = false
            val lineRaws = ArrayList<Raw>()
            for (ln in lines) {
                if (anyConf && ln.confidence < lineMin) continue
                val txt = fixLongMark(ln.text.trim())
                if (txt.isEmpty()) continue
                val bb = ln.boundingBox ?: continue
                val st = Stats().apply { add(txt) }
                val lineCjk = st.kana + st.han > 0
                if (sb.isNotEmpty()) sb.append(if (cjk || lineCjk) "" else " ")
                sb.append(txt)
                cjk = cjk || lineCjk
                lineRaws.add(Raw(txt, Rect(bb), lineCjk))
                if (rect == null) rect = Rect(bb) else rect.union(bb)
            }
            val rc = rect ?: continue
            val text = sb.toString().trim()
            if (text.isEmpty()) continue
            out.add(Raw(text, rc, cjk, 0, false, lineRaws))
        }
        return out
    }

    /**
     * 일본어 글자 뒤의 장음 기호(ー, 세로쓰기에서는 선 하나)를 인식기가 숫자 1·알파벳 l·I·세로선(|)으로 잘못 읽는 일이 많다
     * ("勿体ねー" → "勿体ね1"). 가나 바로 뒤에 붙어 있고 앞뒤가 숫자가 아닌 그 글자들만 ー 로 되돌린다.
     */
    private val LONG_MARK_MISREAD = Regex("(?<=[\\u3041-\\u3096\\u30A1-\\u30FA])[1lI|\\uFF5C\\u4E28\\u01C0\\u2223](?![0-9\\uFF10-\\uFF19])")

    private fun fixLongMark(s: String): String {
        if (s.length < 2) return s
        return LONG_MARK_MISREAD.replace(s, "\u30FC")
    }

    private fun letters(s: String): Int {
        var n = 0
        for (ch in s) if (Character.isLetter(ch)) n++
        return n
    }


    // ───────────────────────── 말풍선 ─────────────────────────

    private fun overlapRatio(a: Rect, b: Rect): Float {
        val l = maxOf(a.left, b.left)
        val t = maxOf(a.top, b.top)
        val r = minOf(a.right, b.right)
        val bt = minOf(a.bottom, b.bottom)
        if (r <= l || bt <= t) return 0f
        val inter = (r - l).toLong() * (bt - t)
        val m = minOf(a.width().toLong() * a.height(), b.width().toLong() * b.height())
        return if (m <= 0L) 0f else inter.toFloat() / m.toFloat()
    }

    /**
     * 글자 덩어리 둘레의 바탕색이 이어진 곳(말풍선 안쪽)을 찾아, 그 안에서 윤곽선 쪽으로 최대한 넓힌 사각형을 돌려준다.
     * 인식 못 한 작은 글자(후리가나·말끝 등)까지 덮고, 번역문이 들어갈 자리도 넓어진다. 못 찾으면 원래 범위.
     */
    private fun bubbleRect(bmp: Bitmap, rc: Rect, bg: Int, all: List<Rect>): Bub {
        try {
            val bw = bmp.width
            val bh = bmp.height
            val margin = minOf(200, (maxOf(rc.width(), rc.height()) * 0.8f).toInt() + 24)
            val wl = maxOf(0, rc.left - margin)
            val wt = maxOf(0, rc.top - margin)
            val wr = minOf(bw, rc.right + margin)
            val wb = minOf(bh, rc.bottom + margin)
            val ww = wr - wl
            val wh = wb - wt
            if (ww <= 0 || wh <= 0 || ww.toLong() * wh > 1_500_000L) return Bub(rc, true)
            val px = IntArray(ww * wh)
            bmp.getPixels(px, 0, ww, wl, wt, ww, wh)
            val br = Color.red(bg)
            val bgn = Color.green(bg)
            val bbl = Color.blue(bg)
            val fill = BooleanArray(ww * wh)
            val stack = IntArray(ww * wh)
            var sp = 0

            fun close(c: Int): Boolean =
                abs(Color.red(c) - br) + abs(Color.green(c) - bgn) + abs(Color.blue(c) - bbl) <= 60

            // 글자 덩어리 둘레(4px 바깥)에서 시작
            val sl = rc.left - wl - 4
            val st = rc.top - wt - 4
            val sr = rc.right - wl + 4
            val sb = rc.bottom - wt + 4
            var x = sl
            while (x <= sr) {
                for (y in intArrayOf(st, sb)) {
                    if (x in 0 until ww && y in 0 until wh) {
                        val i = y * ww + x
                        if (!fill[i] && close(px[i])) {
                            fill[i] = true
                            stack[sp++] = i
                        }
                    }
                }
                x += 3
            }
            var y = st
            while (y <= sb) {
                for (xx in intArrayOf(sl, sr)) {
                    if (xx in 0 until ww && y in 0 until wh) {
                        val i = y * ww + xx
                        if (!fill[i] && close(px[i])) {
                            fill[i] = true
                            stack[sp++] = i
                        }
                    }
                }
                y += 3
            }
            if (sp == 0) return Bub(rc, true)

            while (sp > 0) {
                val i = stack[--sp]
                val cx = i % ww
                val cy = i / ww
                if (cx > 0) {
                    val j = i - 1
                    if (!fill[j] && close(px[j])) {
                        fill[j] = true
                        stack[sp++] = j
                    }
                }
                if (cx < ww - 1) {
                    val j = i + 1
                    if (!fill[j] && close(px[j])) {
                        fill[j] = true
                        stack[sp++] = j
                    }
                }
                if (cy > 0) {
                    val j = i - ww
                    if (!fill[j] && close(px[j])) {
                        fill[j] = true
                        stack[sp++] = j
                    }
                }
                if (cy < wh - 1) {
                    val j = i + ww
                    if (!fill[j] && close(px[j])) {
                        fill[j] = true
                        stack[sp++] = j
                    }
                }
            }

            // 바탕색이 창 가장자리 두 변 이상에 닿으면 윤곽선으로 막힌 말풍선이 아니라 열린 바탕(제목·크레딧이 있는 흰 여백 등)
            run {
                var lf = false
                var rt = false
                var tp = false
                var bt = false
                for (yy in 0 until wh) {
                    if (fill[yy * ww]) lf = true
                    if (fill[yy * ww + ww - 1]) rt = true
                }
                for (xx in 0 until ww) {
                    if (fill[xx]) tp = true
                    if (fill[(wh - 1) * ww + xx]) bt = true
                }
                val sides = (if (lf) 1 else 0) + (if (rt) 1 else 0) + (if (tp) 1 else 0) + (if (bt) 1 else 0)
                if (sides >= 2) return Bub(rc, true)
            }

            // 글자로 읽은 자리도 바탕으로 친다 (글자 획은 바탕색이 아니라서)
            for (r in all) {
                val l0 = maxOf(r.left, wl) - wl
                val t0 = maxOf(r.top, wt) - wt
                val r0 = minOf(r.right, wr) - wl
                val b0 = minOf(r.bottom, wb) - wt
                for (yy in t0 until b0) for (xx in l0 until r0) fill[yy * ww + xx] = true
            }

            fun ok(x0: Int, y0: Int, x1: Int, y1: Int): Boolean {
                var cnt = 0
                var tot = 0
                for (yy in y0 until y1) {
                    for (xx in x0 until x1) {
                        tot++
                        if (fill[yy * ww + xx]) cnt++
                    }
                }
                return tot > 0 && cnt >= tot * 0.8f
            }

            var l = (rc.left - wl).coerceIn(0, ww)
            var t = (rc.top - wt).coerceIn(0, wh)
            var r = (rc.right - wl).coerceIn(0, ww)
            var b = (rc.bottom - wt).coerceIn(0, wh)
            val step = 3
            var grew = true
            var rounds = 0
            while (grew && rounds < 120) {
                grew = false
                rounds++
                if (t - step >= 0 && ok(l, t - step, r, t)) {
                    t -= step
                    grew = true
                }
                if (b + step <= wh && ok(l, b, r, b + step)) {
                    b += step
                    grew = true
                }
                if (l - step >= 0 && ok(l - step, t, l, b)) {
                    l -= step
                    grew = true
                }
                if (r + step <= ww && ok(r, t, r + step, b)) {
                    r += step
                    grew = true
                }
            }
            // 윤곽선에 닿지 않게 안쪽으로 2px, 단 원래 글자 범위는 항상 포함
            return Bub(
                Rect(
                    minOf(rc.left, l + wl + 2),
                    minOf(rc.top, t + wt + 2),
                    maxOf(rc.right, r + wl - 2),
                    maxOf(rc.bottom, b + wt - 2)
                ),
                false
            )
        } catch (e: Throwable) {
            return Bub(rc, true)
        }
    }

    /** 글자 덩어리 바로 바깥 둘레 중 바탕색과 비슷한 곳의 비율 (말풍선·단색 바탕이면 높고, 그림 위 글자면 낮다) */
    private fun flatRatio(bmp: Bitmap, rc: Rect, bg: Int): Float {
        val bw = bmp.width
        val bh = bmp.height
        val br = Color.red(bg)
        val bgn = Color.green(bg)
        val bbl = Color.blue(bg)
        var tot = 0
        var hit = 0
        val step = maxOf(2, (rc.width() + rc.height()) * 2 / 200)
        fun test(x: Int, y: Int) {
            if (x < 0 || y < 0 || x >= bw || y >= bh) return
            val c = bmp.getPixel(x, y)
            tot++
            if (abs(Color.red(c) - br) + abs(Color.green(c) - bgn) + abs(Color.blue(c) - bbl) <= 48) hit++
        }
        for (off in intArrayOf(3, 6)) {
            val l = rc.left - off
            val r = rc.right + off
            val t = rc.top - off
            val b = rc.bottom + off
            var x = l
            while (x <= r) {
                test(x, t)
                test(x, b)
                x += step
            }
            var y = t
            while (y <= b) {
                test(l, y)
                test(r, y)
                y += step
            }
        }
        return if (tot == 0) 1f else hit.toFloat() / tot.toFloat()
    }

    /**
     * 열린 바탕(말풍선이 아닌 곳)의 여러 줄 덩어리를 줄마다 나눌지: 가로쓰기이면서
     * ① 단색 여백 위이거나 ② 줄 높이가 1.6배 넘게 다르거나(제목+로고+작은 글) ③ 줄 사이가 줄 높이의 1.2배보다 벌어졌으면 나눈다.
     * 세로쓰기는 한 문장의 세로줄들일 가능성이 커서 나누지 않는다.
     */
    private fun splitLines(bmp: Bitmap, r: Raw, bg: Int): Boolean {
        val ls = r.lines
        if (ls.size < 2) return false
        if (ls.count { it.rect.width() >= it.rect.height() } * 2 <= ls.size) return false
        if (flatRatio(bmp, r.rect, bg) >= 0.6f) return true
        var minH = Int.MAX_VALUE
        var maxH = 0
        for (l in ls) {
            minH = minOf(minH, l.rect.height())
            maxH = maxOf(maxH, l.rect.height())
        }
        if (minH > 0 && maxH.toFloat() / minH > 1.6f) return true
        val sorted = ls.sortedBy { it.rect.top }
        for (k in 1 until sorted.size) {
            val gap = sorted[k].rect.top - sorted[k - 1].rect.bottom
            if (gap > 1.2f * minOf(sorted[k].rect.height(), sorted[k - 1].rect.height())) return true
        }
        return false
    }

    /** 같은 말풍선 안의 덩어리를 하나로 합친다 (세로쓰기는 오른쪽 줄부터, 가로쓰기는 위 줄부터 읽는 순서) */
    private fun mergeBubbles(bmp: Bitmap, kept: List<Raw>): List<Grp> {
        val n = kept.size
        if (n == 0) return emptyList()
        val bgs = IntArray(n)
        val exp = ArrayList<Rect>(n)
        val rects = ArrayList<Rect>(n)
        for (r in kept) rects.add(r.rect)
        val opens = BooleanArray(n)
        for (i in 0 until n) {
            bgs[i] = sampleBg(bmp, kept[i].rect)
            val bb = bubbleRect(bmp, kept[i].rect, bgs[i], rects)
            exp.add(bb.rect)
            opens[i] = bb.open
        }
        val parent = IntArray(n) { it }
        fun find(x: Int): Int {
            var a = x
            while (parent[a] != a) {
                parent[a] = parent[parent[a]]
                a = parent[a]
            }
            return a
        }
        for (i in 0 until n) {
            for (j in i + 1 until n) {
                // 읽은 글자 범위끼리 분명히 겹치는 조각(「ー..」·「0」 같은 작은 조각이 따로 읽힌 것)은 한 덩어리로 본다.
                // 열린 바탕의 글(제목·크레딧 줄)은 가까이 있어도 합치지 않는다 — 합치면 줄 모양·크기가 사라진다
                val touching = overlapRatio(kept[i].rect, kept[j].rect) > 0.1f
                if (touching || overlapRatio(exp[i], exp[j]) >= 0.3f) {
                    val a = find(i)
                    val b = find(j)
                    if (a != b) parent[b] = a
                }
            }
        }
        val groups = LinkedHashMap<Int, ArrayList<Int>>()
        for (i in 0 until n) groups.getOrPut(find(i)) { ArrayList() }.add(i)

        val out = ArrayList<Grp>()
        for (ids in groups.values) {
            if (ids.size == 1 && opens[ids[0]] && splitLines(bmp, kept[ids[0]], bgs[ids[0]])) {
                // 열린 바탕의 글이 문단이 아니라 따로 노는 줄들(제목·로고·크레딧 등)이면: 줄마다 따로 번역해 원래 줄 모양·크기를 지킨다.
                // 한 문장으로 이어지는 여러 줄 글은 이 길로 오지 않고 그대로 합쳐 번역한다
                for (ln in kept[ids[0]].lines) {
                    if (ln.rect.height() < 8) continue
                    if (FreeTranslator.isKoreanOrEmpty(ln.text)) continue
                    if (!ln.cjk && letters(ln.text) < 2) continue
                    val lbg = sampleBg(bmp, ln.rect)
                    val lflat = flatRatio(bmp, ln.rect, lbg) >= 0.6f
                    out.add(Grp(Raw(ln.text, ln.rect, ln.cjk, minOf(ln.rect.width(), ln.rect.height()), false), lbg, lflat, Rect(ln.rect)))
                }
                continue
            }
            val members = ArrayList<Raw>()
            for (id in ids) members.add(kept[id])
            var vert = 0
            for (m in members) if (m.cjk && m.rect.height() > m.rect.width() * 3 / 2) vert++
            val vertical = vert * 2 > members.size
            val sorted = if (vertical) {
                members.sortedWith(compareByDescending<Raw> { it.rect.centerX() }.thenBy { it.rect.top })
            } else {
                members.sortedWith(compareBy<Raw>({ it.rect.centerY() }, { it.rect.left }))
            }
            val sb = StringBuilder()
            var prevCjk = false
            for ((k, m) in sorted.withIndex()) {
                if (k > 0) sb.append(if (prevCjk || m.cjk) "" else " ")
                sb.append(m.text)
                prevCjk = m.cjk
            }
            val u = Rect(exp[ids[0]])
            val o = Rect(kept[ids[0]].rect)
            var fs = 0
            var best = ids[0]
            var bestA = -1L
            for (id in ids) {
                u.union(exp[id])
                u.union(kept[id].rect)
                o.union(kept[id].rect)
                val rr = kept[id].rect
                fs = maxOf(fs, minOf(rr.width(), rr.height()))
                val a = rr.width().toLong() * rr.height()
                if (a > bestA) {
                    bestA = a
                    best = id
                }
            }
            val grown = u.width() > o.width() + 4 || u.height() > o.height() + 4
            val big = u.width().toLong() * u.height() * 2 >= o.width().toLong() * o.height() * 3
            val flat = big || flatRatio(bmp, kept[best].rect, bgs[best]) >= 0.6f
            out.add(Grp(Raw(sb.toString(), u, members.any { it.cjk }, fs, grown), bgs[best], flat, Rect(o)))
        }
        return out
    }

    // ───────────────────────── 배경색 ─────────────────────────

    /**
     * 글자 덩어리 바로 바깥 둘레의 색들 중 가장 많은 색을 배경색으로 쓴다.
     * (말풍선이면 흰색, 자막 바탕이면 그 바탕색 — 그림 위 글자는 가장 비슷한 색)
     */
    private fun sampleBg(bmp: Bitmap, rc: Rect): Int {
        val counts = HashMap<Int, IntArray>()
        val bw = bmp.width
        val bh = bmp.height
        val perimeter = (rc.width() + rc.height()) * 2
        val step = maxOf(2, perimeter / 300)
        fun add(x: Int, y: Int) {
            if (x < 0 || y < 0 || x >= bw || y >= bh) return
            val c = bmp.getPixel(x, y)
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            val key = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
            val a = counts.getOrPut(key) { IntArray(4) }
            a[0]++
            a[1] += r
            a[2] += g
            a[3] += b
        }
        for (off in intArrayOf(3, 6)) {
            val l = rc.left - off
            val r = rc.right + off
            val t = rc.top - off
            val b = rc.bottom + off
            var x = l
            while (x <= r) {
                add(x, t)
                add(x, b)
                x += step
            }
            var y = t
            while (y <= b) {
                add(l, y)
                add(r, y)
                y += step
            }
        }
        var best: IntArray? = null
        for (a in counts.values) if (best == null || a[0] > best[0]) best = a
        val bst = best ?: return Color.WHITE
        return Color.rgb(bst[1] / bst[0], bst[2] / bst[0], bst[3] / bst[0])
    }

    fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)
}
