package com.example.evergreen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.SystemClock
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** 서비스 → 앱(액티비티) 연결: 알림의 '정지' 버튼이 눌리면 재생 중인 미디어를 멈춘다. */
object MediaBridge {
    @Volatile var onStop: (() -> Unit)? = null

    /** 내장 플레이어가 백그라운드에서 재생 중일 때 알림의 '정지' 로 멈추기 위한 연결 */
    @Volatile var playerStop: (() -> Unit)? = null

    /**
     * 시스템 미디어 플레이어(알림창·잠금화면)에서 온 조작.
     * a = "play" / "pause" / "seek"(v = 위치 ms) / "skip"(v = 이동 ms, 음수면 되감기) / "prev" / "next"
     */
    @Volatile var onControl: ((String, Long) -> Unit)? = null

    /** 시스템 미디어 플레이어에 보여 줄 그림 (사이트 아이콘) */
    @Volatile var art: Bitmap? = null

    /** 알림을 눌렀을 때 열어 줄 탭 (BrowserTab 의 identityHashCode). 0 이면 특정 탭 없음 */
    @Volatile var openTabId: Int = 0
}

/**
 * 백그라운드 오디오용 포그라운드 서비스.
 * 영상/소리가 재생되는 동안만 떠 있으면서 앱이 화면 밖으로 나가거나 화면이 꺼져도 시스템이 앱을 멈추지 못하게 한다.
 */
class MediaService : Service() {

    companion object {
        // 채널의 중요도는 만든 뒤에 바꿀 수 없어서, 소리·팝업 없는 최소 중요도 채널을 새 이름으로 만든다
        // 백그라운드 유지용 알림은 '알림 끔' 채널로 보내서 알림창·상태 표시줄에 나타나지 않게 한다.
        // (포그라운드 서비스는 알림 객체가 꼭 있어야 해서, 보이지만 않게 하는 방식이다)
        private const val CH = "media_playback_hidden"
        private const val OLD_CH = "media_playback"
        private const val OLD_CH2 = "media_playback_quiet"
        private const val ID = 4201
        private const val ACTION_STOP = "com.example.evergreen.MEDIA_STOP"
        private const val ACTION_TOGGLE = "com.example.evergreen.MEDIA_TOGGLE"
        private const val ACTION_REW = "com.example.evergreen.MEDIA_REW"
        private const val ACTION_FF = "com.example.evergreen.MEDIA_FF"
        private const val ACTION_PREV = "com.example.evergreen.MEDIA_PREV"
        private const val ACTION_NEXT = "com.example.evergreen.MEDIA_NEXT"
        // 미디어 컨트롤 알림은 최소 중요도 채널로 보낸다: 상태 표시줄 아이콘·팝업·알림 목록 항목은 숨기고,
        // 시스템 미디어 플레이어(세션)만 남긴다. 중요도는 만든 뒤에 못 바꿔서 새 이름을 쓴다.
        private const val CH_CTL = "media_controls_min"
        private const val OLD_CH_CTL = "media_controls"
        // Android 13+ 는 시스템 미디어 플레이어를 세션에서 직접 만들기 때문에, 알림 항목은 '알림 끔' 채널로 보내
        // 알림 패널에 한 줄로 뜨지 않게 한다. (12 이하는 알림이 있어야 플레이어가 떠서 최소 중요도로 둔다)
        private const val CH_CTL_HIDDEN = "media_controls_hidden"
        private const val SKIP_MS = 10_000L
        // 시스템 미디어 패널(Android 13+, 삼성 One UI 포함)용 「커스텀 동작」 이름. 패널은 이전·재생·다음 3칸만 기본으로 그리고
        // 되감기·앞으로 같은 표준 동작에는 칸을 주지 않아서, 10초 되감기·앞으로를 커스텀 동작으로 넣어 5칸(⏪ ⏮ ⏯ ⏭ ⏩)으로 만든다
        private const val CA_REW = "com.example.evergreen.CA_REW"
        private const val CA_FF = "com.example.evergreen.CA_FF"

        /**
         * [controls] 가 true 면 시스템 미디어 플레이어(MediaSession)에 제목·아티스트·재생 위치와 조작 버튼을 보여 준다.
         * false 면 예전처럼 백그라운드 유지용 조용한 알림만 띄운다.
         */
        fun start(
            ctx: Context, title: String, sub: String,
            controls: Boolean = false, artist: String = "",
            playing: Boolean = true, posMs: Long = 0L, durMs: Long = -1L,
            buffering: Boolean = false
        ): Boolean {
            return try {
                ContextCompat.startForegroundService(
                    ctx,
                    Intent(ctx, MediaService::class.java)
                        .putExtra("title", title).putExtra("sub", sub)
                        .putExtra("controls", controls).putExtra("artist", artist)
                        .putExtra("playing", playing).putExtra("buffering", buffering).putExtra("pos", posMs).putExtra("dur", durMs)
                )
                true
            } catch (e: Exception) {
                // 백그라운드에서 시작이 막힌 경우 등: 호출한 쪽이 다음에 다시 시도할 수 있게 실패를 알린다
                false
            }
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, MediaService::class.java)) } catch (e: Exception) {}
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.deleteNotificationChannel(OLD_CH)
            nm.deleteNotificationChannel(OLD_CH2)
            nm.createNotificationChannel(
                NotificationChannel(CH, "백그라운드 재생 유지 (표시 안 함)", NotificationManager.IMPORTANCE_NONE).apply {
                    setShowBadge(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_SECRET
                    setSound(null, null)
                    enableVibration(false)
                    enableLights(false)
                }
            )
            // 미디어 컨트롤용: 소리 없이 알림창·잠금화면에 보이는 채널
            nm.deleteNotificationChannel(OLD_CH_CTL)
            nm.createNotificationChannel(
                NotificationChannel(CH_CTL_HIDDEN, "미디어 컨트롤 (표시 안 함)", NotificationManager.IMPORTANCE_NONE).apply {
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    setSound(null, null)
                    enableVibration(false)
                    enableLights(false)
                }
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_CTL, "미디어 컨트롤 (조용히)", NotificationManager.IMPORTANCE_MIN).apply {
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    setSound(null, null)
                    enableVibration(false)
                    enableLights(false)
                }
            )
        }
    }

    private var session: MediaSession? = null

    private fun ensureSession(): MediaSession {
        session?.let { return it }
        val s = MediaSession(this, "evergreen_media")
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { MediaBridge.onControl?.invoke("play", 0L) }
            override fun onPause() { MediaBridge.onControl?.invoke("pause", 0L) }
            override fun onSeekTo(pos: Long) { MediaBridge.onControl?.invoke("seek", pos) }
            override fun onFastForward() { MediaBridge.onControl?.invoke("skip", SKIP_MS) }
            override fun onRewind() { MediaBridge.onControl?.invoke("skip", -SKIP_MS) }
            override fun onSkipToNext() { MediaBridge.onControl?.invoke("next", 0L) }
            override fun onSkipToPrevious() { MediaBridge.onControl?.invoke("prev", 0L) }
            override fun onCustomAction(action: String, extras: Bundle?) {
                when (action) {
                    CA_REW -> MediaBridge.onControl?.invoke("skip", -SKIP_MS)
                    CA_FF -> MediaBridge.onControl?.invoke("skip", SKIP_MS)
                }
            }
            override fun onStop() { stopAll() }
        })
        s.isActive = true
        session = s
        return s
    }

    private fun releaseSession() {
        session?.let { runCatching { it.isActive = false; it.release() } }
        session = null
    }

    private fun stopAll() {
        MediaBridge.onStop?.invoke()
        MediaBridge.playerStop?.invoke()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releaseSession()
        super.onDestroy()
    }

    private fun servicePi(code: Int, action: String): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, MediaService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** 알림을 누르면 재생 중인 탭이 있는 창이 앞으로 나오고 그 탭이 열린다 (탭 번호는 extra 로 넘긴다) */
    private fun openPi(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_OPEN_TAB, MediaBridge.openTabId),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** 시스템 미디어 플레이어에 보이는 알림 + 세션 갱신 */
    private fun showControls(title: String, sub: String, artist: String, playing: Boolean, posMs: Long, durMs: Long, buffering: Boolean = false) {
        val s = ensureSession()
        val art = MediaBridge.art
        s.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist.ifBlank { sub })
                .putString(MediaMetadata.METADATA_KEY_ALBUM, sub)
                // 곡/영상이 바뀐 걸 시스템 플레이어가 확실히 알아채도록 그림이 달라지면 식별값도 달라지게 한다
                .putString(MediaMetadata.METADATA_KEY_MEDIA_ID, "$title|${System.identityHashCode(art)}")
                .apply {
                    if (durMs > 0) putLong(MediaMetadata.METADATA_KEY_DURATION, durMs)
                    if (art != null) {
                        putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art)
                        putBitmap(MediaMetadata.METADATA_KEY_ART, art)
                        putBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON, art)
                    }
                }
                .build()
        )
        var actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_STOP or PlaybackState.ACTION_FAST_FORWARD or PlaybackState.ACTION_REWIND or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS
        if (durMs > 0) actions = actions or PlaybackState.ACTION_SEEK_TO
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(actions)
                // 첫 번째는 왼쪽 끝, 두 번째는 오른쪽 끝 칸에 놓인다 (이전·다음이 있을 때)
                .addCustomAction(PlaybackState.CustomAction.Builder(CA_REW, "10초 뒤로", R.drawable.ic_rewind_10).build())
                .addCustomAction(PlaybackState.CustomAction.Builder(CA_FF, "10초 앞으로", R.drawable.ic_forward_10).build())
                .setState(
                    // 로딩(버퍼링) 중이면 시스템 미디어 플레이어가 재생/일시정지 버튼 자리에 로딩 고리를 보여 준다
                    if (buffering) PlaybackState.STATE_BUFFERING
                    else if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    posMs.coerceAtLeast(0L), if (playing && !buffering) 1f else 0f, SystemClock.elapsedRealtime()
                )
                .build()
        )

        val open = openPi()
        val ctlCh = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) CH_CTL_HIDDEN else CH_CTL
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, ctlCh)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setSmallIcon(R.drawable.ic_notif_evergreen)
            .setContentTitle(title)
            .setContentText(artist.ifBlank { sub })
            .setSubText(sub)
            .setContentIntent(open)
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            @Suppress("DEPRECATION") b.setPriority(Notification.PRIORITY_MIN)
        }
        if (art != null) b.setLargeIcon(art)
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_previous), "이전 영상", servicePi(5, ACTION_PREV)).build())
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_rew), "되감기", servicePi(2, ACTION_REW)).build())
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
            if (playing) "일시정지" else "재생", servicePi(3, ACTION_TOGGLE)).build())
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_ff), "앞으로", servicePi(4, ACTION_FF)).build())
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_next), "다음 영상", servicePi(6, ACTION_NEXT)).build())
        b.setStyle(
            Notification.MediaStyle().setMediaSession(s.sessionToken).setShowActionsInCompactView(0, 2, 4)
        )
        ServiceCompat.startForeground(this, ID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            return START_NOT_STICKY
        }
        // 시스템 미디어 플레이어 알림의 버튼
        when (intent?.action) {
            ACTION_TOGGLE -> { MediaBridge.onControl?.invoke("toggle", 0L); return START_NOT_STICKY }
            ACTION_REW -> { MediaBridge.onControl?.invoke("skip", -SKIP_MS); return START_NOT_STICKY }
            ACTION_FF -> { MediaBridge.onControl?.invoke("skip", SKIP_MS); return START_NOT_STICKY }
            ACTION_PREV -> { MediaBridge.onControl?.invoke("prev", 0L); return START_NOT_STICKY }
            ACTION_NEXT -> { MediaBridge.onControl?.invoke("next", 0L); return START_NOT_STICKY }
        }
        val title = intent?.getStringExtra("title").orEmpty().ifBlank { "재생 중" }
        val sub = intent?.getStringExtra("sub").orEmpty()
        if (intent?.getBooleanExtra("controls", false) == true) {
            try {
                showControls(
                    title, sub, intent.getStringExtra("artist").orEmpty(),
                    intent.getBooleanExtra("playing", true),
                    intent.getLongExtra("pos", 0L), intent.getLongExtra("dur", -1L),
                    intent.getBooleanExtra("buffering", false)
                )
            } catch (e: Throwable) {
                // 컨트롤 알림을 만들다 실패해도 앱이 꺼지지 않게, 단순한 알림으로 포그라운드만 유지한다
                runCatching {
                    val n = NotificationCompat.Builder(this, CH)
                        .setSmallIcon(android.R.drawable.ic_media_play)
                        .setContentTitle(title).setContentText(sub).setOngoing(true).build()
                    ServiceCompat.startForeground(this, ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                }
            }
            return START_NOT_STICKY
        }
        // 미디어 컨트롤을 끈 경우: 세션을 없애고 예전 조용한 알림만 쓴다
        releaseSession()

        val open = openPi()
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, MediaService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif_evergreen)
            .setContentTitle(title)
            .setContentText(sub)
            .setContentIntent(open)
            .addAction(0, "정지", stop)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setShowWhen(false)
            .build()
        ServiceCompat.startForeground(this, ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        return START_NOT_STICKY
    }
}
