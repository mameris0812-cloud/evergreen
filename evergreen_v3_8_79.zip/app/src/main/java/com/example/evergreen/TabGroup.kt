package com.example.evergreen

/** 탭 그룹: 이름 / 색상 / 접힘 상태를 가진다. 탭은 BrowserTab.groupId 로 그룹에 속한다. */
class TabGroup(
    val id: Int,
    var name: String,
    var color: Int,
    var collapsed: Boolean = false
) {
    /** 탭 화면에서 펼쳐져 있는지. false 면 그룹 전체가 카드 한 칸으로 보이고, 누르면 펼쳐진다 (탭바의 접힘(collapsed)과는 따로) */
    var swExpanded: Boolean = false

    companion object {
        /** 그룹 색상 팔레트 */
        val COLORS = intArrayOf(
            0xFF2FA35B.toInt(), // 초록
            0xFFD93025.toInt(), // 빨강
            0xFFF29900.toInt(), // 주황
            0xFF3978E8.toInt(), // 파랑
            0xFF12B5CB.toInt(), // 청록
            0xFF9334E6.toInt(), // 보라
            0xFFE52592.toInt(), // 분홍
            0xFF5F6368.toInt()  // 회색
        )
    }
}
