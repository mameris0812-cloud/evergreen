package com.example.evergreen

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import java.net.URLEncoder

/**
 * 성인 모드 > 「키워드 추천」: 지금 열려 있는 사이트의 페이지에서 영상 목록을 읽어, 내가 등록해 둔 키워드가 들어갔거나 비슷한 영상을 골라 준다.
 *  - 페이지를 읽는 것도 계산도 모두 폰 안에서만 한다. 키워드는 서버로 보내지 않고 이 앱의 설정(Prefs)에만 저장한다.
 *  - 영상 찾기 = 페이지의 링크 중 썸네일 · 영상 모양인 것을 [SCAN_JS] 로 모은다 (현재 탭 또는 열린 탭 전부).
 *  - 추천 = ① 제목/주소에 키워드가 들어간 영상(점수순) ② 키워드는 없지만 ①의 제목들에 자주 나온 낱말(= 비슷한 키워드)이 든 영상 ('비슷').
 */
object AdultReco {

    class PageItem(val url: String, val title: String, val site: String = "")
    /** similar=true 면 키워드가 직접 들어간 건 아니고 비슷한 낱말로 고른 것. matched 는 맞은 키워드(또는 비슷한 낱말) */
    class Hit(val url: String, val title: String, val site: String, val score: Int, val matched: List<String>, val similar: Boolean)
    class Result(val hits: List<Hit>, val related: List<String>, val scanned: Int)

    const val MAX_KEYWORDS = 30

    /** 페이지에서 영상 링크 후보를 JSON 문자열로 돌려준다: [{u:주소, t:제목}, ...] (최대 400개) */
    const val SCAN_JS = """(function(){try{var out=[],seen={},here=location.href.split('#')[0];
var as=document.querySelectorAll('a[href]');
for(var i=0;i<as.length&&out.length<400;i++){var a=as[i],h=a.href;
if(!/^https?:/.test(h)||seen[h]||h.split('#')[0]===here)continue;
var img=a.querySelector('img,video,picture');
var vid=!!a.querySelector('[class*=duration],[class*=thumb],[class*=video],[class*=preview]')||/video|watch|view|movie|embed|play|\/v\//i.test(h);
if(!img&&!vid)continue;
var t=(a.getAttribute('title')||(img&&(img.getAttribute('alt')||img.getAttribute('title')))||a.textContent||'').replace(/\s+/g,' ').trim();
if(t.length<2)continue;seen[h]=1;out.push({u:h,t:t.slice(0,160)});}
return JSON.stringify(out)}catch(e){return '[]'}})()"""

    /**
     * 웹사이트 안에 띄우는 추천 (모든 http 페이지의 최상위 문서에 넣는다). 키워드는 [applyJs] 로 넘긴다.
     *  - 키워드가 든 영상 썸네일에 초록 테두리, 비슷한 영상에 점선 테두리를 둘러 한눈에 보이게 한다.
     *  - 오른쪽 아래 「★ 추천 N」 알약을 누르면 아래에서 올라오는 목록이 열리고, 누르면 그 영상으로 가거나(↧ 는 목록 위치로 스크롤) 한다.
     *  - 더 불러온 영상(무한 스크롤)은 DOM 이 바뀔 때 다시 읽는다. 앱 쪽 점수 계산([recommend])과 같은 규칙이다.
     *  - 글자는 textContent 로만 넣는다 (페이지 제목이 마크업으로 해석되지 않게).
     */
    private const val OVERLAY_JS = """(function(KW){
if(window!==window.top)return;
var G=window.__evAdult;if(G){G.set(KW);return}
G=window.__evAdult={};
var STOP={the:1,and:1,for:1,with:1,from:1,video:1,videos:1,free:1,full:1,new:1,best:1,hd:1,www:1,com:1,http:1,https:1,min:1,sec:1,views:1,'영상':1,'동영상':1,'무료':1,'다시보기':1,'보기':1,'최신':1,'모음':1,'시리즈':1,'채널':1};
var kws=[],root=null,fab=null,panel=null,timer=0,open=false,obs=null,last=null;
function tok(s){return s.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(function(w){return w.length>=2&&!STOP[w]&&!/^\d+${'$'}/.test(w)})}
function el(tag,css,txt){var e=document.createElement(tag);if(css)e.style.cssText=css;if(txt!=null)e.textContent=txt;return e}
function collect(){var out=[],seen={},here=location.href.split('#')[0],as=document.querySelectorAll('a[href]');
 for(var i=0;i<as.length&&out.length<500;i++){var a=as[i],h=a.href;
  if(!/^https?:/.test(h)||seen[h]||h.split('#')[0]===here||(root&&root.contains(a)))continue;
  var img=a.querySelector('img,video,picture');
  var vid=!!a.querySelector('[class*=duration],[class*=thumb],[class*=video],[class*=preview]')||/video|watch|view|movie|embed|play|\/v\//i.test(h);
  if(!img&&!vid)continue;
  var t=(a.getAttribute('title')||(img&&(img.getAttribute('alt')||img.getAttribute('title')))||a.textContent||'').replace(/\s+/g,' ').trim();
  if(t.length<2)continue;seen[h]=1;out.push({a:a,u:h,t:t.slice(0,160)})}
 return out}
function calc(){
 var all=collect(),direct=[],rest=[];
 all.forEach(function(it){var t=it.t.toLowerCase(),u=it.u.toLowerCase(),sc=0,m=[];
  kws.forEach(function(k){var inT=t.indexOf(k)>=0,inU=u.indexOf(k)>=0||u.indexOf(k.replace(/ /g,'-'))>=0||u.indexOf(k.replace(/ /g,'+'))>=0||u.indexOf(k.replace(/ /g,'_'))>=0;
   if(inT||inU){sc+=(inT?3:0)+(inU?1:0);m.push(k)}});
  if(m.length){it.sc=sc+2*(m.length-1);it.m=m;direct.push(it)}else rest.push(it)});
 direct.sort(function(a,b){return b.sc-a.sc});
 var have={};kws.forEach(function(k){have[k]=1;tok(k).forEach(function(w){have[w]=1})});
 var freq={};direct.forEach(function(it){var seen={};tok(it.t).forEach(function(w){if(!have[w]&&!seen[w]){seen[w]=1;freq[w]=(freq[w]||0)+1}})});
 var need=direct.length>=3?2:1;
 var rel=Object.keys(freq).filter(function(w){return freq[w]>=need}).sort(function(a,b){return freq[b]-freq[a]||(a<b?-1:1)}).slice(0,8);
 var sim=[];if(rel.length){var rs={};rel.forEach(function(w){rs[w]=1});
  rest.forEach(function(it){var sh=[];tok(it.t).forEach(function(w){if(rs[w]&&sh.indexOf(w)<0)sh.push(w)});if(sh.length){it.sc=sh.length;it.m=sh;sim.push(it)}});
  sim.sort(function(a,b){return b.sc-a.sc})}
 return {direct:direct,sim:sim,rel:rel,n:all.length}}
function ensure(){if(root&&root.isConnected)return;
 root=el('div','position:fixed;z-index:2147483646;left:0;right:0;bottom:0;pointer-events:none;font:14px/1.35 system-ui,sans-serif;');
 root.id='__evadult_root';
 fab=el('div','position:fixed;right:14px;bottom:84px;pointer-events:auto;background:#2e9e5b;color:#fff;border-radius:22px;padding:10px 16px;font-weight:600;box-shadow:0 3px 12px rgba(0,0,0,.35);display:none;user-select:none;-webkit-user-select:none;');
 fab.onclick=function(){open=!open;draw()};
 panel=el('div','position:fixed;left:0;right:0;bottom:0;max-height:64vh;overflow:auto;pointer-events:auto;background:#1f2822;color:#e4ebe5;border-radius:20px 20px 0 0;padding:14px 16px 22px;box-shadow:0 -6px 24px rgba(0,0,0,.45);display:none;');
 root.appendChild(fab);root.appendChild(panel);document.documentElement.appendChild(root)}
function marks(r){var old=document.querySelectorAll('[data-evk]');for(var i=0;i<old.length;i++)old[i].removeAttribute('data-evk');
 if(!r)return;r.direct.forEach(function(it){it.a.setAttribute('data-evk','1')});r.sim.forEach(function(it){it.a.setAttribute('data-evk','2')})}
function style(){if(document.getElementById('__evadult_css'))return;var s=el('style');s.id='__evadult_css';
 s.textContent='[data-evk="1"]{outline:3px solid #2e9e5b!important;outline-offset:-3px!important;border-radius:6px}[data-evk="2"]{outline:2px dashed #e0a526!important;outline-offset:-2px!important;border-radius:6px}@keyframes evk{0%,100%{outline-color:#fff}50%{outline-color:#2e9e5b}}[data-evflash]{animation:evk .5s 3!important}';
 (document.head||document.documentElement).appendChild(s)}
function row(it,sim){var r=el('div','display:flex;align-items:center;gap:10px;padding:10px 12px;margin:6px 0;border-radius:14px;background:rgba(255,255,255,.07);');
 var box=el('div','flex:1;min-width:0');
 box.appendChild(el('div','display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:14px;',it.t));
 var tag=el('div','margin-top:4px;font-size:12px;color:'+(sim?'#e0a526':'#5fd08d'),(sim?'비슷 · ':'일치 · ')+it.m.join(', '));box.appendChild(tag);
 box.onclick=function(){location.href=it.u};
 var go=el('div','flex:none;width:36px;height:36px;border-radius:18px;background:rgba(255,255,255,.12);text-align:center;line-height:36px;font-size:16px;','↧');
 go.onclick=function(e){e.stopPropagation();open=false;draw();try{it.a.scrollIntoView({behavior:'smooth',block:'center'});it.a.setAttribute('data-evflash','1');setTimeout(function(){it.a.removeAttribute('data-evflash')},1700)}catch(x){}};
 r.appendChild(box);r.appendChild(go);return r}
function draw(){ensure();var r=last;
 if(!kws.length||!r||(!r.direct.length&&!r.sim.length)){fab.style.display='none';panel.style.display='none';return}
 fab.textContent='★ 추천 '+(r.direct.length+r.sim.length);fab.style.display=open?'none':'block';
 if(!open){panel.style.display='none';return}
 panel.textContent='';
 var head=el('div','display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;');
 head.appendChild(el('div','font-weight:700;font-size:16px;','키워드 추천'));
 var x=el('div','padding:4px 10px;font-size:18px;','✕');x.onclick=function(){open=false;draw()};head.appendChild(x);panel.appendChild(head);
 panel.appendChild(el('div','font-size:12px;color:#9fb0a4;margin-bottom:6px;','읽은 영상 '+r.n+'개 중 일치 '+r.direct.length+' · 비슷 '+r.sim.length+(r.rel.length?'  ·  비슷한 키워드: '+r.rel.join(', '):'')));
 r.direct.slice(0,30).forEach(function(it){panel.appendChild(row(it,false))});
 r.sim.slice(0,20).forEach(function(it){panel.appendChild(row(it,true))});
 panel.style.display='block'}
function run(){timer=0;if(!kws.length){last=null;marks(null);if(root)draw();return}
 style();ensure();last=calc();marks(last);draw()}
function sched(){if(timer)clearTimeout(timer);timer=setTimeout(run,700)}
G.set=function(k){kws=(k||[]).map(function(s){return String(s).toLowerCase()});if(!kws.length){open=false}run()};
try{obs=new MutationObserver(sched);obs.observe(document.body||document.documentElement,{childList:true,subtree:true})}catch(e){}
window.addEventListener('load',sched);
G.set(KW)
})(__KW__)"""

    /** 열려 있는 모든 페이지에 키워드를 반영하는 스크립트. 빈 목록이면 표시를 걷는다 */
    fun applyJs(keywords: List<String>): String = OVERLAY_JS.replace("__KW__", JSONArray(keywords.map(::norm)).toString())

    private val STOP = setOf(
        "the", "and", "for", "with", "from", "video", "videos", "free", "full", "new", "best", "hd", "www", "com", "http", "https",
        "영상", "동영상", "무료", "다시보기", "보기", "최신", "모음", "시리즈", "채널", "min", "sec", "views"
    )

    fun norm(s: String): String = s.trim().lowercase().replace(Regex("\\s+"), " ")

    /** 쉼표 · 줄바꿈으로 여러 개를 한꺼번에 넣을 수 있다. 중복 · 빈 값 제거, 최대 [MAX_KEYWORDS] 개 */
    fun addKeywords(current: List<String>, input: String): List<String> {
        val out = LinkedHashSet<String>(current)
        for (p in input.split(',', '\n', '，', '、')) {
            val k = norm(p).take(40)
            if (k.length >= 2) out.add(k)
        }
        return out.take(MAX_KEYWORDS)
    }

    fun tokens(text: String): List<String> =
        text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 && it !in STOP && !it.all(Char::isDigit) }

    /** [SCAN_JS] 가 돌려준 글(evaluateJavascript 결과: 따옴표로 싼 JSON 문자열)을 항목 목록으로 바꾼다 */
    fun parseScan(raw: String?, site: String): List<PageItem> = runCatching {
        if (raw.isNullOrBlank() || raw == "null") return emptyList()
        val inner = org.json.JSONTokener(raw).nextValue() as? String ?: return emptyList()
        val arr = JSONArray(inner)
        List(arr.length()) { val o = arr.getJSONObject(it); PageItem(o.getString("u"), o.optString("t"), site) }
    }.getOrDefault(emptyList())

    /** 여러 탭에서 모은 영상 중 같은 주소는 하나로 합친다 */
    fun dedupe(items: List<PageItem>): List<PageItem> = items.distinctBy { it.url }

    fun recommend(keywords: List<String>, items: List<PageItem>, limit: Int = 40): Result {
        val kws = keywords.map(::norm).filter { it.isNotEmpty() }.distinct()
        val all = dedupe(items)
        if (kws.isEmpty() || all.isEmpty()) return Result(emptyList(), emptyList(), all.size)

        val direct = ArrayList<Hit>()
        val rest = ArrayList<PageItem>()
        for (it in all) {
            val t = it.title.lowercase(); val u = it.url.lowercase()
            var score = 0; val m = ArrayList<String>()
            for (k in kws) {
                val inT = t.contains(k)
                val inU = u.contains(k) || u.contains(k.replace(' ', '-')) || u.contains(k.replace(' ', '+')) || u.contains(k.replace(' ', '_'))
                if (inT || inU) { score += (if (inT) 3 else 0) + (if (inU) 1 else 0); m.add(k) }
            }
            if (m.isEmpty()) rest.add(it) else direct.add(Hit(it.url, it.title.ifBlank { it.url }, it.site, score + 2 * (m.size - 1), m, false))
        }
        direct.sortByDescending { it.score }

        // 비슷한 키워드: 맞은 제목에 같이 나온 낱말 (직접 맞은 영상이 3개 미만이면 한 번만 나와도 인정)
        val have = kws.flatMap { tokens(it) }.toSet() + kws
        val freq = HashMap<String, Int>()
        for (h in direct) for (w in tokens(h.title).toSet()) if (w !in have) freq[w] = (freq[w] ?: 0) + 1
        val need = if (direct.size >= 3) 2 else 1
        val related = freq.entries.filter { it.value >= need }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(8).map { it.key }

        // 비슷한 영상: 키워드는 없지만 비슷한 낱말이 든 것 (겹치는 낱말이 많을수록 앞)
        val similar = ArrayList<Hit>()
        if (related.isNotEmpty()) {
            val rel = related.toSet()
            for (it in rest) {
                val shared = tokens(it.title).filter { w -> w in rel }.distinct()
                if (shared.isNotEmpty()) similar.add(Hit(it.url, it.title.ifBlank { it.url }, it.site, shared.size, shared, true))
            }
            similar.sortByDescending { it.score }
        }
        return Result((direct + similar).take(limit), related, all.size)
    }

    // ───────── 저장 ─────────
    fun load(prefs: Prefs): List<String> = runCatching {
        val a = JSONArray(prefs.adultKeywords); List(a.length()) { a.getString(it) }
    }.getOrDefault(emptyList())

    fun save(prefs: Prefs, list: List<String>) { prefs.adultKeywords = JSONArray(list).toString() }

    // ───────── 화면 ─────────
    /**
     * [scan] 은 영상을 읽어 온다 (allTabs=false: 지금 탭, true: 열린 탭 전부). 다 읽으면 한 번 콜백한다.
     * [open] 은 주소를 새 탭으로 연다. [onChanged] 는 키워드 · 「웹사이트에 표시」가 바뀔 때 열린 페이지에 반영하라고 알린다
     */
    fun show(
        act: Activity, prefs: Prefs,
        scan: (allTabs: Boolean, done: (List<PageItem>) -> Unit) -> Unit,
        open: (String) -> Unit,
        onChanged: () -> Unit
    ) {
        val d = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val accent = act.getColor(R.color.ev_accent)
        val cOn = ThemeColors.get(act.window.decorView, com.google.android.material.R.attr.colorOnSurface, Color.BLACK)
        val cVar = ThemeColors.get(act.window.decorView, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)
        val cardBg = (cOn and 0xFFFFFF) or 0x12000000
        val amber = Color.parseColor("#E0A526")

        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val scroll = ScrollView(act).apply { addView(root) }
        val dlg = ThemedDialogBuilder(act).setTitle("키워드 추천").setView(scroll).setPositiveButton("닫기", null).create()

        fun label(t: String, size: Float = 12f, color: Int = cVar, bold: Boolean = false) = TextView(act).apply {
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, size); setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        fun card(pad: Int = 12) = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(cardBg) }
        }
        fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
        fun chip(t: String, style: Int, onClick: () -> Unit) = TextView(act).apply { // style 0=윤곽 1=채움 2=옅은 채움
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); gravity = Gravity.CENTER
            setTextColor(if (style == 1) Color.WHITE else cOn)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                when (style) { 1 -> setColor(accent); 2 -> setColor(cardBg); else -> { setColor(Color.TRANSPARENT); setStroke(dp(1), cVar) } }
            }
            setOnClickListener { onClick() }
        }
        fun wrapRow(items: List<View>): View {
            val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            val maxW = act.resources.displayMetrics.widthPixels - dp(32 + 48 + 24)
            var line = LinearLayout(act); var used = 0
            box.addView(line)
            for (v in items) {
                v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
                val w = v.measuredWidth + dp(8)
                if (used + w > maxW && used > 0) { line = LinearLayout(act); box.addView(line); used = 0 }
                line.addView(v, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(3), dp(8), dp(3)) })
                used += w
            }
            return box
        }

        var items: List<PageItem> = emptyList()
        var scanning = false
        var scannedAll = false
        var everScanned = false
        var showKw = load(prefs).isEmpty() // 키워드가 없으면 키워드 입력을 펼쳐서 시작
        var wantFocus = showKw // 다음에 그릴 때 입력칸에 커서를 두고 키보드를 올린다

        fun changed(render: () -> Unit) { render(); onChanged() }

        fun render() {
            root.removeAllViews()
            val kws = load(prefs)

            // ① 찾기 버튼 (가장 먼저)
            val actions = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            fun scanBtn(text: String, all: Boolean, primary: Boolean) = chip(text, if (primary) 1 else 2) {
                if (kws.isEmpty()) { showKw = true; wantFocus = true; AppToast.show(act, "먼저 키워드를 등록해 주세요"); render(); return@chip }
                scanning = true; scannedAll = all; render()
                scan(all) { list -> act.runOnUiThread { items = list; scanning = false; everScanned = true; render() } }
            }
            val b1 = scanBtn(if (everScanned && !scannedAll) "↻ 이 페이지 다시 읽기" else "이 페이지에서 찾기", false, !scannedAll || !everScanned)
            val b2 = scanBtn("열린 탭 전부", true, scannedAll && everScanned)
            actions.addView(b1, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
            actions.addView(b2, LinearLayout.LayoutParams(0, -2, 1f))
            root.addView(actions, lp(4))

            // ② 결과
            val res = if (everScanned && !scanning && kws.isNotEmpty()) recommend(kws, items) else null
            when {
                scanning -> root.addView(label("페이지를 읽는 중…", 13f).apply { setPadding(0, dp(14), 0, dp(6)) })
                res == null -> root.addView(card(14).apply {
                    addView(label("사이트의 목록 페이지(검색 결과 · 추천 목록)를 연 채로 눌러 주세요.\n웹사이트 안에서도 ★ 알약으로 바로 볼 수 있어요.", 13f))
                }, lp(12))
                res.scanned == 0 -> root.addView(label("영상 링크를 못 찾았어요. 영상이 여러 개 나열된 페이지에서 해 보세요.", 13f).apply { setPadding(0, dp(14), 0, dp(6)) })
                else -> {
                    val direct = res.hits.count { !it.similar }
                    root.addView(label("읽은 ${res.scanned}개 중 일치 $direct · 비슷 ${res.hits.size - direct}", 12f).apply { setPadding(dp(2), dp(14), 0, dp(4)) })
                    if (res.hits.isEmpty()) root.addView(label("이 페이지에는 키워드가 든 영상이 없어요. 다른 페이지에서 해 보세요.", 13f))
                    for (h in res.hits) {
                        val c = card(12).apply {
                            addView(label(h.title.take(100), 14f, cOn).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
                            val host = h.site.ifBlank { runCatching { java.net.URI(h.url).host }.getOrNull() ?: "" }
                            addView(label((if (h.similar) "비슷 · " else "일치 · ") + h.matched.joinToString(", ") + (if (host.isNotEmpty()) "  ·  $host" else ""), 12f, if (h.similar) amber else accent).apply { setPadding(0, dp(4), 0, 0) })
                            setOnClickListener { dlg.dismiss(); open(h.url) }
                        }
                        root.addView(c, lp(6))
                    }
                    if (res.related.isNotEmpty()) {
                        root.addView(label("비슷한 키워드 · 눌러서 등록", 12f).apply { setPadding(dp(2), dp(14), 0, dp(2)) })
                        root.addView(wrapRow(res.related.map { w -> chip("+ $w", 0) { save(prefs, addKeywords(load(prefs), w)); changed(::render) } }))
                    }
                }
            }

            // ③ 키워드 (접었다 펴기)
            val kwCard = card(12)
            val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(label("내 키워드 ${kws.size}/$MAX_KEYWORDS", 14f, cOn, true), LinearLayout.LayoutParams(0, -2, 1f))
            head.addView(label(if (showKw) "접기 ▴" else "편집 ▾", 13f, accent))
            head.setOnClickListener { showKw = !showKw; wantFocus = showKw; render() }
            kwCard.addView(head)
            if (kws.isNotEmpty() && !showKw) kwCard.addView(label(kws.joinToString("  ·  "), 13f).apply { setPadding(0, dp(6), 0, 0); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            if (showKw) {
                if (kws.isNotEmpty()) kwCard.addView(wrapRow(kws.map { k -> chip("$k  ✕", 1) { save(prefs, load(prefs) - k); changed(::render) } }), lp(6))
                val input = EditText(act).apply {
                    hint = "키워드 입력 · 쉼표로 여러 개"; inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
                    setTextColor(cOn); setHintTextColor(cVar); imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
                }
                fun submit() {
                    val before = load(prefs)
                    val next = addKeywords(before, input.text.toString())
                    if (next.size == before.size && input.text.isNotBlank()) AppToast.show(act, "이미 있거나 너무 짧아요 (2글자 이상)")
                    save(prefs, next); wantFocus = true; changed(::render)
                }
                input.setOnEditorActionListener { _, _, _ -> submit(); true }
                val inRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                inRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
                inRow.addView(chip("추가", 1) { submit() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
                kwCard.addView(inRow, lp(8))
                if (wantFocus) {
                    wantFocus = false
                    input.post {
                        input.requestFocus()
                        (act.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                            .showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                    }
                }
                kwCard.addView(label("폰 안에만 저장돼요 · 서버로 보내지 않아요", 11f).apply { setPadding(0, dp(6), 0, 0) })
            }
            root.addView(kwCard, lp(14))

            // ④ 웹사이트 안 표시 스위치
            val ovRow = card(12).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val texts = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(label("웹사이트 안에 표시", 14f, cOn, true))
            texts.addView(label("영상에 테두리를 두르고 ★ 추천 알약을 띄워요", 12f))
            ovRow.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            val sw = com.google.android.material.materialswitch.MaterialSwitch(act).apply {
                isChecked = prefs.adultOverlay
                setOnCheckedChangeListener { _, on -> prefs.adultOverlay = on; onChanged() }
            }
            ovRow.addView(sw)
            ovRow.setOnClickListener { sw.toggle() }
            root.addView(ovRow, lp(10))
        }
        render()
        // 대화상자 안의 입력칸에서 키보드가 안 뜨는 것을 막는다: 입력기를 받을 수 있는 창으로 만들고, 키보드가 올라오면 크기를 줄인다
        dlg.window?.apply {
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or android.view.WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.show()
    }

    /** 처음 한 번, 성인 모드 기능을 쓰기 전에 만 19세 이상인지 확인한다 */
    fun ensureAdult(act: Activity, prefs: Prefs, then: () -> Unit) {
        if (prefs.adultConfirmed) { then(); return }
        ThemedDialogBuilder(act).setTitle("성인 확인")
            .setMessage("이 기능은 만 19세 이상 성인만 쓸 수 있어요. 만 19세 이상인가요?")
            .setPositiveButton("네, 성인이에요") { _, _ -> prefs.adultConfirmed = true; then() }
            .setNegativeButton("아니요", null).show()
    }
}
