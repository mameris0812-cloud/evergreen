package com.example.evergreen

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 성인 모드 키워드 추천(AdultReco) 중 폰 안에서만 도는 계산: 키워드 넣기 · 점수 · 비슷한 영상/키워드 · 중복 합치기 */
class AdultRecoTest {
    private fun p(u: String, t: String) = AdultReco.PageItem(u, t)

    @Test
    fun addKeywords_splitsDedupesAndTrims() {
        val r = AdultReco.addKeywords(listOf("abc"), " Foo ,abc\nBar baz, x ,")
        assertEquals(listOf("abc", "foo", "bar baz"), r)
    }

    @Test
    fun addKeywords_capsAtMax() {
        val r = AdultReco.addKeywords(emptyList(), (1..50).joinToString(",") { "kw$it" })
        assertEquals(AdultReco.MAX_KEYWORDS, r.size)
    }

    @Test
    fun recommend_ranksMoreMatchesFirst_andDropsNonMatches() {
        val items = listOf(p("https://a.com/1", "alpha only"), p("https://a.com/2", "alpha beta together"), p("https://a.com/3", "nothing here"))
        val r = AdultReco.recommend(listOf("alpha", "beta"), items)
        assertEquals("https://a.com/2", r.hits[0].url)
        assertEquals(2, r.hits.size)
        assertEquals(3, r.scanned)
    }

    @Test
    fun recommend_addsSimilarVideosByCoOccurringWords() {
        val items = listOf(
            p("https://a.com/1", "alpha gamma"), p("https://a.com/2", "alpha gamma delta"), p("https://a.com/3", "alpha delta"),
            p("https://a.com/4", "gamma delta only"), p("https://a.com/5", "unrelated")
        )
        val r = AdultReco.recommend(listOf("alpha"), items)
        assertEquals(listOf("delta", "gamma"), r.related)
        assertEquals(listOf(false, false, false, true), r.hits.map { it.similar })
        assertEquals("https://a.com/4", r.hits.last().url)
    }

    @Test
    fun recommend_matchesKeywordInUrl_andMergesDuplicates() {
        val items = listOf(p("https://a.com/watch/some-alpha-clip", "제목"), p("https://a.com/watch/some-alpha-clip", "제목"))
        val r = AdultReco.recommend(listOf("alpha"), items)
        assertEquals(1, r.hits.size)
        assertEquals(1, r.scanned)
    }

    @Test
    fun recommend_emptyKeywordsGivesNothing() {
        val r = AdultReco.recommend(emptyList(), listOf(p("https://a.com", "x")))
        assertTrue(r.hits.isEmpty() && r.related.isEmpty())
    }
}
