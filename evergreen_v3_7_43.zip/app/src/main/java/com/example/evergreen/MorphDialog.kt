package com.example.evergreen

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.google.android.material.color.MaterialColors

/**
 * 눌린 카드([origin], 새 탭 화면의 개인정보 위젯)가 그대로 펼쳐져 팝업 창이 되고,
 * 닫을 때는 다시 그 카드 자리로 접혀 들어가는 팝업 (컨테이너 트랜스폼).
 *
 * - 창 배경(면·테두리·모서리)이 카드 모양에서 팝업 모양으로 연속해서 변한다. 크기·위치·모서리·색이 하나의 스프링으로 움직인다.
 * - 카드 안의 글자·아이콘은 카드가 커지는 동안 사라지고, 팝업 내용은 펼쳐지는 면 안에서만 보이며
 *   머리말 → 항목 → 버튼 순서로 떠오른다. (내용은 처음부터 최종 크기로 배치되어 있어 글자가 늘어나거나 찌그러지지 않는다)
 * - 뒤 화면의 어두워짐·블러도 진행도에 맞춰 서서히 진해진다.
 * - 스프링이라 열리는 도중에 닫아도 그 자리에서 자연스럽게 되돌아간다.
 *
 * 창 전체를 투명하게 덮고 그 안에서 면을 직접 그리기 때문에, 카드가 팝업 창 밖(화면 어디든)에 있어도 이어진다.
 */
internal class MorphDialog(
    ctx: Context,
    private val origin: View,
    private val originRadiusDp: Float = 24f
) : Dialog(ctx, R.style.Evergreen_Popup) {

    private lateinit var root: FrameLayout
    private lateinit var card: View
    private lateinit var surface: MorphSurface

    private val src = RectF()
    private val dst = RectF()
    private val rect = RectF()
    private val clip = RectF()
    private var clipRadius = 0f

    private var header: View? = null
    private var buttons: View? = null
    private var rows: List<View> = emptyList()

    private var ghost: Bitmap? = null
    private var glassOrigin: ThemeGlassDrawable? = null   // 카드가 테마 유리(흐린 배경)면 그 유리: 펼쳐지는 면이 단색이 아니라 이 유리에서 출발한다
    private var useGhost = true
    private var originPrevVisibility = View.VISIBLE
    private var originHidden = false

    private var startColor = 0
    private var startStrokeAlpha = 0   // 카드 테두리의 시작 짙기 (테두리 없는 카드는 0 — 열릴 때 테두리가 갑자기 생기지 않게)
    private var endColor = 0
    private var outlineColor = 0
    private var endStrokeAlpha = 0
    private var endDim = 0.12f
    private var endBlur = 0
    private var blurOn = false
    private var lastDim = -1f
    private var lastBlur = -1

    private var progress = 0f
    private var spring: SpringAnimation? = null
    private var ready = false
    private var settled = false
    private var closing = false
    private var finished = false

    private fun dp(v: Float) = v * context.resources.displayMetrics.density

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun seg(c: Float, a: Float, b: Float): Float = ((c - a) / (b - a)).coerceIn(0f, 1f)

    /** 팝업 카드를 투명한 전체 창 가운데에 올린다. 창이 뜨기 전에 한 번 부른다. */
    fun setCard(card: View, widthPx: Int) {
        this.card = card
        surface = MorphSurface(context)
        root = FrameLayout(context)
        root.addView(surface, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(card, FrameLayout.LayoutParams(
            widthPx, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        // 카드 바깥(투명한 부분)을 누르면 닫는다. 카드 안을 눌러도 닫히지 않도록 카드가 터치를 받는다.
        root.setOnClickListener { cancel() }
        root.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        card.setOnClickListener { }
        // 내용은 펼쳐지는 면 안에서만 보이게 자른다
        card.clipToOutline = true
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(
                    clip.left.toInt(), clip.top.toInt(), clip.right.toInt(), clip.bottom.toInt(), clipRadius
                )
            }
        }
        setContentView(root)
        window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            // 창 전체가 커지고 줄어드는 기본 애니메이션은 끈다. 움직임은 전부 여기서 그린다.
            setWindowAnimations(0)
        }
    }

    /**
     * 배경 블러·색을 정하고 시작 준비를 한다. 블러(Blur.behind) 처리까지 끝난 뒤, show() 전에 부른다.
     * @param glass 반투명 유리 배경(+뒤 블러)으로 만들어졌는지
     */
    fun arm(glass: Boolean) {
        endColor = Blur.surface(context, com.google.android.material.R.attr.colorSurface, glass)
        readOriginLook()
        outlineColor = ThemeColors.get(
            context, com.google.android.material.R.attr.colorOutlineVariant, 0x33888888)
        endStrokeAlpha = if (glass) 0x80 else 0
        val lp = window?.attributes
        if (lp != null) {
            endDim = lp.dimAmount
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                (lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND) != 0
            ) {
                blurOn = true
                endBlur = lp.blurBehindRadius
            }
        }
        // 배경은 이제 MorphSurface 가 그린다
        card.background = null
        card.alpha = 0f
        applyBackdrop(0f)
        root.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                if (card.width <= 0 || card.height <= 0) return true
                root.viewTreeObserver.removeOnPreDrawListener(this)
                begin()
                return true
            }
        })
    }

    /**
     * 출발 색·테두리를 카드의 실제 모습에서 읽는다 (투명도 포함).
     * 예전엔 늘 불투명한 창 색에서 출발해서, 반투명 카드가 열릴 때 흰 창으로 툭 튀었다.
     * - 유리 카드: 유리 자체가 그려지므로 면은 투명에서 시작한다 (창 색이 서서히 올라온다)
     * - 그 밖의 카드: 카드 배경을 작은 그림에 한 번 그려 면 색과 테두리 유무를 읽는다
     */
    private fun readOriginLook() {
        val bg = origin.background
        if (bg is ThemeGlassDrawable) {
            startColor = ColorUtils.setAlphaComponent(endColor, 0)
            startStrokeAlpha = 0
            return
        }
        val w = origin.width
        val h = origin.height
        if (bg != null && w >= 24 && h >= 24) {
            val ob = Rect(bg.bounds)
            try {
                val bmp = Bitmap.createBitmap(12, 4, Bitmap.Config.ARGB_8888)
                val cv = Canvas(bmp)
                cv.translate(0f, -(h / 2f - 2f))        // 카드 왼쪽 가운데 가장자리만 담는다
                bg.setBounds(0, 0, w, h)
                bg.draw(cv)
                val edge = bmp.getPixel(0, 2)            // 맨 가장자리 (테두리가 있으면 테두리 색)
                val face = bmp.getPixel(11, 2)           // 테두리 안쪽 면
                bmp.recycle()
                val diff = Math.abs(Color.alpha(edge) - Color.alpha(face)) +
                    Math.abs(Color.red(edge) - Color.red(face)) +
                    Math.abs(Color.green(edge) - Color.green(face)) +
                    Math.abs(Color.blue(edge) - Color.blue(face))
                startColor = face
                startStrokeAlpha = if (diff > 8) 255 else 0
                return
            } catch (e: Throwable) {
                // 읽지 못하면 아래 기본값
            } finally {
                bg.setBounds(ob)
            }
        }
        startColor = ThemeColors.get(
            origin.context, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF.toInt())
        startStrokeAlpha = 255
    }

    /** 첫 프레임이 그려지기 직전: 카드 자리·팝업 자리를 재고, 카드 모양에서 출발한다 */
    private fun begin() {
        header = card.findViewById(R.id.popupHeader)
        buttons = card.findViewById(R.id.popupButtons)
        val list = card.findViewById<ViewGroup>(R.id.popupList)
        rows = if (list == null) emptyList() else (0 until list.childCount).map { list.getChildAt(it) }
        dst.set(card.left.toFloat(), card.top.toFloat(), card.right.toFloat(), card.bottom.toFloat())
        locateOrigin()
        originPrevVisibility = origin.visibility
        // 카드는 숨기고 그 자리를 지금부터 MorphSurface 가 (같은 모양으로) 이어받는다
        originHidden = true
        if (useGhost && glassOrigin != null) {
            // 유리 카드: 카드와 창은 서로 다른 창이라 같은 프레임에 바뀐다는 보장이 없다.
            // 카드를 먼저 숨기면 창의 유리가 뜨기 전 한 프레임 동안 블러 없는 배경이 비치므로, 창이 먼저 뜬 뒤 숨긴다
            // (유리는 불투명한 흐린 그림이라 잠깐 겹쳐도 같은 모양이다)
            root.postOnAnimation { root.postOnAnimation { if (originHidden) origin.visibility = View.INVISIBLE } }
        } else origin.visibility = View.INVISIBLE
        ready = true
        card.alpha = 1f
        applyProgress(0f)
        root.viewTreeObserver.addOnPreDrawListener(follow)
        runSpring(1f, 300f, 0.86f) {
            applyProgress(1f)
            settled = true
            card.clipToOutline = false
        }
    }

    /** 팝업이 다 열린 뒤 창 크기가 바뀌면(분할 화면 등) 면이 카드를 따라가게 한다 */
    private val follow = ViewTreeObserver.OnPreDrawListener {
        if (settled && !closing) {
            val l = card.left.toFloat()
            val t = card.top.toFloat()
            val r = card.right.toFloat()
            val b = card.bottom.toFloat()
            if (l != dst.left || t != dst.top || r != dst.right || b != dst.bottom) {
                dst.set(l, t, r, b)
                applyProgress(1f)
            }
        }
        true
    }

    /** 카드(origin)의 지금 화면 위치를 출발/도착점으로 잡는다. 카드가 없으면 팝업을 살짝 줄이며 사라지게 한다 */
    private fun locateOrigin() {
        if (origin.isAttachedToWindow && origin.width > 0 && origin.height > 0) {
            val rl = IntArray(2)
            val ol = IntArray(2)
            root.getLocationOnScreen(rl)
            origin.getLocationOnScreen(ol)
            val l = (ol[0] - rl[0]).toFloat()
            val t = (ol[1] - rl[1]).toFloat()
            src.set(l, t, l + origin.width, t + origin.height)
            useGhost = true
            glassOrigin = origin.background as? ThemeGlassDrawable
            if (ghost == null) ghost = snapshotOrigin()
        } else {
            glassOrigin = null
            val w = dst.width() * 0.9f
            val h = dst.height() * 0.9f
            src.set(dst.centerX() - w / 2f, dst.centerY() - h / 2f, dst.centerX() + w / 2f, dst.centerY() + h / 2f)
            useGhost = false
        }
    }

    /** 카드 안의 글자·아이콘(배경 제외)을 그림으로 떠 둔다: 펼쳐지는 면 위에서 서서히 사라진다 */
    private fun snapshotOrigin(): Bitmap? {
        val w = origin.width
        val h = origin.height
        if (w <= 0 || h <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            if (origin is ViewGroup) {
                for (i in 0 until origin.childCount) {
                    val ch = origin.getChildAt(i)
                    if (ch.visibility != View.VISIBLE) continue
                    canvas.save()
                    canvas.translate(ch.left.toFloat(), ch.top.toFloat())
                    ch.draw(canvas)
                    canvas.restore()
                }
            } else {
                origin.draw(canvas)
            }
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    private fun runSpring(target: Float, stiffness: Float, damping: Float, onEnd: (() -> Unit)?) {
        spring?.cancel()
        val s = SpringAnimation(FloatValueHolder(progress))
        s.setStartValue(progress)
        s.setSpring(SpringForce(target).setStiffness(stiffness).setDampingRatio(damping))
        s.setMinimumVisibleChange(1f / 500f)
        s.addUpdateListener { _, value, _ -> applyProgress(value) }
        s.addEndListener { _, canceled, _, _ -> if (!canceled) onEnd?.invoke() }
        spring = s
        s.start()
    }

    /**
     * 0 = 카드 모양, 1 = 팝업 모양. 스프링이 살짝 넘칠 수 있어 1 을 넘는 값도 들어온다.
     * 가로는 그대로, 세로는 조금 앞서 자라게 해서 중심이 직선이 아니라 살짝 호를 그리며 움직인다.
     */
    private fun applyProgress(v: Float) {
        progress = v
        val t = if (v < 0f) 0f else v
        val c = if (t > 1f) 1f else t
        val ty = t * 0.5f + (1f - (1f - c) * (1f - c)) * 0.5f
        rect.set(
            lerp(src.left, dst.left, t), lerp(src.top, dst.top, ty),
            lerp(src.right, dst.right, t), lerp(src.bottom, dst.bottom, ty)
        )
        val radius = lerp(dp(originRadiusDp), dp(26f), c)

        // 카드로 돌아갈 자리가 없을 때만 면 전체가 서서히 사라진다
        val fadeAll = if (useGhost) 1f else seg(c, 0f, 0.6f)
        // 카드가 유리(흐린 배경)면: 면은 처음엔 그 유리로 보이다가 팝업 색으로 서서히 바뀐다 (단색 면이 툭 튀어나오지 않게)
        val glass = if (useGhost) glassOrigin else null
        val fillRamp = if (glass != null) seg(c, 0.06f, 0.8f) else 1f
        var fill = ColorUtils.blendARGB(startColor, endColor, c)
        fill = ColorUtils.setAlphaComponent(fill, (Color.alpha(fill) * fadeAll * fillRamp).toInt().coerceIn(0, 255))
        val strokeA = (lerp(startStrokeAlpha.toFloat(), endStrokeAlpha.toFloat(), c) * fadeAll).toInt().coerceIn(0, 255)
        val stroke = ColorUtils.setAlphaComponent(outlineColor, strokeA)
        val ghostA = if (useGhost) ((1f - seg(c, 0f, 0.28f)) * 255f).toInt() else 0
        val glassA = if (glass != null) ((1f - seg(c, 0f, 0.7f)) * 255f).toInt() else 0
        surface.update(rect, radius, fill, lerp(dp(1f), 1f, c), stroke, if (useGhost) ghost else null, ghostA, glass, glassA)

        // 내용은 면 안쪽만 보인다 (카드 좌표로 바꿔서)
        clip.set(rect.left - card.left, rect.top - card.top, rect.right - card.left, rect.bottom - card.top)
        clipRadius = radius
        card.invalidateOutline()

        applyParts(c)
        applyBackdrop(c)
    }

    /** 머리말 → 항목(위에서 아래로) → 버튼 순서로 떠오른다. 닫을 때는 같은 값이 거꾸로 흘러 아래부터 먼저 사라진다 */
    private fun applyParts(c: Float) {
        header?.alpha = seg(c, 0.12f, 0.45f)
        buttons?.alpha = seg(c, 0.55f, 0.92f)
        val rise = dp(8f)
        rows.forEachIndexed { i, r ->
            val a = 0.28f + minOf(i, 10) * 0.028f
            val s = seg(c, a, a + 0.4f)
            r.alpha = s
            r.translationY = (1f - s) * rise
        }
    }

    /** 뒤 화면을 어둡게·흐리게 하는 정도를 진행도에 맞춘다 */
    private fun applyBackdrop(c: Float) {
        val w = window ?: return
        val dim = endDim * c
        val blur = if (blurOn) (endBlur * c).toInt() else 0
        val edge = c <= 0f || c >= 1f
        if (!edge && blur == lastBlur && Math.abs(dim - lastDim) < 0.004f) return
        lastDim = dim
        lastBlur = blur
        val lp = w.attributes
        lp.dimAmount = dim
        if (blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) lp.blurBehindRadius = blur
        w.attributes = lp
    }

    /** 닫기(뒤로 가기·바깥 누르기·버튼): 카드 자리로 접혀 들어간 뒤 창을 없앤다 */
    override fun dismiss() {
        if (finished) {
            super.dismiss()
            return
        }
        if (closing) return
        if (!ready || !isShowing || !Motion.enabled(context)) {
            dismissNow()
            return
        }
        closing = true
        settled = false
        dst.set(card.left.toFloat(), card.top.toFloat(), card.right.toFloat(), card.bottom.toFloat())
        locateOrigin()
        card.clipToOutline = true
        runSpring(0f, 380f, SpringForce.DAMPING_RATIO_NO_BOUNCY) {
            applyProgress(0f)
            if (useGhost && glassOrigin != null) {
                // 유리 카드: 카드(다른 창)가 다시 그려지기 전에 창의 유리를 지우면 한 프레임 동안 블러 없는 배경이 비쳐 깜빡인다.
                // 그래서 글자·면은 지우고 유리만 남긴 채 카드를 되살리고, 카드가 그려진 뒤에 유리를 지운다.
                // (유리는 불투명한 흐린 그림이라 카드의 유리와 겹쳐도 같은 모양이다)
                surface.holdGlassOnly()
                card.visibility = View.INVISIBLE
                restoreOrigin()
                root.postOnAnimation { root.postOnAnimation { surface.hide(); dismissNow() } }
            } else {
                // 카드를 되살리는 바로 그 순간 창의 면·글자 그림을 함께 지운다.
                // (면을 한 프레임 더 남기면 반투명 카드 위에 겹쳐 잠깐 더 진해 보인다)
                surface.hide()
                card.visibility = View.INVISIBLE
                restoreOrigin()
                root.postOnAnimation { dismissNow() }
            }
        }
    }

    /** 애니메이션 없이 바로 닫는다 (같은 팝업을 곧바로 다시 열 때 등) */
    fun dismissNow() {
        if (finished) return
        finished = true
        spring?.cancel()
        restoreOrigin()
        ghost = null
        super.dismiss()
    }

    override fun onStop() {
        super.onStop()
        restoreOrigin()
    }

    private fun restoreOrigin() {
        if (originHidden) {
            originHidden = false
            origin.visibility = originPrevVisibility
        }
    }
}

/** 카드 모양에서 팝업 모양으로 변하는 면(둥근 사각형 + 테두리)과, 사라져 가는 카드 속 내용 그림 */
private class MorphSurface(ctx: Context) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ghostPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val inset = RectF()
    private val path = Path()
    private var radius = 0f
    private var visible = false
    private var ghost: Bitmap? = null
    private var ghostAlpha = 0
    private var glass: ThemeGlassDrawable? = null
    private var glassAlpha = 0
    private val loc = IntArray(2)

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun update(
        r: RectF, radius: Float, color: Int, strokeWidth: Float, strokeColor: Int,
        ghost: Bitmap?, ghostAlpha: Int, glass: ThemeGlassDrawable? = null, glassAlpha: Int = 0
    ) {
        this.glass = glass
        this.glassAlpha = glassAlpha
        rect.set(r)
        this.radius = radius
        fill.color = color
        stroke.strokeWidth = strokeWidth
        stroke.color = strokeColor
        this.ghost = ghost
        this.ghostAlpha = ghostAlpha
        visible = true
        invalidate()
    }

    /** 글자 그림·면·테두리는 지우고 유리(흐린 배경)만 남긴다 (카드가 돌아와 그려지길 기다리는 동안 배경이 비치지 않게) */
    fun holdGlassOnly() {
        ghost = null
        fill.color = 0
        stroke.strokeWidth = 0f
        invalidate()
    }

    /** 면과 그림을 더 그리지 않는다 (닫기가 끝나 카드가 돌아온 순간) */
    fun hide() {
        visible = false
        ghost = null
        glass = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!visible) return
        val gl = glass
        if (gl != null && glassAlpha > 0) {
            getLocationOnScreen(loc)
            gl.paintAt(canvas, rect, loc[0], loc[1], radius, glassAlpha)
        }
        canvas.drawRoundRect(rect, radius, radius, fill)
        if (Color.alpha(stroke.color) > 0 && stroke.strokeWidth > 0f) {
            val h = stroke.strokeWidth / 2f
            inset.set(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h)
            val rr = maxOf(radius - h, 0f)
            canvas.drawRoundRect(inset, rr, rr, stroke)
        }
        val g = ghost
        if (g != null && ghostAlpha > 0) {
            path.reset()
            path.addRoundRect(rect, radius, radius, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(path)
            canvas.translate(rect.left, rect.top)
            ghostPaint.alpha = ghostAlpha.coerceIn(0, 255)
            canvas.drawBitmap(g, 0f, 0f, ghostPaint)
            canvas.restore()
        }
    }
}
