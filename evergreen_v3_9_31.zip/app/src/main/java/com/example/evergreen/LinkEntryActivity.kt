package com.example.evergreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 다른 앱의 링크(http/https)를 받는 입구. 화면이 없는 중계 창이다.
 * - 커스텀 탭으로 온 링크: 부른 앱의 작업 안에서 [CustomTabActivity] 를 띄운다 (유튜브 같은 앱 위에 얹혀 뜬다).
 * - 그 밖의 링크: 예전처럼 [MainActivity] 로 그대로 넘겨 일반 탭으로 연다.
 */
class LinkEntryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val src = intent
        if (CustomTabActivity.isCustomTabIntent(src)) {
            CustomTabActivity.launch(this, src, onTopOfHost = false)
        } else {
            startActivity(Intent(src).setClass(this, MainActivity::class.java))
        }
        finish()
    }
}
