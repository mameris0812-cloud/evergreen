package com.example.evergreen

import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Region
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.PathParser
import androidx.dynamicanimation.animation.SpringAnimation
import kotlin.math.roundToInt

/**
 * 상/하단바 버튼 아이콘을 직접 그려서, 누르면 아이콘 '모양 자체'가 변하게 한다.
 * 가만히 있을 때(progress = 0)는 ic_*.xml 과 똑같은 모양(24 격자 · 선 1.8 · 둥근 끝)이다.
 *
 *  back/forward : 화살표 몸통이 짧아지며 화살촉이 앞으로 쏜다     home : 지붕이 솟고 문이 길어진다
 *  menu         : 세 점이 한 점으로 모였다 다시 세 개로 늘어난다             desktop : 모니터 ↔ 폰 모양으로 변한다 (상태를 따른다)
 *  ai           : 큰 별이 찌그러지며 비틀리고 작은 별이 커진다      newtab : + 의 선이 줄었다 늘어난다
 *  bookmark     : 윤곽이 차오르며 아래 홈이 깊어진다                 bookmarks : 리본이 좁아지며 홈이 깊어진다
 *  history      : 시계 바늘이 돈다                                  downloads : 화살표가 받침대로 내려꽂힌다
 *  find         : 돋보기 렌즈가 커지고 손잡이가 길어진다             player : 재생 삼각형이 갈라져 일시정지가 된다
 *  hidebars     : 네 모서리 괄호가 가운데로 모인다                   settings : 톱니가 돌고 가운데 구멍이 커진다
 *  tabs         : 누르는 동안 앞 카드가 왼쪽 아래로 움츠리고, 떼면 뒤 카드가 오른쪽 위로 튀어 오른다. 숫자는 앞 카드와 함께 움직이고,
 *                 탭 개수가 바뀌면 숫자가 위/아래로 굴러 바뀌며 카드가 한 번 출렁인다 (숫자도 이 그림이 직접 그린다)
 *  openplayer   : 상/하단바의 「내장 플레이어로 재생」 — 누르는 동안 삼각형이 뒤로 물러나고, 떼면 오른쪽으로 날아가고 새 삼각형이 왼쪽에서 들어온다
 *  pip          : 안쪽 작은 창이 커지며 튀어나온다                   rotate : 폰 모양이 기울었다 돌아온다
 *  skipback/skipfwd : 10초 원형 화살표가 되감기/빨리감기 방향으로 한 바퀴 돈다
 *  player (재생/일시정지 버튼) : progress 0 = 재생 삼각형, 1 = 일시정지 — 눌림이 아니라 상태(settle)를 따른다
 */
class MorphIconDrawable(
    private val kind: String,
    private val density: Float,
    private var baseColor: Int = Color.BLACK
) : Drawable() {

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.8f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val rect = RectF()
    private var tint: ColorStateList? = null
    private var alphaValue = 255

    /** 모양이 변한 정도. 0 = 평소 모양, 1 = 가장 많이 변한 모양 (튕기면서 조금 넘나든다) */
    var progress = 0f
        private set
    private var anim: SpringAnimation? = null
    private var settled = false

    // ── 탭 버튼 숫자 (tabs): 숫자도 그림이 그려서 카드와 같이 움직이고, 바뀔 때 굴러 바뀐다 ──
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private var label = ""
    private var prevLabel = ""
    /** 숫자가 굴러 바뀐 정도. 1 = 새 숫자가 자리를 잡음 (튕기면서 조금 넘는다) */
    private var roll = 1f
    /** +1 = 개수가 늘어남 (새 숫자가 아래에서 올라옴), -1 = 줄어듦 (위에서 내려옴) */
    private var rollDir = 1
    private var rollAnim: SpringAnimation? = null

    // ── 내장 플레이어 버튼 (openplayer): 삼각형이 날아가고 새 삼각형이 들어오는 정도 ──
    private var swap = 0f
    private var swapAnim: SpringAnimation? = null

    private val gearOuter: Path? by lazy {
        try {
            PathParser.createPathFromPathData(GEAR)
        } catch (e: Exception) { null }
    }
    private val bigStar: Path? by lazy {
        try { PathParser.createPathFromPathData(STAR_BIG) } catch (e: Exception) { null }
    }
    private val smallStar: Path? by lazy {
        try { PathParser.createPathFromPathData(STAR_SMALL) } catch (e: Exception) { null }
    }
    private val rotateArrow: Path? by lazy {
        try { PathParser.createPathFromPathData(ROTATE_ARROW) } catch (e: Exception) { null }
    }
    /** 10초 뒤로/앞으로: 위가 열린 원호 */
    private val skipArc: Path? by lazy {
        val data = if (kind == "skipback") SKIP_BACK_ARC else SKIP_FWD_ARC
        try { PathParser.createPathFromPathData(data) } catch (e: Exception) { null }
    }
    /** 10초 뒤로/앞으로: 채운 화살촉 */
    private val skipHead: Path? by lazy {
        val data = if (kind == "skipback") SKIP_BACK_HEAD else SKIP_FWD_HEAD
        try { PathParser.createPathFromPathData(data) } catch (e: Exception) { null }
    }

    private fun set(v: Float) {
        progress = v
        invalidateSelf()
    }

    /** 누르고 있는 동안 모양이 머무는 정도 (미리 움츠리는 동작). 이 종류가 아니면 0 */
    private fun holdLevel(): Float = when (kind) {
        "tabs" -> 0.4f
        "openplayer" -> 0.5f
        else -> 0f
    }

    /**
     * 손가락이 닿는 순간(down = true)에 떼기 전 자세로 미리 움츠리고, 떼면(탭이 아니거나 밖으로 나가서 뗌) 제자리로 돌아온다.
     * 탭으로 뗐을 때는 이 자세에서 [play] 가 이어받아 튀어 나간다.
     */
    fun press(down: Boolean) {
        val hold = holdLevel()
        if (hold == 0f) return
        anim?.cancel()
        val to = if (down) hold else 0f
        anim = Motion.springValue(
            from = progress, to = to, stiffness = 700f, damping = 0.85f,
            onUpdate = { set(it) },
            onEnd = { set(to) }
        )
    }

    /** 눌렀을 때: 모양이 변했다가 튕기며 돌아온다 */
    fun play() {
        if (kind == "desktop") return // 데스크톱/폰은 상태가 바뀔 때(settle) 모양이 바뀐다
        when (kind) {
            "tabs" -> {
                // 누르고 있던 자세(앞 카드가 움츠림)에서 뒤 카드가 튀어 오르고, 출렁이며 제자리
                anim?.cancel()
                anim = Motion.springValue(
                    from = progress, to = 0f, stiffness = 380f, damping = 0.55f, velocity = 30f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
            "openplayer" -> {
                // 물러나 있던 삼각형이 오른쪽으로 날아가고, 새 삼각형이 왼쪽에서 들어와 살짝 넘어갔다가 자리를 잡는다
                anim?.cancel()
                anim = Motion.springValue(
                    from = progress, to = 0f, stiffness = 500f, damping = 0.8f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
                swapAnim?.cancel()
                swap = 0f
                swapAnim = Motion.springValue(
                    from = 0f, to = 1f, stiffness = 300f, damping = 0.62f,
                    onUpdate = { swap = it; invalidateSelf() },
                    onEnd = { swap = 0f; invalidateSelf() }
                )
            }
            else -> {
                anim?.cancel()
                anim = Motion.springValue(
                    from = progress, to = 0f, stiffness = 420f, damping = 0.5f, velocity = 30f,
                    onUpdate = { set(it) },
                    onEnd = { set(0f) }
                )
            }
        }
    }

    /**
     * 탭 버튼의 숫자를 바꾼다. animate = true 면 숫자가 굴러 바뀌고 카드가 한 번 출렁인다 (모양이 눌려 있는 중이면 이어서).
     * dir: +1 = 늘어남, -1 = 줄어듦. tabs 가 아닌 종류에서는 아무 일도 하지 않는다.
     */
    fun setLabel(text: String, animate: Boolean, dir: Int = 1) {
        if (kind != "tabs" || text == label) return
        rollAnim?.cancel()
        if (!animate || label.isEmpty()) {
            label = text; prevLabel = text; roll = 1f
            invalidateSelf()
            return
        }
        prevLabel = label
        label = text
        rollDir = if (dir >= 0) 1 else -1
        roll = 0f
        rollAnim = Motion.springValue(
            from = 0f, to = 1f, stiffness = 500f, damping = 0.8f,
            onUpdate = { roll = it; invalidateSelf() },
            onEnd = { roll = 1f; invalidateSelf() }
        )
        // 카드도 한 번 출렁인다
        anim?.cancel()
        anim = Motion.springValue(
            from = progress, to = 0f, stiffness = 380f, damping = 0.55f, velocity = 34f,
            onUpdate = { set(it) },
            onEnd = { set(0f) }
        )
    }

    /** 숫자 한 개를 그린다 (24 격자 기준, 카드 가운데가 (12, 12)). 글자 크기 규칙은 TabCountDrawable 과 같다: 99+ → 8, 두 자리 → 10, 한 자리 → 12 */
    private fun drawLabel(canvas: Canvas, s: String, dx: Float, dy: Float, scale: Float, frac: Float, color: Int, a: Int) {
        if (s.isEmpty() || frac <= 0.01f) return
        num.color = color
        num.alpha = (a * frac.coerceIn(0f, 1f)).roundToInt()
        num.textSize = (if (s.endsWith("+")) 8f else if (s.length >= 2) 10f else 12f) * scale
        // 실제 버튼(TextView, 글꼴 여백 없음, 가운데 정렬)처럼 글줄(ascent~descent)의 가운데를 카드 가운데에 둔다
        val fm = num.fontMetrics
        canvas.drawText(s, 12f + dx, 12f + dy - (fm.ascent + fm.descent) / 2f, num)
    }

    /** 상태에 맞는 모양으로 자리를 잡는다 (처음에는 바로, 그 뒤로는 스프링으로 모양이 바뀐다) */
    fun settle(target: Float, animate: Boolean) {
        anim?.cancel()
        if (!animate || !settled) {
            settled = true
            set(target)
            return
        }
        anim = Motion.springValue(
            from = progress, to = target, stiffness = 260f, damping = 0.62f,
            onUpdate = { set(it) },
            onEnd = { set(target) }
        )
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun curColor(): Int {
        val t = tint
        return if (t != null) t.getColorForState(state, t.defaultColor) else baseColor
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val side = minOf(b.width(), b.height()).toFloat()
        val u = side / 24f
        val c = curColor()
        val a = (Color.alpha(c) * alphaValue / 255)
        stroke.color = c; stroke.alpha = a
        fill.color = c; fill.alpha = a
        canvas.save()
        canvas.translate(b.exactCenterX() - side / 2f, b.exactCenterY() - side / 2f)
        canvas.scale(u, u)
        val p = progress
        val q = p.coerceIn(0f, 1f)
        path.reset()
        when (kind) {
            "back", "forward" -> {
                // 몸통이 짧아지며 화살촉이 앞으로 쏜다
                val d = if (kind == "back") 1f else -1f
                fun x(v: Float) = if (d > 0f) v else 24f - v
                path.moveTo(x(19f - 6f * p), 12f); path.lineTo(x(5f - 2.5f * p), 12f)
                path.moveTo(x(11f - 2.5f * p), 6f); path.lineTo(x(5f - 2.5f * p), 12f); path.lineTo(x(11f - 2.5f * p), 18f)
                canvas.drawPath(path, stroke)
            }
            "home" -> {
                // 지붕이 솟고 문이 길어진다
                val lift = 2.6f * p
                val door = 15f - 3f * p
                path.moveTo(4f, 11.2f - 0.8f * p); path.lineTo(12f, 4.2f - lift); path.lineTo(20f, 11.2f - 0.8f * p)
                path.moveTo(6f, 9.6f - 0.8f * p); path.lineTo(6f, 19.2f); path.quadTo(6f, 20.2f, 7f, 20.2f)
                path.lineTo(10f, 20.2f); path.lineTo(10f, door); path.lineTo(14f, door); path.lineTo(14f, 20.2f)
                path.lineTo(17f, 20.2f); path.quadTo(18f, 20.2f, 18f, 19.2f); path.lineTo(18f, 9.6f - 0.8f * p)
                canvas.drawPath(path, stroke)
            }
            "menu" -> {
                // 세 점이 가운데 한 점으로 모였다가 다시 세 개로 늘어난다
                val r = 1.7f + 0.5f * q
                for (i in 0..2) {
                    canvas.drawCircle(12f, lerp(5f + 7f * i, 12f, p), r, fill)
                }
            }
            "desktop" -> {
                // 0 = 모니터, 1 = 폰
                rect.set(lerp(3f, 7f, p), lerp(4f, 3f, p), lerp(21f, 17f, p), lerp(16f, 21f, p))
                val r = lerp(2f, 2.5f, q)
                canvas.drawRoundRect(rect, r, r, stroke)
                val ly = lerp(20f, 18f, p)
                path.moveTo(lerp(9f, 11f, p), ly); path.lineTo(lerp(15f, 13f, p), ly)
                path.moveTo(12f, lerp(16f, 18f, p)); path.lineTo(12f, ly)
                canvas.drawPath(path, stroke)
            }
            "ai" -> {
                val big = bigStar; val small = smallStar
                if (big != null) {
                    canvas.save()
                    canvas.rotate(-25f * p, 10.5f, 12.5f)
                    canvas.scale(1f - 0.2f * p, 1f + 0.25f * p, 10.5f, 12.5f)
                    canvas.drawPath(big, stroke)
                    canvas.restore()
                }
                if (small != null) {
                    canvas.save()
                    val s = 1f + 0.9f * p
                    canvas.scale(s, s, 18.5f, 5f)
                    canvas.drawPath(small, stroke)
                    canvas.restore()
                }
            }
            "newtab" -> {
                // + 의 두 선이 가운데로 줄어들었다가 다시 늘어난다
                val l = (7f * (1f - p)).coerceAtLeast(0.2f)
                canvas.drawLine(12f, 12f - l, 12f, 12f + l, stroke)
                canvas.drawLine(12f - l, 12f, 12f + l, 12f, stroke)
            }
            "bookmark" -> {
                val notch = 16.6f - 2.4f * p
                path.moveTo(7f, 4f); path.lineTo(17f, 4f); path.quadTo(18f, 4f, 18f, 5f); path.lineTo(18f, 20.2f)
                path.lineTo(12f, notch); path.lineTo(6f, 20.2f); path.lineTo(6f, 5f); path.quadTo(6f, 4f, 7f, 4f); path.close()
                fill.alpha = (a * q).roundToInt()
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
            }
            "bookmarks" -> {
                val notch = 16.6f - 2.6f * p
                val tip = 20.2f + 1.2f * p
                val sx = 0.8f * p
                path.moveTo(7f + sx, 4f); path.lineTo(17f - sx, 4f); path.quadTo(18f - sx, 4f, 18f - sx, 5f); path.lineTo(18f - sx, tip)
                path.lineTo(12f, notch); path.lineTo(6f + sx, tip); path.lineTo(6f + sx, 5f); path.quadTo(6f + sx, 4f, 7f + sx, 4f); path.close()
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
            }
            "history" -> {
                canvas.drawCircle(12f, 12f, 8.5f, stroke)
                canvas.save()
                canvas.rotate(-360f * p, 12f, 12f)
                canvas.drawLine(12f, 12f, 12f, 7.5f, stroke)
                canvas.restore()
                canvas.save()
                canvas.rotate(-30f * p, 12f, 12f)
                canvas.drawLine(12f, 12f, 15f, 14f, stroke)
                canvas.restore()
            }
            "downloads" -> {
                // 화살표가 받침대로 내려꽂히고 받침대가 넓어진다
                val dy = 2f * p
                path.moveTo(12f, 4f + 3f * p); path.lineTo(12f, 15f + dy)
                path.moveTo(7.5f, 10.5f + dy); path.lineTo(12f, 15f + dy); path.lineTo(16.5f, 10.5f + dy)
                path.moveTo(5f - 1.5f * p, 20f); path.lineTo(19f + 1.5f * p, 20f)
                canvas.drawPath(path, stroke)
            }
            "find" -> {
                val cx = 11f - 0.5f * p; val cy = 11f - 0.5f * p
                val r = 6.5f + 1.2f * p
                canvas.drawCircle(cx, cy, r, stroke)
                val s = (r + 0.57f) * 0.7071f
                canvas.drawLine(cx + s, cy + s, 20f + 1.6f * p, 20f + 1.6f * p, stroke)
            }
            "player" -> {
                // 재생 삼각형이 둘로 갈라져 일시정지 막대 두 개가 된다
                path.moveTo(lerp(8f, 7.5f, p), lerp(5.5f, 5f, p))
                path.lineTo(lerp(13f, 10.5f, p), lerp(8.6f, 5f, p))
                path.lineTo(lerp(13f, 10.5f, p), lerp(15.4f, 19f, p))
                path.lineTo(lerp(8f, 7.5f, p), lerp(18.5f, 19f, p))
                path.close()
                path.moveTo(lerp(13f, 13.5f, p), lerp(8.6f, 5f, p))
                path.lineTo(lerp(18.5f, 16.5f, p), lerp(12f, 5f, p))
                path.lineTo(lerp(18.5f, 16.5f, p), lerp(12f, 19f, p))
                path.lineTo(lerp(13f, 13.5f, p), lerp(15.4f, 19f, p))
                path.close()
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
            }
            "hidebars" -> {
                // 네 모서리 괄호가 가운데로 모인다
                val m = 2.6f * p
                canvas.save(); canvas.translate(m, m)
                path.moveTo(4f, 9f); path.lineTo(4f, 5.5f); path.quadTo(4f, 4f, 5.5f, 4f); path.lineTo(9f, 4f)
                canvas.drawPath(path, stroke); canvas.restore(); path.reset()
                canvas.save(); canvas.translate(-m, m)
                path.moveTo(15f, 4f); path.lineTo(18.5f, 4f); path.quadTo(20f, 4f, 20f, 5.5f); path.lineTo(20f, 9f)
                canvas.drawPath(path, stroke); canvas.restore(); path.reset()
                canvas.save(); canvas.translate(-m, -m)
                path.moveTo(20f, 15f); path.lineTo(20f, 18.5f); path.quadTo(20f, 20f, 18.5f, 20f); path.lineTo(15f, 20f)
                canvas.drawPath(path, stroke); canvas.restore(); path.reset()
                canvas.save(); canvas.translate(m, -m)
                path.moveTo(9f, 20f); path.lineTo(5.5f, 20f); path.quadTo(4f, 20f, 4f, 18.5f); path.lineTo(4f, 15f)
                canvas.drawPath(path, stroke); canvas.restore()
            }
            "settings" -> {
                val g = gearOuter
                if (g != null) {
                    canvas.save()
                    canvas.rotate(60f * p, 12f, 12f)
                    canvas.drawPath(g, stroke)
                    canvas.restore()
                }
                canvas.drawCircle(12f, 12f, 2.8f + 1.6f * p, stroke)
            }
            "tabs" -> {
                // 앞 카드(숫자 포함)는 왼쪽 아래로 움츠리고, 뒤 카드는 오른쪽 위로 튀어 오른다.
                // 뒤 카드는 앞 카드에 가려지는 부분(+ 얇은 틈)을 잘라 내고 그려서 겹쳐 보이지 않는다.
                val sh = 2f * p
                val r = 3.5f
                val k = 1f - 0.12f * q
                canvas.save()
                canvas.scale(k, k, 12f, 12f)
                if (q > 0.01f) {
                    val gap = 1.5f
                    path.reset()
                    rect.set(3f - sh - gap, 3f + sh - gap, 21f - sh + gap, 21f + sh + gap)
                    path.addRoundRect(rect, r + gap, r + gap, Path.Direction.CW)
                    canvas.save()
                    if (Build.VERSION.SDK_INT >= 26) {
                        canvas.clipOutPath(path)
                    } else {
                        @Suppress("DEPRECATION")
                        canvas.clipPath(path, Region.Op.DIFFERENCE)
                    }
                    rect.set(3f + sh, 3f - sh, 21f + sh, 21f - sh)
                    stroke.alpha = (a * q).roundToInt()
                    canvas.drawRoundRect(rect, r, r, stroke)
                    stroke.alpha = a
                    canvas.restore()
                }
                rect.set(3f - sh, 3f + sh, 21f - sh, 21f + sh)
                canvas.drawRoundRect(rect, r, r, stroke)
                // 숫자: 카드 안쪽에서만 굴러 바뀐다
                val rolling = roll < 0.999f
                canvas.save()
                if (rolling) canvas.clipRect(4.4f - sh, 4.4f + sh, 19.6f - sh, 19.6f + sh)
                if (rolling) {
                    val t = roll
                    val travel = 6f * rollDir
                    // 옛 숫자: 가는 쪽으로 밀려 나가며 사라짐 / 새 숫자: 반대쪽에서 들어오며 커짐
                    drawLabel(canvas, prevLabel, -sh, sh - travel * t, 1f - 0.2f * t, 1f - t / 0.6f, c, a)
                    drawLabel(canvas, label, -sh, sh + travel * (1f - t), 0.75f + 0.25f * t.coerceAtMost(1f), (t - 0.1f) / 0.7f, c, a)
                } else {
                    drawLabel(canvas, label, -sh, sh, 1f, 1f, c, a)
                }
                canvas.restore()
                canvas.restore()
            }
            "openplayer" -> {
                // 누르면 삼각형이 뒤로 물러나고, 떼면 오른쪽으로 날아가며 사라지고 새 삼각형이 왼쪽에서 들어온다
                val s2 = swap
                val pull = -2.4f * p.coerceAtLeast(0f)
                canvas.save()
                canvas.clipRect(1.5f, 0f, 22.5f, 24f)
                val outA = (1f - 1.6f * s2).coerceIn(0f, 1f)
                if (outA > 0.01f) {
                    canvas.save()
                    canvas.translate(pull + 13f * s2, 0f)
                    val sc = 1f - 0.12f * s2.coerceIn(0f, 1f)
                    canvas.scale(sc, sc, 12f, 12f)
                    drawPlayTriangle(canvas, a, outA)
                    canvas.restore()
                }
                val inA = ((s2 - 0.12f) * 1.7f).coerceIn(0f, 1f)
                if (inA > 0.01f) {
                    canvas.save()
                    canvas.translate(-13f * (1f - s2), 0f)
                    drawPlayTriangle(canvas, a, inA)
                    canvas.restore()
                }
                canvas.restore()
            }
            "pip" -> {
                // 바깥 화면은 그대로, 안쪽 작은 창이 왼쪽 위로 커지며 튀어나온다
                rect.set(3f, 5f, 21f, 19f)
                canvas.drawRoundRect(rect, 2f, 2f, stroke)
                rect.set(lerp(11.5f, 8.8f, p), lerp(12f, 9.6f, p), 18f, lerp(16f, 16.4f, p))
                canvas.drawRoundRect(rect, 1f, 1f, fill)
                canvas.drawRoundRect(rect, 1f, 1f, stroke)
            }
            "rotate" -> {
                // 폰 모양이 시계 방향으로 기울어졌다가 돌아온다
                val arrow = rotateArrow
                canvas.save()
                canvas.rotate(90f * p, 12f, 12f)
                rect.set(8f, 9f, 20f, 20f)
                canvas.drawRoundRect(rect, 1.5f, 1.5f, stroke)
                if (arrow != null) canvas.drawPath(arrow, stroke)
                canvas.restore()
            }
            "skipback", "skipfwd" -> {
                // 원형 화살표가 되감기/빨리감기 방향으로 한 바퀴 돈다 (가운데 "10" 은 화면에서 따로 얹는다)
                val arc = skipArc; val head = skipHead
                val dir = if (kind == "skipback") -1f else 1f
                canvas.save()
                canvas.rotate(360f * dir * p, 12f, 13f) // 원의 중심은 (12, 13) — 12 로 돌리면 링이 흔들린다
                if (arc != null) {
                    stroke.strokeWidth = 1.9f
                    canvas.drawPath(arc, stroke)
                }
                if (head != null) {
                    stroke.strokeWidth = 0.9f
                    canvas.drawPath(head, fill)
                    canvas.drawPath(head, stroke)
                }
                stroke.strokeWidth = 1.8f
                canvas.restore()
            }
            else -> {
                canvas.drawCircle(12f, 12f, 8f, stroke)
            }
        }
        canvas.restore()
    }

    /** 재생 삼각형 (ic_play 와 같은 모양) */
    private fun drawPlayTriangle(canvas: Canvas, a: Int, frac: Float) {
        path.reset()
        path.moveTo(8f, 5.5f); path.lineTo(18.5f, 12f); path.lineTo(8f, 18.5f); path.close()
        val al = (a * frac.coerceIn(0f, 1f)).roundToInt()
        fill.alpha = al
        stroke.alpha = al
        canvas.drawPath(path, fill)
        canvas.drawPath(path, stroke)
        fill.alpha = a
        stroke.alpha = a
    }

    override fun getIntrinsicWidth(): Int = (24f * density).roundToInt()
    override fun getIntrinsicHeight(): Int = (24f * density).roundToInt()

    override fun isStateful(): Boolean = true
    override fun onStateChange(stateSet: IntArray): Boolean {
        val t = tint ?: return false
        t.getColorForState(stateSet, t.defaultColor)
        invalidateSelf()
        return true
    }

    override fun setTintList(tint: ColorStateList?) {
        this.tint = tint
        invalidateSelf()
    }

    override fun setAlpha(alpha: Int) { alphaValue = alpha; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) { stroke.colorFilter = cf; fill.colorFilter = cf; invalidateSelf() }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        private const val GEAR =
            "M10.23,4.92 L10.66,2.49 L13.34,2.49 L13.77,4.92 A7.3,7.3 0 0 1 15.76,5.74 L17.78,4.33 L19.67,6.22 " +
            "L18.26,8.24 A7.3,7.3 0 0 1 19.08,10.23 L21.51,10.66 L21.51,13.34 L19.08,13.77 A7.3,7.3 0 0 1 18.26,15.76 " +
            "L19.67,17.78 L17.78,19.67 L15.76,18.26 A7.3,7.3 0 0 1 13.77,19.08 L13.34,21.51 L10.66,21.51 L10.23,19.08 " +
            "A7.3,7.3 0 0 1 8.24,18.26 L6.22,19.67 L4.33,17.78 L5.74,15.76 A7.3,7.3 0 0 1 4.92,13.77 L2.49,13.34 " +
            "L2.49,10.66 L4.92,10.23 A7.3,7.3 0 0 1 5.74,8.24 L4.33,6.22 L6.22,4.33 L8.24,5.74 A7.3,7.3 0 0 1 10.23,4.92 Z"
        private const val STAR_BIG =
            "M10.5,5 C11.2,9.6 12.4,11.4 17,12.5 C12.4,13.6 11.2,15.4 10.5,20 C9.8,15.4 8.6,13.6 4,12.5 C8.6,11.4 9.8,9.6 10.5,5 Z"
        private const val STAR_SMALL =
            "M18.5,2.6 C18.7,4.3 19.1,4.8 20.8,5 C19.1,5.2 18.7,5.7 18.5,7.4 C18.3,5.7 17.9,5.2 16.2,5 C17.9,4.8 18.3,4.3 18.5,2.6 Z"

        private const val ROTATE_ARROW = "M4,12 V9.5 A4.5,4.5 0 0 1 8.5,5 H12 M10,2.8 L12.2,5 L10,7.2"
        private const val SKIP_BACK_ARC = "M7.18,7.25 A7.5,7.5 0 1 0 12,5.5"
        private const val SKIP_BACK_HEAD = "M9.2,5.5 L13.2,2.6 L13.2,8.4 Z"
        private const val SKIP_FWD_ARC = "M16.82,7.25 A7.5,7.5 0 1 1 12,5.5"
        private const val SKIP_FWD_HEAD = "M14.8,5.5 L10.8,2.6 L10.8,8.4 Z"

        /** 모양이 그려져 있는 버튼 종류. 이 밖의 종류는 아이콘을 바꾸지 않고 눌림 효과만 준다. */
        private val KINDS = setOf(
            "back", "forward", "home", "menu", "desktop", "ai", "newtab", "bookmark", "bookmarks", "history",
            "downloads", "find", "player", "openplayer", "hidebars", "settings", "tabs", "tablist", "pip", "rotate",
            "skipback", "skipfwd"
        )

        /** 버튼 종류에 맞는 모양 변하는 아이콘을 버튼에 끼운다. 못 끼우는 버튼이면 null. */
        fun install(v: View, kind: String): MorphIconDrawable? {
            if (kind == "refresh" || kind !in KINDS) return null
            val density = v.resources.displayMetrics.density
            return when {
                v is ImageView -> {
                    val d = MorphIconDrawable(kind, density)
                    v.setImageDrawable(d)
                    d
                }
                v is ViewGroup && (kind == "tabs" || kind == "tablist") -> {
                    val tv = (0 until v.childCount).map { v.getChildAt(it) }.filterIsInstance<TextView>().firstOrNull() ?: return null
                    val color = com.google.android.material.color.MaterialColors.getColor(
                        tv, com.google.android.material.R.attr.colorOnSurface
                    )
                    val d = MorphIconDrawable("tabs", density, color)
                    tv.background = d
                    // 숫자는 그림이 직접 그린다 (카드와 같이 움직이고 굴러 바뀌어야 해서). 글자는 자리만 잡고 보이지 않게 한다
                    d.setLabel(tv.text.toString(), animate = false)
                    tv.setTextColor(Color.TRANSPARENT)
                    d
                }
                else -> null
            }
        }
    }
}
