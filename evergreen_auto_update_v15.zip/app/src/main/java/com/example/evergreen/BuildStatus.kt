package com.example.evergreen

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * GitHub Actions 빌드 진행 상황을 보여 주는 창.
 * 최신 워크플로 실행(run)의 상태와 단계(step)를 몇 초마다 확인해서 진행 막대·단계 목록으로 그린다.
 *
 * 로그인 없이 쓰는 GitHub API 는 시간당 60번 제한이 있다. 그래서 ETag(If-None-Match)를 쓴다:
 * 바뀐 게 없으면 304 로 답하고, 304 는 제한 횟수에 들어가지 않는다.
 * 앱에는 토큰을 넣지 않는다 (공개 저장소 전용).
 */
object BuildStatus {
    private const val POLL_MS = 8_000L

    private class RateLimited(val resetAt: Long) : Exception()

    private class Snapshot(
        val title: String,
        val status: String,          // queued / in_progress / completed ...
        val conclusion: String?,     // success / failure / cancelled ...
        val startedAt: Long,         // ms, 0 이면 모름
        val steps: List<Step>
    )

    private class Step(val name: String, val status: String, val conclusion: String?)

    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followSslRedirects(false)
        .build()

    private val etags = HashMap<String, String>()
    private val bodies = HashMap<String, String>()

    private fun get(url: String): String {
        val b = Request.Builder().url(url)
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "evergreen-updater")
        synchronized(etags) { etags[url] }?.let { b.header("If-None-Match", it) }
        client.newCall(b.build()).execute().use { resp ->
            if (resp.code == 304) {
                return synchronized(bodies) { bodies[url] } ?: throw IllegalStateException("캐시 없음")
            }
            if ((resp.code == 403 || resp.code == 429) && resp.header("x-ratelimit-remaining") == "0") {
                throw RateLimited((resp.header("x-ratelimit-reset")?.toLongOrNull() ?: 0L) * 1000L)
            }
            if (resp.code == 404) throw IllegalStateException("저장소나 워크플로를 찾지 못했어요 (비공개 저장소는 볼 수 없어요)")
            if (!resp.isSuccessful) throw IllegalStateException("서버 응답 오류 (${resp.code})")
            val text = resp.body?.string() ?: throw IllegalStateException("빈 응답")
            resp.header("ETag")?.let { synchronized(etags) { etags[url] = it } }
            synchronized(bodies) { bodies[url] = text }
            return text
        }
    }

    private fun parseTime(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (e: Exception) { 0L }

    private fun fetch(): Snapshot? {
        val base = "https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/actions"
        val runs = JSONObject(get("$base/runs?per_page=1")).optJSONArray("workflow_runs")
        if (runs == null || runs.length() == 0) return null
        val run = runs.getJSONObject(0)
        val id = run.getLong("id")
        val status = run.optString("status")
        val steps = ArrayList<Step>()
        val jobs = JSONObject(get("$base/runs/$id/jobs")).optJSONArray("jobs")
        if (jobs != null && jobs.length() > 0) {
            val st = jobs.getJSONObject(0).optJSONArray("steps")
            if (st != null) for (i in 0 until st.length()) {
                val s = st.getJSONObject(i)
                steps.add(Step(s.optString("name"), s.optString("status"), s.optString("conclusion").ifEmpty { null }))
            }
        }
        return Snapshot(
            title = run.optString("display_title").ifEmpty { "빌드 #${run.optInt("run_number")}" },
            status = status,
            conclusion = run.optString("conclusion").ifEmpty { null },
            startedAt = parseTime(run.optString("run_started_at")),
            steps = steps
        )
    }

    fun show(act: Activity) {
        if (!Updater.enabled()) {
            AppToast.show(act, "업데이트 저장소가 설정되지 않았어요 (GitHub Actions 로 빌드한 앱에서만 동작해요)")
            return
        }
        val dp = act.resources.displayMetrics.density
        val status = TextView(act).apply { textSize = 15f; text = "불러오는 중…" }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; isIndeterminate = true
        }
        val elapsed = TextView(act).apply { textSize = 12f; alpha = 0.7f }
        val stepsView = TextView(act).apply { textSize = 13f; setLineSpacing(0f, 1.25f) }
        val scroll = ScrollView(act).apply { addView(stepsView) }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((24 * dp).toInt(), (12 * dp).toInt(), (24 * dp).toInt(), 0)
            addView(status)
            addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (10 * dp).toInt() })
            addView(elapsed, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (6 * dp).toInt() })
            addView(scroll, LinearLayout.LayoutParams(-1, (200 * dp).toInt()).apply { topMargin = (10 * dp).toInt() })
        }

        val stopped = AtomicBoolean(false)
        val busy = AtomicBoolean(false)
        var last: Snapshot? = null

        val dlg = MaterialAlertDialogBuilder(act)
            .setTitle("빌드 진행 상황")
            .setView(box)
            .setPositiveButton("닫기", null)
            .setNeutralButton("업데이트 확인") { _, _ -> Updater.manualCheck(act) }
            .setOnDismissListener { stopped.set(true) }
            .show()

        fun render(s: Snapshot) {
            val done = s.steps.count { it.status == "completed" }
            val total = s.steps.size
            val finished = s.status == "completed"
            status.text = when {
                finished && s.conclusion == "success" -> "✓ 빌드 완료 — ${s.title}"
                finished && s.conclusion == "cancelled" -> "빌드가 취소됐어요 — ${s.title}"
                finished -> "✗ 빌드 실패 — ${s.title}"
                s.status == "queued" -> "대기 중… — ${s.title}"
                else -> "빌드 중 ($done/$total 단계) — ${s.title}"
            }
            if (finished) {
                bar.isIndeterminate = false
                bar.progress = if (s.conclusion == "success") 100 else (if (total > 0) done * 100 / total else 0)
            } else if (total == 0 || s.status == "queued") {
                bar.isIndeterminate = true
            } else {
                bar.isIndeterminate = false
                bar.progress = done * 100 / total
            }
            stepsView.text = s.steps.joinToString("\n") { st ->
                val mark = when {
                    st.status == "completed" && (st.conclusion == "success" || st.conclusion == "skipped") -> "✓"
                    st.status == "completed" -> "✗"
                    st.status == "in_progress" -> "▶"
                    else -> "○"
                }
                "$mark  ${st.name}"
            }
            elapsed.text = if (s.startedAt > 0 && !finished) {
                val sec = ((System.currentTimeMillis() - s.startedAt) / 1000).coerceAtLeast(0)
                "경과 ${sec / 60}분 ${sec % 60}초"
            } else if (finished) "끝났어요. 새 버전이면 '업데이트 확인'을 누르세요" else ""
            if (finished && s.conclusion == "success") elapsed.visibility = View.VISIBLE
        }

        fun tick() {
            if (stopped.get() || !busy.compareAndSet(false, true)) return
            Thread {
                var snap: Snapshot? = null
                var err: String? = null
                var halt = false
                try {
                    snap = fetch()
                    if (snap == null) err = "아직 빌드 기록이 없어요"
                } catch (e: RateLimited) {
                    val min = ((e.resetAt - System.currentTimeMillis()) / 60000).coerceAtLeast(1)
                    err = "GitHub 요청 한도에 도달했어요. 약 ${min}분 뒤에 다시 열어 주세요"
                    halt = true
                } catch (e: Exception) {
                    err = e.message ?: "네트워크 오류"
                }
                main.post {
                    busy.set(false)
                    if (stopped.get() || act.isFinishing || act.isDestroyed) return@post
                    if (snap != null) { last = snap; render(snap) }
                    else if (err != null && last == null) { status.text = err; bar.isIndeterminate = false; bar.progress = 0 }
                    val finished = snap?.status == "completed"
                    if (halt || finished) stopped.set(true) // 끝났거나 한도에 걸리면 더 묻지 않는다
                    else main.postDelayed({ tick() }, POLL_MS)
                }
            }.start()
        }
        tick()
    }
}
