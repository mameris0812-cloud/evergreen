package com.example.evergreen

import android.app.Activity
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * 설정 > 앱 정보 > '업데이트 로그': 버전별로 바뀐 내용을 보여 준다.
 * 새 버전을 낼 때마다 [ENTRIES] 맨 위에 한 항목씩 더한다 (최신이 위).
 */
object Changelog {

    class Entry(val version: String, val date: String, val notes: List<String>)

    val ENTRIES: List<Entry> = listOf(
        Entry(
            "2.6.27", "2026-11-10", listOf(
                "메뉴창 미디어 플레이어: 일시정지 버튼과 10초 이동 버튼 사이 간격을 약 30dp로 맞춤"
            )
        ),
        Entry(
            "2.6.26", "2026-11-10", listOf(
                "메뉴창 미디어 플레이어: 재생/일시정지 버튼과 10초 이동 버튼 사이 여백을 살짝 줄임"
            )
        ),
        Entry(
            "2.6.25", "2026-11-10", listOf(
                "유튜브 광고가 시작될 때 로딩이 오래 걸리던 문제 개선",
                "광고를 끝으로 넘길 때 0.25초마다 계속 옮기던 것을 광고 하나당 한 번만 옮기도록 고침",
                "유튜브 광고 차단이 켜져 있으면 유튜브에서 구글 광고 서버 요청을 막지 않고 통과시킴 (막으면 광고가 안 불러와져 유튜브가 한참 기다림)"
            )
        ),
        Entry(
            "2.6.24", "2026-11-10", listOf(
                "설정 > 앱 정보에 '업데이트 로그' 추가"
            )
        ),
        Entry(
            "2.6.23", "2026-11-10", listOf(
                "유튜브 광고 차단 개선: 영상 정보에서 광고 목록을 미리 지워 광고가 시작되지 않게 함",
                "광고의 '건너뛰기' 버튼이 스크립트 클릭으로 안 눌리면 앱이 진짜 터치로 눌러 줌",
                "설정 > 광고 차단에 '유튜브 광고 미리 지우기' 켜고 끄기 추가"
            )
        )
    )

    fun show(act: Activity) {
        val dp = act.resources.displayMetrics.density
        val sb = SpannableStringBuilder()
        ENTRIES.forEachIndexed { i, e ->
            if (i > 0) sb.append("\n\n")
            val head = "v${e.version}"
            val s = sb.length
            sb.append(head)
            sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(RelativeSizeSpan(1.1f), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (e.version == BuildConfig.VERSION_NAME) sb.append("  · 현재 버전")
            sb.append("\n").append(e.date)
            e.notes.forEach { sb.append("\n• ").append(it) }
        }
        val tv = TextView(act).apply {
            text = sb
            textSize = 14f
            setLineSpacing(0f, 1.2f)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(act).apply {
            addView(
                LinearLayout(act).apply {
                    setPadding((24 * dp).toInt(), (8 * dp).toInt(), (24 * dp).toInt(), (8 * dp).toInt())
                    addView(tv)
                }
            )
        }
        MaterialAlertDialogBuilder(act)
            .setTitle("업데이트 로그")
            .setView(scroll)
            .setPositiveButton("닫기", null)
            .show()
    }
}
